#!/usr/bin/env bash

set -e

python -m unittest discover -s python_scripts/test -p "*_test.py"