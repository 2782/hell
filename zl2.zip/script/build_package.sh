#!/usr/bin/env bash

GRADLE_TEST_IMAGE_NAME="sysco/prime:alpine-java8-gradle"

PROJECT_HOME=$(cd `dirname $0`/../ && pwd)

./fetchKeystore.sh

docker run --rm -t \
    -v ${HOME}.gradle:/root/.gradle \
    -v ${PROJECT_HOME}:/opt/app \
    -w /opt/app \
    ${GRADLE_TEST_IMAGE_NAME} ./gradlew clean bootJar

sudo chown -R go:go ../build
