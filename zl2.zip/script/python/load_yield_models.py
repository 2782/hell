#!/usr/bin/env python

import csv
import json
import sys
import copy

import requests


# TODO: Lie to pass validation. When API saves, it recalcs the cost
def let_api_calculate_cost():
    return 1


def load_cutting_yield_models(file_path):
    with open(file_path, 'r') as csvfile:
        data = []
        reader = csv.DictReader(csvfile)
        for row in reader:
            if any(row.values()):
                yield_model = parse_cutting_yield_model_row(row)
                data.append(yield_model)
        return json.dumps(data)


def load_grinding_yield_models(file_path):
    with open(file_path, 'r') as csvfile:
        data = []
        reader = csv.DictReader(csvfile)
        for row in reader:
            if any(row.values()):
                yield_model = parse_grinding_yield_model_row(row)
                data.append(yield_model)
        return json.dumps(data)


def load_yield_model_groups(file_path):
    with open(file_path, 'r') as csvfile:
        data = []
        reader = csv.DictReader(csvfile)
        for row in reader:
            if any(row.values()):
                yield_model = parse_yield_model_group_row(row)
                data.append(yield_model)
        return json.dumps(data)


def pad_with_zeros(cell):
    if cell.isdigit():
        return cell.zfill(7)
    return cell


def parse_yield_model_group_row(row):
    finishedProductCodes = parse_finishedproducts(row)
    return {
        "productGroupName": pad_with_zeros(row["Primary Product Number / Blend Name"]),
        "finishedProductCodes": finishedProductCodes
    }


def parse_finishedproducts(row):
    finishedproducts = []

    productRow = copy.deepcopy(row)
    productRow.pop("Primary Product Number / Blend Name", None)

    for key, value in productRow.items():
        finishedproducts.append(pad_with_zeros(value))

    return filter(lambda product: bool(product.strip()), finishedproducts)


def parse_cutting_yield_model_row(row):
    byproducts = parse_byproducts(row)
    additives = parse_additives(row)
    pricing_model = row["Pricing Model"].lower() in ["yes", "true"]
    return {
        "finishedProductCode": pad_with_zeros(row["Finished Product #"]),
        "finishedProductCost": let_api_calculate_cost(),
        "sourceProductCode": pad_with_zeros(row["Source Product #"]),
        "labor": row["Labor"],
        "packaging": row["Packaging"],
        "overhead": row["Overhead"],
        "pricingModel": pricing_model,
        "yieldByproducts": byproducts,
        "yieldAdditives": additives,
        "sourceLbs": row["Source lbs"],
        "pickupPercent": row["Pickup %"]
    }


def parse_grinding_yield_model_row(row):
    source_products = parse_grinding_source_products(row);
    pricing_model = row["Pricing Model"].lower() in ["yes", "true"]
    return {
        'blend': row['Blend Name'],
        'wastePercentage': row['Waste %'],
        'labor': row['Labor'],
        'additives': row['Additives'],
        'packaging': row['Packaging'],
        'overhead': row['Overhead'],
        'pricingModel': pricing_model,
        'sourceProducts': source_products
    }


def parse_grinding_source_products(row):
    source_products = []
    number_of_source_products_str = row["# of Source Products"]
    number_of_source_products = int(number_of_source_products_str) if number_of_source_products_str else 0
    if number_of_source_products > 0:
        for j in range(number_of_source_products):
            additive = {
                "code": pad_with_zeros(row["Source {0}".format(j + 1)]),
                "blendPercentage": row["Blend % {0}".format(j + 1)]
            }
            source_products.append(additive)
    return source_products


def parse_additives(row):
    additives = []
    number_of_additives_str = row["# of Additives"]
    number_of_additives = int(number_of_additives_str) if number_of_additives_str else 0
    if number_of_additives > 0:
        for j in range(number_of_additives):
            additive = {
                "productCode": pad_with_zeros(row["Additive {0}".format(j + 1)]),
                "weight": row["Weight (lbs) {0}".format(j + 1)]
            }
            additives.append(additive)
    return additives


def parse_byproducts(row):
    byproducts = []
    number_of_byproducts_str = row["# of Byproducts"]
    number_of_byproducts = int(number_of_byproducts_str) if number_of_byproducts_str else 0
    if number_of_byproducts > 0:
        for i in range(number_of_byproducts):
            byproduct = {
                "byproductCode": pad_with_zeros(row["Byproduct {0}".format(i + 1)]),
                "yieldPercentage": row["BP Yield % {0}".format(i + 1)],
                "cost": row["BP Cost {0}".format(i + 1)],
                "labor": row["BP Labor {0}".format(i + 1)]
            }
            byproducts.append(byproduct)
    return byproducts


def api_post(host, path, data, session_cookie):
    url = host + path

    if session_cookie is None:
        cookies = None
    else:
        cookies = requests.cookies.RequestsCookieJar()
        cookies.set('SESSION', session_cookie)

    return requests.post(url, data=data, headers={"Content-type": "application/json"}, cookies=cookies)


if __name__ == '__main__':
    if len(sys.argv) < 4 or len(sys.argv) > 5:
        print >> sys.stderr, "Usage: {0} cutting|grinding <prime-api-url-base> <csv-file> [session-cookie]".format(
            sys.argv[0])
        sys.exit(1)

    model_type = sys.argv[1]
    prime_api_url_base = sys.argv[2]
    csv_file = sys.argv[3]
    session_cookie = sys.argv[4] if 5 == len(sys.argv) else None

    if 'cutting' == model_type:
        payload = load_cutting_yield_models(csv_file)
        prime_api_path = '/api/yield-models/cutting'
    elif 'grinding' == model_type:
        payload = load_grinding_yield_models(csv_file)
        prime_api_path = '/api/yield-models/grinding'
    elif 'group' == model_type:
        payload = load_yield_model_groups(csv_file)
        prime_api_path = '/api/products/groups/load'
    else:
        print >> sys.stderr, "Usage: {0} cutting|grinding|group <prime_api_host> <csv_file> [session-cookie]".format(
            sys.argv[0])
        sys.exit(1)

    response = api_post(prime_api_url_base, prime_api_path, payload, session_cookie)
    status = response.status_code

    if not status == requests.codes.created:
        print >> sys.stderr, \
            "{0}: Loading {1} yield models to {2} failed reading from {3}; no yield models loaded.".format(
                sys.argv[0], model_type, prime_api_url_base, csv_file)
        print >> sys.stderr, "Status:", status
        print >> sys.stderr, response.json()
        sys.exit(1)
