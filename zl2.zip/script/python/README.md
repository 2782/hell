# Setup
## Python Installation
* Install python2 [You can follow the instructions at the Hitchhiker's guide to
  Python](https://docs.python-guide.org/starting/installation/#legacy-python-2-installation-guides).
* Install pip
* Install the necessary python packages

```bash
pip install requests pytest pytest-cache
```
## Running unit tests (devs only)

```bash
pytest load_yield_models_test.py
```

## Usage
* Run the script with no arguments see usage instructions printed out
```
./load_yield_models.py
```

# Bulk upload of YMs

## Testing

### Local

There are python unit tests you can run by running `pytest` (installation
instructions above) in _this directory_. 

Testing the upload of data from csv's into Prime is manual. From _this
directory_, in a separate window bring up the API server, and try:

```
for csv_file in ../sample-csv/*.csv
do
    echo $csv_file:
    ./load_yield_models.py cutting http://localhost:8081 $csv_file
done
```

Then monitor the output.

- The "good" file should produce no output
- The "bad" file for malformed Excel export should say:

```$xslt
Traceback (most recent call last):
  File "./load_yield_models.py", line 87, in <module>
    payload = load_cutting_yield_models(prime_api_url_base, csv_file)
  File "./load_yield_models.py", line 21, in load_cutting_yield_models
    byproducts = parse_byproducts(row)
  File "./load_yield_models.py", line 61, in parse_byproducts
    "byproductCode": row["Byproduct {0}".format(i + 1)],
KeyError: 'Byproduct 3'
```

- The "bad" file for product code not found should say:

```
./load_yield_models.py: Loading cutting yield models to http://localhost:8081 failed reading from ../sample-csv/cutting-yield-model-sample-bad-finished-code.csv; no yield models loaded.
Status: 422
{u'status': 0, u'exceptionMessage': u'0961172 is NOT_EXIST for createAll.request[1].finishedProductCode', u'timestamp': 1544547801518, u'exceptionClass': u'org.opensaml.xml.validation.ValidationException', u'statusText': u'', u'path': u'/api/yield-models', u'method': u'POST'}
```

Note that when local CSV parsing works, but validation in the API fails, the
resulting JSON back from the API uses 0-based indexing, so the above example
reads `request[1]` to indicate the 2nd line of CSV had a bad product code.

### Dev

For Dev environment, see [PRODUCTION.md](../../PRODUCTION.md) for the
hostname to use as Prime API URL base in the 2nd argument.

### QA and higher environments

For QA and higher environments, see [PRODUCTION.md](../../PRODUCTION.md)
for the hostname to use as Prime API URL base in the 2nd argument.

Additionally, supply the additional 4th of a cookie value, also
described in `PRODUCTION.md`.
