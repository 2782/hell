#!/usr/bin/env bash

export PS4='+${BASH_SOURCE}:${LINENO}:${FUNCNAME[0]:+${FUNCNAME[0]}():} '

set -e
set -u
set -o pipefail

readonly progname="${0##*/}"
readonly version=1

fmt=fmt
function -setup-terminal {
    if [[ ! -t 1 ]]
    then
        readonly fmt
        return 0
    fi

    : "${LINES:=$(tput lines)}"
    export LINES
    : "${COLUMNS:=$(tput cols)}"
    export COLUMNS

    local -r fmt_width=$((COLUMNS - 5))
    if (( fmt_width < 10 ))
    then
        echo "$progname: Your terminal is too narrow." >&2
        exit 2
    fi
    fmt="fmt -w $fmt_width"
    readonly fmt
}

function -setup-colors {
    local -r ncolors=$(tput colors)

    if $color && (( ${ncolors-0} > 7 ))
    then
        printf -v pblack "$(tput setaf 0)"
        printf -v pred "$(tput setaf 1)"
        printf -v pgreen "$(tput setaf 2)"
        printf -v pyellow "$(tput setaf 3)"
        printf -v pblue "$(tput setaf 4)"
        printf -v pmagenta "$(tput setaf 5)"
        printf -v pcyan "$(tput setaf 6)"
        printf -v pwhite "$(tput setaf 7)"
        printf -v pbold "$(tput bold)"
        printf -v punderline "$(tput smul)"
        printf -v pblink "$(tput blink)"
        printf -v pinvisible "$(tput invis)"
        printf -v preverse "$(tput rev)"
        printf -v preset "$(tput sgr0)"

        printf $preset  # Clear changes to help debugging
    else
        pblack=''
        pred=''
        pgreen=''
        pyellow=''
        pblue=''
        pmagenta=''
        pcyan=''
        pwhite=''
        pbold=''
        punderline=''
        pblink=''
        pinvisible=''
        preverse=''
        preset=''
    fi
    readonly pred
    readonly pgreen
    readonly pyellow
    readonly pblue
    readonly pmagenta
    readonly pcyan
    readonly pwhite
    readonly pbold
    readonly punderline
    readonly pblink
    readonly pinvisible
    readonly preverse
    readonly preset
}

DISTRIB_ID=
if [[ -r /etc/lsb-release ]]
then
    . /etc/lsb-release
fi

cygwin=false
ubuntu=false
psql=psql
case $(uname) in
    *CYGWIN* ) cygwin=true ;;
    * ) case "$DISTRIB_ID" in
        Ubuntu )
            ubuntu=true
            psql='sudo -u postgres psql'
            pg_sql='sudo -u postgres /usr/lib/postgresql/10/bin/pg_sql'
            ;;
	esac ;;
esac

if $cygwin
then
    export PGDATA=/usr/share/postgresql/data
    export PATH="/usr/sbin:$PATH"
elif $ubuntu
then
    export PGDATA=/var/lib/postgresql/10/data
    export PATH="/usr/lib/postgresql/10/bin:$PATH"
else
    export PGDATA=/usr/local/var/postgres
fi
readonly pg_ctl="pg_ctl -l $PWD/postgres.log"



# Note to editors:
# In support of "help" features, please add new functions (new commands)
# up here near the top of the file.  Help functions are named after their
# task following the pattern, "-TASK-help".

function install-git-hooks {
    for hook in etc/git-hooks/*
    do
        local hook_name=${hook##*/}
        $verbose && echo "$progname: Symlinking $hook into .git/hooks/$hook_name"
        if [[ -e .git/hooks/$hook_name ]]
        then
            echo "$progname: Replacing $hook_name" >&2
        fi
        (cd .git/hooks ; ln -sf ../../$hook $hook_name)
    done
}

function -install-git-hooks-help {
    cat <<EOH
Installs any GIT hooks found under etc/git-hooks into your local repository:
EOH
    for hook in etc/git-hooks/*
    do
        echo "   - ${hook##*/}"
    done
}

function delete-database {
    $run $pg_ctl stop || true
    $run rm -rf $PGDATA || true
}

function -delete-database-help {
    cat <<EOH
Stops Postgres, and deletes all files in $PGDATA.
EOH
}

function -ensure-postgres-is-running {
    $run $pg_ctl status || $run $pg_ctl start
}

function install-postgres {
    if $cygwin
    then
        cat <<EOM | $fmt
Assuming Postgres already set up for Cygwin.
If not, see https://blog.dbi-services.com/postgresql-on-cygwin/
EOM
    elif $ubuntu
    then
        $run sudo -u postgres apt install postgresql postgresql-contrib
    else
        $run brew list postgresql >/dev/null 2>&1 || $run brew install postgresql
    fi
    $run initdb || true
    $run initdb -s
    -ensure-postgres-is-running
    sleep 5
}

function -install-postgres-help {
    cat <<EOH
On MacOS, installs Postgres with homebrew, initializes the database, and starts it in the background.

On Cygwin, initializes the database, and starts it in the background.  (BROKEN)

On Ubuntu, installs Postgres with apt, initializes the database, and starts it in the background.  (UNTESTED)
EOH
}

function make-schema {
    -ensure-postgres-is-running
    local sql
    read -d '' sql <<SQL || true
CREATE DATABASE prime;
CREATE DATABASE "prime-test";
CREATE DATABASE "prime-integrationtest";
CREATE USER "primeApp" WITH PASSWORD 'password';
GRANT ALL PRIVILEGES ON DATABASE prime to "primeApp";
GRANT ALL PRIVILEGES ON DATABASE "prime-test" to "primeApp";
GRANT ALL PRIVILEGES ON DATABASE "prime-integrationtest" to "primeApp";
SQL
    if [[ -n "$run" ]]
    then
        $run "echo \"$sql\" | $psql postgres"
    else
        echo "$sql" | $psql postgres
    fi

    update-liquibase
}

function -make-schema-help {
    cat <<EOH
Creates the Prime databases and users in Postgres, and updates liquibase.
EOH
}

function reset-data {
    $run ./api-test/test_data.sh reset ${1-local}
}

function -reset-data-help {
    cat <<EOH
Restores database data to initial values using "delete_data.sql" and "insert_data.sql".
EOH
}

function reset-database {
    delete-database
    install-postgres
    make-schema
    reset-data
}

function -reset-database-help {
    cat <<EOH
Fully recreates the database schema and data.  Useful after switching branches with Liquibase changes.
EOH
}

function full-build {
    -ensure-postgres-is-running
    $run ./gradlew  # Default tasks: clean build
}

function -full-build-help {
    cat <<EOH
Runs a Gradle clean build.
EOH
}

function initialize-api-tests {
    $run cd ./api-test
    $run npm install || true
    $run cd ..
}

function -initialize-api-tests-help {
    cat <<EOH
Runs "npm install" in the api-test directory.
EOH
}

function api-tests {
    -ensure-postgres-is-running
    $run ./gradlew bootRun &
    local api_pid=$!
    $run trap "kill $api_pid" EXIT

    $run sleep 30  # TODO: Actively check when API server is ready
    if ! kill -0 $api_pid 2>/dev/null
    then
        echo "$progname: API failed to start" >&2
        wait $api_pid
        return $?
    fi

    $run ./gradlew apiTest
}

function -api-tests-help {
    cat <<EOH
Runs the application in the background, runs API tests against it, and stops the application afterwards.
EOH
}

function rollback-liquibase {
    local count="${1-1}"

    $run ./gradlew -PliquibaseCommandValue=$count rollbackCount
}

function -rollback-liquibase-help {
    cat <<EOH
Rolls back N liquibase changes (not scripts).  Note: a liquibase script may have multiple changes.
EOH
}

function update-liquibase {
    $run ./gradlew update
}

function -update-liquibase-help {
    cat <<EOH
Runs all liquibase scripts, updating local database to current.
EOH
}

function restart-postgres {
    $run $pg_ctl stop || true
    -ensure-postgres-is-running
}

function -restart-postgres-help {
    cat <<EOH
Stop Postgres, and starts it again.
EOH
}

function pr-checks {
    -are-all-files-committed
    -is-master-merged-into-branch
    full-build
    api-tests
}

function -pr-checks-help {
    cat <<EOH
Runs all PR pre-checks.

You should use this task before merging your PR branch into master.
EOH
}

function -read-password {
    local var=$1
    local prompt="$2"
    read -rs -p "$prompt" $var
    echo
}

function app {
    local profileauth=noauth
    local profilescale=dummyscale
    local profilesus=dummysus
    local profileprinter=dummyprinter
    local realauth=false
    local realscale=false
    local realsus=false
    local realprinter=false
    local opt
    while getopts :-: opt
    do
        [[ - == $opt ]] && opt=${OPTARG%%=*} OPTARG=${OPTARG#*=}
        case $opt in
        A | real-auth ) realauth=true ;;  # TODO: dummyauth
        C | real-scale ) realscale=true ;;
        P | real-printer ) realprinter=true ;;
        S | real-sus ) realsus=true ;;
        * ) echo "$progname: app [-CS]" >&2 ; exit 2 ;;
        esac
    done
    shift $((OPTIND - 1))

    local flags=()

    if $realauth
    then
        profileauth=auth
    fi

    if $realscale
    then
        profilescale=realscale
    fi

    if $realsus
    then
        cat <<EOM | $fmt
Using real SUS requires a client ID and client secret from API Central.  Have those ready for the prompts below.

EOM

        local client_id client_secret
        if [[ -n "${API_CENTRAL_CLIENT_ID:-}" ]]
        then
            client_id="$API_CENTRAL_CLIENT_ID"
            $verbose && echo "$progname: Using API Central client ID from environment"
        else
            -read-password client_id 'ID: '
        fi
        if [[ -n "${API_CENTRAL_CLIENT_SECRET:-}" ]]
        then
            client_secret="$API_CENTRAL_CLIENT_SECRET"
            $verbose && echo "$progname: Using API Central client secret from environment"
        else
            -read-password client_secret 'Secret: '
        fi

        profilesus=realsus
        flags=("${flags[@]}" \
            '-Dsus.service.domain=https://api-qa.sysco.com' \
            '-Dsus.subscribe.domain=http://sus-prime-qa.aws-us-east-1.na.sysco.tst' \
            '-Doauth2.api.central.access.token.uri=https://api-qa.sysco.com/token' \
            "-Doauth2.api.central.client.id=$client_id" \
            "-Doauth2.api.central.client.secret=$client_secret")
    fi

    if $realprinter
    then
        profileprinter=realprinter
    fi

    # Force color if printing to console; leave color out if in a shell pipe or redirected to file
    if [[ -t 1 ]]
    then
        flags=(${flags[@]+"${flags[@]}"} -Dspring.output.ansi.enabled=always)
    fi

    flags=(${flags[@]+"${flags[@]}"} "-Dspring.profiles.active=$profileauth,$profilescale,$profilesus,$profileprinter")

    -ensure-postgres-is-running
    $run ./gradlew "${flags[@]}" bootRun
}

function -app-help {
    cat <<EOH
Runs the application in the foreground
   -C   Use real scale in Houston
   -S   Use real SUS
EOH
}

function docker-app {
    if $cygwin || $ubuntu
    then
        echo "$program: Only Mac supports Docker with external Postgres (FIXME)" >&2
        exit 2
    fi

    ./gradlew docker
    docker run -p 8081:8081/tcp -e PG_HOSTNAME=docker.for.mac.host.internal "$@" sysco/prime-api:0.1.0-local
}

function -docker-app-help {
    cat <<EOH
Runs the application in the local docker container with default Spring profiles

Additional command-line arguments are passed to Docker
EOH
}

function read-scale {
    curl \
        -X POST \
        -u admin:PASS \
        -d 'group=Line' \
        -d 'optionalGroupInstance=1' \
        -d 'action=Command n=100 m=1000 t=0D 0a050d' \
        http://sgx5150-0080a3c7417a.na.sysco.net/action/status
}

function -read-scale-help {
    cat <<EOH
Read the Houston dev scale.
EOH
}

declare -a tasks=($(declare -F | cut -d' ' -f3 | grep -v '^-' | sort))

# Internal functions and rest of script

function -print-usage {
    local all_tasks="${tasks[@]}"
    cat <<EOU | $fmt
Usage: $progname [-c|--color|--no-color] [-d|--debug] [-h|--help] [-n|--dry-run] [-v|--verbose] [${tasks[@]}]
EOU
}

function -format-help {
   $fmt | sed 's/^/       /'
}

function -print-help {
    echo "$progname, version $version"
    -print-usage
    cat <<EOH

Flags:
  -c, --color     Print in color
      --no-color  Print without color
  -d, --debug     Print debug output while running
  -h, --help      Print help and exit normally
  -n, --dry-run   Do nothing (dry run); echo actions
  -v, --verbose   Verbose output

Tasks:
EOH
    for task in "${tasks[@]}"
    do
        local help_fn="-$task-help"
        echo "  * $task"
        if declare -F -- $help_fn >/dev/null 2>&1
        then
            $help_fn | -format-help
        fi
    done
}

-setup-terminal

[[ -t 1 ]] && color=true || color=false
debug=false
run=
verbose=false
while getopts :-: opt
do
    [[ - == $opt ]] && opt=${OPTARG%%=*} OPTARG=${OPTARG#*=}
    case $opt in
    c | color ) color=true ;;
    no-color ) color=false ;;
    d | debug ) debug=true ;;
    h | help ) -print-help ; exit 0 ;;
    n | dry-run ) run=echo ;;
    v | verbose ) verbose=true ;;
    * ) -print-usage >&2
        echo "Try '$progname --help' for more information." >&2
        exit 2
        ;;
    esac
done
shift $((OPTIND - 1))

readonly color
readonly debug
readonly run
readonly verbose

case $# in
0 ) ;;
* ) # TODO: This is ugly code
    cmd="$1"
    found=false
    for task in "${tasks[@]}"
    do
        [[ "$cmd" == "$task" ]] && found=true
    done
    $found || {
        echo "$progname: $cmd: Unknown command." >&2
        echo "Try '$progname --help' for more information." >&2
        -print-usage >&2
        exit 2
    }
    ;;
esac

-setup-colors
$debug && set -x

function -ask-nicely-to-continue {
    cat <<EOM
Welcome to the Prime API onboarding script!

These are the things I'll do.  I'll ask you first if it's ok:

- Wipe your local Postgres database -- THIS IS DESTRUCTIVE AND PERMANENT
- Install Postgres, if you don't already have an installation
- Install the Prime DB Schema into Postgres, and any Liquibase updates
- Reset the Prime data to "known state"
- Run the full, clean build of the API
- Update the NPM modules for the api tests
- Bring up the API server in the background, and run the API tests
- Shut down API server and Postgres (TODO: Do not shutdown Postgres)

Hopefully it all goes well!
EOM

    readonly prompt="Are you OK with ${pred}replacing your database${preset}, and building Prime? (y/${pbold}n${preset}) "
    read -p "$prompt" -n 1 -r
    echo
    case $REPLY in
    y|Y ) true ;;
    * ) false ;;
    esac
}

function -are-all-files-committed {
    if [[ -n "$run" ]]
    then
        $run 'git ls-files . --exclude-standard --modified | grep .'
        $run 'git ls-files . --exclude-standard --other | grep .'
        return
    fi

    if git ls-files . --exclude-standard --modified | grep .
    then
        echo "$progname: Modified files not committed" >&2
        false
    elif git ls-files . --exclude-standard --other | grep .
    then
        echo "$progname: Untracked files not committed" >&2
        false
    elif git ls-files . --exclude-standard --deleted | grep .
    then
        echo "$progname: Deleted files not committed" >&2
        false
    elif git diff --name-only HEAD | grep .
    then
        echo "$progname: Files added but not committed" >&2
        false
    elif git ls-files . --exclude-standard --unmerged | grep .
    then
        echo "$progname: Merge incomplete" >&2
        false
    fi
}

function -is-master-merged-into-branch {
    local branch="$(git rev-parse --abbrev-ref HEAD)"
    if [[ -n "$run" ]]
    then
        $run 'git branch --no-merged | grep -q master'
        $run 'git branch --remote --no-merged | grep -q origin/master'
        return
    fi
    if git branch --no-merged | grep -q master
    then
        echo "$progname: Latest local master not merged into branch: $branch" >&2
        false
    fi
    if git branch --remote --no-merged | grep -q origin/master
    then
        echo "$progname: Latest remote master not merged into branch: $branch" >&2
        false
    fi
}


case $# in
0 ) ;;
* ) "$@" ; exit ;;
esac


-ask-nicely-to-continue
install-git-hooks
delete-database
install-postgres
make-schema
reset-data
full-build
initialize-api-tests
api-tests
pr-checks
