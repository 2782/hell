#!/usr/bin/env bash

set -e
PROJECT_HOME=$(cd `dirname $0`/ && pwd)

VERSION_NUMBER=${1:?"Please specify your version number"}

./gradlew clean bootJar

mkdir -p ${PROJECT_HOME}/tmp

cp -r build ${PROJECT_HOME}/tmp/
cp docker/run-app/Dockerfile ${PROJECT_HOME}/tmp/

IMAGE_NAME="sysco/prime-api:0.1.0-${VERSION_NUMBER}-alb-test"

cd ${PROJECT_HOME}/tmp

docker build --rm --tag ${IMAGE_NAME} .

docker push ${IMAGE_NAME}

cd ${PROJECT_HOME}

rm -rf tmp/*
