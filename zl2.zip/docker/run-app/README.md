#####build prime-api docker image

should build by ../../script/build_image.sh
