build docker image
```
docker build --rm --tag sysco/prime:alpine-java8-gradle .
```
