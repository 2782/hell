package com.sysco.prime;

import com.sysco.prime.cost.Cost;
import com.sysco.prime.cost.CostResponse;
import com.sysco.prime.cost.CostService;
import com.sysco.prime.cost.Money;
import com.sysco.prime.product.ProductService;
import com.sysco.prime.profile.Profile;
import com.sysco.prime.sus.eventProcessors.CostProcessor;
import com.sysco.prime.sus.model.SusProductCostNotificationData;
import io.restassured.response.Response;
import org.junit.Ignore;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.io.IOException;
import java.math.BigDecimal;
import java.time.LocalDate;

import static com.sysco.prime.cost.Cost.COST_NEVER_EXPIRES;
import static com.sysco.prime.cost.CostSource.SUS;
import static io.restassured.RestAssured.get;
import static io.restassured.http.ContentType.JSON;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

public class CostIntegrationTest extends IntegrationTestBase {
    @Autowired
    private CostProcessor processor;
    // Workaround lack of API client-facing endpoints to extract weighted average cost
    @Autowired
    private ProductService productService;
    @Autowired
    private CostService costService;

    @Test
    public void shouldGetUpdatedCostFromSus() throws IOException {
        final String sourceProductCode = "2020766";

        final CostResponse oldCost = getPartialCostsPublically(sourceProductCode);

        assertThat(oldCost, is(CostResponse.builder()
                .cost(Money.ofCost(6.268))
                .labor(Money.zero())
                .build()));

        final Response profileResponse = get(getHostName() + "/api/profile")
                .then()
                .statusCode(200)
                .contentType(JSON)
                .extract().response();

        final Profile profile = readBodyAs(profileResponse, Profile.class);

        final LocalDate startDate = LocalDate.now();
        processor.run(SusProductCostNotificationData.builder()
                .sourceItemNumber(sourceProductCode)
                .opCo(profile.getPlantNumber())
                .startDate(startDate)
                .endDate(COST_NEVER_EXPIRES)
                .sequenceNumber(1)
                .marketCost(7.7)
                .weightedAverageCost(42)
                .build());

        final CostResponse newCost = getPartialCostsPublically(sourceProductCode);

        // TODO: will be modified by 1452
        assertThat(newCost, is(CostResponse.builder()
                .cost(Money.ofCost(7.7))
                .labor(Money.zero())
                .build()));

        final Cost fullCosts = getFullCostInternally(sourceProductCode);

        assertThat(fullCosts, is(Cost.builder()
                .name(sourceProductCode)
                .marketCost(Money.ofCost(7.7))
                .yieldModelId(null)
                .labor(Money.zero())
                .weightedAverageCost(Money.of(42))
                .currentCostPerPound(Money.of(7.7)) // Catch weight
                .startDate(startDate)
                .endDate(COST_NEVER_EXPIRES)
                .source(SUS)
                .build()));
    }

    public CostResponse getPartialCostsPublically(final String sourceProductCode) throws IOException {
        final Response response = get(getHostName() + "/api/cost/" + sourceProductCode)
                .then()
                .statusCode(200)
                .contentType(JSON)
                .extract().response();

        return readBodyAs(response, CostResponse.class);
    }

    private Cost getFullCostInternally(final String sourceProductCode) {
        return costService.findCost(productService.findByCode(sourceProductCode));
    }
}
