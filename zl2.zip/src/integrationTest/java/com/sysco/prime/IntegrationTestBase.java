package com.sysco.prime;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.type.CollectionType;
import com.sysco.Application;
import com.sysco.prime.IntegrationTestBase.RandomPortInitializer;
import com.sysco.prime.portionRoom.response.PortionRoomResponse;
import com.sysco.prime.product.response.ProductResponse;
import io.restassured.response.Response;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.context.ApplicationContextInitializer;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.jdbc.SqlConfig;
import org.springframework.test.context.junit4.SpringRunner;

import java.io.IOException;
import java.util.List;

import static io.restassured.RestAssured.with;
import static io.restassured.http.ContentType.JSON;
import static org.springframework.boot.test.context.SpringBootTest.WebEnvironment.DEFINED_PORT;
import static org.springframework.jdbc.datasource.init.ScriptUtils.EOF_STATEMENT_SEPARATOR;
import static org.springframework.test.context.support.TestPropertySourceUtils.addInlinedPropertiesToEnvironment;
import static org.springframework.util.SocketUtils.findAvailableTcpPort;

@RunWith(SpringRunner.class)
@SpringBootTest(
        webEnvironment = DEFINED_PORT,
        classes = Application.class)
@TestPropertySource(locations = "/config/application-integrationtest.properties")
@Sql({"/delete_data.sql", "/insert_data.sql"})
@SqlConfig(separator = EOF_STATEMENT_SEPARATOR)
@ContextConfiguration(initializers = RandomPortInitializer.class)
public abstract class IntegrationTestBase {
    @Autowired
    protected ObjectMapper mapper;

    @LocalServerPort
    protected int port;

    protected final String asJson(final Object body) throws JsonProcessingException {
        return mapper.writeValueAsString(body);
    }

    protected final <T> T readBodyAs(final Response response, final Class<T> type) throws IOException {
        return mapper.readValue(response.getBody().asInputStream(), type);
    }

    protected final <T> List<T> readPagedBodyAsListOf(final Response response, final Class<T> type) throws IOException {
        final CollectionType listOfType = mapper.getTypeFactory().constructCollectionType(List.class, type);
        return mapper.readValue(readBodyAs(response, JsonNode.class).get("content").toString(), listOfType);
    }

    protected final <T> List<T> readBodyAsListOf(final Response response, final Class<T> type) throws IOException {
        final CollectionType listOfType = mapper.getTypeFactory().constructCollectionType(List.class, type);
        return mapper.readValue(response.getBody().asInputStream(), listOfType);
    }

    protected final String getHostName() {
        return "http://localhost:" + port;
    }

    protected final void openRoom(final String roomCode) throws IOException {
        final Response roomResponse = with()
                .when()
                .get(getHostName() + "/api/rooms")
                .then()
                .statusCode(200)
                .contentType(JSON)
                .extract().response();

        final PortionRoomResponse room = readBodyAsListOf(roomResponse, PortionRoomResponse.class).stream()
                .filter(__ -> __.getCode().equals(roomCode))
                .findFirst()
                .orElseThrow(() -> new AssertionError("Room missing: " + roomCode));

        with().when()
                .post(getHostName() + "/api/rooms/" + room.getId() + "/open")
                .then()
                .statusCode(200);
    }

    protected final ProductResponse getProduct(final String productCode) throws IOException {
        final Response response = with().queryParam("productCode", productCode)
                .when()
                .get(getHostName() + "/api/products/by-code")
                .then()
                .statusCode(200)
                .contentType(JSON)
                .extract().response();

        return readBodyAs(response, ProductResponse.class);
    }

    /**
     * This hooks our randome port into the dummy SUS endpoints.
     *
     * @see <a href="https://github.com/spring-projects/spring-boot/issues/7759#issuecomment-269363307"><cite>Dynamic
     * SpringBootTest properties</cite></a>
     */
    public static class RandomPortInitializer implements ApplicationContextInitializer<ConfigurableApplicationContext> {
        @Override
        public void initialize(final ConfigurableApplicationContext configurableApplicationContext) {
            final int randomPort = findAvailableTcpPort();
            addInlinedPropertiesToEnvironment(configurableApplicationContext,
                    "server.port=" + randomPort,
                    "prime.server.name=localhost:" + randomPort);
        }
    }
}
