
package com.sysco.prime;

import com.sysco.prime.cost.Cost;
import com.sysco.prime.cost.CostRepository;
import com.sysco.prime.cost.CostSource;
import com.sysco.prime.cost.Money;
import com.sysco.prime.product.Product;
import com.sysco.prime.product.ProductGroup;
import com.sysco.prime.product.ProductGroupRepository;
import com.sysco.prime.product.ProductOutput;
import com.sysco.prime.product.ProductRepository;
import com.sysco.prime.yieldModel.CuttingYieldByproduct;
import com.sysco.prime.yieldModel.CuttingYieldModel;
import com.sysco.prime.yieldModel.CuttingYieldModelRepository;
import com.sysco.prime.yieldModel.CuttingYieldModelService;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Set;

import static com.sysco.prime.DummyObjectFactory.cuttingYieldModelBuilder;
import static com.sysco.prime.DummyObjectFactory.productBuilder;
import static com.sysco.prime.cost.Cost.COST_NEVER_EXPIRES;
import static com.sysco.prime.product.ProductGroup.cuttingProductGroup;
import static java.util.Collections.singletonList;
import static org.assertj.core.api.AssertionsForInterfaceTypes.assertThat;

public class SavingCuttingYieldModelTest extends IntegrationTestBase {

    @Autowired
    private ProductRepository productRepo;
    @Autowired
    private CuttingYieldModelRepository cuttingYieldModelRepo;
    @Autowired
    private ProductGroupRepository productGroupRepo;
    @Autowired
    private CostRepository costRepo;

    @Autowired
    private CuttingYieldModelService cuttingYieldModelService;

    private static final String finishedProductCode = "9999990";
    private static final String secondFinishedProductCode = "9999993";
    private static final String sourceProductCode = "9999991";
    private static final String byProductCode = "9999994";

    private Product firstFinishedProductForYieldModel;
    private Product secondFinishedProductForYieldModel;

    private Product sourceProduct;
    private Product byProduct;

    private CuttingYieldModel oldYieldPricingModel;
    private CuttingYieldModel oldYieldSecondPricingModel;

    @Before
    public void setup() {
        //Create Products and Cost
        firstFinishedProductForYieldModel = productBuilder()
                .code(finishedProductCode)
                .build();
        secondFinishedProductForYieldModel = productBuilder()
                .code(secondFinishedProductCode)
                .build();
        byProduct = productBuilder()
                .code(byProductCode)
                .productOutput(ProductOutput.BYPRODUCT_ONLY)
                .build();

        sourceProduct = productBuilder()
                .productOutput(ProductOutput.SOURCE)
                .code(sourceProductCode)
                .productGroup(null).build();

        Cost sourceProductCost = Cost.builder()
                .name(sourceProduct.getCode())
                .source(CostSource.SUS)
                .currentCostPerPound(new BigDecimal("1.00"))
                .marketCost(new BigDecimal("1.00"))
                .startDate(LocalDate.now().minusDays(2))
                .endDate(Cost.COST_NEVER_EXPIRES)
                .build();

        costRepo.save(sourceProductCost);

        Cost byProductCost = Cost.builder()
                .name(byProduct.getCode())
                .source(CostSource.BYPRODUCT_ONLY)
                .weightedAverageCost(new BigDecimal("5.83"))
                .currentCostPerPound(new BigDecimal("5.83"))
                .marketCost(new BigDecimal("5.83"))
                .startDate(LocalDate.now())
                .endDate(Cost.COST_NEVER_EXPIRES)
                .build();

        costRepo.save(byProductCost);

        productRepo.save(sourceProduct);
        productRepo.save(byProduct);

        final Product firstProductFromDb = productRepo.save(firstFinishedProductForYieldModel);
        final Product secondProductFromDb = productRepo.save(secondFinishedProductForYieldModel);

        //Create original ProductGroup
        ProductGroup originalProductGroup = cuttingProductGroup(firstProductFromDb);
        //Set Product Group ID so hibernate won't think Product Group is transient
        originalProductGroup.setId(9999L);
        productGroupRepo.save(originalProductGroup);

        //Create original ProductGroup
        ProductGroup originalSecondProductGroup = cuttingProductGroup(secondProductFromDb);
        //Set Product Group ID so hibernate won't think Product Group is transient
        originalSecondProductGroup.setId(9999L);
        productGroupRepo.save(originalSecondProductGroup);

        //Create YieldModel Associated with Product Groups with ProductToChange Groups As Member
        oldYieldPricingModel = cuttingYieldModelBuilder()
                .yieldByproducts(null)
                .finishedProductCode(firstProductFromDb.getCode())
                .sourceProductCode(sourceProduct.getCode())
                .labor(new BigDecimal("1.11"))
                .finishedProductCost(BigDecimal.valueOf(17.65d))
                .pricingModel(true)
                .build();

        final Set<CuttingYieldByproduct> byproducts = oldYieldPricingModel.getYieldByproducts();
        byproducts.clear();
        CuttingYieldByproduct byProductForFirstYieldModel = CuttingYieldByproduct.builder()
                .yieldModel(oldYieldPricingModel)
                .byproductCode(byProduct.getCode())
                .yieldPercentage(Money.of(1))
                .labor(Money.of(0.00))
                .cost(Money.of(5.83))
                .overhead(Money.of(0))
                .packaging(Money.of(0))
                .build();
        byproducts.add(byProductForFirstYieldModel);

        cuttingYieldModelRepo.save(oldYieldPricingModel);

        //Create YieldModel Associated with Product Groups with ProductToChange Groups As Member
        oldYieldSecondPricingModel = cuttingYieldModelBuilder()
                .yieldByproducts(null)
                .finishedProductCode(secondProductFromDb.getCode())
                .sourceProductCode(sourceProduct.getCode())
                .labor(new BigDecimal("1.11"))
                .finishedProductCost(BigDecimal.valueOf(17.65d))
                .pricingModel(true)
                .build();

        final Set<CuttingYieldByproduct> secondByProduct = oldYieldSecondPricingModel.getYieldByproducts();
        secondByProduct.clear();
        CuttingYieldByproduct byProductForSecondYieldModel = CuttingYieldByproduct.builder()
                .yieldModel(oldYieldSecondPricingModel)
                .byproductCode(byProduct.getCode())
                .yieldPercentage(Money.of(1))
                .labor(Money.of(0.00))
                .cost(Money.of(5.83))
                .overhead(Money.of(0))
                .packaging(Money.of(0))
                .build();
        secondByProduct.add(byProductForSecondYieldModel);

        cuttingYieldModelRepo.save(oldYieldPricingModel);
        cuttingYieldModelRepo.save(oldYieldSecondPricingModel);
    }

    @Test
    public void shouldRetrieveByProductCostAndLaborUsingSusCostAndNotOverrideCostFromAnotherYieldModel() {

        final CuttingYieldModel retrieveExistingYieldModel = cuttingYieldModelService
                .findCuttingYieldModelByFinishedProductCodeAndSourceProductCode(
                        oldYieldPricingModel.getFinishedProductCode(), oldYieldPricingModel.getSourceProductCode(),
                        new HashMap<>());

        final Set<CuttingYieldByproduct> byproducts = retrieveExistingYieldModel.getYieldByproducts();
        byproducts.clear();
        CuttingYieldByproduct byProductForFirstYieldModel = CuttingYieldByproduct.builder()
                .yieldModel(retrieveExistingYieldModel)
                .byproductCode(byProduct.getCode())
                .yieldPercentage(Money.of(1))
                .labor(Money.of(6.00))
                .cost(Money.of(6.83))
                .overhead(Money.of(0))
                .packaging(Money.of(0))
                .build();
        byproducts.add(byProductForFirstYieldModel);

        cuttingYieldModelService.createOrUpdateCuttingYieldModels(singletonList(retrieveExistingYieldModel), new
                HashMap<>());

        Cost byProductCost = Cost.builder()
                .name(byProduct.getCode())
                .source(CostSource.BYPRODUCT_ONLY)
                .weightedAverageCost(new BigDecimal("7.83"))
                .currentCostPerPound(new BigDecimal("7.83"))
                .marketCost(new BigDecimal("7.83"))
                .startDate(LocalDate.now())
                .endDate(COST_NEVER_EXPIRES)
                .build();

        costRepo.save(byProductCost);

        final CuttingYieldModel updatedYieldModel = cuttingYieldModelService
                .findCuttingYieldModelByFinishedProductCodeAndSourceProductCode(
                        retrieveExistingYieldModel.getFinishedProductCode(), retrieveExistingYieldModel
                                .getSourceProductCode(), new HashMap<>());

        final CuttingYieldModel secondExistingYieldModel = cuttingYieldModelService
                .findCuttingYieldModelByFinishedProductCodeAndSourceProductCode(
                        oldYieldSecondPricingModel.getFinishedProductCode(), oldYieldSecondPricingModel
                                .getSourceProductCode(), new HashMap<>());

        final List<CuttingYieldByproduct> originalCuttingYieldByProduct =
                new ArrayList<>(retrieveExistingYieldModel.getYieldByproducts());
        final List<CuttingYieldByproduct> updatedFirstCuttingYieldByProduct =
                new ArrayList<>(updatedYieldModel.getYieldByproducts());
        final List<CuttingYieldByproduct> secondCuttingYieldByProduct =
                new ArrayList<>(secondExistingYieldModel.getYieldByproducts());

        final CuttingYieldByproduct firstYieldModelByProduct = updatedFirstCuttingYieldByProduct.get(0);
        assertThat(originalCuttingYieldByProduct.get(0).getLabor())
                .isEqualTo(firstYieldModelByProduct.getLabor());
        assertThat(originalCuttingYieldByProduct.get(0).getCost())
                .isEqualTo(Money.of(firstYieldModelByProduct.getCost()));

        final CuttingYieldByproduct secondYieldModelByProduct = secondCuttingYieldByProduct.get(0);

        assertThat(updatedFirstCuttingYieldByProduct.get(0).getLabor())
                .isNotEqualTo(secondYieldModelByProduct.getLabor());
        assertThat(updatedFirstCuttingYieldByProduct.get(0).getCost())
                .isNotEqualTo(secondYieldModelByProduct.getCost());

        //check second yield model is using updated sus cost
        assertThat(secondYieldModelByProduct.getCost()).isEqualTo(byProductCost.getMarketCost());
    }
}