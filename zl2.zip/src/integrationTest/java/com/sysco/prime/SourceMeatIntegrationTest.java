package com.sysco.prime;

import com.sysco.prime.product.response.ProductResponse;
import com.sysco.prime.sourceMeat.SourceMeatOrderRequest;
import com.sysco.prime.station.response.StationResponse;
import com.sysco.prime.sus.model.SusInvoice;
import com.sysco.prime.sus.model.SusInvoiceHeader;
import com.sysco.prime.sus.model.SusInvoiceItem;
import io.restassured.response.Response;
import org.junit.Assert;
import org.junit.Ignore;
import org.junit.Test;

import java.io.IOException;

import static com.sysco.prime.unitOfMeasure.UnitOfMeasure.BOX;
import static io.restassured.RestAssured.with;
import static io.restassured.http.ContentType.JSON;
import static java.util.Collections.singletonList;

public class SourceMeatIntegrationTest extends IntegrationTestBase {
    @Test
    @Ignore("WIP")
    public void shouldReceiveSourceMeatReceiptFromSus() throws IOException {
        final String roomCode = "A";
        final String productCode = "3260878";

        openRoom(roomCode);

        final ProductResponse product = getProduct(productCode);
        final StationResponse station = getFirstStation(roomCode);

        requestMeat(SourceMeatOrderRequest.builder()
                .productCode(product.getCode())
                .productDesc(product.getDescription())
                .quantity(2)
                .roomCode(roomCode)
                .stationId(station.getId())
                .unitOfMeasure(BOX)
                .build());

        /*
2018-12-02 13:49:47.635 ERROR 26446 --- [io-59028-exec-2] c.s.prime.sourceMeat.SourceMeatService   : Unexpected
source meat receipt from SUS; no matching order found: SourceMeatReceipt(poNumber=Find the PO # returned from dummy
SUS, items=[SourceMeatReceiptItem(itemNumber=3260878, currentQty=2, catchWeightIndicator=N,
currentTotalCatchWeight=12.34)])
        */
        receiveReceipt(SusInvoice.builder()
                .header(SusInvoiceHeader.builder()
                        .poNumber("Find the PO # returned from dummy SUS")
                        .build())
                .detail(singletonList(SusInvoiceItem.builder()
                        .itemNumber(productCode)
                        .catchWeightIndicator("N") // TODO: Hard to figure out from code this is Y/N
                        .currentQty(2)
                        .currentTotalCatchWeight(12.34d)
                        .build()))
                .build());

        checkReportingForReceipt();
    }

    private StationResponse getFirstStation(final String roomCode) throws IOException {
        final Response response = with().queryParam("room-code", roomCode)
                .when()
                .get(getHostName() + "/api/stations")
                .then()
                .statusCode(200)
                .contentType(JSON)
                .extract().response();

        return readBodyAsListOf(response, StationResponse.class).get(0); // There must be at least 1
    }

    private void requestMeat(final SourceMeatOrderRequest order) throws IOException {
        with().body(asJson(singletonList(order)))
                .contentType(JSON)
                .when()
                .post(getHostName() + "/api/source-meat")
                .then()
                .statusCode(201);
    }

    private void receiveReceipt(final SusInvoice invoice) throws IOException {
        with().body(asJson(invoice))
                .contentType(JSON)
                .when()
                .post(getHostName() + "/sus/invoice")
                .then()
                .statusCode(201);
    }

    private void checkReportingForReceipt() {
        Assert.fail("TODO");
    }
}
