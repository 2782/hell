
package com.sysco.prime;

import com.sysco.dummysus.DummySusController;
import com.sysco.prime.cost.Cost;
import com.sysco.prime.cost.CostRepository;
import com.sysco.prime.cost.CostService;
import com.sysco.prime.cost.CostSource;
import com.sysco.prime.cost.Money;
import com.sysco.prime.product.ItemMasterUpdateService;
import com.sysco.prime.product.Product;
import com.sysco.prime.product.ProductCategory;
import com.sysco.prime.product.ProductService;
import com.sysco.prime.profile.Profile;
import com.sysco.prime.profile.ProfileService;
import com.sysco.prime.reporting.reports.finishedGoodMarketCost.FinishedCostSection;
import com.sysco.prime.reporting.reports.finishedGoodMarketCost.FinishedGoodMarketCostRenderer;
import com.sysco.prime.reporting.reports.finishedGoodMarketCost.FinishedGoodMarketCostRow;
import com.sysco.prime.schedule.yieldModel.PriceApplicationEventProcessorFactory;
import com.sysco.prime.schedule.yieldModel.YieldModelRunner;
import com.sysco.prime.schedule.yieldModel.topology.CutTopologyService;
import com.sysco.prime.sus.client.SusClient;
import com.sysco.prime.sus.model.SusProductCostNotificationData;
import com.sysco.prime.sus.model.product.SusProductData;
import com.sysco.prime.yieldModel.CuttingYieldByproduct;
import com.sysco.prime.yieldModel.CuttingYieldModel;
import com.sysco.prime.yieldModel.CuttingYieldModelRepository;
import com.sysco.prime.yieldModel.CuttingYieldModelService;
import com.sysco.prime.yieldModel.CuttingYieldModelServiceCopy;
import com.sysco.prime.yieldModel.GrindingYieldModelServiceCopy;
import com.sysco.prime.yieldModel.YieldModelService;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;

import java.math.BigDecimal;
import java.time.Clock;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import static com.google.common.collect.Sets.newHashSet;
import static com.sysco.prime.DummyObjectFactory.profileBuilder;
import static com.sysco.prime.DummyObjectFactory.susProductDataBuilder;
import static com.sysco.prime.utils.TimeUtilsTest.mockClockToNow;
import static com.sysco.prime.yieldModel.YieldModelFactory.sourceCost;
import static org.assertj.core.api.Java6Assertions.assertThat;
import static org.mockito.Mockito.when;

public class FutureEffectiveCostUpdateTest extends IntegrationTestBase {

    private static final String SOURCE_PRODUCT_CODE = "2857102";
    private static final String FINISHED_PROUDCT_CODE = "2111148";
    private static final String DEPENDED_ON_FINISHED_PRODUCT_CODE = "4102218";

    @Autowired
    FinishedGoodMarketCostRenderer finishedGoodMarketCostRenderer;

    @Autowired
    CostRepository costRepository;

    @Mock
    ItemMasterUpdateService itemMasterUpdateService;

    @Mock
    GrindingYieldModelServiceCopy grindingYieldModelService;

    @Autowired
    private ProfileService profileService;

    @Autowired
    private CutTopologyService cutTopologyService;

    @Autowired
    private PriceApplicationEventProcessorFactory factory;

    @Autowired
    DummySusController dummySusController;

    @Autowired
    YieldModelRunner yieldModelRunner;

    @Autowired
    ProductService productService;

    @Autowired
    CuttingYieldModelServiceCopy cuttingYieldModelServiceCopy;

    @Autowired
    CuttingYieldModelRepository cuttingYieldModelRepository;

    @Autowired
    CuttingYieldModelService cuttingYieldModelService;

    @Autowired
    YieldModelService yieldModelService;

    @Mock
    SusClient susClient;

    @Mock
    private Clock when;

    @Autowired
    CostService costService;

    private LocalDate date;
    Profile profile;

    @Before
    public void setUp() {
        mockClockToNow(when);
        date = LocalDate.now(when);

        profile = profileBuilder()
                .plantNumber("332")
                .name("Buckhead Dallas")
                .address("4216 Mint Way")
                .city("Dallas")
                .zipCode("75237")
                .establishmentNumber("2213D")
                .vendorShipFrom(194)
                .sequenceNumber(1)
                .state("TX")
                .build();


        this.costService = new CostService(
          when,
          costRepository,
          susClient,
          profileService,
          null,
          null,
          productService,
          itemMasterUpdateService,
          null
        );

        this.finishedGoodMarketCostRenderer = new FinishedGoodMarketCostRenderer(
            productService,
            costService,
            profileService,
            grindingYieldModelService,
            cuttingYieldModelServiceCopy,
            yieldModelService,
            when);


        this.yieldModelRunner = new YieldModelRunner(
                cutTopologyService,
                null,
                factory,
                profileService,
                susClient,
                itemMasterUpdateService,
                costService,
                when
        );

    }

    @Test
    public void shouldUpdateCostOnYieldModelWhenSourceCostUpdate() {

        //Setup

        Product finishedProduct = productService.findByCode(FINISHED_PROUDCT_CODE);

        LocalDate endDate = date.plusDays(28);
        LocalDate startDate = date.plusDays(14);
        Cost sourceCostInTheFuture = sourceCost(SOURCE_PRODUCT_CODE).toBuilder()
                .startDate(startDate)
                .endDate(endDate)
                .build();

        HashMap<String, SusProductData> productsMap = new HashMap<>();
        productsMap.put(FINISHED_PROUDCT_CODE, susProductDataBuilder().id(FINISHED_PROUDCT_CODE).build());
        productsMap.put(SOURCE_PRODUCT_CODE, susProductDataBuilder().id(SOURCE_PRODUCT_CODE).build());

        when(susClient.getProductsFromSus(
                newHashSet(FINISHED_PROUDCT_CODE),
                profile)).thenReturn(productsMap);

        //Action
        final SusProductCostNotificationData sourceCostUpdate =
                buildSusProductCostNotification(sourceCostInTheFuture);

        dummySusController.createSourceProductCosts(sourceCostUpdate);


        final Cost expectedYMcost = Cost.builder()
                .labor(Money.of(2.23))
                .currentCostPerPound(Money.ofCost(16.540d))
                .marketCost(Money.ofCost(165.4))
                .yieldModelId(999990101005003L)
                .name(FINISHED_PROUDCT_CODE)
                .startDate(startDate)
                .endDate(endDate)
                .source(CostSource.PRICING_MODEL)
                .build();

        //Runs on a chron job during application run, so manually run for test
        yieldModelRunner.publishPrices();


        // - Sending FED cost to SUS:
        List<Product> productsInGroup =
                productService.findByProductGroupName(finishedProduct.getProductGroup().getName());

        productsInGroup.forEach( product -> {
            Cost cost = expectedYMcost.toBuilder()
                    .name(product.getCode())
                    .marketCost(Money.ofCost(expectedYMcost.getCurrentCostPerPound()
                            .multiply(Money.of(product.getWeightPerBox()))))
                    .build();

            // TODO: will be modified by 1452
//            verify(susClient, times(1)).sendProductionProductCostToSus(
//                    cost.getName(),cost, profile);
        });


        //UI is using correct cost:
        CuttingYieldModel pricingModel = cuttingYieldModelRepository
                .findByFinishedProductCodeAndSourceProductCode(DEPENDED_ON_FINISHED_PRODUCT_CODE, SOURCE_PRODUCT_CODE)
                .get();
        Set<CuttingYieldByproduct> byproducts = pricingModel.getYieldByproducts()
                .stream()
                .map(byproduct -> {
                    Cost byproductCost = costService.findCost(productService.findByCode(byproduct.getByproductCode()));
                    byproduct.setCost(byproductCost.getCurrentCostPerPound());
                    return byproduct;
                })
                .collect(Collectors.toSet());

        pricingModel.setYieldByproducts(byproducts);
        Cost pricingModelCostObject = costService.findCost(productService.findByCode(DEPENDED_ON_FINISHED_PRODUCT_CODE));
        pricingModel.setLabor(pricingModelCostObject.getLabor());

        CuttingYieldModel yieldModel = cuttingYieldModelService.calculateCuttingYieldModelCost(pricingModel);
        String currentYieldModelCostPerPound = "16.353";

        BigDecimal unitCostPerPoundForUI = yieldModel.getFinishedProductCost();
        assertThat(unitCostPerPoundForUI).isEqualTo(currentYieldModelCostPerPound);

        // Reports are ok:
        FinishedCostSection expectedFinishedProductSection =
                buildFgmcReportsFinishedProductCostSection(unitCostPerPoundForUI, finishedProduct);

        assertThat(getFinishedProductCostSection()).isEqualTo(expectedFinishedProductSection);
    }

    private FinishedCostSection buildFgmcReportsFinishedProductCostSection(
            final BigDecimal currentCostPerPound,
            final Product finishedProduct) {

        BigDecimal marketCost = ProductCategory.FIXED.equals(finishedProduct.getCategory())
                ? Money.ofCost(currentCostPerPound
                        .multiply(new BigDecimal(finishedProduct.getWeightPerBox()))) :
                Money.ofCost(currentCostPerPound);

        BigDecimal previousCost = Money.ofCost(40.215);
        String variance = marketCost.subtract(previousCost).toPlainString();

        return FinishedCostSection.builder()
                    .productCode(finishedProduct.getCode())
                    .description(finishedProduct.getDescription())
                    .marketCost(marketCost.toPlainString())
                    .variance(variance)
                    .build();
    }

    private FinishedCostSection getFinishedProductCostSection() {
        List<FinishedGoodMarketCostRow> finishedGoodMarketCostReportRows = finishedGoodMarketCostRenderer.buildRows();
        List<FinishedGoodMarketCostRow> reportRows = finishedGoodMarketCostReportRows
                .stream()
                .filter(row -> null != row && filterOnProductCode(row, FINISHED_PROUDCT_CODE))
                .collect(Collectors.toList());

        return reportRows.get(0).getFinishedProductSection();
    }

    private boolean filterOnProductCode(final FinishedGoodMarketCostRow row, String productCode) {
        return productCode.equals(row.getFinishedProductSection().getProductCode());
    }

    private SusProductCostNotificationData buildSusProductCostNotification(final Cost sourceCostInTheFuture) {
        return SusProductCostNotificationData.builder()
                    .sourceItemNumber(sourceCostInTheFuture.getName())
                    .marketCost(sourceCostInTheFuture.getMarketCost().doubleValue())
                    .weightedAverageCost(0)
                    .opCo("332")
                    .startDate(sourceCostInTheFuture.getStartDate())
                    .endDate(sourceCostInTheFuture.getEndDate())
                    .build();
    }
}
