
package com.sysco.dummysus;

import com.sysco.prime.customer.Customer;
import com.sysco.prime.customer.CustomerRepository;
import com.sysco.prime.profile.ProfileService;
import com.sysco.prime.sus.model.SusCreatePurchaseOrderData;
import com.sysco.prime.sus.model.SusCustomerData;
import com.sysco.prime.sus.model.SusInvoice;
import com.sysco.prime.sus.model.SusProductCostNotificationData;
import com.sysco.prime.sus.model.SusProductCostUpdateData;
import com.sysco.prime.sus.model.SusPurchaseOrderReceipt;
import com.sysco.prime.sus.model.SusUpdatePurchaseOrderData;
import com.sysco.prime.sus.model.product.SusProductData;
import com.sysco.prime.sus.model.product.itemMaster.SusUpdateProductInfoData;
import com.sysco.prime.sus.model.product.salesOrder.SusSalesOrderStatus;
import com.sysco.prime.sus.model.product.salesOrder.SusSalesOrdersData;
import com.sysco.prime.sus.model.stock.SusAsohData;
import com.sysco.prime.sus.model.stock.SusSalesOrderAllocationData;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import static java.lang.String.format;
import static org.springframework.http.HttpStatus.CREATED;
import static org.springframework.http.HttpStatus.OK;
import static org.springframework.http.ResponseEntity.notFound;
import static org.springframework.http.ResponseEntity.ok;

@RestController
@RequestMapping("/sus")
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class DummySusController {
    private static final String TODO_FAKE_ROOM_CODE = "0";

    private final DummySusService service;
    private final ProfileService profileService;
    private final CustomerRepository customerRepository;


    @PostMapping("/product")
    @ResponseStatus(CREATED)
    @ApiOperation(value = "create product",
            notes = "mock sus create product endpoint, product will transfer to prime ")
    public void createProduct(@RequestBody final SusProductData payload) {
        service.createProduct(payload);
    }

    @PostMapping("/production-product-cost")
    @ApiOperation(value = "process product code data",
            notes = "Used when we send cost from a yield model to SUS.  Does not save cost")
    @ResponseStatus(CREATED)
    public void createProductionProductCost(@RequestBody final List<SusProductCostUpdateData> payload) {
        service.createProductionProductCost(payload);
    }

    @PostMapping("/source-product-cost")
    @ApiOperation(value = "process product code data coming from SUS",
            notes = "Receive product cost data from SUS")
    @ResponseStatus(CREATED)
    public void createSourceProductCosts(@RequestBody final SusProductCostNotificationData payload) {
        service.createSourceProductCosts(payload);
    }

    @PostMapping("/sales-order")
    @ApiOperation(value = "create sales order in SUS",
            notes = "create sales order in SUS (prime will call it when get meat)")
    @ResponseStatus(CREATED)
    public void createSalesOrder(@RequestBody final SusSalesOrdersData payload) {
        service.createSalesOrderInDummySus(payload);
    }

    @PostMapping("/sales-order/status")
    @ApiOperation(value = "Sales Order from SUS to Prime",
            notes = "create sales order in SUS which will transfer to Prime (prime will call it when get meat)")
    @ResponseStatus(CREATED)
    public void createSalesOrder(@RequestBody final SusSalesOrderStatus payload) {
        service.receiveSalesOrderFromSus(payload);
    }

    @PostMapping("/sales-orders/{salesOrderNumber}/opcos/{opcoId}/allocations")
    @ApiOperation(value = "consume stock in prime",
            notes = "notify SUS how many stock we used")
    @ResponseStatus(CREATED)
    public void updateStockAllocation(
            @PathVariable("salesOrderNumber") final String salesOrderNumber,
            @PathVariable("opcoId") final String opcoId,
            @RequestBody final SusSalesOrderAllocationData payload) {
        service.updateAllocatedStocks(salesOrderNumber, opcoId, payload);
    }

    @PostMapping("/customer")
    @ResponseStatus(CREATED)
    public void createCustomer(@RequestBody final SusCustomerData payload) {
        service.createCustomer(payload);
    }

    @PostMapping("/invoice")
    @ResponseStatus(CREATED)
    public void receiveInvoice(@RequestBody final SusInvoice payload) {
        service.receiveSourceMeatInvoice(payload);
    }

    @PostMapping("/asoh")
    @ResponseStatus(CREATED)
    public void createOrUpdateAsoh(@RequestBody final SusAsohData payload) {
        service.createOrUpdateAsoh(payload);
    }

    @PostMapping("/asoh/get")
    @ResponseStatus(OK)
    public SusAsohData getAsoh(@RequestBody final SusAsohData payload) {
        return service.getAsoh(payload);
    }

    @PostMapping("/purchase-order")
    @ResponseStatus(OK)
    public String createPurchaseOrder(@RequestBody final SusCreatePurchaseOrderData payload) {
        return service.createPurchaseOrder(payload, TODO_FAKE_ROOM_CODE);
    }

    @PutMapping("/purchase-order/{po-number}")
    @ResponseStatus(OK)
    public void updatePurchaseOrder(
            @PathVariable("po-number") final String poNumber,
            @RequestBody final SusUpdatePurchaseOrderData payload) {
        service.updatePurchaseOrder(poNumber, payload);
    }

    @PostMapping("/purchase-orders/opCo/{op-co-number}/purchase-order/{po-number}/receipts")
    @ResponseStatus(OK)
    public long createPurchaseOrderReceipt(
            @PathVariable("op-co-number") final String opCoNumber,
            @PathVariable("po-number") final String poNumber,
            @RequestBody final SusPurchaseOrderReceipt payload) {
        return service.createPurchaseOrderReceipt(opCoNumber, poNumber, payload);
    }

    @PostMapping("purchase-orders/{requestNumber}/confirm")
    @ApiOperation(value = "request number from Dummy SUS in the PO",
            notes = "Confirms the create or update of a single PO")
    @ResponseStatus(OK)
    public void confirmPurchaseOrderCreate(@PathVariable("requestNumber") final String requestNumber) {
        service.confirmPurchaseOrder(requestNumber);
    }

    @PostMapping("purchase-orders/confirm")
    @ApiOperation(value = "", notes = "Confirms the create or update of a all POs")
    @ResponseStatus(OK)
    public void confirmPurchaseOrders() {
        service.confirmPurchaseOrders();
    }

    @PatchMapping("/item-master/v1/items/{productCode}/opcos/{opCo}")
    @ResponseStatus(OK)
    public void updateItemMaster(
            @PathVariable("opCo") final String opCoNumber,
            @PathVariable("productCode") final String productCode,
            @RequestBody final SusUpdateProductInfoData susUpdateProductInfoData) {
        service.updateProductStatusInfo(opCoNumber, productCode, susUpdateProductInfoData);
    }

    @GetMapping("sm/product-info/opcos/{opCo}/products/{productCode}")
    public ResponseEntity<SusProductData> getProduct(
            @PathVariable("opCo") final String opCoNumber,
            @PathVariable("productCode") final String productCode) throws IOException {
        final SusProductData found = service.getSusProduct(opCoNumber, productCode);

        return null == found ? notFound().build() : ok(found);
    }

    @GetMapping("opcos/{opcoId}/customers/{customerId}")
    public ResponseEntity<SusCustomerData> getCustomer(@PathVariable("opcoId") final String opcoId,
                                                       @PathVariable("customerId") final String customerId) {
        final String plantNumber = profileService.get().getPlantNumber();
        if (!Objects.equals(plantNumber, opcoId)) {
            throw new IllegalArgumentException(format("Your OpCo, %s, is not our OpCo, %s", plantNumber, opcoId));
        }

        final Customer customer = customerRepository.findByCustomerCode(customerId);

        if (null == customer) {
            return notFound().build();
        } else {
            final Map<String, String> routingGroups = new HashMap<>();
            routingGroups.put("friday", "5");
            routingGroups.put("monday", "1");
            routingGroups.put("saturday", "6");
            routingGroups.put("sunday", "7");
            routingGroups.put("thursday", "4");
            routingGroups.put("tuesday", "2");
            routingGroups.put("wednesday", "3");

            return ok(SusCustomerData.builder()
                    .addressLine1(customer.getAddress().getLineOne())
                    .addressLine2(customer.getAddress().getLineTwo())
                    .name(customer.getName())
                    .city(customer.getAddress().getCity())
                    .country(customer.getAddress().getCountry())
                    .customerId(customerId)
                    .customerType(customer.getType().toString())
                    .zipCode(customer.getAddress().getPostalCode())
                    .routingGroup(routingGroups)
                    .build());
        }
    }
}
