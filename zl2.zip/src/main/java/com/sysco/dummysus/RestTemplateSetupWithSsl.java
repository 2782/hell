package com.sysco.dummysus;

import org.apache.http.client.HttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.ssl.SSLContextBuilder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.util.ResourceUtils;
import org.springframework.web.client.RestTemplate;

import javax.net.ssl.SSLContext;

@Profile("dummyauth")
@Configuration
public class RestTemplateSetupWithSsl implements RestTemplateSetup {

    @Value("${server.ssl.trust-store-password}")
    private String trustStorePassword;

    @Value("${server.ssl.trust-store}")
    private String trustStore;

    @Value("${server.ssl.key-store-password}")
    private String keyStorePassword;

    @Value("${server.ssl.key-store}")
    private String keyStore;

    public RestTemplate setup() throws Exception {
        final SSLContext sslContext = new SSLContextBuilder()
                .loadKeyMaterial(
                        ResourceUtils.getFile(keyStore),
                        keyStorePassword.toCharArray(),
                        keyStorePassword.toCharArray())
                .loadTrustMaterial(
                        ResourceUtils.getFile(trustStore),
                        trustStorePassword.toCharArray()
                ).build();

        final HttpClient httpClient = HttpClients.custom().setSSLContext(sslContext).build();
        final ClientHttpRequestFactory factory = new HttpComponentsClientHttpRequestFactory(httpClient);

        return new RestTemplateBuilder()
                .requestFactory(() -> factory)
                .build();
    }
}
