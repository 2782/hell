package com.sysco.dummysus;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sysco.prime.profile.ProfileService;
import com.sysco.prime.sus.eventProcessors.CostProcessor;
import com.sysco.prime.sus.eventProcessors.CustomerOrderProcessor;
import com.sysco.prime.sus.eventProcessors.CustomerProcessor;
import com.sysco.prime.sus.eventProcessors.InvoiceProcessor;
import com.sysco.prime.sus.eventProcessors.ProductProcessor;
import com.sysco.prime.sus.eventProcessors.PurchaseOrderProcessor;
import com.sysco.prime.sus.model.SusCreatePurchaseOrderData;
import com.sysco.prime.sus.model.SusCustomerData;
import com.sysco.prime.sus.model.SusInvoice;
import com.sysco.prime.sus.model.SusProductCostNotificationData;
import com.sysco.prime.sus.model.SusProductCostUpdateData;
import com.sysco.prime.sus.model.SusPurchaseLineItemData;
import com.sysco.prime.sus.model.SusPurchaseOrderReceipt;
import com.sysco.prime.sus.model.SusPurchaseOrderReceiptLineItem;
import com.sysco.prime.sus.model.SusPurchaseOrderReceiptLineItemCase;
import com.sysco.prime.sus.model.SusPurchaseOrderResponse;
import com.sysco.prime.sus.model.SusUpdatePurchaseOrderData;
import com.sysco.prime.sus.model.product.SusProductData;
import com.sysco.prime.sus.model.product.itemMaster.SusUpdateProductInfoData;
import com.sysco.prime.sus.model.product.salesOrder.SusSalesOrderStatus;
import com.sysco.prime.sus.model.product.salesOrder.SusSalesOrdersData;
import com.sysco.prime.sus.model.stock.SusAllocationLineItem;
import com.sysco.prime.sus.model.stock.SusAsohData;
import com.sysco.prime.sus.model.stock.SusAsohProductData;
import com.sysco.prime.sus.model.stock.SusSalesOrderAllocationData;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.Random;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

import static com.sysco.dummysus.SusModel.SusType.ASOH;
import static com.sysco.dummysus.SusModel.SusType.CUSTOMER;
import static com.sysco.dummysus.SusModel.SusType.PO_RECEIPT;
import static com.sysco.dummysus.SusModel.SusType.PRODUCT;
import static com.sysco.dummysus.SusModel.SusType.PRODUCT_COST;
import static com.sysco.dummysus.SusModel.SusType.PRODUCT_SYNC;
import static com.sysco.dummysus.SusModel.SusType.PURCHASE_ORDER;
import static com.sysco.dummysus.SusModel.SusType.SALES_ORDER;
import static com.sysco.dummysus.SusModel.SusType.SALES_ORDER_STATUS;
import static com.sysco.dummysus.SusModel.SusType.STOCK_ALLOCATION;
import static com.sysco.prime.sus.model.SusPurchaseOrderResponse.fromSusPurchaseOrderData;
import static java.lang.Integer.valueOf;
import static java.lang.String.format;
import static java.util.Arrays.asList;
import static java.util.Objects.isNull;
import static java.util.function.Function.identity;
import static java.util.stream.Collectors.toList;
import static java.util.stream.Collectors.toMap;

@RequiredArgsConstructor(onConstructor = @__(@Autowired))
@Service
@Slf4j
public class DummySusService {
    private static final AtomicInteger poNumbers = new AtomicInteger();
    private static final AtomicInteger requestNumber = new AtomicInteger();
    private static final AtomicLong nextReponseNumber = new AtomicLong();
    private static final String REAL_OP_CO = "332"; // TODO: Our seed data sets up a dummy profile
    private static final Map<String, String> susOnlyProducts = new HashMap<>(6);

    static {
        susOnlyProducts.put("2536993", "{\n"
                + "  \"id\": \"2536993\",\n"
                + "  \"name\": \"VEAL BONE\",\n"
                + "  \"description\": \"VEAL BONE\",\n"
                + "  \"lineDescription\": null,\n"
                + "  \"pack\": \"1\",\n"
                + "  \"size\": \"50 LB\",\n"
                + "  \"brandId\": \"PACKER\",\n"
                + "  \"brand\": \"PACKER\",\n"
                + "  \"categoryId\": 3,\n"
                + "  \"catMajId\": 6,\n"
                + "  \"catIntId\": 5,\n"
                + "  \"catMinId\": 27,\n"
                + "  \"manufacturerCode\": \"\",\n"
                + "  \"imageLink\": [],\n"
                + "  \"categoryName\": \"MEATS\",\n"
                + "  \"catMajName\": \"VEAL FROZEN\",\n"
                + "  \"catIntName\": \"FORMULA/MLK FED\",\n"
                + "  \"catMinName\": \"BONES\",\n"
                + "  \"taxonomy\": {\n"
                + "    \"hierarchyId\": 1489,\n"
                + "    \"businessCenter\": \"BEEF\",\n"
                + "    \"itemGroup\": \"LAMB, VEAL & GAME\",\n"
                + "    \"attributeGroup\": \"PORTION CUTS\",\n"
                + "    \"attributes\": null\n"
                + "  },\n"
                + "  \"opcoId\": \"332\",\n"
                + "  \"statusCode\": \"A\",\n"
                + "  \"stockIndicator\": \"N\",\n"
                + "  \"asoh\": 100,\n"
                + "  \"proprietaryCode\": \" \",\n"
                + "  \"internalUpc\": null,\n"
                + "  \"externalUpc\": 70000000000009,\n"
                + "  \"averageWeight\": 50,\n"
                + "  \"storageCode\": \"F\",\n"
                + "  \"hseBrandFlag\": \"N\",\n"
                + "  \"phaseOtFlag\": \"N\",\n"
                + "  \"catchWeightIndicator\": \"N\",\n"
                + "  \"split\": \"N\",\n"
                + "  \"minimumSplit\": 0,\n"
                + "  \"shipSplitOnly\": \"N\",\n"
                + "  \"buyMultiple\": 0,\n"
                + "  \"unitPerCase\": 1,\n"
                + "  \"kosher\": false,\n"
                + "  \"vegan\": false,\n"
                + "  \"halal\": false,\n"
                + "  \"vegetarian\": false,\n"
                + "  \"organic\": false,\n"
                + "  \"greenCertified\": false,\n"
                + "  \"coreIndicator\": \" \",\n"
                + "  \"relatedProductId\": null,\n"
                + "  \"lastOrderedDate\": null,\n"
                + "  \"controlCode\": \"CS\",\n"
                + "  \"leadTimeForecast\": 1,\n"
                + "  \"isDropShip\": false,\n"
                + "  \"grdCode\": \" \",\n"
                + "  \"isSelectedNonstock\": false,\n"
                + "  \"quantity\": null,\n"
                + "  \"brokerId\": \"\",\n"
                + "  \"brokerName\": null,\n"
                + "  \"sourceVendor\": \"19418\",\n"
                + "  \"sourceVendorType\": null,\n"
                + "  \"trueVendor\": \"19418\",\n"
                + "  \"trueVendorShipPtNumber\": \"19418\",\n"
                + "  \"productSpecialist\": \"013\",\n"
                + "  \"productSpecialistName\": \"KURT HEDTKE\",\n"
                + "  \"isSlowMoving\": false,\n"
                + "  \"demandStatusFlag\": 0,\n"
                + "  \"last30quantity\": 0,\n"
                + "  \"rdcNumber\": \"\",\n"
                + "  \"productionItemFlag\": \"N\",\n"
                + "  \"trueVendorName\": \"J&B GROUP\",\n"
                + "  \"governmentGrade\": null,\n"
                + "  \"subPrimalCode\": null,\n"
                + "  \"subPrimalDescription\": null,\n"
                + "  \"active\": true,\n"
                + "  \"category\": \"03006005027\",\n"
                + "  \"isProprietary\": false,\n"
                + "  \"isNonstock\": true,\n"
                + "  \"isNonstockOrderable\": false,\n"
                + "  \"isLeavingSoon\": false\n"
                + "}");
        susOnlyProducts.put("7197171", "{\n"
                + "  \"id\": \"7197171\",\n"
                + "  \"name\": \"BEEF PRIME RIB CKD BNL RARE 10\",\n"
                + "  \"description\": \"Beef Prime Rib Cooked Boneless Rare 10\",\n"
                + "  \"lineDescription\": \"BEEF PRIME RIB COOKED CHOICE BONELESS, COOKED RARE USDA CHOICE, "
                + "RARE COOK ,"
                + " 1\\\" LIP, 10% ADDED, HEAT AND SERVE. VERSATILE ENOUGH FOR CENTER OF PLATE, SANDWICHES AND "
                + "APPETIZERS. FREE OF BIG 8 ALLERGENS. 50 DAY SHELF LIFE. - - PRODUCT DIMENSIONS: -- PRODUCT"
                + " BENEFITS:"
                + " OUR PRIME RIB IS FULLY COOKED AND JUST NEEDS TO BE WARMED. - - COMPARABLE PRODUCTS: -- "
                + "PACKING INFORMATION: CRYOVAC - - PREP & COOKING INSTRUCTIONS: PRE-HEAT OVEN TO 275 DEGREES. OPEN "
                + "PROTECTIVE COOKING BAG AND PLACE THE PRIME RIB AND ITS JUICES IN A LARGE PAN WITH AT LEAST 2 INCH "
                + "SIDES. COVER THE PAN WITH ALUMINUM FOIL. WARM THE PRIME RIB AT 2-3 HOURS OR UNTIL THE CENTER "
                + "REACHES AN INTERNAL TEMPERATURE OF 100-105 DEGREES F MAXIMUM. INCREASE OVEN TEMPERATURE TO 425 "
                + "DEGREES F. REMOVE FOIL "
                + "FROM THE PRIME RIB AND BASTE WITH ITS JUICES. RETURN PRIME RIB TO THE OVEN AND HEAT FOR AN"
                + " ADDITION 3-5 MINUTES MAXIMUM. -- DIRECTIONS FOR USE: N/A - - ENVIRONMENTAL INFORMATION: N/A -- "
                + "FORMULATION "
                + "DATA: MADE WITH CHOICE BEEF - - HANDLING INSTRUCTIONS: DO NOT OVERCOOK. -- SERVING "
                + "SUGGESTIONS: "
                + "CAREFULLY HEAT IN AN OVEN, DO NOT OVERCOOK. -- STORAGE AND USAGE: STORE IN THE BACK OF THE "
                + "REFRIGERATOR BETWEEN 34 AND 38 DEGREES; REFRIGERATE AFTER OPENING. - - SUGGESTED USES: "
                + "CENTER OF "
                + "PLATE APPLICATIONS, SANDWICHES OR APPETIZERS. -- : 976 - - ORGANIC: NO -- KOSHER: NO "
                + "-HALAL: NO -- "
                + "ZERO TRANS FAT: NO -- ALLERGENS (E.G. NUTS/ WHEAT/ SOY/ MILK/ EGGS): NO -- GREEN: (BLANK) "
                + "-- CHILD "
                + "NUTRITION: (BLANK) -- VEGAN: NO\",\n"
                + "  \"pack\": \"2\",\n"
                + "  \"size\": \"14-17#\",\n"
                + "  \"brandId\": \"BBRLIMP\",\n"
                + "  \"brand\": \"BLOCK & BARREL IMPERIAL\",\n"
                + "  \"categoryId\": 3,\n"
                + "  \"catMajId\": 1,\n"
                + "  \"catIntId\": 9,\n"
                + "  \"catMinId\": 3,\n"
                + "  \"manufacturerCode\": \"20393\",\n"
                + "  \"imageLink\": [],\n"
                + "  \"categoryName\": \"MEATS\",\n"
                + "  \"catMajName\": \"BEEF FRESH\",\n"
                + "  \"catIntName\": \"CKD PRIME RIB\",\n"
                + "  \"catMinName\": \"CHOICE\",\n"
                + "  \"taxonomy\": {\n"
                + "    \"hierarchyId\": 1042,\n"
                + "    \"businessCenter\": \"Beef\",\n"
                + "    \"itemGroup\": \"Deli Whole\",\n"
                + "    \"attributeGroup\": \"Prime Rib\",\n"
                + "    \"attributes\": [\n"
                + "      {\n"
                + "        \"priority\": 1,\n"
                + "        \"name\": \"Raw Materials\",\n"
                + "        \"value\": \"Ribeye\"\n"
                + "      },\n"
                + "      {\n"
                + "        \"priority\": 2,\n"
                + "        \"name\": \"Grade\",\n"
                + "        \"value\": \"Choice\"\n"
                + "      },\n"
                + "      {\n"
                + "        \"priority\": 3,\n"
                + "        \"name\": \"Doneness\",\n"
                + "        \"value\": \"Rare\"\n"
                + "      },\n"
                + "      {\n"
                + "        \"priority\": 4,\n"
                + "        \"name\": \"Cattle Type\",\n"
                + "        \"value\": \"Steer\"\n"
                + "      },\n"
                + "      {\n"
                + "        \"priority\": 5,\n"
                + "        \"name\": \"Shape\",\n"
                + "        \"value\": \"Whole\"\n"
                + "      },\n"
                + "      {\n"
                + "        \"priority\": 6,\n"
                + "        \"name\": \"Slice Size (Ounces)\",\n"
                + "        \"value\": \"Not Applicable\"\n"
                + "      },\n"
                + "      {\n"
                + "        \"priority\": 7,\n"
                + "        \"name\": \"Salt/Water Retention %\",\n"
                + "        \"value\": \"0.1\"\n"
                + "      },\n"
                + "      {\n"
                + "        \"priority\": 8,\n"
                + "        \"name\": \"Sodium Level Per 2 Oz Serving\",\n"
                + "        \"value\": \"<500\"\n"
                + "      },\n"
                + "      {\n"
                + "        \"priority\": 9,\n"
                + "        \"name\": \"Soy/Food Starch/Carogene Present?\",\n"
                + "        \"value\": \"Not Present\"\n"
                + "      },\n"
                + "      {\n"
                + "        \"priority\": 10,\n"
                + "        \"name\": \"Shelf Life\",\n"
                + "        \"value\": \"50\"\n"
                + "      },\n"
                + "      {\n"
                + "        \"priority\": 11,\n"
                + "        \"name\": \"Cook In Bag\",\n"
                + "        \"value\": null\n"
                + "      }\n"
                + "    ]\n"
                + "  },\n"
                + "  \"opcoId\": \"332\",\n"
                + "  \"statusCode\": \"A\",\n"
                + "  \"stockIndicator\": \"S\",\n"
                + "  \"asoh\": 10,\n"
                + "  \"proprietaryCode\": \" \",\n"
                + "  \"internalUpc\": null,\n"
                + "  \"externalUpc\": 90074865446849,\n"
                + "  \"averageWeight\": 30.469,\n"
                + "  \"storageCode\": \"C\",\n"
                + "  \"hseBrandFlag\": \"Y\",\n"
                + "  \"phaseOtFlag\": \"N\",\n"
                + "  \"catchWeightIndicator\": \"Y\",\n"
                + "  \"split\": \"N\",\n"
                + "  \"minimumSplit\": 0,\n"
                + "  \"shipSplitOnly\": \"N\",\n"
                + "  \"buyMultiple\": 0,\n"
                + "  \"unitPerCase\": 2,\n"
                + "  \"kosher\": false,\n"
                + "  \"vegan\": false,\n"
                + "  \"halal\": false,\n"
                + "  \"vegetarian\": false,\n"
                + "  \"organic\": false,\n"
                + "  \"greenCertified\": false,\n"
                + "  \"coreIndicator\": \"A\",\n"
                + "  \"relatedProductId\": null,\n"
                + "  \"lastOrderedDate\": null,\n"
                + "  \"controlCode\": \"CS\",\n"
                + "  \"leadTimeForecast\": 14,\n"
                + "  \"isDropShip\": false,\n"
                + "  \"grdCode\": \"I\",\n"
                + "  \"isSelectedNonstock\": false,\n"
                + "  \"quantity\": null,\n"
                + "  \"brokerId\": \"43009\",\n"
                + "  \"brokerName\": \"AFFINITY GROUP FOOD MARKETING\",\n"
                + "  \"sourceVendor\": \"966\",\n"
                + "  \"sourceVendorType\": null,\n"
                + "  \"trueVendor\": \"966\",\n"
                + "  \"trueVendorShipPtNumber\": \"966\",\n"
                + "  \"productSpecialist\": \"013\",\n"
                + "  \"productSpecialistName\": \"KURT HEDTKE\",\n"
                + "  \"isSlowMoving\": false,\n"
                + "  \"demandStatusFlag\": 0,\n"
                + "  \"last30quantity\": 0,\n"
                + "  \"rdcNumber\": \"\",\n"
                + "  \"productionItemFlag\": \"\",\n"
                + "  \"trueVendorName\": \"DANS PRIZE\",\n"
                + "  \"governmentGrade\": null,\n"
                + "  \"subPrimalCode\": null,\n"
                + "  \"subPrimalDescription\": null,\n"
                + "  \"active\": true,\n"
                + "  \"category\": \"03001009003\",\n"
                + "  \"isNonstockOrderable\": false,\n"
                + "  \"isProprietary\": false,\n"
                + "  \"isNonstock\": false,\n"
                + "  \"isLeavingSoon\": false\n"
                + "}");
        susOnlyProducts.put("9306242", "    {\n"
                + "      \"id\": \"9306242\",\n"
                + "      \"name\": \"CHEESE WHEEL PRIMA DONNA\",\n"
                + "      \"description\": \"Cheese Wheel Prima Donnna\",\n"
                + "      \"lineDescription\": \"A SUPERB DUTCH GOUDA STYLE CHEESE OF PASTEURIZED C OW MILK. WITH AN"
                + " AGE OF NEAR 5 MONTHS THE FLAVOR I S SMOOTH ON THE PALATE AND REMINISCENT OF GRUYERE, REGGIANO AND "
                + " AGED GOUDA. A NATURAL FOR ANY CHE\",\n"
                + "      \"pack\": \"1\",\n"
                + "      \"size\": \"22#\",\n"
                + "      \"brandId\": \"CHSLAND\",\n"
                + "      \"brand\": \"CHEESELAND   (IMPORT)\",\n"
                + "      \"categoryId\": 2,\n"
                + "      \"catMajId\": 4,\n"
                + "      \"catIntId\": 99,\n"
                + "      \"catMinId\": 99,\n"
                + "      \"manufacurerCode\": \"HD237\",\n"
                + "      \"imageLink\": [],\n"
                + "      \"categoryName\": \"DAIRY PRODUCTS\",\n"
                + "      \"catMajName\": \"CHEESE\",\n"
                + "      \"catIntName\": \"CHEESE MISC\",\n"
                + "      \"catMinName\": \"CHEESE MISC\",\n"
                + "      \"taxonomy\": {\n"
                + "        \"hierarchyId\": 1201,\n"
                + "        \"businessCenter\": \"Dairy\",\n"
                + "        \"itemGroup\": \"Processed Cheese\",\n"
                + "        \"attributeGroup\": \"Processed Cheese\",\n"
                + "        \"attributes\": null\n"
                + "      },\n"
                + "      \"opcoId\": \"332\",\n"
                + "      \"statusCode\": \"A\",\n"
                + "      \"stockIndicator\": \"D\",\n"
                + "      \"asoh\": 0,\n"
                + "      \"proprietaryCode\": \" \",\n"
                + "      \"internalUpc\": null,\n"
                + "      \"externalUpc\": 70000000000009,\n"
                + "      \"averageWeight\": 26.3,\n"
                + "      \"storageCode\": \"C\",\n"
                + "      \"hseBrandFlag\": \"N\",\n"
                + "      \"phaseOtFlag\": \"N\",\n"
                + "      \"catchWeightIndicator\": \"Y\",\n"
                + "      \"split\": \"N\",\n"
                + "      \"minimumSplit\": 0,\n"
                + "      \"shipSplitOnly\": \"N\",\n"
                + "      \"buyMultiple\": 0,\n"
                + "      \"unitPerCase\": 1,\n"
                + "      \"kosher\": false,\n"
                + "      \"vegan\": false,\n"
                + "      \"halal\": false,\n"
                + "      \"vegetarian\": false,\n"
                + "      \"organic\": false,\n"
                + "      \"greenCertified\": false,\n"
                + "      \"coreIndicator\": \"A\",\n"
                + "      \"relatedProductId\": null,\n"
                + "      \"lastOrderedDate\": null,\n"
                + "      \"controlCode\": \"CS\",\n"
                + "      \"leadTimeForecast\": 2,\n"
                + "      \"isDropShip\": false,\n"
                + "      \"grdCode\": \" \",\n"
                + "      \"isSelectedNonstock\": false,\n"
                + "      \"quantity\": null,\n"
                + "      \"brokerId\": \"687970\",\n"
                + "      \"brokerName\": \"EUROPEAN IMPORTS\",\n"
                + "      \"sourceVendor\": \"1188\",\n"
                + "      \"sourceVendorType\": null,\n"
                + "      \"trueVendor\": \"1188\",\n"
                + "      \"trueVendorShipPtNumber\": \"1188\",\n"
                + "      \"productSpecialist\": \"001\",\n"
                + "      \"productSpecialistName\": \"ADAM SKEATE\",\n"
                + "      \"isSlowMoving\": false,\n"
                + "      \"demandStatusFlag\": 1,\n"
                + "      \"last30quantity\": 0,\n"
                + "      \"rdcNumber\": \"\",\n"
                + "      \"productionItemFlag\": \"\",\n"
                + "      \"trueVendorName\": \"EUROPEAN IMPORTS LTD\",\n"
                + "      \"governmentGrade\": null,\n"
                + "      \"subPrimalCode\": null,\n"
                + "      \"subPrimalDescription\": null,\n"
                + "      \"active\": true,\n"
                + "      \"category\": \"02004099099\",\n"
                + "      \"isNonstockOrderable\": false,\n"
                + "      \"isProprietary\": false,\n"
                + "      \"isNonstock\": false,\n"
                + "      \"isLeavingSoon\": false\n"
                + "    }");
        susOnlyProducts.put("9240714", "    {\n"
                + "      \"id\": \"9240714\",\n"
                + "      \"name\": \"OLIVE CURED IN OIL\",\n"
                + "      \"description\": \"Olive Cured In Oil\",\n"
                + "      \"lineDescription\": \"GREEK OIL CURED OLIVES ARE PERFECT FOR USE AS AN"
                + " APPETIZER, ANTIPASTO PLATTERS, IN SALADS, OR ANY MEDITERRANEAN CUISINE."
                + " REFIGERATE AFTER OPENING, AND KEEP THE LEVEL OF OIL OVER THE OLIVES FOR BEST"
                + " RESULTS. ** PLEASE ALLOW 7 TO 10 DAYS FOR DELIVERY PRODUCT IS HAND PACKED AND SHIPS FROMLOS"
                + " ANGELES UPS GROUND **\",\n"
                + "      \"pack\": \"12\",\n"
                + "      \"size\": \"16 OZ\",\n"
                + "      \"brandId\": \"AIELLO\",\n"
                + "      \"brand\": \"AIELLO\",\n"
                + "      \"categoryId\": 7,\n"
                + "      \"catMajId\": 44,\n"
                + "      \"catIntId\": 19,\n"
                + "      \"catMinId\": 99,\n"
                + "      \"manufacurerCode\": \"500095\",\n"
                + "      \"imageLink\": [],\n"
                + "      \"categoryName\": \"CANNED AND DRY\",\n"
                + "      \"catMajName\": \"IMPORT SPECLTY\",\n"
                + "      \"catIntName\": \"OLIVES SPECLTY\",\n"
                + "      \"catMinName\": \"MISC.\",\n"
                + "      \"taxonomy\": {\n"
                + "        \"hierarchyId\": 1096,\n"
                + "        \"businessCenter\": \"Canned\",\n"
                + "        \"itemGroup\": \"Fruits\",\n"
                + "        \"attributeGroup\": \"Olives\",\n"
                + "        \"attributes\": null\n"
                + "      },\n"
                + "      \"opcoId\": \"332\",\n"
                + "      \"statusCode\": \"N\",\n"
                + "      \"stockIndicator\": \"R\",\n"
                + "      \"asoh\": 0,\n"
                + "      \"proprietaryCode\": \" \",\n"
                + "      \"internalUpc\": null,\n"
                + "      \"externalUpc\": 82313060100,\n"
                + "      \"averageWeight\": 8.25,\n"
                + "      \"storageCode\": \"D\",\n"
                + "      \"hseBrandFlag\": \"N\",\n"
                + "      \"phaseOtFlag\": \"N\",\n"
                + "      \"catchWeightIndicator\": \"N\",\n"
                + "      \"split\": \"Y\",\n"
                + "      \"minimumSplit\": 1,\n"
                + "      \"shipSplitOnly\": \"N\",\n"
                + "      \"buyMultiple\": 1,\n"
                + "      \"unitPerCase\": 12,\n"
                + "      \"kosher\": false,\n"
                + "      \"vegan\": false,\n"
                + "      \"halal\": false,\n"
                + "      \"vegetarian\": false,\n"
                + "      \"organic\": false,\n"
                + "      \"greenCertified\": false,\n"
                + "      \"coreIndicator\": \"N\",\n"
                + "      \"relatedProductId\": null,\n"
                + "      \"lastOrderedDate\": null,\n"
                + "      \"controlCode\": \"CS\",\n"
                + "      \"leadTimeForecast\": 1,\n"
                + "      \"isDropShip\": false,\n"
                + "      \"grdCode\": \" \",\n"
                + "      \"isSelectedNonstock\": false,\n"
                + "      \"quantity\": null,\n"
                + "      \"brokerId\": \"\",\n"
                + "      \"brokerName\": null,\n"
                + "      \"sourceVendor\": \"7308\",\n"
                + "      \"sourceVendorType\": \"CW\",\n"
                + "      \"trueVendor\": \"7308\",\n"
                + "      \"trueVendorShipPtNumber\": \"7308\",\n"
                + "      \"productSpecialist\": \"002\",\n"
                + "      \"productSpecialistName\": \"KEVIN WELLE\",\n"
                + "      \"isSlowMoving\": false,\n"
                + "      \"demandStatusFlag\": 0,\n"
                + "      \"last30quantity\": 0,\n"
                + "      \"rdcNumber\": \"\",\n"
                + "      \"productionItemFlag\": \"\",\n"
                + "      \"trueVendorName\": \"SYSCO CENTRAL WHSE S&E FOND DU\",\n"
                + "      \"governmentGrade\": null,\n"
                + "      \"subPrimalCode\": null,\n"
                + "      \"subPrimalDescription\": null,\n"
                + "      \"active\": true,\n"
                + "      \"category\": \"07044019099\",\n"
                + "      \"isNonstockOrderable\": false,\n"
                + "      \"isProprietary\": false,\n"
                + "      \"isNonstock\": false,\n"
                + "      \"isLeavingSoon\": false\n"
                + "    }");
        susOnlyProducts.put("6684769", "    {\n"
                + "      \"id\": \"6684769\",\n"
                + "      \"name\": \"CHEESE HUMBOLDT FOG\",\n"
                + "      \"description\": \"Cheese Humboldt Fog\",\n"
                + "      \"lineDescription\": \"THIS PRESTIGIOUS SOFT RIPENEDGOAT S MILK CHEESE I S"
                + " THE CREATION OF MARY KEEHN.FRENCH IN STYLE, IT HAS AN ASH VEIN THAT RUNS DOWN THE CENTER OF THE"
                + " R ICH INTERIOR.\",\n"
                + "      \"pack\": \"4\",\n"
                + "      \"size\": \"1LB\",\n"
                + "      \"brandId\": \"CYP GRV\",\n"
                + "      \"brand\": \"CYPRESS GROVE (DAIRY)\",\n"
                + "      \"categoryId\": 2,\n"
                + "      \"catMajId\": 4,\n"
                + "      \"catIntId\": 8,\n"
                + "      \"catMinId\": 99,\n"
                + "      \"manufacurerCode\": \"036055\",\n"
                + "      \"imageLink\": [],\n"
                + "      \"categoryName\": \"DAIRY PRODUCTS\",\n"
                + "      \"catMajName\": \"CHEESE\",\n"
                + "      \"catIntName\": \"NATURAL BULK\",\n"
                + "      \"catMinName\": \"MISC.\",\n"
                + "      \"taxonomy\": {\n"
                + "        \"hierarchyId\": 0,\n"
                + "        \"businessCenter\": null,\n"
                + "        \"itemGroup\": null,\n"
                + "        \"attributeGroup\": null,\n"
                + "        \"attributes\": null\n"
                + "      },\n"
                + "      \"opcoId\": \"332\",\n"
                + "      \"statusCode\": \"N\",\n"
                + "      \"stockIndicator\": \"D\",\n"
                + "      \"asoh\": 0,\n"
                + "      \"proprietaryCode\": null,\n"
                + "      \"internalUpc\": null,\n"
                + "      \"externalUpc\": 90039496002024,\n"
                + "      \"averageWeight\": null,\n"
                + "      \"storageCode\": \"C\",\n"
                + "      \"hseBrandFlag\": \"N\",\n"
                + "      \"phaseOtFlag\": \"N\",\n"
                + "      \"catchWeightIndicator\": \"N\",\n"
                + "      \"split\": \"N\",\n"
                + "      \"minimumSplit\": 0,\n"
                + "      \"shipSplitOnly\": \"N\",\n"
                + "      \"buyMultiple\": 0,\n"
                + "      \"unitPerCase\": 4,\n"
                + "      \"kosher\": false,\n"
                + "      \"vegan\": false,\n"
                + "      \"halal\": false,\n"
                + "      \"vegetarian\": false,\n"
                + "      \"organic\": false,\n"
                + "      \"greenCertified\": false,\n"
                + "      \"coreIndicator\": null,\n"
                + "      \"relatedProductId\": null,\n"
                + "      \"lastOrderedDate\": null,\n"
                + "      \"controlCode\": null,\n"
                + "      \"leadTimeForecast\": 0,\n"
                + "      \"isDropShip\": false,\n"
                + "      \"grdCode\": null,\n"
                + "      \"isSelectedNonstock\": false,\n"
                + "      \"quantity\": null,\n"
                + "      \"brokerId\": null,\n"
                + "      \"brokerName\": null,\n"
                + "      \"sourceVendor\": null,\n"
                + "      \"sourceVendorType\": null,\n"
                + "      \"trueVendor\": null,\n"
                + "      \"trueVendorShipPtNumber\": null,\n"
                + "      \"productSpecialist\": null,\n"
                + "      \"productSpecialistName\": null,\n"
                + "      \"isSlowMoving\": false,\n"
                + "      \"demandStatusFlag\": 0,\n"
                + "      \"last30quantity\": 0,\n"
                + "      \"rdcNumber\": null,\n"
                + "      \"productionItemFlag\": null,\n"
                + "      \"trueVendorName\": null,\n"
                + "      \"governmentGrade\": null,\n"
                + "      \"subPrimalCode\": null,\n"
                + "      \"subPrimalDescription\": null,\n"
                + "      \"active\": true,\n"
                + "      \"category\": \"02004008099\",\n"
                + "      \"isNonstockOrderable\": false,\n"
                + "      \"isProprietary\": false,\n"
                + "      \"isNonstock\": false,\n"
                + "      \"isLeavingSoon\": false\n"
                + "    }");
        susOnlyProducts.put("1245206", "    {\n"
                + "      \"id\": \"1245206\",\n"
                + "      \"name\": \"CANDY SOUR GHETTI\",\n"
                + "      \"description\": \"Candy Sour S'ghetti\",\n"
                + "      \"lineDescription\": \"TONGUE TWISTING SOUR SPAGHETTI SHAPED STRANDS COME IN BLUEBERRY,"
                + " GREEN APPLE AND STRAWBERRY WITH TRU E SOUR POWER.\",\n"
                + "      \"pack\": \"12\",\n"
                + "      \"size\": \"5 OZ\",\n"
                + "      \"brandId\": \"HARIBO\",\n"
                + "      \"brand\": \"HARIBO\",\n"
                + "      \"categoryId\": 7,\n"
                + "      \"catMajId\": 6,\n"
                + "      \"catIntId\": 1,\n"
                + "      \"catMinId\": 6,\n"
                + "      \"manufacurerCode\": \"35888\",\n"
                + "      \"imageLink\": [],\n"
                + "      \"categoryName\": \"CANNED AND DRY\",\n"
                + "      \"catMajName\": \"CANDY AND NUTS\",\n"
                + "      \"catIntName\": \"CANDY\",\n"
                + "      \"catMinName\": \"HARD/SOFT\",\n"
                + "      \"taxonomy\": {\n"
                + "        \"hierarchyId\": 1283,\n"
                + "        \"businessCenter\": \"Grocery\",\n"
                + "        \"itemGroup\": \"Candy\",\n"
                + "        \"attributeGroup\": \"Candy (Non-Chocolate)\",\n"
                + "        \"attributes\": null\n"
                + "      },\n"
                + "      \"opcoId\": \"332\",\n"
                + "      \"statusCode\": \"N\",\n"
                + "      \"stockIndicator\": \"D\",\n"
                + "      \"asoh\": 0,\n"
                + "      \"proprietaryCode\": \" \",\n"
                + "      \"internalUpc\": null,\n"
                + "      \"externalUpc\": 42238358898,\n"
                + "      \"averageWeight\": 3.75,\n"
                + "      \"storageCode\": \"D\",\n"
                + "      \"hseBrandFlag\": \"N\",\n"
                + "      \"phaseOtFlag\": \"N\",\n"
                + "      \"catchWeightIndicator\": \"N\",\n"
                + "      \"split\": \"N\",\n"
                + "      \"minimumSplit\": 0,\n"
                + "      \"shipSplitOnly\": \"N\",\n"
                + "      \"buyMultiple\": 0,\n"
                + "      \"unitPerCase\": 12,\n"
                + "      \"kosher\": false,\n"
                + "      \"vegan\": false,\n"
                + "      \"halal\": false,\n"
                + "      \"vegetarian\": false,\n"
                + "      \"organic\": false,\n"
                + "      \"greenCertified\": false,\n"
                + "      \"coreIndicator\": \" \",\n"
                + "      \"relatedProductId\": null,\n"
                + "      \"lastOrderedDate\": null,\n"
                + "      \"controlCode\": \"CS\",\n"
                + "      \"leadTimeForecast\": 2,\n"
                + "      \"isDropShip\": false,\n"
                + "      \"grdCode\": \" \",\n"
                + "      \"isSelectedNonstock\": false,\n"
                + "      \"quantity\": null,\n"
                + "      \"brokerId\": \"687970\",\n"
                + "      \"brokerName\": \"EUROPEAN IMPORTS\",\n"
                + "      \"sourceVendor\": \"1188\",\n"
                + "      \"sourceVendorType\": null,\n"
                + "      \"trueVendor\": \"1188\",\n"
                + "      \"trueVendorShipPtNumber\": \"1188\",\n"
                + "      \"productSpecialist\": \"001\",\n"
                + "      \"productSpecialistName\": \"ADAM SKEATE\",\n"
                + "      \"isSlowMoving\": false,\n"
                + "      \"demandStatusFlag\": 1,\n"
                + "      \"last30quantity\": 0,\n"
                + "      \"rdcNumber\": \"\",\n"
                + "      \"productionItemFlag\": \"\",\n"
                + "      \"trueVendorName\": \"EUROPEAN IMPORTS LTD\",\n"
                + "      \"governmentGrade\": null,\n"
                + "      \"subPrimalCode\": null,\n"
                + "      \"subPrimalDescription\": null,\n"
                + "      \"active\": true,\n"
                + "      \"category\": \"07006001006\",\n"
                + "      \"isNonstockOrderable\": false,\n"
                + "      \"isProprietary\": false,\n"
                + "      \"isNonstock\": false,\n"
                + "      \"isLeavingSoon\": false\n"
                + "    }");
        susOnlyProducts.put("1900568", "    {\n"
                + "      \"id\": \"1900568\",\n"
                + "      \"name\": \"WATER FLAVOR CRAN RASP CAN 12Z\",\n"
                + "      \"description\": \"Water Flavor Cranberry Raspberry Can 12 oz\",\n"
                + "      \"lineDescription\": \"THE TARTNESS OF CRANBERRIES COMBINE WITH THE SWEET NESS OF RASPBERRIES"
                + " FOR A TASTE SATISFYING BEVERAG E. IT IS PACKAGED IN A PULL TAB CAN.\",\n"
                + "      \"pack\": \"2\",\n"
                + "      \"size\": \"12\",\n"
                + "      \"brandId\": \"LACROIX\",\n"
                + "      \"brand\": \"LACROIX\",\n"
                + "      \"categoryId\": 7,\n"
                + "      \"catMajId\": 16,\n"
                + "      \"catIntId\": 6,\n"
                + "      \"catMinId\": 99,\n"
                + "      \"manufacurerCode\": \"69196-9\",\n"
                + "      \"imageLink\": [\n"
                + "        \"./1900568/web/1.jpg\"\n"
                + "      ],\n"
                + "      \"categoryName\": \"CANNED AND DRY\",\n"
                + "      \"catMajName\": \"JUICES/DRINKS\",\n"
                + "      \"catIntName\": \"WATER\",\n"
                + "      \"catMinName\": \"MISC.\",\n"
                + "      \"taxonomy\": {\n"
                + "        \"hierarchyId\": 1086,\n"
                + "        \"businessCenter\": \"Beverage\",\n"
                + "        \"itemGroup\": \"Water\",\n"
                + "        \"attributeGroup\": \"Spring, Artesian & Mineral\",\n"
                + "        \"attributes\": null\n"
                + "      },\n"
                + "      \"opcoId\": \"332\",\n"
                + "      \"statusCode\": \"A\",\n"
                + "      \"stockIndicator\": \"S\",\n"
                + "      \"asoh\": 4,\n"
                + "      \"proprietaryCode\": \" \",\n"
                + "      \"internalUpc\": null,\n"
                + "      \"externalUpc\": 70000000000009,\n"
                + "      \"averageWeight\": 21,\n"
                + "      \"storageCode\": \"D\",\n"
                + "      \"hseBrandFlag\": \"N\",\n"
                + "      \"phaseOtFlag\": \"N\",\n"
                + "      \"catchWeightIndicator\": \"N\",\n"
                + "      \"split\": \"N\",\n"
                + "      \"minimumSplit\": 0,\n"
                + "      \"shipSplitOnly\": \"N\",\n"
                + "      \"buyMultiple\": 0,\n"
                + "      \"unitPerCase\": 2,\n"
                + "      \"kosher\": false,\n"
                + "      \"vegan\": false,\n"
                + "      \"halal\": false,\n"
                + "      \"vegetarian\": false,\n"
                + "      \"organic\": false,\n"
                + "      \"greenCertified\": false,\n"
                + "      \"coreIndicator\": \" \",\n"
                + "      \"relatedProductId\": null,\n"
                + "      \"lastOrderedDate\": null,\n"
                + "      \"controlCode\": \"CS\",\n"
                + "      \"leadTimeForecast\": 2,\n"
                + "      \"isDropShip\": false,\n"
                + "      \"grdCode\": \" \",\n"
                + "      \"isSelectedNonstock\": false,\n"
                + "      \"quantity\": null,\n"
                + "      \"brokerId\": \"687970\",\n"
                + "      \"brokerName\": \"EUROPEAN IMPORTS\",\n"
                + "      \"sourceVendor\": \"1188\",\n"
                + "      \"sourceVendorType\": null,\n"
                + "      \"trueVendor\": \"1188\",\n"
                + "      \"trueVendorShipPtNumber\": \"1188\",\n"
                + "      \"productSpecialist\": \"001\",\n"
                + "      \"productSpecialistName\": \"ADAM SKEATE\",\n"
                + "      \"isSlowMoving\": false,\n"
                + "      \"demandStatusFlag\": 0,\n"
                + "      \"last30quantity\": 0,\n"
                + "      \"rdcNumber\": \"\",\n"
                + "      \"productionItemFlag\": \"\",\n"
                + "      \"trueVendorName\": \"EUROPEAN IMPORTS LTD\",\n"
                + "      \"governmentGrade\": null,\n"
                + "      \"subPrimalCode\": null,\n"
                + "      \"subPrimalDescription\": null,\n"
                + "      \"active\": true,\n"
                + "      \"category\": \"07016006099\",\n"
                + "      \"isNonstockOrderable\": false,\n"
                + "      \"isProprietary\": false,\n"
                + "      \"isNonstock\": false,\n"
                + "      \"isLeavingSoon\": false\n"
                + "    }");

        susOnlyProducts.put("4391102", "{\n"
                + "  \"id\": \"4391102\",\n"
                + "  \"name\": \"STEAK BEEF SIRLOIN FAJ CUT\",\n"
                + "  \"description\": null,\n"
                + "  \"lineDescription\": null,\n"
                + "  \"pack\": \"2\",\n"
                + "  \"size\": \"5 LB\",\n"
                + "  \"brandId\": \"APPERTS\",\n"
                + "  \"brand\": \"APPERTS\",\n"
                + "  \"categoryId\": 3,\n"
                + "  \"catMajId\": 1,\n"
                + "  \"catIntId\": 3,\n"
                + "  \"catMinId\": 1,\n"
                + "  \"manufacturerCode\": \"94500\",\n"
                + "  \"imageLink\": [\n"
                + "    \"./4391102/web/1.jpg\"\n"
                + "  ],\n"
                + "  \"categoryName\": \"MEATS\",\n"
                + "  \"catMajName\": \"BEEF FRESH\",\n"
                + "  \"catIntName\": \"BEEF PORTION FR\",\n"
                + "  \"catMinName\": \"STEAKS\",\n"
                + "  \"taxonomy\": {\n"
                + "    \"hierarchyId\": 1048,\n"
                + "    \"businessCenter\": \"Beef\",\n"
                + "    \"itemGroup\": \"Further Processed Meat\",\n"
                + "    \"attributeGroup\": \"Fajita Meat\",\n"
                + "    \"attributes\": [\n"
                + "      {\n"
                + "        \"priority\": 1,\n"
                + "        \"name\": \"Raw Materials\",\n"
                + "        \"value\": null\n"
                + "      },\n"
                + "      {\n"
                + "        \"priority\": 2,\n"
                + "        \"name\": \"Grade\",\n"
                + "        \"value\": null\n"
                + "      },\n"
                + "      {\n"
                + "        \"priority\": 3,\n"
                + "        \"name\": \"Marination %\",\n"
                + "        \"value\": null\n"
                + "      },\n"
                + "      {\n"
                + "        \"priority\": 4,\n"
                + "        \"name\": \"Natural Claim\",\n"
                + "        \"value\": null\n"
                + "      },\n"
                + "      {\n"
                + "        \"priority\": 5,\n"
                + "        \"name\": \"Feed Claim\",\n"
                + "        \"value\": null\n"
                + "      },\n"
                + "      {\n"
                + "        \"priority\": 6,\n"
                + "        \"name\": \"Trim\",\n"
                + "        \"value\": null\n"
                + "      }\n"
                + "    ]\n"
                + "  },\n"
                + "  \"opcoId\": \"332\",\n"
                + "  \"statusCode\": \"A\",\n"
                + "  \"stockIndicator\": \"S\",\n"
                + "  \"asoh\": 0,\n"
                + "  \"proprietaryCode\": \" \",\n"
                + "  \"internalUpc\": null,\n"
                + "  \"externalUpc\": 98911945008,\n"
                + "  \"averageWeight\": 10,\n"
                + "  \"storageCode\": \"C\",\n"
                + "  \"hseBrandFlag\": \"N\",\n"
                + "  \"phaseOtFlag\": \"N\",\n"
                + "  \"catchWeightIndicator\": \"N\",\n"
                + "  \"split\": \"N\",\n"
                + "  \"minimumSplit\": 0,\n"
                + "  \"shipSplitOnly\": \"N\",\n"
                + "  \"buyMultiple\": 0,\n"
                + "  \"unitPerCase\": 2,\n"
                + "  \"kosher\": false,\n"
                + "  \"vegan\": false,\n"
                + "  \"halal\": false,\n"
                + "  \"vegetarian\": false,\n"
                + "  \"organic\": false,\n"
                + "  \"greenCertified\": false,\n"
                + "  \"coreIndicator\": \" \",\n"
                + "  \"relatedProductId\": null,\n"
                + "  \"lastOrderedDate\": null,\n"
                + "  \"controlCode\": \"CS\",\n"
                + "  \"leadTimeForecast\": 2,\n"
                + "  \"isDropShip\": false,\n"
                + "  \"grdCode\": \" \",\n"
                + "  \"isSelectedNonstock\": false,\n"
                + "  \"quantity\": null,\n"
                + "  \"brokerId\": \"\",\n"
                + "  \"brokerName\": null,\n"
                + "  \"sourceVendor\": \"194\",\n"
                + "  \"sourceVendorType\": null,\n"
                + "  \"trueVendor\": \"194\",\n"
                + "  \"trueVendorShipPtNumber\": \"194\",\n"
                + "  \"productSpecialist\": \"008\",\n"
                + "  \"productSpecialistName\": \"PROCESSING DIVISION\",\n"
                + "  \"isSlowMoving\": false,\n"
                + "  \"demandStatusFlag\": 0,\n"
                + "  \"last30quantity\": 0,\n"
                + "  \"rdcNumber\": \"\",\n"
                + "  \"productionItemFlag\": \"Y\",\n"
                + "  \"trueVendorName\": \"SYSCO WESTERN MINNESOTA INC.\",\n"
                + "  \"governmentGrade\": null,\n"
                + "  \"subPrimalCode\": null,\n"
                + "  \"subPrimalDescription\": null,\n"
                + "  \"active\": true,\n"
                + "  \"category\": \"03001003001\",\n"
                + "  \"isNonstockOrderable\": false,\n"
                + "  \"isProprietary\": false,\n"
                + "  \"isNonstock\": false,\n"
                + "  \"isLeavingSoon\": false\n"
                + "}");

        susOnlyProducts.put("2857102", "{\n"
                + "  \"id\": \"2857102\",\n"
                + "  \"name\": \"BEEF SHORT LOIN CH #174\",\n"
                + "  \"description\": null,\n"
                + "  \"lineDescription\": null,\n"
                + "  \"pack\": \"1\",\n"
                + "  \"size\": \"20#AVG\",\n"
                + "  \"brandId\": \"APPERTS\",\n"
                + "  \"brand\": \"APPERTS\",\n"
                + "  \"categoryId\": 3,\n"
                + "  \"catMajId\": 1,\n"
                + "  \"catIntId\": 1,\n"
                + "  \"catMinId\": 13,\n"
                + "  \"manufacturerCode\": \"91105\",\n"
                + "  \"imageLink\": [],\n"
                + "  \"categoryName\": \"MEATS\",\n"
                + "  \"catMajName\": \"BEEF FRESH\",\n"
                + "  \"catIntName\": \"BEEF BOXED FRSH\",\n"
                + "  \"catMinName\": \"PREM BOX BEEF\",\n"
                + "  \"taxonomy\": {\n"
                + "    \"hierarchyId\": 0,\n"
                + "    \"businessCenter\": null,\n"
                + "    \"itemGroup\": null,\n"
                + "    \"attributeGroup\": null,\n"
                + "    \"attributes\": [\n"
                + "      {\n"
                + "        \"priority\": 0,\n"
                + "        \"name\": null,\n"
                + "        \"value\": null\n"
                + "      }\n"
                + "    ]\n"
                + "  },\n"
                + "  \"opcoId\": \"332\",\n"
                + "  \"statusCode\": \"N\",\n"
                + "  \"stockIndicator\": \"S\",\n"
                + "  \"asoh\": 43,\n"
                + "  \"proprietaryCode\": \" \",\n"
                + "  \"internalUpc\": null,\n"
                + "  \"externalUpc\": 90098911911051,\n"
                + "  \"averageWeight\": 20,\n"
                + "  \"storageCode\": \"C\",\n"
                + "  \"hseBrandFlag\": \"N\",\n"
                + "  \"phaseOtFlag\": \"N\",\n"
                + "  \"catchWeightIndicator\": \"Y\",\n"
                + "  \"split\": \"N\",\n"
                + "  \"minimumSplit\": 0,\n"
                + "  \"shipSplitOnly\": \"N\",\n"
                + "  \"buyMultiple\": 0,\n"
                + "  \"unitPerCase\": 1,\n"
                + "  \"kosher\": false,\n"
                + "  \"vegan\": false,\n"
                + "  \"halal\": false,\n"
                + "  \"vegetarian\": false,\n"
                + "  \"organic\": false,\n"
                + "  \"greenCertified\": false,\n"
                + "  \"coreIndicator\": \" \",\n"
                + "  \"relatedProductId\": null,\n"
                + "  \"lastOrderedDate\": null,\n"
                + "  \"controlCode\": \"CS\",\n"
                + "  \"leadTimeForecast\": 2,\n"
                + "  \"isDropShip\": false,\n"
                + "  \"grdCode\": \" \",\n"
                + "  \"isSelectedNonstock\": false,\n"
                + "  \"quantity\": null,\n"
                + "  \"brokerId\": \"\",\n"
                + "  \"brokerName\": null,\n"
                + "  \"sourceVendor\": \"194\",\n"
                + "  \"sourceVendorType\": null,\n"
                + "  \"trueVendor\": \"194\",\n"
                + "  \"trueVendorShipPtNumber\": \"194\",\n"
                + "  \"productSpecialist\": \"008\",\n"
                + "  \"productSpecialistName\": \"PROCESSING DIVISION\",\n"
                + "  \"isSlowMoving\": false,\n"
                + "  \"demandStatusFlag\": 0,\n"
                + "  \"last30quantity\": 0,\n"
                + "  \"rdcNumber\": \"\",\n"
                + "  \"productionItemFlag\": \"N\",\n"
                + "  \"trueVendorName\": \"SYSCO WESTERN MINNESOTA INC.\",\n"
                + "  \"governmentGrade\": null,\n"
                + "  \"subPrimalCode\": null,\n"
                + "  \"subPrimalDescription\": null,\n"
                + "  \"active\": true,\n"
                + "  \"category\": \"03001001013\",\n"
                + "  \"isNonstockOrderable\": false,\n"
                + "  \"isProprietary\": false,\n"
                + "  \"isNonstock\": false,\n"
                + "  \"isLeavingSoon\": false\n"
                + "}");
        susOnlyProducts.put("3492610", "    {\n"
                + "  \"id\": \"3492610\",\n"
                + "  \"name\": \"SPICE BASIL LEAVES\",\n"
                + "  \"description\": \"Spice Basil Leaves\",\n"
                + "  \"lineDescription\": \"Sysco Classic basil leaves are a pantry staple with a robust flavor ideal"
                + " "
                + "for tomato-based dishes and sauces. Combine the leaves with other herbs to season pizzas, "
                + "stuffings and soups.\\n\\n\\n* Three 1.8-pound resealable plastic bottles per case\\n\\n* Whole "
                + "leaf herb, yield depends on usage\\n\\n* Consistent leaf texture and flavor, 11 percent maximum "
                + "moisture\\n\\n* Accentuates chicken dishes, pesto recipes and vegetables such as squash, zucchini "
                + "and eggplant\\n\\n* Store at ambient temperatures between 50 and 80 F, avoid direct sunlight "
                + "exposure and excessive heat\\n\\n* Case measures 16 inches long by 8.8 inches wide by 10.8 "
                + "inches high\",\n"
                + "  \"pack\": \"3\",\n"
                + "  \"size\": \"1.75LB\",\n"
                + "  \"brandId\": \"SYS CLS\",\n"
                + "  \"brand\": \"SYSCO CLASSIC\",\n"
                + "  \"categoryId\": 7,\n"
                + "  \"catMajId\": 35,\n"
                + "  \"catIntId\": 3,\n"
                + "  \"catMinId\": 99,\n"
                + "  \"manufacturerCode\": \"901216551\",\n"
                + "  \"imageLink\": [\n"
                + "    \"./3492610/web/1.jpg\",\n"
                + "    \"./3492610/web/2.jpg\",\n"
                + "    \"./3492610/web/3.jpg\",\n"
                + "    \"./3492610/web/4.jpg\",\n"
                + "    \"./3492610/web/5.jpg\",\n"
                + "    \"./3492610/web/6.jpg\",\n"
                + "    \"./3492610/web/7.jpg\"\n"
                + "  ],\n"
                + "  \"categoryName\": \"CANNED AND DRY\",\n"
                + "  \"catMajName\": \"SALT/SEASN/SPCE\",\n"
                + "  \"catIntName\": \"SPICES\",\n"
                + "  \"catMinName\": \"MISC.\",\n"
                + "  \"taxonomy\": {\n"
                + "    \"hierarchyId\": 1310,\n"
                + "    \"businessCenter\": \"Grocery\",\n"
                + "    \"itemGroup\": \"Seasonings, Spices & Herbs\",\n"
                + "    \"attributeGroup\": \"Seasonings, Spices & Herbs\",\n"
                + "    \"attributes\": [\n"
                + "      {\n"
                + "        \"priority\": 1,\n"
                + "        \"name\": \"Seasoning/Spice Type\",\n"
                + "        \"value\": \"Spices & Herbs\"\n"
                + "      },\n"
                + "      {\n"
                + "        \"priority\": 2,\n"
                + "        \"name\": \"Seasoning/Spice Type\",\n"
                + "        \"value\": \"Lavender\"\n"
                + "      },\n"
                + "      {\n"
                + "        \"priority\": 3,\n"
                + "        \"name\": \"Form\",\n"
                + "        \"value\": null\n"
                + "      },\n"
                + "      {\n"
                + "        \"priority\": 4,\n"
                + "        \"name\": \"Color\",\n"
                + "        \"value\": null\n"
                + "      },\n"
                + "      {\n"
                + "        \"priority\": 5,\n"
                + "        \"name\": \"Container Size\",\n"
                + "        \"value\": null\n"
                + "      },\n"
                + "      {\n"
                + "        \"priority\": 6,\n"
                + "        \"name\": \"Container Type\",\n"
                + "        \"value\": \"Plastic Bag\"\n"
                + "      },\n"
                + "      {\n"
                + "        \"priority\": 7,\n"
                + "        \"name\": \"Iodine Claim\",\n"
                + "        \"value\": null\n"
                + "      },\n"
                + "      {\n"
                + "        \"priority\": 8,\n"
                + "        \"name\": \"Organic Claim\",\n"
                + "        \"value\": null\n"
                + "      },\n"
                + "      {\n"
                + "        \"priority\": 9,\n"
                + "        \"name\": \"Natural Claim\",\n"
                + "        \"value\": null\n"
                + "      }\n"
                + "    ]\n"
                + "  },\n"
                + "  \"opcoId\": \"332\",\n"
                + "  \"statusCode\": \"A\",\n"
                + "  \"stockIndicator\": \"S\",\n"
                + "  \"asoh\": 27,\n"
                + "  \"proprietaryCode\": \" \",\n"
                + "  \"internalUpc\": 734730511221,\n"
                + "  \"externalUpc\": 10734730511228,\n"
                + "  \"averageWeight\": 5.25,\n"
                + "  \"storageCode\": \"D\",\n"
                + "  \"hseBrandFlag\": \"Y\",\n"
                + "  \"phaseOtFlag\": \"N\",\n"
                + "  \"catchWeightIndicator\": \"N\",\n"
                + "  \"split\": \"Y\",\n"
                + "  \"minimumSplit\": 1,\n"
                + "  \"shipSplitOnly\": \"Y\",\n"
                + "  \"buyMultiple\": 1,\n"
                + "  \"unitPerCase\": 3,\n"
                + "  \"kosher\": false,\n"
                + "  \"vegan\": false,\n"
                + "  \"halal\": false,\n"
                + "  \"vegetarian\": false,\n"
                + "  \"organic\": false,\n"
                + "  \"greenCertified\": false,\n"
                + "  \"coreIndicator\": \"A\",\n"
                + "  \"relatedProductId\": null,\n"
                + "  \"lastOrderedDate\": null,\n"
                + "  \"controlCode\": \"CS\",\n"
                + "  \"leadTimeForecast\": 14,\n"
                + "  \"isDropShip\": false,\n"
                + "  \"grdCode\": \"C\",\n"
                + "  \"isSelectedNonstock\": false,\n"
                + "  \"quantity\": null,\n"
                + "  \"brokerId\": \"43015\",\n"
                + "  \"brokerName\": \"THE CORE GROUP\",\n"
                + "  \"sourceVendor\": \"2341\",\n"
                + "  \"sourceVendorType\": null,\n"
                + "  \"trueVendor\": \"2341\",\n"
                + "  \"trueVendorShipPtNumber\": \"2341\",\n"
                + "  \"productSpecialist\": \"017\",\n"
                + "  \"productSpecialistName\": \"KEVIN WELLE\",\n"
                + "  \"isSlowMoving\": false,\n"
                + "  \"demandStatusFlag\": 0,\n"
                + "  \"last30quantity\": 0,\n"
                + "  \"rdcNumber\": \"\",\n"
                + "  \"productionItemFlag\": \"\",\n"
                + "  \"trueVendorName\": \"MCCORMICK&CO INC\",\n"
                + "  \"governmentGrade\": null,\n"
                + "  \"subPrimalCode\": null,\n"
                + "  \"subPrimalDescription\": null,\n"
                + "  \"active\": true,\n"
                + "  \"category\": \"07035003099\",\n"
                + "  \"isNonstockOrderable\": false,\n"
                + "  \"isProprietary\": false,\n"
                + "  \"isNonstock\": false,\n"
                + "  \"isLeavingSoon\": false\n"
                + "}");
        susOnlyProducts.put("8847491", "    {\n"
                + "      \"id\": \"8847491\",\n"
                + "      \"name\": \"EGG HARDBOILED WHL PEEL SEL\",\n"
                + "      \"description\": \"Egg Hardboiled Whole Peeled Select\",\n"
                + "      \"lineDescription\": \"Wholesome Farms Classic refrigerated peeled hard cooked eggs by Sysco"
                + " deliver authentic hardboiled egg taste in an easy-to-prepare product. Just remove what you need"
                + " from the tub to use in a wide range of recipes.* One 25-pound, square tub per master case\\n*"
                + " Made from Select grade whole hard cooked eggs, approximately 230 eggs stored in brine\\n* Fully"
                + " cooked for convenience that saves on food prep time, high-volume tub optimizes inventory"
                + " control\\n* 100 percent yield, ideal for high-volume operators with a lot of egg recipes\\n* Ideal"
                + " for breakfast, anytime snack, egg salads, salad toppings, or as ingredient for scotch eggs or"
                + " deviled eggs\\n* Simply thaw and serve, no cooking required\\n* Keep refrigerated between 33-40 F,"
                + " shelf life is 56 days from production date if kept unopened\\n* Use within 5 days of opening"
                + " product\\n* Use by packaging code listed as DD/MMM/YY format\\n* Case dimensions 9.9 inches long"
                + " by 9.9 inches wide by 13.3 inches high\",\n"
                + "      \"pack\": \"1\",\n"
                + "      \"size\": \"25 LB\",\n"
                + "      \"brandId\": \"WHLFCLS\",\n"
                + "      \"brand\": \"WHOLESOME FARMS CLASSIC\",\n"
                + "      \"categoryId\": 2,\n"
                + "      \"catMajId\": 1,\n"
                + "      \"catIntId\": 2,\n"
                + "      \"catMinId\": 1,\n"
                + "      \"manufacurerCode\": \"34730-25505-00\",\n"
                + "      \"imageLink\": [],\n"
                + "      \"categoryName\": \"DAIRY PRODUCTS\",\n"
                + "      \"catMajName\": \"EGGS\",\n"
                + "      \"catIntName\": \"HARD COOKED EGG\",\n"
                + "      \"catMinName\": \"WHOLE/BUCKET\",\n"
                + "      \"taxonomy\": {\n"
                + "        \"hierarchyId\": 1191,\n"
                + "        \"businessCenter\": \"Dairy\",\n"
                + "        \"itemGroup\": \"Eggs\",\n"
                + "        \"attributeGroup\": \"Pre-Cooked\",\n"
                + "        \"attributes\": null\n"
                + "      },\n"
                + "      \"opcoId\": \"332\",\n"
                + "      \"statusCode\": \"A\",\n"
                + "      \"stockIndicator\": \"S\",\n"
                + "      \"asoh\": 17,\n"
                + "      \"proprietaryCode\": \" \",\n"
                + "      \"internalUpc\": null,\n"
                + "      \"externalUpc\": 734730255057,\n"
                + "      \"averageWeight\": 25,\n"
                + "      \"storageCode\": \"C\",\n"
                + "      \"hseBrandFlag\": \"Y\",\n"
                + "      \"phaseOtFlag\": \"N\",\n"
                + "      \"catchWeightIndicator\": \"N\",\n"
                + "      \"split\": \"N\",\n"
                + "      \"minimumSplit\": 0,\n"
                + "      \"shipSplitOnly\": \"N\",\n"
                + "      \"buyMultiple\": 0,\n"
                + "      \"unitPerCase\": 1,\n"
                + "      \"kosher\": false,\n"
                + "      \"vegan\": false,\n"
                + "      \"halal\": false,\n"
                + "      \"vegetarian\": false,\n"
                + "      \"organic\": false,\n"
                + "      \"greenCertified\": false,\n"
                + "      \"coreIndicator\": \"A\",\n"
                + "      \"relatedProductId\": null,\n"
                + "      \"lastOrderedDate\": null,\n"
                + "      \"controlCode\": \"CS\",\n"
                + "      \"leadTimeForecast\": 9,\n"
                + "      \"isDropShip\": false,\n"
                + "      \"grdCode\": \"C\",\n"
                + "      \"isSelectedNonstock\": false,\n"
                + "      \"quantity\": null,\n"
                + "      \"brokerId\": \"43015\",\n"
                + "      \"brokerName\": \"THE CORE GROUP\",\n"
                + "      \"sourceVendor\": \"25104\",\n"
                + "      \"sourceVendorType\": null,\n"
                + "      \"trueVendor\": \"25104\",\n"
                + "      \"trueVendorShipPtNumber\": \"25104\",\n"
                + "      \"productSpecialist\": \"113\",\n"
                + "      \"productSpecialistName\": \"EMILY SCHNEIDER\",\n"
                + "      \"isSlowMoving\": false,\n"
                + "      \"demandStatusFlag\": 0,\n"
                + "      \"last30quantity\": 0,\n"
                + "      \"rdcNumber\": \"\",\n"
                + "      \"productionItemFlag\": \"\",\n"
                + "      \"trueVendorName\": \"MICHAEL FOODS\",\n"
                + "      \"governmentGrade\": null,\n"
                + "      \"subPrimalCode\": null,\n"
                + "      \"subPrimalDescription\": null,\n"
                + "      \"active\": true,\n"
                + "      \"category\": \"02001002001\",\n"
                + "      \"isNonstockOrderable\": false,\n"
                + "      \"isProprietary\": false,\n"
                + "      \"isNonstock\": false,\n"
                + "      \"isLeavingSoon\": false\n"
                + "    }");
    }

    private final DummySusSusModelRepository repository;
    private final ProductProcessor productProcessor;
    private final CustomerOrderProcessor customerOrderProcessor;
    private final InvoiceProcessor invoiceProcessor;
    private final CustomerProcessor customerProcessor;
    private final CostProcessor costProcessor;
    private final PurchaseOrderProcessor purchaseOrderProcessor;
    private final ProfileService profileService;

    private final ObjectMapper objectMapper;

    private static String generatePoNumber(final SusCreatePurchaseOrderData payload, final String roomCode) {
        return isNull(payload.getCustomerOrderNumber())
                ? format("%s-%d-%d", roomCode, payload.getCalendarShipPickupDate(), poNumbers.incrementAndGet())
                : "po-" + payload.getCustomerOrderNumber();
    }

    private static void updatePurchaseItems(final List<SusPurchaseLineItemData> existItems,
                                            final List<SusPurchaseLineItemData> newItems) {
        final Map<String, SusPurchaseLineItemData> newItemsMap = newItems.stream()
                .collect(toMap(lineItemData -> format("%s-%s", lineItemData.getOrderDetailLineNumber(),
                        lineItemData.getItemNumber()), identity()));

        final Map<String, SusPurchaseLineItemData> existedItemsMap = existItems.stream()
                .collect(toMap(lineItemData -> format("%s-%s", lineItemData.getOrderDetailLineNumber(),
                        lineItemData.getItemNumber()), identity()));

        for (final Entry<String, SusPurchaseLineItemData> entry : newItemsMap.entrySet()) {
            final String lineItemKey = entry.getKey();
            final SusPurchaseLineItemData value = entry.getValue();

            if (!existedItemsMap.containsKey(lineItemKey)) {
                existItems.add(value);
            }
        }
    }

    private static String guessAtFirstCaseId(final SusPurchaseOrderReceipt payload) {
        final List<SusPurchaseOrderReceiptLineItem> lineItems = payload.getDetailLineItems();
        if (lineItems.isEmpty()) {
            return "∅LITEMS:" + nextReponseNumber.incrementAndGet();
        }
        final List<SusPurchaseOrderReceiptLineItemCase> lineItemCases = lineItems.get(0).getCases();
        if (lineItemCases.isEmpty()) {
            return "∅CASES:" + nextReponseNumber.incrementAndGet();
        }
        return lineItemCases.get(0).getId();
    }

    void createProduct(final SusProductData productData) {
        final String code = productData.getId();

        repository.save(new SusModel(code, PRODUCT, productData.asMap(objectMapper)));
        productProcessor.run(productData);
    }

    void createProductionProductCost(final List<SusProductCostUpdateData> susCostDataList) {
        final List<SusModel> susModels = susCostDataList.stream()
                .map(data -> new SusModel(data.getProducedItemNumber(), PRODUCT_COST, data.asMap(objectMapper)))
                .collect(toList());

        repository.saveAll(susModels);
    }

    void createSourceProductCosts(final SusProductCostNotificationData susCostData) {
        repository.save(new SusModel(susCostData.getSourceItemNumber(), PRODUCT_COST, susCostData.asMap(objectMapper)));
        costProcessor.run(susCostData);
    }

    void receiveSalesOrderFromSus(final SusSalesOrderStatus susSalesOrdersData) {
        log.info("Sales order from SUS to Prime: " + susSalesOrdersData);

        final Random rnd = new Random();
        final int generatedId = 100000 + rnd.nextInt(900000);
        repository.save(new SusModel(String.valueOf(generatedId), SALES_ORDER_STATUS,
                susSalesOrdersData.asMap(objectMapper)));

        customerOrderProcessor.preProcess(susSalesOrdersData);
    }

    void createSalesOrderInDummySus(final SusSalesOrdersData susSalesOrdersData) {
        log.info("Sales order from Prime to SUS: " + susSalesOrdersData);
        susSalesOrdersData.getOrder().forEach(order -> {
            final String id = order.getOrderHeader().getPurchaseOrderNo(); //maybe not purchase no
            repository.save(new SusModel(id, SALES_ORDER, order.asMap(objectMapper)));
        });
    }

    void receiveSourceMeatInvoice(final SusInvoice invoice) {
        invoiceProcessor.run(invoice);
    }

    void createCustomer(final SusCustomerData customer) {
        final String id = customer.getCustomerId();
        repository.save(new SusModel(id, CUSTOMER, customer.asMap(objectMapper)));
        customerProcessor.run(customer);
    }

    void createOrUpdateAsoh(final SusAsohData payload) {
        final String id = payload.getBusinessUnitNumber();
        repository.save(new SusModel(id, ASOH, payload.asMap(objectMapper)));
    }

    SusAsohData getAsoh(final SusAsohData payload) {
        final Optional<SusModel> susModel = repository.findByTypeAndModelId(ASOH, payload.getBusinessUnitNumber());
        if (susModel.isPresent()) {
            final SusAsohData existingSusAsohData = objectMapper.convertValue(
                    susModel.get().getData(), SusAsohData.class);

            final List<SusAsohProductData> queriedProducts = existingSusAsohData.getProducts()
                    .stream()
                    .filter(p ->
                            payload.getProducts()
                                    .stream()
                                    .anyMatch(product -> product.getSupc().equals(p.getSupc())))
                    .collect(toList());

            return SusAsohData.builder()
                    .products(queriedProducts)
                    .businessUnitNumber(existingSusAsohData.getBusinessUnitNumber())
                    .requestDate(payload.getRequestDate())
                    .build();
        }

        return null;
    }

    void updateAllocatedStocks(final String salesOrderNumber,
                               final String opCoNumber,
                               final SusSalesOrderAllocationData payload) {
        repository.save(new SusModel(salesOrderNumber, STOCK_ALLOCATION, payload.asMap(objectMapper)));

        final Optional<SusModel> susModel = repository.findByTypeAndModelId(ASOH, opCoNumber);

        if (!susModel.isPresent()) {
            return;
        }

        final SusModel model = susModel.get();
        final SusAsohData existingSusAsohData = objectMapper.convertValue(model.getData(), SusAsohData.class);
        final List<SusAllocationLineItem> susAllocationLineItems = payload.getDetail();

        susAllocationLineItems.forEach(susAllocationOrder -> {
            final String productCode = susAllocationOrder.getItemNumber();
            final Optional<SusAsohProductData> productData = existingSusAsohData.getProducts()
                    .stream()
                    .filter(susAsohProductData -> susAsohProductData.getSupc().equals(productCode))
                    .findFirst();

            productData.ifPresent(susAsohProductData -> {
                final int currentAvailableStocksOnHand = susAsohProductData.getAvailableOnHand();
                final Integer quantityToAllocated = valueOf(susAllocationOrder.getQuantityToAllocateOrConfirm());

                susAsohProductData.setAvailableOnHand(currentAvailableStocksOnHand - quantityToAllocated);
            });
        });

        existingSusAsohData.setRequestDate(LocalDate.now());

        repository.save(new SusModel(model.getModelId(), ASOH, existingSusAsohData.asMap(objectMapper)));
    }

    String createPurchaseOrder(final SusCreatePurchaseOrderData payload, final String roomCode) {
        final int requestNumber = DummySusService.requestNumber.incrementAndGet();
        final String poNumber = generatePoNumber(payload, roomCode);
        final SusPurchaseOrderResponse response = fromSusPurchaseOrderData(payload,
                poNumber, String.valueOf(requestNumber));
        repository.save(new SusModel(String.valueOf(requestNumber), PURCHASE_ORDER, response.asMap(objectMapper)));

        return String.valueOf(requestNumber);
    }

    void confirmPurchaseOrders() {
        final List<SusModel> purchaseOrders = repository.findAllByTypeIs(PURCHASE_ORDER);
        purchaseOrders.forEach(this::processPurchaseOrder);
    }

    void confirmPurchaseOrder(final String requestNumber) {
        final Optional<SusModel> purchaseOrderResponse = repository.findByTypeAndModelId(PURCHASE_ORDER, requestNumber);
        purchaseOrderResponse.ifPresent(this::processPurchaseOrder);
    }

    private void processPurchaseOrder(final SusModel susModel) {
        final SusPurchaseOrderResponse response = objectMapper.convertValue(susModel.getData(),
                SusPurchaseOrderResponse.class);
        purchaseOrderProcessor.run(response);
    }

    void updatePurchaseOrder(final String poNumber, final SusUpdatePurchaseOrderData payload) {
        repository.findByTypeAndModelId(PURCHASE_ORDER, poNumber)
                .ifPresent(order -> {
                    final SusCreatePurchaseOrderData savedPurchaseOrder =
                            objectMapper.convertValue(order.getData(), SusCreatePurchaseOrderData.class);

                    final List<SusPurchaseLineItemData> newItems = payload.getDetail();
                    final List<SusPurchaseLineItemData> existItems = savedPurchaseOrder.getDetail();
                    updatePurchaseItems(existItems, newItems);

                    final SusPurchaseOrderResponse response = fromSusPurchaseOrderData(savedPurchaseOrder,
                            poNumber, order.getModelId());
                    repository.save(new SusModel(order.getModelId(), PURCHASE_ORDER, response.asMap(objectMapper)));
                });
    }

    long createPurchaseOrderReceipt(final String opCoNumber, final String poNumber,
                                    final SusPurchaseOrderReceipt payload) {
        final String modelId = opCoNumber + poNumber + guessAtFirstCaseId(payload);

        repository.save(new SusModel(modelId, PO_RECEIPT, payload.asMap(objectMapper)));

        return nextReponseNumber.incrementAndGet();
    }

    void updateProductStatusInfo(final String opCoNumber,
                                 final String productCode,
                                 final SusUpdateProductInfoData susUpdateProductInfoData) {
        final String modelId = productCode + " - " + opCoNumber;

        repository.save(new SusModel(modelId, PRODUCT_SYNC, susUpdateProductInfoData.asMap(objectMapper)));
    }

    SusProductData getSusProduct(final String opCoNumber, final String productCode) throws IOException {
        final String ourOpCo = profileService.get().getPlantNumber();
        if (!asList(ourOpCo, REAL_OP_CO).contains(opCoNumber)) {
            return null;
        }

        final String found = susOnlyProducts.get(productCode);

        return null == found ? null : objectMapper.readValue(found, SusProductData.class);
    }
}
