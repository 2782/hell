package com.sysco.healthcheck;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.HealthIndicator;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

@Component
@Profile("realsus")
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
@Slf4j
public class CustomerServiceHealthcheck implements HealthIndicator {
    private final CheckStatus checkStatus;

    @Override
    public Health health() {
        return checkStatus.apply("/sm/customer/1.0.0/health");
    }
}
