package com.sysco.healthcheck;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.Health.Builder;
import org.springframework.boot.actuate.health.Status;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.oauth2.client.OAuth2RestTemplate;
import org.springframework.stereotype.Component;

import java.util.function.Function;

import static org.springframework.http.HttpMethod.GET;

@Component
public class CheckStatus implements Function<String, Health> {
    private final OAuth2RestTemplate restTemplate;
    private final String uriPrefix;

    @Autowired
    public CheckStatus(
            @Qualifier("oauth2RestTemplate") final OAuth2RestTemplate restTemplate,
            @Value("${sus.service.domain}") final String uriPrefix) {
        this.restTemplate = restTemplate;
        this.uriPrefix = uriPrefix;
    }

    @Override
    public Health apply(String path) {
        String uri = String.format("%s%s", uriPrefix, path);
        final ResponseEntity<String> responseEntity = restTemplate.exchange(uri, GET, null, String.class);

        HttpStatus statusCode = responseEntity.getStatusCode();

        Status status = new Status(statusCode.toString(), statusCode.getReasonPhrase());
        Builder healthBuilder = Health.status(status);

        return statusCode.isError() ? healthBuilder.down().build() : healthBuilder.build();
    }
}
