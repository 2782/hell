package com.sysco.prime.exception;

import com.sysco.prime.validation.ValidationError;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class InvalidValueException extends RuntimeException {
    private ValidationError error;

    public InvalidValueException(final String message, final ValidationError error) {
        super(message);
        this.error = error;
    }

    public InvalidValueException(final String message) {
        super(message);
    }
}
