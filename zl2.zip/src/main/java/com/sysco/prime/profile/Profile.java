package com.sysco.prime.profile;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.sysco.prime.shared.model.TransactionalEntity;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import javax.persistence.Entity;

@AllArgsConstructor
@Builder
@Data
@Entity
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
public class Profile extends TransactionalEntity {
    private String plantNumber;
    private String name;
    private String address;
    private String city;
    private String zipCode;
    private String establishmentNumber;
    private String state;
    private int vendorShipFrom;
    private int sequenceNumber;

    @JsonIgnore
    public String getAsVendorNumber() {
        return String.valueOf(vendorShipFrom);
    }

    @JsonIgnore
    public String getAsPrimeUser() {
        // TODO: Reconcile with SusSerializeable#susUserIdFor(String)
        return "Prime-" + plantNumber;
    }

    @JsonIgnore
    public boolean isPlantNumberMatch(final String opCoNumber) {
        return plantNumber.equals(opCoNumber);
    }
}
