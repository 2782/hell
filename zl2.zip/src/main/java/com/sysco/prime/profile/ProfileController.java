package com.sysco.prime.profile;

import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;

import static org.springframework.http.HttpStatus.CREATED;
import static org.springframework.http.HttpStatus.OK;

// See https://github.com/spring-projects/spring-boot/issues/1718#issuecomment-59329942 why the bean
// is renamed.
@RestController("opcoProfileController")
@RequestMapping("/api/profile")
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
@Secured({"ROLE_ADMIN"})
public class ProfileController {
    private final ProfileService profileService;

    @PostMapping
    @ResponseStatus(CREATED)
    public void create(@RequestBody @Valid final ProfileRequest profileRequest) {
        profileService.createOrUpdate(profileRequest.toProfile());
    }

    @GetMapping
    @ResponseStatus(OK)
    public Profile get() {
        return profileService.get();
    }
}
