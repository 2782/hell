package com.sysco.prime.fiscalCalendar;

import com.sysco.prime.PrimeRepository;

import java.time.LocalDate;
import java.util.Optional;

public interface FiscalCalendarRepository extends PrimeRepository<FiscalCalendar> {
    Optional<FiscalCalendar> findByActiveIsTrue();

    Optional<FiscalCalendar> findByStartDateLessThanEqualAndNextStartDateAfter(LocalDate date, LocalDate sameDate);
}
