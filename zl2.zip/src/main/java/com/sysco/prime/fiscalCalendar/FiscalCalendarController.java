package com.sysco.prime.fiscalCalendar;

import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

import static java.util.stream.Collectors.toList;

@RestController
@RequestMapping("/api/fiscal-calendar")
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class FiscalCalendarController {
    private final FiscalCalendarService fiscalCalendarService;

    @GetMapping
    @ApiOperation("get all fiscal calendar")
    @Secured({"ROLE_ADMIN", "ROLE_COSTING"})
    public List<FiscalCalendarResponse> getFiscalCalendars() {
        return fiscalCalendarService.getAllFiscalCalendars().stream()
                .map(FiscalCalendarResponse::new)
                .collect(toList());
    }

    @GetMapping("/active")
    @ApiOperation("get active fiscal calendar")
    @Secured({"ROLE_ADMIN"})
    public FiscalCalendarResponse getActiveFiscalCalendar() {
        return new FiscalCalendarResponse(fiscalCalendarService.getActiveFiscalCalendar());
    }

    @PutMapping("{fiscalCalendarId}")
    @ApiOperation("update active fiscal calendar")
    @Secured({"ROLE_ADMIN"})
    public FiscalCalendarResponse updateActiveFiscalCalendar(
            @PathVariable final Long fiscalCalendarId,
            @RequestBody final FiscalCalendarRequest fiscalCalendarRequest) {
        return new FiscalCalendarResponse(
                fiscalCalendarService.updateActiveFiscalCalendar(fiscalCalendarId, fiscalCalendarRequest.toDomain()));
    }
}
