package com.sysco.prime.fiscalCalendar;

import com.sysco.prime.exception.NotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.Clock;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import static java.lang.String.format;
import static java.time.LocalDate.now;

@Service
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class FiscalCalendarService {
    private static final int WEEK_COUNT_FOR_FIRST_MONTH_OF_FISCAL_YEAR = 4;
    private static final int WEEK_COUNT_AT_END_OF_SECOND_MONTH_OF_FISCAL_YEAR = 8;
    private static final int WEEK_COUNT_FOR_A_QUARTER = 13;
    private static final int DAYS_IN_A_WEEK = 7;

    private final FiscalCalendarRepository fiscalCalendarRepository;
    private final Clock when;

    FiscalCalendar getActiveFiscalCalendar() {
        final Optional<FiscalCalendar> optionalActiveFiscalCalendar = fiscalCalendarRepository.findByActiveIsTrue();
        if (!optionalActiveFiscalCalendar.isPresent()) {
            throw new NotFoundException("[getActiveFiscalCalendar] active FiscalCalendar Not Found");
        }
        return handleStartDateRollover(optionalActiveFiscalCalendar.get());
    }

    private FiscalCalendar handleStartDateRollover(final FiscalCalendar fiscalCalendar) {
        if (fiscalCalendar.getNextStartDate() == null) {
            return fiscalCalendar;
        }

        final LocalDate today = now(when);
        if (today.compareTo(fiscalCalendar.getStartDate()) >= 0
                && today.compareTo(fiscalCalendar.getNextStartDate()) <= 0) {
            return fiscalCalendar;
        }

        final FiscalCalendar newFiscalCalendar = FiscalCalendar.builder()
                .startDate(fiscalCalendar.getNextStartDate())
                .active(true)
                .build();

        fiscalCalendar.setActive(false);
        fiscalCalendarRepository.save(fiscalCalendar);
        fiscalCalendarRepository.save(newFiscalCalendar);

        return newFiscalCalendar;
    }

    FiscalCalendar updateActiveFiscalCalendar(final Long fiscalCalendarId, final FiscalCalendar fiscalCalendar) {
        final FiscalCalendar fiscalCalendarExist = fiscalCalendarRepository.getOneOrNull(fiscalCalendarId);
        if (fiscalCalendarExist == null) {
            throw new NotFoundException(format("[updateActiveFiscalCalendar] FiscalCalendar with Id %s Not Found",
                    fiscalCalendarId));
        }
        fiscalCalendarExist.update(fiscalCalendar);
        fiscalCalendarRepository.save(fiscalCalendarExist);
        return fiscalCalendarExist;
    }

    public String getFiscalWeekFor(final OffsetDateTime reportDate) {
        final FiscalCalendar fiscalCalendar = getFiscalCalendarFor(reportDate);

        return fiscalCalendar.getFiscalWeekWithYear(reportDate);
    }

    private FiscalCalendar getFiscalCalendarFor(final OffsetDateTime reportDate) {
        FiscalCalendar fiscalCalendar = getActiveFiscalCalendar();
        if (!fiscalCalendar.checkReportDateIsInCurrentFiscalCalendar(reportDate)) {
            final LocalDate date = reportDate.toLocalDate();
            fiscalCalendar = fiscalCalendarRepository.findByStartDateLessThanEqualAndNextStartDateAfter(date, date)
                    .orElseThrow(() -> new NotFoundException("[Week Recap Report] Fiscal Year Not Found"));
        }

        return fiscalCalendar;
    }

    public Map<Integer, LocalDate> getFiscalWeeksForReportDateMonth(final OffsetDateTime reportDate) {
        final FiscalCalendar fiscalCalendar = getFiscalCalendarFor(reportDate);

        return fiscalCalendar.getFiscalWeeksForReportDateMonth(reportDate);
    }

    public Map<String, LocalDate> getFiscalMonthFor(final OffsetDateTime reportDate) {
        final FiscalCalendar fiscalCalendar = getFiscalCalendarFor(reportDate);

        return fiscalCalendar.getFiscalMonthFor(reportDate);
    }

    public List<FiscalCalendar> getAllFiscalCalendars() {
        return fiscalCalendarRepository.findAll();
    }
}
