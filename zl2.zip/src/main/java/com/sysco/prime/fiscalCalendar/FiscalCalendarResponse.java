package com.sysco.prime.fiscalCalendar;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

import java.time.LocalDate;

@Data
@AllArgsConstructor
@Builder(toBuilder = true)
class FiscalCalendarResponse {
    private Long id;
    private LocalDate startDate;
    private LocalDate nextStartDate;
    private boolean active;

    FiscalCalendarResponse(final FiscalCalendar fiscalCalendar) {
        if (fiscalCalendar != null) {
            id = fiscalCalendar.getId();
            startDate = fiscalCalendar.getStartDate();
            nextStartDate = fiscalCalendar.getNextStartDate();
            active = fiscalCalendar.isActive();
        }
    }
}
