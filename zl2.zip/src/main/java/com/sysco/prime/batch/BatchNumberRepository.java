package com.sysco.prime.batch;

import com.sysco.prime.PrimeRepository;
import com.sysco.prime.portionRoom.PortionRoom;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface BatchNumberRepository extends PrimeRepository<BatchNumber> {
    /**
     * Uses a Postgres SQL function to <em>atomically</em> increment the batch number counter.  This preserves the ACID
     * nature, and prevents mutliple writers, or reading during update.
     *
     * @see <a href="https://stackoverflow.com/questions/46593463/postgres-dynamically-create-sequences">
     * <cite>Postgres Dynamically Create Sequences</cite></a>
     */
    @Query(nativeQuery = true, value = "SELECT next_batch_number(:#{#room.id})")
    int nextBatchNumber(@Param("room") PortionRoom room);
}
