package com.sysco.prime.batch.request;

import com.sysco.prime.batch.Batch;
import com.sysco.prime.batch.BatchFinishedProduct;
import com.sysco.prime.batch.BatchIngredient;
import com.sysco.prime.batch.BatchSourceMeat;
import com.sysco.prime.portionRoom.PortionRoomService;
import com.sysco.prime.product.ProductService;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.Valid;
import javax.validation.constraints.AssertTrue;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

import static java.util.stream.Collectors.toList;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class FinishMarinationBatchRequest implements Serializable {
    private Long id;
    private int batchNumber;
    @NotNull
    private LocalDate productionDate;
    @NotNull
    private String tumbler;
    @NotNull
    private LocalTime tumblerStartTime;
    @NotNull
    private LocalTime tumblerStopTime;
    @NotNull
    private Double startBatchTemp;
    @NotNull
    private Double finishedBatchTemp;

    @NotNull
    private String portionRoomCode;

    private boolean allergens;
    @NotNull
    @AssertTrue
    private boolean finished;
    @NotNull
    @Valid
    @Size(min = 1)
    private List<FinishBatchSourceMeatRequest> sourceMeats;
    @NotNull
    @Valid
    @Size(min = 1)
    private List<BatchIngredientRequest> ingredients;
    @Valid
    @Size(min = 1)
    private List<BatchFinishedProductRequest> finishedProducts;

    public Batch toDomain(final ProductService productService, final PortionRoomService portionRoomService) {
        final Batch batch = Batch.builder()
                .batchNumber(batchNumber)
                .blend(null)
                .grindSize(null)
                .productionDate(productionDate)
                .tumbler(tumbler)
                .tumblerStartTime(tumblerStartTime)
                .tumblerStopTime(tumblerStopTime)
                .startBatchTemp(startBatchTemp)
                .finishedBatchTemp(finishedBatchTemp)
                .finished(finished)
                .allergens(allergens)
                .portionRoom(portionRoomService.getPortionRoomByCode(portionRoomCode))
                .build()
                .addSourceMeats(toSourceMeats(productService))
                .addFinishedProducts(toFinishedProducts(productService))
                .addIngredients(toIngredients(productService));

        batch.getSourceMeats().forEach(sourceMeat -> sourceMeat.setBatch(batch));
        batch.getIngredients().forEach(ingredient -> ingredient.setBatch(batch));
        batch.getFinishedProducts().forEach(finishedProduct -> finishedProduct.setBatch(batch));
        batch.setId(id);
        return batch;
    }

    private List<BatchSourceMeat> toSourceMeats(final ProductService productService) {
        return sourceMeats.stream()
                .map(sourceMeat -> sourceMeat.toDomain(productService))
                .collect(toList());
    }

    private List<BatchIngredient> toIngredients(final ProductService productService) {
        return ingredients.stream()
                .map(ingredient -> ingredient.toDomain(productService))
                .collect(toList());
    }

    List<BatchFinishedProduct> toFinishedProducts(final ProductService productService) {
        return null == finishedProducts ? new ArrayList<>() : finishedProducts.stream()
                .map(finishedProductCode -> finishedProductCode.toDomain(productService))
                .collect(toList());
    }
}
