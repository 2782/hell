package com.sysco.prime.batch;

import com.sysco.prime.Reportable;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import static java.util.Collections.unmodifiableList;

@AllArgsConstructor
@Data
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
@ToString
public class PublishingBatch implements Reportable {
    private int batchNumber;
    private String blendName;
    private LocalDate productionDate;
    private String portionRoomCode;
    private OffsetDateTime workingDay;

    private Set<PublishingBatchSourceMeat> sourceMeats = new LinkedHashSet<>();
    private Set<PublishingBatchIngredient> ingredients = new LinkedHashSet<>();
    private Set<PublishingBatchFinishedProduct> finishedProducts = new LinkedHashSet<>();

    @Builder
    public PublishingBatch(
            final int batchNumber,
            final String blendName,
            final LocalDate productionDate,
            final String portionRoomCode,
            final OffsetDateTime workingDay) {
        this.batchNumber = batchNumber;
        this.blendName = blendName;
        this.productionDate = productionDate;
        this.portionRoomCode = portionRoomCode;
        this.workingDay = workingDay;
    }

    public List<PublishingBatchSourceMeat> getSourceMeats() {
        return unmodifiableList(new ArrayList<>(sourceMeats));
    }

    public List<PublishingBatchIngredient> getIngredients() {
        return unmodifiableList(new ArrayList<>(ingredients));
    }

    public List<PublishingBatchFinishedProduct> getFinishedProducts() {
        return unmodifiableList(new ArrayList<>(finishedProducts));
    }

    public PublishingBatch add(final PublishingBatchSourceMeat sourceMeat) {
        sourceMeats.add(sourceMeat);
        return this;
    }

    public PublishingBatch add(final PublishingBatchIngredient ingredient) {
        ingredients.add(ingredient);
        return this;
    }

    public PublishingBatch add(final PublishingBatchFinishedProduct finishedProduct) {
        finishedProducts.add(finishedProduct);
        return this;
    }

    PublishingBatch addSourceMeats(final Iterable<PublishingBatchSourceMeat> sourceMeats) {
        sourceMeats.forEach(this::add);
        return this;
    }

    public PublishingBatch addIngredients(final Iterable<PublishingBatchIngredient> ingredients) {
        ingredients.forEach(this::add);
        return this;
    }

    public PublishingBatch addFinishedProducts(final Iterable<PublishingBatchFinishedProduct> finishedProducts) {
        finishedProducts.forEach(this::add);
        return this;
    }
}
