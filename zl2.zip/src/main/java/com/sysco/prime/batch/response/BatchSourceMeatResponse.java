package com.sysco.prime.batch.response;

import com.sysco.prime.batch.BatchSourceMeat;
import lombok.Data;

import java.time.LocalDate;

@Data
class BatchSourceMeatResponse {
    private final Long id;
    private final String sourceProductCode;
    private final LocalDate harvestDate;
    private final String establishmentNumber;
    private final String lotNumber;
    private final String vendor;
    private final String poNumber;
    private final Double meatTemp;
    private final Double actualLbs;

    BatchSourceMeatResponse(final BatchSourceMeat sourceMeat) {
        id = sourceMeat.getId();
        actualLbs = sourceMeat.getActualLbs();
        establishmentNumber = sourceMeat.getEstablishmentNumber();
        harvestDate = sourceMeat.getHarvestDate();
        lotNumber = sourceMeat.getLotNumber();
        meatTemp = sourceMeat.getMeatTemp();
        poNumber = sourceMeat.getPoNumber();
        sourceProductCode = sourceMeat.getSourceProductCode();
        vendor = sourceMeat.getVendor();
    }
}
