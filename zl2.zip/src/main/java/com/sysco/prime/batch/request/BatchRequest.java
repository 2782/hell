package com.sysco.prime.batch.request;

import com.sysco.prime.batch.Batch;
import com.sysco.prime.batch.BatchFinishedProduct;
import com.sysco.prime.batch.BatchIngredient;
import com.sysco.prime.batch.BatchSourceMeat;
import com.sysco.prime.portionRoom.PortionRoomService;
import com.sysco.prime.product.GrindSize;
import com.sysco.prime.product.ProductService;
import com.sysco.prime.productionOrder.Blend;
import com.sysco.prime.productionOrder.BlendRepository;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

import static java.util.stream.Collectors.toList;

@AllArgsConstructor
@Builder(toBuilder = true)
@Data
public class BatchRequest {
    @NotNull
    private final int batchNumber;
    private final String blendName;
    @NotNull
    private final LocalDate productionDate;
    private final String tumbler;
    private final LocalTime tumblerStartTime;
    private final LocalTime tumblerStopTime;
    private final Double startBatchTemp;
    private final Double finishedBatchTemp;
    private final boolean allergens;
    private final boolean finished;
    private final GrindSize grindSize;
    @NotNull
    private final String portionRoomCode;
    @Valid
    private final List<BatchSourceMeatRequest> sourceMeats;
    @Valid
    private final List<BatchIngredientRequest> ingredients;
    @Valid
    private final List<BatchFinishedProductRequest> finishedProducts;

    public Batch toDomain(final ProductService productService,
                          final PortionRoomService portionRoomService,
                          final BlendRepository blendRepository) {
        final Batch batch = Batch.builder()
                .batchNumber(batchNumber)
                .blend(null != blendName ? Blend.fromString(blendName, blendRepository) : null)
                .productionDate(productionDate)
                .tumbler(tumbler)
                .tumblerStartTime(tumblerStartTime)
                .tumblerStopTime(tumblerStopTime)
                .startBatchTemp(startBatchTemp)
                .finishedBatchTemp(finishedBatchTemp)
                .allergens(allergens)
                .finished(finished)
                .grindSize(grindSize)
                .portionRoom(portionRoomService.getPortionRoomByCode(portionRoomCode))
                .build()
                .addSourceMeats(toSourceMeats(productService))
                .addIngredients(toIngredients(productService))
                .addFinishedProducts(toFinishedProducts(productService));
        return batch;
    }

    private List<BatchSourceMeat> toSourceMeats(final ProductService productService) {
        return null == sourceMeats ? new ArrayList<>() : sourceMeats.stream()
                .map(sourceMeat -> sourceMeat.toDomain(productService))
                .collect(toList());
    }

    private List<BatchIngredient> toIngredients(final ProductService productService) {
        return null == ingredients ? new ArrayList<>() : ingredients.stream()
                .map(ingredient -> ingredient.toDomain(productService))
                .collect(toList());
    }

    private List<BatchFinishedProduct> toFinishedProducts(final ProductService productService) {
        return null == finishedProducts ? new ArrayList<>() : finishedProducts.stream()
                .map(finishedProductCode -> finishedProductCode.toDomain(productService))
                .collect(toList());
    }
}
