package com.sysco.prime.batch.request;

import com.sysco.prime.batch.BatchSourceMeat;
import com.sysco.prime.product.ProductService;
import com.sysco.prime.product.validation.ValidProduct;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class FinishBatchSourceMeatRequest implements Serializable {
    private Long id;
    @ValidProduct
    private String sourceProductCode;
    @NotNull
    private LocalDate harvestDate;
    @NotNull
    private String establishmentNumber;
    @NotNull
    private String lotNumber;
    @NotNull
    private String poNumber;
    @NotNull
    private Double meatTemp;
    @NotNull
    private Double actualLbs;
    @NotNull
    private String vendor;

    public BatchSourceMeat toDomain(final ProductService productService) {
        final BatchSourceMeat sourceMeat = BatchSourceMeat.builder()
                .sourceProduct(productService.findByCode(sourceProductCode))
                .harvestDate(harvestDate)
                .establishmentNumber(establishmentNumber)
                .lotNumber(lotNumber)
                .vendor(vendor)
                .poNumber(poNumber)
                .meatTemp(meatTemp)
                .actualLbs(actualLbs)
                .build();

        if (id != null) {
            sourceMeat.setId(id);
        }

        return sourceMeat;
    }
}
