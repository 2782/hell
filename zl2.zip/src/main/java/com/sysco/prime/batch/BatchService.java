package com.sysco.prime.batch;

import com.sysco.prime.portionRoom.PortionRoom;
import com.sysco.prime.portionRoom.PortionRoomService;
import com.sysco.prime.product.Product;
import com.sysco.prime.product.ProductService;
import com.sysco.prime.productionOrder.Blend;
import com.sysco.prime.productionOrder.BlendRepository;
import com.sysco.prime.reporting.ReportingPublisher;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

import javax.swing.text.html.Option;
import javax.transaction.Transactional;
import java.time.Clock;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.util.List;

import static com.sysco.prime.productionOrder.Blend.existBlendName;
import static java.util.Objects.isNull;
import static java.util.stream.Collectors.toList;

@Service
public class BatchService {
    private final BatchRepository batchRepository;
    private final BatchValidator batchValidator;
    private final ReportingPublisher reportingPublisher;
    private final BlendRepository blendRepository;
    private final PortionRoomService portionRoomService;
    private final Clock when;

    public BatchService(
            final BatchRepository batchRepository,
            final BatchValidator batchValidator,
            final ReportingPublisher reportingPublisher,
            final BlendRepository blendRepository,
            @Lazy final PortionRoomService portionRoomService,
            final Clock when) {
        this.batchRepository = batchRepository;
        this.batchValidator = batchValidator;
        this.reportingPublisher = reportingPublisher;
        this.blendRepository = blendRepository;
        this.portionRoomService = portionRoomService;
        this.when = when;
    }

    @Transactional
    public Batch create(final Batch batch) {
        assignBatchNumber(batch);
        batchValidator.validate(batch);
        return batchRepository.save(batch);
    }

    private void assignBatchNumber(final Batch batch) {
        batch.setBatchNumber(portionRoomService.nextBatchNumber(batch.getPortionRoom()));
    }

    @Transactional
    public Batch update(final Batch batch) {
        final Batch existingBatch = batchRepository.getOneOrNull(batch.getId());
        if (existingBatch.isFinished()) {
            throw new IllegalStateException("Cannot update a finished batch");
        }

        batch.setCreatedAt(existingBatch.getCreatedAt());
        batch.setUpdatedAt(LocalDateTime.now(when));

        batchValidator.validate(batch);
        batchRepository.delete(existingBatch);
        return batchRepository.save(batch);
    }

    @Transactional
    public Batch finish(final Batch batch) {
        final Batch finishedBatch;

        if (isNull(batch.getId())) {
            finishedBatch = create(batch);
        } else {
            finishedBatch = update(batch);
        }

        final PublishingBatch publishingBatch = finishedBatch.toReporting(
                finishedBatch.getPortionRoomCode(), getPortionRoomLastOpenedAt(finishedBatch.getPortionRoom()));
        reportingPublisher.reportOn(publishingBatch);
        return finishedBatch;
    }

    OffsetDateTime getPortionRoomLastOpenedAt(final PortionRoom portionRoom) {
        OffsetDateTime lastOpenedAt = portionRoom.getLastOpenedAt();
        if (lastOpenedAt == null) {
            lastOpenedAt = OffsetDateTime.now(when);
        }
        return lastOpenedAt;
    }

    List<Batch> getByBlendNames(final List<String> blendNames, final LocalDate produceDate) {
        return batchRepository.findByBlendNameInAndProductionDate(blendNames, produceDate);
    }

    // TODO: Avoid optionls as parameters
    List<Batch> findAllBatches(
            final LocalDate startProductionDate,
            final LocalDate endProductionDate,
            final String sourcePurchaseNumber,
            final String finishedOrBlendName,
            final String sourceNumber) {
        String blendName = null;
        String finishedProductNumber = null;
        String sourceProductNumber = null;

        if (sourceNumber != null) {
            sourceProductNumber = ProductService.formatProductCode(sourceNumber);
        }

        if (finishedOrBlendName != null) {
            if (existBlendName(finishedOrBlendName, blendRepository)) {
                blendName = Blend.fromString(finishedOrBlendName, blendRepository).getName();
            } else {
                finishedProductNumber = ProductService.formatProductCode(finishedOrBlendName);
            }
        }
        return batchRepository.findAll(startProductionDate,
                endProductionDate,
                sourcePurchaseNumber,
                blendName,
                finishedProductNumber,
                sourceProductNumber);
    }

    public List<Batch> findUnfinishableBatches(final String roomCode) {
        final PortionRoom matchingRoom = portionRoomService.getPortionRoomByCode(roomCode);
        final List<Batch> unFinishedBatches =
                batchRepository.findByPortionRoomCodeAndProductionDateAndFinishedIsFalse(roomCode,
                        matchingRoom.getLastOpenedAt().toLocalDate());

        return unFinishedBatches.stream().filter(Batch::couldNotBeFinished).collect(toList());
    }

    public void finishBatch(final PortionRoom portionRoom) {
        final List<Batch> unFinishedBatches =
                batchRepository.findByPortionRoomCodeAndProductionDateAndFinishedIsFalse(portionRoom.getCode(),
                        portionRoom.getLastOpenedAt().toLocalDate());

        unFinishedBatches.forEach(batch -> {
            if (batch.couldNotBeFinished()) {
                throw new BatchUnfinishableException(
                        String.format("[unfinishable batch]: batch is unfinishable, id: %s", batch.getId()));
            }
            batch.changeToFinished();
            reportingPublisher.reportOn(batch.toReporting(portionRoom.getCode(), portionRoom.getLastOpenedAt()));
            batchRepository.save(batch);
        });
    }
}
