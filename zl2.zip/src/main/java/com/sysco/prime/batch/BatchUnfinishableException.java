package com.sysco.prime.batch;

public class BatchUnfinishableException extends RuntimeException {
    public BatchUnfinishableException(final String message) {
        super(message);
    }
}
