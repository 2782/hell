package com.sysco.prime.batch.response;

import com.sysco.prime.batch.Batch;
import com.sysco.prime.product.GrindSize;
import com.sysco.prime.productionOrder.response.BlendResponse;
import lombok.Data;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

import static java.util.stream.Collectors.toList;

@Data
public class BatchResponse {
    private final Long id;
    private final int batchNumber;
    private final LocalDate productionDate;
    private final String tumbler;
    private final LocalTime tumblerStartTime;
    private final LocalTime tumblerStopTime;
    private final Double startBatchTemp;
    private final Double finishedBatchTemp;
    private final boolean allergens;
    private final boolean finished;
    private final GrindSize grindSize;
    private final String portionRoomCode;
    private final String portionRoomType;
    private final List<BatchSourceMeatResponse> sourceMeats;
    private final List<BatchIngredientResponse> ingredients;
    private final List<BatchFinishedProductResponse> finishedProducts;
    private BlendResponse blend;

    public BatchResponse(final Batch batch) {
        id = batch.getId();
        batchNumber = batch.getBatchNumber();
        productionDate = batch.getProductionDate();
        tumbler = batch.getTumbler();
        tumblerStartTime = batch.getTumblerStartTime();
        tumblerStopTime = batch.getTumblerStopTime();
        startBatchTemp = batch.getStartBatchTemp();
        finishedBatchTemp = batch.getFinishedBatchTemp();
        allergens = batch.isAllergens();
        finished = batch.isFinished();
        grindSize = batch.getGrindSize();
        portionRoomCode = batch.getPortionRoom().getCode();
        portionRoomType = batch.getPortionRoom().getRoomType().toString();
        sourceMeats = batch.getSourceMeats().stream()
                .map(BatchSourceMeatResponse::new)
                .collect(toList());
        finishedProducts = batch.getFinishedProducts().stream()
                .map(BatchFinishedProductResponse::new)
                .collect(toList());
        ingredients = batch.getIngredients().stream()
                .map(BatchIngredientResponse::new)
                .collect(toList());

        if (batch.getBlend() != null) {
            blend = new BlendResponse(batch.getBlend());
        }
    }
}
