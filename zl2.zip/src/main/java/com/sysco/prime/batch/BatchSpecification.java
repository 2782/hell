package com.sysco.prime.batch;

import lombok.NoArgsConstructor;
import org.springframework.data.jpa.domain.Specification;

import javax.persistence.criteria.JoinType;
import java.time.LocalDate;
import java.util.Optional;

import static lombok.AccessLevel.PRIVATE;

@SuppressWarnings("OptionalUsedAsFieldOrParameterType")
@NoArgsConstructor(access = PRIVATE)
final class BatchSpecification {
    private static Specification<Batch> areGreaterThanAndEqualTo(
            final String attribute,
            final LocalDate object) {
        final Optional<LocalDate> optional = Optional.ofNullable(object);
        return optional.<Specification<Batch>>map(o -> (root, query, cb) -> cb.greaterThanOrEqualTo(
                root.<LocalDate>get(attribute), o))
                .orElse(null);
    }

    private static Specification<Batch> areLessThanAndEqualTo(
            final String attribute,
            final LocalDate object) {
        final Optional<LocalDate> optional = Optional.ofNullable(object);
        return optional.<Specification<Batch>>map(o -> (root, query, cb) -> cb.lessThanOrEqualTo(
                root.<LocalDate>get(attribute), o))
                .orElse(null);
    }

    private static Specification<Batch> hasSourcePoNumber(
            final String object) {
        final Optional<String> optional = Optional.ofNullable(object);
        return optional.<Specification<Batch>>map(o -> (root, query, cb) -> cb.equal(
                root.join("sourceMeats").get("poNumber"), o))
                .orElse(null);
    }

    private static Specification<Batch> hasSourceProduct(
            final String object) {
        final Optional<String> optional = Optional.ofNullable(object);
        return optional.<Specification<Batch>>map(o -> (root, query, cb) -> cb.equal(
                root.join("sourceMeats").join("sourceProduct").get("code"), o))
                .orElse(null);
    }

    private static Specification<Batch> hasFinishedProduct(
            final String object) {
        final Optional<String> optional = Optional.ofNullable(object);
        return optional.<Specification<Batch>>map(o -> (root, query, cb) -> cb.equal(
                root.join("finishedProducts").join("finishedProduct").get("code"), o))
                .orElse(null);
    }

    static Specification<Batch> extendQuery(
            final LocalDate startProductionDate,
            final LocalDate endProductionDate,
            final String sourcePurchaseNumber,
            final String finishedNumber,
            final String sourceNumber) {
        return Specification
                .where(areGreaterThanAndEqualTo("productionDate", startProductionDate))
                .and(areLessThanAndEqualTo("productionDate", endProductionDate))
                .and(hasSourcePoNumber(sourcePurchaseNumber))
                .and(hasFinishedProduct(finishedNumber))
                .and(hasSourceProduct(sourceNumber));
    }
}
