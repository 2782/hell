package com.sysco.prime.batch;

import java.time.LocalDate;
import java.util.List;

public interface BatchRepositoryCustom {
    List<Batch> findAll(
            LocalDate startProductionDate,
            LocalDate endProductionDate,
            String sourcePurchaseNumber,
            String blendName,
            String finishedNumber,
            String sourceNumber
    );
}
