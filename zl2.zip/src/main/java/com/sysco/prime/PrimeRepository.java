package com.sysco.prime;

import com.sysco.prime.shared.model.TransactionalEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.rest.core.annotation.RestResource;

import java.util.List;

public interface PrimeRepository<T extends TransactionalEntity> extends JpaRepository<T, Long> {
    default T getOneOrNull(final Long id) {
        return findById(id).orElse(null);
    }

    // Pass-thru overrides to make Data REST interfaces read-only
    // No impact on regular JPA usage
    // See https://jira.spring.io/browse/DATAREST-1289
    // See https://docs.spring.io/spring-data/rest/docs/current/reference/html/#customizing-sdr.http-methods.default-exposure

    @Override
    @RestResource(exported = false)
    <S extends T> List<S> saveAll(Iterable<S> entities);

    @Override
    @RestResource(exported = false)
    void flush();

    @Override
    @RestResource(exported = false)
    <S extends T> S saveAndFlush(S entity);

    @Override
    @RestResource(exported = false)
    void deleteInBatch(Iterable<T> entities);

    @Override
    @RestResource(exported = false)
    void deleteAllInBatch();

    @Override
    @RestResource(exported = false)
    <S extends T> S save(S entity);

    @Override
    @RestResource(exported = false)
    void deleteById(Long id);

    @Override
    @RestResource(exported = false)
    void delete(T entity);

    @Override
    @RestResource(exported = false)
    void deleteAll(Iterable<? extends T> entities);

    @Override
    @RestResource(exported = false)
    void deleteAll();
}
