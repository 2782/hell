package com.sysco.prime.customerOrder;

import com.fasterxml.jackson.annotation.JsonCreator;

import java.util.Comparator;

public enum TimedWillCallRoutes {
    // IMMEDIATE < C08 < C09 < C10 < C11 < C12 < C01 < C02 < C03 < C04 < NO_PRIORITY
    IMMEDIATE(1), C08(2), C09(3), C10(4), C11(5), C12(6), C01(7), C02(8), C03(9), C04(10), NO_PRIORITY(11);

    private final int value;

    TimedWillCallRoutes(final int value) {
        this.value = value;
    }

    @JsonCreator
    public static TimedWillCallRoutes from(final String value) {
        try {
            if (value.startsWith("I") || value.startsWith("i")) {
                return IMMEDIATE;
            }
            return TimedWillCallRoutes.valueOf(value);
        } catch (final Exception e) {
            return NO_PRIORITY;
        }
    }

    public static final Comparator<TimedWillCallRoutes> timedWillCallComparator = Comparator.nullsLast(
            Comparator.comparingInt(p -> p.value));
}
