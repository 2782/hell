package com.sysco.prime.customerOrder;

import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import java.util.List;
import java.util.Map;

import static org.springframework.http.HttpStatus.CREATED;

@RestController
@RequestMapping("/api/line-items")
@Slf4j
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
@Secured({"ROLE_ADMIN", "ROLE_PORTION_ROOM_MEMBER"})
public class LineItemController {
    private final LineItemService lineItemService;

    @GetMapping("/future-items")
    @ApiOperation(value = "get line items",
            notes = "get line items resource(same as the model in database)")
    public List<PrimeLineItem> getLineItems(
            @RequestParam("room-code") final String roomCode) {
        return lineItemService.futureItems(roomCode);
    }

    @PostMapping("/future-items/schedule")
    @ApiOperation("post future items to schedule")
    @ResponseStatus(CREATED)
    public void scheduleFutureItems(@Valid @RequestBody final Map<Long, Integer> scheduleLineItemMap) {
        lineItemService.schedule(scheduleLineItemMap);
    }
}
