package com.sysco.prime.customerOrder;

import com.sysco.prime.PrimeRepository;
import com.sysco.prime.product.ProductOutput;

import java.time.LocalDate;
import java.util.List;

public interface LineItemRepository extends PrimeRepository<LineItem> {
    // CHECKSTYLE: OFF
    // WARNING - Be careful with indentation and line breaks, or checkstyle gets sad
    List<LineItem> findByCustomerOrderShipDateBetweenAndProductTableStationRoomCodeAndProductProductOutputInAndDeletedIsFalseAndCustomerOrderCancelledIsFalseAndCustomerOrderOnHoldIsFalse(
            LocalDate startingDate, LocalDate endingDate, String roomCode, List<ProductOutput> productOutputs);

    List<LineItem> findByIdIn(List<Long> ids);

    List<LineItem> findByCustomerOrderShipDateAfterAndProductTableStationRoomCodeAndProductProductOutputInAndDeletedIsFalseAndCustomerOrderCancelledIsFalseAndCustomerOrderImmediateOrderIsTrue(
            LocalDate endDate, String roomCode, List<ProductOutput> productOutputs);
    // CHECKSTYLE: ON
}
