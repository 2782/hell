package com.sysco.prime.customerOrder;

import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;

@Service
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class StockAllocationService {
    private final StockAllocationRepository repository;

    StockAllocation create(final StockAllocation stockAllocation) {
        return repository.save(stockAllocation);
    }

    List<StockAllocation> findByLineItemIds(final List<Long> lineItemIds) {
        return repository.findByLineItemIdIn(lineItemIds);
    }

    public StockAllocation findByLineItemId(final Long lineItemId) {
        final List<StockAllocation> stockAllocations = findByLineItemIds(Collections.singletonList(lineItemId));

        return stockAllocations.size() > 0 ? stockAllocations.get(0) : null;
    }
}
