package com.sysco.prime.customerOrder;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sysco.prime.shared.model.TransactionalEntity;
import com.sysco.prime.sus.model.product.salesOrder.SusSalesOrderStatus;
import com.sysco.prime.sus.model.product.salesOrder.SusSalesOrderStatusHeader;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.Type;

import javax.persistence.Entity;
import javax.validation.constraints.NotNull;
import java.time.LocalDateTime;
import java.util.Map;

import static com.sysco.prime.utils.TimeUtils.SUS_TIMESTAMP;
import static java.time.LocalDateTime.parse;

@AllArgsConstructor
@Builder(toBuilder = true)
@Data
@Entity
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
public class OrderStatusSnapshot extends TransactionalEntity {

    @NotNull
    private String orderNumber;

    @Type(type = "jsonb")
    private Map<String, Object> message;

    @NotNull
    private LocalDateTime susCreatedOn;
    private LocalDateTime susModifiedOn;

    public static OrderStatusSnapshot from(SusSalesOrderStatus orderStatus, final ObjectMapper mapper) {
        final SusSalesOrderStatusHeader header = orderStatus.getHeader();

        final String modifiedOn = header.getModifiedOn();
        final boolean isModifiedOnParseable = null != modifiedOn && !modifiedOn.trim().isEmpty();

        return OrderStatusSnapshot.builder()
                .message(orderStatus.asMap(mapper))
                .orderNumber(header.getOrderNumber())
                .susCreatedOn(parse(header.getCreatedOn(), SUS_TIMESTAMP))
                .susModifiedOn(
                        isModifiedOnParseable
                                ? parse(modifiedOn, SUS_TIMESTAMP)
                                : null)
                .build();
    }

    public boolean hasBothCreatedOnAndModifiedOn() {
        return null != getSusCreatedOn() && null != getSusModifiedOn();
    }

    public boolean shouldUpdate(OrderStatusSnapshot previous) {
        if (null != previous.getSusCreatedOn() && null == previous.getSusModifiedOn()
                && hasBothCreatedOnAndModifiedOn()) {
            return true;
        }
        if (previous.hasBothCreatedOnAndModifiedOn()) {
            if (null == getSusModifiedOn()) {
                return false;
            } else if (hasBothCreatedOnAndModifiedOn()) {
                if (previous.getSusModifiedOn().isAfter(getSusModifiedOn())) {
                    return false;
                } else {
                    return true;
                }
            }
        }
        return false;
    }
}
