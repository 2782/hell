package com.sysco.prime.customerOrder;

import com.sysco.prime.PrimeRepository;

import java.util.List;

public interface LineItemOutRepository extends PrimeRepository<LineItemOut> {
    List<LineItemOut> findByLineItemIdIn(List<Long> lineItemIds);
}
