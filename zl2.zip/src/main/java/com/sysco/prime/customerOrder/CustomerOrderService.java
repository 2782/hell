package com.sysco.prime.customerOrder;

import com.sysco.prime.portionRoom.PortionRoom;
import com.sysco.prime.portionRoom.PortionRoomService;
import com.sysco.prime.productionOrder.ProductionOrderService;
import com.sysco.prime.productionOrder.ProductionOrderUpdateService;
import com.sysco.prime.profile.ProfileService;
import com.sysco.prime.systemConfig.SystemConfigService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import static com.sysco.prime.portionRoom.PortionRoomType.CUTTING;
import static com.sysco.prime.portionRoom.PortionRoomType.GRINDING;
import static java.lang.String.format;
import static java.util.stream.Collectors.toList;

@Service
@Slf4j
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class CustomerOrderService {
    private final CustomerOrderRepository customerOrderRepository;
    private final SystemConfigService systemConfigService;
    private final PortionRoomService portionRoomService;
    private final ProductionOrderService productionOrderService;
    private final ProductionOrderUpdateService productionOrderUpdateService;
    private final LineItemService lineItemService;
    private final ProfileService profileService;

    private static Map<String, PortionRoom> generateRoomCodeToPortionRoomMap(final List<PortionRoom> allPortionRooms) {
        return allPortionRooms.stream()
                .collect(Collectors.toMap(PortionRoom::getCode, portionRoom -> portionRoom));
    }

    private static boolean shouldProcessOrder(final LineItem lineItem, final PortionRoom portionRoom) {
        return (lineItem.getProduct().isFinishedProductOutput()
                || lineItem.getProduct().isByproductOnlyOutput())
                && portionRoom.isOpened()
                && !lineItem.getCustomerOrder().isOnHold()
                && CUTTING.equals(portionRoom.getRoomType());
    }

    public Optional<CustomerOrder> findCustomerOrderByOrderNumberAndShipDate(
            final String orderNumber, final LocalDate shipDate) {
        return customerOrderRepository.findByOrderNumberAndShipDate(orderNumber, shipDate);
    }

    public Optional<CustomerOrder> findCustomerOrderByOrderNumber(final String orderNumber) {
        return customerOrderRepository.findByOrderNumber(orderNumber);
    }

    @Transactional
    public void handleCustomerOrderFromSus(final CustomerOrder orderFromSus) {
        final Optional<CustomerOrder> orderOptional = customerOrderRepository.findByOrderNumber(orderFromSus
                .getOrderNumber());

        if (orderOptional.isPresent()) {
            final CustomerOrder oldOrder = orderOptional.get().copy();
            final CustomerOrder savedOrder = customerOrderRepository.save(oldOrder.update(orderFromSus));
            final CustomerOrderDiff diff = new CustomerOrderDiff(oldOrder, savedOrder);
            handleUpdateCustomerOrder(diff);
        } else {
            final CustomerOrder savedOrder = customerOrderRepository.save(orderFromSus);
            handleCreateCustomerOrder(savedOrder);
        }
    }

    void handleUpdateCustomerOrder(final CustomerOrderDiff customerOrderDiff) {
        final boolean productionOrdersExistForCustomerOrder = productionOrderService
                .areThereProductionOrdersForCustomerOrder(customerOrderDiff.getNewOrder());
        final LocalDate today = systemConfigService.getFirstWorkDay(OffsetDateTime.now());
        final LocalDate nextDay = systemConfigService.getNextWorkDay(OffsetDateTime.now());

        if (!productionOrdersExistForCustomerOrder
                && customerOrderDiff.isNowNecessaryToCreateNewProductionOrdersFor(today, nextDay)) {
            createProductionOrders(customerOrderDiff.getNewOrder());
        } else {
            customerOrderDiff.getLineItemDiff().forEach(productionOrderUpdateService::update);
        }
    }

    void handleCreateCustomerOrder(final CustomerOrder customerOrder) {
        final LocalDate today = systemConfigService.getFirstWorkDay(OffsetDateTime.now());
        final LocalDate nextDay = systemConfigService.getNextWorkDay(OffsetDateTime.now());

        if (!customerOrder.isShipDateIncludes(today, nextDay)
                && !customerOrder.isFutureImmediateAfter(nextDay)) {
            return;
        }

        createProductionOrders(customerOrder);
    }

    void createProductionOrders(CustomerOrder customerOrder) {
        final List<PortionRoom> portionRooms = portionRoomService.getAllPortionRooms();
        final Map<String, PortionRoom> roomCodeToPortionRoomMap = generateRoomCodeToPortionRoomMap(portionRooms);

        final String opCo = profileService.get().getPlantNumber();

        final List<PrimeLineItem> cuttingPrimeLineItems =
                createCuttingPrimeLineItemsToGenerateCutOrders(roomCodeToPortionRoomMap, customerOrder);
        if (!cuttingPrimeLineItems.isEmpty()) {
            final List<PrimeLineItem> lineItemsToGenerateCutOrders =
                    lineItemService.allocateStocksAndGetRemainingLineItems(
                            opCo,
                            cuttingPrimeLineItems,
                            "",
                            true);

            productionOrderService.generateOrdersFromPrimeLineItems(lineItemsToGenerateCutOrders, null);
        }

        final List<PrimeLineItem> grindingPrimeLineItems =
                createGrindingPrimeLineItemsToAllocateStock(roomCodeToPortionRoomMap, customerOrder);

        if (!grindingPrimeLineItems.isEmpty()) {
            log.info(format("[new grinding order need to allocate stock], grindingPrimeLineItems.size = %s for "
                    + "customerOrder=%s", grindingPrimeLineItems.size(), customerOrder.getOrderNumber()));
            lineItemService.allocateStocksAndGetRemainingLineItems(
                    opCo,
                    grindingPrimeLineItems,
                    "",
                    true);
        }
    }

    private List<PrimeLineItem> createGrindingPrimeLineItemsToAllocateStock(
            final Map<String, PortionRoom> roomCodeToPortionRoomMap, final CustomerOrder customerOrder) {
        return customerOrder.getLineItems().stream()
                .filter(lineItem -> isGrindingLineItems(lineItem, roomCodeToPortionRoomMap.get(lineItem.getRoomCode())))
                .filter(lineItem -> !lineItem.getCustomerOrder().isOnHold())
                .map(lineItem -> {
                    PortionRoom portionRoom = roomCodeToPortionRoomMap.get(lineItem.getRoomCode());
                    return PrimeLineItem.builder()
                            .lineItem(lineItem)
                            .quantityRemaining(lineItem.getQuantity())
                            .shouldOut(portionRoom.isOpened() && portionRoom.isApproved())
                            .build();
                })
                .collect(toList());
    }

    private boolean isGrindingLineItems(final LineItem lineItem, final PortionRoom portionRoom) {
        return lineItem.getProduct().isFinishedProductOutput()
                && GRINDING.equals(portionRoom.getRoomType());
    }

    private List<PrimeLineItem> createCuttingPrimeLineItemsToGenerateCutOrders(
            final Map<String, PortionRoom> roomCodeToPortionRoomMap,
            final CustomerOrder customerOrder) {
        return customerOrder.getLineItems().stream()
                .filter(lineItem ->
                        shouldProcessOrder(lineItem, roomCodeToPortionRoomMap.get(lineItem.getRoomCode())))
                .map(lineItem -> PrimeLineItem.builder()
                        .lineItem(lineItem)
                        .quantityRemaining(lineItem.getQuantity())
                        .build())
                .collect(toList());
    }

    public List<CustomerOrder> findRemainingOrders() {
        final LocalDate nextWorkDay = systemConfigService.getNextWorkDay(null);

        return customerOrderRepository.findByShipDateGreaterThanEqual(nextWorkDay);
    }
}
