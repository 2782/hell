package com.sysco.prime.customerOrder;

import com.sysco.prime.shared.model.TransactionalEntity;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;

import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.validation.constraints.NotNull;

import static javax.persistence.FetchType.EAGER;

@Entity
@Getter
@NoArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
@EqualsAndHashCode(callSuper = false)
class LineItemOut extends TransactionalEntity {
    @NotNull
    @OneToOne(fetch = EAGER)
    @JoinColumn(name = "lineItemId")
    private LineItem lineItem;

    @NotNull
    private int outQuantity;
}
