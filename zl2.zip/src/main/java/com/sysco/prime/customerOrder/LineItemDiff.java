package com.sysco.prime.customerOrder;

import lombok.Data;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static com.sysco.prime.unitOfMeasure.UnitOfMeasure.BOX;
import static com.sysco.prime.unitOfMeasure.UnitOfMeasure.PIECE;
import static java.util.stream.Collectors.toMap;

@Data
public class LineItemDiff {
    private final LineItem oldItem;
    private final LineItem newItem;

    static List<LineItemDiff> lineItemDiffs(final List<LineItem> oldItems, final List<LineItem> newItems) {
        final List<LineItemDiff> lineItemDiffs = new ArrayList<>();


        final Map<Integer, LineItem> newLineNumberToItem = newItems.stream()
                .collect(toMap(LineItem::getLineNumber, item -> item));
        final Map<Integer, LineItem> oldLineNumberToItem = oldItems.stream()
                .collect(toMap(LineItem::getLineNumber, item -> item));

        for (Map.Entry<Integer, LineItem> entry: newLineNumberToItem.entrySet()) {
            final Integer lineNumber = entry.getKey();
            if (oldLineNumberToItem.containsKey(lineNumber)) {
                final LineItem oldItem = oldLineNumberToItem.get(lineNumber);
                final LineItem newItem = entry.getValue();
                lineItemDiffs.add(new LineItemDiff(oldItem, newItem));
            }
            // } else {
            //      TODO: For when we handle adding new line items as part of an update (PRM-1681)
            // }
        }

        return lineItemDiffs;
    }

    public LineItemDiff(final LineItem oldItem, final LineItem newItem) {
        this.oldItem = oldItem;
        this.newItem = newItem;
    }

    public Long getId() {
        return newItem.getId();
    }

    public boolean unitOfMeasureHasChangedFromCasesToPieces() {
        return BOX.equals(oldItem.getUnitOfMeasure()) && PIECE.equals(newItem.getUnitOfMeasure());
    }
}

