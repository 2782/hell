package com.sysco.prime.customerOrder;

import com.sysco.prime.cost.CostService;
import com.sysco.prime.portionRoom.PortionRoom;
import com.sysco.prime.portionRoom.PortionRoomService;
import com.sysco.prime.product.ProductOutput;
import com.sysco.prime.productionOrder.ProductionOrder;
import com.sysco.prime.productionOrder.ProductionOrderService;
import com.sysco.prime.profile.ProfileService;
import com.sysco.prime.sus.model.stock.SusAsohData;
import com.sysco.prime.sus.model.stock.SusAsohProductData;
import com.sysco.prime.sus.service.AsohService;
import com.sysco.prime.systemConfig.SystemConfigService;
import com.sysco.prime.utils.TimeUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import static com.google.common.collect.Lists.newArrayList;
import static com.sysco.prime.portionRoom.PortionRoomType.GRINDING;
import static com.sysco.prime.productionOrder.ProductionOrderStatus.CLOSED;
import static com.sysco.prime.productionOrder.ProductionOrderStatus.PACKED;
import static com.sysco.prime.unitOfMeasure.UnitOfMeasure.PIECE;
import static com.sysco.prime.utils.TimeUtils.getStartTimeOfDay;
import static java.lang.String.format;
import static java.util.Arrays.asList;
import static java.util.Collections.singletonList;
import static java.util.Objects.isNull;
import static java.util.stream.Collectors.groupingBy;
import static java.util.stream.Collectors.toList;
import static java.util.stream.Collectors.toMap;

@Slf4j
@Service
public class LineItemService {
    public static final int FUTURE_WORK_DAYS_FOR_CUTTING_ORDERS = 5;
    static final int FUTURE_WORK_DAYS_FOR_GRINDING_ORDERS = 14;

    private final LineItemRepository lineItemRepository;
    private final PortionRoomService portionRoomService;
    private final SystemConfigService systemConfigService;
    private final ProductionOrderService productionOrderService;
    private final AsohService asohService;
    private final StockAllocationService stockAllocationService;
    private final LineItemOutService lineItemOutService;
    private final CostService costService;
    private final ProfileService profileService;

    @Autowired
    public LineItemService(
            final LineItemRepository lineItemRepository,
            @Lazy final PortionRoomService portionRoomService,
            final SystemConfigService systemConfigService,
            final ProductionOrderService productionOrderService,
            final AsohService asohService,
            final StockAllocationService stockAllocationService,
            @Lazy final LineItemOutService lineItemOutService,
            final CostService costService,
            final ProfileService profileService) {
        this.lineItemRepository = lineItemRepository;
        this.portionRoomService = portionRoomService;
        this.systemConfigService = systemConfigService;
        this.productionOrderService = productionOrderService;
        this.asohService = asohService;
        this.stockAllocationService = stockAllocationService;
        this.lineItemOutService = lineItemOutService;
        this.costService = costService;
        this.profileService = profileService;
    }

    static int calculateQuantityRemaining(
            final List<ProductionOrder> existedProductionOrders,
            final LineItem item,
            final StockAllocation stockAllocation) {
        final int qtyPackedInBox = existedProductionOrders.stream()
                .filter(getClosedCutOrderPredicate(item))
                .mapToInt(ProductionOrder::getQtyPacked)
                .sum();

        final int actualPacked = item.getUnitOfMeasure() == PIECE
                ? qtyPackedInBox * item.getProduct().getPiecesPerCase()
                : qtyPackedInBox;

        final int qtyScheduleToCut = existedProductionOrders.stream()
                .filter(getOpenedProductionOrderPredicate(item))
                .mapToInt(ProductionOrder::getQtyToProduce)
                .sum();

        final int qtyStockAllocated = getQtyStockAllocated(stockAllocation, item);

        return item.getQuantity() - actualPacked - qtyScheduleToCut - qtyStockAllocated;
    }

    private static int getQtyStockAllocated(final StockAllocation stockAllocation, final LineItem item) {
        if (stockAllocation == null) {
            return 0;
        }

        return item.getUnitOfMeasure() == PIECE
                ? stockAllocation.getAllocatedQuantity() * item.getProduct().getPiecesPerCase()
                : stockAllocation.getAllocatedQuantity();
    }

    private static Predicate<ProductionOrder> getOpenedProductionOrderPredicate(final LineItem item) {
        return productionOrder -> productionOrder.getSourceId().equals(item.getId())
                && productionOrder.getStatus() != CLOSED;
    }

    private static Predicate<ProductionOrder> getClosedCutOrderPredicate(final LineItem item) {
        return cutOrder -> cutOrder.getSourceId().equals(item.getId()) && cutOrder.getStatus() == CLOSED;
    }

    private static boolean isLineItemPackedComplete(
            final Map<Long, StockAllocation> lineItemStockAllocations,
            final Map<Long, List<ProductionOrder>> cutOrdersGroupByItemNumber,
            final LineItem item) {
        final StockAllocation stockAllocation = lineItemStockAllocations.get(item.getId());
        final int stockAllocated = isNull(stockAllocation) ? 0 : stockAllocation.getAllocatedQuantity();
        final List<ProductionOrder> cutOrders = cutOrdersGroupByItemNumber.get(item.getId());
        return item.isPackedComplete(isNull(cutOrders) ? newArrayList() : cutOrders, stockAllocated);
    }

    public List<PrimeLineItem> getCutItems(final PortionRoom room) {
        final LocalDate startDate = systemConfigService.getFirstWorkDay(room.getLastOpenedAt());
        final LocalDate endDate =
                systemConfigService.getNextWorkDay(TimeUtils.getStartTimeOfDay(startDate));

        final List<PrimeLineItem> lineItemsForCurrentAndNextWorkingDay = getLineItems(room.getCode(), startDate,
                endDate, asList(new ProductOutput[]{ProductOutput.FINISHED, ProductOutput.BYPRODUCT_ONLY}));
        final List<PrimeLineItem> futureImmediateLineItems = getFutureImmediateLineItems(room.getCode(), endDate);
        final List<PrimeLineItem> primeLineItemList = new ArrayList<>(lineItemsForCurrentAndNextWorkingDay);
        primeLineItemList.addAll(futureImmediateLineItems);

        return filterClosedLineItemsByLineItemOuts(primeLineItemList);
    }

    private List<PrimeLineItem> getFutureImmediateLineItems(final String roomCode, final LocalDate startFrom) {
        final List<LineItem> lineItems = lineItemRepository
                .findByCustomerOrderShipDateAfterAndProductTableStationRoomCodeAndProductProductOutputInAndDeletedIsFalseAndCustomerOrderCancelledIsFalseAndCustomerOrderImmediateOrderIsTrue(
                        startFrom, roomCode, singletonList(ProductOutput.FINISHED));

        return getPrimeLineItems(lineItems);
    }

    List<PrimeLineItem> filterClosedLineItemsByLineItemOuts(final List<PrimeLineItem> lineItems) {
        final List<Long> lineItemsIds = lineItems.stream()
                .map(lineItem -> lineItem.getLineItem().getId())
                .collect(toList());
        final List<Long> lineItemsIdFromOuts = lineItemOutService.getOutsByLineItemIds(lineItemsIds).stream()
                .map(lineItemOut -> lineItemOut.getLineItem().getId())
                .collect(toList());

        return lineItems.stream()
                .filter(lineItem -> !lineItemsIdFromOuts.contains(lineItem.getLineItem().getId()))
                .collect(toList());
    }

    List<PrimeLineItem> getLineItems(
            final String roomCode, final LocalDate startDate, final LocalDate endDate, List<ProductOutput>
            productOutputs) {
        final List<LineItem> lineItems = lineItemRepository
                .findByCustomerOrderShipDateBetweenAndProductTableStationRoomCodeAndProductProductOutputInAndDeletedIsFalseAndCustomerOrderCancelledIsFalseAndCustomerOrderOnHoldIsFalse(
                        startDate, endDate, roomCode, productOutputs);
        return getPrimeLineItems(lineItems);
    }

    public List<PrimeLineItem> getPrimeLineItemsFromSchedule(final Map<Long, Integer> scheduledMap) {
        final List<Long> sourceIds = scheduledMap.entrySet().stream()
                .filter(entry -> entry.getValue() > 0)
                .map(Entry::getKey)
                .collect(toList());

        final List<LineItem> lineItems = lineItemRepository.findByIdIn(sourceIds);

        return getPrimeLineItems(lineItems);
    }

    void schedule(final Map<Long, Integer> scheduledMap) {
        final List<PrimeLineItem> primeLineItems = getPrimeLineItemsFromSchedule(scheduledMap);

        productionOrderService.generateOrdersFromPrimeLineItems(primeLineItems, scheduledMap);
    }

    private List<PrimeLineItem> getPrimeLineItems(final List<LineItem> lineItems) {
        final List<Long> sourceIds = lineItems.stream()
                .map(LineItem::getId)
                .collect(toList());
        final List<ProductionOrder> existingProductionOrders = productionOrderService.findBySourceIdIn(sourceIds);

        final Map<Long, StockAllocation> lineItemStockAllocations = getLineItemStockAllocation(sourceIds);

        return lineItems.stream()
                .map(item -> PrimeLineItem.builder()
                        .costing(costService.costing(item.getProduct()))
                        .lineItem(item)
                        .quantityRemaining(
                                calculateQuantityRemaining(existingProductionOrders, item,
                                        lineItemStockAllocations.get(item.getId())))
                        .build())
                .filter(lineItem -> lineItem.getQuantityRemaining() > 0)
                .collect(toList());
    }

    private Map<Long, StockAllocation> getLineItemStockAllocation(final List<Long> sourceIds) {
        final List<StockAllocation> stockAllocations = stockAllocationService.findByLineItemIds(sourceIds);
        return stockAllocations.stream()
                .collect(toMap(allocation -> allocation.getLineItem().getId(), allocation -> allocation));
    }

    List<PrimeLineItem> futureItems(final String roomCode) {
        final PortionRoom portionRoom = portionRoomService.getPortionRoomByCode(roomCode);
        final LocalDate startDate;
        final LocalDate endDate;

        if (portionRoom.getRoomType() == GRINDING) {
            startDate = systemConfigService.getFirstWorkDay(portionRoom.getLastOpenedAt());
            endDate = systemConfigService.getFutureWorkDay(
                    portionRoom.getLastOpenedAt(),
                    FUTURE_WORK_DAYS_FOR_GRINDING_ORDERS);
        } else {
            startDate = systemConfigService.getFutureWorkDay(
                    portionRoom.getLastOpenedAt(),
                    1);
            endDate = systemConfigService.getFutureWorkDay(
                    portionRoom.getLastOpenedAt(),
                    FUTURE_WORK_DAYS_FOR_CUTTING_ORDERS);
        }

        final List<PrimeLineItem> allFuturePrimeLineItems = getLineItems(portionRoom.getCode(), startDate, endDate,
                asList(new ProductOutput[]{ProductOutput.FINISHED}));

        return filterClosedLineItemsByLineItemOuts(allFuturePrimeLineItems).stream()
                .peek(primeLineItem -> {
                    if (primeLineItem.getCustomerOrder().isImmediateOrder()) {
                        primeLineItem.getCustomerOrder()
                                .setShipDate(systemConfigService.getFirstWorkDay(OffsetDateTime.now()));
                    }
                })
                .collect(toList());
    }

    public List<PrimeLineItem> allocateStocksAndGetRemainingLineItems(
            final String opCo,
            final List<PrimeLineItem> primeLineItems,
            final String roomCode,
            final boolean isNewCustomerOrder) {
        final Map<String, Integer> stocks = getStocks(primeLineItems, opCo, roomCode, isNewCustomerOrder);

        final List<PrimeLineItem> lineItemsNeededToGenerateCutOrders = new ArrayList<>();

        final List<PrimeLineItem> lineItemsAssignedStocks = new ArrayList<>();

        primeLineItems.forEach(primeLineItem -> {
            final LineItem lineItem = primeLineItem.getLineItem();
            final String productCode = lineItem.getProduct().getCode();
            final Integer currentStock = Optional.ofNullable(stocks.get(productCode)).orElse(0);

            log.info(format("[LineItem]  customerOrderId=%s, lineItemId=%s, quantity=%s, productCode=%s, "
                            + "hasCuttingInstructions=%s, hasPackingInstructions=%s, currentStock=%s",
                    lineItem.getCustomerOrder().getId(), lineItem.getId(), lineItem.getQuantity(),
                    productCode, lineItem.hasCuttingInstructions(), lineItem.hasPackingInstructions(),
                    currentStock));

            if (currentStock <= 0 || lineItem.notAllocable()) {
                final boolean isbyProductOnly = lineItem.getProduct().isByproductOnlyOutput();
                if (!isbyProductOnly) {
                    lineItemsNeededToGenerateCutOrders.add(primeLineItem
                            .withQuantityRemaining(primeLineItem.getQuantityRemaining()));
                }
                lineItemsAssignedStocks.add(primeLineItem
                        .withQuantityRemaining(0)
                        .withShouldOut(isbyProductOnly));
                createStockAllocation(lineItem, false, 0);
            } else {
                final int quantityRemaining = primeLineItem.getQuantityRemaining();
                if (currentStock >= quantityRemaining) {
                    final int stocksLeft = currentStock - quantityRemaining;
                    stocks.put(productCode, stocksLeft);
                    lineItemsAssignedStocks.add(primeLineItem.withQuantityRemaining(quantityRemaining));
                    createStockAllocation(lineItem, true, quantityRemaining);
                } else {
                    stocks.put(productCode, 0);
                    lineItemsAssignedStocks.add(primeLineItem.withQuantityRemaining(currentStock)
                            .withShouldOut(lineItem.getProduct().isByproductOnlyOutput()));
                    if (!lineItem.getProduct().isByproductOnlyOutput()) {
                        final int quantityToCut = primeLineItem.getQuantityRemaining() - currentStock;
                        lineItemsNeededToGenerateCutOrders.add(PrimeLineItem.builder()
                                .lineItem(lineItem)
                                .quantityRemaining(quantityToCut)
                                .build());
                    }
                    createStockAllocation(lineItem, false, currentStock);
                }
            }
        });

        if (!lineItemsAssignedStocks.isEmpty()) {
            final Map<String, List<PrimeLineItem>> lineItemsGroupedByCustomerOrderNumber =
                    lineItemsAssignedStocks.stream().collect(groupingBy(PrimeLineItem::getCustomerOrderNumber));

            lineItemsGroupedByCustomerOrderNumber.keySet()
                    .forEach(customerOrderNumber -> {
                        asohService.updateStocks(lineItemsGroupedByCustomerOrderNumber.get(customerOrderNumber));
                    });
        }

        return lineItemsNeededToGenerateCutOrders;
    }

    private Map<String, Integer> getStocks(
            final List<PrimeLineItem> primeLineItems,
            final String businessUnitNumber,
            final String roomCode,
            final boolean isNewCustomerOrder) {
        final List<String> productCodes = primeLineItems.stream()
                .map(lineItem -> lineItem.getLineItem().getProduct().getCode())
                .distinct()
                .collect(toList());
        final SusAsohData stocksFromSus
                = asohService.getStocks(productCodes, businessUnitNumber, roomCode, !isNewCustomerOrder);

        if (stocksFromSus == null || stocksFromSus.getProducts() == null) {
            return new LinkedHashMap<>();
        }

        return stocksFromSus.getProducts().stream()
                .collect(toMap(SusAsohProductData::getSupc, SusAsohProductData::getAvailableOnHand));
    }

    private void createStockAllocation(final LineItem lineItem, final boolean enough, final int allocatedQuantity) {
        log.info(format("[StockAllocation] lineItemId=%s, allocatedQuantity=%s, enough=%s",
                lineItem.getId(), allocatedQuantity, enough));
        stockAllocationService.create(StockAllocation.builder()
                .lineItem(lineItem)
                .allocatedQuantity(allocatedQuantity)
                .enough(enough)
                .build());
    }

    public boolean isAllLineItemsComplete(final List<LineItem> lineItems) {
        final List<Long> sourceIds = lineItems.stream().map(LineItem::getId).collect(toList());
        final List<ProductionOrder> existingCutOrders = productionOrderService.findBySourceIdIn(sourceIds);

        final Map<Long, StockAllocation> lineItemStockAllocations = getLineItemStockAllocation(sourceIds);

        final Map<Long, List<ProductionOrder>> productionOrdersGroupedBySourceId = existingCutOrders.stream()
                .collect(groupingBy(ProductionOrder::getSourceId));

        return lineItems.stream()
                .allMatch(item -> isLineItemPackedComplete(lineItemStockAllocations, productionOrdersGroupedBySourceId,
                        item));
    }

    public void allocateStocksForGrindingOrders(final PortionRoom portionRoom) {
        final String opCo = profileService.get().getPlantNumber();
        final LocalDate nextWorkDay = systemConfigService.getNextWorkDay(portionRoom.getLastOpenedAt());
        final LocalDate tomorrowOfNextWorkDay =
                systemConfigService.getNextWorkDay(getStartTimeOfDay(nextWorkDay));

        final List<PrimeLineItem> primeLineItems = getLineItems(portionRoom.getCode(), nextWorkDay,
                tomorrowOfNextWorkDay,
                asList(new ProductOutput[]{ProductOutput.FINISHED, ProductOutput.BYPRODUCT_ONLY}));

        filterClosedLineItemsByLineItemOuts(primeLineItems).stream()
                .collect(groupingBy(PrimeLineItem::asSusGroupingKey))
                .entrySet()
                .forEach(entry -> allocateStockForShipDate(
                        entry.getValue(),
                        opCo,
                        portionRoom
                ));
    }

    void allocateStockForShipDate(
            final List<PrimeLineItem> items,
            final String opCo,
            final PortionRoom portionRoom) {
        log.info(format("[close grinding room allocate stock], primeLineItems.size = %s",
                items.size()));

        allocateStocksAndGetRemainingLineItems(
                opCo,
                items,
                portionRoom.getCode(),
                false);
    }

    public void sendOutsForUnscheduledLineItems(final PortionRoom portionRoom, final LocalDate firstWorkDay) {
        final List<LineItem> lineItems = newArrayList();
        final List<LineItem> lineItemsForToday =
                lineItemRepository
                        .findByCustomerOrderShipDateBetweenAndProductTableStationRoomCodeAndProductProductOutputInAndDeletedIsFalseAndCustomerOrderCancelledIsFalseAndCustomerOrderOnHoldIsFalse(
                                firstWorkDay, firstWorkDay, portionRoom.getCode(), singletonList(ProductOutput
                                        .FINISHED));

        final List<LineItem> futureImmediateLineItems = lineItemRepository
                .findByCustomerOrderShipDateAfterAndProductTableStationRoomCodeAndProductProductOutputInAndDeletedIsFalseAndCustomerOrderCancelledIsFalseAndCustomerOrderImmediateOrderIsTrue(
                        firstWorkDay, portionRoom.getCode(), singletonList(ProductOutput.FINISHED));

        lineItems.addAll(lineItemsForToday);
        lineItems.addAll(futureImmediateLineItems);

        final List<Long> existedLineItemIds = lineItems.stream()
                .map(LineItem::getId)
                .collect(Collectors.toList());

        final List<Long> existedLineItemOutIds = lineItemOutService.getOutsByLineItemIds(existedLineItemIds)
                .stream()
                .map(lineItemOut -> lineItemOut.getLineItem().getId())
                .collect(Collectors.toList());

        final List<Long> finishedProductionOrderLineItemsIds =
                productionOrderService.findAllProductionOrdersByRoomCodeAndStatuses(
                        portionRoom.getCode(), singletonList(PACKED))
                        .stream()
                        .map(ProductionOrder::getSourceId)
                        .collect(Collectors.toList());

        lineItems.forEach(lineItem -> {
            final Long lineItemId = lineItem.getId();

            if (!existedLineItemOutIds.contains(lineItemId)
                    && !finishedProductionOrderLineItemsIds.contains(lineItemId)) {
                lineItemOutService.create(lineItemId, lineItem.getQuantityInCases());
            }
        });
    }
}
