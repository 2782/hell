package com.sysco.prime.customerOrder;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.sysco.prime.cost.Costing;
import com.sysco.prime.unitOfMeasure.UnitOfMeasure;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.time.LocalDate;

import static java.lang.Math.ceil;

@AllArgsConstructor
@Builder(toBuilder = true)
@EqualsAndHashCode
@Getter
@JsonSerialize(using = PrimeLineItemSerializer.class)
@NoArgsConstructor
@ToString
public class PrimeLineItem {
    private LineItem lineItem;
    private int quantityRemaining;

    @Builder.Default
    private boolean shouldOut = false;
    private Costing costing;

    int getQuantityRemainingInCases() {
        return lineItem.getUnitOfMeasure() == UnitOfMeasure.BOX
                ? quantityRemaining
                : (int) ceil(quantityRemaining * 1.0 / lineItem.getProduct().getPiecesPerCase());
    }

    public PrimeLineItem withQuantityRemaining(final int amount) {
        return this
                .toBuilder()
                .quantityRemaining(amount)
                .build();
    }

    public PrimeLineItem withShouldOut(final boolean shouldOut) {
        return this
                .toBuilder()
                .shouldOut(shouldOut)
                .build();
    }

    public CustomerOrder getCustomerOrder() {
        return lineItem.getCustomerOrder();
    }

    public String getCustomerOrderNumber() {
        return getCustomerOrder().getOrderNumber();
    }

    public SusGroupingKey asSusGroupingKey() {
        return new SusGroupingKey();
    }

    @EqualsAndHashCode
    @ToString
    public final class SusGroupingKey {
        public final String customerCode;
        public final LocalDate shipDate;

        public SusGroupingKey() {
            customerCode = lineItem.getCustomerOrder().getCustomerCode();
            shipDate = lineItem.getCustomerOrder().getShipDate();
        }
    }
}
