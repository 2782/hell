package com.sysco.prime.portionRoom.response;

import com.sysco.prime.portionRoom.PortionRoomStatus;
import com.sysco.prime.portionRoom.PortionRoomType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotNull;
import java.time.OffsetDateTime;

@Data
@Builder
@EqualsAndHashCode(callSuper = false)
@AllArgsConstructor
@NoArgsConstructor
public class PortionRoomResponse {
    private long id;
    @NotNull
    private String code;
    @NotNull
    private String description;
    private PortionRoomType roomType;
    private PortionRoomStatus portionRoomStatus;
    private boolean openable;
    private boolean approved;
    private OffsetDateTime lastOpenedAt;
    private String customerNumber;
}
