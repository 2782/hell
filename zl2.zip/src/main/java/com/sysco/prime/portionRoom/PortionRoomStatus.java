package com.sysco.prime.portionRoom;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

import static java.lang.String.format;

public enum PortionRoomStatus {
    OPENED,
    CLOSED;

    @JsonCreator
    public static PortionRoomStatus from(final String value) {
        for (final PortionRoomStatus portionRoomStatus: values()) {
            if (portionRoomStatus.toString().equals(value)) {
                return portionRoomStatus;
            }
        }
        throw new IllegalArgumentException(
                format("[PortionRoomStatus convert] can't parse '%s' to PortionRoomStatus", value));
    }

    @Override
    @JsonValue
    public String toString() {
        return name().toLowerCase();
    }
}
