package com.sysco.prime.portionRoom;

import com.sysco.prime.portionRoom.response.PortionRoomResponse;
import com.sysco.prime.productionOrder.ProductionType;
import com.sysco.prime.shared.model.TransactionalEntity;
import com.sysco.prime.station.Station;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Builder.Default;
import lombok.Generated;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.Entity;
import javax.persistence.Enumerated;
import javax.persistence.OneToMany;
import java.time.Clock;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.List;
import java.util.Objects;

import static com.sysco.prime.portionRoom.PortionRoomStatus.CLOSED;
import static com.sysco.prime.portionRoom.PortionRoomStatus.OPENED;
import static com.sysco.prime.portionRoom.PortionRoomType.COSTING;
import static com.sysco.prime.portionRoom.PortionRoomType.CUTTING;
import static com.sysco.prime.portionRoom.PortionRoomType.GRINDING;
import static com.sysco.prime.utils.TimeUtils.getStartTimeOfDay;
import static java.util.Objects.hash;
import static java.util.Objects.isNull;
import static javax.persistence.CascadeType.ALL;
import static javax.persistence.EnumType.STRING;
import static javax.persistence.FetchType.LAZY;

@Getter
@Setter
@Entity
@Builder(toBuilder = true)
@AllArgsConstructor
@NoArgsConstructor
@ToString(callSuper = true)
public class PortionRoom extends TransactionalEntity {
    @OneToMany(mappedBy = "room",
            targetEntity = Station.class,
            cascade = ALL, fetch = LAZY)
    private List<Station> stations;
    private String code;
    private String description;
    @Enumerated(STRING)
    private PortionRoomType roomType;
    @Enumerated(STRING)
    @Default
    private PortionRoomStatus portionRoomStatus = CLOSED;
    private OffsetDateTime lastOpenedAt;
    private boolean approved;
    private String customerNumber;

    private boolean isClosed() {
        return CLOSED == portionRoomStatus;
    }

    public boolean isOpened() {
        return OPENED == portionRoomStatus;
    }

    boolean isOpenable(final Clock clock) {
        return isClosed() && canBeReopenedForToday(clock);
    }

    private boolean canBeReopenedForToday(final Clock clock) {
        return isNull(lastOpenedAt) || !getStartTimeOfDay(lastOpenedAt.toLocalDate())
                .equals(getStartTimeOfDay(LocalDate.now(clock)));
    }

    public void update(final PortionRoom portionRoom) {
        code = setIfNonNull(portionRoom.getCode(), code);
        description = setIfNonNull(portionRoom.getDescription(), description);
        portionRoomStatus = setIfNonNull(portionRoom.getPortionRoomStatus(), portionRoomStatus);
    }

    public PublishingPortionRoom toReporting(
            final OffsetDateTime opening,
            final OffsetDateTime closing) {
        return PublishingPortionRoom.builder()
                .code(code)
                .description(description)
                .roomType(roomType)
                .portionRoomStatus(portionRoomStatus)
                .opening(opening)
                .closing(closing)
                .build();
    }

    PortionRoomWorkingDates workingDatesOnOpening() {
        return PortionRoomWorkingDates.builder()
                .roomCode(code)
                .opening(lastOpenedAt)
                .stockAlerted(null)
                .build();
    }

    PortionRoomResponse toResponse(final boolean isWorkToday, final Clock clock) {
        return PortionRoomResponse.builder()
                .id(getId())
                .code(code)
                .description(description)
                .portionRoomStatus(portionRoomStatus)
                .customerNumber(customerNumber)
                .roomType(roomType)
                .openable(isOpenable(clock) && isWorkToday)
                .lastOpenedAt(lastOpenedAt)
                .approved(approved)
                .build();
    }

    public boolean isCuttingRoom() {
        return CUTTING == roomType;
    }

    public boolean isGrindingRoom() {
        return GRINDING == roomType;
    }

    boolean isCostingRoom() {
        return COSTING == roomType;
    }

    public ProductionType getProductionType() {
        return ProductionType.from(roomType);
    }

    @Override
    @Generated
    public boolean equals(final Object other) {
        if (this == other) {
            return true;
        }
        if (null == other || getClass() != other.getClass()) {
            return false;
        }

        final PortionRoom that = (PortionRoom) other;
        return Objects.equals(code, that.code)
                && Objects.equals(description, that.description)
                && roomType == that.roomType
                && portionRoomStatus == that.portionRoomStatus
                && Objects.equals(lastOpenedAt, that.lastOpenedAt)
                && areHibernateListsEqual(stations, that.stations);
    }

    @Override
    @Generated
    public int hashCode() {
        return hash(stations, code, description, roomType, portionRoomStatus, lastOpenedAt);
    }
}
