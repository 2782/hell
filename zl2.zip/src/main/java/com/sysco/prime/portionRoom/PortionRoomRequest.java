package com.sysco.prime.portionRoom;

import com.sysco.prime.portionRoom.validation.ValidCustomerNumber;
import com.sysco.prime.portionRoom.validation.ValidRoomCode;
import lombok.Data;
import lombok.RequiredArgsConstructor;

import javax.persistence.Enumerated;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import static javax.persistence.EnumType.STRING;

@Data
@RequiredArgsConstructor
public class PortionRoomRequest {
    @ValidRoomCode
    private String code;
    @NotNull(message = "Required")
    @Size(min = 1, max = 64, message = "Maximum 64 characters")
    private String description;
    @NotNull(message = "Required")
    @Enumerated(STRING)
    private PortionRoomType roomType;
    @NotNull(message = "Required")
    @Size(min = 6, max = 6)
    @Pattern(regexp = "[0-9]*")
    @ValidCustomerNumber
    private String customerNumber;

    PortionRoom toDomain() {
        return PortionRoom.builder()
                .code(code)
                .description(description)
                .roomType(roomType)
                .customerNumber(customerNumber)
                .build();
    }
}
