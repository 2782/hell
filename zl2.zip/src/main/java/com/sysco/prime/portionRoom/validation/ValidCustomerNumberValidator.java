package com.sysco.prime.portionRoom.validation;

import com.sysco.prime.customer.Customer;
import com.sysco.prime.customer.CustomerService;
import com.sysco.prime.product.validation.PrimeConstraintValidator;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.validation.ConstraintValidatorContext;

import static com.sysco.prime.validation.ValidationErrorType.INVALID;
import static com.sysco.prime.validation.ValidationErrorType.NOT_EXIST;

@Component
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class ValidCustomerNumberValidator implements PrimeConstraintValidator<ValidCustomerNumber, String> {
    private final CustomerService customerService;

    private boolean checkInternal;

    @Override
    public void initialize(final ValidCustomerNumber constraintAnnotation) {
        checkInternal = constraintAnnotation.internal();
    }

    @Override
    public boolean isValid(final String customerNumber, final ConstraintValidatorContext context) {
        final Customer customer = customerService.getCustomerByCode(customerNumber);

        if (customer == null) {
            return validationFailedBecause(context, NOT_EXIST);
        }

        if (!checkInternal) {
            return true;
        }

        if (!customer.isInternalCustomer()) {
            return validationFailedBecause(context, INVALID);
        }
        return true;
    }
}
