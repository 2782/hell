package com.sysco.prime.portionRoom;

import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class PortionRoomWorkingDatesService {
    private final PortionRoomWorkingDatesRepository repository;

    public void stockAllocationFailed(final String roomCode) {
        final PortionRoomWorkingDates workingDates = repository.findTopByRoomCodeOrderByIdDesc(roomCode);
        if (workingDates != null && null == workingDates.getStockAlerted()) {
            workingDates.setStockAlerted(false);

            repository.save(workingDates);
        }
    }

    public PortionRoomWorkingDates save(final PortionRoomWorkingDates workingDates) {
        return repository.save(workingDates);
    }

    PortionRoomWorkingDates findNewestWorkingDatesFor(final String roomCode) {
        return repository.findTopByRoomCodeOrderByIdDesc(roomCode);
    }

    List<PortionRoomWorkingDates> findFirstTwoWorkingDatesFor(final String roomCode) {
        return repository.findTop2ByRoomCodeOrderByIdDesc(roomCode);
    }

    PortionRoomWorkingDates findUnClosedWorkingDatesFor(final String roomCode) {
        return repository.findByRoomCodeAndClosingIsNull(roomCode);
    }
}
