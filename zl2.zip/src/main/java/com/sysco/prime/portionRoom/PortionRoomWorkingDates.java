package com.sysco.prime.portionRoom;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.sysco.prime.shared.model.TransactionalEntity;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import javax.persistence.Entity;
import java.time.OffsetDateTime;

@Entity
@Data
@Builder(toBuilder = true)
@EqualsAndHashCode(callSuper = false)
@AllArgsConstructor
@NoArgsConstructor
public class PortionRoomWorkingDates extends TransactionalEntity {
    private String roomCode;
    private OffsetDateTime opening;
    private OffsetDateTime closing;
    private Boolean stockAlerted;

    @JsonIgnore
    PortionRoomWorkingDates closeAt(final OffsetDateTime closingAt) {
        final PortionRoomWorkingDates withClosing = builder()
                .roomCode(roomCode)
                .opening(opening)
                .closing(closingAt)
                .stockAlerted(stockAlerted)
                .build();
        withClosing.setId(getId());
        withClosing.setCreatedAt(getCreatedAt());
        return withClosing;
    }
}
