package com.sysco.prime.portionRoom;

import com.sysco.prime.PrimeRepository;

import java.util.List;

public interface PortionRoomWorkingDatesRepository extends PrimeRepository<PortionRoomWorkingDates> {
    PortionRoomWorkingDates findByRoomCodeAndClosingIsNull(String roomCode);

    PortionRoomWorkingDates findTopByRoomCodeOrderByIdDesc(String roomCode);

    List<PortionRoomWorkingDates> findTop2ByRoomCodeOrderByIdDesc(String roomCode);
}
