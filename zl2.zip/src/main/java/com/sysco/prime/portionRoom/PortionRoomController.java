package com.sysco.prime.portionRoom;

import com.sysco.prime.portionRoom.response.CloseRoomResult;
import com.sysco.prime.portionRoom.response.PortionRoomResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import java.time.Clock;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;

import static java.time.OffsetDateTime.now;
import static org.springframework.http.HttpStatus.NO_CONTENT;

@RestController
@RequestMapping("/api")
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class PortionRoomController {
    private final PortionRoomService portionRoomService;
    private final Clock when;

    @PostMapping("/rooms/{id}/open")
    @Secured({"ROLE_ADMIN"})
    public List<PortionRoomResponse> open(@PathVariable("id") final Long portionRoomId) {
        return portionRoomService.open(portionRoomId, now(when));
    }

    @PostMapping("/rooms/{id}/close")
    @Secured({"ROLE_ADMIN"})
    public CloseRoomResult close(@RequestParam("unfinishedOrders") final boolean evenUnfinishedOrders,
                                 @RequestParam("susPoUnavailable") final boolean evenSusPoUnavailable,
                                 @PathVariable("id") final Long portionRoomId) {
        return portionRoomService.close(portionRoomId, evenUnfinishedOrders, evenSusPoUnavailable);
    }

    @GetMapping("/rooms")
    @Secured({"ROLE_ADMIN", "ROLE_PORTION_ROOM_MEMBER","ROLE_COSTING"})
    public List<PortionRoomResponse> get() {
        return portionRoomService.getPortionRooms();
    }

    @GetMapping("/rooms/costing")
    @Secured({"ROLE_COSTING"})
    public PortionRoomResponse getCostingRoom() {
        return portionRoomService.getCostingRoom()
                .toResponse(true, when);
    }

    @GetMapping("/operating-dates/{room-code}")
    @Secured({"ROLE_ADMIN", "ROLE_PORTION_ROOM_MEMBER"})
    public Map<String, LocalDate> operatingDates(@PathVariable("room-code") final String roomCode) {
        return portionRoomService.getOperatingDates(roomCode);
    }

    @PostMapping("/rooms")
    @ResponseStatus(NO_CONTENT)
    @Secured({"ROLE_ADMIN", "ROLE_COSTING"})
    public void create(@Valid @RequestBody final PortionRoomRequest room) {
        portionRoomService.createNewRoom(room.toDomain());
    }

    @GetMapping("/rooms/{room-code}/stock-allocation-alert")
    public boolean stockAlert(@PathVariable("room-code") final String roomCode) {
        return !portionRoomService.stockAlerted(roomCode);
    }
}
