package com.sysco.prime.portionRoom;

import com.sysco.prime.PrimeRepository;

import java.util.Optional;

public interface PortionRoomRepository extends PrimeRepository<PortionRoom> {
    Optional<PortionRoom> findByCode(String code);

    Optional<PortionRoom> findByDescription(String description);

    Optional<PortionRoom> findByRoomType(PortionRoomType roomType);
}
