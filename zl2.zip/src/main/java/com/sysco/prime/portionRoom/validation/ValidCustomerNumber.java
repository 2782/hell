package com.sysco.prime.portionRoom.validation;

import javax.validation.Constraint;
import javax.validation.Payload;
import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import static java.lang.annotation.ElementType.FIELD;
import static java.lang.annotation.ElementType.PARAMETER;
import static java.lang.annotation.ElementType.TYPE_USE;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

@Constraint(validatedBy = {ValidCustomerNumberValidator.class})
@Documented
@Target({FIELD, TYPE_USE, PARAMETER})
@Retention(RUNTIME)
public @interface ValidCustomerNumber {
    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};

    String message() default "";

    /** Requires customer to be internal to Prime. Defaults to {@code true}. */
    boolean internal() default true;
}
