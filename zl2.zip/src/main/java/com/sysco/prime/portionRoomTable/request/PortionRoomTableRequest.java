package com.sysco.prime.portionRoomTable.request;

import com.sysco.prime.portionRoom.PortionRoom;
import com.sysco.prime.portionRoomTable.PortionRoomTable;
import com.sysco.prime.station.request.StationRequest;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.time.LocalTime;

@Getter
@AllArgsConstructor
@Builder
public class PortionRoomTableRequest {
    @NotNull
    private final StationRequest station;

    @NotNull
    @Min(1)
    @Max(99)
    private final Integer tableCode;

    @NotNull
    @Size(min = 1, max = 20)
    private final String tableDescription;

    @NotNull
    private final LocalTime tableOpenTime;
    @NotNull
    private final LocalTime tableCloseTime;
    @NotNull
    private final Integer poundsPerHour;

    public PortionRoomTable toTable() {
        return toTable(null);
    }

    public PortionRoomTable toTable(final PortionRoom room) {
        return PortionRoomTable.builder()
                .tableCode(tableCode)
                .tableDescription(tableDescription)
                .station(station.toStation(room))
                .poundsPerHour(poundsPerHour)
                .tableCloseTime(tableCloseTime)
                .tableOpenTime(tableOpenTime)
                .build();
    }

    public String getRoom() {
        return station == null ? "" : station.getRoom();
    }
}
