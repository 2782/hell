package com.sysco.prime.portionRoomTable;

import com.sysco.prime.exception.InvalidValueException;
import com.sysco.prime.station.StationRepository;
import com.sysco.prime.validation.LengthValidation;
import com.sysco.prime.validation.NumberRangeValidation;
import com.sysco.prime.validation.RequiredValidation;
import com.sysco.prime.validation.Validation;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Objects;
import java.util.Optional;
import java.util.stream.Stream;

import static com.sysco.prime.validation.ValidationError.buildError;
import static com.sysco.prime.validation.ValidationErrorType.NOT_EXIST;
import static com.sysco.prime.validation.ValidationErrorType.OUT_OF_RANGE;
import static com.sysco.prime.validation.ValidationErrorType.REQUIRED;
import static com.sysco.prime.validation.ValidationErrorType.UNIQUE;

@Component
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class PortionRoomTableValidator {
    static final String STATION_DOES_NOT_EXIST = "station does not exist";
    static final String TABLE_CODE_NOT_UNIQUE = "table code must be unique";
    private static final String ERROR_MESSAGE = "Saving portion room failed.";
    private static final String CANNOT_CHANGE_TABLE_CODE = "cannot change table code";

    private final StationRepository stationRepository;

    private final PortionRoomTableRepository portionRoomTableRepository;

    void validate(final PortionRoomTable table) {
        Stream.of(
                new RequiredValidation(ERROR_MESSAGE, table.getTableDescription(), "tableDescription"),
                new LengthValidation(ERROR_MESSAGE, table.getTableDescription(), "tableDescription", 1, 64),
                validateStationExist(table),
                new PortionRoomTableCodeValidator(portionRoomTableRepository, table),
                new NumberRangeValidation(ERROR_MESSAGE, table.getTableCode(), "tableCode", 1, 99)
        ).forEach(Validation::validate);
    }

    private Validation validateStationExist(final PortionRoomTable table) {
        return () -> {
            if (!Optional.ofNullable(stationRepository.getOneOrNull(table.getStationId())).isPresent()) {
                throw new InvalidValueException(STATION_DOES_NOT_EXIST, buildError(
                        "station", NOT_EXIST, ERROR_MESSAGE));
            }
        };
    }

    @RequiredArgsConstructor
    public static class PortionRoomTableCodeValidator implements Validation {
        private final PortionRoomTableRepository repository;
        private final PortionRoomTable table;

        @Override
        public void validate() {
            if (table.existing()) {
                final Long tableId = table.getId();
                if (null == tableId) {
                    throw new InvalidValueException(TABLE_CODE_NOT_UNIQUE, buildError(
                            "table id", REQUIRED, ERROR_MESSAGE));
                }
                final PortionRoomTable found = repository.getOneOrNull(tableId);
                if (!Objects.equals(found.getTableCode(), table.getTableCode())) {
                    throw new InvalidValueException(TABLE_CODE_NOT_UNIQUE, buildError(
                            "tableCode", OUT_OF_RANGE, CANNOT_CHANGE_TABLE_CODE));
                }
            } else {
                if (repository.findByTableCode(table.getTableCode()).isPresent()) {
                    throw new InvalidValueException(TABLE_CODE_NOT_UNIQUE, buildError(
                            "tableCode", UNIQUE, ERROR_MESSAGE));
                }
            }
        }
    }
}
