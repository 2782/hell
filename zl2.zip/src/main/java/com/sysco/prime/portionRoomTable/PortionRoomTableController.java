package com.sysco.prime.portionRoomTable;

import com.sysco.prime.portionRoomTable.request.PortionRoomTableRequest;
import com.sysco.prime.portionRoomTable.response.PortionRoomTableResponse;
import com.sysco.prime.portionRoomTable.response.PortionRoomTableSummary;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping(value = "/api", produces = MediaType.APPLICATION_JSON_VALUE)
public class PortionRoomTableController {
    private final PortionRoomTableService portionRoomTableService;

    @Autowired
    public PortionRoomTableController(final PortionRoomTableService portionRoomTableService) {
        this.portionRoomTableService = portionRoomTableService;
    }

    @GetMapping("/portion-room-tables/{id}")
    @ApiOperation(value = "get table information",
            notes = "get PortionRoomTable resource(same as the model in database) based on given tableId. "
                    + "This is part of the v2 api for order list, can be used to get the table and station information "
                    + "used by CutOrderList page and PackOrderList page header.")
    @Secured({"ROLE_ADMIN", "ROLE_PORTION_ROOM_MEMBER"})
    public PortionRoomTableResponse getPortionRoomTable(@PathVariable("id") final Long id) {
        return new PortionRoomTableResponse(portionRoomTableService.getTableById(id));
    }

    @GetMapping("/portion-room-tables")
    @ApiOperation(value = "get all portion room tables summary information",
            notes = "get portion room table resource(same as the model in database)")
    @Secured({"ROLE_ADMIN", "ROLE_COSTING"})
    public List<PortionRoomTableSummary> getPortionRoomTables() {
        return portionRoomTableService.findAllTableSummary();
    }

    @PostMapping("/portion-room-tables")
    @ResponseStatus(HttpStatus.CREATED)
    @ApiOperation(value = "create table",
            notes = "create table with station id")
    @Secured({"ROLE_ADMIN"})
    public PortionRoomTableResponse createTable(@Valid @RequestBody final PortionRoomTableRequest request) {
        return new PortionRoomTableResponse(portionRoomTableService.create(request.toTable()));
    }

    @PutMapping("/portion-room-tables/{id}")
    @ApiOperation("update table")
    @Secured({"ROLE_ADMIN"})
    public PortionRoomTableResponse updateTable(
            @PathVariable("id") final Long tableId, @RequestBody final PortionRoomTableRequest request) {
        return new PortionRoomTableResponse(portionRoomTableService.update(tableId, request.toTable()));
    }
}
