package com.sysco.prime.portionRoomTable.response;

import com.sysco.prime.portionRoomTable.PortionRoomTable;
import com.sysco.prime.station.response.StationResponse;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.time.LocalTime;

@AllArgsConstructor
@Getter
public class PortionRoomTableResponse {
    private final Integer tableCode;
    private final String tableDescription;
    private StationResponse station;
    private LocalTime tableOpenTime;
    private LocalTime tableCloseTime;
    private Integer poundsPerHour;

    public PortionRoomTableResponse(final PortionRoomTable table) {
        tableCode = table.getTableCode();
        tableDescription = table.getTableDescription();
        tableOpenTime = table.getTableOpenTime();
        tableCloseTime = table.getTableCloseTime();
        poundsPerHour = table.getPoundsPerHour();

        if (table.getStation() != null) {
            station = new StationResponse(table.getStation());
        }
    }
}
