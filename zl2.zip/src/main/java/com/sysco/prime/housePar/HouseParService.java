package com.sysco.prime.housePar;

import com.sysco.prime.cost.CostService;
import com.sysco.prime.exception.InvalidValueException;
import com.sysco.prime.exception.NotFoundException;
import com.sysco.prime.housePar.response.AllocatedStockHouseParResponse;
import com.sysco.prime.portionRoom.PortionRoom;
import com.sysco.prime.portionRoom.PortionRoomService;
import com.sysco.prime.portionRoom.PortionRoomWorkingDates;
import com.sysco.prime.product.ProductService;
import com.sysco.prime.productionOrder.ProductionOrder;
import com.sysco.prime.productionOrder.ProductionOrderService;
import com.sysco.prime.profile.ProfileService;
import com.sysco.prime.shared.model.ParValue;
import com.sysco.prime.shared.repository.ParValueRepository;
import com.sysco.prime.sus.model.stock.SusAsohData;
import com.sysco.prime.sus.model.stock.SusAsohProductData;
import com.sysco.prime.sus.service.AsohService;
import com.sysco.prime.systemConfig.SystemConfigService;
import com.sysco.prime.validation.ValidationErrorType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

import static com.sysco.prime.validation.ValidationError.buildError;
import static java.util.stream.Collectors.toList;
import static java.util.stream.Collectors.toMap;

@Service
public class HouseParService {
    private final HouseParRepository houseParRepository;
    private final ParValueRepository parValueRepository;
    private final ProductService productService;
    private final SystemConfigService systemConfigService;
    private final PortionRoomService portionRoomService;
    private final AsohService asohService;
    private final ProfileService profileService;
    private final ProductionOrderService productionOrderService;
    private final CostService costService;

    @Autowired
    public HouseParService(final HouseParRepository houseParRepository, final ParValueRepository parValueRepository,
                           @Lazy final ProductService productService, final SystemConfigService systemConfigService,
                           @Lazy final PortionRoomService portionRoomService, final AsohService asohService,
                           final ProfileService profileService,
                           @Lazy final ProductionOrderService productionOrderService, final CostService costService) {
        this.houseParRepository = houseParRepository;
        this.parValueRepository = parValueRepository;
        this.productService = productService;
        this.systemConfigService = systemConfigService;
        this.portionRoomService = portionRoomService;
        this.asohService = asohService;
        this.profileService = profileService;
        this.productionOrderService = productionOrderService;
        this.costService = costService;
    }

    private static HousePar toHouseParForToday(final ParValue config) {
        final HousePar housePar = config.getHousePar();
        housePar.setParValueToday(config);
        return housePar;
    }

    public List<HousePar> getActiveHousePars() {
        return houseParRepository.findByDeletedFalse();
    }

    void deleteHousePar(final String productCode) {
        productService.findByCode(productCode);
        final HousePar housePar = Optional.ofNullable(
                houseParRepository
                        .findFirstByDeletedFalseAndProductCodeIs(productCode))
                .orElseThrow(() -> new InvalidValueException(
                        "Deletion of house par failed",
                        buildError("productCode", ValidationErrorType.NOT_EXIST,
                                "No house par found for product", productCode)));
        housePar.markDeleted();
        houseParRepository.save(housePar);
    }

    public HousePar getExistsHousePar(final String productCode) {
        productService.findByCode(productCode);
        return houseParRepository.findFirstByDeletedFalseAndProductCodeIs(productCode);
    }

    @Transactional
    public void createHousePar(final HousePar updatedHousePar) {
        createParValue(updatedHousePar, updatedHousePar);
    }

    @Transactional
    public void updateHousePar(final Long id, final HousePar updatedHousePar) {
        final HousePar existingHousePar = houseParRepository.getOneOrNull(id);
        if (null == existingHousePar) {
            throw new NotFoundException("No House Par found for id: " + id);
        }

        softDelete(existingHousePar.getConfigValues());

        createParValue(existingHousePar, updatedHousePar);
    }

    private void softDelete(final List<ParValue> configValues) {
        parValueRepository.saveAll(configValues.stream()
                .map(ParValue::copy)
                .map(ParValue::markDelete)
                .collect(toList()));
    }

    private void createParValue(final HousePar existingHousePar, final HousePar updatedHousePar) {
        existingHousePar.replaceConfigValuesWith(updatedHousePar.getConfigValues().stream()
                .map(ParValue::markUndelete)
                .collect(toList()));
        houseParRepository.save(existingHousePar);
    }

    public List<HousePar> getAvailableHouseParsForOrderGenerating(
            final PortionRoom portionRoom, final OffsetDateTime date) {

        final int dayOfWeekToday = systemConfigService.getFirstWorkDay(date).getDayOfWeek().getValue();
        return getHouseParsByDayOfWeek(portionRoom, dayOfWeekToday);
    }

    List<AllocatedStockHouseParResponse> getAvailableHouseParsForOrderGenerating(final String roomCode) {
        final PortionRoom portionRoom = portionRoomService.getPortionRoomByCode(roomCode);

        final LocalDate dateToShowHousePar = getDateToShowHousePar(roomCode);
        final int dayOfWeek = dateToShowHousePar.getDayOfWeek().getValue();

        final List<HousePar> availableHousePars = getHouseParsByDayOfWeek(portionRoom, dayOfWeek);

        final List<String> productCodes = availableHousePars.stream().map(HousePar::productCode).collect(toList());

        final Map<String, Integer> stocks = getStocks(productCodes);

        return availableHousePars.stream()
                .map(housePar ->
                        housePar.toAllocatedStockHousePar(
                                calcIgnoredQuantity(stocks, dateToShowHousePar, housePar), dateToShowHousePar,
                                costService))
                .filter(Objects::nonNull)
                .collect(toList());
    }

    private Integer calcIgnoredQuantity(
            final Map<String, Integer> stocks, final LocalDate dateToShowHousePar, final HousePar housePar) {
        final List<ProductionOrder> generatedProductionOrders =
                productionOrderService.findBySourceIdAndProductDate(housePar.getId(), dateToShowHousePar);

        final Integer alreadyGeneratedOrdersQuantity = generatedProductionOrders.stream()
                .mapToInt(ProductionOrder::getQtyToProduceInCases)
                .sum();

        final Integer stockQuantity = stocks.getOrDefault(housePar.productCode(), 0);

        return alreadyGeneratedOrdersQuantity + stockQuantity;
    }

    private List<HousePar> getHouseParsByDayOfWeek(
            final PortionRoom portionRoom,
            final int dateOfWeek) {
        final List<ParValue> parValues = parValueRepository.findByDayOfWeek(dateOfWeek);

        return parValues.stream()
                .filter(config -> config.belongsTo(portionRoom))
                .map(HouseParService::toHouseParForToday)
                .collect(toList());
    }

    public LocalDate getDateToShowHousePar(final String roomCode) {

        final PortionRoomWorkingDates portionRoomWorkingDates = portionRoomService.getPortionRoomWorkingDates(roomCode);

        if (portionRoomWorkingDates == null) {
            return systemConfigService.getFirstWorkDay(null);
        } else if (portionRoomWorkingDates.getClosing() == null) {
            return portionRoomWorkingDates.getOpening().toLocalDate();
        } else {
            return systemConfigService.getNextWorkDay(portionRoomWorkingDates.getOpening());
        }
    }

    public Map<String, Integer> getStocks(
            final List<String> productCodes) {
        final String businessUnitNumber = profileService.get().getPlantNumber();
        final SusAsohData stocksFromSus = asohService.getStocks(productCodes, businessUnitNumber, null, false);

        if (stocksFromSus == null || stocksFromSus.getProducts() == null) {
            return new LinkedHashMap<>();
        }

        return stocksFromSus.getProducts().stream()
                .collect(toMap(SusAsohProductData::getSupc, SusAsohProductData::getAvailableOnHand));
    }

    public List<HousePar> findByIdIn(final List<Long> sourceIds) {
        return houseParRepository.findByIdInAndDeletedFalse(sourceIds);
    }
}
