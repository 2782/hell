package com.sysco.prime.housePar.response;

import com.sysco.prime.product.response.ProductResponse;
import com.sysco.prime.productionOrder.CutOrderSource;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class AllocatedStockHouseParResponse {
    private Long id;
    private ProductResponse product;
    private int quantity;
    private CutOrderSource source;
    private LocalDate deliveryDate;
}
