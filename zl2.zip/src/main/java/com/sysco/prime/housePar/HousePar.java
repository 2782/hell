package com.sysco.prime.housePar;

import com.sysco.prime.cost.CostService;
import com.sysco.prime.housePar.response.AllocatedStockHouseParResponse;
import com.sysco.prime.product.Product;
import com.sysco.prime.product.response.ProductResponse;
import com.sysco.prime.productionOrder.CutOrderSource;
import com.sysco.prime.shared.model.ParValue;
import com.sysco.prime.shared.model.TransactionalEntity;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Generated;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.annotations.Where;

import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Transient;
import java.time.LocalDate;
import java.util.List;
import java.util.Objects;

import static java.util.stream.Collectors.toList;
import static javax.persistence.CascadeType.ALL;
import static javax.persistence.FetchType.EAGER;

@Entity
@Getter
@Setter
@Builder(toBuilder = true)
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class HousePar extends TransactionalEntity {
    @ManyToOne
    @JoinColumn(name = "productId")
    private Product product;
    @NonNull
    private Boolean deleted;
    @OneToMany(mappedBy = "housePar", cascade = ALL, orphanRemoval = true, fetch = EAGER)
    @Where(clause = "type = 'HOUSE_PAR' and deleted = false")
    private List<ParValue> configValues;

    @Transient
    private ParValue parValueToday;

    public String productCode() {
        return product.getCode();
    }

    public boolean isBelongToRoom(final String portionRoom) {
        return product.getPortionRoomCode().equals(portionRoom);
    }

    public AllocatedStockHouseParResponse toAllocatedStockHousePar(
            final Integer ignoredQuantity, final LocalDate deliveryDate, final CostService costService) {

        final int quantity = parValueToday.getValue() - ignoredQuantity;
        if (quantity <= 0) {
            return null;
        }
        return AllocatedStockHouseParResponse.builder()
                .id(this.getId())
                .product(new ProductResponse(product, costService.costing(product)))
                .quantity(quantity)
                .deliveryDate(deliveryDate)
                .source(CutOrderSource.HOUSE_PAR)
                .build();
    }

    public HousePar replaceConfigValuesWith(final List<ParValue> values) {
        configValues.clear();
        values.stream()
                .map(config -> config.attachTo(this))
                .forEach(configValues::add);
        return this;
    }

    public PublishingHousePar toReporting(final LocalDate weekStartDate) {
        final List<PublishingParValue> parValues = configValues.stream()
                .map(parValue -> new PublishingParValue(parValue.getDayOfWeek(), parValue.getValue()))
                .collect(toList());

        return PublishingHousePar.builder()
                .weekStartDate(weekStartDate)
                .productCode(product.getCode())
                .productDescription(product.getDescription())
                .configValues(parValues)
                .build();
    }

    @Override
    @Generated
    public boolean equals(final Object other) {
        if (this == other) {
            return true;
        }
        if (other == null || getClass() != other.getClass()) {
            return false;
        }
        final HousePar that = (HousePar) other;

        return Objects.equals(product, that.product)
                && Objects.equals(deleted, that.deleted)
                && Objects.equals(parValueToday, that.parValueToday)
                && areHibernateListsEqual(configValues, that.configValues);
    }

    @Override
    @Generated
    public int hashCode() {
        return Objects.hash(product, deleted, configValues, parValueToday);
    }

    void markDeleted() {
        deleted = true;
        configValues.forEach(ParValue::markDelete);
    }
}
