package com.sysco.prime.housePar;

import com.sysco.prime.Reportable;
import lombok.Builder;
import lombok.Data;

import java.time.LocalDate;
import java.util.List;

@Builder
@Data
public class PublishingHousePar implements Reportable {
    private LocalDate weekStartDate;
    private String productCode;
    private String productDescription;
    private List<PublishingParValue> configValues;
}
