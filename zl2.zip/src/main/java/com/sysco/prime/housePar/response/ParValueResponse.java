package com.sysco.prime.housePar.response;

import com.sysco.prime.shared.model.ParValue;
import lombok.Data;

@Data
class ParValueResponse {
    private Long id;
    private Integer dayOfWeek;
    private Integer value;

    public ParValueResponse(final ParValue parValue) {
        id = parValue.getId();
        dayOfWeek = parValue.getDayOfWeek();
        value = parValue.getValue();
    }
}
