package com.sysco.prime.housePar;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class PublishingParValue {
    private Integer dayOfWeek;
    private Integer value;
}
