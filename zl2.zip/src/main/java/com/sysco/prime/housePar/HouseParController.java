package com.sysco.prime.housePar;

import com.sysco.prime.housePar.response.AllocatedStockHouseParResponse;
import com.sysco.prime.housePar.response.HouseParResponse;
import com.sysco.prime.product.ProductService;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import java.util.List;
import java.util.Optional;

import static java.util.stream.Collectors.toList;
import static org.springframework.http.HttpStatus.CREATED;
import static org.springframework.http.HttpStatus.NO_CONTENT;
import static org.springframework.http.HttpStatus.OK;

@RestController
@RequestMapping("/api")
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class HouseParController {
    private final HouseParService service;
    private final ProductService productService;

    @GetMapping("/house-pars")
    @ApiOperation(value = "get house pars", notes = "get all active house par")
    @Secured({"ROLE_ADMIN"})
    public List<HouseParResponse> get() {
        return service.getActiveHousePars().stream()
                .map(HouseParResponse::new)
                .collect(toList());
    }

    @GetMapping("/house-par/{productCode}")
    @ApiOperation(value = "get house par", notes = "get house par by given product code")
    @Secured({"ROLE_ADMIN"})
    public HouseParResponse get(@PathVariable("productCode") final String productCode) {
        return Optional.ofNullable(service.getExistsHousePar(productCode))
                .map(HouseParResponse::new)
                .orElse(null);
    }

    @DeleteMapping("/house-par/{productCode}")
    @ApiOperation(value = "delete house par", notes = "delete house par for given product code")
    @Secured({"ROLE_ADMIN"})
    public void delete(@PathVariable("productCode") final String productCode) {
        service.deleteHousePar(productCode);
    }

    @PostMapping("/house-pars")
    @ApiOperation(value = "create house par", notes = "create a house par")
    @ResponseStatus(CREATED)
    @Secured({"ROLE_ADMIN"})
    public void create(@Valid @RequestBody final HouseParRequest request) {
        service.createHousePar(toDomain(request));
    }

    @PutMapping("/house-pars/{id}")
    @ApiOperation(value = "update house par", notes = "update a house par")
    @ResponseStatus(NO_CONTENT)
    @Secured({"ROLE_ADMIN"})
    public void update(@Valid @RequestBody final HouseParRequest request, @PathVariable("id") final Long id) {
        service.updateHousePar(id, toDomain(request));
    }

    @GetMapping("/house-pars/grinding")
    @ApiOperation(value = "get available house par for generating grinding order",
            notes = "get available house par for generating grinding order, query by room code and par config date")
    @ResponseStatus(OK)
    @Secured({"ROLE_ADMIN", "ROLE_PORTION_ROOM_MEMBER"})
    public List<AllocatedStockHouseParResponse> getAvailableHouseParsForOrderGenerating(
            @RequestParam("room-code") final String roomCode) {
        return service.getAvailableHouseParsForOrderGenerating(roomCode);
    }

    private HousePar toDomain(final HouseParRequest request) {
        return request.toDomainWith(productService.findByCode(request.getProductCode()));
    }
}
