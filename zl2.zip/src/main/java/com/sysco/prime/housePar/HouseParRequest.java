package com.sysco.prime.housePar;

import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.sysco.prime.product.Product;
import com.sysco.prime.product.validation.NewHousePar;
import com.sysco.prime.product.validation.Positive;
import com.sysco.prime.product.validation.ValidProduct;
import com.sysco.prime.shared.model.ParValue;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.Valid;
import javax.validation.constraints.Size;
import java.util.HashMap;
import java.util.Map;

import static java.lang.Boolean.FALSE;
import static java.util.stream.Collectors.toList;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
@NewHousePar
public class HouseParRequest {
    private Long id;
    @ValidProduct(sellable = true)
    private String productCode;
    @Valid
    @Size(min = 1, max = 5, message = "LENGTH")
    private Map<String, @Positive Integer> parConfigValues;

    HousePar toDomainWith(final Product product) {
        final HousePar housePar = HousePar.builder()
                .product(product)
                .deleted(FALSE)
                .configValues(parConfigValues.entrySet().stream()
                        .map(ParValue::fromHouseParConfigValue)
                        .collect(toList()))
                .build();
        housePar.setId(id);
        return housePar;
    }

    @JsonAnySetter
    public void initParConfigValues(final String name, final Integer value) {
        if (parConfigValues == null) {
            parConfigValues = new HashMap<>();
        }
        parConfigValues.put(name, value);
    }
}
