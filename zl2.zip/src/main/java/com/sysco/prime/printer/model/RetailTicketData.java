package com.sysco.prime.printer.model;

import com.sysco.prime.box.Box;
import com.sysco.prime.box.Weighing;
import com.sysco.prime.cost.Money;
import com.sysco.prime.customer.Customer;
import com.sysco.prime.customer.DateType;
import com.sysco.prime.exception.InvalidValueException;
import com.sysco.prime.product.RetailSpecific;
import com.sysco.prime.utils.BarcodeUtils;
import lombok.Builder;
import lombok.Generated;
import lombok.RequiredArgsConstructor;
import lombok.Value;

import java.math.BigDecimal;
import java.util.Objects;

import static com.sysco.prime.utils.TimeUtils.LABEL_DATE_FORMATTER;
import static java.math.RoundingMode.HALF_UP;
import static java.util.Objects.hash;

@Builder
@RequiredArgsConstructor
@Value
public final class RetailTicketData implements PrinterSerializable {
    private final String id;
    private BigDecimal netWeight;
    private BigDecimal pricePerPound;
    private BigDecimal totalPrice;
    private String retailNumber;
    private String sellByDate;

    @Generated
    public boolean equals(final Object other) {
        if (this == other) {
            return true;
        }
        if (null == other || getClass() != other.getClass()) {
            return false;
        }

        final RetailTicketData that = (RetailTicketData) other;
        return Objects.equals(netWeight, that.netWeight)
                && Objects.equals(pricePerPound, that.pricePerPound)
                && Objects.equals(totalPrice, that.totalPrice)
                && Objects.equals(sellByDate, that.sellByDate)
                && Objects.equals(retailNumber, that.retailNumber);
    }

    @Override
    @Generated
    public int hashCode() {
        return hash(netWeight, pricePerPound, totalPrice, sellByDate, retailNumber);
    }

    public String getBarcode() {
        String removeDot = String.valueOf(getTotalPrice()).replace(".", "");
        String paddedTotalPrice = String.format("%04d", Integer.parseInt(removeDot));
        String input = retailNumber + paddedTotalPrice;
        return input + BarcodeUtils.getUpcaCheckDigit(input);
    }

    public static RetailTicketData from(final Weighing weighing, final Customer customer) {
        final Box box = weighing.getBox();
        final RetailSpecific retailInformation = box.getItemProduct().getRetailSpecific();
        if (retailInformation == null) {
            throw new InvalidValueException("Not a Retail Product");
        }

        String sellByDate = "";
        if (null != customer && customer.getDateType() == DateType.SELLBY) {
            sellByDate = box.getConsumedDate()
                    .plusDays(customer.getDateValue(box.getItemProduct()))
                    .format(LABEL_DATE_FORMATTER);
        }

        return builder()
                .id(String.valueOf(weighing.getId()))
                .netWeight(weighing.getNetWeight().setScale(2, HALF_UP))
                .pricePerPound(Money.of(retailInformation.getPrice()))
                .totalPrice(Money.of(Money.of(weighing.getNetWeight())
                        .multiply(retailInformation.getPrice())))
                .retailNumber(retailInformation.getRetailNumber())
                .sellByDate(sellByDate)
                .build();
    }
}
