package com.sysco.prime.printer.model;

import com.sysco.prime.packages.TarePackage;
import com.sysco.prime.product.GrindSpecific;
import com.sysco.prime.product.Product;
import com.sysco.prime.product.ProductPortionSize;
import com.sysco.prime.productionOrder.ProductionOrder;
import com.sysco.prime.ticket.TicketType;
import lombok.Builder;
import lombok.RequiredArgsConstructor;
import lombok.Value;

import java.time.format.DateTimeFormatter;

import static java.util.Objects.isNull;

@Builder(toBuilder = true)
@RequiredArgsConstructor
@Value
public final class GrindTicketData implements PrinterSerializable {
    public static final int TRAYS_PER_RACK = 10;

    private final String id;
    private final String blend;
    private final String productCode;
    private final ProductPortionSize productPortionSize;
    private final int totalCases;
    private final int cases;
    private final int trayNumber;
    private final int totalTrays;
    private final String tenderformText;
    private final String packInstruction;
    private final String boxDescription;
    private final String plateName;
    private final String grindTicketCode;

    public GrindTicketData(final ProductionOrder productionOrder, final Product product, final String plateName,
                           final int totalCases, final int trayNumber, final int totalTrays) {
        this.blend = product.getProductGroup().getName();
        // These are common to all orders
        id = productionOrder.getId().toString() + "_" + trayNumber;
        productCode = product.getCode();
        productPortionSize = product.getProductPortionSize();
        this.totalCases = totalCases;
        // Whereas these are aggregates
        cases = getCasesInCurrentTicket(product.getGrindSpecific().getCasesPerTray(), totalCases, trayNumber,
                totalTrays);

        final GrindSpecific grindSpecific = product.getGrindSpecific();
        tenderformText = grindSpecific.isTenderform() ? "Tenderform" : "";
        final String packInstructions = grindSpecific.getPackInstruction();
        packInstruction = checkFreshAndGas(packInstructions) ? "" : formatPackInstruction(packInstructions);
        this.plateName = null != plateName ? plateName : "";
        final TarePackage tarePackage = product.getTarePackage();
        this.boxDescription = null != tarePackage ? tarePackage.getBoxType().getBoxDescription() : "";
        this.trayNumber = trayNumber;
        this.totalTrays = totalTrays;
        this.grindTicketCode = productionOrder.getTicketCode(TicketType.GRIND_TICKET);
    }

    static int getCasesInCurrentTicket(final int casesPerTray, final int totalCases, final int ticketNumber,
                                       final int totalTickets) {
        final int casesPerRack = casesPerTray * TRAYS_PER_RACK;
        final boolean lastRack = totalCases > (casesPerRack * ticketNumber);
        return lastRack ? casesPerRack : totalCases - (casesPerRack * (totalTickets - 1));
    }

    private boolean checkFreshAndGas(final String packInstruction) {
        return "fresh,gas".equalsIgnoreCase(packInstruction);
    }

    private String formatPackInstruction(final String packInstruction) {
        return packInstruction.replace(",", " / ");
    }
}
