package com.sysco.prime.printer.model;

import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.Serializable;
import java.util.Map;

public interface PrinterSerializable extends Serializable {
    @SuppressWarnings("unchecked")
    default Map<String, Object> asMap(final ObjectMapper mapper) {
        return mapper.convertValue(this, Map.class);
    }
}
