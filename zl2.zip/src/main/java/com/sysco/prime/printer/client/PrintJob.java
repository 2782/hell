package com.sysco.prime.printer.client;

import com.sysco.prime.printer.model.PrinterSerializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Generated;

import java.util.Objects;

import static java.util.Objects.hash;

@Data
@EqualsAndHashCode
public class PrintJob {
    private final PrinterSerializable ticketData;
    private final String printerName;
}
