package com.sysco.prime.box.validation;

import com.sysco.prime.product.validation.PrimeConstraintValidator;
import com.sysco.prime.station.Station;
import com.sysco.prime.station.StationRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;

import javax.validation.ConstraintValidatorContext;
import java.util.Optional;

@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class StationCodeValidator implements PrimeConstraintValidator<ActiveStation, Integer> {
    private final StationRepository stationRepository;

    @Override
    public boolean isValid(final Integer stationCode, final ConstraintValidatorContext constraintValidatorContext) {
        final Optional<Station> station = stationRepository.findByStationCode(stationCode);

        return station.isPresent() && station.get().getPrinter() != null;
    }
}
