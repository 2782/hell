package com.sysco.prime.box.validation;

import com.sysco.prime.box.request.BoxRequest;
import com.sysco.prime.product.validation.PrimeConstraintValidator;
import com.sysco.prime.station.Station;
import com.sysco.prime.station.StationService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;

import javax.validation.ConstraintValidatorContext;

import static com.sysco.prime.validation.ValidationErrorType.USER_NOT_ASSIGNED_TO_PACKOFF_STATION;
import static com.sysco.prime.validation.ValidationErrorType.USER_NOT_ASSIGNED_TO_PACKOFF_STATION_IN_CURRENT_ROOM;

@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class PackoffUserValidator implements PrimeConstraintValidator<PackoffUser, BoxRequest> {
    private final StationService stationService;

    @Override
    public boolean isValid(final BoxRequest request, final ConstraintValidatorContext context) {

        Station currentUserStation;
        try {
            currentUserStation = stationService.getCurrentPackoffStation();
        } catch (Exception e) {
            return validationFailedBecause(context,
                    USER_NOT_ASSIGNED_TO_PACKOFF_STATION);
        }

        String roomCode = request.getRoomCode();

        if (roomCode.equals(currentUserStation.getRoom().getCode())) {
            return true;
        }

        return validationFailedBecause(context,
                USER_NOT_ASSIGNED_TO_PACKOFF_STATION_IN_CURRENT_ROOM);
    }
}
