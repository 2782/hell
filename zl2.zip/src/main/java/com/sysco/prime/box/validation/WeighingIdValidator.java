package com.sysco.prime.box.validation;

import com.sysco.prime.box.WeighingRepository;
import com.sysco.prime.product.validation.PrimeConstraintValidator;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;

import javax.validation.ConstraintValidatorContext;

@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class WeighingIdValidator implements PrimeConstraintValidator<ExistedWeighing, Long> {
    private final WeighingRepository weighingRepository;

    @Override
    public boolean isValid(final Long weighingId, final ConstraintValidatorContext constraintValidatorContext) {
        return weighingRepository.findById(weighingId).isPresent();
    }
}
