package com.sysco.prime.box;

import com.sysco.prime.Reportable;
import com.sysco.prime.customerOrder.CustomerOrder;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.time.LocalDate;
import java.time.LocalTime;

@Builder
@Data
@EqualsAndHashCode(callSuper = false)
public class PublishingBox implements Reportable {
    private boolean isFixedWeightProduct;
    private Box.Status status;
    private CustomerOrder customerOrder;
    private double cost;
    private double currentCost;
    private double weightedAverageCost;
    private double weightPerBox;
    private double labor;
    private double weight;
    private double packageTareWeight;
    private double totalTareWeight;
    private double netWeight;
    private double yieldPercentage;
    private Integer stationCode;
    private Integer tableCode;
    private LocalDate workingDate;
    private String portionSize;
    private String portionRoomCode;
    private String productCode;
    private String productDescription;
    private String packoffStationName;
    private String packoffBoxUserId;
    private String sourceProductCode;
    private String tableDescription;
    private boolean incomplete;
    private boolean byproductOnly;
    private Integer piecesPerCase;
    private String userId;

    @Override
    public String productCode() {
        return productCode;
    }
}
