package com.sysco.prime.box;

import com.sysco.prime.Reportable;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Builder
@Data
@EqualsAndHashCode(callSuper = false)
public class PublishingWipSpoil implements Reportable {
    private String productCode;
    private String productDescription;
    private double netWeight;
    private double cost;
    private Integer age;

    @Override
    public String productCode() {
        return productCode;
    }
}
