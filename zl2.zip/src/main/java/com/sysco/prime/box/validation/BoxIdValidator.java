package com.sysco.prime.box.validation;

import com.sysco.prime.box.BoxRepository;
import com.sysco.prime.product.validation.PrimeConstraintValidator;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;

import javax.validation.ConstraintValidatorContext;

@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BoxIdValidator implements PrimeConstraintValidator<ExistedBox, Long> {
    private final BoxRepository boxRepository;

    @Override
    public boolean isValid(final Long boxId, final ConstraintValidatorContext constraintValidatorContext) {
        return boxRepository.findById(boxId).isPresent();
    }
}
