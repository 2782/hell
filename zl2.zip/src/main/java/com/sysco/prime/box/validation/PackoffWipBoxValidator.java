package com.sysco.prime.box.validation;

import com.sysco.prime.box.request.WipBoxRequest;
import com.sysco.prime.product.validation.PrimeConstraintValidator;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;

import javax.validation.ConstraintValidatorContext;

import java.math.BigDecimal;

import static com.sysco.prime.validation.ValidationErrorType.LENGTH;
import static com.sysco.prime.validation.ValidationErrorType.OUT_OF_RANGE;

@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class PackoffWipBoxValidator
        implements PrimeConstraintValidator<PackoffWipBox, WipBoxRequest> {

    @Override
    public boolean isValid(final WipBoxRequest boxRequest, final ConstraintValidatorContext context) {
        if (boxRequest.getWeighings().size() > 1) {
            return validationFailedBecause(context, LENGTH);
        }

        final BigDecimal weight = boxRequest.getWeighings().get(0).getWeight();
        final BigDecimal packagingTare = boxRequest.getPackagingTare();
        final BigDecimal netWeight = weight.subtract(packagingTare);
        return !(netWeight.compareTo(BigDecimal.ZERO) < 0) || validationFailedBecause(context, OUT_OF_RANGE);
    }
}
