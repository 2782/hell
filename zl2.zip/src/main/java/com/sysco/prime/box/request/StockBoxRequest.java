package com.sysco.prime.box.request;

import com.sysco.prime.box.Box;
import com.sysco.prime.box.validation.PackoffStockBox;
import com.sysco.prime.product.ProductService;
import com.sysco.prime.product.validation.ValidProduct;
import com.sysco.prime.shared.validation.FieldChecks;
import com.sysco.prime.station.StationService;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

import javax.validation.GroupSequence;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.groups.Default;
import java.math.BigDecimal;
import java.time.Clock;
import java.util.List;

import static com.sysco.prime.box.Box.Status.AVAILABLE;
import static java.time.LocalDate.now;
import static java.util.stream.Collectors.toList;

@Data
@RequiredArgsConstructor
@Builder
@GroupSequence({FieldChecks.class, StockBoxRequest.class})
@PackoffStockBox(groups = Default.class)
public class StockBoxRequest implements BoxRequest {
    private final Integer qtyToProduce;
    @NotNull(groups = FieldChecks.class)
    @ValidProduct(groups = FieldChecks.class, finished = true, byproductOnly = true)
    private final String productCode;
    @NotNull
    private final String roomCode;
    @NotNull
    private final BigDecimal packagingTare;
    @Valid
    private final List<WeighingRequest> weighings;

    public Box toDomainForStock(final StationService stationService,
                                final ProductService productService,
                                final Clock clock) {
        final Box box = Box.builder()
                .itemProduct(productService.findByCode(productCode))
                .packagingTare(packagingTare)
                .weighings(weighings.stream()
                        .map(WeighingRequest::toDomain)
                        .collect(toList()))
                .sourceCutOrderId(null)
                .targetProductionOrder(null)
                .status(AVAILABLE)
                .incomplete(false)
                .packoffStationName(stationService.getCurrentPackoffStation().getName())
                .consumedDate(now(clock))
                .build();
        box.getWeighings().forEach(weighing -> weighing.setBox(box));
        return box;
    }
}
