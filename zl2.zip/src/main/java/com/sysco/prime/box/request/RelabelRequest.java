package com.sysco.prime.box.request;

import com.sysco.prime.box.validation.ActiveStation;
import com.sysco.prime.box.validation.ExistedBox;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.RequiredArgsConstructor;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

@Data
@RequiredArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
@EqualsAndHashCode(callSuper = false)
public class RelabelRequest {
    @Valid
    @NotNull
    @ExistedBox
    private Long reprintBoxId;

    @Valid
    @NotNull
    @ActiveStation
    private Integer stationCode;
}
