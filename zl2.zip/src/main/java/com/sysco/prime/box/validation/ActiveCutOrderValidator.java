package com.sysco.prime.box.validation;

import com.sysco.prime.box.request.CustomerBoxRequest;
import com.sysco.prime.customerOrder.CustomerOrder;
import com.sysco.prime.customerOrder.LineItem;
import com.sysco.prime.productionOrder.ProductionOrder;
import com.sysco.prime.productionOrder.ProductionOrderRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import java.util.Objects;
import java.util.Optional;

import static com.sysco.prime.productionOrder.ProductionOrderStatus.PACKED;
import static com.sysco.prime.validation.ValidationErrorType.CUT_ORDER_IS_CANCELLED;
import static com.sysco.prime.validation.ValidationErrorType.CUT_ORDER_IS_DELETED;
import static com.sysco.prime.validation.ValidationErrorType.CUT_ORDER_IS_UPDATED;

@Component
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class ActiveCutOrderValidator implements ConstraintValidator<ActiveCutOrder, CustomerBoxRequest> {
    private final ProductionOrderRepository productionOrderRepository;

    @Override
    public void initialize(final ActiveCutOrder constraintAnnotation) {
    }

    @Override
    public boolean isValid(final CustomerBoxRequest boxRequest, final ConstraintValidatorContext context) {
        final Long productionOrderId = boxRequest.getProductionOrderId();
        if (productionOrderId == null) {
            return true;
        }
        final ProductionOrder freshProductionOrder = productionOrderRepository.getOneOrNull(productionOrderId);
        return freshProductionOrder != null
                && validateCutOrderActive(freshProductionOrder, context)
                && validateCutOrderUpdated(boxRequest, freshProductionOrder, context);
    }

    private boolean validateCutOrderUpdated(
            final CustomerBoxRequest boxRequest,
            final ProductionOrder freshProductionOrder,
            final ConstraintValidatorContext context) {
        final boolean quantityUpdated = !Objects.equals(boxRequest.getQtyToProduce(),
                freshProductionOrder.getQtyToProduce());
        if (quantityUpdated && freshProductionOrder.getStatus() == PACKED) {
            setConstraintViolationMessage(context,
                    String.format("%s:%s", CUT_ORDER_IS_UPDATED, freshProductionOrder.getQtyToProduce()));
            return false;
        }
        return true;
    }

    private boolean validateCutOrderActive(final ProductionOrder freshProductionOrder,
                                           final ConstraintValidatorContext context) {
        final CustomerOrder customerOrder = freshProductionOrder.getCustomerOrder();
        if (customerOrder == null) {
            return true; // => House Par
        }
        if (customerOrder.isCancelled()) {
            setConstraintViolationMessage(context, CUT_ORDER_IS_CANCELLED.toString());
            return false;
        }

        final Optional<LineItem> sourceLineItem = customerOrder.getLineItems().stream()
                .filter(lineItem -> Objects.equals(lineItem.getId(), freshProductionOrder.getSourceId()))
                .findAny();

        if (sourceLineItem.isPresent() && sourceLineItem.get().isDeleted()) {
            setConstraintViolationMessage(context, CUT_ORDER_IS_DELETED.toString());
            return false;
        }

        return true;
    }

    private void setConstraintViolationMessage(final ConstraintValidatorContext context,
                                               final String errorType) {
        context.disableDefaultConstraintViolation();
        context.buildConstraintViolationWithTemplate(errorType)
                .addConstraintViolation();
    }
}
