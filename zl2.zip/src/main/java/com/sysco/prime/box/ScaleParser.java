package com.sysco.prime.box;

@FunctionalInterface
public interface ScaleParser {
    String readWeightFromScale();

    class ScaleException extends RuntimeException {
        ScaleException(final String reason) {
            super(reason);
        }

        ScaleException(final String reason, final Throwable cause) {
            super(reason, cause);
        }
    }
}
