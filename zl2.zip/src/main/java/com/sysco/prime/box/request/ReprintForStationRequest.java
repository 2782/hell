package com.sysco.prime.box.request;

import com.sysco.prime.box.validation.ActiveStation;
import com.sysco.prime.box.validation.ExistedWeighing;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.RequiredArgsConstructor;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

@Data
@RequiredArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
@EqualsAndHashCode(callSuper = false)
public class ReprintForStationRequest {
    @Valid
    @NotNull
    @ExistedWeighing
    private Long reprintWeightingId;

    @NotNull
    private ReprintLabelRequestType type;

    @Valid
    @NotNull
    @ActiveStation
    private Integer stationCode;
}
