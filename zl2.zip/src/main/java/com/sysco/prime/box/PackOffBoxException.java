package com.sysco.prime.box;

public class PackOffBoxException extends RuntimeException {
    public PackOffBoxException(final String message) {
        super(message);
    }
}
