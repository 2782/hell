package com.sysco.prime.box;

import com.sysco.prime.box.request.ReprintLabelRequestType;
import com.sysco.prime.cost.Cost;
import com.sysco.prime.cost.CostService;
import com.sysco.prime.customerOrder.CustomerOrder;
import com.sysco.prime.customerOrder.CustomerOrderService;
import com.sysco.prime.exception.InvalidValueException;
import com.sysco.prime.exception.NotFoundException;
import com.sysco.prime.portionRoom.PortionRoom;
import com.sysco.prime.product.Product;
import com.sysco.prime.productionOrder.ProductionOrderService;
import com.sysco.prime.purchaseOrder.PurchaseOrderService;
import com.sysco.prime.reporting.ReportingPublisher;
import com.sysco.prime.sourceMeat.PublishingSourceMeatWipReceipt;
import com.sysco.prime.station.Station;
import com.sysco.prime.station.StationService;
import com.sysco.prime.ticket.TicketService;
import com.sysco.prime.yieldModel.CuttingYieldModelService;
import com.sysco.prime.yieldModel.YieldModelBase;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.function.Function;

import static com.sysco.prime.box.Box.Status.AVAILABLE;
import static com.sysco.prime.box.Box.Status.RESERVED;
import static com.sysco.prime.validation.ValidationError.buildError;
import static com.sysco.prime.validation.ValidationErrorType.CANNOT_CHANGE;
import static java.lang.String.format;
import static java.util.Collections.emptyList;
import static java.util.Objects.isNull;
import static java.util.stream.Collectors.toList;

@Service
@Slf4j
public class BoxService {
    private final BoxRepository boxRepository;
    private final WeighingRepository weighingRepository;

    private final ProductionOrderService productionOrderService;
    private final ReportingPublisher reportingPublisher;
    private final TicketService ticketService;
    private final ScaleParser scaleParser;
    private final PurchaseOrderService purchaseOrderService;
    private final CostService costService;
    private final CuttingYieldModelService cuttingYieldModelService;
    private final CustomerOrderService customerOrderService;
    private final StationService stationService;

    public BoxService(final BoxRepository boxRepository,
                      final WeighingRepository weighingRepository,
                      final ProductionOrderService productionOrderService,
                      final ReportingPublisher reportingPublisher,
                      final TicketService ticketService,
                      final ScaleParser scaleParser,
                      final PurchaseOrderService purchaseOrderService,
                      final CostService costService,
                      final CuttingYieldModelService cuttingYieldModelService,
                      @Lazy final CustomerOrderService customerOrderService,
                      final StationService stationService) {
        this.boxRepository = boxRepository;
        this.productionOrderService = productionOrderService;
        this.weighingRepository = weighingRepository;
        this.reportingPublisher = reportingPublisher;
        this.ticketService = ticketService;
        this.scaleParser = scaleParser;
        this.purchaseOrderService = purchaseOrderService;
        this.costService = costService;
        this.cuttingYieldModelService = cuttingYieldModelService;
        this.customerOrderService = customerOrderService;
        this.stationService = stationService;
    }

    String readWeightFromScale() {
        return scaleParser.readWeightFromScale();
    }

    public Box findById(final Long boxId) {
        final Box box = boxRepository.getOneOrNull(boxId);
        if (null == box) {
            throw new NotFoundException(
                    format("[find box] box not found by id: %s", boxId));
        }
        return box;
    }

    public Weighing findByWeighingId(final Long weighingId) {
        final Weighing weighing = weighingRepository.getOneOrNull(weighingId);
        if (null == weighing) {
            throw new NotFoundException(
                    format("[find weighing] weighing not found by id: %s", weighingId));
        }
        return weighing;
    }

    Box packoffCustomerBox(
            final Box box,
            final PortionRoom portionRoom) {
        if (box.isFullBox()) {
            productionOrderService.packoffOneBox(box.getSourceCutOrderId());
        }
        if (box.isRetail()) {
            ticketService.createRetailLabel(box);
        }
        return packedOffBox(box, portionRoom);
    }

    Box packoffGenericBox(final Box box, final PortionRoom portionRoom) {
        return packedOffBox(box, portionRoom);
    }

    void printPackOffLabel(final Long packOffId) {
        final Box box = findById(packOffId);
        ticketService.createPackOffLabel(box);
    }

    private boolean isFinalWeighing(final Box box, final Long weightingId) {
        return box.isNonRetailFullBox() || (box.isPiecesPerCaseLimitReached()
                && box.getLatestWeighing().getId().equals(weightingId));
    }

    void reprintLabel(final Long reprintWeighingId, final ReprintLabelRequestType type, final Integer stationCode)
            throws InvalidValueException {
        final Weighing weighing = findByWeighingId(reprintWeighingId);
        final Box box = weighing.getBox();
        Station station;
        if (null == stationCode) {
            station = stationService.getCurrentPackoffStation();
        } else {
            station = stationService.findByStationCode(stationCode);
        }

        if (station.getRetailPrinter() == null || station.getRetailPrinter().isEmpty()) {
            throw new InvalidValueException("Retail Printer Required");
        }

        if ((type == ReprintLabelRequestType.BOX || type == ReprintLabelRequestType.BOTH)
                && (box.isIncomplete() || isFinalWeighing(box, reprintWeighingId))) {
            ticketService.reprintPackOffLabel(weighing.getBox(), station);
        }
        if ((type == ReprintLabelRequestType.RETAIL || type == ReprintLabelRequestType.BOTH) && box.isRetail()) {
            ticketService.reprintRetailLabel(weighing, station);
        }
    }

    void relabelPackOffLabel(final Long reprintBoxId, final Integer stationCode) {
        final Box box = findById(reprintBoxId);
        box.relabel();
        boxRepository.save(box);

        final Station station = stationService.findByStationCode(stationCode);
        ticketService.reprintPackOffLabel(box, station);
    }

    List<Box> getBoxes(final String productCode, final LocalDate consumedDate, final String susOrderNo) {
        if (null == susOrderNo || "".equals(susOrderNo)) {
            return boxRepository.findByConsumedDateAndItemProductCode(consumedDate, productCode);
        }

        return customerOrderService
                .findCustomerOrderByOrderNumberAndShipDate(susOrderNo, consumedDate)
                .map(customerBoxesFor(productCode))
                .orElse(emptyList());
    }

    private Function<CustomerOrder, List<Box>> customerBoxesFor(final String productCode) {
        return customerOrder -> {
            final List<Long> productionOrderIds
                    = productionOrderService.getProductionOrderIdsFor(customerOrder);

            return boxRepository.findBySourceCutOrderIdInAndItemProductCode(productionOrderIds, productCode);
        };
    }

    private Box packedOffBox(Box box, final PortionRoom portionRoom) {
        final Cost cost = costService.findCost(box.getItemProduct());

        // TODO: Move to controller validation
        assertPortionRoomOpen(box, portionRoom);
        assertCostExists(box, cost);

        box = mergeExistingPersistedBox(box);

        box = boxRepository.save(box);
        box.assignBarCode();
        box = boxRepository.save(box);

        if (box.isFullBox()) {
            reportPackedBox(box, cost, portionRoom);
            printTicketForPackedBox(box);

            if (!box.isWipBox()) {
                purchaseOrderService.createOrUpdatePurchaseOrderWithNewPackBox(box, portionRoom.getCode());
            }
        }

        return box;
    }

    private Box mergeExistingPersistedBox(Box box) {
        if (box.getId() != null) {
            final List<Weighing> newWeighingsToSave =
                    box.getWeighings().stream()
                            .filter(weighing -> weighing.getId() == null)
                            .collect(toList());
            final Box existingPersistedBox = boxRepository.getOne(box.getId());
            existingPersistedBox.setPackagingTare(box.getPackagingTare());
            newWeighingsToSave.forEach(weighing -> weighing.setBox(existingPersistedBox));
            existingPersistedBox.getWeighings().addAll(newWeighingsToSave);
            box = existingPersistedBox;
        }
        return box;
    }

    private void assertCostExists(final Box box, final Cost cost) {
        if (isNull(cost)) {
            log.warn("Attempt to pack off a box when the cost is invalid: {}", box);
            throw new PackOffBoxException("Cost is invalid");
        }
    }

    private void assertPortionRoomOpen(final Box box, final PortionRoom portionRoom) {
        if (isNull(portionRoom.getLastOpenedAt())) {
            log.warn("Attempt to pack off a box when the room is not open: {}", box);
            throw new PackOffBoxException("Room is not open");
        }
    }

    private void printTicketForPackedBox(final Box box) {
        ticketService.createPackOffLabel(box);
    }

    private void reportPackedBox(
            final Box box,
            final Cost cost,
            final PortionRoom portionRoom) {
        final String packoffBoxUserId = stationService.getCurrentPackoffStation().getUserId();
        final Product product = box.getItemProduct();
        switch (product.getProductOutput()) {
            case FINISHED:
                final YieldModelBase yieldModel = product.isCutting()
                        ? cuttingYieldModelService.findCuttingPricingModelTakingIntoAccountGroup(product)
                        : null;
                reportingPublisher.reportOn(
                        box.toReportingOnFinishedProduct(product, cost, portionRoom, yieldModel, packoffBoxUserId)
                );
                break;
            case SOURCE:
                reportingPublisher.reportOn(box.toReportingOnSourceProduct(product, cost, portionRoom));
                break;
            case BYPRODUCT_ONLY:
                reportingPublisher.reportOn(
                        box.toReportingOnByproductOnlyProduct(product, cost, portionRoom, packoffBoxUserId));
                break;
            default:
                break;
        }
    }

    List<Box> getWipBoxes() {
        return boxRepository.findByIncompleteIsTrue();
    }

    public List<Box> getAvailableWipBoxesByProductCode(final String sourceProductCode) {
        return boxRepository.findByStatusAndIncompleteIsTrueAndItemProductCode(AVAILABLE, sourceProductCode);
    }

    public Optional<Box> reserveWipBox(final Box wipBox, final PortionRoom portionRoom) {
        final Optional<Box> reservedBox = wipBox.reserve(portionRoom);
        reservedBox.ifPresent(boxRepository::save);
        return reservedBox;
    }

    public void returnReservedWipBoxes(final String roomCode) {
        final List<Box> reservedWipBoxes =
                boxRepository.findByReservedForPortionRoomCodeAndStatusAndIncompleteIsTrue(roomCode, RESERVED);
        if (!reservedWipBoxes.isEmpty()) {
            reservedWipBoxes.forEach(Box::returnWip);
            boxRepository.saveAll(reservedWipBoxes);
        }
    }

    void deleteWipBox(final long wipId) {
        boxRepository.findById(wipId).ifPresent(box -> {
            if (box.isWipBox()) {
                boxRepository.delete(box);
                reportingPublisher.reportOn(
                        box.toReportingWipSpoil(costService.costing(box.getItemProduct()))
                );
            } else {
                throw new InvalidValueException(String.format("The box %s is not a WIP box", wipId));
            }
        });
    }

    void bringWipInRoom(final String barcode, final PortionRoom portionRoom) {
        final Box box = boxRepository.findByBarcodeAndIncompleteIsTrue(barcode)
                .orElseThrow(() -> new NotFoundException(format("[find Box] with barcode %s Not Found", barcode)));
        if (box.isReserved() && !box.getReservedForPortionRoom().getCode().equals(portionRoom.getCode())) {
            throw new InvalidValueException("Box is reserved for Another room",
                    buildError("roomCode", CANNOT_CHANGE, "Update Box failed."));
        }
        final Box updatedBox = box.changeBoxStatusToInPortionRoom();
        boxRepository.save(updatedBox);

        final PublishingSourceMeatWipReceipt publishingSourceMeatReceiptItem = PublishingSourceMeatWipReceipt
                .builder()
                .weight(box.getNetWeight().doubleValue())
                .productCode(box.getProductCode())
                .portionRoomCode(portionRoom.getCode())
                .workingDate(portionRoom.getLastOpenedAt().toLocalDate())
                .build();

        reportingPublisher.reportOn(publishingSourceMeatReceiptItem);
    }

    public List<Box> findBySourceCutOrderId(final Long id) {
        return boxRepository.findBySourceCutOrderIdOrderByCreatedAtDesc(id);
    }
}
