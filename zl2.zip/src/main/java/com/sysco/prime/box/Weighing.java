package com.sysco.prime.box;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.sysco.prime.shared.model.TransactionalEntity;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.Entity;
import javax.persistence.Enumerated;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.util.Objects;

import static javax.persistence.EnumType.STRING;
import static javax.persistence.FetchType.LAZY;

@AllArgsConstructor
@Builder(toBuilder = true)
@Getter
@Setter
@Entity
@NoArgsConstructor
@ToString(exclude = "box")
public class Weighing extends TransactionalEntity {
    @ManyToOne(fetch = LAZY)
    @JoinColumn(name = "boxId")
    @JsonIgnore
    private Box box;

    @NotNull
    private BigDecimal weight;
    @NotNull
    private BigDecimal retailPieceTare;
    private Integer overrideWeightRangeReasonCode;
    @Enumerated(STRING)
    private WeighingType type;

    public BigDecimal getNetWeight() {
        return weight.subtract(retailPieceTare);
    }

    public void addTo(Box box) {
        this.box = box;
    }

    @Override
    public boolean equals(final Object other) {
        if (this == other) {
            return true;
        }
        if (other == null || getClass() != other.getClass()) {
            return false;
        }
        final Weighing weighing = (Weighing) other;
        return Objects.equals(getId(box), getId(weighing.box))
                && Objects.equals(weight, weighing.weight)
                && Objects.equals(retailPieceTare, weighing.retailPieceTare)
                && Objects.equals(overrideWeightRangeReasonCode, weighing.overrideWeightRangeReasonCode);
    }

    @Override
    public int hashCode() {
        return Objects.hash(getId(box), weight, retailPieceTare, overrideWeightRangeReasonCode);
    }

    public Long getId(final TransactionalEntity transactionalEntity) {
        return transactionalEntity == null ? null : transactionalEntity.getId();
    }
}
