package com.sysco.prime.box;

public enum WeighingType {
    BOX, RETAIL_PIECE
}
