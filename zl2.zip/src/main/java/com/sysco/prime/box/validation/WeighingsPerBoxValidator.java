package com.sysco.prime.box.validation;

import com.sysco.prime.box.request.CustomerBoxRequest;
import com.sysco.prime.exception.NotFoundException;
import com.sysco.prime.product.Product;
import com.sysco.prime.product.ProductService;
import com.sysco.prime.product.validation.PrimeConstraintValidator;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;

import javax.validation.ConstraintValidatorContext;

@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class WeighingsPerBoxValidator implements PrimeConstraintValidator<WeighingsPerBox, CustomerBoxRequest> {

    private final ProductService productService;

    @Override
    public boolean isValid(final CustomerBoxRequest request, final ConstraintValidatorContext context) {
        final String productCode = request.getProductCode();
        try {
            final Product product = productService.findByCode(productCode);
            final boolean isRetail = product.isRetail();
            if (isRetail) {
                return request.getWeighings().size() <= product.getPiecesPerCase();
            } else {
                return request.getWeighings().size() <= 1;
            }
        } catch (NotFoundException e) {
            return true;
        }
    }
}
