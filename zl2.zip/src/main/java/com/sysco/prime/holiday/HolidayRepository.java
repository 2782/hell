package com.sysco.prime.holiday;

import com.sysco.prime.PrimeRepository;

import java.time.LocalDate;

public interface HolidayRepository extends PrimeRepository<Holiday> {
    boolean existsByDate(LocalDate date);

    Holiday findById(long holidayId);
}
