package com.sysco.prime.holiday.request;

import com.sysco.prime.holiday.Holiday;
import lombok.Builder;
import lombok.Data;

import javax.validation.constraints.NotNull;
import java.time.LocalDate;

@Data
@Builder(toBuilder = true)
public class HolidayRequest {
    @NotNull
    private LocalDate date;
    @NotNull
    private String description;

    public Holiday toDomain() {
        return Holiday.builder()
                .description(description)
                .date(date)
                .build();
    }
}
