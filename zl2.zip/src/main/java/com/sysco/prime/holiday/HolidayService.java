package com.sysco.prime.holiday;

import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

import static java.util.Comparator.comparing;

@Service
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class HolidayService {
    private final HolidayRepository repository;

    public List<Holiday> allHolidays() {
        final List<Holiday> holidays = repository.findAll();
        holidays.sort(comparing(Holiday::getDate));
        return holidays;
    }

    public Holiday newHoliday(final Holiday holiday) {
        return repository.save(holiday);
    }

    public void deleteHoliday(final Long holidayId) {
        repository.deleteById(holidayId);
    }

    public Boolean isHoliday(final LocalDate date) {
        return repository.existsByDate(date);
    }

    public Holiday editHoliday(final Holiday holiday, final long holidayId) {
        Holiday existingHoliday = repository.findById(holidayId);

        existingHoliday.updateHoliday(holiday);
        return repository.save(existingHoliday);
    }
}
