package com.sysco.prime.holiday;

import com.sysco.prime.exception.InvalidValueException;
import com.sysco.prime.holiday.request.HolidayRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.net.URI;
import java.time.Clock;
import java.util.List;

import static com.sysco.prime.validation.ValidationError.buildError;
import static com.sysco.prime.validation.ValidationErrorType.INVALID;
import static java.lang.String.format;
import static java.time.LocalDate.now;
import static org.springframework.http.ResponseEntity.created;
import static org.springframework.http.ResponseEntity.noContent;
import static org.springframework.http.ResponseEntity.ok;

@RestController
@RequestMapping("/api")
@Secured({"ROLE_ADMIN"})
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class HolidayController {
    private final HolidayService service;
    private final Clock when;

    @GetMapping("/holidays")
    public ResponseEntity<List<Holiday>> getHolidays() {
        final List<Holiday> holidays = service.allHolidays();
        return ok(holidays);
    }

    @PostMapping("/holiday")
    public ResponseEntity<?> createHoliday(@RequestBody final HolidayRequest holiday) {
        if (service.isHoliday(holiday.getDate()) || holiday.getDate().isBefore(now(when))) {
            throw new InvalidValueException("Invalid date",
                    buildError("holiday", INVALID, "Invalid date"));
        }

        final Holiday createdHoliday = service.newHoliday(holiday.toDomain());
        final URI location = URI.create(format("/api/holiday/%d", createdHoliday.getId()));

        return created(location).body(createdHoliday);
    }

    @DeleteMapping("/holiday/{holidayId}")
    public ResponseEntity<?> deleteHoliday(@PathVariable("holidayId") final long holidayId) {
        service.deleteHoliday(holidayId);
        return noContent().build();
    }

    @PostMapping("/holiday/edit/{holidayId}")
    public Boolean editHoliday(@RequestBody final HolidayRequest holiday,
                                         @PathVariable("holidayId") final long holidayId) {
        Holiday officialHolidayObject = holiday.toDomain();
        Holiday updatedHoliday = service.editHoliday(officialHolidayObject, holidayId);

        return updatedHoliday != null;
    }
}
