package com.sysco.prime.product.validation;

import org.springframework.stereotype.Component;

import javax.validation.ConstraintValidatorContext;

import static com.sysco.prime.validation.ValidationErrorType.NUMERIC;
import static com.sysco.prime.validation.ValidationErrorType.REQUIRED;

@Component
public class PositiveNumberStringValidator implements PrimeConstraintValidator<PositiveNumberString, String> {
    private boolean checkRequired;

    @Override
    public void initialize(final PositiveNumberString constraintAnnotation) {
        checkRequired = constraintAnnotation.required();
    }

    @Override
    public boolean isValid(final String value, final ConstraintValidatorContext context) {
        if (null == value) {
            if (checkRequired) {
                return validationFailedBecause(context, REQUIRED);
            } else {
                return true;
            }
        }

        try {
            Double doubleValue = Double.parseDouble(value);
            return doubleValue > 0D;
        } catch (NumberFormatException ex) {
            return validationFailedBecause(context, NUMERIC);
        }
    }
}
