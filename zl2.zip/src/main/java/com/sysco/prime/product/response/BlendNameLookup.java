package com.sysco.prime.product.response;

import com.sysco.prime.productionOrder.response.BlendResponse;
import lombok.Builder;
import lombok.Value;

import static com.sysco.prime.product.response.BlendOrProductLookup.BLEND;

@Value
@Builder
public class BlendNameLookup implements NameLookup {
    private final BlendOrProductLookup type = BLEND;
    private final BlendResponse blend;

    public BlendNameLookup(final BlendResponse blend) {
        this.blend = blend;
    }

    public BlendNameLookup() {
        this.blend = null;
    }
}
