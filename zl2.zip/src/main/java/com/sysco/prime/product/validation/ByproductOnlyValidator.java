package com.sysco.prime.product.validation;

import com.sysco.prime.product.Product;
import com.sysco.prime.product.ProductService;
import com.sysco.prime.product.request.ProductSetupRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.validation.ConstraintValidatorContext;

import static com.sysco.prime.validation.ValidationErrorType.CANNOT_CHANGE;
import static com.sysco.prime.validation.ValidationErrorType.IN_PRODUCT_GROUP;
import static com.sysco.prime.validation.ValidationErrorType.PIECES_PACKAGE_REQUIRED;

@Component
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class ByproductOnlyValidator
        implements PrimeConstraintValidator<ValidByproductOnly, ProductSetupRequest> {
    private final ProductService productService;

    public boolean isValid(ProductSetupRequest request, ConstraintValidatorContext context) {
        final Product product = productService.findByCode(request.getProductCode());

        if (isUnsettingByproductOnly(product, request)) {
            return validationFailedBecause(context, CANNOT_CHANGE);
        }

        if (isSettingWhenHasProductGroup(product, request)) {
            return validationFailedBecause(context, IN_PRODUCT_GROUP);
        }

        if (request.isByproductOnly()) {
            return request.getByproductOnlyCost() != null;
        }

        if (request.getPiecesPackageId() == null) {
            return validationFailedBecause(context, PIECES_PACKAGE_REQUIRED);
        }

        return true;
    }

    private boolean isSettingWhenHasProductGroup(final Product product, final ProductSetupRequest request) {
        return product.isGrouped() && request.isByproductOnly();
    }

    private boolean isUnsettingByproductOnly(final Product product, final ProductSetupRequest request) {
        return product.isByproductOnlyOutput() && !request.isByproductOnly();
    }
}
