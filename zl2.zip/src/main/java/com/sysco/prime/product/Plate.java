package com.sysco.prime.product;

import com.sysco.prime.shared.model.TransactionalEntity;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import javax.persistence.Entity;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Builder(toBuilder = true)
@EqualsAndHashCode(callSuper = false)
public class Plate extends TransactionalEntity {
    private String type;
    private int weight;
    private String unit;

    public String generatePlateName() {
        final String plateType = this.type.substring(0, 1).toUpperCase() + this.type.substring(1).toLowerCase();

        return String.format("%d%s %s", this.weight, this.unit.toLowerCase(), plateType);
    }
}
