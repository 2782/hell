package com.sysco.prime.product.validation;

import com.sysco.prime.product.request.GenericProductGroupRequest;

import javax.validation.ConstraintValidatorContext;
import java.util.HashSet;
import java.util.Set;

import static com.sysco.prime.validation.ValidationErrorType.UNIQUE;

public class NoDuplicateProductsValidator implements
        PrimeConstraintValidator<NoDuplicateProducts, GenericProductGroupRequest> {

    @Override
    public boolean isValid(final GenericProductGroupRequest request, final ConstraintValidatorContext context) {
        Set<String> uniqueCodes = new HashSet<>(request.getFinishedProductCodes());

        boolean duplicateFound =
                uniqueCodes.size() != request.getFinishedProductCodes().size()
                        || request.getFinishedProductCodes().stream()
                        .anyMatch(code1 -> request.getProductGroupName().equals(code1));

        if (duplicateFound) {
            context.disableDefaultConstraintViolation();
            context.buildConstraintViolationWithTemplate(UNIQUE.name())
                    .addPropertyNode("productGroupRequest")
                    .addConstraintViolation();
            return false;
        }

        return true;
    }
}
