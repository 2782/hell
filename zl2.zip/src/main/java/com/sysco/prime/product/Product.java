package com.sysco.prime.product;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.sysco.prime.exception.InvalidValueException;
import com.sysco.prime.packages.PiecesPackage;
import com.sysco.prime.packages.TarePackage;
import com.sysco.prime.portionRoomTable.PortionRoomTable;
import com.sysco.prime.product.response.ProductGroupSerializer;
import com.sysco.prime.productionOrder.ProductionType;
import com.sysco.prime.productionOrder.TableForCutOrderSerializer;
import com.sysco.prime.shared.model.TransactionalEntity;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

import javax.persistence.CascadeType;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Transient;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.util.List;
import java.util.StringJoiner;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import static com.sysco.prime.product.ProductCategory.CATCH;
import static com.sysco.prime.product.ProductCategory.FIXED;
import static com.sysco.prime.product.ProductOutput.BYPRODUCT_ONLY;
import static com.sysco.prime.product.ProductOutput.FINISHED;
import static com.sysco.prime.product.ProductOutput.SOURCE;
import static com.sysco.prime.productionOrder.ProductionType.CUTTING;
import static com.sysco.prime.productionOrder.ProductionType.GRINDING;
import static com.sysco.prime.validation.ValidationError.buildError;
import static com.sysco.prime.validation.ValidationErrorType.IN_PRODUCT_GROUP;
import static java.util.Collections.singletonList;
import static java.util.Objects.nonNull;
import static java.util.regex.Pattern.CASE_INSENSITIVE;
import static javax.persistence.EnumType.STRING;
import static javax.persistence.FetchType.EAGER;

@AllArgsConstructor
@Data
@Builder(toBuilder = true)
@Entity
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
public class Product extends TransactionalEntity {
    private static final String ERROR_MESSAGE = "Saving product group failed.";
    @SuppressWarnings("NullableProblems")
    @NotNull
    private String code;
    @SuppressWarnings("NullableProblems")
    @NotNull
    private String description;
    @Enumerated(STRING)
    private ProductOutput productOutput;
    private boolean shipSplitOnly;
    @ManyToOne(fetch = EAGER)
    @JoinColumn(name = "tableId")
    @JsonSerialize(using = TableForCutOrderSerializer.class)
    private PortionRoomTable table;
    @ManyToOne(fetch = EAGER)
    @JoinColumn(name = "productGroupId")
    @JsonSerialize(using = ProductGroupSerializer.class)
    private ProductGroup productGroup;
    @Enumerated(STRING)
    private ProductCategory category;
    private BigDecimal minWeight;
    private BigDecimal maxWeight;
    @Embedded
    private ProductPortionSize productPortionSize;
    private Double weightPerBox;
    private String vendorNumber;
    private String vendorName;
    private String subPrimalCode;
    private String subPrimalDescription;
    private String usdaGrade;
    private String instructions;
    private String storageCode;
    private String ingredientsStatement;
    private String labelProductDescription;
    @Embedded
    private GrindSpecific grindSpecific;
    @Embedded
    private CutSpecific cutSpecific;
    @OneToOne(
            cascade = CascadeType.ALL,
            fetch = FetchType.EAGER,
            targetEntity = RetailSpecific.class,
            mappedBy = "product"
    )
    private RetailSpecific retailSpecific;
    @ManyToOne
    @JoinColumn(name = "tarePackageId")
    private TarePackage tarePackage;
    @ManyToOne
    @JoinColumn(name = "piecesPackageId")
    private PiecesPackage piecesPackage;
    private Long gtin;
    private boolean boneguard;
    private boolean allocateParToBroadline;
    @Enumerated(STRING)
    private SpecialDiet specialDiet;
    @ManyToMany(fetch = FetchType.EAGER, cascade = {CascadeType.PERSIST, CascadeType.MERGE})
    @JoinTable(
            name = "productAllergens",
            joinColumns = @JoinColumn(name = "productId"),
            inverseJoinColumns = @JoinColumn(name = "allergenId")
    )
    @Fetch(FetchMode.SUBSELECT)
    private List<Allergen> allergens;

    @JsonIgnore
    public boolean isCompleteFromSus() {
        if (null == description
                || null == vendorNumber
                || null == vendorName
                || null == storageCode
                || null == productPortionSize
                || null == productPortionSize.getPiecesPerCase()
                || null == productPortionSize.getPortionSize()
                || productPortionSize.getPortionSize().trim().startsWith("0")
                || null == gtin) {
            return false;
        }
        return true;
    }

    @JsonIgnore
    public boolean isFixedWeight() {
        return FIXED.equals(category);
    }

    @JsonIgnore
    public boolean isCatchWeight() {
        return CATCH.equals(category);
    }

    @JsonIgnore
    public String getPortionRoomCode() {
        return table.getStation().getRoom().getCode();
    }

    @JsonIgnore
    public Double getLbsPortionSize() {
        return weightPerBox / getProductPortionSize().getPiecesPerCase();
    }

    @JsonIgnore
    public String getPrinterName() {
        return table.getStation().getPrinter();
    }

    @JsonIgnore
    public Integer getPiecesPerCase() {
        return productPortionSize.getPiecesPerCase();
    }

    @JsonIgnore
    void assignToTable(final PortionRoomTable table) {
        this.table = table;
    }

    @JsonIgnore
    public boolean isFinishedProductOutput() {
        return productOutput == FINISHED;
    }

    @JsonIgnore
    public boolean isSourceProductOutput() {
        return productOutput == SOURCE;
    }

    @JsonIgnore
    public boolean isByproductOnlyOutput() {
        return productOutput == BYPRODUCT_ONLY;
    }

    @JsonIgnore
    @Transient
    public boolean isGrouped() {
        return null != productGroup;
    }

    @JsonIgnore
    @Transient
    public boolean isGroupPrimary() {
        return isGrouped() && productGroup.isPrimaryProduct(this);
    }

    void addTo(final ProductGroup productGroup) {
        if (isGrouped()) {
            throw new InvalidValueException("finished products member of another group",
                    buildError("finishedProductCode", IN_PRODUCT_GROUP, ERROR_MESSAGE, code));
        }

        this.productGroup = productGroup;
    }

    void removeFromGroup() {
        productGroup = null;
    }

    @JsonIgnore
    public String getPrimaryProductCode() {
        return null == productGroup ? code : productGroup.primaryProductCode();
    }

    @JsonIgnore
    public String getPaddedGtin() {
        return String.format("%014d", gtin);
    }

    @JsonIgnore
    public List<Product> getMemberProductsInSameGroup() {
        if (isGrouped()) {
            return productGroup.getMemberProducts();
        } else {
            return singletonList(this);
        }
    }

    public Product ungroupedCopy() {
        final Product copy = toBuilder().build();
        copy.removeFromGroup();
        copy.setId(getId());
        copy.setCreatedAt(getCreatedAt());
        return copy;
    }

    public ProductionType getProductionType() {
        return table == null ? null : table.getProductionType();
    }

    @JsonIgnore
    @Transient
    public boolean isCutting() {
        return CUTTING.equals(getProductionType());
    }

    @JsonIgnore
    @Transient
    public boolean isGrinding() {
        return GRINDING.equals(getProductionType());
    }

    @JsonIgnore
    @Transient
    public String getCostName() {
        return null == productGroup ? code : productGroup.getName();
    }

    @JsonIgnore
    @Transient
    public boolean isPrimeComplete() {
        return (productOutput == ProductOutput.FINISHED && isGrouped() || productOutput == BYPRODUCT_ONLY)
                && null != table
                && null != minWeight
                && null != maxWeight;
    }

    @Override
    public String toString() {
        return new StringJoiner(", ", Product.class.getSimpleName() + "[", "]")
                .add("code='" + code + "'")
                .add("description='" + description + "'")
                .add("productOutput=" + productOutput)
                .add("table=" + (null == table ? null : "'" + table.getTableDescription() + "'"))
                .add("productGroup=" + (null == productGroup ? null : "'" + productGroup.getName() + "'"))
                .add("category=" + category)
                .add("minWeight=" + minWeight)
                .add("maxWeight=" + maxWeight)
                .add("productPortionSize=" + productPortionSize)
                .add("weightPerBox=" + weightPerBox)
                .add("vendorNumber='" + vendorNumber + "'")
                .add("vendorName='" + vendorName + "'")
                .add("subPrimalCode='" + subPrimalCode + "'")
                .add("subPrimalDescription='" + subPrimalDescription + "'")
                .add("usdaGrade='" + usdaGrade + "'")
                .add("instructions='" + instructions + "'")
                .add("cutSpecific=" + cutSpecific)
                .add("grindSpecific=" + grindSpecific)
                .add("retailSpecific=" + retailSpecific)
                .add("tarePackage=" + tarePackage)
                .add("piecesPackage=" + piecesPackage)
                .add("boneguard=" + boneguard)
                .add("allocateParToBroadline=" + allocateParToBroadline)
                .add("ingredientsStatement=" + ingredientsStatement)
                .add("labelProductDescription=" + labelProductDescription)
                .add("specialDiet=" + specialDiet)
                .add("shipSplitOnly=" + shipSplitOnly)
                .add("storageCode=" + storageCode)
                .add("allergens=" + (null == allergens ? "[]" :
                        "[" + allergens.stream()
                                .map(Allergen::getDisplayName)
                                .collect(Collectors.joining(", ")) + "]"))
                .add("gtin=" + gtin)
                .toString();
    }

    @JsonIgnore
    @Transient
    boolean isDescriptionMatch(final String descriptionRegex) {
        final Pattern pattern = Pattern.compile(descriptionRegex, CASE_INSENSITIVE);
        return pattern.matcher(description).matches();
    }

    public void setRetailSpecific(final RetailSpecific retailSpecific) {
        if (nonNull(retailSpecific)) {
            retailSpecific.setProduct(this);

            if (this.retailSpecific != null) {
                retailSpecific.setId(this.retailSpecific.getId());
                retailSpecific.setCreatedAt(this.retailSpecific.getCreatedAt());
            }
        }

        this.retailSpecific = retailSpecific;
    }

    public boolean isRetail() {
        return retailSpecific != null;
    }

    public BigDecimal getRetailMinWeight() {
        if (!isRetail()) {
            return null;
        }
        return retailSpecific.getMinWeight();
    }

    public BigDecimal getRetailMaxWeight() {
        if (!isRetail()) {
            return null;
        }
        return retailSpecific.getMaxWeight();
    }
}
