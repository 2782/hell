package com.sysco.prime.product.response;

import com.sysco.prime.blend.BlendService;
import com.sysco.prime.product.ProductGroup;
import com.sysco.prime.productionOrder.ProductionType;
import com.sysco.prime.productionOrder.response.BlendResponse;
import lombok.Value;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import static com.sysco.prime.productionOrder.ProductionType.GRINDING;

@Value
public class GroupLookup {
    private final ProductionType type;
    private final String name;
    private final ProductResponse primaryProduct;
    private final BlendResponse blend;
    private final List<ProductResponse> memberProducts;

    public GroupLookup(final ProductGroup productGroup, final BlendService blendService) {
        name = productGroup.getName();
        primaryProduct = Optional.ofNullable(productGroup.getPrimaryProduct())
                .map(ProductResponse::new)
                .orElse(null);
        // TODO: should group reference blend id?
        blend = productGroup.type() == GRINDING
                ? new BlendResponse(blendService.getBlend(productGroup.getName()))
                : null;
        memberProducts = productGroup.getMemberProducts().stream()
                .map(ProductResponse::new)
                .collect(Collectors.toList());
        type = productGroup.type();
    }
}
