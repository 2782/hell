package com.sysco.prime.product.validation;

import com.sysco.prime.cost.Cost;
import com.sysco.prime.cost.CostService;
import com.sysco.prime.product.Product;
import com.sysco.prime.product.ProductService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.validation.ConstraintValidatorContext;

import static com.sysco.prime.validation.ValidationErrorType.INVALID_COST;

@Component
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class CostValidator implements PrimeConstraintValidator<ValidCost, String> {
    private final ProductService productService;
    private final CostService costService;

    @Override
    public boolean isValid(final String value, final ConstraintValidatorContext context) {
        final Product sourceProduct = productService.findByCode(value);
        final Cost sourceProductCost = costService.findCost(sourceProduct);
        if (null == sourceProductCost) {
            return validationFailedBecause(context, INVALID_COST);
        }
        return true;
    }
}
