package com.sysco.prime.product;

import com.sysco.prime.PrimeRepository;

import java.util.Optional;

public interface PlateAssociationRepository extends PrimeRepository<PlateAssociation> {
    Optional<PlateAssociation> findByModelNumber(String modelNumber);
}
