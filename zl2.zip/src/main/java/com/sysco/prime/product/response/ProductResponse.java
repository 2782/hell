package com.sysco.prime.product.response;

import com.sysco.prime.cost.Cost;
import com.sysco.prime.cost.Costing;
import com.sysco.prime.packages.PiecesPackageResponse;
import com.sysco.prime.packages.TarePackageResponse;
import com.sysco.prime.portionRoomTable.response.PortionRoomTableResponse;
import com.sysco.prime.product.CutSpecific;
import com.sysco.prime.product.GrindSpecific;
import com.sysco.prime.product.Product;
import com.sysco.prime.product.ProductCategory;
import com.sysco.prime.product.ProductOutput;
import com.sysco.prime.product.ProductPortionSize;
import com.sysco.prime.product.SpecialDiet;
import com.sysco.prime.yieldModel.CuttingYieldModel;
import lombok.AllArgsConstructor;
import lombok.Data;

import java.math.BigDecimal;
import java.util.List;
import java.util.stream.Collectors;

import static java.util.Objects.nonNull;

@AllArgsConstructor
@Data
public class ProductResponse {
    private final Long id;
    private final String code;
    private final String description;
    private final ProductOutput productOutput;
    private final ProductCategory category;
    private final BigDecimal minWeight;
    private final BigDecimal maxWeight;
    private final ProductPortionSize productPortionSize;
    private final Double weightPerBox;
    private final String vendorName;
    private final String subPrimalCode;
    private final String ingredientsStatement;
    private final String labelProductDescription;
    private final boolean boneguard;
    private final boolean allocateParToBroadline;
    private final GrindSpecific grindSpecific;
    private final CutSpecific cutSpecific;
    private RetailSpecificResponse retailSpecific;
    private PortionRoomTableResponse table;
    private ProductGroupResponse productGroup;
    private Double cost;
    private Double marketCost;
    private Double labor;
    private Double packaging;
    private Double overhead;
    private TarePackageResponse tarePackage;
    private PiecesPackageResponse piecesPackage;
    private SpecialDiet specialDiet;
    private List<AllergenResponse> allergens;

    public ProductResponse(final Product product, final Costing costing) {
        this(product);
        if (costing != null) {
            this.cost = costing.getCurrentCost();
            this.labor = costing.getLabor();
        }
    }

    public ProductResponse(final Product product,
                           final Cost cost,
                           final CuttingYieldModel pricingModel) {
        this(product);
        if (cost != null) {
            this.cost = cost.getCurrentCostPerPound() == null ? null : cost.getCurrentCostPerPound().doubleValue();
            this.marketCost = cost.getMarketCost() == null ? null : cost.getMarketCost().doubleValue();
            this.labor = cost.getLabor().doubleValue();
        }
        if (pricingModel != null) {
            this.packaging = pricingModel.getPackaging().doubleValue();
            this.overhead = pricingModel.getOverhead().doubleValue();
        }
    }

    public ProductResponse(final Product product) {
        id = product.getId();
        code = product.getCode();
        category = product.getCategory();
        vendorName = product.getVendorName();
        description = product.getDescription();
        productOutput = product.getProductOutput();
        maxWeight = product.getMaxWeight();
        minWeight = product.getMinWeight();
        productPortionSize = product.getProductPortionSize();
        subPrimalCode = product.getSubPrimalCode();
        weightPerBox = product.getWeightPerBox();
        boneguard = product.isBoneguard();
        allocateParToBroadline = product.isAllocateParToBroadline();
        grindSpecific = product.getGrindSpecific();
        ingredientsStatement = product.getIngredientsStatement();
        labelProductDescription = product.getLabelProductDescription();
        cutSpecific = product.getCutSpecific();
        specialDiet = product.getSpecialDiet();

        if (nonNull(product.getRetailSpecific())) {
            retailSpecific = new RetailSpecificResponse(product.getRetailSpecific());
        }

        if (nonNull(product.getTable())) {
            table = new PortionRoomTableResponse(product.getTable());
        }

        if (nonNull(product.getProductGroup())) {
            productGroup = new ProductGroupResponse(product.getProductGroup());
        }

        if (nonNull(product.getTarePackage())) {
            tarePackage = new TarePackageResponse(product.getTarePackage());
        }

        if (nonNull(product.getPiecesPackage())) {
            piecesPackage = new PiecesPackageResponse(product.getPiecesPackage());
        }

        if (nonNull(product.getAllergens())) {
            allergens = product.getAllergens()
                    .stream()
                    .map(AllergenResponse::new)
                    .collect(Collectors.toList());
        }
    }
}
