package com.sysco.prime.product.request;

import com.sysco.prime.product.Product;
import com.sysco.prime.product.ProductGroup;
import com.sysco.prime.product.ProductService;
import com.sysco.prime.product.validation.HasGrindingPricingModel;
import com.sysco.prime.product.validation.ValidBlendName;
import com.sysco.prime.product.validation.ValidProduct;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.util.List;

import static com.sysco.prime.product.ProductGroup.grindingProductGroup;

@Data
@RequiredArgsConstructor
@Builder
public class GrindingProductGroupRequest implements ProductGroupRequest {
    @ValidBlendName
    @HasGrindingPricingModel
    private final String productGroupName; // blend
    @Valid
    @NotNull
    private final List<@ValidProduct(finished = true) String> finishedProductCodes;

    public ProductGroup toDomain(final ProductService productService) {
        final ProductGroup productGroup = grindingProductGroup(productGroupName);
        finishedProductCodes.stream()
                .map(productService::findByCode)
                .map(Product::ungroupedCopy)
                .forEach(productGroup::add);
        return productGroup;
    }
}
