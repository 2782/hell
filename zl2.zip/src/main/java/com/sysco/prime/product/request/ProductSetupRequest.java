package com.sysco.prime.product.request;

import com.sysco.prime.packages.PiecesPackage;
import com.sysco.prime.packages.TarePackage;
import com.sysco.prime.portionRoomTable.PortionRoomTable;
import com.sysco.prime.product.Allergen;
import com.sysco.prime.product.Product;
import com.sysco.prime.product.ProductSetup;
import com.sysco.prime.product.SpecialDiet;
import com.sysco.prime.product.validation.HasGrindSize;
import com.sysco.prime.product.validation.Positive;
import com.sysco.prime.product.validation.RequiredRetailFields;
import com.sysco.prime.product.validation.ValidAllergen;
import com.sysco.prime.product.validation.ValidByproductOnly;
import com.sysco.prime.product.validation.ValidWeight;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.util.List;

import static java.util.Collections.emptyList;

@HasGrindSize
@RequiredRetailFields
@Data
@RequiredArgsConstructor
@Builder
@ValidWeight
@ValidByproductOnly
public class ProductSetupRequest {
    // TODO: @ValidProduct instead?
    @NotNull
    private final String productCode;
    @NotNull
    private final Integer tableCode;
    // TODO: Why can tarePackageId be null, but not the others??
    private final Long tarePackageId;
    private final Long piecesPackageId;
    private final boolean boneguard;
    private final boolean allocateParToBroadline;
    private final boolean byproductOnly;
    private final String ingredientsStatement;
    private final String labelProductDescription;
    private final String tenderized;
    private final String specialDiet;

    @Positive(required = false)
    private final BigDecimal minWeight;

    @Positive(required = false)
    private final BigDecimal maxWeight;

    @Positive(required = false)
    private final BigDecimal fixWeight;

    @Positive(required = false, zeroInclusive = true)
    private final BigDecimal byproductOnlyCost;

    @Valid
    private final GrindSpecificRequest grindSpecific;
    @Valid
    private final RetailSpecificRequest retailSpecific;
    private final CutSpecificRequest cutSpecific;

    @Valid
    private final List<@ValidAllergen String> allergens;

    public ProductSetup toDomain(final Product product,
                                 final TarePackage tarePackage,
                                 final PortionRoomTable portionRoomTable,
                                 final PiecesPackage piecesPackage,
                                 final TarePackage retailSpecificTarePackage,
                                 final List<Allergen> allergens) {
        BigDecimal maxWeight = getMaxWeight();
        BigDecimal minWeight = getMinWeight();

        if (product.isFixedWeight()) {
            maxWeight = minWeight = getFixWeight();
        }

        return ProductSetup.builder()
                .product(product)
                .table(portionRoomTable)
                .tarePackage(tarePackage)
                .piecesPackage(piecesPackage)
                .byproductOnly(byproductOnly)
                .byproductOnlyCost(byproductOnlyCost)
                .retailSpecific(null != retailSpecific ? retailSpecific.toDomain(retailSpecificTarePackage) : null)
                .grindSpecific(null != grindSpecific ? grindSpecific.toDomain() : null)
                .cutSpecific(null != cutSpecific ? cutSpecific.toDomain() : null)
                .maxWeight(maxWeight)
                .minWeight(minWeight)
                .boneguard(isBoneguard())
                .allocateParToBroadline(isAllocateParToBroadline())
                .ingredientsStatement(getIngredientsStatement())
                .labelProductDescription(getLabelProductDescription())
                .specialDiet(null != specialDiet ? SpecialDiet.valueOf(specialDiet.toUpperCase()) : SpecialDiet.NONE)
                .allergens(null != allergens ? allergens : emptyList())
                .build();
    }

    public Long getRetailSpecificTareId() {
        return null != retailSpecific
                ? retailSpecific.getTare() : null;
    }
}
