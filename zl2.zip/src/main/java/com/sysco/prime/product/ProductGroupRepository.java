package com.sysco.prime.product;

import com.sysco.prime.PrimeRepository;

import java.util.Optional;

public interface ProductGroupRepository extends PrimeRepository<ProductGroup> {
    Optional<ProductGroup> findByName(String productGroupName);
}
