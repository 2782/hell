package com.sysco.prime.product.request;

import com.sysco.prime.packages.TarePackage;
import com.sysco.prime.product.RetailSpecific;
import lombok.Builder;
import lombok.Data;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Positive;
import javax.validation.constraints.Size;
import java.math.BigDecimal;

@Data
@Builder
public class RetailSpecificRequest {
    @Positive
    private final BigDecimal price;
    @Positive
    private final Long tare;
    @Positive
    private final BigDecimal minWeight;
    @Positive
    private final BigDecimal maxWeight;
    @NotNull
    @Size(min = 1, max = 8)
    @Pattern(regexp = "[0-9]*")
    private final String retailNumber;

    public RetailSpecific toDomain(final TarePackage tarePackage) {
        return RetailSpecific.builder()
                .price(price)
                .tare(tarePackage)
                .minWeight(minWeight)
                .maxWeight(maxWeight)
                .retailNumber(retailNumber)
                .build();
    }
}
