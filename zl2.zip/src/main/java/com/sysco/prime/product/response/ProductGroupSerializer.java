package com.sysco.prime.product.response;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.ser.std.StdSerializer;
import com.sysco.prime.product.ProductGroup;

import java.io.IOException;

public class ProductGroupSerializer extends StdSerializer<ProductGroup> {
    protected ProductGroupSerializer() {
        super(ProductGroup.class);
    }

    @Override
    public void serialize(final ProductGroup productGroup, final JsonGenerator gen,
                          final SerializerProvider provider) throws IOException {
        gen.writeObject(new ProductGroupResponse(productGroup));
    }
}
