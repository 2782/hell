package com.sysco.prime.product.validation;

import javax.validation.Constraint;
import javax.validation.Payload;
import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import static java.lang.annotation.ElementType.FIELD;
import static java.lang.annotation.ElementType.PARAMETER;
import static java.lang.annotation.ElementType.TYPE_USE;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

@Constraint(validatedBy = {ValidProductValidator.class})
@Documented
@Target({FIELD, TYPE_USE, PARAMETER})
@Retention(RUNTIME)
public @interface ValidProduct {
    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};

    String message() default "";

    /** Requires the product to exist.  Set to {@code false} when setting up a new product. */
    boolean exists() default true;

    /** Requires the product to be a source item.  Implies {@link #exists()} {@code false}. */
    boolean source() default false;

    /** Requires the product to be a finished item.  Implies {@link #exists()} {@code true}. */
    boolean finished() default false;

    /** Requires the product to be a byproductOnly item. Implies {@link #exists()} {@code true}. */
    boolean byproductOnly() default false;

    /** Requires the product to have a pricing model.  Implies {@link #finished()} {@code true}. */
    boolean sellable() default false;

    /** Configures the validator to not update incomplete product information with data from SUS */
    boolean nosus() default false;
}
