package com.sysco.prime.product.validation;

import com.sysco.prime.cost.CostService;
import com.sysco.prime.exception.NotFoundException;
import com.sysco.prime.product.Product;
import com.sysco.prime.product.ProductService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.validation.ConstraintValidatorContext;
import java.util.regex.Pattern;

import static com.sysco.prime.product.ProductService.formatProductCode;
import static com.sysco.prime.validation.ValidationErrorType.INVALID;
import static com.sysco.prime.validation.ValidationErrorType.NOT_EXIST;
import static com.sysco.prime.validation.ValidationErrorType.PRODUCT_IS_BYPRODUCT_ONLY_ITEM;
import static com.sysco.prime.validation.ValidationErrorType.PRODUCT_IS_NOT_A_SOURCE_ITEM;
import static com.sysco.prime.validation.ValidationErrorType.PRODUCT_IS_NOT_PRODUCTION_ITEM;
import static com.sysco.prime.validation.ValidationErrorType.PRODUCT_IS_PRODUCTION_ITEM;
import static com.sysco.prime.validation.ValidationErrorType.PRODUCT_LACKS_PRICING_MODEL;
import static com.sysco.prime.validation.ValidationErrorType.REQUIRED;

@Component
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class ValidProductValidator implements PrimeConstraintValidator<ValidProduct, String> {
    private static final Pattern PRODUCT_CODE = Pattern.compile("\\d{7}");

    private final ProductService productService;
    private final CostService costService;

    private boolean checkExists;
    private boolean checkAnyTypeProductExists;
    private boolean checkFinished;
    private boolean checkByproductOnly;
    private boolean checkSellable;
    private boolean checkSourceProduct;
    private boolean checkSusForProduct;

    @Override
    public void initialize(final ValidProduct constraintAnnotation) {
        checkSellable = constraintAnnotation.sellable();
        checkFinished = checkSellable || constraintAnnotation.finished();
        checkByproductOnly = constraintAnnotation.byproductOnly();
        checkSourceProduct = constraintAnnotation.source();
        checkExists = checkFinished || checkSourceProduct || checkByproductOnly || constraintAnnotation.exists();
        checkAnyTypeProductExists =
                constraintAnnotation.finished() && checkSourceProduct
                        && checkByproductOnly && constraintAnnotation.exists();
        checkSusForProduct = !constraintAnnotation.nosus();
    }

    @Override
    public boolean isValid(final String productCode, final ConstraintValidatorContext context) {
        if (null == productCode || "".equals(productCode)) {
            return validationFailedBecause(context, REQUIRED);
        }


        final String formattedProductCode = formatProductCode(productCode);
        if (!PRODUCT_CODE.matcher(formattedProductCode).matches()) {
            return validationFailedBecause(context, INVALID);
        }
        if (!checkExists) {
            return true;
        }

        final Product product;
        if (!checkSusForProduct) {
            product = productService.findByCodeIgnoringSus(formattedProductCode);
            if (null == product) {
                return validationFailedBecause(context, NOT_EXIST);
            }
        } else {
            try {
                product = productService.findByCode(formattedProductCode);
            } catch (final NotFoundException ignored) {
                return validationFailedBecause(context, NOT_EXIST);
            }
        }

        if (!checkAnyTypeProductExists) {
            if (checkSourceProduct) {
                if (checkFinished) {
                    if (product.isByproductOnlyOutput()) {
                        return validationFailedBecause(context, PRODUCT_IS_BYPRODUCT_ONLY_ITEM);
                    }
                } else if (checkByproductOnly) {
                    if (product.isFinishedProductOutput()) {
                        return validationFailedBecause(context, PRODUCT_IS_PRODUCTION_ITEM);
                    }
                } else {
                    if (!product.isSourceProductOutput()) {
                        return validationFailedBecause(context, PRODUCT_IS_NOT_A_SOURCE_ITEM);
                    }
                }
                return true;
            }

            if (checkFinished) {
                if (checkByproductOnly) {
                    if (product.isSourceProductOutput()) {
                        return validationFailedBecause(context, PRODUCT_IS_NOT_PRODUCTION_ITEM);
                    }
                } else {
                    if (product.isByproductOnlyOutput()) {
                        return validationFailedBecause(context, PRODUCT_IS_BYPRODUCT_ONLY_ITEM);
                    }
                    if (product.isSourceProductOutput()) {
                        return validationFailedBecause(context, PRODUCT_IS_NOT_PRODUCTION_ITEM);
                    }
                }
            }
        }

        if (!checkSellable) {
            return true;
        }
        if (null == costService.findCost(product)) {
            return validationFailedBecause(context, PRODUCT_LACKS_PRICING_MODEL);
        }

        return true;
    }
}
