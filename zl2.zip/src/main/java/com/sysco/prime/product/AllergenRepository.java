package com.sysco.prime.product;

import com.sysco.prime.PrimeRepository;

import java.util.Collection;
import java.util.List;
import java.util.Optional;

public interface AllergenRepository extends PrimeRepository<Allergen> {
    Optional<Allergen> findByName(final String allergenName);

    List<Allergen> findAllByNameIn(final Collection<String> allergenNames);
}
