package com.sysco.prime.product.validation;

import com.sysco.prime.product.Product;
import com.sysco.prime.product.ProductService;
import com.sysco.prime.product.request.ProductSetupRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.validation.ConstraintValidatorContext;

import java.math.BigDecimal;

import static com.sysco.prime.validation.ValidationErrorType.MIN_IS_GREATER_THAN_MAX;
import static com.sysco.prime.validation.ValidationErrorType.REQUIRED;

@Component
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class ValidWeightValidator implements PrimeConstraintValidator<ValidWeight, ProductSetupRequest> {
    private final ProductService productService;

    @Override
    public boolean isValid(final ProductSetupRequest value, final ConstraintValidatorContext context) {
        final Product product = productService.findByCode(value.getProductCode());
        if (product.isFixedWeight() && null == value.getFixWeight()) {
            return validationFailedBecause(context, REQUIRED);
        }

        final BigDecimal minWeight = value.getMinWeight();
        final BigDecimal maxWeight = value.getMaxWeight();

        if (product.isCatchWeight()) {
            if (minWeight == null || maxWeight == null) {
                return validationFailedBecause(context, REQUIRED);
            } else {
                if (maxWeight.compareTo(minWeight) < 0) {
                    return validationFailedBecause(context, MIN_IS_GREATER_THAN_MAX);
                }
            }
        }

        return true;
    }
}
