package com.sysco.prime.product.validation;

import javax.validation.Constraint;
import javax.validation.Payload;
import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import static java.lang.annotation.ElementType.FIELD;
import static java.lang.annotation.ElementType.TYPE_USE;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

@Constraint(validatedBy = PositiveValidator.class)
@Documented
@Target({FIELD, TYPE_USE})
@Retention(RUNTIME)
public @interface Positive {
    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};

    String message() default "POSITIVE_INTEGER";

    /** Requires the value to exist.  Set to {@code false} when value is not required. */
    boolean required() default true;

    /** Positive including zero.  Set to {@code true} when value positive includes zero. */
    boolean zeroInclusive() default false;
}
