package com.sysco.prime.product.response;

import com.sysco.prime.product.Product;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.format.DateTimeFormatter;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class IncompleteProductResponse {
    private static final DateTimeFormatter monthDay = DateTimeFormatter.ofPattern("MM-dd");

    private String code;
    private String description;
    private String portionSize;
    private boolean tableAssigned;
    private boolean priceModelAssigned;
    private boolean minWeightAssigned;
    private boolean maxWeightAssigned;
    private String createdAt;
    private String ingredientsStatement;

    public static IncompleteProductResponse fromProduct(final Product product) {
        return IncompleteProductResponse.builder()
                .code(product.getCode())
                .description(product.getDescription())
                .portionSize(product.getProductPortionSize().getPortionSize())
                .tableAssigned(product.getTable() != null)
                .priceModelAssigned(product.getProductGroup() != null)
                .minWeightAssigned(product.getMinWeight() != null)
                .maxWeightAssigned(product.getMaxWeight() != null)
                .createdAt(product.getCreatedAt() != null ? product.getCreatedAt().format(monthDay) : "")
                .build();
    }
}
