package com.sysco.prime.product.validation;

import org.springframework.stereotype.Component;

import javax.validation.ConstraintValidatorContext;

import static com.sysco.prime.validation.ValidationErrorType.REQUIRED;

@Component
public class PositiveValidator implements PrimeConstraintValidator<Positive, Number> {
    private boolean checkRequired;
    private boolean checkZeroInclusive;

    @Override
    public void initialize(final Positive constraintAnnotation) {
        checkRequired = constraintAnnotation.required();
        checkZeroInclusive = constraintAnnotation.zeroInclusive();
    }

    @Override
    public boolean isValid(final Number value, final ConstraintValidatorContext context) {
        if (null == value) {
            if (checkRequired) {
                return validationFailedBecause(context, REQUIRED);
            } else {
                return true;
            }
        }

        return checkZeroInclusive ? value.doubleValue() >= 0D : value.doubleValue() > 0D;
    }
}
