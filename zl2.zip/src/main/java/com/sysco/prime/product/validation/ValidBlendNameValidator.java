package com.sysco.prime.product.validation;

import com.sysco.prime.exception.InvalidValueException;
import com.sysco.prime.productionOrder.Blend;
import com.sysco.prime.productionOrder.BlendRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.validation.ConstraintValidatorContext;

import static com.sysco.prime.validation.ValidationErrorType.NOT_EXIST;
import static com.sysco.prime.validation.ValidationErrorType.REQUIRED;

@Component
@RequiredArgsConstructor(onConstructor =  @__(@Autowired))
public class ValidBlendNameValidator implements PrimeConstraintValidator<ValidBlendName, String> {
    private final BlendRepository blendRepository;

    @Override
    public boolean isValid(final String value, final ConstraintValidatorContext context) {
        if (null == value || "".equals(value)) {
            return validationFailedBecause(context, REQUIRED);
        }

        try {
            Blend.fromString(value, blendRepository);
            return true;
        } catch (final InvalidValueException ex) {
            return validationFailedBecause(context, NOT_EXIST);
        }
    }
}
