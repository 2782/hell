package com.sysco.prime.product.validation;

import com.sysco.prime.housePar.HouseParRequest;
import com.sysco.prime.housePar.HouseParService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.validation.ConstraintValidatorContext;

@Component
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class NewHouseParValidator implements PrimeConstraintValidator<NewHousePar, HouseParRequest> {
    private final HouseParService service;

    @Override
    public boolean isValid(final HouseParRequest request, final ConstraintValidatorContext context) {
        return null != request.getId() || null == service.getExistsHousePar(request.getProductCode());
    }
}
