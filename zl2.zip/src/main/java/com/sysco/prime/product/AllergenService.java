package com.sysco.prime.product;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Slf4j
@Service
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class AllergenService {
    private final AllergenRepository allergenRepository;

    public List<Allergen> getAllergens() {
        return allergenRepository.findAll();
    }

    public Optional<Allergen> findByName(final String allergenName) {
        return allergenRepository.findByName(allergenName);
    }

    public List<Allergen> findAllByName(final List<String> allergenNames) {
        return allergenRepository.findAllByNameIn(allergenNames);
    }
}
