package com.sysco.prime.product.request;

import com.sysco.prime.product.Product;
import com.sysco.prime.product.ProductGroup;
import com.sysco.prime.product.ProductService;
import com.sysco.prime.product.validation.ValidProduct;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

import javax.validation.constraints.NotNull;
import java.util.List;

import static com.sysco.prime.product.ProductGroup.cuttingProductGroup;

@Data
@RequiredArgsConstructor
@Builder
public class CuttingProductGroupRequest implements ProductGroupRequest {
    @ValidProduct(sellable = true, finished = true)
    private final String productGroupName; // primary product code
    @NotNull
    private final List<@ValidProduct(finished = true) String> finishedProductCodes;

    public ProductGroup toDomain(final ProductService productService) {
        final ProductGroup productGroup =
                cuttingProductGroup(productService.findByCode(productGroupName).ungroupedCopy());
        finishedProductCodes.stream()
                .map(productService::findByCode)
                .flatMap(this::includeGroupmatesForMerge)
                .map(Product::ungroupedCopy)
                .forEach(productGroup::add);
        return productGroup;
    }
}
