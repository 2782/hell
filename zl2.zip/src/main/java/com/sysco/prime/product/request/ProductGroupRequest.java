package com.sysco.prime.product.request;

import com.sysco.prime.product.Product;

import java.util.List;
import java.util.stream.Stream;

public interface ProductGroupRequest {
    String getProductGroupName();

    List<String> getFinishedProductCodes();

    default Stream<Product> includeGroupmatesForMerge(final Product product) {
        return product.isGroupPrimary()
                ? product.getMemberProductsInSameGroup().stream()
                : Stream.of(product);
    }
}
