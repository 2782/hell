package com.sysco.prime.product.response;

import lombok.Builder;
import lombok.Value;

import static com.sysco.prime.product.response.BlendOrProductLookup.PRODUCT;

@Value
@Builder
public class ProductNameLookup implements NameLookup {
    private final BlendOrProductLookup type = PRODUCT;
    private final ProductResponse product;

    public ProductNameLookup(final ProductResponse product) {
        this.product = product;
    }

    public ProductNameLookup() {
        this.product = null;
    }

}