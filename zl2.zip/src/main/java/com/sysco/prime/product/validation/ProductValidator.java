package com.sysco.prime.product.validation;

import com.sysco.prime.exception.InvalidValueException;
import com.sysco.prime.product.Product;
import com.sysco.prime.product.ProductService;
import com.sysco.prime.validation.Validation;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Set;

import static com.sysco.prime.validation.ValidationError.buildError;
import static com.sysco.prime.validation.ValidationErrorType.NOT_EXIST;
import static java.util.Collections.singletonList;

@Component
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class ProductValidator implements Validation {
    private final ProductService productService;

    @Override
    public void validate() {
    }

    public void validateProductMustExist(final String code, final String fieldName, final String error) {
        validateAllProductsMustExist(singletonList(code), fieldName, error);
    }

    void validateAllProductsMustExist(final List<String> codes, final String fieldName, final String error) {
        final List<Product> result = productService.findByCodeIn(codes);
        if (result.size() < codes.size()) {
            throw new InvalidValueException(String.format("%s must exist", fieldName),
                    buildError(fieldName, NOT_EXIST, error));
        }
    }
}
