package com.sysco.prime.product.request;

import com.sysco.prime.product.Product;
import com.sysco.prime.product.ProductGroup;
import com.sysco.prime.product.validation.NoDuplicateProducts;
import com.sysco.prime.product.validation.ValidProduct;
import com.sysco.prime.product.validation.ValidProductGroupName;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;
import java.util.regex.Pattern;
import java.util.stream.Stream;

import static com.sysco.prime.product.ProductGroup.cuttingProductGroup;
import static com.sysco.prime.product.ProductGroup.grindingProductGroup;
import static java.util.stream.Collectors.toList;

@Data
@RequiredArgsConstructor
@Builder
@NoDuplicateProducts
public class GenericProductGroupRequest implements ProductGroupRequest {
    private static final Pattern PRODUCT_CODE = Pattern.compile("\\d{7}");

    @ValidProductGroupName
    private final String productGroupName;
    @Valid
    @NotNull
    private final List<@ValidProduct(finished = true) String> finishedProductCodes;

    public ProductGroup toDomain(final Function<String, Product> productLookup) {
        final ProductGroup productGroup = initializeProductGroup(productLookup);

        final List<Product> products = finishedProductCodes.stream()
                .map(productLookup)
                .collect(toList());

        return addProductsToProductGroup(products, productGroup);
    }

    public boolean isCuttingRequest() {
        return PRODUCT_CODE.matcher(productGroupName).matches();
    }

    private ProductGroup initializeProductGroup(Function<String, Product> productLookup) {
        if (isCuttingRequest()) {
            final Product product = productLookup.apply(productGroupName);
            return cuttingProductGroup(product.ungroupedCopy());
        } else {
            return grindingProductGroup(productGroupName.trim().toUpperCase());
        }
    }

    private ProductGroup addProductsToProductGroup(final List<Product> productsToAdd, final ProductGroup productGroup) {
        final boolean isCuttingRequest = isCuttingRequest();

        productsToAdd.stream()
                .flatMap(product -> isCuttingRequest ? includeGroupmatesForMerge(product) : Stream.of(product))
                .map(Product::ungroupedCopy)
                .forEach(productGroup::add);
        return productGroup;
    }

    public List<String> getAllProductCodes() {
        final List<String> productCodes = new ArrayList<>(finishedProductCodes);
        if (PRODUCT_CODE.matcher(productGroupName).matches()) {
            productCodes.add(productGroupName);
        }
        return productCodes;
    }
}