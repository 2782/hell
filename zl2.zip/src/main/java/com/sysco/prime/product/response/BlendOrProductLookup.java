package com.sysco.prime.product.response;

import static org.apache.commons.lang.StringUtils.isNumeric;

public enum BlendOrProductLookup {
    BLEND, PRODUCT;

    public static BlendOrProductLookup isBlendNameOrProductCode(final String value) {
        return isNumeric(value) ? PRODUCT : BLEND;
    }
}
