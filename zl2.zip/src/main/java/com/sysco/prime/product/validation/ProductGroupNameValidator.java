package com.sysco.prime.product.validation;

import com.sysco.prime.cost.CostService;
import com.sysco.prime.exception.InvalidValueException;
import com.sysco.prime.exception.NotFoundException;
import com.sysco.prime.product.Product;
import com.sysco.prime.product.ProductService;
import com.sysco.prime.productionOrder.Blend;
import com.sysco.prime.productionOrder.BlendRepository;
import com.sysco.prime.yieldModel.GrindingYieldModelRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.validation.ConstraintValidatorContext;
import java.util.regex.Pattern;

import static com.sysco.prime.validation.ValidationErrorType.BLEND_DOES_NOT_EXIST;
import static com.sysco.prime.validation.ValidationErrorType.NOT_EXIST;
import static com.sysco.prime.validation.ValidationErrorType.PRODUCT_GROUP_LACKS_PRICING_MODEL;
import static com.sysco.prime.validation.ValidationErrorType.PRODUCT_IS_NOT_PRODUCTION_ITEM;
import static com.sysco.prime.validation.ValidationErrorType.PRODUCT_LACKS_PRICING_MODEL;
import static com.sysco.prime.validation.ValidationErrorType.REQUIRED;

@Component
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class ProductGroupNameValidator implements PrimeConstraintValidator<ValidProductGroupName, String> {
    private static final Pattern PRODUCT_CODE = Pattern.compile("\\d{7}");

    private final ProductService productService;
    private final CostService costService;
    private final GrindingYieldModelRepository grindingYieldModelRepository;
    private final BlendRepository blendRepository;

    @Override
    public boolean isValid(String productGroupName, ConstraintValidatorContext context) {
        if (null == productGroupName || "".equals(productGroupName)) {
            return validationFailedBecause(context, REQUIRED);
        }

        return isValidPrimaryProduct(productGroupName, context);
    }

    private boolean isValidPrimaryProduct(String productGroupName, ConstraintValidatorContext context) {
        if (!PRODUCT_CODE.matcher(productGroupName).matches()) {
            return isValidBlendName(productGroupName, context);
        }

        final Product product;
        try {
            product = productService.findByCode(productGroupName);
        } catch (final NotFoundException ignored) {
            return validationFailedBecause(context, NOT_EXIST);
        }

        if (!product.isFinishedProductOutput()) {
            return validationFailedBecause(context, PRODUCT_IS_NOT_PRODUCTION_ITEM);
        }

        if (null == costService.findCost(product)) {
            return validationFailedBecause(context, PRODUCT_LACKS_PRICING_MODEL);
        }

        return true;
    }

    private boolean isValidBlendName(final String productGroupName, final ConstraintValidatorContext context) {
        try {
            final Blend blend = Blend.fromString(productGroupName, blendRepository);
            return grindingYieldModelRepository.findByBlendNameAndPricingModelTrue(
                    blend.getName()).isPresent() || validationFailedBecause(context, PRODUCT_GROUP_LACKS_PRICING_MODEL);
        } catch (final InvalidValueException ex) {
            return validationFailedBecause(context, BLEND_DOES_NOT_EXIST);
        }
    }
}
