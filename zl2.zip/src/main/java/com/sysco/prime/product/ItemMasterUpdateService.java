package com.sysco.prime.product;

import com.sysco.prime.cost.Cost;
import com.sysco.prime.profile.Profile;
import com.sysco.prime.profile.ProfileService;
import com.sysco.prime.sus.client.SusClient;
import com.sysco.prime.yieldModel.CuttingYieldModelService;
import com.sysco.prime.yieldModel.GrindingYieldModelService;
import com.sysco.prime.yieldModel.YieldModelBase;
import com.sysco.prime.yieldModel.YieldModelService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

import java.util.List;

@Slf4j
@Service
public class ItemMasterUpdateService {
    private final ProfileService profileService;
    private final GrindingYieldModelService grindingYieldModelService;
    private final CuttingYieldModelService cuttingYieldModelService;
    private final YieldModelService yieldModelService;

    private final ProductGroupService productGroupService;
    private final SusClient susClient;

    public ItemMasterUpdateService(
            final ProfileService profileService,
            @Lazy final GrindingYieldModelService grindingYieldModelService,
            @Lazy final CuttingYieldModelService cuttingYieldModelService,
            @Lazy final YieldModelService yieldModelService,
            final ProductGroupService productGroupService,
            final SusClient susClient) {
        this.profileService = profileService;
        this.grindingYieldModelService = grindingYieldModelService;
        this.cuttingYieldModelService = cuttingYieldModelService;
        this.yieldModelService = yieldModelService;

        this.productGroupService = productGroupService;
        this.susClient = susClient;
    }

    public void updateSusItemMasterForCutting(final String primaryProductCode) {
        final YieldModelBase yieldModel = cuttingYieldModelService
                .findCuttingPricingModelForPrimaryProduct(primaryProductCode);
        updateSusItemMaster(primaryProductCode, yieldModel);
    }

    public void updateSusItemMasterForCutting(final Product primaryProduct, YieldModelBase yieldModel) {
        updateSusItemMaster(primaryProduct.getCode(), yieldModel);
    }

    public void updateSusItemMasterForGrinding(final String blendName) {
        final YieldModelBase yieldModel = grindingYieldModelService.findGrindingPricingModelByBlend(blendName);
        updateSusItemMaster(blendName, yieldModel);
    }

    ProductGroup updateSusItemMaster(final ProductGroup productGroup) {
        if (productGroup.isCuttingProductGroup()) {
            updateSusItemMasterForCutting(productGroup.getName());
        } else {
            updateSusItemMasterForGrinding(productGroup.getName());
        }
        return productGroup;
    }

    void updateSusItemMaster(final Product completeProduct) {
        if (completeProduct.isPrimeComplete()) {

            final YieldModelBase yieldModel = yieldModelService.getPricingYieldModelFor(completeProduct);

            if (null != yieldModel) {
                susClient.updateItemMaster(
                        completeProduct,
                        yieldModel,
                        profileService.get());
            }
        }

    }

    private void updateSusItemMaster(final String groupName,
                                     final YieldModelBase yieldModel) {
        final List<Product> memberProducts = productGroupService.productsInGroupOf(groupName);
        final Profile profile = profileService.get();
        memberProducts.stream()
                .filter(Product::isPrimeComplete)
                .forEach(completeProduct -> {
                    susClient.updateItemMaster(
                            completeProduct,
                            yieldModel,
                            profile);
                });
    }

    public void updateSusItemMaster(final Product completeProduct, final Cost cost) {
        if (cost != null) {
            try {
                susClient.updateItemMaster(completeProduct, cost, profileService.get());
            } catch (Exception ex) {
                log.error("Cannot update cost to Item Master for product {}", completeProduct.getCode());
            }
        }
    }
}
