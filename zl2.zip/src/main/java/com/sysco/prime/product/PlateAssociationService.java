package com.sysco.prime.product;

import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class PlateAssociationService {
    private final PlateAssociationRepository repository;

    public PlateAssociation findByModelNumber(final String modelNumber) {
        return repository.findByModelNumber(modelNumber).orElse(null);
    }

}
