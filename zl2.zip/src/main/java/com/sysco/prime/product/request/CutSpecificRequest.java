package com.sysco.prime.product.request;

import com.sysco.prime.product.CutSpecific;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class CutSpecificRequest {
    private String tenderized;

    public CutSpecific toDomain() {
        return CutSpecific.builder()
                .tenderized(tenderized).build();
    }
}
