package com.sysco.prime.blend;

import com.sysco.prime.productionOrder.Blend;
import com.sysco.prime.productionOrder.BlendRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Order;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BlendService {
    private final BlendRepository repository;

    public List<Blend> allBlends() {
        return repository.findAll(Sort.by(Order.asc("id")));
    }

    public Blend getBlend(final String blendName) {
        return Blend.fromString(blendName, repository);
    }
}
