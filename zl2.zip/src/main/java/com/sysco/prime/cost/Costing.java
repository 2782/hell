package com.sysco.prime.cost;

import lombok.Builder;
import lombok.Data;

@Builder
@Data
public class Costing {
    private final Double currentCost;
    private final Double labor;

    static Costing withCurrentCostPerPound(final Cost cost) {
        return new Costing(cost.getCurrentCostPerPound().doubleValue(), cost.getLabor().doubleValue());
    }

    public static Costing withMarketCost(final Cost cost) {
        return new Costing(cost.getMarketCost().doubleValue(), cost.getLabor().doubleValue());
    }
}
