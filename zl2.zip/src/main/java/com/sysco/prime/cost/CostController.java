package com.sysco.prime.cost;

import com.sysco.prime.cost.request.SourceCostRequest;
import com.sysco.prime.product.Product;
import com.sysco.prime.product.ProductService;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import java.time.Clock;
import java.util.List;
import java.util.stream.Collectors;

import static org.springframework.http.HttpStatus.CREATED;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

@Validated
@RestController
@RequestMapping(path = "/api", produces = APPLICATION_JSON_VALUE)
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class CostController {
    private final Clock clock;
    private final CostService costService;
    private final ProductService productService;
    // TODO: Remove when done!
    // private final CostPublisher costPublisher;

    @GetMapping(path = "/cost/{product-code}", produces = APPLICATION_JSON_VALUE)
    @Secured({"ROLE_ADMIN", "ROLE_PORTION_ROOM_MEMBER", "ROLE_COSTING"})
    public CostResponse getCostByProductCode(@PathVariable("product-code") final String productCode) {
        final Product product = productService.findByCodeFillZeroBefore(productCode);
        return CostResponse.from(costService.findCost(product));
    }

    @PostMapping(path = "/costs")
    @ResponseStatus(CREATED)
    @ApiOperation(value = "Upload source product costs", notes = "Upload source product costs")
    @Secured({"ROLE_ADMIN", "ROLE_COSTING"})
    public void loadSourceProductCosts(@Valid @RequestBody final List<@Valid SourceCostRequest> requests) {
        final List<Cost> costs = requests.stream()
                .map(request -> request.toDomain(productService, clock))
                .collect(Collectors.toList());
        costService.createCostList(costs);
    }

    // TODO: For testing only
    //    @GetMapping(path = "/cost/testing")
    //    @ResponseStatus(OK)
    //    public void testPublishCost() {
    //        costPublisher.publish(Cost.builder()
    //                .source(YIELD_MODEL)
    //                .labor(Money.of(12.01))
    //                .marketCost(Money.ofCost(12.02))
    //                .currentCostPerPound(Money.ofCost(12.0d))
    //                .weightedAverageCost(Money.ofCost(35.01d))
    //                .build());
    //    }
}
