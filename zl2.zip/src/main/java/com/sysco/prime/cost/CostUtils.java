package com.sysco.prime.cost;

import com.sysco.prime.product.Product;

import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static java.math.RoundingMode.HALF_UP;

public class CostUtils {
    public static BigDecimal calculateCurrentCostPerPound(
            final Product product,
            final BigDecimal marketCost) {
        return product.isFixedWeight()
                ? (product.getWeightPerBox() != null
                ? marketCost.divide(Money.ofCost(product.getWeightPerBox()), 3, HALF_UP)
                : null)
                : marketCost;
    }

    public static List<Cost> getMostRecentForDateRanges(final List<Cost> costList) {
        Map<String, List<Cost>> costMap = createCostMap(costList);
        final List<Cost> validCosts = new ArrayList<>();

        costMap.forEach((costName, listOfCosts) -> {
            Collections.sort(listOfCosts);
            validCosts.add(listOfCosts.get(0));
        });

        return validCosts;
    }

    private static Map<String, List<Cost>> createCostMap(final List<Cost> costList) {

        HashMap<String, List<Cost>> costMap = new HashMap<>();
        costList.forEach(cost -> {

            @NotNull String costName = cost.getName();

            String costKey = costName + "_" + cost.getStartDate() + " - " + cost.getEndDate();

            List<Cost> costs = costMap.get(costKey);

            if (costs == null) {
                List<Cost> initalCostList = new ArrayList<>();
                initalCostList.add(cost);
                costMap.put(costKey, initalCostList);
            } else {
                costs.add(cost);
            }
        });

        return costMap;
    }
}
