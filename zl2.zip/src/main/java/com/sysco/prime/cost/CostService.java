package com.sysco.prime.cost;

import com.sysco.prime.cost.Cost.CostBuilder;
import com.sysco.prime.product.ItemMasterUpdateService;
import com.sysco.prime.product.Product;
import com.sysco.prime.product.ProductGroup;
import com.sysco.prime.product.ProductGroupService;
import com.sysco.prime.product.ProductService;
import com.sysco.prime.profile.Profile;
import com.sysco.prime.profile.ProfileService;
import com.sysco.prime.schedule.yieldModel.PricePublisher;
import com.sysco.prime.sus.client.SusClient;
import com.sysco.prime.systemConfig.SystemConfigService;
import com.sysco.prime.yieldModel.CuttingYieldByproduct;
import com.sysco.prime.yieldModel.CuttingYieldModel;
import com.sysco.prime.yieldModel.GrindingYieldModel;
import com.sysco.prime.yieldModel.YieldModelBase;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.Clock;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.OptionalInt;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;
import java.util.stream.IntStream;

import static com.sysco.prime.cost.Cost.COST_NEVER_EXPIRES;
import static com.sysco.prime.cost.Cost.unsetPricingModelFrom;
import static com.sysco.prime.cost.CostSource.BYPRODUCT_ONLY;
import static com.sysco.prime.cost.CostSource.BYPRODUCT_OVERRIDE;
import static com.sysco.prime.cost.CostSource.PRICING_MODEL;
import static com.sysco.prime.cost.CostSource.REMOVE_OVERRIDE;
import static com.sysco.prime.cost.CostSource.SUS;
import static com.sysco.prime.cost.CostSource.YIELD_MODEL;
import static com.sysco.prime.cost.CostUtils.getMostRecentForDateRanges;
import static com.sysco.prime.cost.Money.ofCost;
import static com.sysco.prime.yieldModel.YieldModelUtils.calculateMarketCost;
import static java.time.LocalDate.now;
import static java.util.Arrays.asList;
import static java.util.Collections.unmodifiableList;
import static java.util.stream.Collectors.toList;

@Service
@Slf4j
public class CostService {
    /**
     * Picks up market cost, et al, from pricing model, WAC from SUS.
     */
    public static final Predicate<Cost> PRICING_MODEL_FILTER = cost -> PRICING_MODEL == cost.getSource();
    static final Predicate<Cost> ALL_COSTS_FILTER = cost -> true;
    static final List<CostSource> MODEL_SOURCES = asList(YIELD_MODEL, PRICING_MODEL);
    public static final List<CostSource> BYPRODUCT_OVERRIDE_SOURCES = unmodifiableList(asList(BYPRODUCT_OVERRIDE,
            REMOVE_OVERRIDE));
    public static final Predicate<Cost> SUS_FILTER = cost -> SUS == cost.getSource();
    private static final Predicate<Cost> BYPRODUCT_ONLY_FILTER = cost -> BYPRODUCT_ONLY == cost.getSource();
    private final Clock when;
    private final CostRepository costRepository;
    private final SusClient susClient;
    private final ProfileService profileService;
    private final SystemConfigService systemConfigService;
    private final ProductGroupService productGroupService;
    private final ProductService productService;
    private final ItemMasterUpdateService itemMasterUpdateService;
    private final PricePublisher pricePublisher;

    public CostService(
            final Clock when,
            final CostRepository costRepository,
            final SusClient susClient,
            final ProfileService profileService,
            final SystemConfigService systemConfigService,
            final ProductGroupService productGroupService,
            @Lazy final ProductService productService,
            final ItemMasterUpdateService itemMasterUpdateService,
            final PricePublisher pricePublisher) {
        this.when = when;
        this.costRepository = costRepository;
        this.susClient = susClient;
        this.profileService = profileService;
        this.systemConfigService = systemConfigService;
        this.productGroupService = productGroupService;
        this.productService = productService;
        this.itemMasterUpdateService = itemMasterUpdateService;
        this.pricePublisher = pricePublisher;
    }

    public static boolean isCostChanged(final Cost existing, final CuttingYieldByproduct yieldByproduct) {
        return existing != null && existing.getCurrentCostPerPound() != null
                && hasChanged(existing::getCurrentCostPerPound, yieldByproduct::getCost);
    }

    private static boolean isLaborChanged(final Cost existing, final CuttingYieldByproduct yieldByproduct) {
        return existing != null && existing.getLabor() != null
                && hasChanged(existing::getLabor, yieldByproduct::getLabor);
    }

    static boolean hasChanged(final Supplier<BigDecimal> cost, final Supplier<BigDecimal> fromByProduct) {
        return !Objects.equals(Money.of(cost.get()), Money.of(fromByProduct.get()));
    }

    private static <T> void copyIfPresent(
            final Collection<Cost> costs,
            final Function<Cost, T> getter,
            final Consumer<T> setter,
            final Predicate<Cost> costFilter) {
        costs.stream()
                .filter(costFilter)
                .map(getter)
                .filter(Objects::nonNull)
                .findFirst()
                .ifPresent(setter);
    }

    static Cost withMissingCostsAsZero(final Cost cost) {
        final BigDecimal marketCost = cost.getMarketCost();
        final BigDecimal labor = cost.getLabor();
        final BigDecimal weightedAverageCost = cost.getWeightedAverageCost();
        final BigDecimal currentCostPerPound = cost.getCurrentCostPerPound();

        return cost.toBuilder()
                .marketCost(null == marketCost ? Money.zero() : marketCost)
                .labor(null == labor ? Money.zero() : labor)
                .weightedAverageCost(
                        null == weightedAverageCost ? Money.zero() : weightedAverageCost)
                .currentCostPerPound(
                        null == currentCostPerPound ? Money.zero() : currentCostPerPound)
                .build();
    }

    public List<String> getCostNamesForPricesApplicableToday() {
        final LocalDate today = systemConfigService.getFirstWorkDay(OffsetDateTime.now(when));
        final List<Cost> costs = findAvailableInputCosts(today);
        return costs.stream()
                .map(Cost::getName)
                .collect(toList());
    }

    void createCostList(final List<Cost> costs) {
        costRepository.saveAll(costs);
    }

    public void updateFinishedProductCosts(final List<Product> productsNeedToUpdate,
                                           final YieldModelBase yieldModel) {
        if (!yieldModel.isPricingModel()) {
            return;
        }
        productsNeedToUpdate.stream().filter(Product::isFinishedProductOutput)
                .forEach(p -> sendCostToSus(p, yieldModel.getPrimeCost(p)));
    }

    public Cost create(final Cost cost, final boolean shouldSave) {
        final Cost existingCost = mostRecentViewForYieldModelsNow(
                cost.getName(), cost.getYieldModelId(), MODEL_SOURCES);

        if (existingCost.isEmpty() || cost.hasPrimeCostChanged(existingCost)) {
            return save(cost, shouldSave);
        }
        return null;
    }

    public void unsetExistingPricingModelCost(final GrindingYieldModel pricingModel) {
        final Cost cost = getForPricingModelInternal(pricingModel.getCostName());
        save(unsetPricingModelFrom(cost), true);
    }

    public void unsetExistingPricingModelCost(final CuttingYieldModel pricingModel) {
        final Cost cost = getForPricingModelInternal(pricingModel.getCostName());
        save(unsetPricingModelFrom(cost), true);
    }

    public void createOrUpdateGrindingYieldModelCost(final GrindingYieldModel yieldModel) {
        save(yieldModel.getPrimeCost(null), true);
    }

    public void createOrUpdateByproductCost(final Long yieldModelId, final List<CuttingYieldByproduct>
            yieldByProducts) {
        costRepository.saveAll(getNewCosts(yieldModelId, yieldByProducts, new HashMap<String, Product>()).stream()
                .map(this::withStartEndDates)
                .collect(toList()));
    }

    public List<Cost> getUpdatedByproductCost(final Long yieldModelId, final List<CuttingYieldByproduct>
            yieldByProducts, final Map<String, Product> productMap) {
        return getNewCosts(yieldModelId, yieldByProducts, productMap).stream()
                .map(this::withStartEndDates)
                .collect(toList());
    }

    private List<Cost> getNewCosts(final Long yieldModelId, final List<CuttingYieldByproduct> yieldByProducts,
                                   final Map<String, Product> productMap) {
        final List<Cost> newCosts = new ArrayList<>();

        yieldByProducts.forEach(yieldByproduct -> {
            final Product productForByproduct;
            final String productCode = yieldByproduct.getByproductCode();
            if (productMap.containsKey(productCode)) {
                productForByproduct = productMap.get(productCode);
            } else {
                productForByproduct = productService.findByCode(productCode);
                productMap.put(productCode, productForByproduct);
            }
            final Cost existingOverrideCost = getByproductOverrideCost(yieldByproduct.getByproductCode(),
                    yieldModelId);
            final Cost existingCost = findCost(productForByproduct);

            final boolean currentCostChanged = hasCostChangedFromOverrideOrPricing(yieldByproduct,
                    existingOverrideCost, existingCost);
            final boolean laborChanged = hasLaborCostChangedFromOverrideOrPricing(yieldByproduct,
                    existingOverrideCost, existingCost);
            if (currentCostChanged || laborChanged) {
                CostBuilder costBuilder = Cost.builder()
                        .weightedAverageCost(null)
                        .yieldModelId(yieldModelId)
                        .source(BYPRODUCT_OVERRIDE)
                        .name(yieldByproduct.getByproductCode());
                if (laborChanged) {
                    costBuilder = costBuilder.labor(ofCost(yieldByproduct.getLabor()));
                }
                if (currentCostChanged) {
                    costBuilder = costBuilder
                            .marketCost(ofCost(calculateMarketCost(productForByproduct,
                                    yieldByproduct.getCost())))
                            .currentCostPerPound(ofCost(yieldByproduct.getCost()));
                }
                newCosts.add(costBuilder.build());
            }
        });
        return newCosts;
    }

    private boolean hasLaborCostChangedFromOverrideOrPricing(final CuttingYieldByproduct yieldByproduct, final Cost
            existingOverrideCost, final Cost existingCost) {
        final boolean laborOverrideChanged = isLaborChanged(existingOverrideCost, yieldByproduct);
        final boolean laborChangedCompareWithPricingModel = isLaborChanged(existingCost, yieldByproduct);

        return laborOverrideChanged || laborChangedCompareWithPricingModel;
    }

    private boolean hasCostChangedFromOverrideOrPricing(final CuttingYieldByproduct yieldByproduct, final Cost
            existingOverrideCost, final Cost existingCost) {
        final boolean costChangedCompareWithOverrideCost = isCostChanged(existingOverrideCost, yieldByproduct);
        final boolean costChangedCompareWithPricingModel = isCostChanged(existingCost, yieldByproduct);

        return costChangedCompareWithOverrideCost || costChangedCompareWithPricingModel;
    }

    public void removeByproductOverride(final Long yieldModelId,
                                        final Collection<CuttingYieldByproduct> yieldByProductsToRemove,
                                        final Map<String, Product> productMap) {
        final List<Cost> removeByProductOverrideList = yieldByProductsToRemove.stream()
                .filter(byProduct -> getByproductOverrideCost(byProduct.getByproductCode(), yieldModelId) != null)
                .map(byProduct -> {
                    Product productForByProduct = productService.getProductAndCheckInCache(productMap,
                            byProduct.getByproductCode());
                    return Cost.from(byProduct, productForByProduct, yieldModelId, REMOVE_OVERRIDE);
                })
                .map(this::withStartEndDates)
                .collect(toList());
        if (!removeByProductOverrideList.isEmpty()) {
            costRepository.saveAll(removeByProductOverrideList);
        }
    }

    public void saveAll(List<Cost> costs) {
        //saveAllDatesForAllCosts(costs)
        costRepository.saveAll(costs);
    }

    public Cost getForYieldModel(final YieldModelBase yieldModel) {
        final String costName = yieldModel.getCostName();
        final Cost cost = mostRecentViewForYieldModelsNow(
                costName, yieldModel.getId(), MODEL_SOURCES);
        return cost.isEmpty() ? null : withMissingCostsAsZero(cost);
    }

    public Cost getForPricingModel(final YieldModelBase pricingModel) {
        final Cost cost = getForPricingModelInternal(pricingModel.getCostName());
        return cost.isEmpty() ? null : withMissingCostsAsZero(cost);
    }

    private Cost getForPricingModelInternal(final String costName) {
        return mostRecentViewForProductsOn(costName, now(when), PRICING_MODEL_FILTER);
    }

    public Cost getByproductOverrideCost(final String productCode, final Long yieldModelId) {
        final List<Cost> costs = costRepository.findAllByNameAndYieldModelIdAndSourceInOrderByCreatedAtDesc(
                productCode, yieldModelId, BYPRODUCT_OVERRIDE_SOURCES);
        if (costs.isEmpty() || costs.get(0).getSource().equals(REMOVE_OVERRIDE)) {
            return null;
        }
        List<Cost> costWithoutRemove = filterCostTillRemoveOverride(costs);
        return mostRecentView(costWithoutRemove, productCode, ALL_COSTS_FILTER);
    }

    public Cost getByproductOverrideCost(final String productCode,
                                         final Long yieldModelId,
                                         final LocalDate costAt) {
        final List<Cost> costs = costRepository.mostRecentForAt(
                productCode, yieldModelId, BYPRODUCT_OVERRIDE_SOURCES, costAt);
        if (costs.isEmpty() || costs.get(0).getSource().equals(REMOVE_OVERRIDE)) {
            return null;
        }
        List<Cost> costWithoutRemove = filterCostTillRemoveOverride(costs);
        return mostRecentView(costWithoutRemove, productCode, ALL_COSTS_FILTER);
    }

    private List<Cost> filterCostTillRemoveOverride(final List<Cost> costs) {
        OptionalInt indexOpt = IntStream.range(0, costs.size())
                .filter(i -> costs.get(i).getSource().equals(REMOVE_OVERRIDE))
                .findFirst();
        if (indexOpt.isPresent()) {
            final int index = indexOpt.getAsInt();
            if (index > 0) {
                return costs.subList(0, index);
            }
        }
        return costs;
    }

    public Cost getForCuttingByproduct(final Product product, final Long yieldModelId) {
        // TODO: Not parameterized by date!
        final List<Cost> costs = costRepository.findAllByNameAndYieldModelIdAndSourceInOrderByCreatedAtDesc(
                product.getCostName(), yieldModelId, BYPRODUCT_OVERRIDE_SOURCES);
        if (costs.isEmpty() || costs.get(0).getSource().equals(REMOVE_OVERRIDE)) {
            return findCost(product);
        }

        List<Cost> costWithoutRemove = filterCostTillRemoveOverride(costs);
        Cost cost = mostRecentView(costWithoutRemove, product.getCostName(), ALL_COSTS_FILTER);

        if (cost.getLabor() == null || cost.getCurrentCostPerPound() == null) {
            final CostBuilder costBuilder = cost.toBuilder();
            final Cost pricingCost = findCost(product);
            if (cost.getLabor() == null) {
                costBuilder.labor(pricingCost.getLabor());
            }
            if (cost.getCurrentCostPerPound() == null) {
                costBuilder.currentCostPerPound(pricingCost.getCurrentCostPerPound());
                costBuilder.marketCost(pricingCost.getMarketCost());
                costBuilder.endDate(pricingCost.getEndDate());
                costBuilder.startDate(pricingCost.getStartDate());
                costBuilder.source(pricingCost.getSource());
            }
            cost = costBuilder.build();
        }

        return cost;
    }

    public void saveCostFromSus(final Cost cost) {
        save(cost, true);
    }

    public void updateCostForProductsInGroup(final ProductGroup productGroup) {
        final Cost cost = getForPricingModelInternal(productGroup.getName());
        productGroup.getMemberProducts().forEach(product -> sendCostToSus(product, cost));
    }

    public void sendCostToSus(final Product product, final Cost cost) {
        final Profile profile = profileService.get();
        susClient.sendProductionProductCostToSus(product.getCode(), cost, profile);
    }

    // TODO: Could be trouble
    public List<Cost> findAvailableInputCosts(final LocalDate dateBetweenStartAndEndDate) {
        return costRepository.findBySourceInAndStartDateLessThanEqualAndEndDateGreaterThanEqual(
                asList(SUS, BYPRODUCT_ONLY, PRICING_MODEL), dateBetweenStartAndEndDate, dateBetweenStartAndEndDate);
    }

    public List<Cost> getAllFutureCosts(final Product sourceProduct, final LocalDate startDate) {
        List<Cost> futureCosts = costRepository
                .findByNameAndSourceInAndStartDateGreaterThanEqualAndEndDateLessThanEqualOrderByCreatedAtDesc(
                        sourceProduct.getCode(), asList(SUS),
                        startDate.plusDays(1), COST_NEVER_EXPIRES)
                .stream()
                .filter(cost ->
                    cost.getCurrentCostPerPound() != null
                        && cost.getStartDate() != null
                            && cost.getEndDate() != null
                            && cost.getCreatedAt() != null)
                .collect(toList());

        return getMostRecentForDateRanges(futureCosts);
    }

    public Costing costing(final Product product) {
        final Cost cost = findCost(product);
        if (null != cost) {
            return Costing.withCurrentCostPerPound(cost);
        } else {
            return new Costing(null, null);
        }
    }

    public Cost findCostDaysFromToday(final Product product, final int daysFromToday) {
        return findCost(product, now(when).minusDays(daysFromToday));
    }

    public Cost findCost(final Product product) {
        return findCost(product, now(when));
    }

    public Cost findCost(final Product product, final LocalDate costAtDate) {
        final String costName = product.getCostName();
        Cost cost;
        switch (product.getProductOutput()) {
            case FINISHED:
                cost = mostRecentViewForProductsOn(costName, costAtDate, PRICING_MODEL_FILTER);
                cost = checkAndGetWeightedAverageCostForProduct(product, cost);
                if (!product.getCode().equalsIgnoreCase(costName)) {
                    cost = cost.getCostOfMember(product);
                }
                break;
            case BYPRODUCT_ONLY:
                cost = mostRecentViewForProductsOn(costName, costAtDate, BYPRODUCT_ONLY_FILTER);
                if (cost.getCurrentCostPerPound() == null && cost.getMarketCost() != null) {
                    cost = cost.updateCurrentCost(product);
                    costRepository.save(cost);
                    pricePublisher.publish(cost);
                    itemMasterUpdateService.updateSusItemMaster(product, cost);
                }
                break;
            case SOURCE:
            default:
                cost = mostRecentViewForProductsOn(costName, costAtDate, SUS_FILTER);
                if (cost.getCurrentCostPerPound() == null) {
                    cost = updateFromMostRecentExpiredViewForProductsOn(cost, costAtDate, SUS_FILTER);
                }
                break;
        }
        return cost.isEmpty() ? null : withMissingCostsAsZero(cost);
    }

    private Cost checkAndGetWeightedAverageCostForProduct(final Product product, Cost cost) {
        if (product.isGrouped()) {
            final Cost costOfProduct = mostRecentViewForProductsOn(product.getCode(), now(when), SUS_FILTER);
            cost = cost.assignWeightedAverageCost(costOfProduct);
        }
        return cost;
    }

    /**
     * Consolidate the most recent version of each component of cost: <ul>
     * <li>Market cost - From SUS for source products, from Prime for finished</li>
     * <li>Labor - From Prime</li>
     * <li>Weighted-average cost - From SUS</li>
     * <li>Current cost per pound - Computed by Prime from market cost</li>
     * </ul>
     * <p>
     * This is a <em>bitemporal</em> or <em>fact table</em> approach.
     * <p>
     * For each single cost component, find the cost row which most recently has a value for that component.  For
     * example: if market cost was saved to the DB today for product 1234567 a $2.50, and was also saved yesterday as
     * $1.50, then $2.50 is the most recent market cost.  Repeat this <em>separately</em> for each cost component.
     * Typically the consolidated view has cost components from multiple DB cost records, not all from the same cost
     * record (most records only update a few cost components, not all of them).
     * <p>
     * This approach relies on the {@link CostRepository#mostRecentForAt(String, LocalDate)} custom query, which finds
     * all records for the given <var>product</var> where the
     * <var>costAtDate</var> is included between <em>startDate</em> and <em>endDate</em>
     * fields for those records.  The results are sorted from most recent to oldest in descending order, based on
     * <em>updatedAt</em> or <em>createdAt</em> (when the record has never been updated).
     * <p>
     * The start/end dates and source are defined by the record from which market cost comes.  This provides a
     * consistent view, as if a single, complete record had been read from the DB.
     * <p>
     * Marked {@code public} <strong>solely</strong> so other classes tests can mock.
     */
    public Cost mostRecentViewForProductsOn(
            final String costName, final LocalDate costAt, final Predicate<Cost> costFilter) {
        final List<Cost> costs = costRepository.mostRecentForAt(costName, costAt);
        return mostRecentView(costs, costName, costFilter);
    }

    Cost updateFromMostRecentExpiredViewForProductsOn(
            final Cost cost, final LocalDate costAt, final Predicate<Cost> costFilter) {
        final List<Cost> costs = costRepository.mostRecentExpiredFor(cost.getName(), costAt);
        return updateMostRecentViewOfMarketCostAndCurrentCostPerPound(costs, cost, costFilter);
    }

    private Cost mostRecentViewForYieldModelsNow(
            final String costName, final Long yieldModelId, final Collection<CostSource> sources) {
        final List<Cost> costs = costRepository.findAllByNameAndYieldModelIdAndSourceInOrderByCreatedAtDesc(
                costName, yieldModelId, sources);
        return mostRecentView(costs, costName, ALL_COSTS_FILTER);
    }

    private Cost updateMostRecentViewOfMarketCostAndCurrentCostPerPound(final List<Cost> costs, final Cost currentCost,
                                                                        final Predicate<Cost> costFilter) {
        final CostBuilder builder = currentCost.toBuilder();

        costs.stream().filter(costFilter.and(cost -> null != cost.getMarketCost()))
                .findFirst()
                .ifPresent(cost -> {
                    builder.marketCost(cost.getMarketCost());
                    builder.startDate(cost.getStartDate());
                    builder.endDate(cost.getEndDate());
                    builder.source(cost.getSource());
                });

        copyIfPresent(costs, Cost::getCurrentCostPerPound, builder::currentCostPerPound, costFilter);

        return builder.build();
    }

    /**
     * Market cost is special: the start/end dates and source are defined relative to it.
     */
    private Cost mostRecentView(final List<Cost> costs, final String costName, final Predicate<Cost> costFilter) {
        final CostBuilder builder = Cost.builder()
                .name(costName);

        costs.stream().filter(costFilter.and(cost -> null != cost.getMarketCost()))
                .findFirst()
                .ifPresent(cost -> {
                    builder.marketCost(cost.getMarketCost());
                    builder.startDate(cost.getStartDate());
                    builder.endDate(cost.getEndDate());
                    builder.source(cost.getSource());
                });

        copyIfPresent(costs, Cost::getYieldModelId, builder::yieldModelId, costFilter);
        copyIfPresent(costs, Cost::getLabor, builder::labor, costFilter);
        copyIfPresent(costs, Cost::getCurrentCostPerPound, builder::currentCostPerPound, costFilter);
        copyIfPresent(costs, Cost::getWeightedAverageCost, builder::weightedAverageCost, costFilter);

        return builder.build();
    }

    Cost withStartEndDates(final Cost cost) {
        final LocalDate startDate = cost.getStartDate();
        final LocalDate endDate = cost.getEndDate();
        return cost.toBuilder()
                .startDate(null == startDate ? now(when) : startDate)
                .endDate(null == endDate ? COST_NEVER_EXPIRES : endDate)
                .build();
    }

    public Cost save(Cost cost, final boolean shouldSave) {
        if (null == cost.getSource()) {
            throw new IllegalArgumentException("Cost with no source: " + cost);
        } else {
            if (SUS == cost.getSource()) {
                if (null != cost.getLabor()) {
                    log.error("BUG: SUS cost with labor: {}", cost);
                    cost = cost.toBuilder()
                            .labor(null)
                            .build();
                } else if (null != cost.getYieldModelId()) {
                    log.error("BUG: SUS cost with yield model: {}", cost);
                    cost = cost.toBuilder()
                            .yieldModelId(null)
                            .build();
                }
            } else if (null != cost.getWeightedAverageCost()) {
                log.error("BUG: Prime cost with WAC: {}", cost);
                cost = cost.toBuilder()
                        .weightedAverageCost(null)
                        .build();
            }
        }

        final Cost costWithDates = withStartEndDates(cost);
        if (shouldSave) {
            return costRepository.save(costWithDates);
        }
        return costWithDates;
    }

    public void createByproductOnlyCost(final Cost byproductOnlyCost) {
        final Cost existingCost = mostRecentViewForProductsOn(
                byproductOnlyCost.getName(), now(when), BYPRODUCT_ONLY_FILTER);

        if (existingCost.isEmpty() || byproductOnlyCost.hasPrimeCostChanged(existingCost)) {
            pricePublisher.publish(save(byproductOnlyCost, true));
        }
    }
}
