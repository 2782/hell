package com.sysco.prime.cost;

import com.sysco.prime.PrimeRepository;

import java.time.LocalDate;
import java.util.Collection;
import java.util.List;

public interface CostRepository extends PrimeRepository<Cost> {
    List<Cost> findBySourceInAndStartDateLessThanEqualAndEndDateGreaterThanEqual(
            List<CostSource> sources, LocalDate startDate, LocalDate endDate);

    List<Cost> findAllByNameAndStartDateLessThanEqualAndEndDateGreaterThanEqualOrderByCreatedAtDesc(
            String name, LocalDate costOn, LocalDate sameDate);

    default List<Cost> mostRecentForAt(final String name, final LocalDate costOn) {
        return findAllByNameAndStartDateLessThanEqualAndEndDateGreaterThanEqualOrderByCreatedAtDesc(
                name, costOn, costOn);
    }

    default List<Cost> mostRecentForAt(final String name,
                                       final Long yieldModelId,
                                       final Collection<CostSource> sources,
                                       final LocalDate costOn) {
        // CHECKSTYLE: OFF
        return findAllByNameAndYieldModelIdAndSourceInAndStartDateLessThanEqualAndEndDateGreaterThanEqualOrderByCreatedAtDesc(
                        name, yieldModelId, sources, costOn, costOn);
        // CHECKSTYLE: ON
    }

    List<Cost> findAllByNameAndYieldModelIdAndSourceInOrderByCreatedAtDesc(
            String name, Long yieldModelId, Collection<CostSource> sources);

    // CHECKSTYLE: OFF
    List<Cost> findAllByNameAndYieldModelIdAndSourceInAndStartDateLessThanEqualAndEndDateGreaterThanEqualOrderByCreatedAtDesc(
            String name, Long yieldModelId, Collection<CostSource> sources, LocalDate startDate, LocalDate endDate);
    // CHECKSTYLE: ON

    default List<Cost> mostRecentExpiredFor(final String name, final LocalDate costOn) {
        return findAllByNameAndEndDateLessThanOrderByEndDateDescCreatedAtDesc(
                name, costOn);
    }

    List<Cost> findAllByNameAndEndDateLessThanOrderByEndDateDescCreatedAtDesc(
            final String name, final LocalDate costOn);

    // CHECKSTYLE: OFF
    List<Cost> findByNameAndSourceInAndStartDateGreaterThanEqualAndEndDateLessThanEqualOrderByCreatedAtDesc(String name,
        List<CostSource> asList, LocalDate startDate, LocalDate endDate);
    // CHECKSTYLE: ON
}
