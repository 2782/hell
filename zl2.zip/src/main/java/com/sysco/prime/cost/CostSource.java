package com.sysco.prime.cost;

public enum CostSource {
    SUS, PRICING_MODEL, YIELD_MODEL, BYPRODUCT_OVERRIDE, BYPRODUCT_ONLY, REMOVE_OVERRIDE
}
