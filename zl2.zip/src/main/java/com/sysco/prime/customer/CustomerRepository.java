package com.sysco.prime.customer;

import com.sysco.prime.PrimeRepository;

import java.util.List;

public interface CustomerRepository extends PrimeRepository<Customer> {
    Customer findByCustomerCode(String customerCode);

    List<Customer> findByCustomerCodeIn(List<String> customerCodes);
}
