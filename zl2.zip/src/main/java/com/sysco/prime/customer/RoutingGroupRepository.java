package com.sysco.prime.customer;

import com.sysco.prime.PrimeRepository;
import org.springframework.stereotype.Repository;

@Repository
interface RoutingGroupRepository extends PrimeRepository<RoutingGroup> {
}
