package com.sysco.prime.customer.request;

import com.sysco.prime.customer.CustomerSpecificItemNumber;
import com.sysco.prime.product.ProductService;
import com.sysco.prime.product.validation.ValidProduct;
import lombok.Builder;
import lombok.Getter;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Getter
@Builder
public class CustomerSpecificItemNumberRequest {
    @ValidProduct
    private String productCode;

    @NotNull
    @Size(min = 1, max = 8)
    private String itemNumber;

    CustomerSpecificItemNumber toDomain(final ProductService productService) {
        return CustomerSpecificItemNumber.builder()
                .product(productService.findByCode(productCode))
                .itemNumber(itemNumber)
                .build();
    }
}
