package com.sysco.prime.customer;

import com.sysco.prime.customer.request.CustomerSetupRequest;
import com.sysco.prime.customer.response.CustomerResponse;
import com.sysco.prime.customer.validation.CustomerValidImageFile;
import com.sysco.prime.product.ProductService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.Valid;
import java.util.List;

import static java.util.stream.Collectors.toList;

@Validated
@RestController
@RequestMapping("/api/customers")
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
@Secured({"ROLE_ADMIN", "ROLE_PORTION_ROOM_MEMBER"})
public class CustomerController {

    private final CustomerService customerService;
    private final ProductService productService;

    @GetMapping
    public List<CustomerResponse> getAllCustomers() {
        return customerService.getAllCustomers().stream()
                .map(CustomerResponse::new)
                .collect(toList());
    }

    @GetMapping("/{customerCode}")
    public CustomerResponse getCustomerByCode(@PathVariable("customerCode") final String customerCode) {
        return new CustomerResponse(customerService.findCustomerWithException(customerCode));
    }

    @PostMapping(path = "/setup", consumes = {"multipart/form-data"})
    public CustomerResponse setupCustomer(@Valid @RequestPart(value = "data") final CustomerSetupRequest request,
                                          @RequestPart(value = "file", required = false) @CustomerValidImageFile
                                          final MultipartFile file) {
        return new CustomerResponse(customerService.setupCustomer(request.toDomain(productService), file));
    }
}
