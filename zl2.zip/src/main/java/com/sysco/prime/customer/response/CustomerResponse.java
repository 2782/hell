package com.sysco.prime.customer.response;

import com.sysco.prime.customer.Address;
import com.sysco.prime.customer.Customer;
import com.sysco.prime.customer.CustomerImageFile;
import com.sysco.prime.customer.DateType;
import com.sysco.prime.customer.RoutingGroup;
import com.sysco.prime.customer.SubPrimal;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.ToString;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Getter
@AllArgsConstructor
@Builder(toBuilder = true)
@ToString
public class CustomerResponse {
    private final Long id;
    private final String name;
    private final String customerCode;
    private final String dateType;
    private final String dateTypeDisplayName;
    private final Integer dateValue;
    private final Address address;
    private final List<RoutingGroup> routingGroups;
    private final List<SubPrimal> subPrimals;
    private final List<CustomerSpecificItemNumberResponse> customerSpecificItemNumbers;
    private final CustomerImageFile customerImageFile;

    public CustomerResponse(final Customer customer) {
        id = customer.getId();
        name = customer.getName();
        customerCode = customer.getCustomerCode();
        address = customer.getAddress();
        routingGroups = customer.getRoutingGroups();

        final DateType customerDateType = customer.getDateType();
        dateType = customerDateType != null ? customerDateType.name() : null;
        dateTypeDisplayName = customerDateType != null ? customerDateType.getDisplayValue() : null;
        dateValue = customer.getDateValue();
        subPrimals = customer.getSubPrimals();
        customerSpecificItemNumbers = customer.getItemNumbers().stream()
                .map(CustomerSpecificItemNumberResponse::new)
                .collect(Collectors.toList());
        List<CustomerImageFile> imageList = new ArrayList<>(customer.getCustomerImageFiles());
        customerImageFile = !imageList.isEmpty() && imageList.size() == 1 ? imageList.get(0) : null;
    }
}
