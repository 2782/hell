package com.sysco.prime.customer;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.sysco.prime.product.Product;
import com.sysco.prime.shared.model.TransactionalEntity;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;
import org.hibernate.annotations.Where;

import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Enumerated;
import javax.persistence.OneToMany;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import static com.sysco.prime.customer.DateType.NONE;
import static javax.persistence.CascadeType.ALL;
import static javax.persistence.EnumType.STRING;
import static javax.persistence.FetchType.EAGER;

@AllArgsConstructor
@Builder(toBuilder = true)
@Data
@Entity
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
public class Customer extends TransactionalEntity {
    @NonNull
    private String name;
    @NonNull
    private String customerCode;

    @Embedded
    private Address address;

    @OneToMany(mappedBy = "customer", cascade = ALL, fetch = EAGER, orphanRemoval = true)
    @Fetch(value = FetchMode.SUBSELECT)
    private List<RoutingGroup> routingGroups;

    private boolean broadline;
    @Enumerated(STRING)
    private CustomerType type;

    @Enumerated(STRING)
    private DateType dateType;
    private Integer dateValue;

    @OneToMany(mappedBy = "customer", cascade = ALL, orphanRemoval = true, fetch = EAGER)
    @Builder.Default
    private List<SubPrimal> subPrimals = new ArrayList<>();

    @OneToMany(mappedBy = "customer", cascade = ALL, orphanRemoval = true, fetch = EAGER)
    @Fetch(value = FetchMode.SUBSELECT)
    @Builder.Default
    private List<CustomerSpecificItemNumber> itemNumbers = new ArrayList<>();

    @OneToMany(mappedBy = "customer", cascade = ALL, fetch = EAGER)
    @Where(clause = "deleted = false")
    @Builder.Default
    private Set<CustomerImageFile> customerImageFiles = new LinkedHashSet<>();

    public Integer getDateValue(final Product product) {
        final Optional<SubPrimal> optionalSubPrimal = subPrimals.stream()
                .filter(subPrimal -> subPrimal.getSubPrimalCode().equalsIgnoreCase(product.getSubPrimalCode()))
                .findFirst();
        if (optionalSubPrimal.isPresent()) {
            return optionalSubPrimal.get().getDateValue();
        } else {
            return dateValue;
        }
    }

    public boolean hasDateType() {
        return NONE != dateType;
    }

    public void attachRoutingGroup() {
        routingGroups.forEach(routingGroup -> routingGroup.attachTo(this));
    }

    void attachImages() {
        customerImageFiles.forEach(imageFile -> imageFile.attachTo(this));
    }

    public void attachToCustomerSpecificItems() {
        itemNumbers.forEach(itemNumber -> itemNumber.attachTo(this));
    }

    public void update(final Customer customer) {
        this.name = customer.getName();
        this.address = customer.getAddress();
        this.broadline = customer.isBroadline();
        this.routingGroups = customer.getRoutingGroups();
        this.attachRoutingGroup();
    }

    void overrideSubPrimals(final List<SubPrimal> subPrimals) {
        this.subPrimals.forEach(subPrimal -> subPrimal.setCustomer(null));
        this.subPrimals = subPrimals;
        this.subPrimals.forEach(subPrimal -> subPrimal.setCustomer(this));
    }

    void overrideCustomerSpecificItemNumber(final List<CustomerSpecificItemNumber> itemNumbers) {
        this.itemNumbers.forEach(itemNumber -> itemNumber.setCustomer(null));
        this.itemNumbers = itemNumbers;
        this.itemNumbers.forEach((itemNumber -> itemNumber.setCustomer(this)));
    }

    void updateCustomerImageFile(final boolean includeCustomerImage, final CustomerImageFile file) {
        if (file == null && includeCustomerImage) {
            return;
        }
        this.customerImageFiles.forEach(CustomerImageFile::markDelete);
        if (file != null) {
            file.setCustomer(this);
            this.customerImageFiles.add(file);
        }
    }

    @JsonIgnore
    public boolean isInternalCustomer() {
        return CustomerType.I == type;
    }
}
