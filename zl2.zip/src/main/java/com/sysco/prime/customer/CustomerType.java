package com.sysco.prime.customer;

public enum CustomerType {
    E("Employee"),
    I("Intracompany"),
    R("Intercompany"),
    S("Sales to vendors"),
    T("Trade"),
    V("Vendor"),
    W("Bad debt write-offs");

    private String displayValue;

    CustomerType(final String displayValue) {
        this.displayValue = displayValue;
    }

    public static CustomerType from(final String value) {
        for (final CustomerType type : values()) {
            if (type.toString().equals(value)) {
                return type;
            }
        }
        return null;
    }
}
