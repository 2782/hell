package com.sysco.prime.customer;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.sysco.prime.shared.model.TransactionalEntity;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Generated;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import java.util.Objects;

import static java.lang.Boolean.TRUE;
import static javax.persistence.FetchType.EAGER;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder(toBuilder = true)
public class CustomerImageFile extends TransactionalEntity {
    @ManyToOne(fetch = EAGER)
    @JoinColumn(name = "customerId")
    @JsonIgnore
    private Customer customer;
    private String fileName;
    private String fileType;
    private byte[] data;
    @JsonIgnore
    private boolean deleted;

    public CustomerImageFile markDelete() {
        deleted = TRUE;
        return this;
    }

    CustomerImageFile attachTo(final Customer customer) {
        this.customer = customer;
        return this;
    }

    @Generated
    @Override
    public boolean equals(final Object other) {
        if (this == other) {
            return true;
        }

        if (other == null || getClass() != other.getClass()) {
            return false;
        }

        final CustomerImageFile that = (CustomerImageFile) other;

        if (customer != null) {
            if (!customer.getCustomerCode().equals(that.customer.getCustomerCode())) {
                return false;
            }
        } else if (that.customer != null) {
            return false;
        }

        return Objects.equals(fileType, that.fileType)
                && Objects.equals(fileName, that.fileName)
                && Objects.equals(deleted, that.deleted);
    }

    @Generated
    @Override
    public int hashCode() {
        Boolean deletedBoolean = Boolean.valueOf(deleted);
        int result = customer != null ? customer.getCustomerCode().hashCode() : 0;
        result = 31 * result + (fileType != null ? fileType.hashCode() : 0);
        result = 31 * result + (fileName != null ? fileName.hashCode() : 0);
        result = 31 * result + deletedBoolean.hashCode();

        return result;
    }
}

