package com.sysco.prime.customer.validation;

import com.sysco.prime.customer.request.SubPrimalRequest;
import com.sysco.prime.exception.NotFoundException;
import com.sysco.prime.product.ProductService;
import com.sysco.prime.product.validation.PrimeConstraintValidator;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.validation.ConstraintValidatorContext;

import static com.sysco.prime.validation.ValidationErrorType.NOT_EXIST;

@Component
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class SubPrimalValidator implements PrimeConstraintValidator<ValidSubPrimal, SubPrimalRequest> {
    private final ProductService productService;

    @Override
    public boolean isValid(final SubPrimalRequest subPrimalRequest, final ConstraintValidatorContext context) {
        final String subPrimalCode = subPrimalRequest.getSubPrimalCode();

        return checkSubPrimalCodeExists(subPrimalCode, context);
    }

    private boolean checkSubPrimalCodeExists(final String subPrimalCode, final ConstraintValidatorContext context) {
        try {
            productService.findBySubPrimalCode(subPrimalCode);
        } catch (final NotFoundException ignored) {
            return validationFailedBecause(context, NOT_EXIST);
        }

        return true;
    }
}
