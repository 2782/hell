package com.sysco.prime.customer;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.sysco.prime.shared.model.TransactionalEntity;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import static javax.persistence.FetchType.LAZY;

@EqualsAndHashCode(callSuper = false)
@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@ToString(exclude = {"customer"})
public class SubPrimal extends TransactionalEntity {
    @ManyToOne(fetch = LAZY)
    @JoinColumn(name = "customerId")
    @JsonIgnore
    private Customer customer;

    private String subPrimalCode;
    private Integer dateValue;
}
