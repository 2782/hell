package com.sysco.prime.customer;

import com.sysco.prime.customerOrder.CustomerOrder;
import com.sysco.prime.customerOrder.CustomerOrderService;
import com.sysco.prime.exception.InvalidValueException;
import com.sysco.prime.exception.NotFoundException;
import com.sysco.prime.profile.ProfileService;
import com.sysco.prime.sus.client.SusClient;
import com.sysco.prime.sus.model.SusCustomerData;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

import static java.lang.String.format;
import static java.util.Collections.emptyList;

@Service
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class CustomerService {
    private final CustomerRepository repository;
    private final ProfileService profileService;
    private final CustomerOrderService customerOrderService;
    private final RoutingGroupService routingGroupService;
    private final SusClient susClient;

    public Customer create(final Customer customer) {
        final Customer existingCustomer = repository.findByCustomerCode(customer.getCustomerCode());

        if (existingCustomer != null) {
            return null;
        }
        customer.attachRoutingGroup();

        return repository.save(customer);
    }

    List<Customer> getCustomersByCodes(final List<String> customerCodes) {
        if (customerCodes.isEmpty()) {
            return emptyList();
        }

        return repository.findByCustomerCodeIn(customerCodes);
    }

    List<Customer> getAllCustomers() {
        return repository.findAll();
    }

    public Customer getCustomerByCode(final String customerCode) {
        if (customerCode == null || customerCode.isEmpty()) {
            return null;
        }

        final Customer existingCustomer = repository.findByCustomerCode(customerCode);

        if (existingCustomer != null) {
            return existingCustomer;
        }

        final Customer customerFromSus = getCustomerFromSus(customerCode);

        if (customerFromSus != null) {
            return repository.save(customerFromSus);
        }

        return null;
    }

    Customer findCustomerWithException(final String customerCode) {
        final Customer customer = getCustomerByCode(customerCode);
        if (customer == null) {
            throw new NotFoundException(format("[find customer] customer not found by code: %s", customerCode));
        }
        return customer;
    }

    Customer getCustomerFromSus(final String customerNo) {
        final SusCustomerData customerFromSus = susClient.getCustomerFromSus(profileService.get(), customerNo);
        if (customerFromSus == null) {
            return null;
        }

        return customerFromSus.toDomain();
    }

    public void sync() {
        customerOrderService.findRemainingOrders().stream().map(CustomerOrder::getCustomerCode)
                .distinct()
                .forEach(customerCode -> update(getCustomerFromSus(customerCode)));
    }

    private Customer update(final Customer customer) {
        if (customer == null) {
            return null;
        }

        final Customer existedCustomer = repository.findByCustomerCode(customer.getCustomerCode());
        routingGroupService.delete(existedCustomer.getRoutingGroups());
        existedCustomer.update(customer);

        return repository.save(existedCustomer);
    }

    Customer setupCustomer(final CustomerSetup customerSetup, final MultipartFile file) {
        final Customer existedCustomer = repository.findByCustomerCode(customerSetup.getCustomerCode());

        try {
            CustomerImageFile customerImageFile = null;
            if (file != null) {
                final String originalFilename = file.getOriginalFilename();
                if (originalFilename == null) {
                    throw new InvalidValueException("Missing original file name");
                }
                final String fileName = StringUtils.cleanPath(originalFilename);
                customerImageFile = CustomerImageFile.builder()
                        .fileName(fileName)
                        .fileType(file.getContentType())
                        .data(file.getBytes())
                        .deleted(false)
                        .build();
            }

            final Customer setupCustomer = customerSetup.getSetupCustomer(existedCustomer, customerImageFile);
            return repository.save(setupCustomer);
        } catch (IOException e) {
            throw new ImageFileException("Error adding image file to Customer ", e);
        }
    }
}
