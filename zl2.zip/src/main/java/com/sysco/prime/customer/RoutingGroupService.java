package com.sysco.prime.customer;

import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class RoutingGroupService {
    private final RoutingGroupRepository repository;

    public void delete(final List<RoutingGroup> routingGroups) {
        routingGroups.forEach(repository::delete);
    }
}
