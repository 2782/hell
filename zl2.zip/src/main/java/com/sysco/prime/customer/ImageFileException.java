package com.sysco.prime.customer;

public class ImageFileException extends RuntimeException {
    public ImageFileException(final String message) {
        super(message);
    }

    ImageFileException(final String reason, final Throwable cause) {
        super(reason, cause);
    }
}
