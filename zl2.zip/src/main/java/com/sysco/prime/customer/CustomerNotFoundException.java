package com.sysco.prime.customer;

import com.sysco.prime.exception.NotFoundException;

public class CustomerNotFoundException extends NotFoundException {
    public CustomerNotFoundException(final String message) {
        super(message);
    }
}
