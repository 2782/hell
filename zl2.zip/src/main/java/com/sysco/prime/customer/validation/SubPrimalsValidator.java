package com.sysco.prime.customer.validation;

import com.sysco.prime.customer.request.CustomerSetupRequest;
import com.sysco.prime.customer.request.SubPrimalRequest;
import com.sysco.prime.product.validation.PrimeConstraintValidator;
import org.springframework.stereotype.Component;

import javax.validation.ConstraintValidatorContext;
import java.util.HashSet;
import java.util.List;

import static com.sysco.prime.validation.ValidationErrorType.IDENTICAL;
import static java.util.stream.Collectors.toList;

@Component
public class SubPrimalsValidator implements PrimeConstraintValidator<ValidSubPrimals, CustomerSetupRequest> {

    @Override
    public boolean isValid(final CustomerSetupRequest customerSetupRequest, final ConstraintValidatorContext context) {
        return !haveDuplicatedSubPrimals(customerSetupRequest.getSubPrimals(), context) ;
    }

    private boolean haveDuplicatedSubPrimals(final List<SubPrimalRequest> subPrimals,
                                             final ConstraintValidatorContext context) {
        final List<String> subPrimalCodes = subPrimals.stream()
                .map(SubPrimalRequest::getSubPrimalCode)
                .collect(toList());

        if (subPrimalCodes.size() != new HashSet<>(subPrimalCodes).size()) {
            validationFailedBecause(context, IDENTICAL);
            return true;
        }

        return false;
    }
}
