package com.sysco.prime.customer;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.ToString;

import java.util.List;

@AllArgsConstructor
@Builder
@Getter
@EqualsAndHashCode
@ToString
public class CustomerSetup {
    private String customerCode;
    private DateType dateType;
    private Integer dateValue;
    private List<SubPrimal> subPrimals;
    private List<CustomerSpecificItemNumber> customerSpecificItemNumbers;
    private boolean includeCustomerLogo;

    public Customer getSetupCustomer(final Customer customer, CustomerImageFile imageFile) {
        final Customer result = customer.toBuilder().build();
        result.setDateType(dateType);
        result.setDateValue(dateValue);
        result.overrideSubPrimals(subPrimals);
        result.overrideCustomerSpecificItemNumber(customerSpecificItemNumbers);
        result.setId(customer.getId());
        result.setCreatedAt(customer.getCreatedAt());
        result.updateCustomerImageFile(includeCustomerLogo, imageFile);
        return result;
    }
}
