package com.sysco.prime.customer.request;

import com.sysco.prime.customer.CustomerSetup;
import com.sysco.prime.customer.DateType;
import com.sysco.prime.customer.validation.ValidDays;
import com.sysco.prime.customer.validation.ValidSubPrimals;
import com.sysco.prime.portionRoom.validation.ValidCustomerNumber;
import com.sysco.prime.product.ProductService;
import lombok.Builder;
import lombok.Data;

import javax.validation.Valid;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import java.util.List;

import static java.util.stream.Collectors.toList;

@Data
@Builder
@ValidSubPrimals
public class CustomerSetupRequest {
    @NotNull
    @ValidCustomerNumber(internal = false)
    private String customerCode;
    @NotNull
    private String dateType;
    @Min(1)
    @Max(99)
    @ValidDays
    private Integer dateValue;

    @Valid
    private List<SubPrimalRequest> subPrimals;

    @Valid
    private List<CustomerSpecificItemNumberRequest> customerSpecificItemNumbers;

    private boolean includeCustomerLogo;

    public CustomerSetup toDomain(final ProductService productService) {
        return CustomerSetup.builder()
                .customerCode(customerCode)
                .dateType(DateType.valueOf(dateType))
                .dateValue(dateValue)
                .subPrimals(subPrimals.stream()
                        .map(SubPrimalRequest::toDomain)
                        .collect(toList())
                )
                .customerSpecificItemNumbers(customerSpecificItemNumbers.stream()
                        .map(request -> request.toDomain(productService))
                        .collect(toList()))
                .includeCustomerLogo(includeCustomerLogo)
                .build();
    }
}
