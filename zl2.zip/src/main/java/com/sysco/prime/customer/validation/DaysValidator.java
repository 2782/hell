package com.sysco.prime.customer.validation;

import com.sysco.prime.product.validation.PrimeConstraintValidator;
import org.springframework.stereotype.Component;

import javax.validation.ConstraintValidatorContext;

import static com.sysco.prime.validation.ValidationErrorType.INVALID;

@Component
public class DaysValidator implements PrimeConstraintValidator<ValidDays, Integer> {
    @Override
    public boolean isValid(final Integer days, final ConstraintValidatorContext context) {
        if (days == null || days > 0) {
            return true;
        }
        return validationFailedBecause(context, INVALID);
    }
}
