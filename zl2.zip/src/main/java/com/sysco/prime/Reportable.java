package com.sysco.prime;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.type.MapType;
import com.sysco.prime.housePar.HousePar;
import com.sysco.prime.reporting.model.ReportingHousePar;
import com.sysco.prime.reporting.processing.HouseParProcessor;

import java.io.Serializable;
import java.util.Map;
import java.util.regex.Pattern;

public interface Reportable extends Serializable {
    Pattern publishing = Pattern.compile("^Publishing");

    /**
     * Uses convention over configuration.  The <em>name</em> of a reportable event class <strong>must</strong> match
     * the name of the <em>domain</em> type they wrap with the text, "Reporting", prepended.
     * <p>
     * Example: {@link ReportingHousePar} events hold {@link HousePar} domain objects, and are processed by a {@link
     * HouseParProcessor} (for those events with a processor; not all have them).
     * <p>
     * The sole exception is for "YieldModel", which is used for both cutting and grinding yield model domain objects
     * (so they override {@code typeName()}.
     */
    @JsonIgnore
    default String typeName() {
        return publishing.matcher(getClass().getSimpleName()).replaceFirst("");
    }

    default String productCode() {
        return null;
    }

    default Map<String, Object> asMap(final ObjectMapper mapper) {
        final MapType typedMap = mapper
                .getTypeFactory()
                .constructMapType(Map.class, String.class, Object.class);
        return mapper.convertValue(this, typedMap);
    }
}
