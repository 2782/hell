package com.sysco.prime.purchaseOrder;

import com.sysco.prime.PrimeRepository;

import java.time.LocalDate;
import java.util.List;

public interface PurchaseLineItemCaseRepository extends PrimeRepository<PurchaseLineItemCase> {
    List<PurchaseLineItemCase> findByPackDate(final LocalDate openDate);
}
