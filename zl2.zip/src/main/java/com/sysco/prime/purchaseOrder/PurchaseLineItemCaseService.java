package com.sysco.prime.purchaseOrder;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
public class PurchaseLineItemCaseService {
    private final PurchaseLineItemCaseRepository repository;

    @Autowired
    public PurchaseLineItemCaseService(final PurchaseLineItemCaseRepository repository) {
        this.repository = repository;
    }

    public void save(final PurchaseLineItemCase purchaseLineItemCase) {
        repository.save(purchaseLineItemCase);
    }

    List<PurchaseLineItemCase> findLineItemCasesForCurrentWorkingDay(final LocalDate openDate) {
        return repository.findByPackDate(openDate);
    }
}
