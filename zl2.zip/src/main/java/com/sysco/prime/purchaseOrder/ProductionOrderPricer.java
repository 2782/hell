package com.sysco.prime.purchaseOrder;

import com.sysco.prime.cost.Cost;
import com.sysco.prime.cost.CostService;
import com.sysco.prime.product.Product;
import com.sysco.prime.productionOrder.ProductionOrder;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.function.Function;

import static java.math.BigDecimal.ZERO;

@Component
@Slf4j
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class ProductionOrderPricer implements Function<ProductionOrder, BigDecimal> {
    private final CostService costService;

    @Override
    public BigDecimal apply(final ProductionOrder productionOrder) {
        final Product product = productionOrder.getProduct();

        final Cost cost = costService.findCost(product);
        if (null == cost) {
            log.error("No pricing yield model for product: {}", product.getCode());
            return ZERO;
        }

        return cost.getMarketCost();
    }
}
