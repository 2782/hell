package com.sysco.prime.packages;

import com.sysco.prime.PrimeRepository;

public interface PiecesPackageRepository extends PrimeRepository<PiecesPackage> {
}
