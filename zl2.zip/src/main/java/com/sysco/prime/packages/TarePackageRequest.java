package com.sysco.prime.packages;

import com.sysco.prime.product.validation.UniqueTarePackage;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@UniqueTarePackage
@Data
@Builder(toBuilder = true)
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
public class TarePackageRequest {
    private Long id;
    private BoxType boxType;
    private FilmType filmType;
    private boolean defaulted;

    public TarePackage toTarePackage() {
        final TarePackage tarePackage = new TarePackage(boxType, filmType, defaulted);
        tarePackage.setId(this.id);

        return tarePackage;
    }
}
