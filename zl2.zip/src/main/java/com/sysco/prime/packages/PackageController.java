package com.sysco.prime.packages;

import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import java.net.URI;
import java.util.List;

import static org.springframework.http.HttpStatus.CREATED;
import static org.springframework.http.ResponseEntity.created;

@RestController
@RequestMapping("/api/package")
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class PackageController {
    private final PackageService packageService;

    @GetMapping("/box-types")
    @Secured({"ROLE_ADMIN"})
    public List<BoxType> getAllBoxTypes() {
        return packageService.getAllBoxTypes();
    }

    @GetMapping("/film-types")
    @Secured({"ROLE_ADMIN"})
    public List<FilmType> getAllFilmTypes() {
        return packageService.getAllFilmTypes();
    }

    @GetMapping("/tare-packages")
    @Secured({"ROLE_ADMIN", "ROLE_COSTING"})
    public List<TarePackage> getAllTarePackages() {
        return packageService.getAllTarePackages();
    }

    @GetMapping("/tare-package/{id}")
    @Secured({"ROLE_ADMIN"})
    public TarePackage findOneTarePackage(@PathVariable("id") final Long id) {
        return packageService.findTarePackageById(id);
    }

    @GetMapping("/tare-package/default")
    @Secured({"ROLE_ADMIN", "ROLE_PORTION_ROOM_MEMBER"})
    public TarePackage getDefaultTarePackage() {
        return packageService.findDefaultParePackage();
    }

    @PostMapping("/tare-packages")
    @ResponseStatus(CREATED)
    @Secured({"ROLE_ADMIN"})
    public ResponseEntity<?> saveOneTarePackage(@RequestBody @Valid final TarePackageRequest tarePackageRequest) {
        final TarePackage saved = packageService.saveOneTarePackage(tarePackageRequest.toTarePackage());
        return created(URI.create("/api/package/tare-package/" + saved.getId())).build();
    }

    @GetMapping("/pieces-packages")
    @Secured({"ROLE_ADMIN", "ROLE_COSTING"})
    public List<PiecesPackage> getAllPiecesPackages() {
        return packageService.getAllPiecesPackages();
    }
}
