package com.sysco.prime.productionOrder.response.cut;

import com.sysco.prime.productionOrder.CutOrderSource;

import java.time.LocalDate;
import java.util.List;
import java.util.function.Predicate;

import static com.google.common.collect.Lists.newArrayList;
import static java.util.stream.Collectors.toList;

final class CutOrderSummaryItemHelper {
    static List<CutOrderSummaryItem> groupOrdersToNextWorkingDay(
            final List<CutOrderSummaryItem> cutOrderSummaryItems,
            final LocalDate firstDate, final LocalDate secondDate) {
        final List<CutOrderSummaryItem> results = newArrayList();

        addSummaryToResults(cutOrderSummaryItems, results, isFirstWorkingDayPredicate(firstDate), firstDate);
        addSummaryToResults(
                cutOrderSummaryItems, results, isNextWorkingDayPredicate(firstDate, secondDate), secondDate);
        addSummaryToResults(cutOrderSummaryItems, results, isFutureDayPredicate(secondDate), null);
        addSummaryToResults(cutOrderSummaryItems, results, isHouseParPredicate(), firstDate);

        return results;
    }

    private static void addSummaryToResults(
            final List<CutOrderSummaryItem> cutOrderSummaryItems,
            final List<CutOrderSummaryItem> results,
            final Predicate<CutOrderSummaryItem> predicate,
            final LocalDate workingDate) {

        final List<CutOrderSummaryItem> filteredItems =
                cutOrderSummaryItems.stream().filter(predicate).collect(toList());
        final long total = filteredItems.stream().mapToLong(CutOrderSummaryItem::getTotal).sum();

        if (0 != total) {
            final CutOrderSource source = filteredItems.get(0).getSource();

            final CutOrderSummaryItem item = CutOrderSummaryItem.builder()
                    .source(source)
                    .date(workingDate)
                    .total(total)
                    .build();
            results.add(item);
        }
    }

    private static Predicate<CutOrderSummaryItem> isFutureDayPredicate(final LocalDate secondDate) {
        return entry -> entry.isFromLineItem() && entry.getDate().isAfter(secondDate);
    }

    private static Predicate<CutOrderSummaryItem> isNextWorkingDayPredicate(
            final LocalDate firstDate, final LocalDate secondDate) {
        return entry -> entry.isFromLineItem()
                && entry.getDate().isAfter(firstDate) && !entry.getDate().isAfter(secondDate);
    }

    private static Predicate<CutOrderSummaryItem> isFirstWorkingDayPredicate(final LocalDate firstDate) {
        return entry -> entry.isFromLineItem() && entry.isShippedOn(firstDate);
    }

    private static Predicate<CutOrderSummaryItem> isHouseParPredicate() {
        return CutOrderSummaryItem::isFromHousePar;
    }
}
