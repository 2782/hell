package com.sysco.prime.productionOrder;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

@Component
public class StringCutOrderStatusConverter implements Converter<String, CutOrderStatus> {
    @Override
    public CutOrderStatus convert(final String source) {
        return CutOrderStatus.from(source);
    }
}
