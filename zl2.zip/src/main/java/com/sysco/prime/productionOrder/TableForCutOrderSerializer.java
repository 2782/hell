package com.sysco.prime.productionOrder;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.ser.std.StdSerializer;
import com.sysco.prime.portionRoomTable.PortionRoomTable;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class TableForCutOrderSerializer extends StdSerializer<PortionRoomTable> {
    protected TableForCutOrderSerializer() {
        super(PortionRoomTable.class);
    }

    @Override
    public void serialize(final PortionRoomTable table, final JsonGenerator gen,
                          final SerializerProvider provider) throws IOException {
        final Map<String, Object> map = new HashMap<>();
        map.put("tableCode", table.getTableCode());
        map.put("tableDescription", table.getTableDescription());
        final HashMap<String, Object> portionRoomTable = new HashMap<>();
        portionRoomTable.put("id", table.getStation().getId());
        portionRoomTable.put("stationCode", table.getStation().getStationCode());
        portionRoomTable.put("name", table.getStation().getName());
        map.put("station", portionRoomTable);

        gen.writeObject(map);
    }
}
