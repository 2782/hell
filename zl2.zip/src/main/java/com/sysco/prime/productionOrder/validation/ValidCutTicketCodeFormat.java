package com.sysco.prime.productionOrder.validation;

import javax.validation.Constraint;
import javax.validation.Payload;
import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import static java.lang.annotation.ElementType.PARAMETER;
import static java.lang.annotation.ElementType.TYPE_USE;

@Constraint(validatedBy = {CutTicketCodeFormatValidator.class})
@Documented
@Target({TYPE_USE, PARAMETER})
@Retention(RetentionPolicy.RUNTIME)
public @interface ValidCutTicketCodeFormat {

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};

    String message() default "Invalid Cut Ticket Code Format";
}