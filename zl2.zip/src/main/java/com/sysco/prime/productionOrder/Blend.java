package com.sysco.prime.productionOrder;

import com.sysco.prime.exception.InvalidValueException;
import com.sysco.prime.shared.model.TransactionalEntity;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;

import javax.persistence.Entity;
import java.util.Comparator;
import java.util.Optional;

@Entity
@Getter
@AllArgsConstructor
@Builder(toBuilder = true)
@EqualsAndHashCode(callSuper = false)
@ToString
@NoArgsConstructor
public class Blend extends TransactionalEntity {
    private String name;
    private String displayName;
    private int priority;
    private String description;

    public static Blend fromString(final String name, final BlendRepository blendRepository) {
        final String correctedName = name.trim().toUpperCase();
        final Optional<Blend> maybeBlend = blendRepository.findByName(correctedName);
        if (maybeBlend.isPresent()) {
            return maybeBlend.get();
        }
        throw new InvalidValueException("Invalid Blend Name: " + correctedName);
    }


    public static boolean existBlendName(final String name, final BlendRepository blendRepository) {
        final String correctedName = name.trim().toUpperCase();
        return blendRepository.findByName(correctedName).isPresent();
    }

    public static final Comparator<Blend> blendComparator = Comparator
            .comparingInt(Blend::getPriority);
}
