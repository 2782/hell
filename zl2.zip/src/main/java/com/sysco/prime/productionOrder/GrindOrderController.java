package com.sysco.prime.productionOrder;

import com.sysco.prime.customerOrder.LineItemService;
import com.sysco.prime.customerOrder.PrimeLineItem;
import com.sysco.prime.productionOrder.response.cut.GrindOrderResponse;
import com.sysco.prime.productionOrder.validation.ValidGrindTicketCodeFormat;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import static java.util.stream.Collectors.toList;
import static org.springframework.http.HttpStatus.CREATED;
import static org.springframework.http.HttpStatus.OK;

@Validated
@RestController
@RequestMapping("/api/orders/grind")
@Slf4j
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class GrindOrderController {
    private final ProductionOrderService productionOrderService;
    private final LineItemService lineItemService;

    @GetMapping
    @ApiOperation("get orders to-grind")
    @Secured({"ROLE_ADMIN", "ROLE_PORTION_ROOM_MEMBER"})
    public List<GrindOrderResponse> getAllOrders(
            @RequestParam("room-code") final String roomCode,
            @RequestParam("status") final Optional<List<String>> statuses,
            @RequestParam("cancelled") final Optional<Boolean> cancelled) {
        return productionOrderService.findActiveGrindOrders(roomCode, statuses, cancelled).stream()
                .map(GrindOrderResponse::new)
                .collect(toList());
    }

    @GetMapping("/ticket/{grindTicketCode}/room/{roomCode}")
    @ResponseStatus(OK)
    public String checkGrindTicketCodeAndRoomCode(@PathVariable
                                                  @ValidGrindTicketCodeFormat final String grindTicketCode,
                                                  @PathVariable final String roomCode) {
        return productionOrderService
                .getProductForGroupedProductionOrdersByGrindTicketCodeAndRoomCode(grindTicketCode, roomCode);
    }

    @PostMapping("/schedule")
    @ApiOperation("schedule orders to-grind")
    @Secured({"ROLE_ADMIN"})
    @ResponseStatus(CREATED)
    public void scheduleGrindOrdersForCustomers(@RequestBody final Map<Long, Integer> scheduleMap) {
        final List<PrimeLineItem> primeLineItems = lineItemService.getPrimeLineItemsFromSchedule(scheduleMap);
        productionOrderService.scheduleGrindOrders(primeLineItems, scheduleMap);
    }

    @PostMapping("/house-pars/schedule")
    @ApiOperation("post house-pars to schedule")
    @ResponseStatus(CREATED)
    @Secured({"ROLE_ADMIN"})
    public void scheduleGrindOrdersForHousePar(@RequestBody final Map<Long, Integer> scheduleMap,
                                               @RequestParam("room-code") final String roomCode) {
        productionOrderService.scheduleHouseParGrindingOrders(scheduleMap, roomCode);
    }

    @PostMapping("/approve")
    @Secured({"ROLE_ADMIN"})
    public void approveGrindOrdersForTheDay(@RequestParam("room-code") final String roomCode) {
        productionOrderService.approveGrindOrdersForTheDay(roomCode);
    }

    @PostMapping("/update/{id}/qtyInBoxes/{qtyInBoxes}")
    @ApiOperation("update production order's qtyInBoxes")
    @Secured({"ROLE_ADMIN"})
    public void updateProductionOrderQtyInBoxes(@PathVariable final long id, @PathVariable final int qtyInBoxes) {
        productionOrderService.updatePurchaseOrderQuantity(id, qtyInBoxes);
    }
}
