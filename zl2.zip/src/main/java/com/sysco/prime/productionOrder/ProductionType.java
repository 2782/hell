package com.sysco.prime.productionOrder;

import com.sysco.prime.portionRoom.PortionRoomType;

public enum ProductionType {
    CUTTING, GRINDING;

    public static ProductionType from(final PortionRoomType roomType) {
        return ProductionType.valueOf(roomType.toString());
    }
}
