package com.sysco.prime.productionOrder;

import com.sysco.prime.exception.NotFoundException;

public class ProductionOrderNotFoundException extends NotFoundException {
    public ProductionOrderNotFoundException(final String message) {
        super(message);
    }
}
