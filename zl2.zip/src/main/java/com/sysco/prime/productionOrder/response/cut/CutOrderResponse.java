package com.sysco.prime.productionOrder.response.cut;

import com.sysco.prime.box.Box;
import com.sysco.prime.box.BoxResponse;
import com.sysco.prime.customerOrder.LineItem;
import com.sysco.prime.customerOrder.response.CustomerOrderResponse;
import com.sysco.prime.portionRoomTable.response.PortionRoomTableResponse;
import com.sysco.prime.product.response.ProductResponse;
import com.sysco.prime.productionOrder.ProductionOrder;
import com.sysco.prime.productionOrder.ProductionType;
import lombok.Getter;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import static java.util.stream.Collectors.toList;

@Getter
public class CutOrderResponse {
    final DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("MM/dd hh:mm a");

    private final Long id;
    private final String source;
    private final String unitOfMeasure;
    private final String cutType;
    private final String packInstruction;
    private final Integer piecesPerCase;
    private final String producingInstruction;
    private final Integer qtyToProduce;
    private final Integer qtyPacked;
    private final LocalDate deliveryDate;
    private final Integer qtyInPieces;
    private final Integer qtyInBoxes;
    private final String status;
    private final String cutSelectedAt;
    private final Long purchaseOrderId;
    private final ProductionType productionType;
    private final Boolean deleted;
    private final Boolean updated;
    private ProductResponse product;
    private CustomerOrderResponse customerOrder;
    private PortionRoomTableResponse portionRoomTable;
    private List<BoxResponse> packedBoxes;

    public CutOrderResponse(final ProductionOrder productionOrder,
                            final List<Box> boxesForOrder) {
        id = productionOrder.getId();
        source = productionOrder.getSource().toString();
        unitOfMeasure = productionOrder.getUnitOfMeasure().toString();
        cutType = productionOrder.getOrderType().toString();
        packInstruction = productionOrder.getPackInstruction();
        piecesPerCase = productionOrder.getPiecesPerCase();
        producingInstruction = productionOrder.getProducingInstruction();
        qtyToProduce = productionOrder.getQtyToProduce();
        qtyPacked = productionOrder.getQtyPacked();
        deliveryDate = productionOrder.getDeliveryDate();
        qtyInPieces = productionOrder.getQtyToProduceInPieces();
        qtyInBoxes = productionOrder.getQtyToProduceInCases();
        status = productionOrder.getStatus().toString();
        cutSelectedAt = productionOrder.getStartProducingAt() == null ? "" :
                productionOrder.getStartProducingAt().toLocalDateTime().format(dateTimeFormatter);
        purchaseOrderId = productionOrder.getPurchaseOrderId();
        productionType = productionOrder.getProductionType();

        if (productionOrder.getCustomerOrder() != null) {
            customerOrder = new CustomerOrderResponse(productionOrder.getCustomerOrder());
        }

        if (productionOrder.getPortionRoomTable() != null) {
            portionRoomTable = new PortionRoomTableResponse(productionOrder.getPortionRoomTable());
        }

        if (productionOrder.getProduct() != null) {
            product = new ProductResponse(productionOrder.getProduct());
        }

        if (boxesForOrder != null) {
            packedBoxes = boxesForOrder.stream()
                    .map(BoxResponse::from)
                    .collect(toList());
        }

        if (productionOrder.getProduct() != null
                && productionOrder.getCustomerOrder() != null
                && productionOrder.getLineItem() != null) {
            LineItem lineItem = productionOrder.getLineItem();
            deleted = lineItem.isDeleted();
            updated = lineItem.getUpdatedAt() != null;
        } else {
            deleted = false;
            updated = false;
        }
    }
}
