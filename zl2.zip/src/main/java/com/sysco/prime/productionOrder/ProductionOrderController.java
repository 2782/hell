package com.sysco.prime.productionOrder;

import com.sysco.prime.box.Box;
import com.sysco.prime.box.BoxService;
import com.sysco.prime.productionOrder.request.cut.CutOrderRequest;
import com.sysco.prime.productionOrder.response.cut.CutOrderResponse;
import com.sysco.prime.productionOrder.response.cut.CutOrderStationSummary;
import com.sysco.prime.productionOrder.response.cut.CutOrderTableSummary;
import com.sysco.prime.productionOrder.validation.ValidCutTicketCodeFormat;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.security.access.annotation.Secured;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import static java.util.stream.Collectors.toList;
import static org.springframework.format.annotation.DateTimeFormat.ISO.DATE;
import static org.springframework.http.HttpStatus.NO_CONTENT;
import static org.springframework.http.HttpStatus.OK;

@Validated
@RestController
@RequestMapping("/api/cut-orders")
@Slf4j
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
@Secured({"ROLE_ADMIN", "ROLE_PORTION_ROOM_MEMBER"})
public class ProductionOrderController {
    private final ProductionOrderService productionOrderService;
    private final BoxService boxService;


    @PatchMapping
    @ApiOperation(value = "update the order model",
            notes = "update the order,for example changing the status of the "
                    + "multiple order specified by id from TO_CUT to TO_PACK. "
                    + "an be used by ConfirmCutSelectedOrders page")
    @ResponseStatus(NO_CONTENT)
    public void cut(@RequestBody final List<CutOrderRequest> cutOrderRequests) {
        final List<ProductionOrder> productionOrders = cutOrderRequests.stream()
                .map(CutOrderRequest::toCutOrder)
                .collect(toList());
        productionOrderService.updateAll(productionOrders);
    }

    @GetMapping
    @ApiOperation(value = "get orders to-cut or to-pack",
            notes = "get CutOrders resource(same as the model in database) "
                    + "based on given tableId and CutOrderStatus. "
                    + "This is the api for order list, can be used by CutOrderList page and PackOrderList page.")
    public List<CutOrderResponse> getCutOrders(
            @RequestParam("room-code") final String roomCode,
            @RequestParam(value = "table-id") final Optional<Long> tableId,
            @RequestParam(value = "station-ids") final Optional<List<Long>> stationIds,
            @ApiParam(allowableValues = "to-cut,to-pack,packed")
            @RequestParam(value = "status") final Optional<String> status,
            @RequestParam(value = "cancelled") final Optional<Boolean> cancelled) {
        return productionOrderService
                .findAllCutOrders(roomCode, status, stationIds, tableId, cancelled).stream()
                .map(productionOrder -> {
                    final List<Box> boxesForOrder = boxService.findBySourceCutOrderId(productionOrder.getId());
                    return new CutOrderResponse(productionOrder, boxesForOrder);
                }).collect(toList());
    }

    @GetMapping("/to-pack")
    @ApiOperation(value = "get orders to-pack",
            notes = "get CutOrders resource(same as the model in database) "
                    + "based on given cut selection date and product code. Optionally, additional filtering "
                    + "can be performed using customer number or customer order number.")
    public List<CutOrderResponse> getCutOrdersToPack(
            @RequestParam(value = "date") @DateTimeFormat(iso = DATE) final LocalDate date,
            @RequestParam(value = "product-code") final String productCode,
            @RequestParam(value = "sus-order-no", required = false) final String susOrderNo,
            @RequestParam(value = "customer-no", required = false) final String customerNo) {
        return productionOrderService
                .findAllCutOrdersToPack(date, productCode, susOrderNo, customerNo).stream()
                .map(productionOrder -> {
                    return new CutOrderResponse(productionOrder, null);
                }).collect(toList());
    }

    @GetMapping("/summary/stations")
    @ApiOperation(value = "get order summary for stations",
            notes = "get CutOrders' summary resource for station based on given CutOrderStatus. "
                    + "This is the api for station list, can be used by StationList page")
    public List<CutOrderStationSummary> cutOrderSummaryForStations(
            @RequestParam("room-code") final String roomCode) {
        return productionOrderService.getCutOrdersSummaryForStations(roomCode);
    }

    @GetMapping("/summary/tables")
    @ApiOperation(value = "get order summary for tables",
            notes = "get CutOrders' summary for tables in a station or in all stations if no station id passed. "
                    + "This is the api for table list, can be used by ProductionOrder or PackOrder TableList page.")
    public List<CutOrderTableSummary> cutOrderSummaryForTable(
            @RequestParam("room-code") final String roomCode,
            @RequestParam(value = "station-id", required = false) final Long stationId,
            @ApiParam(required = true, allowableValues = "to-cut,to-pack,packed")
            @RequestParam("status") final CutOrderStatus status) {
        return productionOrderService.getCutOrdersSummaryForTables(roomCode, stationId, status);
    }

    @GetMapping("/{id}")
    @ApiOperation(value = "get order information",
            notes = "get order information by id, "
                    + "can be used by WeighingAndPackingSelectedOrders page showing the order information.")
    public CutOrderResponse get(@PathVariable final Long id) {
        log.info("Get cut-order detail by order-id: " + id);
        final ProductionOrder order = productionOrderService.findById(id);
        final List<Box> boxesForOrder = boxService.findBySourceCutOrderId(id);
        return new CutOrderResponse(order, boxesForOrder);
    }

    @GetMapping("/ticket/{cutTicketCode}/room/{roomCode}")
    @ResponseStatus(OK)
    public Long getCutOrderByTicketCodeAndRoomCode(@PathVariable @ValidCutTicketCodeFormat final String cutTicketCode,
                                                   @PathVariable final String roomCode) {
        return productionOrderService.findByCutTicketCodeAndRoomCode(cutTicketCode, roomCode).getId();
    }

    @PostMapping("/{id}/banquet/complete")
    @ApiOperation(value = "complete a banquet order",
            notes = "complete a banquet order independent of quantity remaining.")
    @ResponseStatus(NO_CONTENT)
    public void completeBanquetOrder(@PathVariable final Long id) {
        productionOrderService.completeBanquetOrderWithOrderQuantityPacked(id);
    }
}
