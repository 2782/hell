package com.sysco.prime.productionOrder.response.cut;

import com.sysco.prime.productionOrder.CutOrderSource;
import com.sysco.prime.productionOrder.ProductionOrder;
import com.sysco.prime.station.Station;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static java.util.stream.Collectors.groupingBy;
import static java.util.stream.Collectors.mapping;
import static java.util.stream.Collectors.toList;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class CutOrderStationSummary {
    private String name;
    private Long stationId;
    private String room;
    private Integer stationCode;
    private List<CutOrderSummaryItem> boxesToCutForCustomerOrders;

    public static CutOrderStationSummary buildCutOrderStationSummary(
            final Station station,
            final List<ProductionOrder> productionOrdersForStation,
            final LocalDate firstDate,
            final LocalDate secondDate) {
        final Map<SourceDateKey, List<ProductionOrder>> cutOrdersPerSourcePerDate =
                productionOrdersForStation.stream()
                        .peek((order) -> {
                            if (order.isImmediateOrder()) {
                                order.setDeliveryDate(firstDate);
                            }
                        })
                        .collect(groupingBy((ProductionOrder cutOrder) ->
                                        new SourceDateKey(cutOrder.getSource(), cutOrder.getDeliveryDate()),
                                HashMap::new,
                                mapping(order -> order, toList())
                        ));

        final List<CutOrderSummaryItem> cutOrderSummaryItems = cutOrdersPerSourcePerDate.entrySet().stream()
                .map(entry -> {
                    final CutOrderSource source = entry.getKey().getSource();
                    final LocalDate date = entry.getKey().getDate();
                    final List<ProductionOrder> productionOrders = entry.getValue();
                    return CutOrderSummaryItem.from(source, date, productionOrders);
                }).collect(toList());

        final List<CutOrderSummaryItem> results =
                CutOrderSummaryItemHelper.groupOrdersToNextWorkingDay(
                        cutOrderSummaryItems,
                        firstDate,
                        secondDate);

        return builder()
                .boxesToCutForCustomerOrders(results)
                .name(station.getName())
                .room(station.getRoom().getCode())
                .stationCode(station.getStationCode())
                .stationId(station.getId())
                .build();
    }
}
