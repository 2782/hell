package com.sysco.prime.productionOrder.validation;

import com.sysco.prime.portionRoom.PortionRoomRepository;
import com.sysco.prime.product.Product;
import com.sysco.prime.product.ProductService;
import com.sysco.prime.product.validation.PrimeConstraintValidator;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.validation.ConstraintValidatorContext;

import static com.sysco.prime.validation.ValidationErrorType.NOT_EXIST;
import static com.sysco.prime.validation.ValidationErrorType.PRODUCT_IS_NOT_PRODUCTION_ITEM;
import static com.sysco.prime.validation.ValidationErrorType.UNIQUE;

@Component
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class GrindTicketCodeFormatValidator implements PrimeConstraintValidator<ValidGrindTicketCodeFormat, String> {
    private static final int MIN_GRIND_TICKET_CODE_LENGTH = 15;
    private static final int MAX_GRIND_TICKET_CODE_LENGTH = 16;

    private final ProductService productService;
    private final PortionRoomRepository portionRoomRepository;

    @Override
    public boolean isValid(final String value, final ConstraintValidatorContext context) {

        if (TicketCodeUtils.invalidLength(value, MIN_GRIND_TICKET_CODE_LENGTH)
                && TicketCodeUtils.invalidLength(value, MAX_GRIND_TICKET_CODE_LENGTH)) {
            return false;
        }
        if (TicketCodeUtils.missingPrefix(value.charAt(0), 'G')) {
            return false;
        }
        if (TicketCodeUtils.nonParseableDate(value.substring(1, 7), "MMddyy")) {
            return false;
        }

        if (!productSuffix(value, context)) {
            return false;
        }

        if (!roomCodeSuffix(value, context)) {
            return false;
        }

        return true;
    }

    private boolean roomCodeSuffix(final String value, final ConstraintValidatorContext context) {
        final String roomCode = value.substring(14, value.length());
        if (!portionRoomRepository.findByCode(roomCode).isPresent()) {
            return validationFailedBecause(context, UNIQUE);
        }
        return true;
    }

    private boolean productSuffix(final String value, final ConstraintValidatorContext context) {
        final String productCodeSuffix = value.substring(7, 14);
        final Product product = productService.findByCodeIgnoringSus(productCodeSuffix);
        if (product == null) {
            return validationFailedBecause(context, NOT_EXIST);
        }

        if (!product.isFinishedProductOutput()) {
            return validationFailedBecause(context, PRODUCT_IS_NOT_PRODUCTION_ITEM);
        }
        return true;
    }
}

