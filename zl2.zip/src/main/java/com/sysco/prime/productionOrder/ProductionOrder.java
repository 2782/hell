package com.sysco.prime.productionOrder;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.sysco.prime.customerOrder.CustomerOrder;
import com.sysco.prime.customerOrder.DeliveryMethod;
import com.sysco.prime.customerOrder.LineItem;
import com.sysco.prime.cutType.CutType;
import com.sysco.prime.exception.InvalidValueException;
import com.sysco.prime.housePar.HousePar;
import com.sysco.prime.portionRoomTable.PortionRoomTable;
import com.sysco.prime.product.Product;
import com.sysco.prime.shared.model.TransactionalEntity;
import com.sysco.prime.ticket.TicketType;
import com.sysco.prime.unitOfMeasure.UnitOfMeasure;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import javax.persistence.Entity;
import javax.persistence.Enumerated;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Transient;
import javax.persistence.Version;
import java.math.BigDecimal;
import java.time.Clock;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Stream;

import static com.sysco.prime.customerOrder.DeliveryMethod.NORMAL;
import static com.sysco.prime.customerOrder.DeliveryMethod.WILL_CALL;
import static com.sysco.prime.customerOrder.DeliveryMethod.deliveryMethodComparator;
import static com.sysco.prime.customerOrder.TimedWillCallRoutes.timedWillCallComparator;
import static com.sysco.prime.productionOrder.CutOrderSource.HOUSE_PAR;
import static com.sysco.prime.productionOrder.CutOrderSource.LINE_ITEM;
import static com.sysco.prime.productionOrder.OrderType.BANQUET;
import static com.sysco.prime.productionOrder.OrderType.from;
import static com.sysco.prime.productionOrder.ProductionOrderStatus.CLOSED;
import static com.sysco.prime.productionOrder.ProductionOrderStatus.PACKED;
import static com.sysco.prime.productionOrder.ProductionOrderStatus.TO_APPROVE;
import static com.sysco.prime.productionOrder.ProductionOrderStatus.TO_CUT;
import static com.sysco.prime.productionOrder.ProductionOrderStatus.TO_GRIND;
import static com.sysco.prime.productionOrder.ProductionOrderStatus.TO_PACK;
import static com.sysco.prime.productionOrder.ProductionOrderStatus.unfinishedStatuses;
import static com.sysco.prime.productionOrder.ProductionType.CUTTING;
import static com.sysco.prime.productionOrder.ProductionType.GRINDING;
import static com.sysco.prime.unitOfMeasure.UnitOfMeasure.PIECE;
import static java.lang.Math.ceil;
import static java.math.RoundingMode.HALF_UP;
import static java.util.Arrays.asList;
import static java.util.Comparator.nullsFirst;
import static java.util.Objects.isNull;
import static javax.persistence.EnumType.STRING;
import static javax.persistence.FetchType.EAGER;

@Entity
@Data
@Builder(toBuilder = true)
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
public class ProductionOrder extends TransactionalEntity {
    // 559 < 559A < 1547 < P103 < P1030
    static Comparator<String> subPrimalCodeComparator = nullsFirst((left, right) -> {
        final Pattern p = Pattern.compile("^(P?)(\\d+)([a-zA-Z]?)$");
        final Matcher m1 = p.matcher(left);
        final Matcher m2 = p.matcher(right);

        boolean p1Match = m1.matches();
        boolean p2Match = m2.matches();
        if (!p1Match && !p2Match) {
            return 0;
        } else if (!p1Match) {
            return 1;
        } else if (!p2Match) {
            return -1;
        }

        boolean prefixP1 = "P".equals(m1.group(1));
        boolean prefixP2 = "P".equals(m2.group(1));
        int prefixPCompares = comparatorPrefixP(prefixP1, prefixP2);
        if (prefixPCompares != 0) {
            return prefixPCompares;
        }

        Integer number1 = Integer.valueOf(m1.group(2));
        Integer number2 = Integer.valueOf(m2.group(2));
        int numberCompares = Integer.compare(number1, number2);
        if (numberCompares != 0) {
            return numberCompares;
        }

        Character alphabet1 = m1.group(3).isEmpty() ? '0' : m1.group(3).charAt(0);
        Character alphabet2 = m2.group(3).isEmpty() ? '0' : m2.group(3).charAt(0);
        return Character.compare(alphabet1, alphabet2);
    });
    static Comparator<ProductionOrder> byQty = Comparator.comparing(ProductionOrder::getQtyToProduceInCases).reversed();
    static Comparator<ProductionOrder> byShipDate = Comparator.comparing(ProductionOrder::getDeliveryDate);
    static Comparator<ProductionOrder> byDeliveryMethod = (p1, p2) -> deliveryMethodComparator.compare(
            p1.getCustomerOrder().getDeliveryMethod(),
            p2.getCustomerOrder().getDeliveryMethod()
    );
    static Comparator<ProductionOrder> byProductCode =
            Comparator.comparing(productionOrder -> productionOrder.getProduct().getCode());
    static Comparator<ProductionOrder> bySubPrimalCode = (p1, p2) -> {
        String subPrimalCode1 = p1.getProduct().getSubPrimalCode();
        String subPrimalCode2 = p2.getProduct().getSubPrimalCode();

        return subPrimalCodeComparator.compare(subPrimalCode1, subPrimalCode2);
    };
    static Comparator<ProductionOrder> subSortedComparator = bySubPrimalCode.thenComparing(
            byProductCode.thenComparing(byQty));
    static Comparator<ProductionOrder> byTimedWillCall = (p1, p2) -> timedWillCallComparator.compare(
            p1.getCustomerOrder().getTimedWillCallRoutes(),
            p2.getCustomerOrder().getTimedWillCallRoutes());
    @Enumerated(STRING)
    private CutOrderSource source;
    @Enumerated(STRING)
    private UnitOfMeasure unitOfMeasure;
    @JsonIgnore
    private Long sourceId;
    @Version
    @JsonIgnore
    private Long version;
    @OneToOne
    @JoinColumn(name = "productId")
    private Product product;
    @Enumerated(STRING)
    private OrderType orderType;
    @Enumerated(STRING)
    private ProductionType productionType;
    private String packInstruction;
    private Integer piecesPerCase;
    private String producingInstruction;
    private Integer qtyToProduce;
    private Integer qtyPacked;
    private LocalDate deliveryDate;
    private Integer qtyToProduceInCases;
    @ManyToOne(fetch = EAGER)
    @JoinColumn(name = "customerOrderId")
    @JsonSerialize(using = CustomerForCutOrderSerializer.class)
    private CustomerOrder customerOrder;
    @ManyToOne(fetch = EAGER)
    @JoinColumn(name = "tableId")
    @JsonSerialize(using = TableForCutOrderSerializer.class)
    @ApiModelProperty(hidden = true)
    private PortionRoomTable portionRoomTable;
    @Enumerated(STRING)
    private ProductionOrderStatus status;
    private OffsetDateTime startProducingAt;
    private Long purchaseOrderId;
    @Transient
    private Blend blend;

    private static int comparatorPrefixP(final boolean prefixP1, final boolean prefixP2) {
        if (prefixP1 && !prefixP2) {
            return 1;
        } else if (!prefixP1 && prefixP2) {
            return -1;
        }
        return 0;
    }

    static ProductionOrder fromHouseParForCutting(final HousePar housePar, final int quantity,
                                                  final LocalDate deliveryDate) {
        return fromHousePar(housePar, quantity, deliveryDate, TO_CUT, CUTTING);
    }

    static ProductionOrder fromHouseParForGrinding(final HousePar housePar, final int quantity,
                                                   final LocalDate deliveryDate) {
        return fromHousePar(housePar, quantity, deliveryDate, TO_APPROVE, GRINDING);
    }

    private static ProductionOrder fromHousePar(final HousePar housePar, final int quantity,
                                                final LocalDate deliveryDate, final ProductionOrderStatus status,
                                                final ProductionType type) {

        final Product product = housePar.getProduct();
        return ProductionOrder.builder()
                .qtyToProduce(quantity)
                .piecesPerCase(product.getPiecesPerCase())
                .sourceId(housePar.getId())
                .source(HOUSE_PAR)
                .status(status)
                .customerOrder(null)
                .orderType(OrderType.STANDARD)
                .productionType(type)
                .unitOfMeasure(UnitOfMeasure.BOX)
                .qtyPacked(0)
                .portionRoomTable(product.getTable())
                .product(product)
                .deliveryDate(deliveryDate)
                .qtyToProduceInCases(quantity)
                .build();
    }

    public static ProductionOrder fromLineItem(final LineItem item,
                                               final ProductionType productionType,
                                               final int qtyToCut) {
        final Integer piecesPerCase = item.getProduct().getPiecesPerCase();
        final int qtyToProduceInCases = item.getUnitOfMeasure() == UnitOfMeasure.BOX
                ? qtyToCut
                : (int) ceil(qtyToCut * 1.0 / piecesPerCase);

        return builder()
                .qtyToProduce(qtyToCut)
                .unitOfMeasure(item.getUnitOfMeasure())
                .piecesPerCase(piecesPerCase)
                .sourceId(item.getId())
                .source(CutOrderSource.LINE_ITEM)
                .status(ProductionOrderStatus.from(productionType))
                .customerOrder(item.getCustomerOrder())
                .packInstruction(item.getPackInstruction())
                .producingInstruction(item.getCutInstruction())
                .orderType(item.isBanquetType() ? from(CutType.BANQUET) : from(CutType.STANDARD))
                .productionType(productionType)
                .qtyPacked(0)
                .portionRoomTable(item.getProduct().getTable())
                .product(item.getProduct())
                .deliveryDate(item.getCustomerOrder().getShipDate())
                .qtyToProduceInCases(qtyToProduceInCases)
                .build();
    }

    // TODO: only expect to find one
    static ProductionOrder aggregateQuantities(final ProductionOrder identity,
                                               final List<ProductionOrder> existingProductionOrders) {
        if (existingProductionOrders.isEmpty()) {
            return identity;
        }

        return existingProductionOrders.stream().reduce(identity, (productionOrder1, productionOrder2) -> {
            productionOrder1.setQtyPacked(productionOrder1.getQtyPacked() + productionOrder2.getQtyPacked());
            productionOrder1.setQtyToProduce(productionOrder1.getQtyToProduce() + productionOrder2.getQtyToProduce());
            productionOrder1.setQtyToProduceInCases(
                    productionOrder1.getQtyToProduceInCases() + productionOrder2.getQtyToProduceInCases());
            return productionOrder1;
        });
    }

    public PublishingUpdatedProductionOrder toReporting() {
        return PublishingUpdatedProductionOrder.builder()
                .qtyToProduce(qtyToProduce)
                .piecesPerCase(piecesPerCase)
                .sourceId(sourceId)
                .source(source)
                .status(status)
                .customerOrder(customerOrder)
                .packInstruction(packInstruction)
                .producingInstruction(producingInstruction)
                .orderType(orderType)
                .productionType(productionType)
                .unitOfMeasure(unitOfMeasure)
                .qtyPacked(qtyPacked)
                .portionRoomTable(portionRoomTable)
                .product(product)
                .deliveryDate(deliveryDate)
                .qtyToProduceInCases(qtyToProduceInCases)
                .build();
    }

    PublishingCutOrderSelection toReportingCutSelection() {
        final OffsetDateTime lastOpenedAt = portionRoomTable.getStation().getRoom().getLastOpenedAt();
        return PublishingCutOrderSelection.builder()
                .qtyToProduce(qtyToProduce)
                .piecesPerCase(piecesPerCase)
                .sourceId(sourceId)
                .source(source)
                .status(status)
                .customerOrder(customerOrder)
                .packInstruction(packInstruction)
                .producingInstruction(producingInstruction)
                .orderType(orderType)
                .productionType(productionType)
                .unitOfMeasure(unitOfMeasure)
                .qtyPacked(qtyPacked)
                .portionRoomTable(portionRoomTable)
                .product(product)
                .deliveryDate(deliveryDate)
                .qtyToProduceInCases(qtyToProduceInCases)
                .workingDate(lastOpenedAt.toLocalDate())
                .build();
    }

    @JsonIgnore
    void packBox() {
        if (qtyToProduceInCases.equals(++qtyPacked)) {
            status = ProductionOrderStatus.from(PACKED.toString());
        }
    }

    @JsonIgnore
    boolean isWillCallDeliveryMethod() {
        return WILL_CALL.equals(getCustomerOrder().getDeliveryMethod());
    }

    @JsonIgnore
    boolean isNormalDeliveryMethod() {
        return NORMAL.equals(getCustomerOrder().getDeliveryMethod());
    }

    @JsonIgnore
    public boolean isImmediateOrder() {
        return !HOUSE_PAR.equals(source) && getCustomerOrder().isImmediateOrder();
    }

    @JsonIgnore
    boolean isNotImmediateOrder() {
        return !getCustomerOrder().isImmediateOrder();
    }

    @JsonIgnore
    boolean isShipDateIn(final LocalDate... dates) {
        return Stream.of(dates).anyMatch(date -> deliveryDate.equals(date));
    }

    @JsonIgnore
    boolean isShipDateNotIn(final LocalDate... dates) {
        return Stream.of(dates).noneMatch(date -> deliveryDate.equals(date));
    }

    @JsonIgnore
    public boolean isHouseParType() {
        return HOUSE_PAR.equals(source);
    }

    @JsonIgnore
    public boolean isLineItemType() {
        return LINE_ITEM.equals(source);
    }

    public void update(final ProductionOrder productionOrder, final Clock clock) {
        source = setIfNonNull(productionOrder.getSource(), source);
        sourceId = setIfNonNull(productionOrder.getSourceId(), sourceId);
        product = setIfNonNull(productionOrder.getProduct(), product);
        qtyToProduce = setIfNonNull(productionOrder.getQtyToProduce(), qtyToProduce);
        qtyPacked = setIfNonNull(productionOrder.getQtyPacked(), qtyPacked);
        deliveryDate = setIfNonNull(productionOrder.getDeliveryDate(), deliveryDate);
        unitOfMeasure = setIfNonNull(productionOrder.getUnitOfMeasure(), unitOfMeasure);
        status = setIfNonNull(productionOrder.getStatus(), status);
        customerOrder = setIfNonNull(productionOrder.getCustomerOrder(), customerOrder);
        portionRoomTable = setIfNonNull(productionOrder.getPortionRoomTable(), portionRoomTable);
        packInstruction = setIfNonNull(productionOrder.getPackInstruction(), packInstruction);
        qtyToProduceInCases = setIfNonNull(productionOrder.getQtyToProduceInCases(), qtyToProduceInCases);
        orderType = setIfNonNull(productionOrder.getOrderType(), orderType);
        startProducingAt = OffsetDateTime.now(clock);
    }

    @JsonIgnore
    void assignToTable(final PortionRoomTable table) {
        portionRoomTable = table;
    }

    @JsonIgnore
    void assignPurchaseOrderId(final Long purchaseOrderId) {
        this.purchaseOrderId = purchaseOrderId;
    }

    @JsonIgnore
    public boolean isActive() {
        return status != CLOSED;
    }

    public boolean isUnfinished(final LocalDate today) {
        if (today.equals(deliveryDate)) {
            return unfinishedStatuses().contains(status);
        } else {
            return TO_PACK == status;
        }
    }

    int calculateOutQuantity(final int stockQuantity) {
        return getQtyToProduceInCases() - getQtyPacked() - stockQuantity;
    }

    boolean shouldSendOut(final LocalDate firstWorkDay, final LocalDate nextWorkDay) {
        if (HOUSE_PAR.equals(getSource())) {
            return false;
        }

        final DeliveryMethod deliveryMethod = customerOrder.getDeliveryMethod();
        final LocalDate shipDate = customerOrder.getShipDate();

        return customerOrder.isImmediateOrder()
                || WILL_CALL.equals(deliveryMethod) && shipDate.isEqual(firstWorkDay)
                || NORMAL.equals(deliveryMethod) && shipDate.isEqual(firstWorkDay)
                || NORMAL.equals(deliveryMethod) && shipDate.isEqual(nextWorkDay)
                && !asList(TO_CUT, TO_GRIND).contains(getStatus());
    }

    int getQtyAlreadyPacked() {
        return unitOfMeasure == PIECE
                ? qtyPacked * piecesPerCase
                : qtyPacked;
    }

    void updateProduceQuantities(final int qtyToProduceRemaining) {
        final int qtyToCutInBoxes = unitOfMeasure == UnitOfMeasure.BOX
                ? qtyToProduceRemaining
                : (int) ceil(qtyToProduceRemaining * 1.0 / piecesPerCase);
        qtyToProduce = qtyToProduceRemaining;
        qtyToProduceInCases = qtyToCutInBoxes;

        setToPackedIfOrderedAmountFulfilled();
    }

    public int getQtyToProduceInPieces() {
        final int piecesPerCase = getProduct().getPiecesPerCase();
        return BigDecimal.valueOf(getQtyToProduceInCases())
                .multiply(BigDecimal.valueOf(piecesPerCase))
                .setScale(0, HALF_UP)
                .intValue();
    }

    public void setToPackedIfOrderedAmountFulfilled() {
        if (qtyPacked >= qtyToProduceInCases) {
            status = PACKED;
        }
    }

    String getRoomCode() {
        return portionRoomTable.getStation().getRoom().getCode();
    }

    public LineItem getLineItem() {
        return getCustomerOrder().getLineItems().stream().filter(lineItem -> Objects.equals(
                lineItem.getId(),
                this.getSourceId()))
                .findFirst()
                .orElse(null);
    }

    public void completeBanquetOrder() {
        if (BANQUET != orderType) {
            throw new InvalidValueException("invalid productionOrder type: " + orderType);
        }

        if (qtyPacked == null || qtyPacked <= 0) {
            throw new InvalidValueException("invalid qtyPacked: " + qtyPacked);
        }

        qtyToProduceInCases = qtyPacked;
        status = ProductionOrderStatus.PACKED;
    }

    public String getTicketCodeSuffixFromId() {
        final Long id = getId();
        final String idStr = id.toString();
        final String shortId = (idStr.length() < 4) ? idStr : idStr.substring(idStr.length() - 4);

        return String.format("%04d", Integer.parseInt(shortId));
    }

    public String getTicketCode(final TicketType ticketType) {
        if (status == TO_PACK && deliveryDate != null) {
            return "C" + deliveryDate.format(DateTimeFormatter.ofPattern("MMddyy"))
                    + getTicketCodeSuffixFromId();
        } else if (ticketType.equals(TicketType.GRIND_TICKET) && status == TO_APPROVE && deliveryDate != null) {
            final String roomCode = portionRoomTable.getStation().getPortionRoomCode();
            return "G" + deliveryDate.format(DateTimeFormatter.ofPattern("MMddyy"))
                    + product.getCode()
                    + roomCode;
        }

        return null;
    }
}
