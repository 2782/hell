package com.sysco.prime.productionOrder.validation;

import com.sysco.prime.product.validation.PrimeConstraintValidator;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.validation.ConstraintValidatorContext;

import static org.apache.commons.lang.math.NumberUtils.isDigits;

@Component
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class CutTicketCodeFormatValidator implements PrimeConstraintValidator<ValidCutTicketCodeFormat, String> {
    private static final int CUT_TICKET_CODE_LENGTH = 11;

    @Override
    public boolean isValid(final String value, final ConstraintValidatorContext context) {
        if (TicketCodeUtils.invalidLength(value, CUT_TICKET_CODE_LENGTH)) {
            return false;
        }
        if (TicketCodeUtils.missingPrefix(value.charAt(0), 'C')) {
            return false;
        }
        if (TicketCodeUtils.nonParseableDate(value.substring(1, 7), "MMddyy")) {
            return false;
        }
        if (nonNumericalIdSuffix(value)) {
            return false;
        }
        return true;
    }

    private boolean nonNumericalIdSuffix(final String value) {
        final String idSuffix = value.substring(7, 11);
        return !isDigits(idSuffix);
    }
}
