package com.sysco.prime.productionOrder.response;

import com.sysco.prime.productionOrder.Blend;
import lombok.Data;

@Data
public class BlendResponse {
    private final String name;
    private final String displayName;
    private final int priority;
    private final String description;

    public BlendResponse(final Blend blend) {
        name = blend.getName();
        displayName = blend.getDisplayName();
        priority = blend.getPriority();
        description = blend.getDescription();
    }
}
