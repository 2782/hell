package com.sysco.prime.productionOrder;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.ser.std.StdSerializer;
import com.sysco.prime.customerOrder.CustomerOrder;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class CustomerForCutOrderSerializer extends StdSerializer<CustomerOrder> {
    protected CustomerForCutOrderSerializer() {
        super(CustomerOrder.class);
    }

    @Override
    public void serialize(
            final CustomerOrder value, final JsonGenerator gen, final SerializerProvider provider) throws IOException {
        final Map<String, Object> map = new HashMap<>();
        final Map<String, Object> customer = new HashMap<>();
        customer.put("id", value.getCustomer().getId());
        customer.put("name", value.getCustomer().getName());
        customer.put("customerCode", value.getCustomer().getCustomerCode());
        map.put("id", value.getId());
        map.put("orderNumber", value.getOrderNumber());
        map.put("orderDate", value.getOrderDate());
        map.put("createdBy", value.getCreatedBy());
        map.put("customer", customer);

        gen.writeObject(map);
    }
}
