package com.sysco.prime.productionOrder;

import com.sysco.prime.portionRoomTable.PortionRoomTable;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;

import static com.sysco.prime.productionOrder.CutOrderSpecification.extendQuery;
import static com.sysco.prime.productionOrder.CutOrderSpecification.filterCancelledOrDeleted;

@Component
public class ProductionOrderRepositoryImpl implements ProductionOrderRepositoryCustom {
    @Autowired
    ProductionOrderRepository repository;

    @Override
    public List<ProductionOrder> findAll(
            final String roomCode,
            final Optional<ProductionType> productionType,
            final List<Long> stationIds,
            final Optional<PortionRoomTable> table,
            final Optional<Boolean> cancelled,
            final List<ProductionOrderStatus> status) {
        final List<ProductionOrder> results = repository.findAll(extendQuery(
                roomCode, productionType, stationIds, table, status));
        return filterCancelledOrDeleted(cancelled, results);
    }
}
