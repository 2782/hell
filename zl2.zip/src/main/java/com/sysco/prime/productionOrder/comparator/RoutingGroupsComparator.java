package com.sysco.prime.productionOrder.comparator;

import com.sysco.prime.customer.RoutingGroup;
import com.sysco.prime.productionOrder.ProductionOrder;

import java.io.Serializable;
import java.time.Clock;
import java.time.LocalDate;
import java.util.Comparator;
import java.util.Optional;

public class RoutingGroupsComparator implements Comparator<ProductionOrder>, Serializable {
    private final Clock clock;

    public RoutingGroupsComparator(final Clock clock) {
        this.clock = clock;
    }

    @Override
    public int compare(final ProductionOrder o1, final ProductionOrder o2) {
        final int firstRoutingGroupValue = fetchRoutingGroupValue(o1);
        final int secondRoutingGroupValue = fetchRoutingGroupValue(o2);

        return firstRoutingGroupValue - secondRoutingGroupValue;
    }

    private int fetchRoutingGroupValue(final ProductionOrder productionOrder) {
        final Optional<RoutingGroup> customerRoutingGroup =
                productionOrder.getCustomerOrder().getCustomer().getRoutingGroups().stream()
                        .filter(routingGroup ->
                                routingGroup.getDayOfWeek() == LocalDate.now(clock).getDayOfWeek().getValue()) //check
                        .findFirst();

        return customerRoutingGroup.map(RoutingGroup::getValue).orElse(Integer.MAX_VALUE);
    }
}
