package com.sysco.prime.productionOrder.request.cut;

import com.sysco.prime.productionOrder.CutOrderStatus;
import com.sysco.prime.productionOrder.ProductionOrder;
import lombok.Getter;
import lombok.Setter;

import static com.sysco.prime.productionOrder.ProductionOrderStatus.from;

@Getter
@Setter
public class CutOrderRequest {
    private Long id;
    private CutOrderStatus cutOrderStatus;

    public ProductionOrder toCutOrder() {
        final ProductionOrder productionOrder = ProductionOrder.builder()
                .status(from(cutOrderStatus.toString()))
                .build();
        productionOrder.setId(id);
        return productionOrder;
    }
}
