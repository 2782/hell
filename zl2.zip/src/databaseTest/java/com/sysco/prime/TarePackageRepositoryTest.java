package com.sysco.prime;

import com.sysco.prime.packages.BoxTypeRepository;
import com.sysco.prime.packages.FilmTypeRepository;
import com.sysco.prime.packages.TarePackage;
import com.sysco.prime.packages.TarePackageRepository;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import static com.sysco.prime.DummyObjectFactory.buildTarePackage;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

public class TarePackageRepositoryTest extends RepositoryTestBase<TarePackage, TarePackageRepository> {
    @Autowired
    private BoxTypeRepository boxTypeRepository;
    @Autowired
    private FilmTypeRepository filmTypeRepository;

    @Test
    public void shouldRoundtrip() {
        final TarePackage tarePackage = buildTarePackage();

        boxTypeRepository.save(tarePackage.getBoxType());
        filmTypeRepository.save(tarePackage.getFilmType());

        final TarePackage saved = saveAndReadBack(tarePackage);
        final TarePackage readBack = repository.getOneOrNull(saved.getId());

        assertThat(readBack, is(equalTo(saved)));
    }
}
