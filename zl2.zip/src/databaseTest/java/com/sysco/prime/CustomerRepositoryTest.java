package com.sysco.prime;

import com.sysco.prime.customer.Customer;
import com.sysco.prime.customer.CustomerRepository;
import com.sysco.prime.customer.CustomerSpecificItemNumber;
import com.sysco.prime.product.Product;
import org.junit.Test;

import static com.sysco.prime.DummyObjectFactory.customerBuilder;
import static com.sysco.prime.DummyObjectFactory.productBuilder;
import static java.util.Collections.singletonList;
import static org.assertj.core.api.Assertions.assertThat;

public class CustomerRepositoryTest extends RepositoryTestBase<Customer, CustomerRepository> {

    @Test
    public void shouldRetrieveItemNumbersForCustomer() {
        final Product product = entityManager.persist(productBuilder().build());

        final CustomerSpecificItemNumber item = CustomerSpecificItemNumber.builder()
                .product(product)
                .itemNumber("QA123456")
                .build();

        final Customer customer = customerBuilder()
                .itemNumbers(singletonList(item))
                .build();

        customer.attachRoutingGroup();
        customer.attachToCustomerSpecificItems();

        final Customer saved = entityManager.persist(customer);

        entityManager.flush();

        final Customer retrieved = repository.findByCustomerCode(saved.getCustomerCode());

        assertThat(retrieved.getItemNumbers()).contains(item);
    }
}
