package com.sysco.prime;

import com.sysco.prime.cost.Cost;
import com.sysco.prime.cost.CostRepository;
import com.sysco.prime.cost.Money;
import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Test;

import java.time.Clock;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

import static com.sysco.prime.cost.Cost.COST_NEVER_EXPIRES;
import static com.sysco.prime.cost.CostService.BYPRODUCT_OVERRIDE_SOURCES;
import static com.sysco.prime.cost.CostSource.BYPRODUCT_OVERRIDE;
import static com.sysco.prime.cost.CostSource.PRICING_MODEL;
import static com.sysco.prime.cost.CostSource.REMOVE_OVERRIDE;
import static com.sysco.prime.cost.CostSource.SUS;
import static com.sysco.prime.cost.CostSource.YIELD_MODEL;
import static com.sysco.prime.utils.TimeUtilsTest.mockClockToNow;
import static java.math.BigDecimal.ONE;
import static java.time.LocalTime.MIDNIGHT;
import static java.util.Arrays.asList;
import static java.util.Collections.singletonList;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.mock;

public class CostRepositoryTest extends RepositoryTestBase<Cost, CostRepository> {

    private LocalDate date;
    private Clock when;

    private static Cost sourceCost() {
        final double marketCost = 2;

        final Cost cost = Cost.builder()
                .name("BOB")
                .source(SUS)
                .startDate(LocalDate.of(2018, 11, 1))
                .endDate(LocalDate.of(2018, 11, 5))
                .marketCost(Money.of(marketCost))
                .yieldModelId(null)
                .labor(null)
                .weightedAverageCost(Money.of(3))
                .currentCostPerPound(Money.of(marketCost))
                .build();
        cost.setCreatedAt(LocalDateTime.of(cost.getStartDate().minusDays(1), MIDNIGHT));
        cost.setUpdatedAt(null);

        return cost;
    }

    private static Cost finishedCost() {
        final double marketCost = 2;

        final Cost cost = Cost.builder()
                .name("BOB")
                .source(YIELD_MODEL)
                .startDate(LocalDate.of(2018, 11, 1))
                .endDate(LocalDate.of(2018, 11, 3))
                .marketCost(Money.of(marketCost))
                .yieldModelId(17L)
                .labor(Money.of(3))
                .weightedAverageCost(null)
                .currentCostPerPound(Money.of(marketCost / 2))
                .build();
        cost.setCreatedAt(LocalDateTime.of(cost.getStartDate().minusDays(1), MIDNIGHT));
        cost.setUpdatedAt(null);

        return cost;
    }

    @Before
    public void setup() {
        when = mock(Clock.class);

        mockClockToNow(when);

        date = LocalDate.now(when);
    }

    @Test
    public void shouldFindSourceProductFutureCost() {
        final Cost sourceCost = sourceCost().toBuilder()
                .name("FutureCost 1")
                .currentCostPerPound(Money.ofCost(12))
                .startDate(date.plusDays(1))
                .endDate(date.plusDays(15))
                .build();

        final Cost otherSourceCost = sourceCost().toBuilder()
                .name("FutureCost 1")
                .currentCostPerPound(Money.ofCost(15))
                .startDate(date.plusDays(16))
                .endDate(date.plusDays(30))
                .build();

        repository.save(sourceCost);
        repository.save(otherSourceCost);

        List<Cost> sourceCostList =
                repository.findByNameAndSourceInAndStartDateGreaterThanEqualAndEndDateLessThanEqualOrderByCreatedAtDesc(
                sourceCost.getName(), asList(SUS), date.plusDays(1), COST_NEVER_EXPIRES);

        Assertions.assertThat(sourceCostList).containsExactlyInAnyOrder(sourceCost, otherSourceCost);
    }

    @Test
    public void shouldFindByCostNameAndSourceProductBetweenDates() {
        final Cost source = sourceCost();

        repository.save(source);

        assertThat(repository.mostRecentForAt(source.getName(), source.getStartDate().plusDays(1)),
                is(singletonList(source)));
    }

    @Test
    public void shouldFindByproductOverrideInThePast() {
        final String name = "0078889";
        long yieldModelId = 12L;
        final Cost removeOverrideYesterday = Cost.builder()
                .name(name)
                .yieldModelId(yieldModelId)
                .source(REMOVE_OVERRIDE)
                .startDate(date.minusDays(1))
                .endDate(COST_NEVER_EXPIRES)
                .build();
        final Cost overrideAWeekPrior = Cost.builder()
                .name(name)
                .yieldModelId(yieldModelId)
                .source(BYPRODUCT_OVERRIDE)
                .startDate(date.minusDays(7))
                .endDate(COST_NEVER_EXPIRES)
                .build();

        repository.save(removeOverrideYesterday);
        repository.save(overrideAWeekPrior);

        assertThat(repository.mostRecentForAt(name, yieldModelId, BYPRODUCT_OVERRIDE_SOURCES, date.minusDays(4)),
                is(singletonList(overrideAWeekPrior)));
    }

    @Test
    public void shouldFindLatestExpiredSourceProductCost() {
        final Cost costInTheMiddle = sourceCost();
        repository.save(costInTheMiddle);
        final Cost costInTheBeginning = costInTheMiddle.toBuilder()
                .startDate(LocalDate.of(2018, 11, 1))
                .endDate(LocalDate.of(2018, 11, 3))
                .build();
        repository.save(costInTheBeginning);

        final Cost costWithLatestEndDate = costInTheMiddle.toBuilder()
                .startDate(LocalDate.of(2018, 11, 1))
                .endDate(LocalDate.of(2018, 11, 6))
                .build();
        costWithLatestEndDate.setCreatedAt(LocalDateTime.now().minusMinutes(100));
        repository.save(costWithLatestEndDate);

        final Cost anotherCostUpdateForSameTimeFrame = costInTheMiddle.toBuilder()
                .startDate(LocalDate.of(2018, 11, 1))
                .endDate(LocalDate.of(2018, 11, 6))
                .build();
        repository.save(anotherCostUpdateForSameTimeFrame);

        assertThat(repository.findAllByNameAndEndDateLessThanOrderByEndDateDescCreatedAtDesc(costInTheMiddle
                        .getName(),
                costInTheMiddle.getEndDate().plusDays(3)),
                is(asList(anotherCostUpdateForSameTimeFrame, costWithLatestEndDate, costInTheMiddle,
                        costInTheBeginning)));
    }

    @Test
    public void shouldFindFinishedProductCostFromSevenDaysAgo() {
        LocalDate fromSevenDays = LocalDate.now().minusDays(7);
        final Cost cost = Cost.builder()
                .name("BOB")
                .source(PRICING_MODEL)
                .startDate(fromSevenDays)
                .endDate(LocalDate.now().plusDays(7))
                .marketCost(Money.of(3))
                .yieldModelId(17L)
                .labor(Money.of(3))
                .weightedAverageCost(null)
                .currentCostPerPound(Money.of(3 / 2))
                .build();
        cost.setCreatedAt(LocalDateTime.of(cost.getStartDate().minusDays(1), MIDNIGHT));
        cost.setUpdatedAt(null);

        repository.save(cost);

        assertThat(repository.mostRecentForAt(cost.getName(), cost.getStartDate()),
                is(singletonList(cost)));
    }

    @Test
    public void shouldFindFinishedProductCurrentCost() {
        final Cost finished = finishedCost();

        repository.save(finished);

        assertThat(repository.mostRecentForAt(finished.getName(), finished.getStartDate().plusDays(1)),
                is(singletonList(finished)));
    }

    @Test
    public void shouldOrderByMostRecentFirst() {
        final Cost finishedOld = finishedCost();

        final Cost finishedNew = finishedOld.toBuilder()
                .labor(finishedOld.getLabor().add(ONE))
                .build();
        finishedNew.setCreatedAt(finishedOld.getCreatedAt().plusHours(1));

        repository.save(finishedOld);
        repository.save(finishedNew);

        assertThat(repository.mostRecentForAt(finishedOld.getName(), finishedOld.getStartDate().plusDays(1)),
                is(asList(finishedNew, finishedOld)));
    }
}
