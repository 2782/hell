package com.sysco.prime;

import com.sysco.prime.box.Box;
import com.sysco.prime.box.Box.BoxBuilder;
import com.sysco.prime.box.Box.Status;
import com.sysco.prime.box.BoxRepository;
import com.sysco.prime.box.Weighing;
import com.sysco.prime.product.Product;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.Collections;
import java.util.List;

import static com.sysco.prime.DummyObjectFactory.buildProduct;
import static com.sysco.prime.DummyObjectFactory.incompleteBoxBuilder;
import static com.sysco.prime.DummyObjectFactory.weighingBuilder;
import static java.util.Collections.emptyList;
import static java.util.Collections.singletonList;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThat;

public class BoxRepositoryTest extends RepositoryTestBase<Box, BoxRepository> {
    @Autowired
    private BoxRepository repository;
    @Autowired
    private TestEntityManager entityManager;

    @Test
    public void shouldRoundtrip() {
        final Product sourceProduct = entityManager.persistFlushFind(buildProduct()
                .toBuilder()
                .code("1234567")
                .build());

        final Weighing unsavedWeighing = weighingBuilder()
                .weight(BigDecimal.valueOf(2.2f))
                .retailPieceTare(BigDecimal.valueOf(3.3f))
                .overrideWeightRangeReasonCode(121)
                .build();

        final Box unsavedBox = incompleteBoxBuilder()
                .status(Status.AVAILABLE)
                .sourceCutOrderId(null)
                .itemProduct(sourceProduct)
                .packagingTare(BigDecimal.ZERO)
                .weighings(singletonList(unsavedWeighing))
                .build();
        unsavedBox.getWeighings().forEach(weighing -> weighing.setBox(unsavedBox));

        final Box readBack = saveAndReadBack(unsavedBox);

        assertThat(readBack, is(unsavedBox));
    }

    @Test
    public void shouldSaveAndRetrieveBoxByConsumedDateAndProductCode() {
        final LocalDate today = LocalDate.of(2018, 12, 17);
        final LocalDateTime customerTimestamp = LocalDateTime.of(
                today,
                LocalTime.of(10, 11, 12));

        final Product sourceProduct = entityManager.persistFlushFind(buildProduct()
                .toBuilder()
                .code("1234567")
                .build());

        final Box unsaved = incompleteBoxBuilder()
                .weighings(singletonList(weighingBuilder()
                        .weight(BigDecimal.valueOf(2.2f))
                        .build()))
                .version(null)
                .consumedDate(today)
                .status(Status.AVAILABLE)
                .sourceCutOrderId(null)
                .packagingTare(BigDecimal.ZERO)
                .itemProduct(sourceProduct)
                .build();
        final Box savedBox = unsaved.toBuilder().version(0L).build();

        unsaved.setCreatedAt(customerTimestamp);
        unsaved.getWeighings().forEach(weighing -> weighing.setBox(unsaved));
        entityManager.persistAndFlush(unsaved);

        final List<Box> retrievedBox = repository.findByConsumedDateAndItemProductCode(today,
                sourceProduct.getCode());
        assertEquals(savedBox, retrievedBox.get(0));
    }
}
