package com.sysco.prime;

import com.sysco.prime.portionRoom.PortionRoom;
import com.sysco.prime.portionRoomTable.PortionRoomTable;
import com.sysco.prime.productionOrder.Blend;
import com.sysco.prime.station.Station;
import com.sysco.prime.yieldModel.GrindingYieldModel;
import com.sysco.prime.yieldModel.GrindingYieldModelRepository;
import com.sysco.prime.yieldModel.GrindingYieldModelSourceProduct;
import org.junit.Before;
import org.junit.Test;

import java.util.Optional;

import static com.sysco.prime.DummyObjectFactory.SECOND_SOURCE_PRODUCT_CODE;
import static com.sysco.prime.DummyObjectFactory.SOURCE_PRODUCT_CODE;
import static com.sysco.prime.DummyObjectFactory.THIRD_SOURCE_PRODUCT_CODE;
import static com.sysco.prime.DummyObjectFactory.buildGrindingYieldModel;
import static com.sysco.prime.DummyObjectFactory.grindingYieldModelBuilder;
import static com.sysco.prime.DummyObjectFactory.grindingYieldModelSourceProductBuilder;
import static com.sysco.prime.DummyObjectFactory.portionRoomBuilder;
import static com.sysco.prime.DummyObjectFactory.portionRoomTableBuilder;
import static com.sysco.prime.DummyObjectFactory.productBuilder;
import static com.sysco.prime.DummyObjectFactory.stationBuilder;
import static java.util.Arrays.asList;
import static java.util.Collections.emptyList;
import static java.util.Collections.singletonList;
import static org.hamcrest.CoreMatchers.hasItems;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

public class GrindingYieldModelRepositoryTest extends RepositoryTestBase<GrindingYieldModel,
        GrindingYieldModelRepository> {

    private GrindingYieldModel angusYieldModel;
    private GrindingYieldModelSourceProduct grindingYieldModelSourceProduct1;
    private GrindingYieldModelSourceProduct grindingYieldModelSourceProduct2;
    private Blend blend;

    @Before
    public void setUp() {
        final PortionRoom roomA = entityManager.persist(portionRoomBuilder()
                .code("A")
                .build());
        final Station stationInRoomA = entityManager.persist(stationBuilder()
                .room(roomA)
                .build());

        final PortionRoomTable tableInRoomA = entityManager.persist(portionRoomTableBuilder()
                .station(stationInRoomA)
                .build());
        blend = entityManager.find(Blend.class, 1L);

        entityManager.persist(productBuilder()
                .code(SOURCE_PRODUCT_CODE)
                .table(tableInRoomA)
                .build());
        entityManager.persist(productBuilder()
                .code(SECOND_SOURCE_PRODUCT_CODE)
                .table(tableInRoomA)
                .build());
        angusYieldModel = entityManager.persist(grindingYieldModelBuilder()
                .blend(blend)
                .pricingModel(true)
                .grindingYieldModelSourceProducts(emptyList())
                .build());
        grindingYieldModelSourceProduct1 = entityManager.persist(grindingYieldModelSourceProductBuilder()
                .sourceProductCode(SOURCE_PRODUCT_CODE)
                .grindingYieldModel(angusYieldModel)
                .build());
        grindingYieldModelSourceProduct2 = entityManager.persist(grindingYieldModelSourceProductBuilder()
                .sourceProductCode(SECOND_SOURCE_PRODUCT_CODE)
                .grindingYieldModel(angusYieldModel)
                .build());
        angusYieldModel.setGrindingYieldModelSourceProducts(
                asList(grindingYieldModelSourceProduct1, grindingYieldModelSourceProduct2));

        entityManager.persist(angusYieldModel);
        entityManager.flush();
    }

    @Test
    public void shouldRoundtrip() {
        final GrindingYieldModel grindingYieldModel = buildGrindingYieldModel();
        grindingYieldModel.setBlend(blend);

        final GrindingYieldModel saved = saveAndReadBack(grindingYieldModel);
        final GrindingYieldModel readBack = repository.getOneOrNull(saved.getId());

        assertThat(readBack, is(equalTo(saved)));
    }

    @Test
    public void shouldReturnExistingGrindingYieldModelWithSourceProducts() {
        final GrindingYieldModel readBack = repository.getOneOrNull(angusYieldModel.getId());

        assertThat(readBack, is(equalTo(angusYieldModel)));
        assertThat(readBack.getGrindingYieldModelSourceProducts(), hasItems(
                grindingYieldModelSourceProduct1, grindingYieldModelSourceProduct2));
    }

    @Test
    public void shouldSuccessfullyRetrieveGrindingYieldModelByBlendNameAndSourceProductCodes() {
        final Optional<GrindingYieldModel> actual = repository.findByBlendAndSourceProductCodes(
                blend.getName(), asList(SOURCE_PRODUCT_CODE, SECOND_SOURCE_PRODUCT_CODE));
        assertThat(actual.get(), is(angusYieldModel));
    }

    @Test
    public void shouldSuccessfullyRetrieveGrindingYieldModelByBlendNameAndSourceProductCodesInDifferentOrder() {
        final Optional<GrindingYieldModel> actual = repository.findByBlendAndSourceProductCodes(
                blend.getName(), asList(SECOND_SOURCE_PRODUCT_CODE, SOURCE_PRODUCT_CODE));
        assertThat(actual.get(), is(angusYieldModel));
    }

    @Test
    public void shouldNotRetrieveGrindingYieldModelIfNotAllSourceProductCodesAreProvided() {
        final Optional<GrindingYieldModel> actual = repository.findByBlendAndSourceProductCodes(
                blend.getName(), singletonList(SOURCE_PRODUCT_CODE));
        assertThat(actual, is(Optional.empty()));
    }

    @Test
    public void shouldNotRetrieveGrindingYieldModelIfAllSourceProductCodesAreProvidedButThereIsAdditional() {
        final Optional<GrindingYieldModel> actual = repository.findByBlendAndSourceProductCodes(
                blend.getName(), asList(
                        SOURCE_PRODUCT_CODE,
                        SECOND_SOURCE_PRODUCT_CODE,
                        THIRD_SOURCE_PRODUCT_CODE));
        assertThat(actual, is(Optional.empty()));
    }
}

