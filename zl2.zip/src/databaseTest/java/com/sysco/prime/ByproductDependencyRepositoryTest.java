package com.sysco.prime;

import com.sysco.prime.cost.Money;
import com.sysco.prime.product.Product;
import com.sysco.prime.product.ProductOutput;
import com.sysco.prime.yieldModel.ByproductDependency;
import com.sysco.prime.yieldModel.ByproductDependencyRepository;
import com.sysco.prime.yieldModel.CuttingYieldModelCopy;
import com.sysco.prime.yieldModel.PointsTo;
import com.sysco.prime.yieldModel.YieldModelFactory;
import org.junit.Test;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import static com.sysco.prime.DummyObjectFactory.productBuilder;
import static java.math.BigDecimal.ROUND_HALF_UP;
import static java.util.Collections.emptySet;
import static java.util.Collections.singleton;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

public class ByproductDependencyRepositoryTest extends
        RepositoryTestBase<ByproductDependency, ByproductDependencyRepository> {

    @Test
    public void shouldFindByProductDependenciesByProductCodeCorrespondingToTwoPricingModels() {
        final Product finishedProduct = productBuilder()
                .minWeight(BigDecimal.valueOf(1.0d).setScale(5, ROUND_HALF_UP))
                .maxWeight(BigDecimal.valueOf(25.0d).setScale(5, ROUND_HALF_UP))
                .code("1961172")
                .productOutput(ProductOutput.FINISHED)
                .build();
        final Product finishedProductTwo = productBuilder()
                .code("7734412")
                .productOutput(ProductOutput.FINISHED)
                .build();
        final Product finishedProductThree = productBuilder()
                .code("4102218")
                .productOutput(ProductOutput.FINISHED)
                .build();
        final Product byproductOnly = YieldModelFactory.byproductProduct();

        final ByproductDependency byproductDependency = ByproductDependency.builder()
                .pointsTo(PointsTo.COST)
                .product(byproductOnly)
                .build();
        final CuttingYieldModelCopy model1 = CuttingYieldModelCopy.builder()
                .finishedProduct(finishedProduct)
                .yieldAdditives(emptySet())
                .yieldByproducts(emptySet())
                .ingredients("Soy,milk,love")
                .labor(Money.ofCost(BigDecimal.ONE))
                .overhead(Money.ofCost(BigDecimal.ONE))
                .packaging(Money.ofCost(BigDecimal.ONE))
                .pickupPercent(BigDecimal.TEN)
                .pricingModel(true)
                .sourceLbs(BigDecimal.TEN.setScale(3, RoundingMode.HALF_UP))
                .yieldByproducts(singleton(byproductDependency))
                .build();

        byproductDependency.setOwner(model1);

        entityManager.persist(model1);

        final ByproductDependency byproductDependencyTwo = ByproductDependency.builder()
                .pointsTo(PointsTo.COST)
                .product(byproductOnly)
                .build();
        final CuttingYieldModelCopy model2 = CuttingYieldModelCopy.builder()
                .finishedProduct(finishedProductTwo)
                .yieldAdditives(emptySet())
                .yieldByproducts(emptySet())
                .ingredients("Soy,milk,fear")
                .labor(Money.ofCost(BigDecimal.TEN))
                .overhead(Money.ofCost(BigDecimal.TEN))
                .packaging(Money.ofCost(BigDecimal.TEN))
                .pickupPercent(BigDecimal.TEN)
                .pricingModel(true)
                .sourceLbs(BigDecimal.TEN.setScale(3, RoundingMode.HALF_UP))
                .yieldByproducts(singleton(byproductDependencyTwo))
                .build();
        byproductDependencyTwo.setOwner(model2);

        entityManager.persist(model2);

        final ByproductDependency byproductDependencyThree = ByproductDependency.builder()
                .pointsTo(PointsTo.COST)
                .product(byproductOnly)
                .build();
        final CuttingYieldModelCopy model3 = CuttingYieldModelCopy.builder()
                .finishedProduct(finishedProductThree)
                .yieldAdditives(emptySet())
                .yieldByproducts(emptySet())
                .ingredients("Soy,milk,fear")
                .labor(Money.ofCost(BigDecimal.TEN))
                .overhead(Money.ofCost(BigDecimal.TEN))
                .packaging(Money.ofCost(BigDecimal.TEN))
                .pickupPercent(BigDecimal.TEN)
                .pricingModel(false)
                .sourceLbs(BigDecimal.TEN.setScale(3, RoundingMode.HALF_UP))
                .yieldByproducts(singleton(byproductDependencyThree))
                .build();
        byproductDependencyThree.setOwner(model3);

        entityManager.persist(model3);
        entityManager.flush();

        final String byproductCode = byproductOnly.getCode();

        final List<ByproductDependency> readBack = repository.findByProduct_Code(byproductCode);

        assertThat(readBack.stream()
                .map(ByproductDependency::getOwner)
                .collect(Collectors.toList()), is(Arrays.asList(model1,
                model2, model3)));
    }
}
