package com.sysco.prime;

import com.sysco.prime.cost.Money;
import com.sysco.prime.product.Product;
import com.sysco.prime.productionOrder.Blend;
import com.sysco.prime.yieldModel.GrindingSourceDependency;
import com.sysco.prime.yieldModel.GrindingSourceDependencyRepository;
import com.sysco.prime.yieldModel.GrindingYieldModelCopy;
import com.sysco.prime.yieldModel.PointsTo;
import org.junit.Test;

import java.math.BigDecimal;
import java.util.List;
import java.util.stream.Collectors;

import static com.sysco.prime.yieldModel.YieldModelFactory.sourceProduct;
import static java.util.Collections.singleton;
import static org.assertj.core.api.Java6Assertions.assertThat;

public class GrindingSourceDependencyRepositoryTest extends
        RepositoryTestBase<GrindingSourceDependency, GrindingSourceDependencyRepository> {

    @Test
    public void shouldFindSourceDependenciesByProductCodeCorrespondingToPricingAndNonPricingModels() {
        final Blend blend = entityManager.find(Blend.class, 1L);
        final Blend blendTwo = entityManager.find(Blend.class, 2L);
        final Blend blendThree = entityManager.find(Blend.class, 3L);
        final Product sourceProduct = sourceProduct();

        final GrindingSourceDependency sourceDependency = GrindingSourceDependency.builder()
                .pointsTo(PointsTo.COST)
                .product(sourceProduct)
                .build();
        final GrindingYieldModelCopy model1 = GrindingYieldModelCopy.builder()
                .blend(blend)
                .sourceProducts(singleton(sourceDependency))
                .labor(Money.ofCost(BigDecimal.ONE))
                .overhead(Money.ofCost(BigDecimal.ONE))
                .packaging(Money.ofCost(BigDecimal.ONE))
                .pricingModel(true)
                .build();
        sourceDependency.setOwner(model1);

        entityManager.persist(model1);

        final GrindingSourceDependency sourceDependencyTwo = GrindingSourceDependency.builder()
                .pointsTo(PointsTo.COST)
                .product(sourceProduct)
                .build();
        final GrindingYieldModelCopy model2 = GrindingYieldModelCopy.builder()
                .blend(blendTwo)
                .sourceProducts(singleton(sourceDependencyTwo))
                .labor(Money.ofCost(BigDecimal.TEN))
                .overhead(Money.ofCost(BigDecimal.TEN))
                .packaging(Money.ofCost(BigDecimal.TEN))
                .pricingModel(true)
                .build();
        sourceDependencyTwo.setOwner(model2);

        entityManager.persist(model2);

        final GrindingSourceDependency sourceDependencyThree = GrindingSourceDependency.builder()
                .pointsTo(PointsTo.COST)
                .product(sourceProduct)
                .build();
        final GrindingYieldModelCopy model3 = GrindingYieldModelCopy.builder()
                .blend(blendThree)
                .sourceProducts(singleton(sourceDependencyThree))
                .labor(Money.ofCost(BigDecimal.TEN))
                .overhead(Money.ofCost(BigDecimal.TEN))
                .packaging(Money.ofCost(BigDecimal.TEN))
                .pricingModel(false)
                .build();
        sourceDependencyThree.setOwner(model3);

        entityManager.persist(model3);
        entityManager.flush();

        final String sourceProductCode = sourceProduct.getCode();

        final List<GrindingSourceDependency> readBack = repository.findByProduct_Code(sourceProductCode);

        assertThat(readBack.stream()
                .map(GrindingSourceDependency::getOwner)
                .collect(Collectors.toList()))
                .containsExactlyInAnyOrder(model1,
                        model2, model3);
    }
}
