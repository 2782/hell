package com.sysco.prime;

import com.sysco.prime.product.Product;
import com.sysco.prime.purchaseOrder.PurchaseLineItem;
import com.sysco.prime.purchaseOrder.PurchaseLineItemCase;
import com.sysco.prime.purchaseOrder.PurchaseLineItemCaseRepository;
import com.sysco.prime.purchaseOrder.PurchaseOrder;
import com.sysco.prime.purchaseOrder.PurchaseOrderRepository;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Optional;

import static com.sysco.prime.DummyObjectFactory.purchaseOrderBuilder;
import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThat;

public class PurchaseOrderRepositoryTest extends RepositoryTestBase<PurchaseOrder, PurchaseOrderRepository> {
    private static final LocalDate today = LocalDate.of(2018, 7, 23);
    private static final LocalTime when = LocalTime.of(13, 58, 43);
    private PurchaseOrder latestPurchaseOrderForRoomA;

    @Autowired
    private PurchaseLineItemCaseRepository lineItemCaseRepository;

    @Before
    public void setUp() {
        final PurchaseOrder poA = purchaseOrderBuilder()
                .poNumber("co-123")
                .salesOrderNumber("123")
                .shipDate(today)
                .orderDate(today)
                .build();
        poA.setCreatedAt(today.atTime(when.minusSeconds(3)));
        entityManager.persist(poA);

        final PurchaseOrder poB = purchaseOrderBuilder()
                .poNumber("co-234")
                .salesOrderNumber("234")
                .shipDate(today.plusDays(2))
                .orderDate(today)
                .build();
        poB.setCreatedAt(today.atTime(when.minusSeconds(2)));
        entityManager.persist(poB);

        final PurchaseOrder poC = purchaseOrderBuilder()
                .poNumber("A-old")
                .roomCode("A")
                .shipDate(today)
                .orderDate(today)
                .build();
        poC.setCreatedAt(today.atTime(when.minusSeconds(1)));
        entityManager.persist(poC);

        entityManager.flush();

        latestPurchaseOrderForRoomA = purchaseOrderBuilder()
                .poNumber("A-new")
                .roomCode("A")
                .shipDate(today)
                .orderDate(today)
                .build();
        latestPurchaseOrderForRoomA.setCreatedAt(today.atTime(when));
        entityManager.persist(latestPurchaseOrderForRoomA);

        final PurchaseOrder poE = purchaseOrderBuilder()
                .poNumber("B-new")
                .roomCode("B")
                .shipDate(today)
                .orderDate(today)
                .build();
        poE.setCreatedAt(today.atTime(when));
        entityManager.persist(poE);

        final LocalDate futureDate = today.plusDays(1);
        final PurchaseOrder poF = purchaseOrderBuilder()
                .poNumber("A-back-to-the-future")
                .roomCode("A")
                .shipDate(futureDate)
                .orderDate(futureDate)
                .build();
        poF.setCreatedAt(futureDate.atTime(when));
        entityManager.persist(poF);

        entityManager.flush();
    }

    @Test
    public void shouldGetPurchaseOrderByOrderDateAndRoomCodeOrderByCreatedAtDesc() {
        final Optional<PurchaseOrder> purchaseOrder = repository
                .findTopByOrderDateAndRoomCodeOrderByCreatedAtDesc(today, "A");
        assertEquals(purchaseOrder.get(), latestPurchaseOrderForRoomA);
    }

    @Test
    public void shouldAddCasesToExistingLineItem() {
        final PurchaseOrder unsaved = purchaseOrderBuilder()
                .poNumber("C-back-to-the-future")
                .roomCode("C")
                .shipDate(today)
                .build()
                .add(PurchaseLineItem.builder()
                        .lineItemId(1)
                        .productCode("123456")
                        .quantityToProduce(0)
                        .build());

        PurchaseOrder saved = repository.save(unsaved);

        assertThat(saved.getLineItems().get(0).getLineItemCases(), hasSize(0));
        assertThat(lineItemCaseRepository.count(), is(0L));

        saved.getLineItems().get(0)
                .add(PurchaseLineItemCase.builder()
                        .packDate(LocalDate.now())
                        .weight(7f)
                        .build());
        saved.getLineItems().get(0).increaseQuantity();

        saved = repository.save(saved);

        assertThat(saved.getLineItems().get(0).getLineItemCases(), hasSize(1));
        assertThat(lineItemCaseRepository.count(), is(1L));

        saved.getLineItems().get(0)
                .add(PurchaseLineItemCase.builder()
                        .packDate(LocalDate.now())
                        .weight(12f)
                        .build());
        saved.getLineItems().get(0).increaseQuantity();

        saved = repository.save(saved);

        assertThat(saved.getLineItems().get(0).getLineItemCases(), hasSize(2));
        assertThat(lineItemCaseRepository.count(), is(2L));

        final PurchaseOrder readBack = entityManager.persistFlushFind(saved);
        assertThat(readBack, is(saved));
    }

    @Test
    public void shouldReturnPurchaseOrderBySalesOrderNumber() {
        final Optional<PurchaseOrder> order = repository.findBySalesOrderNumber("123");
        assertThat(order.get().getPoNumber(), is("co-123"));
    }

    @Test
    public void shouldReturnPurchaseOrderByRoomCodeOrderByCreatedAtDesc() {
        final Optional<PurchaseOrder> order = repository.findTopByRoomCodeOrderByCreatedAtDesc("A");
        assertThat(order.get().getPoNumber(), is("A-back-to-the-future"));
    }

    @Test
    public void shouldAddLineItemToPurchaseOrder() {
        final String productCode = "1010101";
        final PurchaseOrder unsaved = purchaseOrderBuilder()
                .poNumber("ZX-401-A")
                .roomCode("C")
                .shipDate(today)
                .build()
                .add(PurchaseLineItem.builder()
                        .lineItemId(1)
                        .productCode(productCode)
                        .quantityToProduce(2)
                        .build());

        PurchaseOrder saved = repository.save(unsaved);

        repository.save(saved.add(PurchaseLineItem.builder()
                .lineItemId(2)
                .productCode("0101010")
                .quantityToProduce(3)
                .build()));

        final Product product = Product.builder().code(productCode).build();
        final PurchaseLineItem lineItemFor = saved.getLineItemFor(product);
        lineItemFor.updateQuantityToProduce(Integer.valueOf(12));
        saved = repository.save(saved);

        final PurchaseOrder readBack = entityManager.persistFlushFind(saved);
        assertThat(12, is(readBack.getLineItemFor(product).getQuantityToProduce()));
    }
}
