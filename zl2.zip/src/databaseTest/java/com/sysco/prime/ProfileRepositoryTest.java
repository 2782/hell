package com.sysco.prime;

import com.sysco.prime.profile.Profile;
import com.sysco.prime.profile.ProfileRepository;
import org.junit.Before;
import org.junit.Test;

import java.util.List;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

public class ProfileRepositoryTest extends RepositoryTestBase<Profile, ProfileRepository> {
    @Before
    public void setUp() {
        final Profile profile1 = DummyObjectFactory
                .profileBuilder()
                .state("AL")
                .build();

        final Profile profile2 = DummyObjectFactory
                .profileBuilder()
                .state("CA")
                .build();

        entityManager.persist(profile1);
        entityManager.persist(profile2);
        entityManager.flush();
    }

    @Test
    public void shouldFindAllCompanyProfileWithRightField() {
        final List<Profile> profiles = repository.findAll();

        assertThat(profiles.size(), is(2));
        assertThat(profiles.get(1).getPlantNumber(), is("123"));
        assertThat(profiles.get(1).getName(), is("Sysco & newPort"));
        assertThat(profiles.get(1).getAddress(), is("4114 Sepulveda Blvd."));
        assertThat(profiles.get(1).getCity(), is("Culver"));
        assertThat(profiles.get(1).getState(), is("CA"));
        assertThat(profiles.get(1).getZipCode(), is("90230"));
        assertThat(profiles.get(1).getEstablishmentNumber(), is("4195"));
        assertThat(profiles.get(0).getState(), is("AL"));
    }
}
