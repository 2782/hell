package com.sysco.prime;

import com.sysco.prime.shared.model.TransactionalEntity;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import static org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace.NONE;

@RunWith(SpringRunner.class)
@DataJpaTest
@AutoConfigureTestDatabase(replace = NONE)
@ActiveProfiles("test")
@Transactional
public abstract class RepositoryTestBase<T extends TransactionalEntity, R extends PrimeRepository<T>> {
    @Autowired
    protected TestEntityManager entityManager;
    @SuppressWarnings("SpringJavaInjectionPointsAutowiringInspection")
    @Autowired
    protected R repository;

    /**
     * Guarantees <em>any</em> {@link TransactionalEntity} is written to the database, and a copy read back from the
     * database, bypassing caching.
     */
    protected <U extends TransactionalEntity> U saveAndReadBack(final U entity) {
        return entityManager.persistFlushFind(entity);
    }
}
