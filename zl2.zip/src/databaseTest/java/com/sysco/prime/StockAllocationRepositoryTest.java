package com.sysco.prime;

import com.sysco.prime.customer.Customer;
import com.sysco.prime.customerOrder.CustomerOrder;
import com.sysco.prime.customerOrder.LineItem;
import com.sysco.prime.customerOrder.StockAllocation;
import com.sysco.prime.customerOrder.StockAllocationRepository;
import com.sysco.prime.product.Product;
import org.junit.Before;
import org.junit.Test;

import java.util.List;

import static com.sysco.prime.DummyObjectFactory.buildCustomer;
import static com.sysco.prime.DummyObjectFactory.customerOrderBuilder;
import static com.sysco.prime.DummyObjectFactory.lineItemBuilder;
import static com.sysco.prime.DummyObjectFactory.productBuilder;
import static com.sysco.prime.DummyObjectFactory.stockAllocationBuilder;
import static java.util.Collections.emptyList;
import static java.util.Collections.singletonList;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

public class StockAllocationRepositoryTest extends RepositoryTestBase<StockAllocation, StockAllocationRepository> {
    private List<Long> lineItemIds;
    private StockAllocation stockAllocation;

    @Before
    public void setUp() {
        final Product product = entityManager.persist(productBuilder().build());
        final Customer customer = entityManager.persist(buildCustomer());
        final CustomerOrder customerOrder = entityManager.persist(
                customerOrderBuilder().customer(customer).lineItems(emptyList()).build()
        );
        final LineItem lineItem = entityManager.persist(
                lineItemBuilder().product(product).customerOrder(customerOrder).build()
        );
        final LineItem lineItem1 = entityManager.persist(
                lineItemBuilder().product(product).customerOrder(customerOrder).build()
        );

        lineItemIds = singletonList(lineItem1.getId());

        entityManager.persist(stockAllocationBuilder().lineItem(lineItem).allocatedQuantity(10).build());
        stockAllocation = entityManager.persist(
                stockAllocationBuilder().lineItem(lineItem1).allocatedQuantity(15).build()
        );

        entityManager.flush();
    }

    @Test
    public void shouldGetStockAllocationsByLineItemIds() {
        final List<StockAllocation> stockAllocations = repository.findByLineItemIdIn(lineItemIds);

        assertThat(stockAllocations.size(), is(1));
        assertThat(stockAllocations.get(0), is(stockAllocation));
    }
}
