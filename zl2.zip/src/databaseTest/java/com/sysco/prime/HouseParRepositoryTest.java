package com.sysco.prime;

import com.sysco.prime.housePar.HousePar;
import com.sysco.prime.housePar.HouseParRepository;
import com.sysco.prime.product.Product;
import com.sysco.prime.shared.model.ParValue;
import org.junit.Before;
import org.junit.Test;

import static com.sysco.prime.DummyObjectFactory.buildProduct;
import static com.sysco.prime.DummyObjectFactory.houseParBuilder;
import static com.sysco.prime.shared.model.ParValue.ParType.HOUSE_PAR;
import static java.util.Arrays.asList;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

public class HouseParRepositoryTest extends RepositoryTestBase<HousePar, HouseParRepository> {
    private HousePar housePar;

    @Before
    public void setUp() {
        final Product savedProduct = entityManager.persist(buildProduct().toBuilder().build());
        housePar = houseParBuilder()
                .product(savedProduct)
                .build();
        housePar.getConfigValues().forEach(config -> config.attachTo(housePar));
    }

    @Test
    public void shouldRoundtrip() {
        final HousePar saved = saveAndReadBack(housePar);
        final HousePar readBack = repository.getOneOrNull(saved.getId());

        assertThat(readBack, is(equalTo(saved)));
    }

    @Test
    public void shouldUpdateAndDeleteOrphans() {
        HousePar saved = saveAndReadBack(housePar);
        final HousePar updated = repository.getOneOrNull(saved.getId());

        updated.replaceConfigValuesWith(asList(
                new ParValue(HOUSE_PAR, null, 1, 2, false),
                new ParValue(HOUSE_PAR, null, 2, 1, false)));
        saved = saveAndReadBack(updated);
        final HousePar readBack = repository.getOneOrNull(saved.getId());

        assertThat(readBack, is(equalTo(updated)));
    }
}
