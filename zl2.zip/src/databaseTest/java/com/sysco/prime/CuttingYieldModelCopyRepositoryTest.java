package com.sysco.prime;

import com.sysco.prime.cost.CostService;
import com.sysco.prime.yieldModel.CuttingYieldModelCopy;
import com.sysco.prime.yieldModel.CuttingYieldModelCopyRepository;
import com.sysco.prime.yieldModel.YieldModelFactory;
import org.junit.Before;
import org.junit.Test;

import java.time.Clock;
import java.time.LocalDate;

import static com.sysco.prime.utils.TimeUtilsTest.mockClockToNow;
import static com.sysco.prime.yieldModel.YieldModelFactory.finishedProduct;
import static com.sysco.prime.yieldModel.YieldModelFactory.sourceProduct;
import static org.assertj.core.api.Java6Assertions.assertThat;
import static org.mockito.Mockito.mock;

public class CuttingYieldModelCopyRepositoryTest extends
        RepositoryTestBase<CuttingYieldModelCopy, CuttingYieldModelCopyRepository> {
    private Clock when;
    private CostService costService;
    private LocalDate date;

    @Before
    public void setup() {
        when = mock(Clock.class);
        costService = mock(CostService.class);
        mockClockToNow(when);
        date = LocalDate.now(when);
    }

    @Test
    public void shouldFindPricingModelByFinishedProductCode() {
        CuttingYieldModelCopy model = YieldModelFactory.cuttingAllCosts(costService, date, null, 13L);
        model.getFinishedProduct().setProductGroup(null);

        entityManager.persist(model);
        entityManager.flush();

        String productCode = YieldModelFactory.finishedProduct().getCode();

        final CuttingYieldModelCopy readBack = repository
                .findByFinishedProductCodeAndPricingModelTrue(productCode);

        assertThat(readBack).isEqualTo(model);
    }

    @Test
    public void shouldFindYieldModelByFinishedAndSourceProductCode() {
        final CuttingYieldModelCopy model = YieldModelFactory.cuttingAllCosts(costService, date, null, 13L);
        model.getFinishedProduct().setProductGroup(null);

        entityManager.persist(model);
        entityManager.flush();

        final CuttingYieldModelCopy readBackOne =
                repository.findByFinishedProductCodeAndSourceProduct_Product_Code(finishedProduct().getCode(),
                        sourceProduct().getCode());

        assertThat(readBackOne).isEqualTo(model);
    }
}
