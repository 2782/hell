package com.sysco.prime;

import com.sysco.prime.packages.BoxType;
import com.sysco.prime.packages.FilmType;
import com.sysco.prime.packages.TarePackage;
import com.sysco.prime.product.Allergen;
import com.sysco.prime.product.Product;
import com.sysco.prime.product.ProductOutput;
import com.sysco.prime.product.ProductRepository;
import com.sysco.prime.product.RetailSpecific;
import com.sysco.prime.sus.model.SusIncompleteProductResponse;
import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Test;

import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.util.List;

import static com.sysco.prime.DummyObjectFactory.buildBoxType;
import static com.sysco.prime.DummyObjectFactory.buildFilmType;
import static com.sysco.prime.DummyObjectFactory.buildProduct;
import static com.sysco.prime.DummyObjectFactory.buildSusIncompleteProductResponse;
import static com.sysco.prime.DummyObjectFactory.productBuilder;
import static com.sysco.prime.DummyObjectFactory.tarePackageBuilder;
import static java.util.Arrays.asList;
import static java.util.Collections.singletonList;
import static java.util.stream.Collectors.toList;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

public class ProductRepositoryTest extends RepositoryTestBase<Product, ProductRepository> {
    @Before
    public void setUp() {
        final Product product1 = productBuilder().code("1").description("CF LA DNF").build();
        final Product product2 = productBuilder().code("2").description("CP LA").build();
        final Product product3 = productBuilder().code("3").description("LA D").build();
        final Product product4 = productBuilder().code("4").description("LECAD").build();
        final Product product5 = productBuilder().code("5").description("LA/E").build();
        final Product product6 = productBuilder().code("6").description("LA,P").build();
        final Product product7 = productBuilder().code("7").description("la,c").build();

        entityManager.persist(product1);
        entityManager.persist(product2);
        entityManager.persist(product3);
        entityManager.persist(product4);
        entityManager.persist(product5);
        entityManager.persist(product6);
        entityManager.persist(product7);

        entityManager.flush();
    }

    @Test
    public void shouldRoundTripProductWithAllergens() {
        final Allergen allergen1 = entityManager.find(Allergen.class, 1L);
        final Allergen allergen2 = entityManager.find(Allergen.class, 2L);

        final Product product = buildProduct();
        product.setAllergens(asList(allergen1, allergen2));

        final Product saved = saveAndReadBack(product);

        final Product readBack = repository.getOneOrNull(saved.getId());

        assertThat(readBack, is(equalTo(saved)));
    }

    @Test
    public void shouldRemoveProductFromAllergen() {
        final Allergen allergen1 = entityManager.find(Allergen.class, 1L);
        final Allergen allergen2 = entityManager.find(Allergen.class, 2L);


        final Product setupProduct = buildProduct();
        setupProduct.setAllergens(asList(allergen1, allergen2));

        final Product existing = saveAndReadBack(setupProduct);

        existing.setAllergens(singletonList(allergen2));

        final Product saved = saveAndReadBack(existing);

        final Product readBack = repository.getOneOrNull(saved.getId());

        assertThat(readBack.getAllergens(), hasSize(1));
        assertThat(readBack.getAllergens().get(0), is(equalTo(allergen2)));
    }

    @Test
    public void shouldRoundTripCompleteProduct() {
        final Product product = buildProduct();

        final Product saved = saveAndReadBack(product);
        final Product readBack = repository.getOneOrNull(saved.getId());

        assertThat(readBack, is(equalTo(saved)));
    }

    @Test
    public void shouldRoundTripIncompleteProduct() {
        final SusIncompleteProductResponse incompleteProductResponse = buildSusIncompleteProductResponse();
        final Product product = incompleteProductResponse.toDomain();

        final Product saved = saveAndReadBack(product.toBuilder().build());
        final Product readBack = repository.getOneOrNull(saved.getId());

        assertThat(readBack, is(equalTo(saved)));
    }

    @Test
    public void shouldFilterOutByProductOnlyFromIncompleteProducts() {
        final SusIncompleteProductResponse incompleteProductResponse = buildSusIncompleteProductResponse();
        final Product product = incompleteProductResponse.toDomain();

        Product byProductOnly = repository.saveAndFlush(product.toBuilder()
                .productOutput(ProductOutput.BYPRODUCT_ONLY)
                .build());

        final List<Product> incompleteProducts = repository.findAllIncompleteProducts();

        Assertions.assertThat(incompleteProducts).doesNotContain(byProductOnly);
    }

    @Test
    public void shouldSaveWithoutSubprimalCode() {
        final Product product = productBuilder()
                .subPrimalCode(null)
                .subPrimalDescription(null)
                .build();

        final Product saved = saveAndReadBack(product);
        final Product readBack = repository.getOneOrNull(saved.getId());

        assertThat(readBack, is(equalTo(saved)));
    }

    @Test
    public void shouldGetProductsByDescriptions() {
        String description = "LA";
        List<Product> products = repository.findByDescription(description);
        final List<@NotNull String> descriptions = products.stream()
                .map(Product::getDescription)
                .sorted()
                .collect(toList());

        assertThat(descriptions, is(asList(
                "CF LA DNF",
                "CP LA",
                "LA D",
                "LA,P",
                "LA/E",
                "la,c")));

        description = "^(.*\\W)?LA DNF(\\W.*)?$";
        products = repository.findByDescription(description);
        assertThat(products.size(), is(1));
        assertThat(products.get(0).getDescription(), is("CF LA DNF"));
    }

    @Test
    public void shouldGetAllFinishedProducts() {
        final Product sourceProduct = productBuilder()
                .productOutput(ProductOutput.SOURCE)
                .code("8").build();
        entityManager.persist(sourceProduct);

        List<Product> products = repository.findByProductOutputInOrderByCode(singletonList(ProductOutput.FINISHED));

        assertThat(products.size(), is(7));
    }

    @Test
    public void shouldSaveRetailSpecificWhenSaving() {
        final Product product = buildProduct();

        BoxType savedBox = entityManager.persistFlushFind(buildBoxType());
        FilmType savedFilm = entityManager.persistFlushFind(buildFilmType());

        TarePackage tarePackage = tarePackageBuilder()
                .boxType(savedBox)
                .filmType(savedFilm)
                .build();

        TarePackage savedPackage = entityManager.persistFlushFind(tarePackage);

        final RetailSpecific retailSpecific = RetailSpecific.builder()
                .price(BigDecimal.valueOf(10))
                .maxWeight(BigDecimal.valueOf(3))
                .minWeight(BigDecimal.valueOf(1))
                .tare(savedPackage)
                .build();

        product.setRetailSpecific(retailSpecific);

        Product savedProduct = entityManager.persistFlushFind(product);

        assertThat(savedProduct.getRetailSpecific(), is(retailSpecific));
    }
}
