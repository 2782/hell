package com.sysco.prime;

import com.sysco.prime.portionRoom.PortionRoom;
import com.sysco.prime.portionRoomTable.PortionRoomTable;
import com.sysco.prime.portionRoomTable.PortionRoomTableRepository;
import com.sysco.prime.station.Station;
import com.sysco.prime.station.StationRepository;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.time.LocalDateTime;
import java.time.LocalTime;

import static com.sysco.prime.DummyObjectFactory.portionRoomBuilder;
import static com.sysco.prime.DummyObjectFactory.stationBuilder;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.not;
import static org.junit.Assert.assertThat;

public class PortionRoomTableRepositoryTest extends RepositoryTestBase<PortionRoomTable, PortionRoomTableRepository> {
    @Autowired
    private StationRepository stations;

    @Test
    public void shouldSaveAndUpdateTable() {
        final PortionRoom roomA = entityManager.persist(portionRoomBuilder()
                .code("A")
                .build());
        final Station station12 = stations.save(stationBuilder()
                .room(roomA)
                .build());

        PortionRoomTable table64 = repository.save(PortionRoomTable.builder()
                .tableCode(64)
                .tableDescription("GOAT")
                .station(station12)
                .tableOpenTime(LocalTime.parse("08:00"))
                .tableCloseTime(LocalTime.parse("16:00"))
                .poundsPerHour(100)
                .build());

        entityManager.flush();

        final PortionRoomTable theFirstOne = repository.getOneOrNull(table64.getId());
        final LocalDateTime originalCreatedAt = theFirstOne.getCreatedAt();
        final LocalDateTime originalUpdatedAt = theFirstOne.getUpdatedAt();

        assertThat(theFirstOne.getTableCode(), is(table64.getTableCode()));
        assertThat(theFirstOne.getTableDescription(), is("GOAT"));
        assertThat(theFirstOne.getStationId(), is(table64.getStationId()));

        table64.setTableDescription("MUTTON");
        table64 = repository.save(table64);

        entityManager.flush();

        final PortionRoomTable theOtherOne = repository.getOneOrNull(table64.getId());

        assertThat(theOtherOne.getTableCode(), is(table64.getTableCode()));
        assertThat(theOtherOne.getTableDescription(), is("MUTTON"));
        assertThat(theOtherOne.getStationId(), is(table64.getStationId()));

        assertThat(theOtherOne.getCreatedAt(), is(originalCreatedAt));
        assertThat(theOtherOne.getUpdatedAt(), is(not(originalUpdatedAt)));
    }
}
