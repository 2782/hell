package com.sysco.prime.reporting.repository;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sysco.prime.RepositoryTestBase;
import com.sysco.prime.cost.Money;
import com.sysco.prime.reporting.model.ReportingEvent;
import com.sysco.prime.reporting.model.ReportingGrindingYieldModel;
import com.sysco.prime.reporting.model.ReportingGrindingYieldModelChangeLog;
import com.sysco.prime.reporting.model.ReportingGrindingYieldModelSourceProduct;
import com.sysco.prime.yieldModel.GrindingYieldModel;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.json.JsonTest;

import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.Set;

import static com.sysco.prime.DummyObjectFactory.grindingYieldModelBuilder;
import static com.sysco.prime.cost.Cost.COST_NEVER_EXPIRES;
import static java.util.stream.Collectors.toSet;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThat;

@JsonTest
public class ReportingGrindingYieldModelChangeLogRepositoryTest extends
        RepositoryTestBase<ReportingGrindingYieldModelChangeLog,
                ReportingGrindingYieldModelChangeLogRepository> {
    @Autowired
    private ReportingGrindingYieldModelChangeLogRepository repository;
    @Autowired
    private ObjectMapper objectMapper;

    private ReportingGrindingYieldModel saved;

    private LocalDate activityDate;

    @Before
    public void setup() {
        final OffsetDateTime timestamp = ZonedDateTime.of(2011, 2, 15, 4, 10, 0, 0, ZoneId.systemDefault())
                .toOffsetDateTime();
        activityDate = LocalDate.of(2011, 2, 15);

        final GrindingYieldModel grindingYieldModel = grindingYieldModelBuilder()
                .build();

        final ReportingEvent event = ReportingEvent.builder().type("YieldModel")
                .timestamp(timestamp)
                .principal("user-1")
                .data(grindingYieldModel.asMap(objectMapper))
                .build();
        final ReportingEvent savedEvent = entityManager.persistFlushFind(event);

        final Set<String> sourceProductCodes = grindingYieldModel.sourceProductCodes();

        final Set<ReportingGrindingYieldModelSourceProduct> reportingSourceProducts =
                sourceProductCodes.stream()
                        .map(sourceProductCode ->
                                ReportingGrindingYieldModelSourceProduct.builder()
                                        .sourceProductCode(sourceProductCode)
                                        .build())
                        .collect(toSet());
        final ReportingGrindingYieldModel reportingGrindingYieldModel = ReportingGrindingYieldModel
                .builder()
                .blend(grindingYieldModel.getBlend().getName())
                .build()
                .addAll(reportingSourceProducts)
                .addChangelog(ReportingGrindingYieldModelChangeLog
                        .builder()
                        .fieldName(ReportingGrindingYieldModelChangeLog.FieldType.CREATED)
                        .userId("user-1")
                        .timestamp(timestamp)
                        .reportingEventId(savedEvent.getId())
                        .activityDate(activityDate).build())
                .addChangelog(ReportingGrindingYieldModelChangeLog
                        .builder()
                        .fieldName(ReportingGrindingYieldModelChangeLog.FieldType.LABOR)
                        .userId("user-1")
                        .oldValue(Money.of(0.0))
                        .newValue(Money.of(1.0))
                        .timestamp(timestamp.plusDays(1))
                        .reportingEventId(savedEvent.getId())
                        .activityDate(activityDate.plusDays(1)).build())
                .addChangelog(ReportingGrindingYieldModelChangeLog
                        .builder()
                        .fieldName(ReportingGrindingYieldModelChangeLog.FieldType.LABOR)
                        .userId("user-2")
                        .oldValue(Money.of(1.0))
                        .newValue(Money.of(2.0))
                        .timestamp(timestamp.plusDays(1))
                        .reportingEventId(savedEvent.getId())
                        .activityDate(activityDate.plusDays(1)).build());
        saved = entityManager.persistFlushFind(reportingGrindingYieldModel);
    }

    @Test
    public void shouldUniqueDatesForGivenGrindingYieldModel() {
        final List<LocalDate> foundList = repository.findUniqueActivityDatesFor(saved.getId());
        assertEquals(foundList.get(0), activityDate);
        assertEquals(foundList.get(1), activityDate.plusDays(1));
    }

    @Test
    public void shouldFindUniqueUserIds() {
        final List<String> foundList = repository.findUniqueLogUserIds(saved.getId(), LocalDate.ofEpochDay(0),
                COST_NEVER_EXPIRES);
        assertThat(foundList, is(Arrays.asList("user-1", "user-2")));
    }
}
