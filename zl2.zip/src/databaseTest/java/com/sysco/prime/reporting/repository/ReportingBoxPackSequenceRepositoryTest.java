package com.sysco.prime.reporting.repository;

import com.sysco.prime.RepositoryTestBase;
import com.sysco.prime.reporting.model.ReportingBox;
import com.sysco.prime.reporting.model.ReportingBoxPackSequence;
import org.junit.Before;
import org.junit.Test;
import org.springframework.boot.test.autoconfigure.json.JsonTest;

import java.time.LocalDate;
import java.util.List;

import static com.sysco.prime.reporting.model.ReportingBox.Status.ASSIGNED;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

@JsonTest
public class ReportingBoxPackSequenceRepositoryTest extends RepositoryTestBase<ReportingBoxPackSequence,
        ReportingBoxPackSequenceRepository> {
    @Before
    public void setup() {
        final LocalDate localDate = LocalDate.of(2011, 2, 3);
        final String packOffStationName = "Next to the Fire Drill Door";
        final ReportingBox unsaved = ReportingBox.builder()
                .netWeight(2.22d)
                .customerCode("77")
                .customerName("Popeye")
                .customerOrderNumber("10101010101")
                .weightPerBox(12.34d)
                .isFixWeightProduct(true)
                .laborCost(3.45d)
                .packoffStationName(packOffStationName)
                .portionRoomCode("A")
                .principal("Howard the Duck")
                .workingDate(localDate)
                .productCode("1234567")
                .productDescription("TASTY FOWL")
                .replacementCost(99.99d)
                .shipDate(localDate)
                .stationCode(3)
                .status(ASSIGNED)
                .tableCode(4)
                .tableDescription("BIRDS")
                .yieldPercentage(0.10d)
                .build();

        entityManager.persist(unsaved);
        entityManager.flush();
    }

    @Test
    public void shouldGetOneBoxPackSequence() {
        final List<ReportingBoxPackSequence> readBack = repository.findAll();

        assertThat(readBack.size(), is(1));
    }
}