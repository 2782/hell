package com.sysco.prime.reporting.repository;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sysco.prime.RepositoryTestBase;
import com.sysco.prime.reporting.model.ReportingCuttingYieldModel;
import com.sysco.prime.reporting.model.ReportingCuttingYieldModelChangeLog;
import com.sysco.prime.reporting.model.ReportingCuttingYieldModelChangeLog.FieldType;
import com.sysco.prime.reporting.model.ReportingEvent;
import com.sysco.prime.yieldModel.CuttingYieldModel;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.json.JsonTest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.OffsetDateTime;
import java.util.Collections;
import java.util.List;

import static com.google.common.collect.Lists.newArrayList;
import static com.sysco.prime.DummyObjectFactory.cuttingYieldModelBuilder;
import static com.sysco.prime.utils.TimeUtilsTest.offsetDateTime;
import static org.hamcrest.collection.IsIterableContainingInAnyOrder.containsInAnyOrder;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThat;

@JsonTest
public class ReportingCuttingYieldModelChangeLogRepositoryTest extends
        RepositoryTestBase<ReportingCuttingYieldModelChangeLog, ReportingCuttingYieldModelChangeLogRepository> {

    @Autowired
    private ReportingCuttingYieldModelChangeLogRepository cuttingRepository;
    @Autowired
    private ObjectMapper objectMapper;

    private LocalDate today;
    private LocalDate previousDay;
    private ReportingCuttingYieldModel reportingCuttingYieldModelSavedOne;
    private String userId = "user-1";
    private int pageNumber = 0;
    private int pageSize = 5;
    private Pageable page = PageRequest.of(pageNumber, pageSize);
    private ReportingCuttingYieldModelChangeLog changeLog;
    private ReportingCuttingYieldModelChangeLog changeLogSecond;
    private ReportingCuttingYieldModelChangeLog changeLogLabor;
    private ReportingCuttingYieldModelChangeLog changeLogForDiffFinished;
    private String finishedProductCode = "1961172";
    private String finishedProductCodeDifferent = "2111148";
    private OffsetDateTime timestamp;
    private CuttingYieldModel yieldModelOne;
    private LocalDateTime customerTimestamp;

    @Before
    public void setup() {
        timestamp = offsetDateTime(2018, 12, 17, 4, 5, 0, 0);
        final OffsetDateTime previousTimestamp = offsetDateTime(2018, 12, 16, 4, 5, 0, 0);
        previousDay = LocalDate.of(2018, 12, 16);
        today = LocalDate.of(2018, 12, 17);

        customerTimestamp = LocalDateTime.of(today, LocalTime.of(10, 11, 12));
        final LocalDateTime previousCustomerTimestamp = LocalDateTime.of(previousDay, LocalTime.of(10, 11, 12));
        final String sourceProductCode = "3401581";

        final CuttingYieldModel yieldModelWithDifferentFinished = cuttingYieldModelBuilder()
                .finishedProductCode(finishedProductCodeDifferent)
                .sourceProductCode(sourceProductCode)
                .labor(new BigDecimal("1.11"))
                .finishedProductCost(BigDecimal.valueOf(17.65d))
                .pricingModel(true)
                .build();
        yieldModelWithDifferentFinished.setId(3L);
        final ReportingEvent yieldModelEventWithDiff = ReportingEvent.builder()
                .type("YieldModel")
                .timestamp(previousTimestamp)
                .principal(userId)
                .productCode("1961172")
                .data(yieldModelWithDifferentFinished.asMap(objectMapper)).build();
        yieldModelEventWithDiff.setCreatedAt(previousCustomerTimestamp);
        final ReportingEvent savedReportingEventWithDiffFinished = entityManager
                .persistFlushFind(yieldModelEventWithDiff);

        final ReportingCuttingYieldModel reportingCuttingYieldModelWithDiffFinished = ReportingCuttingYieldModel
                .builder()
                .finishedProductCode(yieldModelWithDifferentFinished.getFinishedProductCode())
                .sourceProductCode(yieldModelWithDifferentFinished.getSourceProductCode())
                .pricingModel(true)
                .build();
        changeLogForDiffFinished = ReportingCuttingYieldModelChangeLog
                .builder()
                .fieldName(FieldType.CREATED)
                .reportingEventId(savedReportingEventWithDiffFinished.getId())
                .timestamp(savedReportingEventWithDiffFinished.getTimestamp())
                .userId(savedReportingEventWithDiffFinished.getPrincipal())
                .activityDate(today)
                .build();
        changeLogForDiffFinished.setCreatedAt(customerTimestamp);
        reportingCuttingYieldModelWithDiffFinished.addChangelog(changeLogForDiffFinished);

        entityManager.persistFlushFind(reportingCuttingYieldModelWithDiffFinished);

        yieldModelOne = cuttingYieldModelBuilder()
                .finishedProductCode(finishedProductCode)
                .sourceProductCode(sourceProductCode)
                .labor(new BigDecimal("1.11"))
                .finishedProductCost(BigDecimal.valueOf(17.65d))
                .pricingModel(true)
                .build();
        yieldModelOne.setId(1L);
        final ReportingEvent yieldModelEvent = ReportingEvent.builder()
                .type("YieldModel")
                .timestamp(timestamp)
                .principal(userId)
                .productCode("1961172")
                .data(yieldModelOne.asMap(objectMapper)).build();
        yieldModelEvent.setCreatedAt(customerTimestamp);
        final ReportingEvent savedReportingEvent = entityManager.persistFlushFind(yieldModelEvent);

        final ReportingCuttingYieldModel reportingCuttingYieldModel = ReportingCuttingYieldModel.builder()
                .finishedProductCode(yieldModelOne.getFinishedProductCode())
                .sourceProductCode(yieldModelOne.getSourceProductCode())
                .pricingModel(true)
                .build();
        changeLog = ReportingCuttingYieldModelChangeLog.builder()
                .fieldName(FieldType.CREATED)
                .reportingEventId(savedReportingEvent.getId())
                .timestamp(yieldModelEvent.getTimestamp())
                .userId(yieldModelEvent.getPrincipal())
                .activityDate(today)
                .build();
        changeLog.setCreatedAt(customerTimestamp);
        reportingCuttingYieldModel.addChangelog(changeLog);
        ReportingCuttingYieldModelChangeLog changeLogSourceCost = ReportingCuttingYieldModelChangeLog.builder()
                .fieldName(FieldType.SOURCE_PRODUCT_COST)
                .reportingEventId(savedReportingEvent.getId())
                .timestamp(yieldModelEvent.getTimestamp())
                .userId(yieldModelEvent.getPrincipal())
                .activityDate(today)
                .build();
        changeLogSourceCost.setCreatedAt(customerTimestamp);
        reportingCuttingYieldModel.addChangelog(changeLogSourceCost);
        reportingCuttingYieldModelSavedOne = entityManager.persistFlushFind(reportingCuttingYieldModel);

        final CuttingYieldModel yieldModelTwo = yieldModelOne.toBuilder()
                .labor(new BigDecimal("1.11"))
                .finishedProductCost(BigDecimal.valueOf(17.65d))
                .build();
        yieldModelTwo.setId(1L);
        final ReportingEvent yieldModelEventTwo = ReportingEvent.builder()
                .type("YieldModel")
                .timestamp(timestamp)
                .principal("user-2")
                .productCode(finishedProductCode)
                .data(yieldModelTwo.asMap(objectMapper)).build();
        yieldModelEventTwo.setCreatedAt(customerTimestamp);
        final ReportingEvent savedReportingEventSecond = entityManager.persistFlushFind(yieldModelEventTwo);

        changeLogSecond = ReportingCuttingYieldModelChangeLog.builder()
                .fieldName(FieldType.CREATED)
                .reportingEventId(savedReportingEventSecond.getId())
                .timestamp(yieldModelEventTwo.getTimestamp())
                .userId(yieldModelEventTwo.getPrincipal())
                .activityDate(today)
                .build();
        changeLogSecond.setCreatedAt(customerTimestamp);
        reportingCuttingYieldModelSavedOne.addChangelog(changeLogSecond);
        changeLogLabor = ReportingCuttingYieldModelChangeLog.builder()
                .fieldName(FieldType.LABOR)
                .reportingEventId(savedReportingEvent.getId())
                .timestamp(yieldModelEvent.getTimestamp())
                .userId(yieldModelEvent.getPrincipal())
                .activityDate(previousDay)
                .build();
        changeLogLabor.setCreatedAt(previousCustomerTimestamp);
        reportingCuttingYieldModelSavedOne.addChangelog(changeLogLabor);
        reportingCuttingYieldModelSavedOne = entityManager.persistFlushFind(reportingCuttingYieldModelSavedOne);
    }

    @Test
    public void shouldUniqueDate() {
        final List<LocalDate> foundList = cuttingRepository
                .findUniqueActivityDatesFor(reportingCuttingYieldModelSavedOne.getId());

        assertEquals(foundList.get(0), previousDay);
        assertEquals(foundList.get(1), today);
    }

    @Test
    public void shouldSearchForPricingCuttingYieldModelAndNonSourceCostAndActivityDatesBetween() {
        final Page<ReportingCuttingYieldModelChangeLog> foundPage = cuttingRepository.findAll(null,
                Collections.emptyList(),
                null,
                previousDay,
                today,
                page);

        assertThat(newArrayList(changeLogForDiffFinished, changeLog, changeLogSecond, changeLogLabor),
                containsInAnyOrder(foundPage.getContent().toArray()));
    }

    @Test
    public void shouldSearchForPricingCuttingYieldModelAndNonSourceCostAndActivityDatesBetweenAndUser() {
        final Page<ReportingCuttingYieldModelChangeLog> foundPage = cuttingRepository.findAll("user-2",
                Collections.emptyList(),
                null,
                previousDay,
                today,
                page);

        assertEquals(newArrayList(changeLogSecond), foundPage.getContent());
    }

    @Test
    public void shouldSearchForPricingCuttingYieldModelAndFieldNameLaborAndActivityDatesBetween() {
        final Page<ReportingCuttingYieldModelChangeLog> foundPage = cuttingRepository.findAll(null,
                newArrayList(FieldType.LABOR),
                null,
                previousDay,
                today,
                page);

        assertEquals(newArrayList(changeLogLabor), foundPage.getContent());
    }

    @Test
    public void shouldSearchForPricingCuttingYieldModelAndFinishedProductAndActivityDatesBetweenAndUser() {
        final Page<ReportingCuttingYieldModelChangeLog> foundPage = cuttingRepository.findAll(null,
                Collections.emptyList(),
                finishedProductCodeDifferent,
                previousDay,
                today,
                page);

        assertEquals(newArrayList(changeLogForDiffFinished), foundPage.getContent());
    }

    @Test
    public void shouldSearchAllCombinations() {
        final Page<ReportingCuttingYieldModelChangeLog> foundPage = cuttingRepository.findAll("user-1",
                newArrayList(FieldType.CREATED),
                finishedProductCode,
                previousDay,
                today,
                page);

        assertEquals(newArrayList(changeLog), foundPage.getContent());
    }

    @Test
    public void shouldNotReturnChangelogForNonPricingModel() {
        final CuttingYieldModel yieldModelNonPricing = yieldModelOne.toBuilder()
                .labor(new BigDecimal("1.11"))
                .finishedProductCost(BigDecimal.valueOf(17.65d))
                .build();
        yieldModelNonPricing.setId(4L);
        final ReportingEvent yieldModelEvent = ReportingEvent.builder()
                .type("YieldModel")
                .timestamp(timestamp)
                .principal("user-2")
                .productCode(finishedProductCode)
                .data(yieldModelNonPricing.asMap(objectMapper)).build();
        yieldModelEvent.setCreatedAt(customerTimestamp);
        final ReportingEvent savedYieldModelEvent = entityManager.persistFlushFind(yieldModelEvent);

        changeLogSecond = ReportingCuttingYieldModelChangeLog.builder()
                .fieldName(FieldType.CREATED)
                .reportingEventId(savedYieldModelEvent.getId())
                .timestamp(savedYieldModelEvent.getTimestamp())
                .userId(savedYieldModelEvent.getPrincipal())
                .activityDate(previousDay)
                .build();
        changeLogSecond.setCreatedAt(customerTimestamp);
        reportingCuttingYieldModelSavedOne.addChangelog(changeLogSecond);
        changeLogLabor = ReportingCuttingYieldModelChangeLog.builder()
                .fieldName(FieldType.LABOR)
                .reportingEventId(savedYieldModelEvent.getId())
                .timestamp(yieldModelEvent.getTimestamp())
                .userId(yieldModelEvent.getPrincipal())
                .activityDate(today)
                .build();
        changeLogLabor.setCreatedAt(customerTimestamp);
        reportingCuttingYieldModelSavedOne.addChangelog(changeLogLabor);
        reportingCuttingYieldModelSavedOne = entityManager.persistFlushFind(reportingCuttingYieldModelSavedOne);

        final Page<ReportingCuttingYieldModelChangeLog> foundPage = cuttingRepository.findAll(null,
                Collections.emptyList(),
                finishedProductCodeDifferent,
                previousDay,
                today,
                page);

        assertEquals(newArrayList(changeLogForDiffFinished), foundPage.getContent());
    }
}
