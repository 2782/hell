package com.sysco.prime.reporting.repository;

import com.sysco.prime.RepositoryTestBase;
import com.sysco.prime.batch.BatchNumber;
import com.sysco.prime.reporting.model.ReportingSourceMeatWip;
import com.sysco.prime.sourceMeat.PublishingSourceMeatWip;
import org.junit.Test;

import java.time.LocalDate;
import java.time.OffsetDateTime;

import static com.sysco.prime.DummyObjectFactory.createLocalDate;
import static com.sysco.prime.DummyObjectFactory.createOffsetDateTime;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

public class ReportingSourceMeatWipRepositoryTest extends RepositoryTestBase<ReportingSourceMeatWip,
        ReportingSourceMeatWipRepository> {

    @Test
    public void shouldRoundtrip() {
        final LocalDate workingDate = createLocalDate();

        final PublishingSourceMeatWip sourceMeatWip = PublishingSourceMeatWip.builder()
                .weight(10d)
                .productCode("1234567")
                .portionRoomCode("A")
                .workingDate(workingDate)
                .build();

        final ReportingSourceMeatWip unsavedSourceMeatWip = ReportingSourceMeatWip.from(sourceMeatWip);

        final ReportingSourceMeatWip readBack = saveAndReadBack(unsavedSourceMeatWip);

        assertThat(readBack, is(unsavedSourceMeatWip));
    }
}