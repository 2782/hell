# Prime Operation-support and Production

Information on scripts and details for production operation support.

## Application endpoints

### Environments

Use these Prime API endpoints for the "prime-api-url-base" argument: 

* Local - http://localhost:8081 - Note, the `http://` prefix is required
* Dev - https://prime-dev.aws.na.sysco.net
* QA - https://prime-qa.aws.na.sysco.net
* Staging - https://prime-stg.aws.na.sysco.net
* Prod - Not yet defined

One symptom in Python scripts of leaving out the `http://` or `https://` prefix is:
```
    raise InvalidSchema("No connection adapters were found for '%s'" % url)
requests.exceptions.InvalidSchema: No connection adapters were found for 'localhost:8081/api/yield-models'
```

### Health

## Run scripts

To run against QA and higher envs, you need to be "logged in" to Prime:

1. In your web browser, go to the Prime UI for the target env.
2. Follow the steps to login with Sysco, and be redirected to Prime.
3. Use your browser tools to examine the cookies for Prime. (In Chrome Dev Tools, go to the Application tab, and then select Cookies from the sidebar)
4. Copy the `SESSION` cookie value.
5. For curl, use `-b SESSION=<cookie value>`; for scripts, follow their instructions for using cookies.

### Bulk loading yield models

See [README](script/python/README.md).
