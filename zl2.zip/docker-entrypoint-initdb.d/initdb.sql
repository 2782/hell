CREATE DATABASE "prime-test";
CREATE DATABASE "prime-integrationtest";
GRANT ALL PRIVILEGES ON DATABASE prime to "primeApp";
GRANT ALL PRIVILEGES ON DATABASE "prime-test" to "primeApp";
GRANT ALL PRIVILEGES ON DATABASE "prime-integrationtest" to "primeApp";
