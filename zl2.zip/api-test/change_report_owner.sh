#!/usr/bin/env bash

# should run this shell script to change the report folder owner, so that CI pipeline could clear the work directory


PROJECT_HOME=$(cd `dirname $0`/../ && pwd)

sudo chown -R go:go ${PROJECT_HOME}/api-test