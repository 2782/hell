#!/usr/bin/env bash

export PS4='+${BASH_SOURCE}:${LINENO}:${FUNCNAME[0]:+${FUNCNAME[0]}():} '

set -e
set -u
set -o pipefail

db_type="local"
PROJECT_HOME=$(cd `dirname $0`/../ && pwd)

parent_dir="${0%/*}"   # TODO: This is actually quite tricky; a full answer deals with many corner cases

function load-psql-file {
    file="$1"
    psql -v 'ON_ERROR_STOP=1' prime -f "$parent_dir/resources/database/$file"
}

function delete-data {
    load-psql-file delete_data.sql
}

function load-data {
    load-psql-file insert_data.sql
}

function load-real-data {
    load-data  # Synonym
}

function delete-data-docker {
    docker run --network prime-api_default \
        --link prime-api_db_1:postgres \
        -v ${PROJECT_HOME}/api-test/resources:/opt/app/resources \
        --rm postgres:9.6 \
        sh -c 'su postgres &  \
                PGPASSWORD=password psql -h postgres -p 5432 -U primeApp prime \
                -f /opt/app/resources/database/delete_data.sql'
}

function load-data-docker {
    docker run --network prime-api_default \
        --link prime-api_db_1:postgres \
        -v ${PROJECT_HOME}/api-test/resources:/opt/app/resources \
        --rm postgres:9.6 \
        sh -c 'su postgres &  \
                PGPASSWORD=password psql -h postgres -p 5432 -U primeApp prime \
                -f /opt/app/resources/database/insert_data.sql'
}


function reset-data {
    delete-data
    load-data
}

function reset-to-real-data {
    delete-data
    load-real-data
}

function reset-data-docker {
    delete-data-docker
    load-data-docker
}

function print-usage {
    echo "Usage: $0 [-h] <COMMAND>"
}

function print-help {
    print-usage
    cat <<EOH

Flags:
   -h   Print help and exit

Commands:
   load   [docker]  Loads all data and exits
   delete [docker]  Deletes all data, preserving schema, and exits
   reset  [docker]  Deletes and reloads all data and exits
EOH
}

while getopts :h opt
do
    case $opt in
    h | help ) print-help ; exit 0 ;;
    * ) print-usage >&2 ; exit 2 ;;
    esac
done
shift $((OPTIND - 1))

case $# in
    1 ) command=$1 ;;
    2 ) command=$1
        db_type=$2 ;;
    * ) print-usage >&2 ; exit 2 ;;
esac

case "$command" in
    load | delete | reset | reset-to-real) ;;
    * ) print-usage >&2 ; exit 2 ;;
esac


if [ $db_type = "docker" ]; then
    $command-data-$db_type
else
    $command-data
fi
