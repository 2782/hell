-- @formatter:off
SET TIME ZONE 'America/Chicago';

INSERT INTO systemconfig
VALUES
(1, 'GROUP_WEEKEND_OPEN_PORTION_ROOM', 'saturday', true, 'allow saturday to open portion room', now(), null),
(2, 'GROUP_WEEKEND_OPEN_PORTION_ROOM', 'sunday', true, 'allow sunday to open portion room', now(), null);

INSERT INTO primeUserDetails(id, userId, role, createdAt, updatedAt) VALUES
(9999999999, 'user-1', 'ROLE_ADMIN', NOW(), null);

INSERT INTO profile(id, createdAt, updatedAt, name, plantNumber, address, city, state, zipCode, establishmentNumber, vendorShipFrom, sequenceNumber)
VALUES
(21421400211, NOW(), NOW(), 'Buckhead Dallas', '332', '4216 Mint Way', 'Dallas', 'TX', '75237', '2213D', 194, 1);

INSERT INTO customer(id, customerCode, name, lineOne, lineTwo, city, country, postalCode, createdat, updatedat, broadline, type)
VALUES
-- This customer represents PRIME as a customer to SUS. Please do not remove this.
(1965, '000005', 'Prime', '1390 Enclave Parkway', 'Houston, TX 77077-2099', 'Houston', 'TX', '75835', NOW(), NOW(), false, 'I'),

-- Real PRIME customers:
(3136, '000170', 'SANDESHA’S NOM NOMS','1390 Enclave Pkwy', '', 'Houston', 'TX', '77077', NOW(), NOW(), false, 'R'),
(3137, '050340', 'MOLLY’S GOOD FOOD','808 HIGHWAY 7', '',        'Silver Lake', 'MN', '55381', NOW(), NOW(), false ,'R'),
(3138, '137851', 'Sysco North Texas', '800 Trinity Drive', '', 'Lewisville', 'TX', '75056', NOW(), NOW(), true,'R'),
(3139, '142679', 'Sysco Knoxville, LLC', '900 Tennessee Avenue', '', 'Knoxville', 'TN', '37921', NOW(), NOW(), true,'R'),
(3140, '142687', 'Sysco Grand Rapids, LLC', '3700 Sysco Court SE', '', 'Grand Rapids', 'MI', '49512', NOW(), NOW(), true,'R'),
(3141, '142695', 'Sysco Nashville', '1 Hermitage Plaza', '', 'Nashville', 'TN', '37209', NOW(), NOW(), true,'R'),
(3142, '142703', 'Sysco Detroit', '41600 Van Born Rd', '', 'Canto', 'MI', '48188', NOW(), NOW(), true,'R'),
(3143, '142711', 'Sysco Indianapolis', '4000 W 62nd St', '', 'Indianapolis', 'IN', '46268', NOW(), NOW(), true,'R'),
(3144, '142729', 'Sysco Cincinnati', '10510 Evendale Dr', '', 'Cincinnati', 'OH', '45241', NOW(), NOW(), true,'R'),
(3145, '142737', 'Sysco Cleveland, Inc.', '4747 Grayton Road', '', 'Cleveland', 'OH', '44135', NOW(), NOW(), true,'R'),
(3146, '142745', 'Sysco Memphis', '4359 B.F. Goodrich Boulevard', '', 'Memphis', 'TN', '38118', NOW(), NOW(), true,'R'),
(3147, '142752', 'Sysco Pittsburgh, LLC', '1 Whitney Dr', '', 'Zelienople', 'PA', '16063', NOW(), NOW(), true,'R'),
(3148, '183715', 'Burger Time West', '1011 S Robert St', '', 'West Saint Paul', 'MN', '55118', NOW(), NOW(), false,'R'),
(3149, '010976', 'Burger Time Moorhead', '1620 1st Ave N', '', 'Moorhead', 'MN', '56560', NOW(), NOW(), false,'R'),
(3150, '852509', 'Garden Steakhouse', '2007 US 71', '', 'Jackson', 'MN', '56143', NOW(), NOW(), false,'R'),
(3151, '573782', 'Tommy''s Central St Steakhouse', '8 W Central St', '', 'Springfield', 'MN', '56087', NOW(),NOW(), false,'R'),
(3152, '617357', 'George''s Fine Steaks', '301 N Minnesota St', '', 'New Ulm', 'MN', '56073', NOW(), NOW(), false,'R'),
(3153, '020402', 'Cowboy Jacks Saloon', '126 North 5th', '', 'St Minneapolis', 'MN', '55403', NOW(), NOW(), false,'R');


INSERT INTO portionroom(id, code, description, createdat, updatedat, portionroomstatus, roomtype, customerNumber, approved)
VALUES
       (2142140210, 'M', 'COSTING',   NOW(), NOW(), 'OPENED', 'COSTING', null, FALSE),
       (2142140211, 'A', 'ROOM A',   NOW(), NOW(), 'CLOSED', 'CUTTING',  '000005', FALSE),
       (2142140212, 'B', 'ROOM B',   NOW(), NOW(), 'CLOSED', 'CUTTING',  '000007', FALSE),
       (2142140213, 'C', 'ROOM C',   NOW(), NOW(), 'CLOSED', 'CUTTING',  '000007', FALSE),
       (2142140214, 'D', 'GRINDING', NOW(), NOW(), 'CLOSED', 'GRINDING', '000005',  FALSE);

INSERT INTO batchnumber(id, portionRoomId, lastBatchNumber, createdat, updatedat)
VALUES
       (2102100211, 2142140211, 0, NOW(), NOW()),
       (2102100212, 2142140212, 0, NOW(), NOW()),
       (2102100213, 2142140213, 0, NOW(), NOW()),
       (2102100214, 2142140214, 0, NOW(), NOW());

INSERT INTO station(id, createdat, updatedat, name, stationcode, roomid, printer, retailPrinter, type, userid)
VALUES
       (21421402141, NOW(), NOW(), 'JOHN',    90, 2142140211, '10.242.137.180', '', 'PRODUCTION', 'user-1'),
       (21421402142, NOW(), NOW(), 'ALEX',    91, 2142140211, '10.242.137.180', '', 'PRODUCTION', 'user-2'),

       (21421402143, NOW(), NOW(), 'SALLY',   92, 2142140212, '10.242.137.180', '', 'PRODUCTION', 'user-3'),
       (21421402144, NOW(), NOW(), 'JESSICA', 93, 2142140212, '10.242.137.180', '', 'PRODUCTION', 'user-4'),

       (21421402145, NOW(), NOW(), 'AJAY',    94, 2142140213, '10.242.137.180', '', 'PRODUCTION', 'user-5'),

       (21421402146, NOW(), NOW(), 'PABLO',   95, 2142140214, '10.242.137.180', '', 'PRODUCTION', 'user-6'),
       (21421402147, NOW(), NOW(), 'MATT',    96, 2142140214, '10.242.137.180', '', 'PRODUCTION', 'user-7'),
       (21421402148, NOW(), NOW(), 'ROBERT',  97, 2142140214, '10.242.137.180', '', 'PRODUCTION', 'user-8'),

       (21421402149, NOW(), NOW(), 'JOSHUA',  98, 2142140211, '10.242.137.180', '10.242.137.182', 'PACKOFF', 'pack-off-user-1'),
       (21421402150, NOW(), NOW(), 'STEVEN',  99, 2142140214, '10.242.137.180', '10.242.137.182', 'PACKOFF', 'pack-off-user-2'),
       (21421402151, NOW(), NOW(), 'JASHAAD', 89, 2142140213, '10.242.137.180', '10.242.137.182', 'PACKOFF', 'pack-off-user-3');

INSERT INTO portionroomtable(id, createdat, updatedat, stationid, tablecode, tabledescription, tableOpenTime,
tableCloseTime, poundsPerHour)
VALUES
       (31421402141, NOW(), NOW(), 21421402141, 90, 'BEEF', '08:00:00', '16:00:00', 100),
       (31421402142, NOW(), NOW(), 21421402142, 91, 'STEAK', '08:00:00', '16:00:00', 100),
       (31421402143, NOW(), NOW(), 21421402143, 92, 'FAJITA', '08:00:00', '16:00:00', 100),
       (31421402144, NOW(), NOW(), 21421402144, 93, 'CHICKEN', '08:00:00', '16:00:00', 100),
       (31421402145, NOW(), NOW(), 21421402145, 94, 'SAUSAGE', '08:00:00', '16:00:00', 100),
       (31421402146, NOW(), NOW(), 21421402146, 95, 'VMAG', '08:00:00', '16:00:00', 100),
       (31421402147, NOW(), NOW(), 21421402147, 96, 'F6', '08:00:00', '16:00:00', 100),
       (31421402148, NOW(), NOW(), 21421402148, 97, 'F19', '08:00:00', '16:00:00', 100);


INSERT INTO product(id, code, description, productOutput, subPrimalCode, subPrimalDescription, tableid, createdat, updatedat,
                    category, minweight, maxweight, weightPerBox, piecespercase,
                    portionsize, usdaGrade, instructions, tenderform,
                    grindsize, packinstruction, casesPerTray, storageCode, ingredientsStatement, vendorNumber,
                    specialDiet, gtin, shipSplitOnly)
VALUES
(10, '4391102', 'STEAK BEEF SIRLOIN FAJ CUT',     'FINISHED', '100', 'BEEF, CARCASS', 31421402143, NOW(), NOW(), 'FIXED', 9.00, 9.00, 10.00, 2, '5 LB', 'Prime', '', FALSE, NULL, NULL, NULL, 'C', NULL, NULL, 'KOSHER', 98911945008, false),
(11, '3401581', 'SAUSAGE CHORIZO COOKED FRZN TB', 'FINISHED', '418', 'PORK TRIMMINGS', 31421402145, NOW(), NOW(), 'CATCH', 9.00, 11.00, 10.00, 4, '2.5 LB', 'Prime', '', FALSE, NULL, NULL, NULL, 'F', NULL, NULL, 'NONE', 90734730505667, false),
(12, '4102218', 'BEEF STEAK T-BONE CLS',          'FINISHED', '102', 'BEEF FOREQUARTER', 31421402142, NOW(), NOW(), 'FIXED',10.44, 10.44, 10.50, 12, '14 OZ', 'Prime', '', FALSE, NULL, NULL, NULL, 'C', 'Lorem ipsum dolor sit amet, ' ||'consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et ' ||'magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium '||'quis, sem. Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. ' ||'In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo. Nullam dictum felis eu pede mollis pretium. ' ||'Integer tincidunt. Cras dapibus. Vivamus elementum semper nisi. Aenean vulputate eleifend tellus. Aenean leo ' ||'ligula, porttitor eu, consequat vitae, eleifend ac, enim. Aliquam lorem ante, dapibus in, viverra quis, feugiat a, tellus', NULL, 'NONE', 98911911072, false),
(13, '4102246', 'BEEF STEAK T-BONE CLS',          'FINISHED', '114C', 'BEEF CHUCK, SHOULDER CLOD TRIMMED',31421402142, NOW(), NOW(), 'FIXED', 9.94, 9.94, 10.00, 10, '16 OZ', 'Prime', '', FALSE, NULL, NULL, NULL, 'C',NULL, NULL, 'NONE', 98911911089, false),
(14, '2111148', 'BEEF STEAK T-BONE CH #1174',     'FINISHED', '107', 'BEEF RIB, OVER-PREPARED', 31421402142, NOW(), NOW(),'FIXED', 10.00, 10.00, 10.50, 14, '12 OZ', 'Prime', '', FALSE, NULL, NULL, NULL, 'C', NULL, NULL, 'NONE', 98911011062,false),
(15, '2111173', 'BEEF STEAK T-BONE CH #1174',     'FINISHED', '155', 'BEEF HINDQUARTER', 31421402142, NOW(), NOW(), 'FIXED',10.44, 10.44, 10.50, 12, '14 OZ', 'Prime', '', FALSE, NULL, NULL, NULL, 'C', NULL, NULL, 'NONE', 98911011109, false),
(16, '2111203', 'BEEF STEAK T-BONE CH #1174',     'FINISHED', '109B', 'BEEF RIB, BLADE MEAT', 31421402142, NOW(),  NOW(), 'FIXED', 9.94, 9.94, 10.50, 10, '16 OZ', 'Prime', '', FALSE, NULL, NULL, NULL, 'C', NULL, NULL, 'NONE', 98911011116, false),
(17, '2111245', 'BEEF STEAK T-BONE CH #1174',     'FINISHED', '109A', 'BEEF RIB, ROAST-READY, SPECIAL', 31421402142, NOW(),NOW(), 'FIXED', 9.94,  9.94, 10.00, 8,  '20 OZ', 'Prime', '', FALSE, NULL, NULL, NULL, 'C', NULL, NULL, 'NONE', 98911011154, false),
(18, '4181840', 'BEEF GROUND BULK 80/20',         'FINISHED', '109', 'BEEF RIB, ROAST-READY', 31421402148, NOW(),  NOW(), 'FIXED', 19.00,  9.94, 10.00, 4, '5 LB', 'Prime', '', FALSE, 'THREE_THIRTY_TWO', 'FRESH,GAS', 3,  'C', NULL, NULL, 'NONE', 98911135867, false),
(19, '4228393', 'BEEF GROUND BULK 80/20',         'FINISHED', '109D', 'BEEF RIB, ROAST-READY COVER OFF, SHORT CUT ', 31421402148, NOW(), NOW(), 'FIXED', 19.00, 19.00, 20.00, 4, '5 LB', 'Prime', '', FALSE, 'THREE_THIRTY_TWO', 'FRESH,' ||'GAS', 3, 'C', NULL, NULL, 'NONE', 98911133863, false),
(20, '4269781', 'BEEF GROUND 80/20 CHUCK BULK',   'FINISHED', '110', 'BEEF RIB, ROAST-READY- BONELESS', 31421402148, NOW(),NOW(), 'FIXED', 19.00, 19.00, 20.00, 4, '5 LB', 'Prime', '', FALSE, 'THREE_THIRTY_TWO', 'FRESH,GAS', 3, 'C', NULL, NULL, 'NONE', 70000000000009, false),
(21, '4554988', 'BEEF PATTY RND 80/20',           'FINISHED', '112A', 'BEEF RIB, RIBEYE LIPON', 31421402148, NOW(),NOW(), 'FIXED', 11.94, 11.94, 20.00, 24,  '8 OZ', 'Prime', '', FALSE, 'THREE_THIRTY_TWO', 'FRESH,GAS', 3,'C', NULL, NULL, 'NONE', 98911133733, false),
(22, '7028918', 'BEEF PATTY RND 80/20',           'FINISHED', '112', 'BEEF RIB, RIBEYE ROLL', 31421402148, NOW(),NOW(), 'FIXED', 11.93,  11.93, 12.00, 36, '5.33 OZ', 'Prime', '', FALSE, 'THREE_THIRTY_TWO', 'FRESH,GAS', 3, 'C', NULL, NULL, 'NONE', 98911135737, false),
(23, '2200238', 'BEEF PATTY CHUCK ROUND',         'FINISHED', '112C', 'BEEF RIB, RIBEYE', 31421402147, NOW(), NOW(),'FIXED',10.44, 10.44, 11.99, 24, '7 OZ', 'Prime', '', FALSE, 'THREE_THIRTY_TWO', 'FRESH,GAS', 3, 'C', NULL, NULL, 'NONE', 98911133351, false),
(24, '3450034', 'BEEF PATTY CHUCK PUCK',          'FINISHED', '113', 'BEEF CHUCK, SQUARE-CUT', 31421402147, NOW(),NOW(), 'FIXED', 11.94,  11.94, 10.50, 24, '8 OZ', 'Prime', '', FALSE, 'THREE_THIRTY_TWO', 'FRESH,GAS', 3, 'C',NULL, NULL, 'NONE', 98911133429, false),
(25, '3655729', 'BEEF PATTY CHUCK SLIDER',        'FINISHED', '114', 'BEEF CHUCK, SHOULDER CLOD', 31421402147, NOW(), NOW(),'FIXED', 11.94, 11.94, 12.00, 96, '2 OZ', 'Prime', '', FALSE, 'THREE_THIRTY_TWO', 'FRESH,GAS', 3, 'C',NULL, NULL, 'NONE', 98911135454, false),
(26, '3655798', 'BEEF PATTY CHUCK 5:1 RND',       'FINISHED', '115', 'BEEF CHUCK, SQUARE-CUT, BONELESS',31421402147, NOW(), NOW(), 'FIXED', 9.54, 9.54, 12.00, 48, '3.2 OZ', 'Prime', '', FALSE,'THREE_THIRTY_TWO', 'FRESH,GAS', 3, 'C', NULL, NULL, 'NONE',98911135157, false),
(27, '4406684', 'BEEF PATTY CHUCK RND',           'FINISHED', '116A', 'BEEF CHUCK, CHUCK ROLL', 31421402147, NOW(),NOW(), 'FIXED', 9.95, 9.95, 9.60, 60, '2.67 OZ', 'Prime', '', FALSE, 'THREE_THIRTY_TWO', 'FRESH,GAS', 3,'C', NULL, NULL, 'NONE', 98911132187, false),
(28, '2184768', 'BEEF PATTY CHUCK NAT',           'FINISHED', '117', 'BEEF FORESHANK', 31421402146, NOW(), NOW(),'FIXED', 11.94, 11.94, 10.01, 24, '8 OZ', 'Prime', '', FALSE, 'THREE_THIRTY_TWO', 'FRESH,GAS', 3, 'C',NULL, NULL, 'NONE', 20630881381147, false),
(29, '3616689', 'BEEF PATTY CHUCK NAT SHAPE',     'FINISHED', '120', 'BEEF BRISKET, DECKLE-OFF, BONELESS',31421402146, NOW(), NOW(), 'FIXED', 11.94, 11.94, 12.00, 24, '8 OZ', 'Prime', '', FALSE,'THREE_THIRTY_TWO', 'FRESH,GAS', 3, 'C', NULL, NULL, 'NONE', 98911133641, false),
(30, '3616706', 'BEEF PATTY CHUCK NAT',           'FINISHED', '120A', 'BEEF BRISKET, FLAT CUT, BONELESS',31421402146, NOW(),NOW(), 'FIXED', 11.94, 11.94, 12.00, 24, '8 OZ', 'Prime', '', FALSE,'THREE_THIRTY_TWO', 'FRESH,GAS', 3, 'C', NULL, NULL, 'NONE', 98911133221, false),
(31, '3616733', 'BEEF PATTY CHUCK NAT',           'FINISHED', '120B', 'BEEF BRISKET, POINT CUT, BONELESS',31421402146, NOW(), NOW(), 'FIXED', 11.94, 11.94, 12.00, 48, '4 OZ', 'Prime', '', FALSE,'THREE_THIRTY_TWO', 'FRESH,GAS', 3, 'C', NULL, NULL, 'NONE', 98911133269, false),
(32, '3655436', 'BEEF PATTY CHUCK NAT SHAPE',     'FINISHED', '121', 'BEEF PLATE, SHORT PLATE', 31421402146, NOW(), NOW(), 'FIXED', 11.93, 11.93, 12.00,  36, '5.33 OZ', 'Prime', '', FALSE, 'THREE_THIRTY_TWO', 'FRESH,GAS', 3, 'C', NULL, NULL, 'NONE', 98911135256, false),
(33, '3655851', 'BEEF PATTY CHUCK NAT SHAPE',     'FINISHED', '121C', 'BEEF PLATE, OUTSIDE SKIRT', 31421402146, NOW(), NOW(), 'FIXED', 11.94, 11.94, 11.99, 24, '8 OZ', 'Prime', '', FALSE, 'THREE_THIRTY_TWO', 'FRESH,GAS', 3, 'C',NULL, NULL,'NONE', 98911135355, false),
(34, '3655883', 'BEEF PATTY CHUCK NAT SHAPE',     'FINISHED', '123', 'BEEF SHORT RIBS', 31421402146, NOW(), NOW(),'FIXED', 10.44, 10.44, 12.00, 24, '7 OZ', 'Prime', '', FALSE, 'THREE_THIRTY_TWO', 'FRESH,GAS', 3, 'C', NULL, NULL, 'NONE', 98911135409, false),
(35, '3655891', 'BEEF PATTY CHUCK NAT',           'FINISHED', '124', 'BEEF RIB, BACK RIBS', 31421402146, NOW(), NOW(),'FIXED', 11.94, 11.94, 10.50, 24, '8 OZ', 'Prime', '', FALSE, 'THREE_THIRTY_TWO', 'FRESH,GAS', 3, 'C', NULL, NULL, 'NONE', 98911135102, false),
(36, '3656031', 'BEEF PATTY CHUCK NAT',           'FINISHED', '124A', 'BEEF RIB, BACK RIB, RIB FINGERS',31421402146, NOW(), NOW(), 'FIXED', 11.93, 11.93, 12.00,  36, '5.33 OZ', 'Prime', '', FALSE,'THREE_THIRTY_TWO', 'FRESH,GAS', 3, 'C', NULL, NULL, 'NONE', 98911135058, false),
(37, '4083533', 'BEEF PATTY CHUCK NAT',           'FINISHED', '123A', 'BEEF SHORT PLATE, SHORT RIBS, TRIMMED',31421402146, NOW(), NOW(), 'FIXED', 11.93, 11.93, 11.99, 36, '5.33 OZ', 'Prime', '', FALSE,'THREE_THIRTY_TWO', 'FRESH,GAS', 3, 'C', NULL, NULL, 'NONE', 98911133382, false),
(38, '4824250', 'BEEF GROUND CHUCK BRSKT',        'FINISHED', '123B', 'BEEF RIB, SHORT RIBS, TRIMMED', 31421402147,NOW(), NOW(), 'FIXED', 19.00,  19.00,  11.99, 4, '5 LB', 'Prime', '', FALSE, 'THREE_THIRTY_TWO','FRESH,GAS', 3, 'C', NULL, NULL, 'NONE', 98911133085, false),
(39, '4872341', 'BEEF PATTY CHUCK BRSKT RND',     'FINISHED', '123C', 'BEEF RIB, SHORT RIBS', 31421402147, NOW(),NOW(), 'FIXED', 11.19, 11.19, 20.00,  30, '6 OZ', 'Prime', '', FALSE, 'THREE_THIRTY_TWO', 'FRESH,GAS', 3, 'C',NULL, NULL, 'NONE', 98911133030, false),
(40, '7031243', 'BEEF PATTY CHUCK BRSKT PUCK',    'FINISHED', '123D', 'BEEF SHORT RIBS, BONELESS', NULL, NOW(), NOW(), 'FIXED', 11.94, 11.94, 11.25, 48, '4 OZ', 'Prime', '', FALSE, 'THREE_THIRTY_TWO', 'FRESH,GAS', 3, 'C', NULL,NULL, 'NONE', 98911135065, false),
(41, '0096505', 'BEEF STEW MEAT FRZN',            'FINISHED', '130', 'BEEF CHUCK, SHORT RIBS', 31421402142, NOW(),NOW(), 'FIXED', 9.00,   9.00,  12.00, 2, '5 LB', 'Prime', '', FALSE, NULL, NULL, NULL, 'F', NULL, NULL,'NONE', 10742158623331, false),
(42, '0565109', 'STEAK STRIP E/E',                'FINISHED', '130A', 'BEEF CHUCK, SHORT RIBS, BONELESS',31421402142, NOW(),NOW(), 'FIXED', 10.44, 10.44, 10.00,  28, '6 OZ', 'Prime', '', FALSE, NULL, NULL, NULL, 'C',NULL, NULL, 'NONE', 10742158637901, false),
(43, '4182307', 'BEEF STEAK STRIP CC',            'FINISHED', '134', 'BEEF BONES', 31421402142, NOW(), NOW(),'FIXED', 10.44,10.44, 10.50, 12, '14 OZ', 'Prime', '', FALSE, NULL, NULL, NULL, 'C', NULL, NULL, 'NONE',98911911454, false),
(44, '3052428', 'BEEF STEAK CUBES 1 135A',        'FINISHED', '135', 'DICED BEEF', 31421402142, NOW(), NOW(),'FIXED', 9.00,9.00,  10.50, 2, '5 LB', 'Prime', '', FALSE, NULL, NULL, NULL, 'C', NULL, NULL, 'HALAL',70000000000009, false),
(45, '1961172', 'CHICKEN BREAST BNLS BRD WINGS',  'FINISHED', 'P1010', 'CHICKEN BREAST QUARTER', 31421402144, NOW(),NOW(), 'FIXED', 9.00, 9.00,  10.00, 2, '5 LB', 'Prime', '', FALSE, NULL, NULL, NULL, 'C', NULL, NULL,'NONE', 98911414559, false),
(46, '7074792', 'CHICKEN CVP 8PC CUT FRSH TRIM',  'FINISHED', 'P1005', 'CHICKEN 8-PIECE CUT-UP TRADITIONAL', 31421402144, NOW(), NOW(), 'CATCH', 41.00, 43.00, 10.00, 12, '3.5 LB', 'Prime', '', FALSE, NULL, NULL, NULL, 'C', NULL, NULL, 'NONE', 90074865807664, false),
(47, '3260878', 'BEEF PECTORAL FZN',              'SOURCE', '135A', 'BEEF FOR STEWING', 31421402142, NOW(), NOW(), 'CATCH', NULL, NULL, 42.00, 1, '70 LB', 'Prime', '', FALSE, NULL, NULL, NULL, 'F', NULL, NULL, 'NONE', 70000000000009, false),
(48, '7203474', 'CHICKEN CVP BRST B/S RDM JUMBO', 'SOURCE', 'P1011', 'CHICKEN BREAST QUARTER W/OUT WING', NULL, NOW(),NOW(), 'FIXED', NULL, NULL, 70.00, 4, '10 LB', 'Prime', '', FALSE, NULL, NULL, NULL, 'C', NULL, NULL, 'NONE', 74865447638, false),
(49, '5807662', 'PORK GROUND 80/20 FINE',         'SOURCE', '400', 'PORK CARCASS  - grade required', NULL, NOW(), NOW(),'FIXED', NULL, NULL, 40.00, 2, '5 LB', 'Prime', '', FALSE, NULL, NULL, NULL, 'C', NULL, NULL, 'NONE', 734730142005, false),
(50, '2857102', 'BEEF SHORT LOIN CH #174',        'SOURCE', '139', 'BEEF, SPECIAL TRIM, BONELESS', NULL, NOW(), NOW(),'CATCH', NULL, NULL, 10.00, 1, '20#AVG', 'Prime', '', FALSE, NULL, NULL, NULL, 'C', NULL, NULL, 'NONE', 90098911911051, false),
(51, '2020766', 'BEEF STRIP LOIN 0X1 CH 180',     'SOURCE', '140', 'BEEF, HANGING TENDER', NULL, NOW(), NOW(), 'CATCH', NULL, NULL, 20.00, 6, '11#AVG', 'Prime', '', FALSE, NULL, NULL, NULL, 'C', NULL, NULL, 'NONE', 90027182001758, false),
(52, '2963082', 'BEEF TRIM TESTED 80/20 COMBO',   'SOURCE', '158', 'BEEF ROUND, PRIMAL', NULL, NOW(), NOW(), 'CATCH', NULL, NULL, 66.00, 1, '2000#', 'Prime', '', FALSE, NULL, NULL, NULL, 'C', NULL, NULL, 'NONE', 70000000000009, false),
(53, '2962845', 'BEEF CHUCK HEREFORD COMBO',      'SOURCE', '158A', 'BEEF ROUND, DIAMOND-CUT', NULL, NOW(), NOW(), 'CATCH', NULL, NULL, 2000.00, 1, '2000#', 'Prime', '', FALSE, NULL, NULL, NULL, 'C', NULL, NULL, 'NONE', 70000000000009, false),
(54, '2423501', 'BEEF CHUCK TRIM FRSH',           'SOURCE', '159', 'BEEF ROUND, PRIMAL, BONLESS', NULL, NOW(), NOW(), 'CATCH', NULL, NULL, 2000.00, 4, '15#AVG', 'Prime', '', FALSE, NULL, NULL, NULL, 'C', NULL, NULL, 'NONE', 60613160201, false),
(55, '3199233', 'BEEF BRISKET WHL',               'SOURCE', '158A', 'BEEF ROUND, DIAMOND-CUT', NULL, NOW(), NOW(), 'CATCH', NULL, NULL, 60.00, 7, '10#AVG', 'Prime', '', FALSE, NULL, NULL, NULL, 'C', NULL, NULL, 'NONE', 90630308601208, false),
(56, '1663364', 'BEEF TRIMMING 50/50 FRZN',       'SOURCE', '159', 'BEEF ROUND, PRIMAL, BONLESS', NULL, NOW(), NOW(), 'FIXED', NULL, NULL, 70.00, 1, '60#AVG', 'Prime', '', FALSE, NULL, NULL, NULL, 'C', NULL, NULL,'NONE', 70000000000009, false),
(57, '2536993', 'VEAL BONE',                      'BYPRODUCT_ONLY', null, null, 31421402142, NOW(), NOW(), 'CATCH', 1.00, 10.00, 60.00, 1, '50 LB', 'Prime', '', FALSE, NULL, NULL, NULL, NULL, NULL, NULL, 'NONE', 70000000000009, false),
(58, '2111011', 'BEEF INEDIBLE SUET',             'BYPRODUCT_ONLY', null, null, 31421402142, NOW(), NOW(), 'CATCH', 1.00, 10.00, 50.00, 1, '50#AVG', 'Prime', '', FALSE, NULL, NULL, NULL, NULL, NULL, NULL, 'NONE', 70000000000009, false),
(60, '3347632', 'BEEF SKIRT INSIDE FRZN',         'SOURCE', '139', 'BEEF, SPECIAL TRIM, BONELESS', NULL, NOW(), NOW(), 'FIXED', NULL, NULL,  50.00, 1, '20#AVG', 'Prime', '', FALSE, NULL, NULL, NULL, 'F', NULL, NULL, 'NONE', 70000000000009, false),
(61, '3126152', 'BEEF SKIRT INSIDE',              'SOURCE', '140', 'BEEF, HANGING TENDER', NULL, NOW(), NOW(), 'CATCH', NULL, NULL, 10.00, 6, '11#AVG', 'Prime', '', FALSE, NULL, NULL, NULL, 'C', NULL, NULL, 'NONE', 70000000000009, false),
(62, '6964233', 'OIL CANOLA OLIVE 90/10 BLEND',   'SOURCE', '139', 'BEEF, SPECIAL TRIM, BONELESS', NULL, NOW(), NOW(), 'FIXED', NULL, NULL,  10.00, 6, '1 GAL', 'Prime', '', FALSE, NULL, NULL, NULL, 'D', NULL, 1188, 'NONE', 39153500853, false),
(63, '4092706', 'SAUCE SOY',                      'SOURCE', '139', 'BEEF, SPECIAL TRIM, BONELESS', NULL, NOW(), NOW(), 'FIXED', NULL, NULL, 10.00, 4, '1 GAL', 'Prime', '', FALSE, NULL, NULL, NULL, 'D', NULL, 204366, 'KOSHER', 10044300126708, false),
(64, '7216286', 'JUICE LEMON',                    'SOURCE', '139', 'BEEF, SPECIAL TRIM, BONELESS', NULL, NOW(), NOW(), 'FIXED', NULL, NULL, 10.00, 4, '1 GAL', 'Prime', '', FALSE, NULL, NULL, NULL, 'D', NULL, 1072, 'NONE', 10041152210319, false),
(65, '5239611', 'SPICE GARLIC POWDER',            'SOURCE', '139', 'BEEF, SPECIAL TRIM, BONELESS', NULL, NOW(), NOW(),'FIXED', NULL, NULL, 10.00, 6, '1 LB', 'Prime', '', FALSE, NULL, NULL, NULL, 'D', NULL, 2341, 'NONE', 10074865202333,false),
(66, '3492610', 'SPICE BASIL LEAVES',             'SOURCE', '139', 'BEEF, SPECIAL TRIM, BONELESS', NULL, NOW(), NOW(), 'FIXED', NULL, NULL, 10.00, 3, '1.75 LB', 'Prime', '', FALSE, NULL, NULL, NULL, 'D', NULL, 2341, 'NONE', 10734730511228, true),
(67, '5935671', 'SPICE PARSLEY FLAKE WHL',        'SOURCE', '139', 'BEEF, SPECIAL TRIM, BONELESS', NULL, NOW(), NOW(), 'FIXED', NULL, NULL, 5.25, 3, '10 OZ', 'Prime', '', FALSE, NULL, NULL, NULL, 'D', NULL, 2341, 'NONE', 10074865312728,true),
(68, '5935689', 'SPICE PEPPER BLK GRND',          'SOURCE', '139', 'BEEF, SPECIAL TRIM, BONELESS', NULL, NOW(), NOW(), 'FIXED', NULL, NULL, 10.00, 3, '5 LB', 'Prime', '', FALSE, NULL, NULL, NULL, 'D', NULL, 2341, 'NONE', 10074865312735,true);

INSERT INTO customerorder(id, createdat, updatedat, customerId, immediateOrder, deliveryMethod, timedWillCallRoutes, orderdate, shipdate, ordernumber, createdby)
VALUES
       (99991, NOW(), NOW(), 3148, FALSE, 'NORMAL' , 'C08', CURRENT_DATE,     CURRENT_DATE,     '00001', 'Filler ' ||
                                                                                                         'value'),
       (99992, NOW(), NOW(), 3148, FALSE, 'NORMAL' , 'C09', CURRENT_DATE + 1, CURRENT_DATE + 1, '00002', 'Filler ' ||
                                                                                                         'value'),
       (99993, NOW(), NOW(), 3149, FALSE, 'NORMAL' , 'C08', CURRENT_DATE + 1, CURRENT_DATE + 1, '00003', 'Filler ' ||
                                                                                                         'value'),
       (99994, NOW(), NOW(), 3149, FALSE, 'NORMAL' , 'C09', CURRENT_DATE,     CURRENT_DATE,     '00004', 'Filler ' ||
                                                                                                         'value'),
       (99995, NOW(), NOW(), 3150, FALSE, 'NORMAL' , 'C11', CURRENT_DATE + 1, CURRENT_DATE + 1, '00005', 'Filler ' ||
                                                                                                         'value'),
       (99996, NOW(), NOW(), 3150, FALSE, 'NORMAL' , 'C12', CURRENT_DATE,     CURRENT_DATE,     '00006', 'Filler ' ||
                                                                                                         'value'),
       (99997, NOW(), NOW(), 3150, FALSE, 'NORMAL' , 'C08', CURRENT_DATE,     CURRENT_DATE,     '00007', 'Filler ' ||
                                                                                                         'value'),
       (99998, NOW(), NOW(), 3150, FALSE, 'NORMAL' , 'C03', CURRENT_DATE + 1, CURRENT_DATE + 1, '00008', 'Filler ' ||
                                                                                                         'value'),
       (999990101001, NOW(), NOW(), 3138 , FALSE , 'NORMAL', 'C09', CURRENT_DATE,    CURRENT_DATE,     '00012',
                      'Filler value'),
       (999990101002, NOW(), NOW(), 3138 , FALSE , 'NORMAL', 'C11', CURRENT_DATE + 1, CURRENT_DATE + 1, '10013',
                      'Filler value'),
       (999990101003, NOW(), NOW(), 3138 , FALSE , 'NORMAL', 'C12', CURRENT_DATE + 2, CURRENT_DATE + 2, '10014',
                      'Filler value'),
       (999990101004, NOW(), NOW(), 3138 , FALSE , 'NORMAL', 'C08', CURRENT_DATE + 3, CURRENT_DATE + 3, '10015',
                      'Filler value'),
       (999990101005, NOW(), NOW(), 3138 , FALSE , 'NORMAL', 'C03', CURRENT_DATE + 4, CURRENT_DATE + 4, '90016',
                      'Filler value'),
       (999990101006, NOW(), NOW(), 3138 , FALSE , 'NORMAL', 'C04', CURRENT_DATE + 5, CURRENT_DATE + 5, '10017',
                      'Filler value'),
       (999990102001, NOW(), NOW(), 3139 ,FALSE , 'NORMAL', 'C09', CURRENT_DATE,    CURRENT_DATE,     '10018',
                      'Filler value'),
       (999990102002, NOW(), NOW(), 3139 ,FALSE , 'NORMAL', 'C08', CURRENT_DATE + 1, CURRENT_DATE + 1, '10019',
                      'Filler value'),
       (999990102003, NOW(), NOW(), 3139 ,FALSE , 'NORMAL', 'C09', CURRENT_DATE + 2, CURRENT_DATE + 2, '10020',
                      'Filler value'),
       (999991124001, NOW(), NOW(), 3139 ,FALSE , 'NORMAL', 'C08', CURRENT_DATE,     CURRENT_DATE,     '00024',
                      'Filler value'),
       (999991124004, NOW(), NOW(), 3139 ,FALSE , 'NORMAL', 'C02', CURRENT_DATE + 3, CURRENT_DATE + 3, '10027',
                      'Filler value'),
       (999991124006, NOW(), NOW(), 3149 ,FALSE , 'NORMAL', 'C08', CURRENT_DATE + 5, CURRENT_DATE + 5, '10029',
                      'Filler value'),
       (999991124007, NOW(), NOW(), 3149 ,FALSE , 'NORMAL', 'C08', CURRENT_DATE + 8, CURRENT_DATE + 8, '10030',
                      'Filler value'),
       (999991124008, NOW(), NOW(), 3149 ,FALSE , 'NORMAL', 'C08', CURRENT_DATE    , CURRENT_DATE    , '10031',
                      'Filler value'),
       (999991124009, NOW(), NOW(), 3149 ,FALSE , 'NORMAL', 'C08', CURRENT_DATE + 1, CURRENT_DATE + 1, '10032',
                      'Filler value'),

       (999991124010, NOW(), NOW(), 3149 ,FALSE , 'NORMAL', 'C09', CURRENT_DATE - 60, CURRENT_DATE - 60, '20033',
                      'Filler value'),
       (999991124011, NOW(), NOW(), 3138 ,FALSE , 'NORMAL', 'C11', CURRENT_DATE - 60, CURRENT_DATE - 60, '20034',
                      'Filler value'),
       (999991124012, NOW(), NOW(), 3139 ,FALSE , 'NORMAL', 'C08', CURRENT_DATE - 30, CURRENT_DATE - 30, '20035',
                      'Filler value'),
       (999991124013, NOW(), NOW(), 3150 ,FALSE , 'NORMAL', 'C03', CURRENT_DATE - 30, CURRENT_DATE - 30, '20036',
                      'Filler value'),
       (999991124014, NOW(), NOW(), 3138 ,FALSE , 'NORMAL', 'C12', CURRENT_DATE - 1, CURRENT_DATE - 1, '12037',
                      'Filler value'),
       (999991124015, NOW(), NOW(), 3149 ,FALSE , 'NORMAL', 'C04', CURRENT_DATE - 1, CURRENT_DATE - 1, '21038',
                      'Filler value');

INSERT INTO lineitem(id, createdat, updatedat, customerOrderId, productId, cutInstruction, packInstruction, unitOfMeasure, quantity, banquetType, lineNumber)
VALUES
       (21402141010001 , NOW(), null,  99991,        10, 'Cutting Instruction for 4391102', 'Packing Instruction for 4391102',          'BOX',   5,   false, 5),
       (21402141010002 , NOW(), null,  99992,        11, 'Cutting Instruction for 3401581', 'Packing Instruction for 3401581',          'BOX',   6,   false, 6),
       (21402141010003 , NOW(), null,  99993,        12, 'Cutting Instruction for 4102218', 'Packing Instruction for 4102218',          'BOX',   7,   false, 7),
       (21402141020001 , NOW(), null,  99994,        13, 'Cutting Instruction for 4102246', 'Packing Instruction for 4102246',          'BOX',   8,   false, 8),
       (21402141020002 , NOW(), null,  99995,        14, 'Cutting Instruction for 2111148', 'Packing Instruction for 2111148',          'BOX',   9,   false, 9),
       (21402141090001 , NOW(), null,  99996,        15, '',                                '',                                         'BOX',   25,  false, 25),
       (21402141090002 , NOW(), null,  99997,        16, '',                                '',                                         'BOX',   32,  false, 32),
       (21402141090003 , NOW(), null,  99998,        17, 'BANQUET IN PIECE',                '',                                         'PIECE', 62,  true,  62),
       (999990101001002, NOW(), null,  999990101002, 10, '',                                '',                                         'BOX',   20,  false, 20),
       (999990101001003, NOW(), null,  999990101003, 11, '',                                '',                                         'BOX',   13,  false, 13),
       (999990101001004, NOW(), null,  999990101004, 12, '',                                '',                                         'BOX',   20,  false, 20),
       (999990101001005, NOW(), null,  999990101005, 13, '',                                '',                                         'BOX',   13,  false, 13),
       (999990101001006, NOW(), null,  999990101006, 14, '',                                '',                                         'BOX',   20,  false, 20),
       (999990101002001, NOW(), null,  999990102001, 15, '',                                'BANQUET ORDER 999990101002001',            'PIECE', 100,  true,  22),
       (999990101002002, NOW(), null,  999990102002, 16, '',                                '',                                         'PIECE', 71,  false, 71),
       (999990101002003, NOW(), null,  999990102003, 17, '',                                '',                                         'PIECE', 22,  false, 22),
       (999991124001001, NOW(), null,  999991124001, 22, 'CUTTING SPEC FOR 7028918',        'PACKING SPEC WITHOUT BANQUET FOR 7028918', 'BOX',   21,  false, 21),
       (999991124001010, NOW(), null,  999991124004, 22, 'CUTTING SPEC FOR 7028918',        'PACKING SPEC WITHOUT BANQUET FOR 7028918', 'BOX',   10,  false, 10),
       (999991124001017, NOW(), null,  999991124006, 29, '',                                '',                                         'BOX',   20,  false, 20),
       (999990101005001, NOW(), null,  999990101001, 10, '',                                '',                                         'BOX',   13,  false, 81),
       (999990101005005, NOW(), null,  999990101001, 11, '',                                '',                                         'BOX',   13,  false, 82),
       (999990101005003, NOW(), null,  999990101001, 12, '',                                '',                                         'BOX',   13,  false, 83),
       (999990101005006, NOW(), null,  999990101001, 13, '',                                '',                                         'BOX',   13,  false, 84),
       (999990101005004, NOW(), null,  999990101001, 14, '',                                '',                                         'BOX',   13,  false, 85),
       (999990101005002, NOW(), null,  999990101001, 15, '',                                '',                                         'BOX',   13,  false, 86),
       (999990101005007, NOW(), null,  999990101001, 16, '',                                '',                                         'BOX',   13,  false, 87),
       (999990101006002, NOW(), null,  999990101001, 17, '',                                '',                                         'BOX',   13,  false, 88),
       (999990101006001, NOW(), null,  999990101001, 22, '',                                '',                                         'BOX',   13,  false, 91),
       (999990101006007, NOW(), null,  999990101001, 29, '',                                '',                                         'BOX',   13,  false, 94),
       (999990101006008, NOW(), null,  999990101004, 33, '',                                '',                                         'BOX',   17,  false, 31),
       (999990101006011, NOW(), null,  999991124007, 33, '',                                '',                                         'BOX',   17,  false, 31),
       (999990101006012, NOW(), null,  999991124008, 33, '',                                '',                                         'PIECE', 50,  false, 31),
       (999990101006013, NOW(), null,  999991124009, 33, '',                                '',                                         'BOX',   9,  false, 31),
       (999990101005014, NOW(), null,  999991124010, 10, 'Cutting Instruction for 4391102', 'Packing Instruction for 4391102',          'BOX',   5,  false, 100),
       (999990101005015, NOW(), null,  999991124010, 11, 'Cutting Instruction for 3401581', 'Packing Instruction for 3401581',          'PIECE',   4,  false, 101),
       (999990101005016, NOW(), null,  999991124010, 12, 'Cutting Instruction for 4102218', 'Packing Instruction for 4102218',          'BOX',   7,  false, 102),
       (999990101005017, NOW(), null,  999991124010, 13, 'BANQUET IN PIECE for 4102246',    'Packing Instruction for 4102246',          'PIECE',   3,  true, 103),
       (999990101005018, NOW(), null,  999991124011, 14, 'Cutting Instruction for 2111148', 'Packing Instruction for 2111148',          'PIECE',   2,  false, 201),
       (999990101005019, NOW(), null,  999991124011, 10, 'Cutting Instruction for 4391102', 'Packing Instruction for 4391102',          'BOX',   4,  false, 202),
       (999990101005020, NOW(), null,  999991124012, 11, 'Cutting Instruction for 3401581', 'Packing Instruction for 3401581',          'BOX',   7,  false, 301),
       (999990101006021, NOW(), null,  999991124012, 12, 'Cutting Instruction for 4102218', 'Packing Instruction for 4102218',          'PIECE',   5,  false, 302),
       (999990101006022, NOW(), null,  999991124012, 13, 'Cutting Instruction for 4102246', 'Packing Instruction for 4102246',          'BOX',   6,  false, 303),
       (999990101006023, NOW(), null,  999991124013, 10, 'Cutting Instruction for 4391102', 'Packing Instruction for 4391102',          'BOX',   2,  false, 401),
       (999990101006024, NOW(), null,  999991124014, 11, 'Cutting Instruction for 3401581', 'Packing Instruction for 3401581',          'BOX',   3,  false, 501),
       (999990101006025, NOW(), null,  999991124014, 12, 'Cutting Instruction for 4102218', 'Packing Instruction for 4102218',          'BOX',   4,  false, 502),
       (999990101006026, NOW(), null,  999991124015, 13, 'BANQUET IN PIECE for 4102246',    'Packing Instruction for 4102246',          'PIECE', 1,  true, 601),
       (999990101006027, NOW(), null,  999991124015, 14, 'Cutting Instruction for 2111148', 'Packing Instruction for 2111148',          'BOX',   4,  false, 602);

INSERT INTO productionOrder(id, createdAt, updatedAt, source, sourceId, qtyToProduce, deliveryDate, status, qtyPacked, tableId, customerOrderId, packInstruction, producingInstruction, unitOfMeasure, qtyToProduceInCases, piecesPerCase, orderType, startProducingAt, productId, purchaseOrderId, productionType, version)
VALUES
  (99000, NOW(), NOW(), 'LINE_ITEM', 999990101005014, 5, CURRENT_DATE - 60, 'CLOSED', 5, 31421402143, 999991124010, 'Packing Instruction for 4391102', 'Cutting Instruction for 4391102', 'BOX', 5, 2, 'STANDARD', CURRENT_DATE - 60, 10, NULL, 'CUTTING', 9),
  (99001, NOW(), NOW(), 'LINE_ITEM', 999990101005015, 4, CURRENT_DATE - 60, 'CLOSED', 4, 31421402145, 999991124010, 'Packing Instruction for 3401581', 'Cutting Instruction for 3401581', 'PIECE', 1, 4, 'STANDARD', CURRENT_DATE - 60, 11, NULL, 'CUTTING', 9),
  (99002, NOW(), NOW(), 'LINE_ITEM', 999990101005016, 7, CURRENT_DATE - 60, 'CLOSED', 7, 31421402142, 999991124010, 'Packing Instruction for 4102218', 'Cutting Instruction for 4102218', 'BOX', 7, 12, 'STANDARD', CURRENT_DATE - 60, 12, NULL, 'CUTTING', 9),
  (99003, NOW(), NOW(), 'LINE_ITEM', 999990101005017, 3, CURRENT_DATE - 60, 'CLOSED', 3, 31421402142, 999991124010, 'Packing Instruction for 4102246', 'BANQUET IN PIECE for 4102246', 'PIECE', 1, 10, 'BANQUET', CURRENT_DATE - 60, 13, NULL, 'CUTTING', 9),

  (99004, NOW(), NOW(), 'LINE_ITEM', 999990101005018, 2, CURRENT_DATE - 60, 'CLOSED', 2, 31421402142, 999991124011, 'Packing Instruction for 2111148', 'Cutting Instruction for 2111148', 'PIECE', 1, 14, 'STANDARD', CURRENT_DATE - 60, 14, NULL, 'CUTTING', 9),
  (99005, NOW(), NOW(), 'LINE_ITEM', 999990101005019, 4, CURRENT_DATE - 60, 'CLOSED', 4, 31421402143, 999991124011, 'Packing Instruction for 4391102', 'Cutting Instruction for 4391102', 'BOX', 4, 2, 'STANDARD', CURRENT_DATE - 60, 10, NULL, 'CUTTING', 9),

  (99006, NOW(), NOW(), 'LINE_ITEM', 999990101005020, 7, CURRENT_DATE - 30, 'CLOSED', 7, 31421402145, 999991124012, 'Packing Instruction for 3401581', 'Cutting Instruction for 3401581', 'BOX', 7, 4, 'STANDARD', CURRENT_DATE - 30, 11, NULL, 'CUTTING', 9),
  (99007, NOW(), NOW(), 'LINE_ITEM', 999990101006021, 5, CURRENT_DATE - 30, 'CLOSED', 5, 31421402142, 999991124012, 'Packing Instruction for 4102218', 'Cutting Instruction for 4102218', 'PIECE', 1, 12, 'STANDARD', CURRENT_DATE - 30, 12, NULL, 'CUTTING', 9),
  (99008, NOW(), NOW(), 'LINE_ITEM', 999990101005022, 6, CURRENT_DATE - 30, 'CLOSED', 6, 31421402142, 999991124012, 'Packing Instruction for 4102246', 'Cutting Instruction for 4102246', 'BOX', 6, 10, 'STANDARD', CURRENT_DATE - 30, 13, NULL, 'CUTTING', 9),

  (99009, NOW(), NOW(), 'LINE_ITEM', 999990101005023, 2, CURRENT_DATE - 30, 'CLOSED', 2, 31421402143, 999991124013, 'Packing Instruction for 4391102', 'Cutting Instruction for 4391102', 'BOX', 2, 2, 'STANDARD', CURRENT_DATE - 30, 10, NULL, 'CUTTING', 9),

  (99010, NOW(), NOW(), 'LINE_ITEM', 999990101005024, 3, CURRENT_DATE - 1, 'PACKED', 3, 31421402145, 999991124014, 'Packing Instruction for 3401581', 'Cutting Instruction for 3401581', 'BOX', 3, 4, 'STANDARD', CURRENT_DATE - 1, 11, NULL, 'CUTTING', 9),
  (99011, NOW(), NOW(), 'LINE_ITEM', 999990101006025, 4, CURRENT_DATE - 1, 'PACKED', 4, 31421402142, 999991124014, 'Packing Instruction for 4102218', 'Cutting Instruction for 4102218', 'BOX', 4, 12, 'STANDARD', CURRENT_DATE - 1, 12, NULL, 'CUTTING', 9),

  (99012, NOW(), NOW(), 'LINE_ITEM', 999990101005026, 1, CURRENT_DATE - 1, 'PACKED', 1, 31421402142, 999991124015, 'Packing Instruction for 4102246', 'BANQUET IN PIECE for 4102246', 'PIECE', 1, 10, 'BANQUET', CURRENT_DATE - 1, 13, NULL, 'CUTTING', 9),
  (99013, NOW(), NOW(), 'LINE_ITEM', 999990101005027, 4, CURRENT_DATE - 1, 'PACKED', 4, 31421402142, 999991124015, 'Packing Instruction for 2111148', 'Cutting Instruction for 2111148', 'BOX', 4, 14, 'STANDARD', CURRENT_DATE - 1, 14, NULL, 'CUTTING', 9);

INSERT INTO sourceMeatOrder(id, cutOrderId, unitOfMeasure, productCode, productDesc, targetProductCode, targetProductDesc, quantity, createdAt, updatedAt, stationId, status, requestedAt, uomOrderNumber, workingDate, roomCode)
VALUES
  (1000, 99002, 'BOX',  '4102218', 'BEEF SHORT LOIN CH #174',         '4102218', 'BEEF STEAK T-BONE CLS',  22.0, CURRENT_DATE - 60, CURRENT_DATE - 60, 21421402142, 'COMPLETED', CURRENT_DATE - 60, 6, CURRENT_DATE - 60, 'A'),
  (1001, 99006, 'BOX',  '3401581', 'BEEF SHORT LOIN CH #174',         '3401581', 'SAUSAGE CHORIZO COOKED FRZN TB',  50.0, CURRENT_DATE - 30, CURRENT_DATE - 30, 21421402145, 'COMPLETED', CURRENT_DATE - 30, 7, CURRENT_DATE - 30, 'C'),
  (1002, 99007, 'PIECE',  '4102218', 'BEEF SHORT LOIN CH #174',         '4102218', 'BEEF STEAK T-BONE CLS',       13.0, CURRENT_DATE - 30, CURRENT_DATE - 30, 21421402142, 'COMPLETED', CURRENT_DATE - 30, 8, CURRENT_DATE - 30, 'A'),
  (1003, 99010, 'BOX',  '5807662', 'BEEF SHORT LOIN CH #174',         '3401581', 'SAUSAGE CHORIZO COOKED FRZN TB',  22.0, CURRENT_DATE - 1, CURRENT_DATE - 1, 21421402145, 'COMPLETED', CURRENT_DATE - 1, 6, CURRENT_DATE - 1, 'C'),
  (1004, NULL, 'BOX', '7074792', 'CHICKEN CVP 8PC CUT FRSH TRIM',  NULL,      NULL,                          25.0, CURRENT_DATE - 60, CURRENT_DATE - 60, 21421402143, 'COMPLETED', CURRENT_DATE - 60, 9, CURRENT_DATE - 60, 'B'),
  (1005, NULL, 'BOX', '1961172', 'CHICKEN BREAST BNLS BRD WINGS',          NULL,      NULL,                          50.0, CURRENT_DATE - 30, CURRENT_DATE - 30, 21421402142, 'COMPLETED', CURRENT_DATE - 30,  10, CURRENT_DATE - 30, 'A'),

  (1006, 99002, 'BOX',  '4102218', 'BEEF SHORT LOIN CH #174',         '4102218', 'BEEF STEAK T-BONE CLS',  22.0, CURRENT_DATE - 60, CURRENT_DATE - 60, 21421402142, 'COMPLETED', CURRENT_DATE - 60, 6, CURRENT_DATE - 60, 'A'),
  (1007, 99006, 'BOX',  '3401581', 'BEEF SHORT LOIN CH #174',         '3401581', 'SAUSAGE CHORIZO COOKED FRZN TB',  50.0, CURRENT_DATE - 30, CURRENT_DATE - 30, 21421402145, 'COMPLETED', CURRENT_DATE - 30, 7, CURRENT_DATE - 30, 'C'),
  (1008, 99007, 'PIECE',  '4102218', 'BEEF SHORT LOIN CH #174',         '4102218', 'BEEF STEAK T-BONE CLS',       13.0, CURRENT_DATE - 30, CURRENT_DATE - 30, 21421402142, 'COMPLETED', CURRENT_DATE - 30, 8, CURRENT_DATE - 30, 'A'),
  (1009, 99010, 'BOX',  '5807662', 'BEEF SHORT LOIN CH #174',         '3401581', 'SAUSAGE CHORIZO COOKED FRZN TB',  22.0, CURRENT_DATE - 1, CURRENT_DATE - 1, 21421402145, 'COMPLETED', CURRENT_DATE - 1, 6, CURRENT_DATE - 1, 'C'),
  (1010, NULL, 'BOX', '7074792', 'CHICKEN CVP 8PC CUT FRSH TRIM',  NULL,      NULL,                          25.0, CURRENT_DATE - 60, CURRENT_DATE - 60, 21421402143, 'COMPLETED', CURRENT_DATE - 60, 9, CURRENT_DATE - 60, 'B'),
  (1011, NULL, 'BOX', '1961172', 'CHICKEN BREAST BNLS BRD WINGS',          NULL,      NULL,                          50.0, CURRENT_DATE - 30, CURRENT_DATE - 30, 21421402142, 'COMPLETED', CURRENT_DATE - 30,  10, CURRENT_DATE - 30, 'A'),

  (1012, 99002, 'BOX',  '4102218', 'BEEF SHORT LOIN CH #174',         '4102218', 'BEEF STEAK T-BONE CLS',  22.0, CURRENT_DATE - 60, CURRENT_DATE - 60, 21421402142, 'COMPLETED', CURRENT_DATE - 60, 6, CURRENT_DATE - 60, 'A'),
  (1013, 99006, 'BOX',  '3401581', 'BEEF SHORT LOIN CH #174',         '3401581', 'SAUSAGE CHORIZO COOKED FRZN TB',  50.0, CURRENT_DATE - 30, CURRENT_DATE - 30, 21421402145, 'COMPLETED', CURRENT_DATE - 30, 7, CURRENT_DATE - 30, 'C'),
  (1014, 99007, 'PIECE',  '4102218', 'BEEF SHORT LOIN CH #174',         '4102218', 'BEEF STEAK T-BONE CLS',       13.0, CURRENT_DATE - 30, CURRENT_DATE - 30, 21421402142, 'COMPLETED', CURRENT_DATE - 30, 8, CURRENT_DATE - 30, 'A'),
  (1015, 99010, 'BOX',  '5807662', 'BEEF SHORT LOIN CH #174',         '3401581', 'SAUSAGE CHORIZO COOKED FRZN TB',  22.0, CURRENT_DATE - 1, CURRENT_DATE - 1, 21421402145, 'COMPLETED', CURRENT_DATE - 1, 6, CURRENT_DATE - 1, 'C'),
  (1016, NULL, 'BOX', '7074792', 'CHICKEN CVP 8PC CUT FRSH TRIM',  NULL,      NULL,                          25.0, CURRENT_DATE - 60, CURRENT_DATE - 60, 21421402143, 'COMPLETED', CURRENT_DATE - 60, 9, CURRENT_DATE - 60, 'B'),
  (1017, NULL, 'BOX', '1961172', 'CHICKEN BREAST BNLS BRD WINGS',          NULL,      NULL,
  50.0, CURRENT_DATE - 30, CURRENT_DATE - 30, 21421402142 , 'COMPLETED', CURRENT_DATE - 30,  10, CURRENT_DATE - 30, 'A');

INSERT INTO box(id, sourceCutOrderId, status, createdAt, updatedAt, productionOrderId, productCode, version, consumedDate, incomplete, packagingTare)
VALUES
  (10001, 99000, 'ASSIGNED', CURRENT_DATE - 60, CURRENT_DATE  - 60, 99000, '4391102', 0, CURRENT_DATE - 60, FALSE, 0.7099999),
  (10002, 99000, 'ASSIGNED', CURRENT_DATE - 60, CURRENT_DATE  - 60, 99000, '4391102', 0, CURRENT_DATE - 60, FALSE, 0.7099999),
  (10003, 99000, 'ASSIGNED', CURRENT_DATE - 60, CURRENT_DATE  - 60, 99000, '4391102', 0, CURRENT_DATE - 60, FALSE, 0.7099999),
  (10004, 99000, 'ASSIGNED', CURRENT_DATE - 60, CURRENT_DATE  - 60, 99000, '4391102', 0, CURRENT_DATE - 60, FALSE, 0.7099999),
  (10005, 99000, 'ASSIGNED', CURRENT_DATE - 60, CURRENT_DATE  - 60, 99000, '4391102', 0, CURRENT_DATE - 60, FALSE, 0.7099999),
  (10006, 99001, 'ASSIGNED', CURRENT_DATE - 60, CURRENT_DATE  - 60, 99001, '3401581', 0, CURRENT_DATE - 60, FALSE, 0.7099999),
  (10007, 99002, 'ASSIGNED', CURRENT_DATE - 60, CURRENT_DATE  - 60, 99002, '4102218', 0, CURRENT_DATE - 60, FALSE, 0.7099999),
  (10008, 99002, 'ASSIGNED', CURRENT_DATE - 60, CURRENT_DATE  - 60, 99002, '4102218', 0, CURRENT_DATE - 60, FALSE, 0.7099999),
  (10009, 99002, 'ASSIGNED', CURRENT_DATE - 60, CURRENT_DATE  - 60, 99002, '4102218', 0, CURRENT_DATE - 60, FALSE, 0.7099999),
  (10010, 99002, 'ASSIGNED', CURRENT_DATE - 60, CURRENT_DATE  - 60, 99002, '4102218', 0, CURRENT_DATE - 60, FALSE, 0.7099999),
  (10011, 99002, 'ASSIGNED', CURRENT_DATE - 60, CURRENT_DATE  - 60, 99002, '4102218', 0, CURRENT_DATE - 60, FALSE, 0.7099999),
  (10012, 99002, 'ASSIGNED', CURRENT_DATE - 60, CURRENT_DATE  - 60, 99002, '4102218', 0, CURRENT_DATE - 60, FALSE, 0.7099999),
  (10013, 99002, 'ASSIGNED', CURRENT_DATE - 60, CURRENT_DATE  - 60, 99002, '4102218', 0, CURRENT_DATE - 60, FALSE, 0.7099999),
  (10014, 99003, 'ASSIGNED', CURRENT_DATE - 60, CURRENT_DATE  - 60, 99003, '4102246', 0, CURRENT_DATE - 60, FALSE, 0.7099999),
  (10015, 99004, 'ASSIGNED', CURRENT_DATE - 60, CURRENT_DATE  - 60, 99004, '2111148', 0, CURRENT_DATE - 60, FALSE, 0.7099999),
  (10016, 99005, 'ASSIGNED', CURRENT_DATE - 60, CURRENT_DATE  - 60, 99005, '4391102', 0, CURRENT_DATE - 60, FALSE, 0.7099999),
  (10017, 99005, 'ASSIGNED', CURRENT_DATE - 60, CURRENT_DATE  - 60, 99005, '4391102', 0, CURRENT_DATE - 60, FALSE, 0.7099999),
  (10018, 99005, 'ASSIGNED', CURRENT_DATE - 60, CURRENT_DATE  - 60, 99005, '4391102', 0, CURRENT_DATE - 60, FALSE, 0.7099999),
  (10019, 99005, 'ASSIGNED', CURRENT_DATE - 60, CURRENT_DATE  - 60, 99005, '4391102', 0, CURRENT_DATE - 60, FALSE, 0.7099999),
  (10020, 99006, 'ASSIGNED', CURRENT_DATE - 30, CURRENT_DATE  - 30, 99006, '3401581', 0, CURRENT_DATE - 30, FALSE, 0.7099999),
  (10021, 99006, 'ASSIGNED', CURRENT_DATE - 30, CURRENT_DATE  - 30, 99006, '3401581', 0, CURRENT_DATE - 30, FALSE, 0.7099999),
  (10022, 99006, 'ASSIGNED', CURRENT_DATE - 30, CURRENT_DATE  - 30, 99006, '3401581', 0, CURRENT_DATE - 30, FALSE, 0.7099999),
  (10023, 99006, 'ASSIGNED', CURRENT_DATE - 30, CURRENT_DATE  - 30, 99006, '3401581', 0, CURRENT_DATE - 30, FALSE, 0.7099999),
  (10024, 99006, 'ASSIGNED', CURRENT_DATE - 30, CURRENT_DATE  - 30, 99006, '3401581', 0, CURRENT_DATE - 30, FALSE, 0.7099999),
  (10025, 99006, 'ASSIGNED', CURRENT_DATE - 30, CURRENT_DATE  - 30, 99006, '3401581', 0, CURRENT_DATE - 30, FALSE, 0.7099999),
  (10026, 99006, 'ASSIGNED', CURRENT_DATE - 30, CURRENT_DATE  - 30, 99006, '3401581', 0, CURRENT_DATE - 30, FALSE, 0.7099999),
  (10027, 99007, 'ASSIGNED', CURRENT_DATE - 30, CURRENT_DATE  - 30, 99007, '4102218', 0, CURRENT_DATE - 30, FALSE, 0.7099999),
  (10028, 99008, 'ASSIGNED', CURRENT_DATE - 30, CURRENT_DATE  - 30, 99008, '4102246', 0, CURRENT_DATE - 30, FALSE, 0.7099999),
  (10029, 99008, 'ASSIGNED', CURRENT_DATE - 30, CURRENT_DATE  - 30, 99008, '4102246', 0, CURRENT_DATE - 30, FALSE, 0.7099999),
  (10030, 99008, 'ASSIGNED', CURRENT_DATE - 30, CURRENT_DATE  - 30, 99008, '4102246', 0, CURRENT_DATE - 30, FALSE, 0.7099999),
  (10031, 99008, 'ASSIGNED', CURRENT_DATE - 30, CURRENT_DATE  - 30, 99008, '4102246', 0, CURRENT_DATE - 30, FALSE, 0.7099999),
  (10032, 99008, 'ASSIGNED', CURRENT_DATE - 30, CURRENT_DATE  - 30, 99008, '4102246', 0, CURRENT_DATE - 30, FALSE, 0.7099999),
  (10033, 99008, 'ASSIGNED', CURRENT_DATE - 30, CURRENT_DATE  - 30, 99008, '4102246', 0, CURRENT_DATE - 30, FALSE, 0.7099999),
  (10034, 99009, 'ASSIGNED', CURRENT_DATE - 30, CURRENT_DATE  - 30, 99009, '4391102', 0, CURRENT_DATE - 30, FALSE, 0.7099999),
  (10035, 99009, 'ASSIGNED', CURRENT_DATE - 30, CURRENT_DATE  - 30, 99009, '4391102', 0, CURRENT_DATE - 30, FALSE, 0.7099999),
  (10036, 99010, 'ASSIGNED', CURRENT_DATE - 1, CURRENT_DATE  - 1, 99010, '3401581', 0, CURRENT_DATE - 1, FALSE, 0.7099999),
  (10037, 99010, 'ASSIGNED', CURRENT_DATE - 1, CURRENT_DATE  - 1, 99010, '3401581', 0, CURRENT_DATE - 1, FALSE, 0.7099999),
  (10038, 99010, 'ASSIGNED', CURRENT_DATE - 1, CURRENT_DATE  - 1, 99010, '3401581', 0, CURRENT_DATE - 1, FALSE, 0.7099999),
  (10039, 99011, 'ASSIGNED', CURRENT_DATE - 1, CURRENT_DATE  - 1, 99011, '4102218', 0, CURRENT_DATE - 1, FALSE, 0.7099999),
  (10040, 99011, 'ASSIGNED', CURRENT_DATE - 1, CURRENT_DATE  - 1, 99011, '4102218', 0, CURRENT_DATE - 1, FALSE, 0.7099999),
  (10041, 99011, 'ASSIGNED', CURRENT_DATE - 1, CURRENT_DATE  - 1, 99011, '4102218', 0, CURRENT_DATE - 1, FALSE, 0.7099999),
  (10042, 99011, 'ASSIGNED', CURRENT_DATE - 1, CURRENT_DATE  - 1, 99011, '4102218', 0, CURRENT_DATE - 1, FALSE, 0.7099999),
  (10043, 99012, 'ASSIGNED', CURRENT_DATE - 1, CURRENT_DATE  - 1, 99012, '4102246', 0, CURRENT_DATE - 1, FALSE, 0.7099999),
  (10044, 99013, 'ASSIGNED', CURRENT_DATE - 1, CURRENT_DATE  - 1, 99013, '2111148', 0, CURRENT_DATE - 1, FALSE, 0.7099999),
  (10045, 99013, 'ASSIGNED', CURRENT_DATE - 1, CURRENT_DATE  - 1, 99013, '2111148', 0, CURRENT_DATE - 1, FALSE, 0.7099999),
  (10046, 99013, 'ASSIGNED', CURRENT_DATE - 1, CURRENT_DATE  - 1, 99013, '2111148', 0, CURRENT_DATE - 1, FALSE, 0.7099999),
  (10047, 99013, 'ASSIGNED', CURRENT_DATE - 1, CURRENT_DATE  - 1, 99013, '2111148', 0, CURRENT_DATE - 1, FALSE, 0.7099999),
  (10048, NULL,  'AVAILABLE', CURRENT_DATE - 1, NULL, NULL, '2111148', 0, CURRENT_DATE - 1, FALSE, 0.7099999),
  (10049, NULL,  'AVAILABLE', CURRENT_DATE - 30, NULL, NULL, '4391102', 0, CURRENT_DATE - 30, FALSE, 0.7099999),
  (10050, NULL,  'AVAILABLE', CURRENT_DATE - 30, NULL, NULL, '3401581', 0, CURRENT_DATE - 30, FALSE, 0.7099999),
  (10051, NULL,  'AVAILABLE', CURRENT_DATE - 60, NULL, NULL, '2111148', 0, CURRENT_DATE - 60, FALSE, 0.7099999),
  (10052, NULL,  'AVAILABLE', CURRENT_DATE - 60, NULL, NULL, '4102246', 0, CURRENT_DATE - 60, FALSE, 0.7099999),
  (10053, NULL,  'AVAILABLE', CURRENT_DATE - 1, NULL, NULL, '3401581', 0, CURRENT_DATE - 1, FALSE, 0.7099999),
  (10054, NULL,  'AVAILABLE', CURRENT_DATE - 1, NULL, NULL, '2111148', 0, CURRENT_DATE - 1, TRUE, 0.7099999),
  (10055, NULL,  'AVAILABLE', CURRENT_DATE - 30, NULL, NULL, '4391102', 0, CURRENT_DATE - 30, TRUE, 0.7099999),
  (10056, NULL,  'AVAILABLE', CURRENT_DATE - 30, NULL, NULL, '3401581', 0, CURRENT_DATE - 30, TRUE, 0.7099999),
  (10057, NULL,  'AVAILABLE', CURRENT_DATE - 60, NULL, NULL, '2111148', 0, CURRENT_DATE - 60, TRUE, 0.7099999),
  (10058, NULL,  'AVAILABLE', CURRENT_DATE - 60, NULL, NULL, '4102246', 0, CURRENT_DATE - 60, TRUE, 0.7099999),
  (10059, NULL,  'AVAILABLE', CURRENT_DATE - 1, NULL, NULL, '3401581', 0, CURRENT_DATE - 1, TRUE, 0.7099999);


INSERT INTO weighing(boxid, weight, retailPieceTare, type, overrideWeightRangeReasonCode, createdAt)
VALUES
  (10001, 10.5, 0, 'BOX', NULL, CURRENT_DATE - 60),
  (10002, 10.5, 0, 'BOX', NULL, CURRENT_DATE - 60),
  (10003, 10.5, 0, 'BOX', NULL, CURRENT_DATE - 60),
  (10004, 10.5, 0, 'BOX', NULL, CURRENT_DATE - 60),
  (10005, 10.5, 0, 'BOX', NULL, CURRENT_DATE - 60),
  (10006, 10.5, 0, 'BOX', NULL, CURRENT_DATE - 60),
  (10007, 168.5, 0, 'BOX', NULL, CURRENT_DATE - 60),
  (10008, 168.5, 0, 'BOX', NULL, CURRENT_DATE - 60),
  (10009, 168.5, 0, 'BOX', NULL, CURRENT_DATE - 60),
  (10010, 168.5, 0, 'BOX', NULL, CURRENT_DATE - 60),
  (10011, 168.5, 0, 'BOX', NULL, CURRENT_DATE - 60),
  (10012, 168.5, 0, 'BOX', NULL, CURRENT_DATE - 60),
  (10013, 168.5, 0, 'BOX', NULL, CURRENT_DATE - 60),
  (10014, 160.5, 0, 'BOX', NULL, CURRENT_DATE - 60),
  (10015, 168.5, 0, 'BOX', NULL, CURRENT_DATE - 60),
  (10016, 10.5, 0, 'BOX', NULL, CURRENT_DATE - 60),
  (10017, 10.5, 0, 'BOX', NULL, CURRENT_DATE - 60),
  (10018, 10.5, 0, 'BOX', NULL, CURRENT_DATE - 60),
  (10019, 10.5, 0, 'BOX', NULL, CURRENT_DATE - 60),
  (10020, 10.5, 0, 'BOX', NULL, CURRENT_DATE - 30),
  (10021, 10.5, 0, 'BOX', NULL, CURRENT_DATE - 30),
  (10022, 10.5, 0, 'BOX', NULL, CURRENT_DATE - 30),
  (10023, 10.5, 0, 'BOX', NULL, CURRENT_DATE - 30),
  (10024, 10.5, 0, 'BOX', NULL, CURRENT_DATE - 30),
  (10025, 10.5, 0, 'BOX', NULL, CURRENT_DATE - 30),
  (10026, 10.5, 0, 'BOX', NULL, CURRENT_DATE - 30),
  (10027, 168.5, 0, 'BOX', NULL, CURRENT_DATE - 30),
  (10028, 160.5, 0, 'BOX', NULL, CURRENT_DATE - 30),
  (10029, 160.5, 0, 'BOX', NULL, CURRENT_DATE - 30),
  (10030, 160.5, 0, 'BOX', NULL, CURRENT_DATE - 30),
  (10031, 160.5, 0, 'BOX', NULL, CURRENT_DATE - 30),
  (10032, 160.5, 0, 'BOX', NULL, CURRENT_DATE - 30),
  (10033, 160.5, 0, 'BOX', NULL, CURRENT_DATE - 30),
  (10034, 10.5, 0, 'BOX', NULL, CURRENT_DATE - 30),
  (10035, 10.5, 0, 'BOX', NULL, CURRENT_DATE - 30),
  (10036, 10.5, 0, 'BOX', NULL, CURRENT_DATE - 1),
  (10037, 10.5, 0, 'BOX', NULL, CURRENT_DATE - 1),
  (10038, 10.5, 0, 'BOX', NULL, CURRENT_DATE - 1),
  (10039, 168.5, 0, 'BOX', NULL, CURRENT_DATE - 1),
  (10040, 168.5, 0, 'BOX', NULL, CURRENT_DATE - 1),
  (10041, 168.5, 0, 'BOX', NULL, CURRENT_DATE - 1),
  (10042, 168.5, 0, 'BOX', NULL, CURRENT_DATE - 1),
  (10043, 160.5, 0, 'BOX', NULL, CURRENT_DATE - 1),
  (10044, 168.5, 0, 'BOX', NULL, CURRENT_DATE - 1),
  (10045, 168.5, 0, 'BOX', NULL, CURRENT_DATE - 1),
  (10046, 168.5, 0, 'BOX', NULL, CURRENT_DATE - 1),
  (10047, 168.5, 0, 'BOX', NULL, CURRENT_DATE - 1),
  (10048, 168.5, 0, 'BOX', NULL, CURRENT_DATE - 1),
  (10049, 10.5, 0, 'BOX', NULL, CURRENT_DATE - 30),
  (10050, 10.5, 0, 'BOX', NULL, CURRENT_DATE - 30),
  (10051, 168.5, 0, 'BOX', NULL, CURRENT_DATE - 60),
  (10052, 169.5, 0, 'BOX', NULL, CURRENT_DATE - 60),
  (10053, 10.5, 0, 'BOX', NULL, CURRENT_DATE - 1),
  (10054, 72.5, 0, 'BOX', NULL, CURRENT_DATE - 1),
  (10055, 5.6, 0, 'BOX', NULL, CURRENT_DATE - 30),
  (10056, 65.5, 0, 'BOX', NULL, CURRENT_DATE - 30),
  (10057, 32.5, 0, 'BOX', NULL, CURRENT_DATE - 60),
  (10058, 42.5, 0, 'BOX', NULL, CURRENT_DATE - 60),
  (10059, 10.5, 0, 'BOX', NULL, CURRENT_DATE - 1);

INSERT INTO reporting.reportingbox (id, productcode, productdescription, laborcost, replacementcost, netweight, weightPerBox, isfixweightproduct, createdat, updatedat, workingDate, portionroomcode, yieldPercentage, status,
packoffStationName, stationCode, tableCode, incomplete, customername, customercode, customerordernumber, packageTareWeight, byproductOnly, weight, totaltareweight) VALUES
  (100001, '4391102', 'STEAK BEEF SIRLOIN FAJ CUT', 2.23, 6.93, 10.5, 10, TRUE, CURRENT_DATE - 60, CURRENT_DATE - 60,CURRENT_DATE - 60, 'B', 71.0, 'ASSIGNED', 'JOHN', 91, 91, FALSE, 'Seed customer', '999999', '999', 0.71, FALSE, 11.21, 0.71),
  (100002, '4391102', 'STEAK BEEF SIRLOIN FAJ CUT', 2.23, 6.93, 10.5, 10, TRUE, CURRENT_DATE - 60, CURRENT_DATE - 60,CURRENT_DATE - 60, 'B', 71.0, 'ASSIGNED', 'JOHN', 91, 91, FALSE, 'Seed customer', '999999', '999', 0.71, FALSE, 11.21, 0.71),
  (100003, '4391102', 'STEAK BEEF SIRLOIN FAJ CUT', 2.23, 6.93, 10.5, 10, TRUE, CURRENT_DATE - 60, CURRENT_DATE - 60,CURRENT_DATE - 60, 'B', 71.0, 'ASSIGNED', 'JOHN', 91, 91, FALSE, 'Seed customer', '999999', '999', 0.71, FALSE, 11.21, 0.71),
  (100004, '4391102', 'STEAK BEEF SIRLOIN FAJ CUT', 2.23, 6.93, 10.5, 10, TRUE, CURRENT_DATE - 60, CURRENT_DATE - 60,CURRENT_DATE - 60, 'B', 71.0, 'ASSIGNED', 'JOHN', 91, 91, FALSE, 'Seed customer', '999999', '999', 0.71, FALSE, 11.21, 0.71),
  (100005, '4391102', 'STEAK BEEF SIRLOIN FAJ CUT', 2.23, 6.93, 10.5, 10, TRUE, CURRENT_DATE - 60, CURRENT_DATE - 60,CURRENT_DATE - 60, 'B', 71.0, 'ASSIGNED', 'JOHN', 91, 91, FALSE, 'Seed customer', '999999', '999', 0.71, FALSE, 11.21, 0.71),
  (100006, '3401581', 'SAUSAGE CHORIZO COOKED FRZN TB', 2.23, 20.58, 10.5, 9, FALSE, CURRENT_DATE - 60, CURRENT_DATE - 60, CURRENT_DATE - 60, 'C', 99.0, 'ASSIGNED', 'JOHN', 91, 91, FALSE, 'Seed customer', '999999', '999', 0.71, FALSE, 11.21, 0.71),
  (100007, '4102218', 'BEEF STEAK T-BONE CLS', 2.23, 18.14, 168.5, 167.0, TRUE, CURRENT_DATE - 60, CURRENT_DATE - 60,CURRENT_DATE - 60, 'A', 64.0, 'ASSIGNED', 'JOHN', 91, 91, FALSE, 'Seed customer', '999999', '999', 0.71, FALSE, 169.21, 0.71),
  (100008, '4102218', 'BEEF STEAK T-BONE CLS', 2.23, 18.14, 168.5, 167.0, TRUE, CURRENT_DATE - 60, CURRENT_DATE - 60,CURRENT_DATE - 60, 'A', 64.0, 'ASSIGNED', 'JOHN', 91, 91, FALSE, 'Seed customer', '999999', '999', 0.71, FALSE, 169.21, 0.71),
  (100009, '4102218', 'BEEF STEAK T-BONE CLS', 2.23, 18.14, 168.5, 167.0, TRUE, CURRENT_DATE - 60, CURRENT_DATE - 60,CURRENT_DATE - 60, 'A', 64.0, 'ASSIGNED', 'JOHN', 01, 91, FALSE, 'Seed customer', '999999', '999', 0.71, FALSE, 169.21, 0.71),
  (100010, '4102218', 'BEEF STEAK T-BONE CLS', 2.23, 18.14, 168.5, 167.0, TRUE, CURRENT_DATE - 60, CURRENT_DATE - 60,CURRENT_DATE - 60, 'A', 64.0, 'ASSIGNED', 'JOHN', 91, 91, FALSE, 'Seed customer', '999999', '999', 0.71, FALSE, 169.21, 0.71),
  (100011, '4102218', 'BEEF STEAK T-BONE CLS', 2.23, 18.14, 168.5, 167.0, TRUE, CURRENT_DATE - 60, CURRENT_DATE - 60,CURRENT_DATE - 60, 'A', 64.0, 'ASSIGNED', 'JOHN', 91, 91, FALSE, 'Seed customer', '999999', '999', 0.71, FALSE, 169.21, 0.71),
  (100012, '4102218', 'BEEF STEAK T-BONE CLS', 2.23, 18.14, 168.5, 167.0, TRUE, CURRENT_DATE - 60, CURRENT_DATE - 60,CURRENT_DATE - 60, 'A', 64.0, 'ASSIGNED', 'JOHN', 91, 91, FALSE, 'Seed customer', '999999', '999', 0.71, FALSE, 169.21, 0.71),
  (100013, '4102218', 'BEEF STEAK T-BONE CLS', 2.23, 18.14, 168.5, 167.0, TRUE, CURRENT_DATE - 60, CURRENT_DATE - 60,CURRENT_DATE - 60, 'A', 64.0, 'ASSIGNED', 'JOHN', 91, 91, FALSE, 'Seed customer', '999999', '999', 0.71, FALSE, 169.21, 0.71),
  (100014, '4102246', 'BEEF STEAK T-BONE CLS', 2.23, 18.14, 160.5, 159.0, TRUE, CURRENT_DATE - 60, CURRENT_DATE - 60,CURRENT_DATE - 60, 'A', 64.0, 'ASSIGNED', 'JOHN', 91, 91, FALSE, 'Seed customer', '999999', '999', 0.71, FALSE, 161.21, 0.71),
  (100015, '2111148', 'BEEF STEAK T-BONE CH #1174', 2.23, 18.14, 168.5, 167.0, TRUE, CURRENT_DATE - 60, CURRENT_DATE - 60, CURRENT_DATE - 60, 'A', 64.0, 'ASSIGNED', 'JOHN', 01, 91, FALSE, 'Seed customer', '999999', '999', 0.71, FALSE, 169.21, 0.71),
  (100016, '4391102', 'STEAK BEEF SIRLOIN FAJ CUT', 2.23, 6.93, 10.5, 10, TRUE, CURRENT_DATE - 60, CURRENT_DATE - 60,CURRENT_DATE - 60, 'B', 71.0, 'ASSIGNED', 'JOHN', 91, 91, FALSE, 'Seed customer', '999999', '999', 0.71, FALSE, 11.21, 0.71),
  (100017, '4391102', 'STEAK BEEF SIRLOIN FAJ CUT', 2.23, 6.93, 10.5, 10, TRUE, CURRENT_DATE - 60, CURRENT_DATE - 60,CURRENT_DATE - 60, 'B', 71.0, 'ASSIGNED', 'JOHN', 91, 91, FALSE, 'Seed customer', '999999', '999', 0.71, FALSE, 11.21, 0.71),
  (100018, '4391102', 'STEAK BEEF SIRLOIN FAJ CUT', 2.23, 6.93, 10.5, 10, TRUE, CURRENT_DATE - 60, CURRENT_DATE - 60,CURRENT_DATE - 60, 'B', 71.0, 'ASSIGNED', 'JOHN', 91, 91, FALSE, 'Seed customer', '999999', '999', 0.71, FALSE, 11.21, 0.71),
  (100019, '4391102', 'STEAK BEEF SIRLOIN FAJ CUT', 2.23, 6.93, 10.5, 10, TRUE, CURRENT_DATE - 60, CURRENT_DATE - 60,CURRENT_DATE - 60, 'B', 71.0, 'ASSIGNED', 'JOHN', 91, 91, FALSE, 'Seed customer', '999999', '999', 0.71, FALSE, 11.21, 0.71),
  (100020, '3401581', 'SAUSAGE CHORIZO COOKED FRZN TB', 2.23, 20.58, 10.5, 9, FALSE, CURRENT_DATE - 30, CURRENT_DATE - 30, CURRENT_DATE - 30, 'C', 99.0, 'ASSIGNED', 'JOHN', 91, 91, FALSE, 'Seed customer', '999999', '999', 0.71, FALSE, 11.21, 0.71),
  (100021, '3401581', 'SAUSAGE CHORIZO COOKED FRZN TB', 2.23, 20.58, 10.5, 9, FALSE, CURRENT_DATE - 30, CURRENT_DATE - 30, CURRENT_DATE - 30, 'C', 99.0, 'ASSIGNED', 'JOHN', 91, 91, FALSE, 'Seed customer', '999999', '999', 0.71, FALSE, 11.21, 0.71),
  (100022, '3401581', 'SAUSAGE CHORIZO COOKED FRZN TB', 2.23, 20.58, 10.5, 9, FALSE, CURRENT_DATE - 30, CURRENT_DATE - 30, CURRENT_DATE - 30, 'C', 99.0, 'ASSIGNED', 'JOHN', 91, 91, FALSE, 'Seed customer', '999999', '999', 0.71, FALSE, 11.21, 0.71),
  (100023, '3401581', 'SAUSAGE CHORIZO COOKED FRZN TB', 2.23, 20.58, 10.5, 9, FALSE, CURRENT_DATE - 30, CURRENT_DATE - 30, CURRENT_DATE - 30, 'C', 99.0, 'ASSIGNED', 'JOHN', 91, 91, FALSE, 'Seed customer', '999999', '999', 0.71, FALSE, 11.21, 0.71),
  (100024, '3401581', 'SAUSAGE CHORIZO COOKED FRZN TB', 2.23, 20.58, 10.5, 9, FALSE, CURRENT_DATE - 30, CURRENT_DATE - 30, CURRENT_DATE - 30, 'C', 99.0, 'ASSIGNED', 'JOHN', 91, 91, FALSE, 'Seed customer', '999999', '999', 0.71, FALSE, 11.21, 0.71),
  (100025, '3401581', 'SAUSAGE CHORIZO COOKED FRZN TB', 2.23, 20.58, 10.5, 9, FALSE, CURRENT_DATE - 30, CURRENT_DATE - 30, CURRENT_DATE - 30, 'C', 99.0, 'ASSIGNED', 'JOHN', 91, 91, FALSE, 'Seed customer', '999999', '999', 0.71, FALSE, 11.21, 0.71),
  (100026, '3401581', 'SAUSAGE CHORIZO COOKED FRZN TB', 2.23, 20.58, 10.5, 9, FALSE, CURRENT_DATE - 30, CURRENT_DATE - 30, CURRENT_DATE - 30, 'C', 99.0, 'ASSIGNED', 'JOHN', 91, 91, FALSE, 'Seed customer', '999999', '999', 0.71, FALSE, 11.21, 0.71),
  (100027, '4102218', 'BEEF STEAK T-BONE CLS', 2.23, 18.14, 168.5, 167.0, TRUE, CURRENT_DATE - 30, CURRENT_DATE - 30,CURRENT_DATE - 30, 'A', 64.0, 'ASSIGNED', 'JOHN', 91, 91, FALSE, 'Seed customer', '999999', '999', 0.71, FALSE, 169.21, 0.71),
  (100028, '4102246', 'BEEF STEAK T-BONE CLS', 2.23, 18.14, 160.5, 159.0, TRUE, CURRENT_DATE - 30, CURRENT_DATE - 30,CURRENT_DATE - 30, 'A', 64.0, 'ASSIGNED', 'JOHN', 91, 91, FALSE, 'Seed customer', '999999', '999', 0.71, FALSE, 161.21, 0.71),
  (100029, '4102246', 'BEEF STEAK T-BONE CLS', 2.23, 18.14, 160.5, 159.0, TRUE, CURRENT_DATE - 30, CURRENT_DATE - 30,CURRENT_DATE - 30, 'A', 64.0, 'ASSIGNED', 'JOHN', 91, 91, FALSE, 'Seed customer', '999999', '999', 0.71, FALSE, 161.21, 0.71),
  (100030, '4102246', 'BEEF STEAK T-BONE CLS', 2.23, 18.14, 160.5, 159.0, TRUE, CURRENT_DATE - 30, CURRENT_DATE - 30,CURRENT_DATE - 30, 'A', 64.0, 'ASSIGNED', 'JOHN', 91, 91, FALSE, 'Seed customer', '999999', '999', 0.71, FALSE, 161.21, 0.71),
  (100031, '4102246', 'BEEF STEAK T-BONE CLS', 2.23, 18.14, 160.5, 159.0, TRUE, CURRENT_DATE - 30, CURRENT_DATE - 30,CURRENT_DATE - 30, 'A', 64.0, 'ASSIGNED', 'JOHN', 91, 91, FALSE, 'Seed customer', '999999', '999', 0.71, FALSE, 161.21, 0.71),
  (100032, '4102246', 'BEEF STEAK T-BONE CLS', 2.23, 18.14, 160.5, 159.0, TRUE, CURRENT_DATE - 30, CURRENT_DATE - 30,CURRENT_DATE - 30, 'A', 64.0, 'ASSIGNED', 'JOHN', 91, 91, FALSE, 'Seed customer', '999999', '999', 0.71, FALSE, 161.21, 0.71),
  (100033, '4102246', 'BEEF STEAK T-BONE CLS', 2.23, 18.14, 160.5, 159.0, TRUE, CURRENT_DATE - 30, CURRENT_DATE - 30,CURRENT_DATE - 30, 'A', 64.0, 'ASSIGNED', 'JOHN', 91, 91, FALSE, 'Seed customer', '999999', '999', 0.71, FALSE, 161.21, 0.71),
  (100034, '4391102', 'STEAK BEEF SIRLOIN FAJ CUT', 2.23, 6.93, 10.5, 10, TRUE, CURRENT_DATE - 30, CURRENT_DATE - 30,CURRENT_DATE - 30, 'B', 71.0, 'ASSIGNED', 'JOHN', 91, 91, FALSE, 'Seed customer', '999999', '999', 0.71, FALSE, 11.21, 0.71),
  (100035, '4391102', 'STEAK BEEF SIRLOIN FAJ CUT', 2.23, 6.93, 10.5, 10, TRUE, CURRENT_DATE - 30, CURRENT_DATE - 30,CURRENT_DATE - 30, 'B', 71.0, 'ASSIGNED', 'JOHN', 91, 91, FALSE, 'Seed customer', '999999', '999', 0.71, FALSE, 11.21, 0.71),
  (100036, '3401581', 'SAUSAGE CHORIZO COOKED FRZN TB', 2.23, 20.58, 10.5, 9, FALSE, CURRENT_DATE - 1, CURRENT_DATE -1, CURRENT_DATE - 1, 'C', 99.0, 'ASSIGNED', 'JOHN', 91, 91, FALSE, 'Seed customer', '999999', '999', 0.71, FALSE, 11.21, 0.71),
  (100037, '3401581', 'SAUSAGE CHORIZO COOKED FRZN TB', 2.23, 20.58, 10.5, 9, FALSE, CURRENT_DATE - 1, CURRENT_DATE -1, CURRENT_DATE - 1, 'C', 99.0, 'ASSIGNED', 'JOHN', 91, 91, FALSE, 'Seed customer', '999999', '999', 0.71, FALSE, 11.21, 0.71),
  (100038, '3401581', 'SAUSAGE CHORIZO COOKED FRZN TB', 2.23, 20.58, 10.5, 9, FALSE, CURRENT_DATE - 1, CURRENT_DATE -1, CURRENT_DATE - 1, 'C', 99.0, 'ASSIGNED', 'JOHN', 91, 91, FALSE, 'Seed customer', '999999', '999', 0.71, FALSE, 11.21, 0.71),
  (100039, '4102218', 'BEEF STEAK T-BONE CLS', 2.23, 18.14, 168.5, 167.0, TRUE, CURRENT_DATE - 1, CURRENT_DATE - 1, CURRENT_DATE - 1, 'A', 64.0, 'ASSIGNED', 'JOHN', 91, 91, FALSE, 'Seed customer', '999999', '999', 0.71, FALSE, 169.21, 0.71),
  (100040, '4102218', 'BEEF STEAK T-BONE CLS', 2.23, 18.14, 168.5, 167.0, TRUE, CURRENT_DATE - 1, CURRENT_DATE - 1, CURRENT_DATE - 1, 'A', 64.0, 'ASSIGNED', 'JOHN', 91, 91, FALSE, 'Seed customer', '999999', '999', 0.71, FALSE, 169.21, 0.71),
  (100041, '4102218', 'BEEF STEAK T-BONE CLS', 2.23, 18.14, 168.5, 167.0, TRUE, CURRENT_DATE - 1, CURRENT_DATE - 1, CURRENT_DATE - 1, 'A', 64.0, 'ASSIGNED', 'JOHN', 91, 91, FALSE, 'Seed customer', '999999', '999', 0.71, FALSE, 169.21, 0.71),
  (100042, '4102218', 'BEEF STEAK T-BONE CLS', 2.23, 18.14, 168.5, 167.0, TRUE, CURRENT_DATE - 1, CURRENT_DATE - 1, CURRENT_DATE - 1, 'A', 64.0, 'ASSIGNED', 'JOHN', 91, 91, FALSE, 'Seed customer', '999999', '999', 0.71, FALSE, 169.21, 0.71),
  (100043, '4102246', 'BEEF STEAK T-BONE CLS', 2.23, 18.14, 160.5, 159.0, TRUE, CURRENT_DATE - 1, CURRENT_DATE - 1, CURRENT_DATE - 1, 'A', 64.0, 'ASSIGNED', 'JOHN', 91, 91, FALSE, 'Seed customer', '999999', '999', 0.71, FALSE, 161.21, 0.71),
  (100044, '2111148', 'BEEF STEAK T-BONE CH #1174', 2.23, 18.14, 168.5, 167.0, TRUE, CURRENT_DATE - 1, CURRENT_DATE - 1, CURRENT_DATE - 1, 'A', 64.0, 'ASSIGNED', 'JOHN', 91, 91, FALSE, 'Seed customer', '999999', '999', 0.71, FALSE, 169.21, 0.71),
  (100045, '2111148', 'BEEF STEAK T-BONE CH #1174', 2.23, 18.14, 168.5, 167.0, TRUE, CURRENT_DATE - 1, CURRENT_DATE - 1, CURRENT_DATE - 1, 'A', 64.0, 'ASSIGNED', 'JOHN', 91, 91, FALSE, 'Seed customer', '999999', '999', 0.71, FALSE, 169.21, 0.71),
  (100046, '2111148', 'BEEF STEAK T-BONE CH #1174', 2.23, 18.14, 168.5, 167.0, TRUE, CURRENT_DATE - 1, CURRENT_DATE - 1, CURRENT_DATE - 1, 'A', 64.0, 'ASSIGNED', 'JOHN', 91, 91, FALSE, 'Seed customer', '999999', '999', 0.71, FALSE, 169.21, 0.71),
  (100047, '2111148', 'BEEF STEAK T-BONE CH #1174', 2.23, 18.14, 168.5, 167.0, TRUE, CURRENT_DATE - 1, CURRENT_DATE - 1, CURRENT_DATE - 1, 'A', 64.0, 'ASSIGNED', 'JOHN', 91, 91, FALSE, 'Seed customer', '999999', '999', 0.71, FALSE, 169.21, 0.71),
  (100048, '2111148', 'BEEF STEAK T-BONE CH #1174', 2.23, 18.14, 168.5, 167.0, TRUE, CURRENT_DATE - 1, CURRENT_DATE - 1, CURRENT_DATE - 1, 'A', 64.0, 'AVAILABLE', 'JOHN', 91, 91, FALSE, NULL, NULL, NULL, 0.71, FALSE, 169.21, 0.71),
  (100049, '4391102', 'STEAK BEEF SIRLOIN FAJ CUT', 2.23, 6.93, 10.5, 10, TRUE, CURRENT_DATE - 30, CURRENT_DATE - 30,CURRENT_DATE - 30, 'B', 71.0, 'AVAILABLE', 'JOHN', 91, 91, FALSE, NULL, NULL, NULL, 0.71, FALSE, 11.21, 0.71),
  (100050, '3401581', 'SAUSAGE CHORIZO COOKED FRZN TB', 2.23, 20.58, 10.5, 9, FALSE, CURRENT_DATE - 30, CURRENT_DATE - 30, CURRENT_DATE - 30, 'C', 99.0, 'AVAILABLE', 'JOHN', 91, 91, FALSE, NULL, NULL, NULL, 0.71, FALSE, 11.21, 0.71),
  (100051, '2111148', 'BEEF STEAK T-BONE CH #1174', 2.23, 18.14, 168.5, 167.0, TRUE, CURRENT_DATE - 60, CURRENT_DATE - 60, CURRENT_DATE - 60, 'A', 64.0, 'AVAILABLE', 'JOHN', 91, 91, FALSE, NULL, NULL, NULL, 0.71, FALSE, 169.21, 0.71),
  (100052, '4102246', 'BEEF STEAK T-BONE CLS', 2.23, 18.14, 160.5, 159.0, TRUE, CURRENT_DATE - 60, CURRENT_DATE - 60,CURRENT_DATE - 60, 'A', 64.0, 'AVAILABLE', 'JOHN', 91, 91, FALSE, NULL, NULL, NULL, 0.71, FALSE, 161.21, 0.71),
  (100053, '3401581', 'SAUSAGE CHORIZO COOKED FRZN TB', 2.23, 20.58, 10.5, 9, FALSE, CURRENT_DATE - 1, CURRENT_DATE -1, CURRENT_DATE - 1, 'C', 99.0, 'AVAILABLE', 'JOHN', 91, 91, FALSE, NULL, NULL, NULL, 0.71, FALSE, 11.21, 0.71),
  (100054, '2111148', 'BEEF STEAK T-BONE CH #1174', 2.23, 18.14, 72.5, 167.0, TRUE, CURRENT_DATE - 1, CURRENT_DATE - 1, CURRENT_DATE - 1, 'A', 64.0, 'AVAILABLE', 'JOHN', 91, 91, TRUE, NULL, NULL, NULL, 0.71, FALSE, 73.21, 0.71),
  (100055, '4391102', 'STEAK BEEF SIRLOIN FAJ CUT', 2.23, 6.93, 68.5, 10, TRUE, CURRENT_DATE - 30, CURRENT_DATE - 30,CURRENT_DATE - 30, 'B', 71.0, 'AVAILABLE', 'JOHN', 91, 91, TRUE, NULL, NULL, NULL, 0.71, FALSE, 69.21, 0.71),
  (100056, '3401581', 'SAUSAGE CHORIZO COOKED FRZN TB', 2.23, 20.58, 65.5, 9, FALSE, CURRENT_DATE - 30, CURRENT_DATE - 30, CURRENT_DATE - 30, 'C', 99.0, 'AVAILABLE', 'JOHN', 91, 91, TRUE, NULL, NULL, NULL, 0.71, FALSE, 66.21, 0.71),
  (100057, '2111148', 'BEEF STEAK T-BONE CH #1174', 2.23, 18.14, 32.5, 167.0, TRUE, CURRENT_DATE - 60, CURRENT_DATE -60, CURRENT_DATE - 60, 'A', 64.0, 'AVAILABLE', 'JOHN', 91, 91, TRUE, NULL, NULL, NULL, 0.71, FALSE, 33.21, 0.71),
  (100058, '4102246', 'BEEF STEAK T-BONE CLS', 2.23, 18.14, 42.5, 159.0, TRUE, CURRENT_DATE - 60, CURRENT_DATE - 60, CURRENT_DATE - 60, 'A', 64.0, 'AVAILABLE', 'JOHN', 91, 91, TRUE, NULL, NULL, NULL, 0.71, FALSE, 43.21, 0.71),
  (100059, '3401581', 'SAUSAGE CHORIZO COOKED FRZN TB', 2.23, 20.58, 10.5, 9, FALSE, CURRENT_DATE - 1, CURRENT_DATE -1, CURRENT_DATE - 1, 'C', 99.0, 'AVAILABLE', 'JOHN', 91, 91, TRUE, NULL, NULL, NULL, 0.71, FALSE, 11.21, 0.71);

INSERT INTO reporting.reportingSourceMeatOrder (id, quantity, weightPerBox, createdAt, updatedAt, poNumber,
productCode, productDescription, portionRoomCode, workingDate, transDate, invoiceNumber, fixedWeightProduct,
portionRoomProduct)
VALUES
(1000, 22.0, 168.0, CURRENT_DATE - 60, CURRENT_DATE - 60, 'kTtewEgtNZ', '4102218', 'BEEF STEAK T-BONE CLS', 'A',
 CURRENT_DATE - 60, CURRENT_DATE - 60, '123456' , TRUE, TRUE),
(1001, 50.0, 10.0, CURRENT_DATE - 30, CURRENT_DATE - 30, '0URmCmQX2X', '3401581', 'SAUSAGE CHORIZO COOKED FRZN TB',
 'C', CURRENT_DATE - 30, CURRENT_DATE - 30, '123457' , FALSE, TRUE),
(1002, 13.0, 168.0, CURRENT_DATE - 30, CURRENT_DATE - 30, '1198dxdV7H', '4102218', 'BEEF STEAK T-BONE CLS', 'A',
 CURRENT_DATE - 30, CURRENT_DATE - 30, '123458' , TRUE, TRUE),
(1003, 22.0, 10.0, CURRENT_DATE - 1, CURRENT_DATE - 1, 'aBtxyTmtYZ', '5807662', 'BEEF SHORT LOIN CH #174', 'C',
 CURRENT_DATE - 1, CURRENT_DATE - 1, '123459' , FALSE, FALSE),
(1004, 25.0, 42.0, CURRENT_DATE - 60, CURRENT_DATE - 60, 'aBtxyTmtYZ', '7074792', 'CHICKEN CVP 8PC CUT FRSH TRIM',
 'B', CURRENT_DATE - 60, CURRENT_DATE - 60, '123461' , FALSE, TRUE),
(1005, 50.0, 10.0, CURRENT_DATE - 30, CURRENT_DATE - 30, 'i53bpY2i6W', '1961172', 'CHICKEN BREAST BNLS BRD WINGS',
 'B', CURRENT_DATE - 30, CURRENT_DATE - 30, '123462' , TRUE, TRUE),
(1006, 22.0, 168.0, CURRENT_DATE - 60, CURRENT_DATE - 60, 'kXtewEgtNZ', '4102218', 'BEEF STEAK T-BONE CLS', 'A',
 CURRENT_DATE - 60, CURRENT_DATE - 60, '123463' , TRUE, TRUE),
(1007, 50.0, 10.0, CURRENT_DATE - 30, CURRENT_DATE - 30, '0YRmCmQX2X', '3401581', 'SAUSAGE CHORIZO COOKED FRZN TB',
 'C', CURRENT_DATE - 30, CURRENT_DATE - 30, '123464' , FALSE, TRUE),
(1008, 13.0, 168.0, CURRENT_DATE - 30, CURRENT_DATE - 30, '1w98dxdV7H', '4102218', 'BEEF STEAK T-BONE CLS', 'A',
 CURRENT_DATE - 30, CURRENT_DATE - 30, '123465' , TRUE, TRUE),
(1009, 22.0, 10.0, CURRENT_DATE - 1, CURRENT_DATE - 1, 'aCtxyTmtYZ', '5807662', 'BEEF SHORT LOIN CH #174', 'C',
 CURRENT_DATE - 1, CURRENT_DATE - 1, '123466' , FALSE, FALSE),
(1010, 25.0, 42.0, CURRENT_DATE - 60, CURRENT_DATE - 60, 'aDtxyTmtYZ', '7074792', 'CHICKEN CVP 8PC CUT FRSH TRIM',
 'B', CURRENT_DATE - 60, CURRENT_DATE - 60, '123467' , FALSE, TRUE),
(1011, 50.0, 10.0, CURRENT_DATE - 30, CURRENT_DATE - 30, 'i63bpY2i6W', '1961172', 'CHICKEN BREAST BNLS BRD WINGS',
 'B', CURRENT_DATE - 30, CURRENT_DATE - 30, '' , TRUE, TRUE),
(1012, 22.0, 168.0, CURRENT_DATE - 60, CURRENT_DATE - 60, 'kZtewEgtNZ', '4102218', 'BEEF STEAK T-BONE CLS', 'A',
 CURRENT_DATE - 60, CURRENT_DATE - 60, '' , TRUE, TRUE),
(1013, 50.0, 10.0, CURRENT_DATE - 30, CURRENT_DATE - 30, '0BRmCmQX2X', '3401581', 'SAUSAGE CHORIZO COOKED FRZN TB',
 'C', CURRENT_DATE - 30, CURRENT_DATE - 30, '' , FALSE, TRUE),
(1014, 13.0, 168.0, CURRENT_DATE - 30, CURRENT_DATE - 30, '1S98dxdV7H', '4102218', 'BEEF STEAK T-BONE CLS', 'A',
 CURRENT_DATE - 30, CURRENT_DATE - 30, '' , TRUE, TRUE),
(1015, 22.0, 10.0, CURRENT_DATE - 1, CURRENT_DATE - 1, 'aFtxyTmtYZ', '5807662', 'BEEF SHORT LOIN CH #174', 'C',
 CURRENT_DATE - 1, CURRENT_DATE - 1, '' , FALSE, FALSE),
(1016, 25.0, 42.0, CURRENT_DATE - 60, CURRENT_DATE - 60, 'aGtxyTmtYZ', '7074792', 'CHICKEN CVP 8PC CUT FRSH TRIM',
 'B', CURRENT_DATE - 60, CURRENT_DATE - 60, '' , FALSE, TRUE),
(1017, 50.0, 10.0, CURRENT_DATE - 30, CURRENT_DATE - 30, 'i73bpY2i6W', '1961172', 'CHICKEN BREAST BNLS BRD WINGS',
 'B', CURRENT_DATE - 30, CURRENT_DATE - 30, '' , TRUE, TRUE);

INSERT INTO reporting.reportingSourceMeatReceiptItem (id, currentQty, marketCost, createdAt, updatedAt, reportingSourceMeatOrderId, weightedAverageCost, catchWeightIndicator, currentTotalCatchWeight, productcode, fixedweightperbox, currentSplitQty)
VALUES
(5000, 20, 9.88, CURRENT_DATE - 60, NULL, 1000, 9.88, TRUE, 245.56,  '2857102', NULL, 0),
(5001, 47, 9.88, CURRENT_DATE - 30, NULL, 1001, 9.88, TRUE, 566.77,  '2857102', NULL, 0),
(5002, 11, 9.88, CURRENT_DATE - 30, NULL, 1002, 9.88, TRUE, 120.77,  '2857102', NULL, 0),
(5003, 24, 43.8, CURRENT_DATE - 1, NULL, 1003, 43.8, FALSE, 240.81,  '7203474', 8.0, 0),
(5004, 49, 16.6, CURRENT_DATE - 60, NULL, 1004, 16.6, FALSE, 565.91, '5807662', 8.0, 0),
(5005, 48, 43.8, CURRENT_DATE - 30, NULL, 1005, 43.8, FALSE, 245.81, '7203474', 8.0, 0),

(5006, 20, 9.88, CURRENT_DATE - 60, NULL, 1006, 9.88, TRUE, 245.56,  '2857102', NULL, 0),
(5007, 47, 9.88, CURRENT_DATE - 30, NULL, 1007, 9.88, TRUE, 566.77,  '2857102', NULL, 0),
(5008, 11, 9.88, CURRENT_DATE - 30, NULL, 1008, 9.88, TRUE, 120.77,  '2857102', NULL, 0),
(5009, 24, 43.8, CURRENT_DATE - 1, NULL, 1009, 43.8, FALSE, 240.81,  '7203474', 8.0, 0),
(5010, 49, 16.6, CURRENT_DATE - 60, NULL, 1010, 16.6, FALSE, 565.91, '5807662', 8.0, 0),
(5011, 48, 43.8, CURRENT_DATE - 30, NULL, 1011, 43.8, FALSE, 245.81, '7203474', 8.0, 0),

(5012, 20, 9.88, CURRENT_DATE - 60, NULL, 1012, 9.88, TRUE, 245.56,  '2857102', NULL, 0),
(5013, 47, 9.88, CURRENT_DATE - 30, NULL, 1013, 9.88, TRUE, 566.77,  '2857102', NULL, 0),
(5014, 11, 9.88, CURRENT_DATE - 30, NULL, 1014, 9.88, TRUE, 120.77,  '2857102', NULL, 0),
(5015, 24, 43.8, CURRENT_DATE - 1, NULL, 1015, 43.8, FALSE, 240.81,  '7203474', 8.0, 0),
(5016, 49, 16.6, CURRENT_DATE - 60, NULL, 1016, 16.6, FALSE, 565.91, '5807662', 8.0, 0),
(5017, 48, 43.8, CURRENT_DATE - 30, NULL, 1017, 43.8, FALSE, 245.81, '7203474', 8.0, 0);


INSERT INTO reporting.reportinghousepar (id, productcode, productdescription, weekstartdate, createdat, updatedat)
VALUES
       (999990101001001, '4391102', 'STEAK BEEF SIRLOIN FAJ CUT', '2018-11-25', '2018-12-04 14:42:00.250000', null),
       (999990101001002, '4102218', 'BEEF STEAK T-BONE CLS', '2018-11-25', '2018-12-04 14:42:00.270000', null),
       (999990101001003, '2111148', 'BEEF STEAK T-BONE CH #1174', '2018-11-25', '2018-12-04 14:42:00.277000', null),
       (999990101001004, '0565109', 'STEAK STRIP E/E', '2018-11-25', '2018-12-04 14:42:00.287000', null);


INSERT INTO reporting.reportingparvalue (id, value, dayofweek, parid, createdat, updatedat)
VALUES
       (999990101001001, 12, 5, 999990101001001, '2018-12-04 14:42:00.254000', null),
       (999990101001002, 10, 2, 999990101001001, '2018-12-04 14:42:00.256000', null),
       (999990101001003, 18, 3, 999990101001002, '2018-12-04 14:42:00.271000', null),
       (999990101001004, 17, 4, 999990101001002, '2018-12-04 14:42:00.272000', null),
       (999990101001005, 11, 1, 999990101001003, '2018-12-04 14:42:00.278000', null),
       (999990101001006, 22, 2, 999990101001003, '2018-12-04 14:42:00.279000', null),
       (999990101001007, 33, 3, 999990101001003, '2018-12-04 14:42:00.280000', null),
       (999990101001008, 44, 4, 999990101001003, '2018-12-04 14:42:00.281000', null),
       (999990101001009, 55, 5, 999990101001003, '2018-12-04 14:42:00.282000', null),
       (999990101001010, 15, 4, 999990101001004, '2018-12-04 14:42:00.288000', null),
       (999990101001011, 15, 5, 999990101001004, '2018-12-04 14:42:00.289000', null);


INSERT INTO productgroup(id, primaryproductid, createdat, updatedat, name)
VALUES
-- t-bone 4102218, 4102246, 2111148, 2111173, 2111203, 2111245,
       (999990101001001, 12,   NOW(), NOW(), '4102218'),
-- 80/20 4181840, 4228393, 4269781, 4554988, 7028918
       (999990101001002, null, NOW(), NOW(), 'BLEND1013'),
-- CHUCK 2200238, 3450034, 3655729, 3655798, 4406684
       (999990101001003, null, NOW(), NOW(), 'BLEND1011'),
-- NATURAL 2184768, 3616689, 3616706, 3616733, 3655436, 3655851, 3655883, 3655891, 3656031, 4083533
       (999990101001004, null, NOW(), NOW(), 'BLEND1004'),
-- BRISKET_BLEND 4824250, 4872341, 7031243
       (999990101001005, null, NOW(), NOW(), 'BLEND1010'),
       (999990101001007, 45,   NOW(), NOW(), '1961172'),
       (999990101001008, 11,   NOW(), NOW(), '3401581'),
       (999990101001009, 42,   NOW(), NOW(), '0565109'),
       (999990101001010, 43,   NOW(), NOW(), '4182307'),
       (999990101001011, 44,   NOW(), NOW(), '3052428'),
       (999990101001012, 41,   NOW(), NOW(), '0096505'),
-- beef sirloin
       (999990101001013, 10,   NOW(), NOW(), '4391102');

UPDATE product SET productgroupid = 999990101001001 WHERE code IN ('4102218', '4102246', '2111148', '2111173', '2111203', '2111245');
UPDATE product SET productgroupid = 999990101001002 WHERE code IN ('4181840', '4228393', '4269781', '4554988', '7028918');
UPDATE product SET productgroupid = 999990101001003 WHERE code IN ('2200238', '3450034', '3655729', '3655798', '4406684');
UPDATE product SET productgroupid = 999990101001004 WHERE code IN ('2184768', '3616689', '3616706', '3616733', '3655436', '3655851', '3655883', '3655891', '3656031', '4083533');
UPDATE product SET productgroupid = 999990101001005 WHERE code IN ('4824250', '4872341', '7031243');
UPDATE product SET productgroupid = 999990101001007 WHERE code = '1961172';
UPDATE product SET productgroupid = 999990101001008 WHERE code = '3401581';
UPDATE product SET productgroupid = 999990101001009 WHERE code = '0565109';
UPDATE product SET productgroupid = 999990101001010 WHERE code = '4182307';
UPDATE product SET productgroupid = 999990101001011 WHERE code = '3052428';
UPDATE product SET productgroupid = 999990101001012 WHERE code = '0096505';
UPDATE product SET productgroupid = 999990101001013 WHERE code = '4391102';

INSERT INTO housepar(id, productid, createdat, updatedat, deleted)
VALUES
       (999990101001001, 10, NOW(), NOW(), false),
       (999990101001002, 11, NOW(), NOW(), true),
       (999990101001003, 12, NOW(), NOW(), false),
       (999990101001004, 14, NOW(), NOW(), false),
       (999990101001005, 42, NOW(), NOW(), false);

INSERT INTO parvalue(id, createdat, updatedat, type, value, dayofweek, parid, deleted)
VALUES
       (999990101001001, NOW(), NOW(), 'HOUSE_PAR',    12, 5, 999990101001001, false),
       (999990101001002, NOW(), NOW(), 'HOUSE_PAR',    11, 1, 999990101001002, true),
       (999990101001003, NOW(), NOW(), 'HOUSE_PAR',    10, 2, 999990101001001, false),
       (999990101001004, NOW(), NOW(), 'HOUSE_PAR',    18, 3, 999990101001003, false),
       (999990101001005, NOW(), NOW(), 'HOUSE_PAR',    17, 4, 999990101001003, false),
       (999990101001006, NOW(), NOW(), 'HOUSE_PAR',    11, 1, 999990101001004, false),
       (999990101001007, NOW(), NOW(), 'HOUSE_PAR',    22, 2, 999990101001004, false),
       (999990101001008, NOW(), NOW(), 'HOUSE_PAR',    33, 3, 999990101001004, false),
       (999990101001009, NOW(), NOW(), 'HOUSE_PAR',    44, 4, 999990101001004, false),
       (999990101001010, NOW(), NOW(), 'HOUSE_PAR',    55, 5, 999990101001004, false),
       (999990101001011, NOW(), NOW(), 'HOUSE_PAR',    15, 4, 999990101001005, false),
       (999990101001012, NOW(), NOW(), 'HOUSE_PAR',    15, 5, 999990101001005, false);



INSERT INTO cuttingyieldmodel(id, createdat, updatedat, finishedproductcode, sourceproductcode, additives,
pricingmodel, ingredients, packaging, overhead, sourceLbs)
VALUES
-- chiken
       (999990101005001,  NOW(), NOW(), '1961172',  '7203474', 0,  true, NULL,   1.22, 0.38, NULL),
-- chorizo
       (999990101005002,  NOW(), NOW(), '3401581',  '5807662', 0,  true, 'test', 1.22, 0.38, NULL),
-- t-bone
       (999990101005003,  NOW(), NOW(), '4102218',  '2857102', 0,  true, NULL,   1.22, 0.38, NULL),
-- strip ee
       (999990101005004,  NOW(), NOW(), '0565109',  '2020766', 0,  true, NULL,   1.22, 0.38, NULL),
-- strip cc
       (999990101005005,  NOW(), NOW(), '4182307',  '2020766', 0,  true, NULL,   1.22, 0.38, NULL),
-- cube steak
       (999990101005006,  NOW(), NOW(), '3052428',  '3260878', 0,  true, NULL,   1.22, 0.38, NULL),
-- stew meat
       (999990101005007,  NOW(), NOW(), '0096505',  '3260878', 0,  true, NULL,   1.22, 0.38, NULL),
-- beef sirloin
       (999990101005009,  NOW(), NOW(), '4391102',  '3347632', 0,  false, NULL,  1.22, 0.38, NULL),
       (999990101005010,  NOW(), NOW(), '4391102',  '3126152', 0,  true, NULL,  1.22, 0.38, 4);


INSERT INTO cuttingyieldbyproduct(id, yieldmodelid, byproductcode, yieldpercentage, createdat, updatedat)
VALUES
-- chiken
       (309, (SELECT id FROM cuttingyieldmodel WHERE finishedproductcode = '1961172' AND sourceproductcode = '7203474'), '0565109',8.0, CURRENT_DATE, NULL),
       (310, (SELECT id FROM cuttingyieldmodel WHERE finishedproductcode = '1961172' AND sourceproductcode = '7203474'), '2536993',6.0, CURRENT_DATE, NULL),
-- chorizo
       (311, (SELECT id FROM cuttingyieldmodel WHERE finishedproductcode = '3401581' AND sourceproductcode = '5807662'), '2536993',1.0, CURRENT_DATE, NULL),
-- t-bone
       (312, (SELECT id FROM cuttingyieldmodel WHERE finishedproductcode = '4102218' AND sourceproductcode = '2857102'), '2536993',4.0, CURRENT_DATE, NULL),
       (313, (SELECT id FROM cuttingyieldmodel WHERE finishedproductcode = '4102218' AND sourceproductcode = '2857102'), '2111011',32.0, CURRENT_DATE, NULL),
-- strip ee
       (314, (SELECT id FROM cuttingyieldmodel WHERE finishedproductcode = '0565109' AND sourceproductcode = '2020766'), '2536993',5.0, CURRENT_DATE, NULL),
       (315, (SELECT id FROM cuttingyieldmodel WHERE finishedproductcode = '0565109' AND sourceproductcode = '2020766'), '2111011',18.0, CURRENT_DATE, NULL),
-- strip cc
       (317, (SELECT id FROM cuttingyieldmodel WHERE finishedproductcode = '4182307' AND sourceproductcode = '2020766'), '2536993',5.0, CURRENT_DATE, NULL),
       (318, (SELECT id FROM cuttingyieldmodel WHERE finishedproductcode = '4182307' AND sourceproductcode = '2020766'), '2111011',28.0, CURRENT_DATE, NULL),
       (319, (SELECT id FROM cuttingyieldmodel WHERE finishedproductcode = '4182307' AND sourceproductcode = '2020766'), '0096505',16.0, CURRENT_DATE, NULL),
-- cube steak
       (320, (SELECT id FROM cuttingyieldmodel WHERE finishedproductcode = '3052428' AND sourceproductcode = '3260878'), '2536993',5.0, CURRENT_DATE, NULL),
       (321, (SELECT id FROM cuttingyieldmodel WHERE finishedproductcode = '3052428' AND sourceproductcode = '3260878'), '2111011',15.0, CURRENT_DATE, NULL),
-- stew meat
       (322, (SELECT id FROM cuttingyieldmodel WHERE finishedproductcode = '0096505' AND sourceproductcode = '3260878'), '2536993',3.0, CURRENT_DATE, NULL),
       (323, (SELECT id FROM cuttingyieldmodel WHERE finishedproductcode = '0096505' AND sourceproductcode = '3260878'), '2111011',7.0, CURRENT_DATE, NULL),
-- beef sirloin
       (324, (SELECT id FROM cuttingyieldmodel WHERE finishedproductcode = '4391102' AND sourceproductcode = '3347632'), '0096505',17.0, CURRENT_DATE, NULL),
       (325, (SELECT id FROM cuttingyieldmodel WHERE finishedproductcode = '4391102' AND sourceproductcode = '3347632'), '2111011',12.0, CURRENT_DATE, NULL),
       (326, (SELECT id FROM cuttingyieldmodel WHERE finishedproductcode = '4391102' AND sourceproductcode = '3126152'), '2111011',2.0, CURRENT_DATE, NULL),
       (327, (SELECT id FROM cuttingyieldmodel WHERE finishedproductcode = '4391102' AND sourceproductcode = '3126152'), '0565109',4.0, CURRENT_DATE, NULL);

INSERT INTO cuttingyieldadditive(id, yieldmodelid, productcode, weight, createdat, updatedat)
VALUES
-- chicken
       (309, (SELECT id FROM cuttingyieldmodel WHERE finishedproductcode = '4391102' AND sourceproductcode =
       '3126152'), '3492610',1, CURRENT_DATE, NULL);

INSERT INTO Allergen (id, displayName, name, createdAt) VALUES
(1, 'Wheat/Gluten', 'WHEAT_GLUTEN', NOW()),
(2, 'Milk', 'MILK', NOW()),
(3, 'Eggs', 'EGGS', NOW()),
(4, 'Shellfish', 'SHELLFISH', NOW()),
(5, 'Peanuts', 'PEANUTS', NOW()),
(6, 'Tree Nuts', 'TREE_NUTS', NOW()),
(7, 'Soy', 'SOY', NOW()),
(8, 'Fish', 'FISH', NOW());

INSERT INTO blend(id, name, displayName, priority, createdAt, description) VALUES
(1, 'BLEND01', 'BLEND01 - 50/90 - TRIM 75/25', 1, NOW(), '50/90 - TRIM 75/25'),
(2, 'BLEND02', 'BLEND02 - 50/90 TRIM 62.5/37.5', 2, NOW(), '50/90 TRIM 62.5/37.5'),
(3, 'BLEND03', 'BLEND03 - CAB-KOBE BLEND', 3, NOW(), 'CAB-KOBE BLEND'),
(4, 'BLEND04', 'BLEND04 - CHK-TRM-BRSK', 4, NOW(), 'CHK-TRM-BRSK'),
(5, 'BLEND05', 'BLEND05 - CHUCK/TRIM BLEND', 5, NOW(), 'CHUCK/TRIM BLEND'),
(6, 'BLEND06', 'BLEND06 - 90/50 TRIM', 6, NOW(), '90/50 TRIM'),
(7, 'BLEND07', 'BLEND07 - CHK-BR-NAVEL', 7, NOW(), 'CHK-BR-NAVEL'),
(8, 'BLEND08', 'BLEND08 - 90/50 TRIMS', 8, NOW(), '90/50 TRIMS'),
(9, 'BLEND09', 'BLEND09 - CHUCK/BACON 80/20', 9, NOW(), 'CHUCK/BACON 80/20'),
(10, 'BLEND10', 'BLEND10 - CAB CHK/CAB BRSK', 10, NOW(), 'CAB CHK/CAB BRSK'),
(11, 'BLEND11', 'BLEND11 - CHK-BR-NAV', 11, NOW(), 'CHK-BR-NAV'),
(12, 'BLEND12', 'BLEND12 - CHK-BR-90''S', 12, NOW(), 'CHK-BR-90''S'),
(13, 'BLEND13', 'BLEND13 - CH-BR-NAVEL', 13, NOW(), 'CH-BR-NAVEL'),
(14, 'BLEND14', 'BLEND14 - CHUCK/BACON 85.7/14.3', 14, NOW(), 'CHUCK/BACON 85.7/14.3'),
(15, 'BLEND15', 'BLEND15 - CHUCK/BACON 87.5/12.5', 15, NOW(), 'CHUCK/BACON 87.5/12.5'),
(16, 'BLEND16', 'BLEND16 - 90/50 TRIM - 55/45', 16, NOW(), '90/50 TRIM - 55/45'),
(17, 'BLEND17', 'BLEND17 - CAB CHK/KOBE TRM BREND', 17, NOW(), 'CAB CHK/KOBE TRM BREND'),
(18, 'BLEND18', 'BLEND18 - HALAL 90/50', 18, NOW(), 'HALAL 90/50'),
(19, 'BLEND19', 'BLEND19 - 90/50 TRIM 58/42', 19, NOW(), '90/50 TRIM 58/42'),
(21, 'BLEND21', 'BLEND21 - CHK-BR-89TR', 21, NOW(), 'CHK-BR-89TR'),
(22, 'BLEND22', 'BLEND22 - HALAL CHK TRM/ HALAL 50''S', 22, NOW(), 'HALAL CHK TRM/ HALAL 50''S'),
(23, 'BLEND23', 'BLEND23 - (NOLAN) 81/19 CHK/CHUCK PLATE/BRISKET 66/17/17', 23, NOW(), '(NOLAN) 81/19 CHK/CHUCK PLATE/BRISKET 66/17/17'),

(1001, 'BLEND1001', 'BLEND1001 - HALAL', 1001, NOW(), 'HALAL'),
(1002, 'BLEND1002', 'BLEND1002 - NOLAN 75/25', 1002, NOW(), 'NOLAN 75/25'),
(1003, 'BLEND1003', 'BLEND1003 - NOLAN 80/20', 1003, NOW(), 'NOLAN 80/20'),
(1004, 'BLEND1004', 'BLEND1004 - NATURAL', 1004, NOW(), 'NATURAL'),
(1005, 'BLEND1005', 'BLEND1005 - AKAUSHI KOBE', 1005, NOW(), 'AKAUSHI KOBE'),
(1006, 'BLEND1006', 'BLEND1006 - KOBE', 1006, NOW(), 'KOBE'),
(1007, 'BLEND1007', 'BLEND1007 - CAB CHUCK', 1007, NOW(), 'CAB CHUCK'),
(1008, 'BLEND1008', 'BLEND1008 - ANGUS', 1008, NOW(), 'ANGUS'),
(1009, 'BLEND1009', 'BLEND1009 - SP BRISKET', 1009, NOW(), 'SP BRISKET'),
(1010, 'BLEND1010', 'BLEND1010 - BRISKET BLEND', 1010, NOW(), 'BRISKET BLEND'),
(1011, 'BLEND1011', 'BLEND1011 - CHUCK', 1011, NOW(), 'CHUCK'),
(1012, 'BLEND1012', 'BLEND1012 - 90%', 1012, NOW(), '90%'),
(1013, 'BLEND1013', 'BLEND1013 - 80/20', 1013, NOW(), '80/20'),
(1014, 'BLEND1014', 'BLEND1014 - 75/25', 1014, NOW(), '75/25'),
(1015, 'BLEND1015', 'BLEND1015 - 72/28', 1015, NOW(), '72/28'),
(1016, 'BLEND1016', 'BLEND1016 - STEAK AND SHAKE', 1016, NOW(), 'STEAK AND SHAKE');

INSERT INTO grindingyieldmodel(id, createdat, updatedat, blendId, wastepercentage, pricingmodel, additives, packaging,
 labor, overhead)
VALUES
-- 8020
       (999990101005007, NOW(), NOW(), 1013, 2.0,  true, 0, 1.22, 2.23, 0.38),
-- chuck
       (999990101005008, NOW(), NOW(), 1011, 2.0,  true, 0, 1.22, 2.23, 0.38),
-- natural
       (999990101005009, NOW(), NOW(), 1004, 2.0,  true, 0, 1.22, 2.23, 0.38),
-- brisket blend
       (999990101005010, NOW(), NOW(), 1010, 2.0,  true, 0, 1.22, 2.23, 0.38);

INSERT INTO grindingyieldmodelsourceproducts(id, createdat, updatedat, sourceproductcode, grindingyieldmodelid, blendpercentage)
VALUES
-- 8020
       (999990101005007, NOW(), NOW(), '2963082',
          (SELECT id FROM grindingyieldmodel WHERE blendId = 1013), 100.0),
-- chuck
       (999990101005008, NOW(), NOW(), '2962845',
          (SELECT id FROM grindingyieldmodel WHERE blendId = 1011), 100.0),
-- natural
       (999990101005009, NOW(), NOW(), '2423501',
          (SELECT id FROM grindingyieldmodel WHERE blendId = 1004), 100.0),
-- brisket blend
       (999990101005010, NOW(), NOW(), '3199233',
          (SELECT id FROM grindingyieldmodel WHERE blendId = 1010), 50.0),
       (999990101005011, NOW(), NOW(), '1663364',
          (SELECT id FROM grindingyieldmodel WHERE blendId = 1010), 30.0),
       (999990101005012, NOW(), NOW(), '2423501',
          (SELECT id FROM grindingyieldmodel WHERE blendId = 1010), 20.0);


INSERT INTO cost (createdat, updatedat, source, name, yieldmodelid, marketcost, labor, startdate, enddate, weightedaveragecost, currentcostperpound)
VALUES
(NOW() - INTERVAL '1 HOUR', NULL, 'PRICING_MODEL', '0096505', 999990101005007, 6.93, 2.23, CURRENT_DATE, CURRENT_DATE + 200, NULL, 6.93),
(NOW()  - INTERVAL '1 HOUR', NULL, 'SUS', '0096505', NULL, NULL, NULL, CURRENT_DATE, CURRENT_DATE + 200, 6.93, NULL),
(NOW()  - INTERVAL '1 HOUR', NULL, 'PRICING_MODEL', '0565109', 999990101005004, 10.89, 2.23, CURRENT_DATE, CURRENT_DATE + 200, NULL, 10.89),
(NOW()  - INTERVAL '1 HOUR', NULL, 'SUS', '0565109', NULL, NULL, NULL, CURRENT_DATE, CURRENT_DATE + 200, 10.89, NULL),
(NOW()  - INTERVAL '1 HOUR', NULL, 'SUS', '1663364', NULL, 76.8, NULL, CURRENT_DATE - 20, CURRENT_DATE - 11, 75.8, 1.38),
(NOW()  - INTERVAL '1 HOUR', NULL, 'SUS', '1663364', NULL, 76.8, NULL, CURRENT_DATE - 10, CURRENT_DATE - 2, 76.8, 1.28),
(NOW()  - INTERVAL '1 HOUR', NULL, 'PRICING_MODEL', '1961172', 999990101005001, 4.2, 2.23, CURRENT_DATE, CURRENT_DATE + 200, NULL, 4.2),
(NOW()  - INTERVAL '1 HOUR', NULL, 'SUS', '1961172', NULL, NULL, NULL, CURRENT_DATE, CURRENT_DATE + 200, 4.2, NULL),
(NOW()  - INTERVAL '1 HOUR', NULL, 'SUS', '2020766', NULL, 6.268, NULL, CURRENT_DATE, CURRENT_DATE + 200, 6.268, 6.268),
(NOW()  - INTERVAL '1 HOUR', NULL, 'BYPRODUCT_ONLY', '2111011', NULL, 5.83, 0.00, CURRENT_DATE, CURRENT_DATE + 200, 5.83, 5.83),
(NOW()  - INTERVAL '1 HOUR', NULL, 'SUS', '2423501', NULL, 2, NULL, CURRENT_DATE, CURRENT_DATE + 200, 2, 2),
(NOW()  - INTERVAL '1 HOUR', NULL, 'BYPRODUCT_ONLY', '2536993', NULL, 0.00, 0.00, CURRENT_DATE, CURRENT_DATE + 200, 0.00, 0.00),
(NOW()  - INTERVAL '1 HOUR', NULL, 'SUS', '2857102', NULL, 9.88, NULL, CURRENT_DATE, CURRENT_DATE + 200, 9.88, 9.88),
(NOW()  - INTERVAL '1 HOUR', NULL, 'SUS', '2962845', NULL, 2.419, NULL, CURRENT_DATE, CURRENT_DATE + 200, 2.419, 2.419),
(NOW()  - INTERVAL '1 HOUR', NULL, 'SUS', '2963082', NULL, 2.329, NULL, CURRENT_DATE, CURRENT_DATE + 200, 2.329, 2.329),
(NOW()  - INTERVAL '1 HOUR', NULL, 'PRICING_MODEL', '3052428', 999990101005006, 7.07, 2.23, CURRENT_DATE,CURRENT_DATE + 200, NULL, 7.07),
(NOW()  - INTERVAL '7 DAY', NULL, 'PRICING_MODEL', '3052428', 999990101005006, 8.07, 2.23, CURRENT_DATE - 7,CURRENT_DATE + 200, NULL, 8.07),
(NOW()  - INTERVAL '7 DAY' + INTERVAL '1 HOUR', NULL, 'PRICING_MODEL', '3052428', 999990101005006, 9.07, 2.23,CURRENT_DATE - 7,CURRENT_DATE + 200, NULL, 9.07),
(NOW()  - INTERVAL '1 HOUR', NULL, 'SUS', '3052428', NULL, NULL, NULL, CURRENT_DATE, CURRENT_DATE + 200, 7.07, NULL),
(NOW()  - INTERVAL '1 HOUR', NULL, 'SUS', '3126152', NULL, 14.8, NULL, CURRENT_DATE, CURRENT_DATE + 200, 14.8, 14.8),
(NOW()  - INTERVAL '1 HOUR', NULL, 'SUS', '3199233', NULL, 3, NULL, CURRENT_DATE, CURRENT_DATE + 200, 3, 3),
(NOW()  - INTERVAL '1 HOUR', NULL, 'SUS', '3260878', NULL, NULL, NULL, CURRENT_DATE, CURRENT_DATE + 200, 2.99, NULL),
(NOW()  - INTERVAL '1 HOUR', NULL, 'SUS', '3347632', NULL, 17.2, NULL, CURRENT_DATE, CURRENT_DATE + 200, 17.2, 1.72),
(NOW()  - INTERVAL '1 HOUR', NULL, 'PRICING_MODEL', '3401581', 999990101005002, 5.47, 2.23, CURRENT_DATE, CURRENT_DATE + 200, NULL, 5.47),
(NOW()  - INTERVAL '1 HOUR', NULL, 'SUS', '3401581', NULL, NULL, NULL, CURRENT_DATE, CURRENT_DATE + 200, 5.47, NULL),
(NOW()  - INTERVAL '1 HOUR', NULL, 'PRICING_MODEL', '4102218', 999990101005003, 17.25, 2.23, CURRENT_DATE, CURRENT_DATE + 200, NULL, 17.25),
(NOW()  - INTERVAL '1 HOUR', NULL, 'SUS', '4102218', NULL, NULL, NULL, CURRENT_DATE, CURRENT_DATE + 200, 17.25, NULL),
(NOW()  - INTERVAL '1 HOUR', NULL, 'SUS', '2111148', NULL, NULL, NULL, CURRENT_DATE, CURRENT_DATE + 200, 10.25, NULL),
(NOW()  - INTERVAL '1 HOUR', NULL, 'PRICING_MODEL', '4182307', 999990101005005, 12.81, 2.23, CURRENT_DATE, CURRENT_DATE + 200, NULL, 12.81),
(NOW()  - INTERVAL '1 HOUR', NULL, 'SUS', '4182307', NULL, NULL, NULL, CURRENT_DATE, CURRENT_DATE + 200, 12.81, NULL),
(NOW()  - INTERVAL '1 HOUR', NULL, 'PRICING_MODEL', '4391102', 999990101005010, 19.2, 2.23, CURRENT_DATE, CURRENT_DATE + 200, NULL, 19.2),
(NOW()  - INTERVAL '1 HOUR', NULL, 'SUS', '4391102', NULL, NULL, NULL, CURRENT_DATE, CURRENT_DATE + 200, 19.2, NULL),
(NOW()  - INTERVAL '1 HOUR', NULL, 'SUS', '4391102', NULL, NULL, NULL, CURRENT_DATE, CURRENT_DATE + 200, 3.67, NULL),
(NOW()  - INTERVAL '1 HOUR', NULL, 'YIELD_MODEL', '4391102', 999990101005009, 3.67, 1, CURRENT_DATE, CURRENT_DATE + 200, NULL, 3.67),
(NOW()  - INTERVAL '1 HOUR', NULL, 'SUS', '5807662', NULL, 16.6, NULL, CURRENT_DATE, CURRENT_DATE + 200, 16.6, 1.66),
(NOW()  - INTERVAL '1 HOUR', NULL, 'SUS', '7203474', NULL, 43.8, NULL, CURRENT_DATE, CURRENT_DATE + 200, 43.8, 1.1),
(NOW()  - INTERVAL '1 HOUR', NULL, 'PRICING_MODEL', 'BLEND1013', 999990101005007, 6.21, 2.23, CURRENT_DATE, CURRENT_DATE + 200, NULL, 6.21),
(NOW()  - INTERVAL '1 HOUR', NULL, 'SUS', 'BLEND1013', NULL, NULL, NULL, CURRENT_DATE, CURRENT_DATE + 200, 6.21, NULL),
(NOW()  - INTERVAL '1 HOUR', NULL, 'PRICING_MODEL', 'BLEND1010', 999990101005010, 6.16, 2.23, CURRENT_DATE, CURRENT_DATE + 200, NULL, 6.16),
(NOW()  - INTERVAL '1 HOUR', NULL, 'SUS', 'BLEND1010', NULL, NULL, NULL, CURRENT_DATE, CURRENT_DATE + 200, 6.16, NULL),
(NOW()  - INTERVAL '1 HOUR', NULL, 'PRICING_MODEL', 'BLEND1011', 999990101005008, 6.3, 2.23, CURRENT_DATE, CURRENT_DATE + 200, NULL, 6.3),
(NOW()  - INTERVAL '1 HOUR', NULL, 'SUS', 'BLEND1011', NULL, NULL, NULL, CURRENT_DATE, CURRENT_DATE + 200, 6.3, NULL),
(NOW()  - INTERVAL '1 HOUR', NULL, 'PRICING_MODEL', 'BLEND1004', 999990101005009, 5.87, 2.23, CURRENT_DATE, CURRENT_DATE + 200, NULL, 5.87),
(NOW()  - INTERVAL '1 HOUR', NULL, 'SUS', 'BLEND1004', NULL, NULL, NULL, CURRENT_DATE, CURRENT_DATE + 200, 5.87, NULL);


INSERT INTO boxtype(id, boxdescription, boxtare, createdat, updatedat)
VALUES
       (919990101001001, 'BUCKHEAD 10# BLACK',    0.692, NOW(), NULL),
       (919990101001002, 'BUCKHEAD 10#',          0.692, NOW(), NULL),
       (919990101001003, '10# LONGHORN CAFE',     0.73, NOW(), NULL),
       (919990101001004, 'CHESTER''S',            0.656, NOW(), NULL),
       (919990101001005, 'REGULAR DIE CUT PATTY', 0.602, NOW(), NULL),
       (919990101001006, '#2',                    0.522, NOW(), NULL),
       (919990101001007, '#4',                    1.072, NOW(), NULL),
       (919990101001008, '#5',                    0.888, NOW(), NULL),
       (919990101001009, '#16',                   2.048, NOW(), NULL),
       (919990101001010, 'RSC REGULAR PATTY',     0.548, NOW(), NULL),
       (919990101001011, '#1 RSC',                0.81, NOW(), NULL),
       (919990101001012, '#2 RSC',                0.536, NOW(), NULL),
       (919990101001013, '#5 RSC',                0.806, NOW(), NULL),
       (919990101001014, 'NOLAN RYAN''S REGULAR', 0.544, NOW(), NULL),
       (919990101001015, 'NOLAN RYAN''S JUMBO',   0.68, NOW(), NULL),
       (919990101001016, 'BB PORK SMALL',         0.744, NOW(), NULL),
       (919990101001017, 'BB PORK LARGE',         1.034, NOW(), NULL),
       (919990101001018, '#1 RANCH & GRILL',      0.684, NOW(), NULL),
       (919990101001019, 'BRINKER PATTY',         1.158, NOW(), NULL),
       (919990101001020, '#5 RSC-BLACK',          0.844, NOW(), NULL),
       (919990101001021, '#1 RSC BLACK',          0.81, NOW(), NULL),
       (919990101001022, '#5 RSC PLAIN',          0.806, NOW(), NULL),
       (919990101001023, '#16 PLAIN',             2.048, NOW(), NULL),
       (919990101001024, 'OB PLAIN',              0.524, NOW(), NULL),
       (919990101001025, 'SCHWEID & SONS',        0.522, NOW(), NULL),
       (919990101001026, 'PATTIE #2',             0.522, NOW(), NULL),
       (919990101001027, '#12 SYSCO CLASSIC',     0.788, NOW(), NULL),
       (919990101001028, 'RSC BLK CHUYS',         0.81, NOW(), NULL);

INSERT INTO filmtype(id, filmdescription, filmtare, createdat, updatedat)
VALUES
       (919990101002001, '1X2', 0.032, NOW(), NULL),
       (919990101002002, '2X2', 0.016, NOW(), NULL),
       (919990101002003, '3X3', 0.0106, NOW(), NULL),
       (919990101002004, '4X4', 0.011, NOW(), NULL),
       (919990101002005, '2X3', 0.029, NOW(), NULL),
       (919990101002006, '4X3', 0.007, NOW(), NULL),
       (919990101002007, '8X2', 0.021, NOW(), NULL);

INSERT INTO TarePackage(id, boxTypeId, filmTypeId, defaulted, createdat, updatedat)
VALUES
       (919990101003001, 919990101001001, 919990101002001, FALSE, NOW(), NULL),
       (919990101003002, 919990101001001, 919990101002002, TRUE, NOW(), NULL);

INSERT INTO PiecesPackage(id, description, weight, createdat, updatedat)
VALUES
       (919990101002001, 'VP1',      0.8, NOW(), NULL),
       (919990101002002, 'VP2',      0.7, NOW(), NULL),
       (919990101002003, 'VP3',      0.6, NOW(), NULL),
       (919990101002004, 'VP4',      0.5, NOW(), NULL),
       (919990101002005, 'VP5',      0.4, NOW(), NULL),
       (919990101002006, 'VP6',      0.3, NOW(), NULL),
       (919990101002007, 'VP7',      0.2, NOW(), NULL),
       (919990101002008, 'VP8',      0.1, NOW(), NULL),
       (919990101002009, '5lb bag', 0.01, NOW(), NULL);


INSERT INTO Plate(id, weight, unit, type, createdat, updatedat)
VALUES
       (919990106662001, 8, 'oz', 'Thick',   NOW(), NULL),
       (919990106662002, 8, 'oz', 'Regular', NOW(), NULL),
       (919990106662003, 6, 'oz', 'Thick',   NOW(), NULL),
       (919990106662004, 4, 'oz', 'Regular', NOW(), NULL);

INSERT INTO PlateAssociation(id, modelNumber, plateId, createdat, updatedat)
VALUES
       (919990107772001, '10549-6',  919990106662001, NOW(), null),
       (919990107772002, '14127-19', 919990106662001, NOW(), null),
       (919990107772003, '8792-6',   919990106662001, NOW(), null),
       (919990107772004, '8793-6',   919990106662001, NOW(), null),
       (919990107772005, '10817-6',  919990106662002, NOW(), null),
       (919990107772006, '10834-6 ', 919990106662002, NOW(), null),
       (919990107772007, '15568-19', 919990106662002, NOW(), null),
       (919990107772008, '6-207',    919990106662003, NOW(), null),
       (919990107772009, '10264-6',  919990106662004, NOW(), null),
       (919990107772010, '10266-6',  919990106662004, NOW(), null);

INSERT INTO FiscalCalendar(id, startdate, nextstartdate, active, createdat, updatedat)
VALUES
       (919990107772001, TO_DATE('2018-07-01', 'YYYY-MM-DD'), NULL, true,  NOW(), NULL);

UPDATE SYSTEMCONFIG SET value = 'true' WHERE configgroup = 'GROUP_WEEKEND_OPEN_PORTION_ROOM';

INSERT INTO Batch(id, batchNumber, blendId, productionDate, tumbler, tumblerStartTime, tumblerStopTime,
startBatchTemp, finishedBatchTemp, allergens, finished, portionRoomCode,  grindSize,  createdat,  updatedat)
VALUES
(999990101005001,1,1004,'1/10/18',11,'10:34 AM','11:59 AM',33,36, false, true,'D', 'THREE_THIRTY_TWO', NOW(), null),
(999990101005002,2,1004,'1/10/18',12,'12:00 PM','02:36 PM',32,35, false, true, 'D', 'THREE_THIRTY_TWO', NOW(), null),
(999990101005003,3,1004,'1/10/18',13,'11:57 PM','12:45 AM',34,37, false, true, 'D', 'THREE_THIRTY_TWO', NOW(), null),
(999990101005004,4,1004,'1/11/18',11,'9:21 AM','11:36 AM',33,36, false, true, 'D', 'THREE_THIRTY_TWO', NOW(), null),
(999990101005005,5,1011,'1/11/18',21,'12:00 AM','1:30 PM',32,35, false, true, 'D', 'THREE_THIRTY_TWO', NOW(), null),
(999990101005006,6,1013,'2/14/18',44,'8:24 AM','11:16 AM',34,37, false, true, 'D', 'THREE_THIRTY_TWO', NOW(), null),
(999990101005007,7,1010,'2/14/18',30,'10:05 AM','1:00 PM',32,37, false, true, 'D', 'THREE_THIRTY_TWO', NOW(), null),
(999990101005008,8,1011,'2/14/18',21,'12:13 PM','2:43 PM',34,36, false, true, 'D', 'THREE_THIRTY_TWO', NOW(), null),
(999990101005009,9,1004,'3/8/18',13,'4:45 PM','6:01 PM',32,35,false, true, 'D', 'THREE_THIRTY_TWO', NOW(), null),
(999990101005010,10,1011,'4/9/18',21,'8:25 PM','9:18 PM',33,37,false, true, 'D', 'THREE_THIRTY_TWO', NOW(), null),
(999990101005011,11,1004,'5/7/18',11,'7:31 AM','8:05 AM',32,37,false, true, 'D', 'THREE_THIRTY_TWO', NOW(), null),
(999990101005012,12,1004,'5/7/18',13,'8:10 AM','10:13 AM',34,37,false, true, 'D', 'THREE_THIRTY_TWO', NOW(), null),
(999990101005013,13,1013,'5/7/18',44,'11:30 AM','2:18 PM',32,36,false, true, 'D', 'THREE_THIRTY_TWO', NOW(), null),
(999990101005014,14,1013,'5/7/18',44,'3:30 PM','9:18 PM',34,35,false, true, 'D', 'THREE_THIRTY_TWO', NOW(), null),
(999990101005015,15,1010,'6/11/18',30,'10:34 AM','11:59 AM',33,37,false, true, 'D', 'THREE_THIRTY_TWO', NOW(), null),
(999990101005016,16,1011,'6/11/18',21,'12:00 PM','2:36 PM',32,36,false, true, 'D', 'THREE_THIRTY_TWO', NOW(), null),
(999990101005017,17,1013,'6/12/18',44,'11:57 PM','12:45 AM',34,35,false, true, 'D', 'THREE_THIRTY_TWO', NOW(), null),
(999990101005018,18,1004,'6/13/18',12,'9:21 AM','11:36 AM',33,37,false, true, 'D', 'THREE_THIRTY_TWO', NOW(), null),
(999990101005019,19,1004,'6/14/18',11,'12:00 AM','1:30 PM',32,37,false, true, 'D', 'THREE_THIRTY_TWO', NOW(), null),
(999990101005020,20,1004,'6/15/18',11,'8:24 AM','11:16 AM',34,36,false, true, 'D', 'THREE_THIRTY_TWO', NOW(), null),
(999990101005021,21,1004,'6/15/18',13,'10:05 AM','1:00 PM',33,35,false, true, 'D', 'THREE_THIRTY_TWO', NOW(), null),
(999990101005022,22,1011,'6/15/18',21,'12:13 PM','2:43 PM',32,37,false, true, 'D', 'THREE_THIRTY_TWO', NOW(), null),
(999990101005023,23,1013,'7/16/18',44,'4:45 PM','6:01 PM',34,35,false, true, 'D', 'THREE_THIRTY_TWO', NOW(), null),
(999990101005024,24,1010,'7/16/18',30,'8:25 PM','9:18 PM',32,37,false, true, 'D', 'THREE_THIRTY_TWO', NOW(), null),
(999990101005025,25,1011,'7/16/18',21,'10:31 PM','11:30 PM',34,36,false, true, 'D', 'THREE_THIRTY_TWO', NOW(), null),
(999990101005026,26,1004,'7/17/18',12,'8:10 AM','10:13 AM',32,35,false, true, 'D', 'THREE_THIRTY_TWO', NOW(), null),
(999990101005027,27,1011,'7/18/18',21,'11:30 AM','2:18 PM',33,37,false, true, 'D', 'THREE_THIRTY_TWO', NOW(), null),
(999990101005028,28,1004,'7/25/18',12,'3:30 PM','9:18 PM',32,36,false, true, 'D', 'THREE_THIRTY_TWO', NOW(), null),
(999990101005029,29,1004,'8/20/18',13,'8:24 AM','11:16 AM',34,35,false, true, 'D', 'THREE_THIRTY_TWO', NOW(), null),
(999990101005030,30,1013,'8/21/18',44,'10:05 AM','1:00 PM',32,37,false, true, 'D', 'THREE_THIRTY_TWO', NOW(), null),
(999990101005031,31,1013,'8/22/18',44,'12:13 PM','2:43 PM',34,37,false, true, 'D', 'THREE_THIRTY_TWO', NOW(), null),
(999990101005032,32,1010,'8/23/18',30,'4:45 PM','6:01 PM',33,36,false, true, 'D', 'THREE_THIRTY_TWO', NOW(), null),
(999990101005033,33,1011,'8/24/18',21,'7:31 AM','8:05 AM',32,35,false, true, 'D', 'THREE_THIRTY_TWO', NOW(), null),
(999990101005034,34,1013,'8/24/18',44,'12:13 PM','2:43 PM',34,37,false, true, 'D', 'THREE_THIRTY_TWO', NOW(), null),
(999990101005035,35,1004,'8/24/18',11,'8:10 AM','10:13 AM',34,37,false, true, 'D', 'THREE_THIRTY_TWO', NOW(), null),
(999990101005036,36,1004,'8/27/18',13,'10:34 AM','11:59 AM',33,36,false, true, 'D', 'THREE_THIRTY_TWO', NOW(), null),
(999990101005037,37,1004,'8/28/18',11,'12:00 PM','2:36 PM',32,36,false, true, 'D', 'THREE_THIRTY_TWO', NOW(), null),
(999990101005038,38,1004,'8/29/18',12,'11:30 AM','2:18 PM',34,35,false, true, 'D', 'THREE_THIRTY_TWO', NOW(), null),
(999990101005039,39,1011,'8/30/18',21,'3:30 PM','9:18 PM',33,37,false, true, 'D', 'THREE_THIRTY_TWO', NOW(), null),
(999990101005040,40,1013,'8/31/18',44,'10:34 AM','11:59 AM',32,36,false, true, 'D', 'THREE_THIRTY_TWO', NOW(), null),
(999990101005041,41,1013,'9/3/18',44,'12:00 PM','2:36 PM',34,35,false, true, 'D', 'THREE_THIRTY_TWO', NOW(), null),
(999990101005042,42,1011,'9/4/18',21,'11:57 PM','12:45 AM',32,37,false, true, 'D', 'THREE_THIRTY_TWO', NOW(), null),
(999990101005043,43,1004,'9/5/18',11,'9:21 AM','11:36 AM',34,37,false, true, 'D', 'THREE_THIRTY_TWO', NOW(), null),
(999990101005044,44,1011,'9/6/18',21,'12:00 AM','1:30 PM',32,36,false, true, 'D', 'THREE_THIRTY_TWO', NOW(), null),
(999990101005045,45,1004,'9/7/18',13,'8:24 AM','11:16 AM',33,35,false, true, 'D', 'THREE_THIRTY_TWO', NOW(), null),
(999990101005046,46,1004,'9/10/18',12,'10:05 AM','1:00 PM',32,37,false, true, 'D', 'THREE_THIRTY_TWO', NOW(), null),
(999990101005047,47,1013,'9/10/18',44,'12:13 PM','2:43 PM',34,37,false, true, 'D', 'THREE_THIRTY_TWO', NOW(), null),
(999990101005048,48,1013,'9/10/18',44,'4:45 PM','6:01 PM',32,37,false, true, 'D', 'THREE_THIRTY_TWO', NOW(), null),
(999990101005049,49,1010,'9/11/18',30,'8:25 PM','9:18 PM',34,36,false, true, 'D', 'THREE_THIRTY_TWO', NOW(), null),
(999990101005050,50,1011,'9/12/18',21,'7:31 AM','8:05 AM',33,35,false, true, 'D', 'THREE_THIRTY_TWO', NOW(), null),
(999990101005051,51,1013,'9/13/18',44,'8:10 AM','10:13 AM',32,37,false, true, 'D', 'THREE_THIRTY_TWO', NOW(), null),
(999990101005052,52,1011,'9/14/18',21,'11:30 AM','2:18 PM',34,36,false, true, 'D', 'THREE_THIRTY_TWO', NOW(), null),
(999990101005053,53,1004,'9/17/18',11,'3:30 PM','9:18 PM',32,35,false, true, 'D', 'THREE_THIRTY_TWO', NOW(), null),
(999990101005054,54,1004,'9/17/18',13,'4:45 PM','6:01 PM',32,37,false, true, 'D', 'THREE_THIRTY_TWO', NOW(), null),
(999990101005055,55,1013,'9/17/18',44,'8:25 PM','9:18 PM',33,37,false, true, 'D', 'THREE_THIRTY_TWO', NOW(), null),
(999990101005056,56,1013,'9/18/18',44,'11:30 AM','2:18 PM',32,36,false, true, 'D', 'THREE_THIRTY_TWO', NOW(), null),
(999990101005057,57,1010,'9/19/18',30,'3:30 PM','9:18 PM',34,35,false, true, 'D', 'THREE_THIRTY_TWO', NOW(), null),
(999990101005058,58,1011,'9/20/18',21,'4:45 PM','6:01 PM',32,37,false, true, 'D', 'THREE_THIRTY_TWO', NOW(), null),
(999990101005059,59,1013,'9/21/18',44,'7:31 AM','8:05 AM',34,35,false, true, 'D', 'THREE_THIRTY_TWO', NOW(), null),
(999990101005060,60,1004,'9/21/18',13,'8:10 AM','10:13 AM',33,37,false, true, 'D', 'THREE_THIRTY_TWO', NOW(), null),
(999990101005061,61,NULL,'8/1/18',11,'10:34 AM','11:59 AM',33,37,false, true, 'B', 'THREE_THIRTY_TWO', NOW(), null),
(999990101005062,62,NULL,'8/1/18',11,'12:00 PM','2:36 PM',32,37,false, true, 'B', 'THREE_THIRTY_TWO', NOW(), null),
(999990101005063,63,NULL,'8/2/18',22,'11:57 PM','12:45 AM',34,36,false, true, 'B', 'THREE_THIRTY_TWO', NOW(), null),
(999990101005064,64,NULL,'9/21/18',11,'9:21 AM','11:36 AM',33,35,false, true, 'B', 'THREE_THIRTY_TWO', NOW(), null),
(999990101005065,65,NULL,'9/21/18',11,'12:00 PM','1:30 PM',32,37,false, true, 'B', 'THREE_THIRTY_TWO', NOW(), null),
(999990101005066,66,NULL,'9/25/18',11,'8:24 AM','11:16 AM',34,35,false, true, 'B', 'THREE_THIRTY_TWO', NOW(), null),
(999990101005067,67,NULL,'9/25/18',11,'10:05 AM','1:00 PM',32,37,false, true, 'B', 'THREE_THIRTY_TWO', NOW(), null),
(999990101005068,68,NULL,'9/25/18',22,'12:13 PM','2:43 PM',34,36,false, true, 'B', 'THREE_THIRTY_TWO', NOW(), null),
(999990101005069,69,NULL,'9/25/18',22,'4:45 PM','6:01 PM',32,35,false, true, 'B', 'THREE_THIRTY_TWO', NOW(), null),
(999990101005070,70,NULL,'9/26/18',11,'8:25 PM','9:18 PM',33,37,false, true, 'B', 'THREE_THIRTY_TWO', NOW(), null),
(999990101005071,71,NULL,'9/27/18',11,'7:31 AM','8:05 AM',32,36,false, true, 'B', 'THREE_THIRTY_TWO', NOW(), null),
(999990101005072,72,NULL,'9/28/18',11,'8:10 AM','10:13 AM',34,35,false, true, 'B', 'THREE_THIRTY_TWO', NOW(), null),
(999990101005073,73,NULL,'10/1/18',11,'11:30 AM','2:18 PM',32,37,false, true, 'B', 'THREE_THIRTY_TWO', NOW(), null),
(999990101005074,74,NULL,'10/1/18',11,'3:30 PM','9:18 PM',34,37,false, true, 'B', 'THREE_THIRTY_TWO', NOW(), null),
(999990101005075,75,NULL,'10/2/18',11,'10:34 AM','11:59 AM',33,36,false, true, 'B', 'THREE_THIRTY_TWO', NOW(), null),
(999990101005076,76,NULL,'10/2/18',11,'12:00 PM','2:36 PM',32,35,false, true, 'B', 'THREE_THIRTY_TWO', NOW(), null),
(999990101005077,77,NULL,'10/2/18',22,'11:57 PM','12:45 AM',34,37,false, true, 'B', 'THREE_THIRTY_TWO', NOW(), null),
(999990101005078,78,NULL,'10/3/18',11,'9:21 AM','11:36 AM',34,37,false, true, 'B', 'THREE_THIRTY_TWO', NOW(), null),
(999990101005079,79,NULL,'10/3/18',11,'12:00 PM','2:36 PM',33,36,false, true, 'B', 'THREE_THIRTY_TWO', NOW(), null),
(999990101005080,80,NULL,'10/3/18',22,'1:57 PM','11:45 PM',32,36,false, true, 'B','THREE_THIRTY_TWO', NOW(),null),
(999990101005081,81,NULL,'10/10/18',22,'1:57 PM','11:45 PM',32,36,false, false,'A', 'THREE_THIRTY_TWO', NOW(), null);

INSERT INTO BatchSourceMeat(id,batchId,sourceProductCode,poNumber, lotNumber, vendor, meatTemp, actualLbs,
establishmentNumber,harvestDate, createdat, updatedat)
VALUES
  (999990101005001,999990101005001,2423501,69110290,5509181650,'Cargill',34,450,13289,'1/3/18' , NOW(), null),
  (999990101005002,999990101005002,2423501,69109750,5509181650,'Cargill',34,6687,13289,'1/3/18', NOW(), null),
  (999990101005003,999990101005004,2423501,69109630,5509181655,'Cargill',34,1000,13289,'1/3/18' , NOW(), null),
  (999990101005004,999990101005004,2423501,69107680,5509181660,'Cargill',34,541,13289,'1/4/18', NOW(), null),
  (999990101005005,999990101005005,2962845,69245150,5509181665,'Conagra',34,987,140,'1/4/18', NOW(), null),
  (999990101005006,999990101005006,2963082,69245090,5509181670,'IBP',34,3215,9268,'2/7/18',NOW(), null),
  (999990101005007,999990101005007,3199233,69245080,5509181675,'Farmland',34,1245,15878,'2/7/18', NOW(), null),
  (999990101005008,999990101005007,1663364,69244220,5509181701,'Cargill',34,1000,13289,'1/31/18', NOW(), null),
  (999990101005009,999990101005007,2423501,69244200,5509181711,'Cargill',34,1000,13289,'2/7/18', NOW(), null),
  (999990101005010,999990101005008,2962845,69245050,5509181680,'Conagra',34,781,140,'2/7/18', NOW(), null),
  (999990101005011,999990101005009,2423501,69245040,5509181685,'Cargill',34,81,13289,'3/1/18', NOW(), null),
  (999990101005012,999990101005010,2962845,69245030,5509181690,'Conagra',34,367,140,'4/2/18', NOW(), null),
  (999990101005013,999990101005011,2423501,69245020,5509181695,'Cargill',34,1587,13289,'4/30/18', NOW(), null),
  (999990101005014,999990101005012,2423501,69244450,5509181700,'Cargill',34,450,13289,'4/30/18', NOW(), null),
  (999990101005015,999990101005013,2963082,69244440,5509181705,'IBP',34,6687,9268,'4/30/18', NOW(), null),
  (999990101005016,999990101005014,2963082,69244430,5509181710,'IBP',34,1000,9268,'4/30/18', NOW(), null),
  (999990101005017,999990101005015,3199233,69244420,5509181715,'Farmland',34,541,15878,'6/4/18', NOW(), null),
  (999990101005018,999990101005015,1663364,69244140,5509181702,'Cargill',34,1000,13289,'5/26/18', NOW(), null),
  (999990101005019,999990101005015,2423501,69244190,5509181712,'Cargill',34,1000,13289,'6/4/18', NOW(), null),
  (999990101005020,999990101005016,2962845,69215470,5509181720,'Conagra',34,987,140,'6/4/18', NOW(), null),
  (999990101005021,999990101005017,2963082,80520220,5509181725,'IBP',34,3215,9268,'6/5/18', NOW(), null),
  (999990101005022,999990101005018,2423501,69234490,5509181730,'Cargill',34,1245,13289,'6/6/18', NOW(), null),
  (999990101005023,999990101005019,2423501,69132630,5509181735,'Cargill',34,781,13289,'6/7/18', NOW(), null),
  (999990101005024,999990101005020,2423501,69113200,5509181740,'Cargill',34,81,13289,'6/8/18', NOW(), null),
  (999990101005025,999990101005021,2423501,11259010,5509181745,'Cargill',34,367,13289,'6/8/18', NOW(), null),
  (999990101005026,999990101005022,2962845,11187860,5509181750,'Conagra',34,1587,140,'6/8/18', NOW(), null),
  (999990101005027,999990101005023,2963082,69234500,5509181755,'IBP',34,361,9268,'7/9/18', NOW(), null),
  (999990101005028,999990101005024,3199233,69234480,5509181760,'Farmland',34,164,15878,'7/9/18', NOW(), null),
  (999990101005029,999990101005024,1663364,69244210,5509181703,'Cargill',34,1000,13289,'7/2/18', NOW(), null),
  (999990101005030,999990101005024,2423501,69244130,5509181713,'Cargill',34,1000,13289,'7/9/18', NOW(), null),
  (999990101005031,999990101005025,2962845,69132620,5509181765,'Conagra',34,450,140,'7/9/18', NOW(), null),
  (999990101005032,999990101005026,2423501,86155680,5509181770,'Cargill',34,6687,13289,'7/10/18', NOW(), null),
  (999990101005033,999990101005027,2962845,69131820,5509181775,'Conagra',34,1000,140,'7/11/18', NOW(), null),
  (999990101005034,999990101005028,2423501,69149950,5509181780,'Cargill',34,541,13289,'7/18/18', NOW(), null),
  (999990101005035,999990101005029,2423501,69149880,5509181785,'Cargill',34,987,13289,'8/13/18', NOW(), null),
  (999990101005036,999990101005030,2963082,69149970,5509181790,'IBP',34,3215,9268,'8/14/18', NOW(), null),
  (999990101005037,999990101005031,2963082,12269730,5509181795,'IBP',34,1245,9268,'8/15/18', NOW(), null),
  (999990101005038,999990101005032,3199233,11260430,5509181800,'Farmland',34,781,15878,'8/16/18', NOW(), null),
  (999990101005039,999990101005032,1663364,69244180,5509181704,'Cargill',34,1000,13289,'8/7/18', NOW(), null),
  (999990101005040,999990101005032,2423501,69244150,5509181714,'Cargill',34,1000,13289,'8/15/18', NOW(), null),
(999990101005041,999990101005033,2962845,12269590,5509181805,'Conagra',34,81,140,'8/17/18', NOW(), null),
(999990101005042,999990101005034,2963082,12269580,5509181810,'IBP',34,367,9268,'8/17/18', NOW(), null),
(999990101005043,999990101005035,2423501,11260290,5509181815,'Cargill',34,1587,13289,'8/17/18', NOW(), null),
(999990101005044,999990101005036,2423501,11260280,5509181820,'Cargill',34,450,13289,'8/20/18', NOW(), null),
(999990101005045,999990101005037,2423501,11256790,5509181825,'Cargill',34,6687,13289,'8/21/18', NOW(), null),
(999990101005046,999990101005038,2423501,11256780,5509181830,'Cargill',34,1000,13289,'8/22/18', NOW(), null),
(999990101005047,999990101005039,2962845,11233570,5509181835,'Conagra',34,541,140,'8/23/18', NOW(), null),
(999990101005048,999990101005040,2963082,11260170,5509181840,'IBP',34,987,9268,'8/24/18', NOW(), null),
(999990101005049,999990101005041,2963082,11259140,5509181845,'IBP',34,3215,9268,'8/27/18', NOW(), null),
(999990101005050,999990101005042,2962845,11259130,5509181850,'Conagra',34,1245,140,'8/28/18', NOW(), null) ,
(999990101005051,999990101005043,2423501,11259120,5509181855,'Cargill',34,781,13289,'8/29/18', NOW(), null),
(999990101005052,999990101005044,2962845,69110960,5509181860,'Conagra',34,81,140,'8/30/18', NOW(), null),
(999990101005053,999990101005045,2423501,69110950,5509181865,'Cargill',34,367,13289,'8/31/18', NOW(), null),
(999990101005054,999990101005046,2423501,69110930,5509181870,'Cargill',34,1587,13289,'9/3/18', NOW(), null),
(999990101005055,999990101005047,2963082,69110920,5509181875,'IBP',34,361,9268,'9/3/18', NOW(), null),
(999990101005056,999990101005048,2963082,69110910,5509181880,'IBP',34,164,9268,'9/3/18', NOW(), null),
(999990101005057,999990101005049,3199233,69110900,5509181885,'Farmland',34,1587,15878,'9/4/18', NOW(), null),
(999990101005058,999990101005049,1663364,69244160,5509181705,'Cargill',34,1000,13289,'8/27/18', NOW(), null),
(999990101005059,999990101005049,2423501,69244050,5509181715,'Cargill',34,1000,13289,'9/4/18', NOW(), null),
(999990101005060,999990101005050,2962845,69109760,5509181890,'Conagra',34,1540,140,'9/5/18', NOW(), null),
(999990101005061,999990101005051,2963082,69110320,5509181895,'IBP',34,1420,9268,'9/6/18', NOW(), null),
(999990101005062,999990101005052,2962845,69110310,5509181900,'Conagra',34,1348,140,'9/7/18', NOW(), null),
(999990101005063,999990101005053,2423501,69110300,5509181905,'Cargill',34,1265,13289,'9/10/18', NOW(), null),
(999990101005064,999990101005054,2423501,86155740,5509181910,'Cargill',34,1182,13289,'9/10/18', NOW(), null),
(999990101005065,999990101005055,2963082,86155720,5509181915,'IBP',34,1098,9268,'9/10/18', NOW(), null),
(999990101005066,999990101005056,2963082,86155690,5509181920,'IBP',34,1015,9268,'9/11/18', NOW(), null),
(999990101005067,999990101005057,3199233,86155730,5509181925,'Farmland',34,931,15878,'9/12/18', NOW(), null),
(999990101005068,999990101005057,1663364,69244170,5509181706,'Cargill',34,1000,13289,'9/5/18', NOW(), null),
(999990101005069,999990101005057,2423501,69244040,5509181716,'Cargill',34,1000,13289,'9/11/18', NOW(), null),
(999990101005070,999990101005058,2962845,86155710,5509181930,'Conagra',34,848,140,'9/13/18', NOW(), null),
(999990101005071,999990101005059,2963082,86155700,5509181935,'IBP',34,764,9268,'9/14/18', NOW(), null),
(999990101005072,999990101005060,2423501,86155680,5509181940,'Cargill',34,681,13289,'9/14/18', NOW(), null),
(999990101005073,999990101005061,3126152,11259120,5509181650,'Greater Omaha Packing',33,50,960,'7/3/18', NOW(), null),
(999990101005074,999990101005062,5807662,69110960,5509181655,'JBS',32,48,1311,'7/3/18', NOW(), null),
(999990101005075,999990101005063,5807662,69110950,5509181660,'JBS',34,49,1311,'7/3/18', NOW(), null),
(999990101005076,999990101005064,5807662,69110930,5509181665,'JBS',33,49,1311,'8/1/18', NOW(), null),
(999990101005077,999990101005065,5807662,69110920,5509181670,'JBS',32,48,1311,'8/1/18', NOW(), null),
(999990101005078,999990101005066,3126152,69110910,5509181675,'Greater Omaha Packing',34,50,960,'8/2/18', NOW(), null),
(999990101005079,999990101005067,3126152,69110900,5509181680,'Greater Omaha Packing',32,50,960,'9/21/18', NOW(), null),
(999990101005080,999990101005068,3126152,69109760,5509181685,'Greater Omaha Packing', 34,48,960,'9/21/18', NOW(), null),
(999990101005081,999990101005069,5807662,69110320,5509181690,'JBS',32,49,1311,'9/25/18', NOW(), null),
(999990101005082,999990101005070,5807662,69110310,5509181695,'JBS',33,49,1311,'9/25/18', NOW(), null),
(999990101005083,999990101005071,3126152,69110300,5509181700,'Greater Omaha Packing',32,48,960,'9/25/18', NOW(), null),
(999990101005084,999990101005072,3126152,86155740,5509181705,'Greater Omaha Packing',34,50,960,'9/25/18', NOW(), null),
(999990101005085,999990101005073,3126152,86155720,5509181710,'Greater Omaha Packing',32,50,960,'9/26/18', NOW(), null),
(999990101005086,999990101005074,5807662,86155690,5509181715,'JBS',34,48,1311,'9/27/18', NOW(), null),
(999990101005087,999990101005075,5807662,86155730,5509181720,'JBS',33,49,1311,'9/28/18', NOW(), null),
(999990101005088,999990101005076,5807662,86155710,5509181725,'JBS',32,49,1311,'10/1/18', NOW(), null),
(999990101005089,999990101005077,5807662,86155700,5509181730,'JBS',34,48,1311,'10/1/18', NOW(), null),
(999990101005090,999990101005078,3126152,86155680,5509181735,'Greater Omaha Packing',34,50,960,'10/2/18', NOW(), null),
(999990101005091,999990101005079,3126152,86155680,5509181740,'Greater Omaha Packing',33,47,960,'10/2/18', NOW(), null),
(999990101005092,999990101005080,3126152,86155680,5509181745,'Greater Omaha Packing',32,45,960,'10/2/18', NOW(), null),
(999990101005093,999990101005081,3126152,86155680,5509181735,'Greater Omaha Packing',34,50,960,'10/2/18', NOW(), null);


INSERT INTO BatchIngredient(id,batchId,ingredientProductCode, vendor, poNumber, actualLbs, allergens, createdat, updatedat)
VALUES
  (999990101005001,999990101005061,4092706,'CONAGRA',5509181820,0.5,true, NOW(), null),
  (999990101005002,999990101005061,7216286,'DOT FOODS',5509181820,0.5, false, NOW(), null),
  (999990101005003,999990101005061,5935689,'MCCORMICK',5509181820,0.5,true, NOW(), null),
  (999990101005004,999990101005062,5239611,'MCCORMICK',5509181825,0.48,false,NOW(), null),
  (999990101005005,999990101005062,3492610,'MCCORMICK',5509181825,0.48,false,NOW(), null),
  (999990101005006,999990101005062,5935671,'MCCORMICK',5509181825,0.48,false,NOW(), null),
  (999990101005007,999990101005063,5239611,'MCCORMICK',5509181830,0.49,false,NOW(), null),
  (999990101005008,999990101005063,3492610,'MCCORMICK',5509181830,0.49,false,NOW(), null),
  (999990101005009,999990101005063,5935671,'MCCORMICK',5509181830,0.49,false,NOW(), null),
  (999990101005010,999990101005064,5239611,'MCCORMICK',5509181835,0.49,false,NOW(), null),
  (999990101005011,999990101005064,3492610,'MCCORMICK',5509181835,0.49,false,NOW(), null),
  (999990101005012,999990101005064,5935671,'MCCORMICK',5509181835,0.49,false,NOW(), null),
  (999990101005013,999990101005065,5239611,'MCCORMICK',5509181840,0.48,false,NOW(), null),
  (999990101005014,999990101005065,3492610,'MCCORMICK',5509181840,0.48,false,NOW(), null),
  (999990101005015,999990101005065,5935671,'MCCORMICK',5509181840,0.48,false,NOW(), null),
  (999990101005016,999990101005066,4092706,'CONAGRA',5509181845,0.5,true,NOW(), null),
  (999990101005017,999990101005066,7216286,'DOT FOODS',5509181845,0.5,false,NOW(), null),
  (999990101005018,999990101005066,5935689,'MCCORMICK',5509181845,0.5,false,NOW(), null),
  (999990101005019,999990101005067,4092706,'CONAGRA',5509181850,0.5,true,NOW(), null),
  (999990101005020,999990101005067,7216286,'DOT FOODS',5509181850,0.5,false,NOW(), null),
  (999990101005021,999990101005067,5935689,'MCCORMICK',5509181850,0.5,false,NOW(), null),
  (999990101005022,999990101005068,4092706,'CONAGRA',5509181855,0.48,true,NOW(), null),
  (999990101005023,999990101005068,7216286,'DOT FOODS',5509181855,0.48,false,NOW(), null),
  (999990101005024,999990101005068,5935689,'MCCORMICK',5509181855,0.48,false,NOW(), null),
  (999990101005025,999990101005069,5239611,'MCCORMICK',5509181860,0.49,false,NOW(), null),
  (999990101005026,999990101005069,3492610,'MCCORMICK',5509181860,0.49,false,NOW(), null),
  (999990101005027,999990101005069,5935671,'MCCORMICK',5509181860,0.49,false,NOW(), null),
  (999990101005028,999990101005070,5239611,'MCCORMICK',5509181865,0.49,false,NOW(), null),
  (999990101005029,999990101005070,3492610,'MCCORMICK',5509181865,0.49,false,NOW(), null),
  (999990101005030,999990101005070,5935671,'MCCORMICK',5509181865,0.49,false,NOW(), null),
  (999990101005031,999990101005071,4092706,'CONAGRA',5509181870,0.48,true,NOW(), null),
  (999990101005032,999990101005071,7216286,'DOT FOODS',5509181870,0.48,false,NOW(), null),
  (999990101005033,999990101005071,5935689,'MCCORMICK',5509181870,0.48,false,NOW(), null),
  (999990101005034,999990101005072,4092706,'CONAGRA',5509181875,0.5,true,NOW(), null),
  (999990101005035,999990101005072,7216286,'DOT FOODS',5509181875,0.5,false,NOW(), null),
  (999990101005036,999990101005072,5935689,'MCCORMICK',5509181875,0.5,false,NOW(), null),
  (999990101005037,999990101005073,4092706,'CONAGRA',5509181880,0.5,true,NOW(), null),
  (999990101005038,999990101005073,7216286,'DOT FOODS',5509181880,0.5,false,NOW(), null),
  (999990101005039,999990101005073,5935689,'MCCORMICK',5509181880,0.5,false,NOW(), null),
  (999990101005040,999990101005074,5239611,'MCCORMICK',5509181885,0.48,false,NOW(), null),
  (999990101005041,999990101005074,3492610,'MCCORMICK',5509181885,0.48,false,NOW(), null),
  (999990101005042,999990101005074,5935671,'MCCORMICK',5509181885,0.48,false,NOW(), null),
  (999990101005043,999990101005075,5239611,'MCCORMICK',5509181890,0.49,false,NOW(), null),
  (999990101005044,999990101005075,3492610,'MCCORMICK',5509181890,0.49,false,NOW(), null),
  (999990101005045,999990101005075,5935671,'MCCORMICK',5509181890,0.49,false,NOW(), null),
  (999990101005046,999990101005076,5239611,'MCCORMICK',5509181895,0.49,false,NOW(), null),
  (999990101005047,999990101005076,3492610,'MCCORMICK',5509181895,0.49,false,NOW(), null),
  (999990101005048,999990101005076,5935671,'MCCORMICK',5509181895,0.49,false,NOW(), null),
 (999990101005049,999990101005077,5239611,'MCCORMICK',5509181900,0.48,false,NOW(), null),
 (999990101005050,999990101005077,3492610,'MCCORMICK',5509181900,0.48,false,NOW(), null),
 (999990101005051,999990101005077,5935671,'MCCORMICK',5509181900,0.48,false,NOW(), null),
 (999990101005052,999990101005078,4092706,'CONAGRA',5509181905,0.5,true,NOW(), null),
 (999990101005053,999990101005078,7216286,'DOT FOODS',5509181905,0.5,false,NOW(), null),
 (999990101005054,999990101005078,5935689,'MCCORMICK',5509181905,0.5,false,NOW(), null),
 (999990101005055,999990101005079,4092706,'CONAGRA',5509181910,0.47,true,NOW(), null),
 (999990101005056,999990101005079,7216286,'DOT FOODS',5509181910,0.47,false,NOW(), null),
 (999990101005057,999990101005079,5935689,'MCCORMICK',5509181910,0.47,false,NOW(), null),
 (999990101005058,999990101005080,4092706,'CONAGRA',5509181910,0.45,true,NOW(), null),
 (999990101005059,999990101005080,7216286,'DOT FOODS',5509181910,0.45,false,NOW(), null),
 (999990101005060,999990101005080,5935689,'MCCORMICK',5509181910,0.45,false,NOW(), null),
 (999990101005061,999990101005081,4092706,'CONAGRA',5509181910,0.45,true,NOW(), null),
 (999990101005062,999990101005081,7216286,'DOT FOODS',5509181910,0.45,false,NOW(), null),
 (999990101005063,999990101005081,5935689,'MCCORMICK',5509181910,0.45,false,NOW(), null);


INSERT INTO BatchFinishedProduct(id,batchId,productCode, createdat,updatedat)
VALUES
  (999990101005001,999990101005061,4391102, NOW(), null),
  (999990101005002,999990101005062,3401581, NOW(), null),
  (999990101005003,999990101005063,3401581, NOW(), null),
  (999990101005004,999990101005064,3401581, NOW(), null),
  (999990101005005,999990101005065,3401581, NOW(), null),
  (999990101005006,999990101005066,4391102, NOW(), null),
  (999990101005007,999990101005067,4391102, NOW(), null),
  (999990101005008,999990101005068,4391102, NOW(), null),
  (999990101005009,999990101005069,3401581, NOW(), null),
  (999990101005010,999990101005070,3401581, NOW(), null),
  (999990101005011,999990101005071,4391102, NOW(), null),
  (999990101005012,999990101005072,4391102, NOW(), null),
  (999990101005013,999990101005073,4391102, NOW(), null),
  (999990101005014,999990101005074,3401581, NOW(), null),
  (999990101005015,999990101005075,3401581, NOW(), null),
  (999990101005016,999990101005076,3401581, NOW(), null),
  (999990101005017,999990101005077,3401581, NOW(), null),
  (999990101005018,999990101005078,4391102, NOW(), null),
  (999990101005019,999990101005079,4391102, NOW(), null),
  (999990101005020,999990101005080,4391102, NOW(), null),
  (999990101005021,999990101005081,4391102, NOW(), null);
-- @formatter:on



INSERT INTO CuttingYieldModelCopy (oldYieldModelId, createdAt, updatedAt, finishedProductId, pricingModel, packaging,
                                   overhead, sourceLbs, pickupPercent, ingredients)
SELECT y.id            AS oldYieldModelId,
       y.createdAt     AS createdAt,
       y.updatedAt     AS updatedAt,
       p.id            AS finishedProductId,
       y.pricingModel  AS pricingModel,
       y.packaging     AS packaging,
       y.overhead      AS overhead,
       y.sourceLbs     AS sourceLbs,
       y.pickupPercent AS pickupPercent,
       y.ingredients   AS ingredients
FROM CuttingYieldModel y
       INNER JOIN Product p ON y.finishedProductCode = p.code;



INSERT INTO GrindingYieldModelCopy (oldYieldModelId, createdAt, updatedAt, blendId, pricingModel, packaging, overhead,
                                    additives, wastePercentage)
SELECT y.id              AS oldYieldModelId,
       y.createdAt       AS createdAt,
       y.updatedAt       AS updatedAt,
       y.blendId         AS blendId,
       y.pricingModel    AS pricingModel,
       y.packaging       AS packaging,
       y.overhead        AS overhead,
       y.additives       AS additives,
       y.wastePercentage AS wastePercentage
FROM GrindingYieldModel y;




UPDATE CuttingYieldModelCopy
SET labor = (SELECT c.labor
             FROM Cost c,
                  Product p
             WHERE CuttingYieldModelCopy.oldYieldModelId = c.yieldModelId
               AND CuttingYieldModelCopy.finishedProductId = p.id
               AND p.code = c.name
             ORDER BY c.createdAt DESC
             LIMIT 1);



UPDATE GrindingYieldModelCopy
SET labor = (SELECT c.labor
             FROM Cost c,
                  Blend b
             WHERE GrindingYieldModelCopy.oldYieldModelId = c.yieldModelId
               AND GrindingYieldModelCopy.blendId = b.id
               AND b.name = c.name
             ORDER BY c.createdAt DESC
             LIMIT 1);



INSERT INTO AdditiveDependency (createdAt, updatedAt, productId, weight, ownerId)
SELECT a.createdAt    AS createdAt,
       a.updatedAt    AS updatedAt,
       p.id           AS productId,
       a.weight       AS weight,
       cyp.id         AS ownerId
FROM CuttingYieldAdditive a
       INNER JOIN CuttingYieldModel cym on a.yieldmodelid = cym.id
       INNER JOIN CuttingYieldModelCopy cyp on cyp.oldYieldModelId = cym.id
       INNER JOIN Product p ON a.productCode = p.code;




INSERT INTO ByproductDependency (createdAt, updatedAt, productId, yieldPercentage, ownerId, pointsTo)
SELECT b.createdAt       AS createdAt,
       b.updatedAt       AS updatedAt,
       p.id              AS productId,
       b.yieldPercentage AS yieldPercentage,
       cyp.id            AS ownerid,
       'COST'            AS pointsTo
FROM CuttingYieldByproduct b
       INNER JOIN CuttingYieldModel cym on b.yieldmodelid = cym.id
       INNER JOIN CuttingYieldModelCopy cyp on cyp.oldYieldModelId = cym.id
       INNER JOIN Product p ON b.byproductCode = p.code;

UPDATE ByproductDependency
SET dependsOnModelId = (
  SELECT cyp.id
  FROM Cost c,
       Product p,
       ProductGroup g,
       CuttingYieldModelCopy cyp
  WHERE ByproductDependency.productId = p.id
    AND p.productGroupId = g.id
    AND g.name = c.name
    AND c.source = 'PRICING_MODEL'
    AND c.yieldModelId = cyp.oldYieldModelId
  ORDER BY c.createdAt DESC
  LIMIT 1);

UPDATE ByproductDependency
SET pointsTo = 'YIELD_MODEL'
WHERE dependsOnModelId IS NOT NULL;

UPDATE ByproductDependency
SET pointsTo = 'COST'
FROM Cost c,
     Product p
WHERE ByproductDependency.productId = p.id
  AND p.code = c.name
  AND p.productOutput = 'SOURCE'
  AND c.source = 'SUS';




INSERT INTO CuttingSourceDependency (createdAt, updatedAt, productId, ownerId, pointsTo)
SELECT y.createdAt AS createdAt,
       y.updatedAt AS updatedAt,
       p.id        AS productId,
       c.id        AS ownerId,
       'COST'
FROM CuttingYieldModelCopy c
       INNER JOIN CuttingYieldModel y ON c.oldYieldModelId = y.id
       INNER JOIN Product p ON y.sourceProductCode = p.code;

UPDATE CuttingSourceDependency
SET dependsOnModelId = (
  SELECT cyp.id
  FROM Cost c,
       Product p,
       ProductGroup g,
       CuttingYieldModelCopy cyp
  WHERE CuttingSourceDependency.productId = p.id
    AND p.productGroupId = g.id
    AND g.name = c.name
    AND c.source = 'PRICING_MODEL'
    AND c.yieldModelId = cyp.oldYieldModelId
  ORDER BY c.createdAt DESC
  LIMIT 1);
UPDATE CuttingSourceDependency
SET pointsTo = 'YIELD_MODEL'
WHERE dependsOnModelId IS NOT NULL;

UPDATE CuttingSourceDependency
SET pointsTo = 'COST'
FROM Cost c,
     Product p
WHERE CuttingSourceDependency.productId = p.id
  AND p.code = c.name
  AND p.productOutput = 'SOURCE'
  AND c.source = 'SUS';



INSERT INTO GrindingSourceDependency (createdAt, updatedAt, productId, blendPercentage, ownerId, pointsTo)
SELECT s.createdAt       AS createdAt,
       s.updatedAt       AS updatedAt,
       p.id              AS productId,
       s.blendPercentage AS blendPercentage,
       gyp.id            AS ownerId,
       'COST'
FROM GrindingYieldModelSourceProducts s
       INNER JOIN grindingyieldmodel gym on s.grindingyieldmodelid = gym.id
       INNER JOIN grindingyieldmodelcopy gyp on gym.id = gyp.oldYieldModelId
       INNER JOIN Product p ON s.sourceProductCode = p.code;

UPDATE GrindingSourceDependency
SET dependsOnModelId = (
  SELECT gyp.oldYieldModelId
  FROM Cost c,
       Product p,
       ProductGroup g,
       GrindingYieldModelCopy gyp
  WHERE GrindingSourceDependency.productId = p.id
    AND p.productGroupId = g.id
    AND g.name = c.name
    AND c.source = 'PRICING_MODEL'
    AND c.yieldModelId = gyp.oldYieldModelId
  ORDER BY c.createdAt DESC
  LIMIT 1);
UPDATE GrindingSourceDependency
SET pointsTo = 'YIELD_MODEL'
WHERE dependsOnModelId IS NOT NULL;

UPDATE GrindingSourceDependency
SET pointsTo = 'COST'
FROM Cost c,
     Product p
WHERE GrindingSourceDependency.productId = p.id
  AND p.code = c.name
  AND p.productOutput = 'SOURCE'
  AND c.source = 'SUS';
