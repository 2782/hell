CREATE OR REPLACE FUNCTION truncateAll() RETURNS void AS
$$
DECLARE
  full_name TEXT;
  statements CURSOR FOR
    SELECT table_schema, table_name
    FROM information_schema.tables
    WHERE table_schema IN ('public', 'reporting', 'dummyprinting', 'dummysus');
BEGIN
  FOR stmt IN statements
    LOOP
      full_name := quote_ident(stmt.table_schema) || '.' || quote_ident(stmt.table_name);
      CONTINUE WHEN full_name IN ('public.databasechangelog', 'public.databasechangeloglock');

      PERFORM 1
      FROM information_schema.views
      WHERE table_schema = stmt.table_schema
        AND table_name = stmt.table_name;
      IF FOUND THEN
        CONTINUE;
      END IF;

      EXECUTE 'TRUNCATE TABLE '
        || quote_ident(stmt.table_schema)
        || '.'
        || quote_ident(stmt.table_name)
        || ' RESTART IDENTITY CASCADE;';
    END LOOP;
END;
$$ LANGUAGE plpgsql;

SET client_min_messages TO WARNING;
SELECT truncateAll();

DROP FUNCTION truncateAll();

ALTER SEQUENCE product_id_seq RESTART WITH 100;
