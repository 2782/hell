#!/usr/bin/env bash

# Run this script in project root directory
PROJECT_HOME=$(cd `dirname $0`/../ && pwd)

docker run --rm -t \
--user=995:992 \
-v ${PROJECT_HOME}/api-test:/opt/app \
-w /opt/app \
sysco/prime:node-8.7 bash -c "npm install && ./run_api_testing.sh -H syscodev"
