module.exports = {
  parser: 'babel-eslint',
  env: {
    es6: true,
    node: true,
    jest: true
  },
  globals: {
    window: true,
    document: true,
    match: true,
    fail: true,
    mount: true,
    jestExpect: true,
    FileReader: true,
    waitForAsyncTasks: true,
    FormData: true,
    Blob: true
  },
  extends: ['eslint:recommended', 'plugin:react/recommended', 'prettier'],
  parserOptions: {
    ecmaFeatures: {
      experimentalObjectRestSpread: true,
      jsx: true
    },
    sourceType: 'module'
  },
  plugins: ['react', 'filenames'],
  rules: {
    quotes: ['error', 'single', { avoidEscape: true, allowTemplateLiterals: false }],
    'react/prop-types': ['warn'],
    'no-console': 1,
    'filenames/match-exported': 2
  }
};
