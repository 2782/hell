import React from 'react';
import { Form } from 'semantic-ui-react';
import { Field, FormSection } from 'redux-form';
import FormElement from '../../shared/FormElement';
import { normalizeToTwoDecimalPlaces } from '../../shared/components/product/normalizer';
import {
  positivePrice,
  positiveWeight,
  required,
  number,
  positiveNumber,
  exactLength
} from '../../shared/validation/formFieldValidations';
import PropTypes from 'prop-types';

export const exactLength7 = exactLength(7);

const RetailSpecificFields = ({ productCategory, tarePackageOptions }) => {
  return (
    <FormSection name='retailSpecific'>
      <Form.Group widths='equal'>
        <Field
          component={FormElement}
          name='tare'
          as={Form.Select}
          type='text'
          fluid
          label='Retail Tare'
          upward
          options={tarePackageOptions}
          validate={[required]}
        />
      </Form.Group>
      <Form.Group widths='equal'>
        <Field
          component={FormElement}
          name='price'
          as={Form.Input}
          type='text'
          label='Retail Price'
          normalize={normalizeToTwoDecimalPlaces}
          validate={[required, positivePrice]}
          width={4}
        />
        <Field
          component={FormElement}
          name='minWeight'
          as={Form.Input}
          type='text'
          label='Retail Min Lbs'
          normalize={normalizeToTwoDecimalPlaces}
          validate={[required, positiveWeight]}
          width={4}
        />
        {productCategory !== 'FIXED' ? (
          <Field
            component={FormElement}
            name='maxWeight'
            as={Form.Input}
            type='text'
            label='Retail Max Lbs'
            normalize={normalizeToTwoDecimalPlaces}
            validate={[required, positiveWeight]}
            width={4}
          />
        ) : null}
      </Form.Group>
      <Form.Group>
        <Field
          component={FormElement}
          name='retailNumber'
          as={Form.Input}
          type='text'
          label='Retail Number'
          validate={[required, number, exactLength7, positiveNumber]}
          width={8}
        />
      </Form.Group>
    </FormSection>
  );
};

RetailSpecificFields.propTypes = {
  showFields: PropTypes.bool,
  productCategory: PropTypes.string,
  tarePackageOptions: PropTypes.arrayOf(PropTypes.object)
};

export default RetailSpecificFields;
