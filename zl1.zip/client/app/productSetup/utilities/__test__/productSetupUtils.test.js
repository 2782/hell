import { generatePortionRoomTableOptions } from '../productSetupUtils';
import portionRoomTableSummaryFactory from '../../../../test-factories/portionRoomTableSummaryFactory';

test('should generate menu options from table data', () => {
  let portionRoomTablesData = [
    portionRoomTableSummaryFactory.build({
      tableId: 1,
      tableCode: 34,
      stationId: 21421402141,
      stationCode: 90,
      stationName: 'JOHN',
      room: 'A',
      tableDescription: 'BEEF'
    }),
    portionRoomTableSummaryFactory.build({
      tableId: 2,
      tableCode: 35,
      stationId: 21421402141,
      stationCode: 90,
      stationName: 'JOHN',
      room: 'A',
      tableDescription: 'CHICKEN'
    }),
    portionRoomTableSummaryFactory.build({
      tableId: 3,
      tableCode: 36,
      stationId: 21421402142,
      stationCode: 91,
      stationName: 'QB CUTTER 2',
      room: 'B',
      tableDescription: 'PORK'
    })
  ];

  const formattedOptions = generatePortionRoomTableOptions(portionRoomTablesData, 'A');

  jestExpect(formattedOptions.length).toEqual(2);
  jestExpect(formattedOptions).toEqual([
    { key: 0, text: '34 - BEEF', value: 34 },
    { key: 1, text: '35 - CHICKEN', value: 35 }
  ]);
});
