import productSetupReducer from '../productSetupReducer';
import {
  PRODUCT_SETUP_ALLERGENS_RETRIEVED,
  PRODUCT_SETUP_GET_ALL_PIECES_PACKAGES
} from '../../actions/productSetupActionTypes';
import { PiecesPackageFactory } from '../../../../test-factories/tarePackageFactory';
import AllergenFactory from '../../../../test-factories/allergenFactory';

describe('productSetupReducer', () => {
  let initState;

  beforeEach(() => {
    initState = {
      piecesPackages: [],
      allergens: []
    };
  });

  test('should return init state when action not defined', () => {
    jestExpect(productSetupReducer(initState, { type: 'ACTION-NOT-DEFINED', payload: {} })).toEqual(
      initState
    );
  });

  test('should return new state when dispatch PRODUCT_SETUP_GET_ALL_PIECES_PACKAGES action', () => {
    const piecesPackages = [PiecesPackageFactory.build(), PiecesPackageFactory.build()];

    const expectedState = { ...initState, piecesPackages: piecesPackages };

    jestExpect(
      productSetupReducer(initState, {
        type: PRODUCT_SETUP_GET_ALL_PIECES_PACKAGES,
        payload: piecesPackages
      })
    ).toEqual(expectedState);
  });

  test('should return new state when dispatch PRODUCT_SETUP_ALLERGENS_RETRIEVED action', () => {
    const allergens = [
      AllergenFactory.build(),
      AllergenFactory.build({ name: 'Shellfish', displayName: 'SHELLFISH' })
    ];

    const expectedState = { ...initState, allergens };

    jestExpect(
      productSetupReducer(initState, {
        type: PRODUCT_SETUP_ALLERGENS_RETRIEVED,
        payload: allergens
      })
    ).toEqual(expectedState);
  });
});
