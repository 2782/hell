import piecesPackagesResources from '../../../shared/api/piecesPackagesResources';
import productResources from '../../../shared/api/productResources';
import { PiecesPackageFactory } from '../../../../test-factories/tarePackageFactory';
import AllergenFactory from '../../../../test-factories/allergenFactory';
import { getAllergens, getAllPiecesPackages } from '../productSetupActions';
import {
  PRODUCT_SETUP_ALLERGENS_RETRIEVED,
  PRODUCT_SETUP_GET_ALL_PIECES_PACKAGES
} from '../productSetupActionTypes';

jest.mock('../../../shared/api/piecesPackagesResources');
jest.mock('../../../shared/api/productResources');

describe('productSetupActions', () => {
  test('should dispatch action on successful callback for getAllPiecesPackages', () => {
    const piecesPackages = [PiecesPackageFactory.build()];
    const dispatch = jest.fn();
    piecesPackagesResources.getAllPiecesPackages.mockImplementation(fn =>
      fn({
        data: piecesPackages
      })
    );

    getAllPiecesPackages()(dispatch);

    jestExpect(dispatch).toBeCalledWith({
      type: PRODUCT_SETUP_GET_ALL_PIECES_PACKAGES,
      payload: piecesPackages
    });
  });

  test('should dispatch action on successful callback for getAllergens', async () => {
    const allergens = [
      AllergenFactory.build(),
      AllergenFactory.build({ name: 'Eggs', displayName: 'EGGS' })
    ];
    const dispatch = jest.fn();

    productResources.getAllergens.mockResolvedValue({
      data: allergens
    });

    await getAllergens()(dispatch);

    jestExpect(dispatch).toBeCalledWith({
      type: PRODUCT_SETUP_ALLERGENS_RETRIEVED,
      payload: allergens
    });
  });
});
