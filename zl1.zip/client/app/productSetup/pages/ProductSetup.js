import React from 'react';
import { connect } from 'react-redux';
import { normalizeProductCode } from '../../shared/components/product/normalizer';
import { Button, Divider, Form, Grid, Icon } from 'semantic-ui-react';
import { bindActionCreators } from 'redux';
import FormElement from '../../shared/FormElement';
import { change, clearFields, Field, FormSection, formValueSelector, reduxForm } from 'redux-form';
import PropTypes from 'prop-types';
import ValidateSubmission, {
  validateMinMaxRetailWeight
} from '../components/productSetupValidator';
import _ from 'lodash';
import { getRooms, getTables } from '../../settings/actions/settingsActions';
import { TAB_SHIFTTAB_F4_F2 } from '../../shared/components/pageFooters';
import { PRODUCT_SETUP } from '../../shared/components/pageTitles';
import { setHeaderAndFooter } from '../../shared/actions/actions';
import { getAllTarePackages } from '../../settings/actions/tarePackagesActions';
import { getAllPiecesPackages, getAllergens } from '../actions/productSetupActions';
import CheckBox from '../../shared/components/CheckBox';
import { GrindSpecificFields } from '../components/GrindSpecificFields';
import { CutSpecificFields } from '../components/CutSpecificFields';
import RetailSpecificFields from '../components/RetailSpecificFields';
import ProductDuplicate from '../../shared/components/product/ProductDuplicate';
import {
  getProductPromise,
  setProductExistTo,
  removeProduct,
  setupProduct
} from '../../shared/components/product/actionsDuplicate';
import { maxLength } from '../../shared/validation/formFieldValidations';
import { generatePortionRoomTableOptions } from '../utilities/productSetupUtils';
import { NOT_A_PRODUCT_CODE } from '../../../config/errorMessage';

export const PRODUCT_SETUP_FORM = 'productSetup';
export const maxLength50 = maxLength(50);

export const specialDietOptions = [
  {
    key: 0,
    text: 'Halal',
    value: 'HALAL'
  },
  {
    key: 1,
    text: 'Kosher',
    value: 'KOSHER'
  },
  {
    key: 2,
    text: 'None',
    value: 'NONE'
  }
];

export const byproductOnlyOptions = [
  {
    key: 0,
    text: 'Yes',
    value: true
  },
  {
    key: 1,
    text: 'No',
    value: false
  }
];

export const RenderWeightInput = ({ product }) => {
  if (_.isEmpty(product) || product.category === 'CATCH') {
    return (
      <div className={'six wide field product-weight-group'}>
        <Field
          as={Form.Input}
          component={FormElement}
          name='minWeight'
          label='min weight'
          className='product-min-weight'
          pid='product-min-weight'
          width={8}
        />
        <Field
          as={Form.Input}
          component={FormElement}
          name='maxWeight'
          label='max weight'
          className='product-max-weight'
          pid='product-max-weight'
          width={8}
        />
      </div>
    );
  } else {
    return (
      <Field
        as={Form.Input}
        component={FormElement}
        name='fixWeight'
        label='fix weight'
        className='product-fix-weight'
        pid='product-fix-weight'
        width={3}
      />
    );
  }
};

export const SaveButton = ({ productCodeExists, submitting, pristine }) => {
  const disabled = !productCodeExists || pristine || submitting;

  return (
    <Button primary size={'large'} loading={submitting} disabled={disabled}>
      <Icon className='icon-save' />
      Save
    </Button>
  );
};
SaveButton.propTypes = {
  productCodeExists: PropTypes.bool,
  submitting: PropTypes.bool,
  pristine: PropTypes.bool
};

export class ProductSetupPage extends React.Component {
  constructor(props) {
    super(props);

    this.submit = this.submit.bind(this);
    this.handleChange = this.handleChange.bind(this);
    this.handleOnBlur = this.handleOnBlur.bind(this);
  }

  componentDidMount() {
    const {
      getRooms,
      getTables,
      getAllTarePackages,
      getAllPiecesPackages,
      getAllergens,
      setHeaderAndFooter
    } = this.props;

    getRooms();
    getTables();
    getAllTarePackages();
    getAllPiecesPackages();
    getAllergens();
    setHeaderAndFooter({
      header: PRODUCT_SETUP,
      footer: TAB_SHIFTTAB_F4_F2
    });
  }

  componentWillUnmount() {
    const {
      product: { code },
      productCodeExists,
      removeProduct
    } = this.props;
    if (productCodeExists) {
      removeProduct(code);
    }
  }

  componentDidUpdate(prevProps) {
    const { selectedRoomValue, clearTableValue } = this.props;
    if (
      prevProps.selectedRoomValue &&
      (!selectedRoomValue || prevProps.selectedRoomValue !== selectedRoomValue)
    ) {
      clearTableValue();
    }
  }

  handleOnBlur(event, productCode) {
    const { getProductPromise, setProductExistTo } = this.props;

    if (!_.isEmpty(productCode)) {
      getProductPromise(productCode, () => setProductExistTo(productCode, false));
    }
  }

  handleChange(event, productCode) {
    const { setProductExistTo } = this.props;
    if (!_.isEmpty(productCode)) {
      setProductExistTo(productCode, true);
    }
  }

  submit(values) {
    const { setupProduct } = this.props;
    ValidateSubmission.validateSubmission(values, this.props);

    return setupProduct(values);
  }

  render() {
    const {
      portionRoomOptions,
      portionRoomTableOptions,
      handleSubmit,
      currentProductFormValue,
      productsExist,
      tarePackageOptions,
      product,
      isGrouped,
      isRetailValue,
      byproductOnlyValue,
      piecesPackageOptions,
      allergenOptions,
      selectedRoomType,
      byproductOnly
    } = this.props;

    return (
      <div className='page-content product-setup-page'>
        <Form size={'large'} pid='product-setup-form' onSubmit={handleSubmit(this.submit)}>
          <Grid>
            <Grid.Row>
              <Grid.Column>
                <Field
                  withRef
                  ref={node => (this.productCodeField = node)}
                  component={ProductDuplicate}
                  name='productCode'
                  pid='product-setup-product-code'
                  label='product #'
                  product={product}
                  normalize={normalizeProductCode}
                  message={
                    _.get(productsExist, currentProductFormValue, true) ? null : NOT_A_PRODUCT_CODE
                  }
                  onBlur={(event, value) => this.handleOnBlur(event, value)}
                  onChange={this.handleChange}
                />
              </Grid.Column>
            </Grid.Row>
          </Grid>

          <Divider hidden />

          <Form.Group>
            <Field
              component={FormElement}
              name='room'
              as={Form.Select}
              options={portionRoomOptions}
              type='text'
              label='Room Description - Room Type'
              width={8}
            />

            <Field
              component={FormElement}
              name='tableCode'
              as={Form.Select}
              options={portionRoomTableOptions}
              type='text'
              label='Table - Description'
              width={8}
            />
          </Form.Group>

          <Divider hidden />

          <Form.Group>
            <Field
              component={FormElement}
              name='tarePackageId'
              as={Form.Select}
              options={tarePackageOptions}
              type='text'
              label='PACKAGING TYPE'
              width={8}
            />

            <Field
              component={FormElement}
              name='piecesPackageId'
              as={Form.Select}
              options={piecesPackageOptions}
              type='text'
              label='PIECES/SUB-PACKAGE'
              width={8}
            />
          </Form.Group>

          <Divider hidden />

          <Form.Group>
            <Field
              component={FormElement}
              name='specialDiet'
              as={Form.Select}
              options={specialDietOptions}
              type='text'
              label='Special Diet'
              width={8}
            />
            <Field
              component={FormElement}
              name='byproductOnly'
              as={Form.Select}
              disabled={byproductOnly || isGrouped}
              options={byproductOnlyOptions}
              type='text'
              label='Byproduct Only'
              width={8}
            />
            {byproductOnlyValue ? (
              <Field
                component={FormElement}
                name='byproductOnlyCost'
                as={Form.Input}
                type='text'
                label='Cost'
                width={8}
              />
            ) : null}
          </Form.Group>

          <Form.Group>
            <RenderWeightInput product={product} />
            <Field
              width={3}
              component={CheckBox}
              label='BONEGUARD'
              name='boneguard'
              pid='product-setup__boneguard'
            />
            <Field
              width={5}
              component={CheckBox}
              label='Allocate Par To Broadline'
              name='allocateParToBroadline'
              pid='product-setup__do-not-allocate-par-to-broadline'
            />
          </Form.Group>

          <Divider hidden />

          <Form.Group>
            <Field
              component={FormElement}
              name='labelProductDescription'
              validate={[maxLength50]}
              as={Form.Input}
              type='text'
              label='Label Product Description'
              width={16}
            />
          </Form.Group>

          <Divider hidden />

          <Form.Group>
            <Field
              component={FormElement}
              name='ingredientsStatement'
              as={Form.TextArea}
              type='text'
              label='Ingredients Statement'
              width={16}
            />
          </Form.Group>

          <Divider hidden />

          <Form.Group>
            <Field
              width={8}
              component={FormElement}
              as={Form.Select}
              multiple
              selection
              options={allergenOptions}
              name='allergens'
              label='Allergens'
              pid='product-setup__allergens-multi-select'
            />
          </Form.Group>

          <Divider hidden />

          {selectedRoomType === 'GRINDING' && (
            <FormSection name={'grindSpecific'} component={GrindSpecificFields} />
          )}
          {selectedRoomType === 'CUTTING' && (
            <FormSection name={'cutSpecific'} component={CutSpecificFields} />
          )}
          <Grid>
            <Grid.Row verticalAlign='top'>
              <Grid.Column width='3'>
                <Field
                  component={CheckBox}
                  label='Retail Item'
                  name='isRetail'
                  pid='product-setup__is-retail-item'
                />
              </Grid.Column>
              <Grid.Column width='13'>
                {isRetailValue && (
                  <RetailSpecificFields
                    productCategory={product.category}
                    tarePackageOptions={tarePackageOptions}
                  />
                )}
              </Grid.Column>
            </Grid.Row>
          </Grid>

          <Divider hidden />

          <SaveButton {...this.props} />
        </Form>
      </div>
    );
  }
}

export const generatePortionRoomOptions = portionRooms => {
  let sortedRooms = _.sortBy(portionRooms, 'description');
  return sortedRooms.map(({ code, description, roomType }, index) => {
    return { key: index, text: `${description} - ${roomType}`, value: code };
  });
};

export const generateTarePackageOptions = tarePackages => {
  return tarePackages.map(
    ({ id, boxType: { boxDescription }, filmType: { filmDescription } }, index) => {
      return { key: index, text: `${boxDescription} - ${filmDescription}`, value: id };
    }
  );
};

export const generatePiecesPackageOptions = piecesPackages => {
  return piecesPackages.map(({ id, description }, index) => {
    return { key: index, text: description, value: id };
  });
};

export const generateAllergenOptions = allergens => {
  return allergens.map(({ name, displayName }, index) => {
    return { key: index, text: displayName, value: name };
  });
};

const findRoomCode = (portionRoomTables, tableCode) => {
  const tableFound = portionRoomTables.find(table => table.tableCode === tableCode);
  return tableFound ? tableFound.room : '';
};

const getGrindSpecific = product => {
  let grindSpecific = {
    packInstructionA: 'Fresh',
    packInstructionB: 'Gas',
    tenderform: false,
    grindSize: '3/32',
    diameter: '',
    thickness: '',
    plateUsed: '',
    casesPerTray: '3'
  };
  if (product && product.grindSpecific) {
    const {
      packInstruction,
      tenderform,
      grindSize,
      diameter,
      thickness,
      plateUsed,
      casesPerTray
    } = product.grindSpecific;
    const packInstructions = _.split(packInstruction, ',');
    grindSpecific = {
      packInstructionA: packInstructions[0] || grindSpecific.packInstructionA,
      packInstructionB: packInstructions[1] || grindSpecific.packInstructionB,
      tenderform,
      grindSize,
      diameter,
      thickness,
      plateUsed,
      casesPerTray: casesPerTray ? casesPerTray : '3'
    };
  }
  return grindSpecific;
};

const getCutSpecific = product => {
  if (product && product.cutSpecific) {
    return product.cutSpecific;
  }
  return {
    tenderized: 'None'
  };
};

const getRetailSpecific = product => {
  const { retailSpecific } = product;

  if (product && !_.isEmpty(retailSpecific)) {
    return {
      ...retailSpecific,
      tare: retailSpecific.tare.id
    };
  }
  return {};
};

ProductSetupPage.propTypes = {
  getRooms: PropTypes.func.isRequired,
  getTables: PropTypes.func.isRequired,
  setHeaderAndFooter: PropTypes.func.isRequired,
  switchTab: PropTypes.func,
  getAllTarePackages: PropTypes.func.isRequired,
  getAllPiecesPackages: PropTypes.func.isRequired,
  getAllergens: PropTypes.func.isRequired,
  portionRoomOptions: PropTypes.array,
  portionRoomTableOptions: PropTypes.array,
  tarePackageOptions: PropTypes.array,
  piecesPackageOptions: PropTypes.array,
  allergenOptions: PropTypes.array,
  selectedTableValue: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  selectedRoomValue: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  selectedRoomType: PropTypes.string,
  selectedPiecesPackageValue: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  productCodeExists: PropTypes.bool,
  byproductOnlyValue: PropTypes.bool,
  submitting: PropTypes.bool,
  pristine: PropTypes.bool,
  handleSubmit: PropTypes.func,
  error: PropTypes.string,
  product: PropTypes.object,
  clearTableValue: PropTypes.func,
  isRetailValue: PropTypes.bool,
  isGrouped: PropTypes.bool,
  invalid: PropTypes.bool,
  removeProduct: PropTypes.func,
  setupProduct: PropTypes.func,
  byproductOnly: PropTypes.bool,
  productsExist: PropTypes.object,
  getProductPromise: PropTypes.func,
  setProductExistTo: PropTypes.func,
  currentProductFormValue: PropTypes.string
};

const selector = formValueSelector(PRODUCT_SETUP_FORM);
const mapStateToProps = state => {
  const portionRooms = state.settingsInfo.rooms;
  const portionRoomTables = state.settingsInfo.tables || [];
  const byproductOnlyValue = selector(state, 'byproductOnly');
  const selectedTableValue = selector(state, 'tableCode');
  const selectedRoomValue = selector(state, 'room');
  const isRetailValue = selector(state, 'isRetail');
  const selectedPiecesPackageValue = selector(state, 'piecesPackageId');

  const currentProductFormValue = selector(state, 'productCode');
  const product = state.productDuplicate.products[currentProductFormValue] || {};
  const productCodeExists = !_.isEmpty(product);
  const isGrouped = !_.isEmpty(product.productGroup);

  const tarePackages = state.tarePackages.tarePackages;
  const piecesPackages = state.productSetup.piecesPackages;
  const allergens = state.productSetup.allergens;
  const selectedRoom = portionRooms
    ? portionRooms.find(room => room.code === selectedRoomValue)
    : null;
  const grindSpecific = getGrindSpecific(product);
  const cutSpecific = getCutSpecific(product);
  const retailSpecific = getRetailSpecific(product);
  const allocateParToBroadline = product.allocateParToBroadline;
  const byproductOnly = _.get(product, 'productOutput', 'FINISHED') === 'BYPRODUCT_ONLY';
  const byProductOnlyCost = byproductOnly ? _.get(product, 'marketCost', '') : '';
  const existingAllergens = _.get(product, 'allergens', []).map(allergen => allergen.name);
  const productsExist = state.productDuplicate.productsExist || {};

  return {
    initialValues: {
      allergens: existingAllergens,
      productCode: currentProductFormValue || product.code,
      room: findRoomCode(portionRoomTables, _.get(product, 'table.tableCode', '')),
      specialDiet: _.get(product, 'specialDiet', ''),
      tableCode: _.get(product, 'table.tableCode', ''),
      tarePackageId: _.get(product, 'tarePackage.id', ''),
      piecesPackageId: _.get(product, 'piecesPackage.id', ''),
      byproductOnly: byproductOnly,
      byproductOnlyCost: byProductOnlyCost,
      boneguard: !!product.boneguard,
      minWeight: _.get(product, 'minWeight', ''),
      maxWeight: _.get(product, 'maxWeight', ''),
      fixWeight: _.get(product, 'minWeight', ''),
      allocateParToBroadline: !!allocateParToBroadline,
      ingredientsStatement: _.get(product, 'ingredientsStatement', ''),
      labelProductDescription: _.get(product, 'labelProductDescription', ''),
      isRetail: !_.isEmpty(retailSpecific),
      grindSpecific,
      cutSpecific,
      retailSpecific
    },
    productCodeExists,
    portionRoomOptions: portionRooms ? generatePortionRoomOptions(portionRooms) : [],
    portionRoomTableOptions: selectedRoomValue
      ? generatePortionRoomTableOptions(portionRoomTables, selectedRoomValue)
      : [],
    tarePackageOptions: tarePackages ? generateTarePackageOptions(tarePackages) : [],
    piecesPackageOptions: piecesPackages ? generatePiecesPackageOptions(piecesPackages) : [],
    allergenOptions: allergens ? generateAllergenOptions(allergens) : [],
    byproductOnlyValue,
    selectedTableValue,
    selectedRoomValue,
    isRetailValue,
    selectedRoomType: selectedRoom ? selectedRoom.roomType : '',
    selectedPiecesPackageValue,
    product,
    isGrouped,
    byproductOnly,
    productsExist,
    currentProductFormValue
  };
};

const mapDispatchToProps = dispatch =>
  bindActionCreators(
    {
      getRooms,
      getTables,
      getAllTarePackages,
      getAllPiecesPackages,
      getAllergens,
      setupProduct,
      removeProduct,
      setHeaderAndFooter,
      clearTableValue: () => {
        return dispatch(change(PRODUCT_SETUP_FORM, 'tableCode', ''));
      },
      getProductPromise,
      setProductExistTo
    },
    dispatch
  );

const asyncValidate = ({ productCode }, dispatch, props) => {
  if (!_.isEmpty(productCode)) {
    return props.getProductPromise(productCode).catch(() => {
      return { productCode: 'Invalid Item Number' };
    });
  }
  return Promise.resolve();
};

const shouldAsyncValidate = ({ syncValidationPasses, trigger }) => {
  if (!syncValidationPasses) {
    return false;
  }
  switch (trigger) {
    case 'blur':
      return true;
    case 'submit':
      return false; // never async validate on submit (only on blur)
    default:
      return false;
  }
};

const onSubmitSuccess = (result, dispatch, props) => {
  const {
    form,
    product: { code }
  } = props;

  dispatch(
    clearFields(
      form,
      false,
      false,
      'productCode',
      'tableCode',
      'room',
      'tarePackageId',
      'piecesPackageId',
      'boneguard'
    )
  );

  dispatch(removeProduct(code));
};

const ProductSetup = connect(
  mapStateToProps,
  mapDispatchToProps
)(
  reduxForm({
    form: PRODUCT_SETUP_FORM,
    enableReinitialize: true,
    asyncValidate,
    shouldAsyncValidate,
    asyncBlurFields: ['productCode'],
    validate: validateMinMaxRetailWeight,
    onSubmitSuccess
  })(ProductSetupPage)
);

export default ProductSetup;
