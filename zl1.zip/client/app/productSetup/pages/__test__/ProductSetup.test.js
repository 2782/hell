import React from 'react';
import { createReduxStore } from '../../../store';
import ProductSetup, { ProductSetupPage, RenderWeightInput, SaveButton } from '../ProductSetup';
import { mount, shallow } from 'enzyme';
import { Field } from 'redux-form';
import { Provider } from 'react-redux';
import semanticUI from '../../../../test-helpers/semantic-ui';
import tarePackageFactory, {
  PiecesPackageFactory
} from '../../../../test-factories/tarePackageFactory';
import AllergenFactory from '../../../../test-factories/allergenFactory';
import portionRoomTableSummaryFactory, {
  portionRoomTableSummaryFactoryForChicken,
  portionRoomTableSummaryFactoryForPork
} from '../../../../test-factories/portionRoomTableSummaryFactory';
import { Button } from 'semantic-ui-react';
import productFactory, { PRODUCT_1 } from '../../../../test-factories/productFactory';
import { PRODUCT_SETUP } from '../../../shared/components/pageTitles';
import { TAB_SHIFTTAB_F4_F2 } from '../../../shared/components/pageFooters';
import { GrindSpecificFields } from '../../components/GrindSpecificFields';
import { CutSpecificFields } from '../../components/CutSpecificFields';
import RetailSpecificFields from '../../components/RetailSpecificFields';
import productResources from '../../../shared/api/productResources';
import tarePackageResources from '../../../shared/api/tarePackagesResources';
import retailSpecificFactory from '../../../../test-factories/retailSpecificFactory';
import portionRoomFactory from '../../../../test-factories/portionRoomFactory';
import productGroupFactory from '../../../../test-factories/productGroupFactory';
import settingsResources from '../../../shared/api/settingsResources';

jest.mock('../../../shared/api/productResources');
jest.mock('../../../shared/api/settingsResources');
jest.mock('../../../shared/api/piecesPackagesResources');
jest.mock('../../../shared/api/tarePackagesResources');
jest.mock('../../../shared/api/settingsResources');

const fillAllFields = async form => {
  semanticUI.changeInput(form, 'productCode', '0078889');

  await waitForAsyncTasks();
  form = form.update();

  semanticUI.selectOption(form, 'room', 0);
  semanticUI.selectOption(form, 'tableCode', 0);
  semanticUI.selectOption(form, 'tarePackageId', 0);
  semanticUI.selectOption(form, 'piecesPackageId', 0);
  semanticUI.selectOption(form, 'specialDiet', 0);
  semanticUI.changeInput(form, 'boneguard', false);
  semanticUI.changeInput(form, 'minWeight', 0.4);
  semanticUI.changeInput(form, 'maxWeight', 5.0);
  semanticUI.changeInput(form, 'labelProductDescription', 'Tasty chicken');
  semanticUI.changeInput(form, 'allocateParToBroadline', true);
};

describe('ProductSetup', () => {
  let reduxStore;
  let portionRoomData = [
    portionRoomFactory.build({ code: 'A', description: 'Room A', roomType: 'CUTTING' }),
    portionRoomFactory.build({ code: 'B', description: 'Room B', roomType: 'CUTTING' }),
    portionRoomFactory.build({ code: 'C', description: 'Room C', roomType: 'CUTTING' }),
    portionRoomFactory.build({ code: 'D', description: 'Room D', roomType: 'GRINDING' })
  ];

  let portionRoomTablesData = [
    portionRoomTableSummaryFactory.build(),
    portionRoomTableSummaryFactoryForChicken,
    portionRoomTableSummaryFactoryForPork
  ];

  let tarePackagesData = [tarePackageFactory.build()];

  let piecesPackagesData = [PiecesPackageFactory.build(), PiecesPackageFactory.build()];

  let allergensData = [
    AllergenFactory.build(),
    AllergenFactory.build({ name: 'EGGS', displayName: 'Eggs' })
  ];

  const initialState = {
    settingsInfo: {
      rooms: portionRoomData,
      tables: portionRoomTablesData
    },
    tarePackages: {
      tarePackages: tarePackagesData
    },
    productSetup: {
      piecesPackages: piecesPackagesData,
      allergens: allergensData
    }
  };

  beforeEach(() => {
    reduxStore = createReduxStore(initialState);
    tarePackageResources.getAllTarePackages.mockImplementation(callback =>
      callback({ data: tarePackagesData })
    );
    productResources.getAllergens.mockResolvedValue({
      data: allergensData
    });

    settingsResources.getRooms.mockImplementation(() => Promise.resolve({ data: portionRoomData }));
  });

  afterEach(() => {
    productResources.getProductInfoPromise.mockReset();
    tarePackageResources.getAllTarePackages.mockReset();
    productResources.getAllergens.mockReset();
  });

  test('should render mapping fields', () => {
    const wrapper = mount(
      <Provider store={createReduxStore({})}>
        <ProductSetup />
      </Provider>
    );

    jestExpect(semanticUI.getInputValue(wrapper, 'productCode')).toEqual('');
    jestExpect(semanticUI.getSelectValue(wrapper, 'room')).toEqual(undefined);
    jestExpect(semanticUI.getSelectValue(wrapper, 'tableCode')).toEqual(undefined);
    jestExpect(semanticUI.getSelectValue(wrapper, 'tarePackageId')).toEqual(undefined);
    jestExpect(semanticUI.getSelectValue(wrapper, 'piecesPackageId')).toEqual(undefined);
    jestExpect(semanticUI.getSelectValue(wrapper, 'specialDiet')).toEqual(undefined);
    jestExpect(semanticUI.getInputValue(wrapper, 'boneguard')).toEqual(undefined);
    jestExpect(semanticUI.getInputValue(wrapper, 'minWeight')).toEqual('');
    jestExpect(semanticUI.getInputValue(wrapper, 'maxWeight')).toEqual('');
    jestExpect(semanticUI.getSelectValue(wrapper, 'byproductOnly')).toEqual(false);
    jestExpect(semanticUI.getInputValue(wrapper, 'labelProductDescription')).toEqual('');
    jestExpect(semanticUI.getInputValue(wrapper, 'allocateParToBroadline')).toEqual(undefined);
    jestExpect(semanticUI.getSelectValue(wrapper, 'allergens')).toEqual(undefined);
  });

  test('should call get Rooms, Tables, getAllTarePackages, getAllPiecesPackages and setHeaderAndFooter upon mount', () => {
    let getRooms = jest.fn();
    let getTables = jest.fn();
    let setHeaderAndFooter = jest.fn();
    let getAllTarePackages = jest.fn();
    let getAllPiecesPackages = jest.fn();
    let getAllergens = jest.fn();

    const wrapper = new ProductSetupPage({
      getRooms,
      getTables,
      getAllTarePackages,
      setHeaderAndFooter,
      getAllPiecesPackages,
      getAllergens
    });

    wrapper.componentDidMount();

    jestExpect(getRooms).toBeCalledTimes(1);

    jestExpect(getTables).toBeCalledTimes(1);
    jestExpect(setHeaderAndFooter).toBeCalledWith({
      header: PRODUCT_SETUP,
      footer: TAB_SHIFTTAB_F4_F2
    });
    jestExpect(getAllergens).toBeCalled();
    jestExpect(getAllTarePackages).toBeCalled();
    jestExpect(getAllPiecesPackages).toBeCalled();
  });

  test('should populate all the drop downs', () => {
    const wrapper = mount(
      <Provider store={reduxStore}>
        <ProductSetup />
      </Provider>
    );

    const listOfOptions = semanticUI.getDropDownSelectionOptionsText(wrapper, 'room');
    const dietOptions = semanticUI.getDropDownSelectionOptionsText(wrapper, 'specialDiet');
    const tarePackageOptions = semanticUI.getDropDownSelectionOptionsText(wrapper, 'tarePackageId');
    const piecesPackageOptions = semanticUI.getDropDownSelectionOptionsText(
      wrapper,
      'piecesPackageId'
    );
    const byproductOnlyOptions = semanticUI.getDropDownSelectionOptionsText(
      wrapper,
      'byproductOnly'
    );
    const allergenOptions = semanticUI.getDropDownSelectionOptionsText(wrapper, 'allergens');

    jestExpect(tarePackageOptions).toEqual(['this is a box - this is a film']);
    jestExpect(listOfOptions).toEqual([
      'Room A - CUTTING',
      'Room B - CUTTING',
      'Room C - CUTTING',
      'Room D - GRINDING'
    ]);
    jestExpect(dietOptions).toEqual(['Halal', 'Kosher', 'None']);
    jestExpect(piecesPackageOptions).toEqual(piecesPackagesData.map(data => data.description));
    jestExpect(byproductOnlyOptions).toEqual(['Yes', 'No']);
    jestExpect(allergenOptions).toEqual(allergensData.map(data => data.displayName));
  });

  test('selecting a room should show tables in a dropdown for that room', () => {
    const wrapper = mount(
      <Provider store={reduxStore}>
        <ProductSetup />
      </Provider>
    );

    semanticUI.selectOption(wrapper, 'room', 0);

    const listOfOptions = semanticUI.getDropDownSelectionOptionsText(wrapper, 'tableCode');

    jestExpect(listOfOptions).toEqual(['34 - BEEF', '35 - CHICKEN']);
  });

  test('should show invalid product message if entered product is invalid', async () => {
    productResources.getProductInfoPromise.mockRejectedValueOnce();

    const form = mount(
      <Provider store={createReduxStore({})}>
        <ProductSetup shouldAsyncValidate={() => false} />
      </Provider>
    );

    await waitForAsyncTasks(form);

    semanticUI.changeInput(form, 'productCode', '4102218');

    await waitForAsyncTasks(form);

    jestExpect(semanticUI.findErrorLabels(form)).toHaveLength(1);
    jestExpect(semanticUI.findErrorLabels(form)).toHaveText('Invalid Item Number');
  });

  test('should call getPortionRoomTables when an onChange happens', () => {
    let clearTable = jest.fn();
    const wrapper = new ProductSetupPage({
      clearTableValue: clearTable,
      selectedRoomValue: 'foo'
    });

    wrapper.componentDidUpdate({ selectedRoomValue: 'bar' });

    jestExpect(clearTable).toBeCalledTimes(1);
  });

  describe('retail specific fields', () => {
    test('should initialize with retail specific fields and values showing', async () => {
      tarePackageResources.getAllTarePackages.mockImplementation(callback =>
        callback({ data: tarePackagesData })
      );
      const retailSpecificData = retailSpecificFactory.build();
      productResources.getProductInfoPromise.mockResolvedValue({
        data: productFactory.build({ retailSpecific: retailSpecificData })
      });

      const wrapper = mount(
        <Provider store={reduxStore}>
          <ProductSetup />
        </Provider>
      );

      semanticUI.changeInput(wrapper, 'productCode', '0000507');

      await waitForAsyncTasks();
      wrapper.update();

      jestExpect(
        wrapper
          .find('form')
          .find(RetailSpecificFields)
          .exists()
      ).toEqual(true);

      const getFormSelectionHtml = createHtmlSelector(wrapper);

      jestExpect(semanticUI.getInputValue(wrapper, 'retailSpecific.price')).toEqual(
        retailSpecificData.price
      );
      jestExpect(getFormSelectionHtml('retailSpecific.tare')).toEqual(
        'this is a box - this is a film'
      );
      jestExpect(semanticUI.getInputValue(wrapper, 'retailSpecific.minWeight')).toEqual(
        retailSpecificData.minWeight
      );
      jestExpect(semanticUI.getInputValue(wrapper, 'retailSpecific.maxWeight')).toEqual(
        retailSpecificData.maxWeight
      );
      jestExpect(semanticUI.getInputValue(wrapper, 'retailSpecific.retailNumber')).toEqual(
        retailSpecificData.retailNumber
      );
    });

    test('should render all retail specific mapping fields from retail flag for catch weight item', async () => {
      productResources.getProductInfoPromise.mockResolvedValue({
        data: productFactory.build({
          code: '0078889',
          category: 'CATCH'
        })
      });

      const wrapper = mount(
        <Provider store={reduxStore}>
          <ProductSetup />
        </Provider>
      );

      semanticUI.changeInput(wrapper, 'productCode', '0078889');

      await waitForAsyncTasks();
      wrapper.update();

      semanticUI.changeInput(wrapper, 'isRetail', true);

      await waitForAsyncTasks();
      wrapper.update();

      jestExpect(
        wrapper
          .find('form')
          .find(RetailSpecificFields)
          .exists()
      ).toBeTruthy();
      jestExpect(semanticUI.doesInputExist(wrapper, 'retailSpecific.price')).toEqual(true);
      jestExpect(semanticUI.doesSelectExist(wrapper, 'retailSpecific.tare')).toEqual(true);
      jestExpect(semanticUI.doesInputExist(wrapper, 'retailSpecific.minWeight')).toEqual(true);
      jestExpect(semanticUI.doesInputExist(wrapper, 'retailSpecific.maxWeight')).toEqual(true);
      jestExpect(semanticUI.doesInputExist(wrapper, 'retailSpecific.retailNumber')).toEqual(true);

      semanticUI.changeInput(wrapper, 'isRetail', false);
      jestExpect(
        wrapper
          .find('form')
          .find(RetailSpecificFields)
          .exists()
      ).toBeFalsy();
    });

    test('should render retail specific mapping fields w/o maxWeight from retail flag for fixed weight item', async () => {
      productResources.getProductInfoPromise.mockResolvedValue({
        data: productFactory.build({
          code: '0078889',
          category: 'FIXED'
        })
      });

      const wrapper = mount(
        <Provider store={reduxStore}>
          <ProductSetup />
        </Provider>
      );

      semanticUI.changeInput(wrapper, 'productCode', '0078889');

      await waitForAsyncTasks();
      wrapper.update();

      semanticUI.changeInput(wrapper, 'isRetail', true);

      jestExpect(semanticUI.doesInputExist(wrapper, 'retailSpecific.price')).toEqual(true);
      jestExpect(semanticUI.doesSelectExist(wrapper, 'retailSpecific.tare')).toEqual(true);
      jestExpect(semanticUI.doesInputExist(wrapper, 'retailSpecific.minWeight')).toEqual(true);
      jestExpect(semanticUI.doesInputExist(wrapper, 'retailSpecific.maxWeight')).toEqual(false);
      jestExpect(semanticUI.doesInputExist(wrapper, 'retailSpecific.retailNumber')).toEqual(true);
    });

    test('should normalize all retail specific fields to two decimal places', () => {
      const wrapper = mount(
        <Provider store={reduxStore}>
          <ProductSetup />
        </Provider>
      );

      semanticUI.changeInput(wrapper, 'isRetail', true);

      semanticUI.changeInput(wrapper, 'retailSpecific.price', '123.456');
      semanticUI.selectOption(wrapper, 'retailSpecific.tare', 0);
      semanticUI.changeInput(wrapper, 'retailSpecific.minWeight', '4.1');
      semanticUI.changeInput(wrapper, 'retailSpecific.maxWeight', '5.000002');

      jestExpect(semanticUI.getInputValue(wrapper, 'retailSpecific.price')).toEqual('123.46');
      jestExpect(semanticUI.getHtmlSelection(wrapper, 'retailSpecific.tare')).toEqual(
        'this is a box - this is a film'
      );
      jestExpect(semanticUI.getInputValue(wrapper, 'retailSpecific.minWeight')).toEqual('4.10');
      jestExpect(semanticUI.getInputValue(wrapper, 'retailSpecific.maxWeight')).toEqual('5.00');
    });
  });

  describe('byproduct only', () => {
    beforeEach(() => {
      productResources.setupProduct.mockReset();
    });

    test('should not render byproduct cost field when byproductOnly is false', () => {
      const wrapper = mount(
        <Provider store={reduxStore}>
          <ProductSetup />
        </Provider>
      );

      jestExpect(semanticUI.getSelectValue(wrapper, 'byproductOnly')).toEqual(false);
      jestExpect(semanticUI.doesInputExist(wrapper, 'byproductOnlyCost')).toEqual(false);
    });

    test('should render byproduct cost field when byproductOnly is true', () => {
      const wrapper = mount(
        <Provider store={reduxStore}>
          <ProductSetup />
        </Provider>
      );

      semanticUI.selectOption(wrapper, 'byproductOnly', 0);

      jestExpect(semanticUI.getSelectValue(wrapper, 'byproductOnly')).toEqual(true);
      jestExpect(semanticUI.doesInputExist(wrapper, 'byproductOnlyCost')).toEqual(true);
    });

    test('should disable byproduct only dropdown when product has product group', async () => {
      productResources.getProductInfoPromise.mockResolvedValue({
        data: productFactory.build({
          code: '0078889',
          productGroup: productGroupFactory.build({})
        })
      });

      let wrapper = mount(
        <Provider store={reduxStore}>
          <ProductSetup />
        </Provider>
      );

      semanticUI.changeInput(wrapper, 'productCode', '0078889');

      await waitForAsyncTasks();
      wrapper = wrapper.update();

      jestExpect(semanticUI.isSelectDisabled(wrapper, 'byproductOnly')).toEqual(true);
    });

    test('should not disable byproduct only dropdown when product has no product group', async () => {
      productResources.getProductInfoPromise.mockResolvedValue({
        data: productFactory.build({
          code: '0078889',
          productGroup: null
        })
      });

      let wrapper = mount(
        <Provider store={reduxStore}>
          <ProductSetup />
        </Provider>
      );

      semanticUI.changeInput(wrapper, 'productCode', '0078889');

      await waitForAsyncTasks();
      wrapper = wrapper.update();

      jestExpect(semanticUI.isSelectDisabled(wrapper, 'byproductOnly')).toEqual(false);
    });

    test('should submit both cost and byproduct only when submitting and byproductOnly is true', async () => {
      productResources.getProductInfoPromise.mockResolvedValue({
        data: productFactory.build({
          code: '0078889'
        })
      });
      productResources.setupProduct.mockResolvedValue({});

      let form = mount(
        <Provider store={reduxStore}>
          <ProductSetup />
        </Provider>
      );

      await fillAllFields(form);

      semanticUI.selectOption(form, 'byproductOnly', 0);
      semanticUI.changeInput(form, 'byproductOnlyCost', 1.25);

      form.find('form').simulate('submit');

      jestExpect(productResources.setupProduct).toBeCalledWith(
        jestExpect.objectContaining({
          byproductOnly: true,
          byproductOnlyCost: '1.25'
        })
      );
    });

    test('should submit allergens when allergens are selected', async () => {
      productResources.getProductInfoPromise.mockResolvedValue({
        data: productFactory.build({
          code: '0078889'
        })
      });
      productResources.setupProduct.mockResolvedValue({});

      let form = mount(
        <Provider store={reduxStore}>
          <ProductSetup />
        </Provider>
      );

      await fillAllFields(form);

      // At the time of writing, enzyme ReactWrapper does not include
      // stopImmediatePropagation in the dispatched Synthetic event

      // see Dropdown/Dropdown-test.js in the Semantic-UI-React github repo
      const nativeEvent = {
        nativeEvent: {
          stopImmediatePropagation: () => {}
        }
      };
      semanticUI.selectOption(form, 'allergens', 0, nativeEvent);
      semanticUI.selectOption(form, 'allergens', 0, nativeEvent);

      form.find('form').simulate('submit');

      jestExpect(productResources.setupProduct).toBeCalledWith(
        jestExpect.objectContaining({
          allergens: allergensData.map(allergen => allergen.name)
        })
      );
    });

    test('should not submit when byproduct only is true and no cost is entered', async () => {
      productResources.getProductInfoPromise.mockResolvedValue({
        data: productFactory.build({
          code: '0078889'
        })
      });
      productResources.setupProduct.mockResolvedValue({});

      let form = mount(
        <Provider store={reduxStore}>
          <ProductSetup />
        </Provider>
      );

      await fillAllFields(form);

      semanticUI.selectOption(form, 'byproductOnly', 0);
      semanticUI.changeInput(form, 'byproductOnlyCost', '');

      form.find('form').simulate('submit');

      jestExpect(productResources.setupProduct).not.toBeCalled();
    });

    test('should initialize product byProductOnly fields with values', async () => {
      const productCode = '0000507';
      const byProductOnlyProduct = productFactory.build({
        code: productCode,
        productOutput: 'BYPRODUCT_ONLY',
        cost: 10.0,
        marketCost: 15.0
      });

      tarePackageResources.getAllTarePackages.mockImplementation(callback =>
        callback({ data: tarePackagesData })
      );

      productResources.getProductInfoPromise.mockResolvedValue({
        data: byProductOnlyProduct
      });

      let wrapper = mount(
        <Provider store={reduxStore}>
          <ProductSetup />
        </Provider>
      );

      semanticUI.changeInput(wrapper, 'productCode', productCode);

      await waitForAsyncTasks();
      wrapper = wrapper.update();

      jestExpect(semanticUI.getSelectValue(wrapper, 'byproductOnly')).toEqual(true);
      jestExpect(semanticUI.getInputValue(wrapper, 'byproductOnlyCost')).toEqual(
        byProductOnlyProduct.marketCost
      );
      jestExpect(
        wrapper.find(Field).filterWhere(n => n.props().label === 'Byproduct Only')
      ).toBeDisabled();
    });
  });

  describe('grind specific fields', () => {
    test('should render grind specific mapping fields when selectedRoomType is GRINDING', () => {
      const wrapper = mount(
        <Provider store={reduxStore}>
          <ProductSetup />
        </Provider>
      );

      semanticUI.selectOption(wrapper, 'room', 3);
      jestExpect(
        wrapper
          .find('form')
          .find(GrindSpecificFields)
          .exists()
      ).toBeTruthy();
      jestExpect(semanticUI.getHtmlSelection(wrapper, 'grindSpecific.packInstructionA')).toEqual(
        'Fresh'
      );
      jestExpect(semanticUI.getHtmlSelection(wrapper, 'grindSpecific.packInstructionB')).toEqual(
        'Gas'
      );
      jestExpect(semanticUI.getHtmlSelection(wrapper, 'grindSpecific.tenderform')).toEqual('No');
      jestExpect(semanticUI.getHtmlSelection(wrapper, 'grindSpecific.grindSize')).toEqual('3/32');
      jestExpect(semanticUI.getInputValue(wrapper, 'grindSpecific.diameter')).toEqual('');
      jestExpect(semanticUI.getInputValue(wrapper, 'grindSpecific.thickness')).toEqual('');
      jestExpect(semanticUI.getInputValue(wrapper, 'grindSpecific.plateUsed')).toEqual('');
      jestExpect(semanticUI.getInputValue(wrapper, 'grindSpecific.casesPerTray')).toEqual('3');

      semanticUI.selectOption(wrapper, 'room', 1);
      jestExpect(
        wrapper
          .find('form')
          .find(GrindSpecificFields)
          .exists()
      ).toBeFalsy();
    });
  });

  describe('cut specific fields', () => {
    test('should render cut specific mapping fields when selectedRoomType is CUTTING', () => {
      const wrapper = mount(
        <Provider store={reduxStore}>
          <ProductSetup />
        </Provider>
      );

      semanticUI.selectOption(wrapper, 'room', 0);
      jestExpect(
        wrapper
          .find('form')
          .find(CutSpecificFields)
          .exists()
      ).toBeTruthy();
      jestExpect(semanticUI.getHtmlSelection(wrapper, 'cutSpecific.tenderized')).toEqual('None');

      semanticUI.selectOption(wrapper, 'room', 3);
      jestExpect(
        wrapper
          .find('form')
          .find(CutSpecificFields)
          .exists()
      ).toBeFalsy();
    });
  });
});

describe('Populating room, tableCode, tarePackageId, piecesPackageId, allergens with existing mapping information', () => {
  let reduxStore;
  let portionRoomData = [
    portionRoomFactory.build({ code: 'A', description: 'Room A' }),
    portionRoomFactory.build({ code: 'B', description: 'Room B' }),
    portionRoomFactory.build({ code: 'C', description: 'Room C' })
  ];

  let allergensData = [
    AllergenFactory.build(),
    AllergenFactory.build({ name: 'Eggs', displayName: 'EGGS' })
  ];

  let portionRoomTablesData = [
    portionRoomTableSummaryFactory.build(),
    portionRoomTableSummaryFactory.build({
      tableId: 2,
      tableCode: 35,
      stationId: 21421402141,
      stationCode: 90,
      stationName: 'JOHN',
      room: 'A',
      tableDescription: 'CHICKEN'
    }),
    portionRoomTableSummaryFactory.build({
      tableId: 3,
      tableCode: 36,
      stationId: 21421402142,
      stationCode: 91,
      stationName: 'QB CUTTER 2',
      room: 'B',
      tableDescription: 'PORK'
    })
  ];

  beforeEach(() => {
    productResources.getProductInfoPromise.mockResolvedValue({
      data: productFactory.build({
        code: '0078889'
      })
    });
    productResources.getAllergens.mockResolvedValue({
      data: allergensData
    });

    const product = PRODUCT_1;
    const tarePackage = tarePackageFactory.build({ id: 123456789 });
    const piecesPackage = PiecesPackageFactory.build({ id: 223456789 });
    product.tarePackage = tarePackage;
    product.piecesPackage = piecesPackage;
    product.allergens = allergensData;

    reduxStore = createReduxStore({
      settingsInfo: {
        rooms: portionRoomData,
        tables: portionRoomTablesData
      },
      productDuplicate: {
        products: {
          [product.code]: product
        }
      },
      tarePackages: {
        tarePackages: [tarePackage, tarePackageFactory.build({ id: 123456790 })]
      },
      productSetup: {
        piecesPackages: [piecesPackage, PiecesPackageFactory.build({ id: 223456790 })]
      }
    });
  });

  afterEach(() => {
    productResources.getProductInfoPromise.mockReset();
    productResources.getAllergens.mockReset();
  });

  test('should initialize the forms', () => {
    const wrapper = mount(
      <Provider store={reduxStore}>
        <ProductSetup />
      </Provider>
    );

    semanticUI.changeInput(wrapper, 'productCode', '0078889');

    jestExpect(semanticUI.getSelectValue(wrapper, 'room')).toEqual('B');
    jestExpect(semanticUI.getSelectValue(wrapper, 'tableCode')).toEqual(36);
    jestExpect(semanticUI.getSelectValue(wrapper, 'tarePackageId')).toEqual(123456789);
    jestExpect(semanticUI.getSelectValue(wrapper, 'piecesPackageId')).toEqual(223456789);
    jestExpect(semanticUI.getSelectValue(wrapper, 'specialDiet')).toEqual('NONE');
    jestExpect(semanticUI.getInputValue(wrapper, 'minWeight')).toEqual(11);
    jestExpect(semanticUI.getInputValue(wrapper, 'maxWeight')).toEqual(14);
    jestExpect(semanticUI.getTextAreaValue(wrapper, 'ingredientsStatement')).toEqual('ingredients');
    jestExpect(semanticUI.getInputValue(wrapper, 'labelProductDescription')).toEqual('description');
    jestExpect(
      wrapper
        .find('div[pid="product-setup__boneguard"]')
        .find('input[type="checkbox"]')
        .props().checked
    ).toEqual(true);
  });
});

describe('Populating grind specific fields with existing mapping information', () => {
  let reduxStore;
  let portionRoomData = [
    portionRoomFactory.build({ code: 'A', description: 'Room A' }),
    portionRoomFactory.build({ code: 'B', description: 'Room B', roomType: 'GRINDING' }),
    portionRoomFactory.build({ code: 'C', description: 'Room C' })
  ];

  let allergensData = [
    AllergenFactory.build(),
    AllergenFactory.build({ name: 'Eggs', displayName: 'EGGS' })
  ];

  let portionRoomTablesData = [
    portionRoomTableSummaryFactory.build(),
    portionRoomTableSummaryFactory.build({
      tableId: 2,
      tableCode: 35,
      stationId: 21421402141,
      stationCode: 90,
      stationName: 'JOHN',
      room: 'A',
      tableDescription: 'CHICKEN'
    }),
    portionRoomTableSummaryFactory.build({
      tableId: 3,
      tableCode: 36,
      stationId: 21421402142,
      stationCode: 91,
      stationName: 'QB CUTTER 2',
      room: 'B',
      tableDescription: 'PORK'
    })
  ];

  beforeEach(() => {
    productResources.getProductInfoPromise.mockResolvedValue({
      data: productFactory.build({
        code: '0078889'
      })
    });
    productResources.getAllergens.mockResolvedValue({
      data: allergensData
    });
  });

  afterEach(() => {
    productResources.getProductInfoPromise.mockReset();
    productResources.getAllergens.mockReset();
  });

  test('should pull in product data when based on input value', () => {
    const product = PRODUCT_1;
    product.grindSpecific = {
      packInstruction: 'Fresh,Gas',
      tenderform: true,
      grindSize: '3/32',
      diameter: '3.1',
      thickness: '3.2',
      plateUsed: '3.3',
      casePerTray: '3'
    };
    product.specialDiet = 'KOSHER';

    reduxStore = createReduxStore({
      settingsInfo: {
        rooms: portionRoomData,
        tables: portionRoomTablesData
      },
      productDuplicate: {
        products: {
          [product.code]: product
        }
      }
    });

    const wrapper = mount(
      <Provider store={reduxStore}>
        <ProductSetup />
      </Provider>
    );

    semanticUI.changeInput(wrapper, 'productCode', product.code);

    jestExpect(semanticUI.getHtmlSelection(wrapper, 'grindSpecific.packInstructionA')).toEqual(
      'Fresh'
    );
    jestExpect(semanticUI.getHtmlSelection(wrapper, 'grindSpecific.packInstructionB')).toEqual(
      'Gas'
    );
    jestExpect(semanticUI.getHtmlSelection(wrapper, 'grindSpecific.tenderform')).toEqual('Yes');
    jestExpect(semanticUI.getHtmlSelection(wrapper, 'grindSpecific.grindSize')).toEqual('3/32');
    jestExpect(semanticUI.getInputValue(wrapper, 'grindSpecific.diameter')).toEqual('3.1');
    jestExpect(semanticUI.getInputValue(wrapper, 'grindSpecific.thickness')).toEqual('3.2');
    jestExpect(semanticUI.getInputValue(wrapper, 'grindSpecific.plateUsed')).toEqual('3.3');
    jestExpect(semanticUI.getInputValue(wrapper, 'grindSpecific.casesPerTray')).toEqual('3');
    jestExpect(semanticUI.getHtmlSelection(wrapper, 'specialDiet')).toEqual('Kosher');
  });

  test('should pull in default pack instructions when product does not have pack instructions', () => {
    const product = productFactory.build({
      code: '0780599',
      grindSpecific: {
        packInstruction: ''
      }
    });

    reduxStore = createReduxStore({
      settingsInfo: {
        rooms: portionRoomData,
        tables: portionRoomTablesData
      },
      productDuplicate: {
        products: {
          [product.code]: product
        }
      }
    });

    const wrapper = mount(
      <Provider store={reduxStore}>
        <ProductSetup />
      </Provider>
    );

    semanticUI.changeInput(wrapper, 'productCode', product.code);
    jestExpect(semanticUI.getHtmlSelection(wrapper, 'grindSpecific.packInstructionA')).toEqual(
      'Fresh'
    );
    jestExpect(semanticUI.getHtmlSelection(wrapper, 'grindSpecific.packInstructionB')).toEqual(
      'Gas'
    );
  });

  test('should call removeProduct on unmount if product exists', () => {
    const currentProduct = {
      code: '1961172',
      description: 'good food',
      tarePackage: null
    };
    const removeProductSpy = jest.fn();
    const wrapper = shallow(
      <ProductSetupPage
        productCodeExists={true}
        getAllPiecesPackages={() => {}}
        getAllTarePackages={() => {}}
        getTables={() => {}}
        handleSubmit={() => {}}
        getRooms={() => {}}
        removeProduct={removeProductSpy}
        product={currentProduct}
        setHeaderAndFooter={() => {}}
        getAllergens={() => {}}
      />
    );

    wrapper.unmount();

    jestExpect(removeProductSpy).toBeCalledWith(currentProduct.code);
  });
});

describe('Save button', () => {
  test('should usually be enabled', () => {
    const wrapper = shallow(
      <SaveButton
        productCodeExists={true}
        selectedTableValue='something'
        selectedPiecesPackageValue='something else'
        submitting={false}
        pristine={false}
      />
    );

    jestExpect(wrapper.find(Button)).not.toBeDisabled();
  });

  test('should disable when the product is no good', () => {
    const wrapper = shallow(
      <SaveButton
        productCodeExists={false}
        selectedTableValue='something'
        selectedPiecesPackageValue='something else'
        submitting={false}
        pristine={false}
      />
    );

    jestExpect(wrapper.find(Button)).toBeDisabled();
  });

  test('should disable when submitting', () => {
    const wrapper = shallow(
      <SaveButton
        productCodeExists={true}
        selectedTableValue='something'
        selectedPiecesPackageValue='something else'
        submitting={true}
        pristine={false}
      />
    );

    jestExpect(wrapper.find(Button)).toBeDisabled();
  });

  test('should disable when pristine', () => {
    const wrapper = shallow(
      <SaveButton
        productCodeExists={true}
        selectedTableValue='something'
        selectedPiecesPackageValue='something else'
        submitting={false}
        pristine={true}
      />
    );

    jestExpect(wrapper.find(Button)).toBeDisabled();
  });
});

describe('RenderWeightInput', () => {
  test('should render maxWeight and minWeight input if prduct is CATCH type', () => {
    const wrapper = shallow(
      <RenderWeightInput product={productFactory.build({ category: 'CATCH' })} />
    );

    jestExpect(wrapper.find(Field)).toHaveLength(2);
  });

  test('should render fixWeight input if prduct is FIXED type', () => {
    const wrapper = shallow(
      <RenderWeightInput product={productFactory.build({ category: 'FIXED' })} />
    );

    jestExpect(wrapper.find(Field)).toHaveLength(1);
  });
});

function createHtmlSelector(wrapper) {
  return function(fieldName) {
    return semanticUI.getHtmlSelection(wrapper, fieldName);
  };
}
