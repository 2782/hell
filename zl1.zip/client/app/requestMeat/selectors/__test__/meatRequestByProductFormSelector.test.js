import {
  generateAdditivesInitialValues,
  generateStationOptions
} from '../meatRequestByProductFormSelector';

describe('MeatRequestByProductFormSelector', () => {
  describe('generateStationOptions', () => {
    const stations = [
      { stationCode: 'A', name: 'Room A', type: 'PRODUCTION' },
      { stationCode: 'B', name: 'Room B', type: 'PACKOFF' },
      { stationCode: 'C', name: 'Room C', type: 'PRODUCTION' }
    ];

    test('should design array to expected results', () => {
      const expectedArray = [
        { key: 0, text: 'A - Room A', value: 'A' },
        { key: 1, text: 'C - Room C', value: 'C' }
      ];

      const result = generateStationOptions(stations);

      jestExpect(result).toEqual(expectedArray);
    });

    test('should return empty array if stations is empty', () => {
      const result = generateStationOptions([]);

      jestExpect(result).toEqual([]);
    });

    test('should return empty array if stations is null', () => {
      const result = generateStationOptions(null);

      jestExpect(result).toEqual([]);
    });

    describe('generateAdditivesInitialValues', () => {
      test('should return additives', () => {
        const sourceMeatOrderPreview = {
          additives: [
            { productCode: '3492610', quantity: 4, productDesc: 'SPICE BASIL LEAVES' },
            { productCode: '4092706', quantity: 2, productDesc: 'SAUCE SOY' }
          ],
          quantity: 12
        };
        const result = generateAdditivesInitialValues(sourceMeatOrderPreview);

        jestExpect(result).toEqual(sourceMeatOrderPreview.additives);
      });

      test('should return empty additives when sourceMeatOrderPreview has no additives', () => {
        const sourceMeatOrderPreview = {
          additives: [],
          quantity: 12
        };
        const result = generateAdditivesInitialValues(sourceMeatOrderPreview);

        jestExpect(result).toEqual([]);
      });

      test('should return empty additives when sourceMeatOrderPreview is null', () => {
        const result = generateAdditivesInitialValues(null);

        jestExpect(result).toEqual([]);
      });
    });
  });
});
