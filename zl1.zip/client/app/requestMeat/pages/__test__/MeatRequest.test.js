import React from 'react';
import { mount } from 'enzyme';
import configureStore from 'redux-mock-store';
import thunk from 'redux-thunk';
import MeatRequest from '../MeatRequest';
import SideNavigation from '../../../shared/components/SideNavigation';
import { Provider } from 'react-redux';
import { PortionRoomState } from '../../../landingPage/reducers/portionRoomReducer';

jest.mock('../../../shared/components/Header');
jest.mock('../../../shared/errors/ErrorNotification');
jest.mock('../../components/MeatRequestByProductForm');
jest.mock('../../components/MeatRequestBySourceCodeForm');
jest.mock('react-router-dom');

let middleware = [thunk];
const createStore = configureStore(middleware);

describe('MeatRequest', () => {
  let wrapper, mockStore;

  describe('When portion room is open', () => {
    beforeEach(() => {
      mockStore = createStore({
        meatRequestInfo: {
          stations: [],
          sourceMeatOrderPreview: {},
          blends: [],
          blendPricingModel: {},
          sourceProductInfo: {}
        },
        portionRoomsInfo: {
          currentPortionRoom: {
            portionRoomState: PortionRoomState.CAN_CLOSE
          }
        },
        confirmationModal: {
          showing: false
        },
        function: {},
        login: {
          role: 'ROLE_ADMIN'
        }
      });
      wrapper = mount(
        <Provider store={mockStore}>
          <MeatRequest match={{ url: 'ROOT' }} location={{ pathname: 'ROOT/by-source-code' }} />
        </Provider>
      );
    });

    test('should render page content', () => {
      jestExpect(wrapper.find('.page-content').exists()).toBeTruthy();
    });

    test(
      'should render side navigation with current path set to current location and ' +
        'correct options when portion room is open',
      () => {
        jestExpect(wrapper.find(SideNavigation).exists()).toBeTruthy();
        jestExpect(wrapper.find(SideNavigation).props().currentPath).toEqual('ROOT/by-source-code');

        jestExpect(wrapper.find(SideNavigation).props().links.length).toEqual(4);
        jestExpect(wrapper.find(SideNavigation).props().links[0]).toEqual(
          jestExpect.objectContaining({
            path: '/available-wip',
            name: 'Available WIP'
          })
        );
        jestExpect(wrapper.find(SideNavigation).props().links[1]).toEqual(
          jestExpect.objectContaining({
            path: '/by-source-code',
            name: 'select by source #'
          })
        );
        jestExpect(wrapper.find(SideNavigation).props().links[2]).toEqual(
          jestExpect.objectContaining({
            path: '/by-product',
            name: 'select by finished #'
          })
        );
        jestExpect(wrapper.find(SideNavigation).props().links[3]).toEqual(
          jestExpect.objectContaining({
            path: '/by-blend',
            name: 'select by blend'
          })
        );
      }
    );
  });

  describe('When portion room is closed', () => {
    beforeEach(() => {
      mockStore = createStore({
        meatRequestInfo: {
          stations: [],
          sourceMeatOrderPreview: {},
          blends: [],
          blendPricingModel: {},
          sourceProductInfo: {}
        },
        portionRoomsInfo: {
          currentPortionRoom: {
            portionRoomState: PortionRoomState.CAN_OPEN
          }
        },
        confirmationModal: {
          showing: false
        },
        function: {},
        login: {
          role: 'ROLE_ADMIN'
        }
      });
      wrapper = mount(
        <Provider store={mockStore}>
          <MeatRequest match={{ url: 'ROOT' }} location={{ pathname: 'ROOT/by-source-code' }} />
        </Provider>
      );
    });

    test('should render side navigation with correct links when portion room is closed', () => {
      jestExpect(wrapper.find(SideNavigation).exists()).toBeTruthy();
      jestExpect(wrapper.find(SideNavigation).props().currentPath).toEqual('ROOT/by-source-code');

      jestExpect(wrapper.find(SideNavigation).props().links.length).toEqual(1);
      jestExpect(wrapper.find(SideNavigation).props().links[0]).toEqual({
        path: '/available-wip',
        name: 'Available WIP',
        toPath: jestExpect.any(Function)
      });
    });
  });
});
