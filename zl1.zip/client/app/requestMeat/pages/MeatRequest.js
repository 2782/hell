import PropTypes from 'prop-types';
import React from 'react';
import { connect } from 'react-redux';
import { Route, Switch } from 'react-router-dom';
import { bindActionCreators } from 'redux';
import SideNavigation from '../../shared/components/SideNavigation';
import MeatRequestByProductForm from '../components/MeatRequestByProductForm';
import MeatRequestBySourceCodeForm from '../components/MeatRequestBySourceCodeForm';
import MeatRequestByBlendForm from '../components/MeatRequestByBlendForm';
import { replacePath, setHeaderAndFooter } from '../../shared/actions/actions';
import { AVAILABLE_WIP, REQUEST_FOR_MEAT } from '../../shared/components/pageTitles';
import { AVAILABLE_WIP_FOOTER, REQUEST_FOR_MEAT_FOOTER } from '../../shared/components/pageFooters';
import AvailableWIP from '../components/AvailableWIP';
import subscriber, { f2BehaviorForSideNavigation } from '../../shared/functionKeys/subscriber';
import { PortionRoomState } from '../../landingPage/reducers/portionRoomReducer';
import _ from 'lodash';

class MeatRequest extends React.Component {
  constructor(props) {
    super(props);
  }

  componentDidMount() {
    this.setHeaderAndFooter(AVAILABLE_WIP, AVAILABLE_WIP_FOOTER);
  }

  setHeaderAndFooter(header, footer) {
    this.props.setHeaderAndFooter({
      header: header,
      footer: footer
    });
  }

  getSelectSourceMeatLinks() {
    const { portionRoomState, match } = this.props;
    return portionRoomState !== PortionRoomState.CAN_CLOSE
      ? []
      : [
          {
            path: '/by-source-code',
            name: 'select by source #',
            toPath: () => {
              this.setHeaderAndFooter(REQUEST_FOR_MEAT, REQUEST_FOR_MEAT_FOOTER);
              this.props.replacePath(`${match.url}/by-source-code`);
            }
          },
          {
            path: '/by-product',
            name: 'select by finished #',
            toPath: () => {
              this.setHeaderAndFooter(REQUEST_FOR_MEAT, REQUEST_FOR_MEAT_FOOTER);
              this.props.replacePath(`${match.url}/by-product`);
            }
          },
          {
            path: '/by-blend',
            name: 'select by blend',
            toPath: () => {
              this.setHeaderAndFooter(REQUEST_FOR_MEAT, REQUEST_FOR_MEAT_FOOTER);
              this.props.replacePath(`${match.url}/by-blend`);
            }
          }
        ];
  }

  render() {
    const { match } = this.props;

    const links = [
      {
        path: '/available-wip',
        name: 'Available WIP',
        toPath: () => {
          this.setHeaderAndFooter(AVAILABLE_WIP, AVAILABLE_WIP_FOOTER);
          this.props.replacePath(`${match.url}/available-wip`);
        }
      }
    ].concat(this.getSelectSourceMeatLinks());

    return (
      <div className='page-content meat-request side-navigation-page left-right'>
        <SideNavigation
          links={links}
          currentPath={this.props.location.pathname}
          ref={ref => (this.sideNavigation = ref)}
        />

        <div className='right'>
          <Switch>
            <Route exact path={`${match.url}/available-wip`} render={() => <AvailableWIP />} />
            <Route
              exact
              path={`${match.url}/by-source-code`}
              render={() => <MeatRequestBySourceCodeForm />}
            />
            <Route
              exact
              path={`${match.url}/by-product`}
              render={() => <MeatRequestByProductForm />}
            />
            <Route exact path={`${match.url}/by-blend`} render={() => <MeatRequestByBlendForm />} />
          </Switch>
        </div>
      </div>
    );
  }
}

MeatRequest.propTypes = {
  replacePath: PropTypes.func.isRequired,
  match: PropTypes.object.isRequired,
  keydown: PropTypes.object,
  location: PropTypes.object.isRequired,
  setHeaderAndFooter: PropTypes.func.isRequired,
  portionRoomState: PropTypes.number.isRequired
};

const mapDispatchToProps = dispatch =>
  bindActionCreators(
    {
      replacePath,
      setHeaderAndFooter
    },
    dispatch
  );

const mapStateToProps = state => {
  const currentPortionRoomState = _.get(
    state.portionRoomsInfo.currentPortionRoom,
    'portionRoomState',
    PortionRoomState.DISABLED
  );

  return {
    portionRoomState: currentPortionRoomState
  };
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(
  subscriber(MeatRequest, {
    f2Behavior: f2BehaviorForSideNavigation,
    targetComponent: 'MeatRequest',
    uris: {
      F2: [
        '#/meat-request/available-wip',
        '#/meat-request/by-source-code',
        '#/meat-request/by-product',
        '#/meat-request/by-blend'
      ]
    }
  })
);
