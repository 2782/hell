import React from 'react';
import PropTypes from 'prop-types';
import { Field } from 'redux-form';
import { Form, Table } from 'semantic-ui-react';
import FormElement from '../../shared/FormElement';
import { isQuantityInRangeForBlend } from './meatRequestValidator';
import {
  nonNegativeNumber,
  number,
  required,
  wholeNumber
} from '../../shared/validation/formFieldValidations';

class MeatRequestSourceProductsTable extends React.Component {
  constructor(props) {
    super(props);
  }

  render() {
    const { fields } = this.props;
    return (
      <div pid='source-products__full-table'>
        <Table columns={3} fixed size='small'>
          <Table.Header>
            <Table.Row pid={'source-products__table-header-row'}>
              <Table.HeaderCell width={3}>Product #</Table.HeaderCell>
              <Table.HeaderCell width={7}>Description</Table.HeaderCell>
              <Table.HeaderCell width={3}>Quantity</Table.HeaderCell>
              <Table.HeaderCell width={3}>U/M</Table.HeaderCell>
            </Table.Row>
          </Table.Header>
          <Table.Body>
            {fields.map((fieldString, index) => {
              const sourceProduct = fields.get(index);
              return (
                <Table.Row
                  pid={`source-products__table-row-${index}`}
                  key={`${index}-${fieldString}`}
                >
                  <Table.Cell width={3}>{sourceProduct.code}</Table.Cell>
                  <Table.Cell width={7}>{sourceProduct.description}</Table.Cell>
                  <Table.Cell width={3}>
                    <Field
                      component={FormElement}
                      name={`${fieldString}.quantity`}
                      as={Form.Input}
                      validate={[
                        required,
                        number,
                        wholeNumber,
                        nonNegativeNumber,
                        isQuantityInRangeForBlend
                      ]}
                      type='text'
                    />
                  </Table.Cell>
                  <Table.Cell width={3}>LB</Table.Cell>
                </Table.Row>
              );
            })}
          </Table.Body>
        </Table>
      </div>
    );
  }
}

MeatRequestSourceProductsTable.propTypes = {
  meta: PropTypes.object.isRequired,
  fields: PropTypes.object.isRequired
};

export default MeatRequestSourceProductsTable;
