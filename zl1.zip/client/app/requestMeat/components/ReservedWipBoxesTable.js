import React, { Fragment } from 'react';
import { Table } from 'semantic-ui-react';
import _ from 'lodash';
import PropTypes from 'prop-types';
import DotDotDot from 'react-dotdotdot';
import moment from 'moment';
import { wipBoxAge } from './wipBoxTable';

const ReservedWipBoxesTable = ({ reservedWipBoxes }) => {
  const now = moment();
  return (
    <Fragment>
      <span>
        {'You need to retrieve the following source meats from WIP. ' +
          'All other requested items will be brought from inventory.'}
      </span>

      <Table>
        <Table.Header>
          <Table.Row>
            <Table.HeaderCell colSpan={2} width={2} textAlign='left'>
              PRODUCT
            </Table.HeaderCell>
            <Table.HeaderCell colSpan={2} width={2} textAlign='left'>
              &nbsp;
            </Table.HeaderCell>
            <Table.HeaderCell colSpan={2} width={2} textAlign='right'>
              AGE (DAYS)
            </Table.HeaderCell>
            <Table.HeaderCell colSpan={2} width={2} textAlign='right'>
              QTY (LBS)
            </Table.HeaderCell>
          </Table.Row>
        </Table.Header>

        <Table.Body>
          {_.map(reservedWipBoxes, wipBox => {
            return (
              <Table.Row key={wipBox.id}>
                <Table.Cell colSpan={1} width={1} textAlign='left'>
                  <div pid='wip-box-table__product-number'>{wipBox.productCode}</div>
                </Table.Cell>
                <Table.Cell colSpan={3} width={3} textAlign='left'>
                  <DotDotDot clamp={1} title={wipBox.productDesc} className='product-description'>
                    {wipBox.productDesc}
                  </DotDotDot>
                </Table.Cell>
                <Table.Cell colSpan={2} width={2} textAlign='right'>
                  {wipBoxAge(wipBox, now)}
                </Table.Cell>
                <Table.Cell colSpan={2} width={2} textAlign='right'>
                  {wipBox.netWeight}
                </Table.Cell>
              </Table.Row>
            );
          })}
        </Table.Body>
      </Table>
    </Fragment>
  );
};

ReservedWipBoxesTable.propTypes = {
  reservedWipBoxes: PropTypes.array.isRequired
};

export default ReservedWipBoxesTable;
