import _ from 'lodash';
import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { Button, Divider, Form, Grid } from 'semantic-ui-react';
import { generateMeatRequest, getStations } from '../actions/meatRequestActions';
import { clearProduct } from '../../shared/components/product/actions';
import { Field, formValueSelector, reduxForm, reset, SubmissionError } from 'redux-form';
import Product from '../../shared/components/product/product';
import { normalizeProductCode } from '../../shared/components/product/normalizer';
import FormElement from '../../shared/FormElement';
import { validateSubmission } from './meatRequestBySourceCodeFormValidator';
import { isQuantityInRange } from './meatRequestValidator';
import {
  number,
  positiveNumber,
  required,
  wholeNumber
} from '../../shared/validation/formFieldValidations';
import { hideModal, replacePath, showModal } from '../../shared/actions/actions';
import ReservedWipBoxesTable from './ReservedWipBoxesTable';
import subscriber from '../../shared/functionKeys/subscriber';

const unitOfMeasureOptions = [
  {
    key: 0,
    text: 'CASE',
    value: 'CASE'
  },
  {
    key: 1,
    text: 'LBS',
    value: 'LBS'
  }
];

export class MeatRequestBySourceCodeFormComponent extends React.Component {
  constructor(props) {
    super(props);
    this.submit = this.submit.bind(this);
  }

  componentDidMount() {
    const { getStations } = this.props;
    getStations();
  }

  componentWillUnmount() {
    const { clearProduct } = this.props;
    clearProduct('MeatRequestBySourceCodeForm-sourceProductCode');
  }

  submit(values) {
    const {
      quantity,
      portionRoom,
      showModal,
      stations,
      generateMeatRequest,
      sourceProductInfo,
      unitOfMeasure
    } = this.props;

    validateSubmission(values, this.props);

    const selectedStation = _.find(stations, item => {
      return item.stationCode === values.stationCode;
    });

    const request = [
      {
        stationId: selectedStation.id,
        productCode: sourceProductInfo.code,
        productDesc: sourceProductInfo.description,
        roomCode: portionRoom.code,
        quantity: quantity,
        unitOfMeasure: unitOfMeasure
      }
    ];

    return generateMeatRequest(
      request,
      usedWipBoxes => {
        if (!_.isEmpty(usedWipBoxes.data)) {
          showModal({
            header: 'Retrieve from WIP',
            content: ReservedWipBoxesTable({ reservedWipBoxes: usedWipBoxes.data }),
            confirmButton: 'ok',
            confirmAction: () => {}
          });
        }
      },
      error => {
        throw new SubmissionError({
          _error: error.message
        });
      }
    );
  }

  showFormError() {
    if (this.props.error) {
      return <span className={'ui red message meat-request-error'}>{this.props.error}</span>;
    }
  }

  render() {
    const { handleSubmit, stationOptions, submitting, pristine, invalid } = this.props;

    return (
      <div className='meat-request-form-wrapper'>
        <Form pid='meat-request-form' size={'large'} onSubmit={handleSubmit(this.submit)}>
          <Form.Group>
            <Field
              component={FormElement}
              name='stationCode'
              pid='request-meat-station-code'
              as={Form.Select}
              options={stationOptions}
              type='text'
              label='station'
            />
          </Form.Group>
          <Divider hidden />
          <Grid>
            <Grid.Row>
              <Grid.Column>
                <Field
                  component={Product}
                  name='sourceProductCode'
                  pid='request-meat-source-product-code'
                  namespace={'MeatRequestBySourceCodeForm-sourceProductCode'}
                  label='source #'
                  normalize={normalizeProductCode}
                />
              </Grid.Column>
            </Grid.Row>
          </Grid>

          <Divider hidden />

          <Form.Group>
            <Field
              component={FormElement}
              width={3}
              name='quantity'
              pid='request-meat-quantity'
              as={Form.Input}
              type='text'
              validate={[required, number, wholeNumber, positiveNumber, isQuantityInRange]}
              label='quantity'
            />
            <Field
              component={FormElement}
              name='unitOfMeasure'
              className={'request-meat-unit-of-measure'}
              width={4}
              pid='request-meat-unitOfMeasure'
              as={Form.Select}
              options={unitOfMeasureOptions}
              type='text'
              label='Unit of Measure'
            />
          </Form.Group>

          <Divider hidden />

          <Button
            primary
            size={'large'}
            loading={submitting}
            disabled={submitting || pristine || invalid}
            className='submit'
          >
            Submit
          </Button>
          <Divider hidden />
          {this.showFormError()}
        </Form>
      </div>
    );
  }
}

export const generateStationOptions = stations => {
  return _.filter(stations, station => station.type === 'PRODUCTION').map(
    ({ stationCode, name }, index) => {
      return { key: index, text: `${stationCode} - ${name}`, value: stationCode };
    }
  );
};

MeatRequestBySourceCodeFormComponent.propTypes = {
  getStations: PropTypes.func.isRequired,
  stationOptions: PropTypes.array.isRequired,
  stations: PropTypes.array.isRequired,

  handleSubmit: PropTypes.func.isRequired,
  clearProduct: PropTypes.func.isRequired,

  generateMeatRequest: PropTypes.func.isRequired,
  sourceProductInfo: PropTypes.object,
  quantity: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  unitOfMeasure: PropTypes.string,
  sourceProductExists: PropTypes.bool.isRequired,
  stationCode: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  keydown: PropTypes.object,
  error: PropTypes.string,
  submitting: PropTypes.bool.isRequired,
  pristine: PropTypes.bool.isRequired,
  invalid: PropTypes.bool.isRequired,
  portionRoom: PropTypes.object,
  showModal: PropTypes.func
};

const selector = formValueSelector('MeatRequestBySourceCodeForm');
const mapStateToProps = state => {
  const portionRoom = state.portionRoomsInfo.currentPortionRoom;
  const stations = state.meatRequestInfo.stations;
  const sourceProductInfo = state.product['MeatRequestBySourceCodeForm-sourceProductCode'];

  return {
    initialValues: {
      quantity: '',
      stationCode: '',
      unitOfMeasure: 'CASE'
    },
    sourceProductInfo: sourceProductInfo,
    quantity: selector(state, 'quantity'),
    stationCode: selector(state, 'stationCode'),
    unitOfMeasure: selector(state, 'unitOfMeasure'),
    stations: stations,
    portionRoom,
    isModalShowing: state.confirmationModal.showing,
    sourceProductExists: !_.isEmpty(
      _.get(state.product, 'MeatRequestBySourceCodeForm-sourceProductCode.code', '')
    ),
    stationOptions: stations ? generateStationOptions(stations) : []
  };
};

const mapDispatchToProps = dispatch =>
  bindActionCreators(
    {
      getStations,
      clearProduct,
      generateMeatRequest,
      showModal,
      hideModal,
      replacePath
    },
    dispatch
  );

const onSubmitSuccess = (sourceProductCode, dispatch, props) => {
  const { clearProduct } = props;
  clearProduct('MeatRequestBySourceCodeForm-sourceProductCode');
  dispatch(reset('MeatRequestBySourceCodeForm'));
};

export const f4Behavior = props => {
  const { hideModal, isModalShowing, replacePath } = props;
  if (isModalShowing) {
    hideModal();
  } else {
    replacePath('/main-navigation');
  }
};

const MeatRequestBySourceCodeForm = connect(
  mapStateToProps,
  mapDispatchToProps
)(
  reduxForm({
    form: 'MeatRequestBySourceCodeForm',
    enableReinitialize: true,
    onSubmitSuccess
  })(
    subscriber(MeatRequestBySourceCodeFormComponent, {
      f4Behavior,
      targetComponent: 'MeatRequestBySourceCodeForm',
      uris: {
        F4: ['#/meat-request/by-source-code']
      }
    })
  )
);

export default MeatRequestBySourceCodeForm;
