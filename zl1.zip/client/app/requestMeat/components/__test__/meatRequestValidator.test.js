import { isInRange, validateMeatRequest } from '../meatRequestValidator';

describe('meatRequestValidator', () => {
  test('should return error when give value is out of range', () => {
    const inRange = isInRange(0, 100);

    jestExpect(inRange(101)).toEqual('quantity is invalid');
  });

  test('should return undefined when give value is in the range', () => {
    const inRange = isInRange(0, 100);

    jestExpect(inRange(60)).toEqual(undefined);
  });

  test('should throw submission error when sourceMeatQuantity and additive quantity are zero', () => {
    try {
      validateMeatRequest({ sourceMeatQuantity: 0, additives: [{ quantity: 0 }] });
    } catch ({ errors }) {
      jestExpect(errors._error).toEqual(
        'Total quantity requested for source meat and additives must be greater than 0.'
      );
      return;
    }
    fail('Expected Submission Error to be thrown.');
  });
});
