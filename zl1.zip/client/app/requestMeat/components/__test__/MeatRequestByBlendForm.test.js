import { mount } from 'enzyme';
import React from 'react';
import { createReduxStore } from '../../../store';
import { Provider } from 'react-redux';
import productResources from '../../../shared/api/productResources';
import MeatRequestByBlendForm, {
  calcSourceProductQty,
  f4Behavior,
  generateSourceProducts
} from '../MeatRequestByBlendForm';
import semanticUI from '../../../../test-helpers/semantic-ui';
import sourceMeatResources from '../../../shared/api/sourceMeatResources';
import { CREATE_SOURCE_MEAT_REQUEST_MESSAGE } from '../../../../config/errorMessage';
import yieldModelResources from '../../../shared/api/yieldModelResources';
import GrindingPricingModelFactory from '../../../../test-factories/grindingPricingModel';
import { RESERVED_WIP_BOX } from '../../../../test-factories/wipBoxFactory';
import { showModal } from '../../../shared/actions/actions';
import ReservedWipBoxesTable from '../ReservedWipBoxesTable';

jest.mock('../../../shared/actions/actions', () => ({
  showModal: jest.fn()
}));
jest.mock('../../../shared/api/sourceMeatResources');
jest.mock('../../../shared/api/yieldModelResources');
jest.mock('../../../shared/api/productResources');

describe('MeatRequestByBlendForm', () => {
  let form, generateSourceMeatOrdersStub;

  beforeEach(() => {
    generateSourceMeatOrdersStub = sourceMeatResources.generateSourceMeatOrders;

    yieldModelResources.getBlends.mockResolvedValue({
      data: [
        {
          name: 'NATURAL',
          displayName: 'Natural'
        },
        {
          name: 'KOBE',
          displayName: 'Kobe'
        }
      ]
    });
    let store = createReduxStore({
      portionRoomsInfo: {
        currentPortionRoom: { code: 'D' }
      }
    });
    form = mount(
      <Provider store={store}>
        <MeatRequestByBlendForm />
      </Provider>
    );
  });

  afterEach(() => {
    yieldModelResources.getBlends.mockReset();
    productResources.getProductInfoByProductCodes.mockReset();
    yieldModelResources.getPricingModelByBlend.mockReset();
    generateSourceMeatOrdersStub.mockReset();
  });

  test('should fill out form and calculate source product quantity values to API', async () => {
    showModal.mockImplementation(() => ({ type: 'MOCK_SHOW_MODAL_ACTION' }));
    const maxQuantity = '99999';
    const grindPricingModel = GrindingPricingModelFactory.build();
    yieldModelResources.getPricingModelByBlend.mockImplementation((arg, callback) =>
      callback({ data: grindPricingModel })
    );
    productResources.getProductInfoByProductCodes.mockImplementation((arg, callback) =>
      callback({
        data: [
          {
            code: '0204000',
            description: 'test data'
          },
          {
            code: '0204001',
            description: 'test data 1'
          }
        ]
      })
    );
    generateSourceMeatOrdersStub.mockImplementation((arg1, arg2, callback) =>
      callback({ data: [RESERVED_WIP_BOX] })
    );

    await waitForAsyncTasks();
    form = form.update();

    semanticUI.selectOption(form, 'blend', 0);
    semanticUI.changeInput(form, 'quantity', maxQuantity);

    // TODO: This might be better validated by API than the UI
    jestExpect(semanticUI.getInputValue(form, 'sourceProducts[0].quantity')).toEqual(25641);
    jestExpect(semanticUI.getInputValue(form, 'sourceProducts[1].quantity')).toEqual(76923);

    form.find('form').simulate('submit');

    jestExpect(generateSourceMeatOrdersStub).toHaveBeenCalledTimes(1);
    jestExpect(showModal).toHaveBeenCalledWith({
      header: 'Retrieve from WIP',
      content: ReservedWipBoxesTable({ reservedWipBoxes: [RESERVED_WIP_BOX] }),
      confirmButton: 'ok',
      confirmAction: jestExpect.anything()
    });
  });

  it('should submit values to API and not call modal when no WIP is received', async () => {
    showModal.mockImplementation(() => ({ type: 'MOCK_SHOW_MODAL_ACTION' }));

    generateSourceMeatOrdersStub.mockImplementation((arg1, arg2, callback) => callback());

    const maxQuantity = '99999';
    const grindPricingModel = GrindingPricingModelFactory.build();
    yieldModelResources.getPricingModelByBlend.mockImplementation((arg, callback) =>
      callback({ data: grindPricingModel })
    );
    productResources.getProductInfoByProductCodes.mockImplementation((arg, callback) =>
      callback({
        data: [
          {
            code: '0204000',
            description: 'test data'
          },
          {
            code: '0204001',
            description: 'test data 1'
          }
        ]
      })
    );
    generateSourceMeatOrdersStub.mockImplementation((arg1, arg2, callback) =>
      callback({ data: [RESERVED_WIP_BOX] })
    );

    await waitForAsyncTasks();
    form = form.update();

    semanticUI.selectOption(form, 'blend', 0);
    semanticUI.changeInput(form, 'quantity', maxQuantity);

    jestExpect(semanticUI.getInputValue(form, 'sourceProducts[0].quantity')).toEqual(25641);
    jestExpect(semanticUI.getInputValue(form, 'sourceProducts[1].quantity')).toEqual(76923);

    form.find('form').simulate('submit');

    jestExpect(showModal).not.toHaveBeenCalledWith({
      header: 'Retrieve from WIP',
      content:
        'You need to retrieve the following source meats from WIP. ' +
        'All other requested items will be brought from inventory.',
      confirmButton: 'ok',
      confirmAction: jestExpect.any(Function)
    });
  });

  test('should not submit form when no sourceProducts', async () => {
    yieldModelResources.getPricingModelByBlend.mockImplementation((arg, callback) => callback({}));

    await waitForAsyncTasks();
    form = form.update();

    semanticUI.selectOption(form, 'blend', 0);
    semanticUI.changeInput(form, 'quantity', '10');

    form.find('form').simulate('submit');

    jestExpect(generateSourceMeatOrdersStub).not.toHaveBeenCalled();
  });

  test('when an error happens during submitting meat request, should show error', async () => {
    generateSourceMeatOrdersStub.mockImplementation((arg1, arg2, success, error) =>
      error({
        message: CREATE_SOURCE_MEAT_REQUEST_MESSAGE
      })
    );

    const grindPricingModel = GrindingPricingModelFactory.build();
    yieldModelResources.getPricingModelByBlend.mockImplementation((arg, callback) =>
      callback({ data: grindPricingModel })
    );
    productResources.getProductInfoByProductCodes.mockImplementation((arg, callback) =>
      callback({
        data: [
          {
            code: '0204000',
            description: 'test data'
          },
          {
            code: '0204001',
            description: 'test data 1'
          }
        ]
      })
    );

    await waitForAsyncTasks();
    form = form.update();

    semanticUI.selectOption(form, 'blend', 0);
    semanticUI.changeInput(form, 'quantity', '10');

    form.find('form').simulate('submit');

    jestExpect(generateSourceMeatOrdersStub).toHaveBeenCalledTimes(1);
    jestExpect(form.find('span.meat-request-error').text()).toEqual(
      CREATE_SOURCE_MEAT_REQUEST_MESSAGE
    );
  });

  test('should return empty when input targetProductQty is empty', () => {
    jestExpect(calcSourceProductQty('', {}, {})).toEqual('');
  });

  test('should return empty when input targetProductQty is not Numeric', () => {
    jestExpect(calcSourceProductQty('abc', {}, {})).toEqual('');
  });

  test('should return empty when input targetProductQty is not Positive Numeric', () => {
    jestExpect(calcSourceProductQty(-10, {}, {})).toEqual('');
  });

  test('should return empty sourceProducts when blendPricingModel is empty ', () => {
    jestExpect(generateSourceProducts({}, {}, 10)).toEqual([]);
  });

  test('should return sourceProducts when give blendPricingModel ', () => {
    const grindPricingModel = GrindingPricingModelFactory.build();
    const sourceProductInfo = {
      '0204000': { code: '0204000', description: 'test data' },
      '0204001': { code: '0204001', description: 'test data 1' }
    };
    jestExpect(generateSourceProducts(grindPricingModel, sourceProductInfo, '')).toEqual([
      { code: '0204000', description: 'test data', quantity: '' },
      { code: '0204001', description: 'test data 1', quantity: '' }
    ]);
  });

  describe('f4 Behavior', () => {
    test('should hide modal on f4 when modal is showing', () => {
      const props = {
        isModalShowing: true,
        hideModal: jest.fn(),
        replacePath: jest.fn()
      };
      f4Behavior(props);

      jestExpect(props.hideModal).toHaveBeenCalledTimes(1);
      jestExpect(props.replacePath).not.toHaveBeenCalled();
    });

    test('should return to table selection on f4 when no orders are selected', () => {
      const props = {
        isModalShowing: false,
        hideModal: jest.fn(),
        replacePath: jest.fn()
      };
      f4Behavior(props);

      jestExpect(props.hideModal).not.toHaveBeenCalled();
      jestExpect(props.replacePath).toHaveBeenCalledWith('/main-navigation');
    });
  });
});
