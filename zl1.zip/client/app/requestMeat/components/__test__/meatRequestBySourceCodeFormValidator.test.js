import { validateSubmission } from '../meatRequestBySourceCodeFormValidator';

describe('meatRequestBySourceCodeFormValidator', () => {
  const VALID_SOURCE_PRODUCT_CODE = '0078889';
  const VALID_STATION_CODE = '2';
  const VALID_QUANTITY = 1;

  describe('submission validation', () => {
    test('should call submit with given values', () => {
      const values = {
        sourceProductCode: VALID_SOURCE_PRODUCT_CODE,
        quantity: VALID_QUANTITY,
        stationCode: VALID_STATION_CODE
      };

      validateSubmission(values, {
        sourceProductExists: true
      });
    });

    test('should check that all fields are required', () => {
      try {
        validateSubmission(
          {},
          {
            sourceProductExists: true
          }
        );
        jest.fail('Expected SubmissionError to be thrown.');
      } catch ({ errors }) {
        jestExpect(errors.sourceProductCode).toEqual('Required');
        jestExpect(errors.stationCode).toEqual('Required');
      }
    });

    test('should validate that source product code are wholeNumber', () => {
      const values = {
        sourceProductCode: 'abc123'
      };

      try {
        validateSubmission(values, {
          sourceProductExists: true
        });
        jest.fail('Expected SubmissionError to be thrown.');
      } catch ({ errors }) {
        jestExpect(errors.sourceProductCode).toEqual('Only whole number characters');
      }
    });

    test('should validate that source product code are exactly 7 characters', () => {
      const values = {
        sourceProductCode: '0123123123'
      };

      try {
        validateSubmission(values, {
          sourceProductExists: true
        });
        jest.fail('Expected SubmissionError to be thrown.');
      } catch ({ errors }) {
        jestExpect(errors.sourceProductCode).toEqual('Must be 7 characters');
      }
    });

    test('should validate that product code is valid', () => {
      const values = {
        sourceProductCode: VALID_SOURCE_PRODUCT_CODE
      };

      try {
        validateSubmission(values, {
          sourceProductExists: false
        });
        jest.fail('Expected SubmissionError to be thrown.');
      } catch ({ errors }) {
        jestExpect(errors.sourceProductCode).toEqual('Invalid Item Number');
      }
    });
  });
});
