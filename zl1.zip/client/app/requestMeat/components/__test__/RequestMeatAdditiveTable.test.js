import React from 'react';
import RequestMeatAdditiveTable from '../RequestMeatAdditiveTable';
import { mount, shallow } from 'enzyme';
import { reduxForm } from 'redux-form';
import { Provider } from 'react-redux';
import { createReduxStore } from '../../../store';
import semanticUI from '../../../../test-helpers/semantic-ui';

describe('RequestMeatAdditiveTable', () => {
  const additives = [
    {
      productCode: '3492610',
      productDesc: 'Spice Basil Leaves',
      quantity: 3
    }
  ];

  test('should render header', () => {
    const wrapper = shallow(<RequestMeatAdditiveTable />);
    const tableHeader = wrapper.find('TableHeader');
    const tableCell = tableHeader.find('TableHeaderCell');

    jestExpect(tableCell.at(0).html()).toEqual(jestExpect.stringContaining('Additives'));
    jestExpect(tableCell.at(2).html()).toEqual(jestExpect.stringContaining('Quantity'));
    jestExpect(tableCell.at(3).html()).toEqual(jestExpect.stringContaining('U/M'));
  });

  test('should render additives given in component', () => {
    const DecoratedComponent = reduxForm({ form: 'test' })(RequestMeatAdditiveTable);
    const store = createReduxStore({
      form: {
        test: {
          values: {
            additives: [{ quantity: 3, unitOfMeasure: 'PIECE' }]
          }
        }
      }
    });

    const wrapper = mount(
      <Provider store={store}>
        <DecoratedComponent additives={additives} />
      </Provider>
    );

    const tableRow = wrapper.find('TableRow');
    const tableCell = tableRow.at(1).find('TableCell');

    jestExpect(tableRow).toHaveLength(2);
    jestExpect(tableCell.at(0).text()).toEqual('3492610');
    jestExpect(tableCell.at(1).text()).toEqual('Spice Basil Leaves');
  });

  test('should render box with quantity when additives exist', () => {
    const DecoratedComponent = reduxForm({ form: 'test' })(RequestMeatAdditiveTable);
    const store = createReduxStore({
      form: {
        test: {
          values: {
            additives: [{ quantity: 3 }]
          }
        }
      }
    });

    const wrapper = mount(
      <Provider store={store}>
        <DecoratedComponent additives={additives} />
      </Provider>
    );

    jestExpect(semanticUI.getInputValue(wrapper, 'additives[0].quantity')).toEqual(3);
  });
});
