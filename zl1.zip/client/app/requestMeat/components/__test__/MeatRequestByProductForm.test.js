import { mount, shallow } from 'enzyme';
import React from 'react';
import { createReduxStore } from '../../../store';
import { Provider } from 'react-redux';
import productResources from '../../../shared/api/productResources';
import MeatRequestByProductForm, {
  getByproductMessage,
  MeatRequestByProductFormComponent
} from '../MeatRequestByProductForm';
import semanticUI from '../../../../test-helpers/semantic-ui';
import productFactory, { PRODUCT_1 } from '../../../../test-factories/productFactory';
import SourceMeatPreviewFactory from '../../../../test-factories/sourceMeatPreview';
import StationFactory from '../../../../test-factories/station';
import sourceMeatResources from '../../../shared/api/sourceMeatResources';
import { CREATE_SOURCE_MEAT_REQUEST_MESSAGE } from '../../../../config/errorMessage';
import { NOT_A_PRODUCT_CODE } from '../../../../config/errorMessage';
import cutStationResources from '../../../shared/api/stationResources';
import { Field, reduxForm } from 'redux-form';
import RequestMeatAdditiveTable from '../RequestMeatAdditiveTable';

jest.mock('../../../shared/api/productResources');
jest.mock('../../../shared/api/stationResources');
jest.mock('../../../shared/api/sourceMeatResources');

const getSourceMeatOrderPreviewByProductResponse = {
  data: {
    productCode: '0079007',
    productDesc: 'FLEMINGS CAB PRHOUSE STK',
    quantity: 5,
    stationId: null,
    targetProductCode: '0078889',
    targetProductDesc: null,
    unitOfMeasure: 'PIECE'
  }
};

describe('MeatRequestByProductForm', () => {
  let form;

  beforeEach(() => {
    productResources.getProductInfo.mockImplementation((arg, callback) =>
      callback({
        data: productFactory.build({ code: '0078889' })
      })
    );
    cutStationResources.getStationsByRoom.mockResolvedValue({
      data: [
        {
          portionRoomTables: [95],
          name: 'ALEX',
          room: 'B',
          stationCode: 91,
          printer: 'PRINTER-91',
          id: 21421402142,
          type: 'PRODUCTION'
        },
        {
          portionRoomTables: [96],
          name: 'SALLY',
          room: 'B',
          stationCode: 92,
          printer: 'PRINTER-92',
          id: 21421402151,
          type: 'PRODUCTION'
        }
      ]
    });
    sourceMeatResources.getSourceMeatOrderPreviewByProduct.mockImplementation((arg, callback) => {
      return callback(getSourceMeatOrderPreviewByProductResponse);
    });
  });

  afterEach(() => {
    productResources.getProductInfo.mockReset();
    sourceMeatResources.getSourceMeatOrderPreviewByProduct.mockReset();
    sourceMeatResources.generateSourceMeatOrders.mockReset();
    cutStationResources.getStationsByRoom.mockReset();
  });

  test('when an error happens during submitting meat request, should show error', async () => {
    sourceMeatResources.generateSourceMeatOrders.mockImplementation((arg1, arg2, arg3, callback) =>
      callback({ message: CREATE_SOURCE_MEAT_REQUEST_MESSAGE })
    );

    productResources.getProductInfo.mockImplementation((arg, success) =>
      success({ data: productFactory.build({ code: '0078889' }) })
    );

    let store = createReduxStore({});
    form = mount(
      <Provider store={store}>
        <MeatRequestByProductForm />
      </Provider>
    );

    await waitForAsyncTasks(form);

    semanticUI.selectOption(form, 'stationCode', 0);
    semanticUI.changeInput(form, 'finishedProductCode', '0078889');
    semanticUI.changeInput(form, 'quantity', '5');
    semanticUI.selectOption(form, 'unitOfMeasure', 1);

    form.find('form').simulate('submit');

    jestExpect(form.find('span.meat-request-error').text()).toEqual(
      CREATE_SOURCE_MEAT_REQUEST_MESSAGE
    );
  });

  test('should render form with fields', () => {
    const wrapper = shallow(
      <MeatRequestByProductFormComponent
        clearProduct={() => {}}
        finishedProductExists={true}
        generateMeatRequest={() => {}}
        getSourceMeatOrderPreview={() => {}}
        handleSubmit={() => {}}
        productsExist={{}}
        getStations={() => {}}
        finishedProductInfo={{}}
        products={{}}
        clearSourceMeatOrderPreview={() => {}}
        pristine={true}
        stationOptions={[]}
        stations={[]}
        submitting={false}
        invalid={false}
        clearMeatRequestByFinishedProduct={() => {}}
        reset={() => {}}
        showProductSourceMeatTable={true}
        requesting={false}
      />
    );

    const rowCell = wrapper.find(Field);
    jestExpect(rowCell.at(0).props().name).toEqual('stationCode');
    jestExpect(rowCell.at(1).props().name).toEqual('finishedProductCode');
    jestExpect(rowCell.at(2).props().name).toEqual('quantity');
    jestExpect(rowCell.at(3).props().name).toEqual('unitOfMeasure');
    jestExpect(rowCell.at(3).props().options[1]).toEqual({ key: 2, text: 'PIECE', value: 'PIECE' });
  });

  test('should render sourceMeatPreview', () => {
    const wrapper = shallow(
      <MeatRequestByProductFormComponent
        clearProduct={() => {}}
        finishedProductExists={true}
        sourceMeatProductCode={'foo'}
        sourceMeatProductDesc={'bar'}
        sourceMeatProductUom={'CASE'}
        generateMeatRequest={() => {}}
        getSourceMeatOrderPreview={() => {}}
        handleSubmit={() => {}}
        productsExist={{}}
        getStations={() => {}}
        showProductSourceMeatTable={true}
        quantity={4}
        products={{}}
        clearSourceMeatOrderPreview={() => {}}
        pristine={true}
        sourceMeatOrderPreview={{ quantity: 19 }}
        stationOptions={[]}
        stations={[]}
        submitting={false}
        invalid={false}
        clearMeatRequestByFinishedProduct={() => {}}
        reset={() => {}}
        requesting={false}
      />
    );

    const tableHeader = wrapper.find('TableHeader');
    const tableCells = tableHeader.find('TableHeaderCell');
    jestExpect(tableCells.at(0).html()).toContain('Source Product');
    jestExpect(tableCells.at(2).html()).toContain('Quantity');
    jestExpect(tableCells.at(3).html()).toContain('U/M');

    const tableBody = wrapper.find('TableBody');
    jestExpect(tableBody.find('TableRow')).toHaveLength(1);

    const row1 = tableBody.find('TableRow').at(0);
    const row1Cells = row1.find('TableCell');
    jestExpect(row1Cells.at(0).html()).toContain('foo');
    jestExpect(row1Cells.at(1).html()).toContain('bar');
    jestExpect(row1Cells.at(3).html()).toContain('CS');
  });

  test('should render additivesTable with additives', () => {
    const additives = [
      {
        productCode: '3492610',
        productDescription: 'Spice Basil Leaves',
        quantity: 3,
        unitOfMeasure: 'PIECE'
      }
    ];
    const wrapper = shallow(
      <MeatRequestByProductFormComponent
        clearProduct={() => {}}
        finishedProductExists={true}
        sourceMeatProductCode={'foo'}
        sourceMeatProductDesc={'bar'}
        generateMeatRequest={() => {}}
        getSourceMeatOrderPreview={() => {}}
        handleSubmit={() => {}}
        productsExist={{}}
        getStations={() => {}}
        showProductSourceMeatTable={true}
        quantity={4}
        products={{}}
        clearSourceMeatOrderPreview={() => {}}
        pristine={true}
        sourceMeatOrderPreview={{ quantity: 19 }}
        stationOptions={[]}
        stations={[]}
        additives={additives}
        submitting={false}
        invalid={false}
        clearMeatRequestByFinishedProduct={() => {}}
        reset={() => {}}
        requesting={false}
      />
    );

    jestExpect(wrapper.find(RequestMeatAdditiveTable).props().additives).toEqual(additives);
  });

  test('should not render additivesTable when no additives exist', () => {
    const additives = [];
    const wrapper = shallow(
      <MeatRequestByProductFormComponent
        clearProduct={() => {}}
        finishedProductExists={true}
        sourceMeatProductCode={'foo'}
        sourceMeatProductDesc={'bar'}
        generateMeatRequest={() => {}}
        getSourceMeatOrderPreview={() => {}}
        handleSubmit={() => {}}
        productsExist={{}}
        getStations={() => {}}
        showProductSourceMeatTable={true}
        quantity={4}
        products={{}}
        clearSourceMeatOrderPreview={() => {}}
        pristine={true}
        sourceMeatOrderPreview={{ quantity: 19 }}
        stationOptions={[]}
        stations={[]}
        additives={additives}
        submitting={false}
        invalid={false}
        clearMeatRequestByFinishedProduct={() => {}}
        reset={() => {}}
        requesting={false}
      />
    );

    jestExpect(wrapper.find(RequestMeatAdditiveTable).length).toEqual(0);
  });

  test('should fill out form and submit values to API', async () => {
    productResources.getProductInfo.mockImplementation((arg, callback) =>
      callback({
        data: productFactory.build({ code: '0078889' })
      })
    );

    let store = createReduxStore({});
    form = mount(
      <Provider store={store}>
        <MeatRequestByProductForm />
      </Provider>
    );

    await waitForAsyncTasks(form);

    semanticUI.selectOption(form, 'stationCode', 0);
    semanticUI.changeInput(form, 'finishedProductCode', '78889');
    semanticUI.changeInput(form, 'quantity', '5');
    semanticUI.selectOption(form, 'unitOfMeasure', 1);
    jestExpect(semanticUI.getSelectValue(form, 'unitOfMeasure')).toEqual('PIECE');
    form.find('form').simulate('submit');

    jestExpect(sourceMeatResources.getSourceMeatOrderPreviewByProduct.mock.calls[0][0]).toEqual({
      productCode: '0078889',
      quantity: '5',
      unitOfMeasure: 'PIECE'
    });

    const tableBody = form.find('TableBody');
    jestExpect(tableBody.find('TableRow')).toHaveLength(1);

    const row1 = tableBody.find('TableRow').at(0);
    const row1Cell = row1.find('TableCell');
    jestExpect(row1Cell.at(0).html()).toContain('0079007');
    jestExpect(row1Cell.at(1).html()).toContain('FLEMINGS CAB PRHOUSE STK');
    jestExpect(row1Cell.at(3).html()).toContain('PC');

    jestExpect(semanticUI.getInputValue(form, 'sourceMeatQuantity')).toEqual(5);
    semanticUI.changeInput(form, 'sourceMeatQuantity', '6');

    form.find('form').simulate('submit');

    jestExpect(sourceMeatResources.generateSourceMeatOrders.mock.calls[1][0]).toEqual([
      {
        additives: [],
        targetProductCode: '0078889',
        targetProductDesc: 'QB, PRIME T-BONE STEAK 205',
        productCode: '0079007',
        productDesc: 'FLEMINGS CAB PRHOUSE STK',
        quantity: '6',
        stationId: 21421402142,
        unitOfMeasure: 'CASE'
      }
    ]);
  });

  test('should not get source meat preview if product is invalid', () => {
    productResources.getProductInfo.mockImplementation((arg, success, fail) => fail(() => {}));
    sourceMeatResources.getSourceMeatOrderPreviewByProduct.mockImplementation((arg, success) =>
      success(null)
    );

    let store = createReduxStore({});
    form = mount(
      <Provider store={store}>
        <MeatRequestByProductForm />
      </Provider>
    );
    semanticUI.changeInput(form, 'finishedProductCode', 'abc');
    semanticUI.changeInput(form, 'quantity', '5');
    semanticUI.selectOption(form, 'unitOfMeasure', 1);

    jestExpect(sourceMeatResources.getSourceMeatOrderPreviewByProduct).not.toHaveBeenCalled();
  });

  test('should not get source meat preview if quantity is invalid', () => {
    let store = createReduxStore({});
    form = mount(
      <Provider store={store}>
        <MeatRequestByProductForm />
      </Provider>
    );

    semanticUI.changeInput(form, 'finishedProductCode', '0078889');
    semanticUI.changeInput(form, 'quantity', -1);
    semanticUI.selectOption(form, 'unitOfMeasure', 1);

    jestExpect(sourceMeatResources.getSourceMeatOrderPreviewByProduct).not.toHaveBeenCalled();
  });

  test('should not get source meat preview if product type is invalid', () => {
    productResources.getProductInfo.mockImplementation((arg, success) =>
      success({ data: productFactory.build({ code: '0078889', productOutput: 'SOURCE' }) })
    );

    let store = createReduxStore({});
    form = mount(
      <Provider store={store}>
        <MeatRequestByProductForm />
      </Provider>
    );

    semanticUI.changeInput(form, 'finishedProductCode', '0078889');
    semanticUI.changeInput(form, 'quantity', 1);
    semanticUI.selectOption(form, 'unitOfMeasure', 1);

    jestExpect(sourceMeatResources.getSourceMeatOrderPreviewByProduct).not.toHaveBeenCalled();
  });

  test('should not get source meat preview if product is byproduct', () => {
    productResources.getProductInfo.mockImplementation((arg, callback) =>
      callback({
        data: productFactory.build({
          code: '0078880',
          productOutput: 'BYPRODUCT_ONLY'
        })
      })
    );
    let store = createReduxStore({});
    form = mount(
      <Provider store={store}>
        <MeatRequestByProductForm />
      </Provider>
    );

    semanticUI.changeInput(form, 'quantity', 1);
    semanticUI.selectOption(form, 'unitOfMeasure', 1);
    form.find('form').simulate('submit');

    jestExpect(sourceMeatResources.getSourceMeatOrderPreviewByProduct).not.toHaveBeenCalled();
  });

  test('should clear source meat order preview model from store after successful submit', () => {
    let sourceMeatPreview = SourceMeatPreviewFactory.build();
    let store = createReduxStore({
      meatRequestInfo: {
        sourceMeatOrderPreview: {
          sourceMeatPreview
        },
        showProductSourceMeatTable: true,
        requesting: false,
        stations: [StationFactory.build({})]
      }
    });

    form = mount(
      <Provider store={store}>
        <MeatRequestByProductForm />
      </Provider>
    );

    form.unmount();

    jestExpect(store.getState().meatRequestInfo.sourceMeatOrderPreview).toEqual({});
    jestExpect(store.getState().meatRequestInfo.showProductSourceMeatTable).toEqual(false);
  });
});

describe('Clearing product from state', () => {
  describe('componentWillReceiveProps()', () => {
    let component;
    let finishedProductInfo = productFactory.build();

    let generateMeatRequest = jest.fn();
    let handleSubmit = jest.fn();
    let getSourceMeatOrderPreview = jest.fn();
    let clearProduct = jest.fn();
    let getStations = jest.fn();

    test('should clear source when changing product', () => {
      let clearMeatRequestByFinishedProduct = jest.fn();

      component = shallow(
        <MeatRequestByProductFormComponent
          clearProduct={clearProduct}
          finishedProductExists={true}
          generateMeatRequest={generateMeatRequest}
          getSourceMeatOrderPreview={getSourceMeatOrderPreview}
          handleSubmit={handleSubmit}
          finishedProductInfo={finishedProductInfo}
          products={{}}
          getStations={getStations}
          clearMeatRequestByFinishedProduct={clearMeatRequestByFinishedProduct}
          pristine={true}
          submitting={false}
          stations={[]}
          stationOptions={[]}
          invalid={false}
          reset={() => {}}
          showProductSourceMeatTable={true}
          requesting={false}
        />
      );

      finishedProductInfo = PRODUCT_1;
      component.setProps({ finishedProductInfo });
      jestExpect(clearMeatRequestByFinishedProduct).toHaveBeenCalledTimes(1);
    });

    test('should clear source when changing product from defined to undefined', () => {
      let clearMeatRequestByFinishedProduct = jest.fn();

      component = shallow(
        <MeatRequestByProductFormComponent
          clearProduct={clearProduct}
          finishedProductExists={true}
          generateMeatRequest={generateMeatRequest}
          getSourceMeatOrderPreview={getSourceMeatOrderPreview}
          handleSubmit={handleSubmit}
          getStations={getStations}
          finishedProductInfo={finishedProductInfo}
          products={{}}
          clearMeatRequestByFinishedProduct={clearMeatRequestByFinishedProduct}
          pristine={true}
          stationOptions={[]}
          stations={[]}
          submitting={false}
          invalid={false}
          reset={() => {}}
          showProductSourceMeatTable={true}
          requesting={false}
        />
      );

      finishedProductInfo = PRODUCT_1;

      component.setProps({ finishedProductInfo: undefined });

      jestExpect(clearMeatRequestByFinishedProduct).toHaveBeenCalledTimes(1);
    });

    test('should call getProduct Action on blur', () => {
      const store = createReduxStore({});
      const DecoratedComponent = reduxForm({ form: 'test' })(MeatRequestByProductFormComponent);

      const getProductMock = jest.fn();
      const wrapper = mount(
        <Provider store={store}>
          <DecoratedComponent
            clearProduct={clearProduct}
            finishedProductExists={true}
            generateMeatRequest={generateMeatRequest}
            getSourceMeatOrderPreview={getSourceMeatOrderPreview}
            sourceMeatOrderPreview={null}
            handleSubmit={handleSubmit}
            getProduct={getProductMock}
            setProductExistTo={() => {}}
            getStations={getStations}
            finishedProductInfo={finishedProductInfo}
            products={{}}
            clearSourceMeatOrderPreview={() => {}}
            pristine={true}
            stationOptions={[]}
            stations={[]}
            submitting={false}
            invalid={false}
            clearMeatRequestByFinishedProduct={() => {}}
            reset={() => {}}
            showProductSourceMeatTable={true}
            requesting={false}
          />
        </Provider>
      );

      let value = '0078889';
      semanticUI.changeInput(wrapper.find(Field), 'finishedProductCode', value);

      jestExpect(getProductMock).toHaveBeenCalled();
    });

    test('should call getProduct Action on change', () => {
      const store = createReduxStore({});
      const DecoratedComponent = reduxForm({ form: 'test' })(MeatRequestByProductFormComponent);

      const setProductExistToMock = jest.fn();
      const wrapper = mount(
        <Provider store={store}>
          <DecoratedComponent
            clearProduct={clearProduct}
            finishedProductExists={true}
            generateMeatRequest={generateMeatRequest}
            getSourceMeatOrderPreview={getSourceMeatOrderPreview}
            handleSubmit={handleSubmit}
            setProductExistTo={setProductExistToMock}
            getStations={getStations}
            finishedProductInfo={finishedProductInfo}
            products={{}}
            clearSourceMeatOrderPreview={() => {}}
            pristine={true}
            stationOptions={[]}
            stations={[]}
            submitting={false}
            invalid={false}
            clearMeatRequestByFinishedProduct={() => {}}
            reset={() => {}}
            showProductSourceMeatTable={true}
            requesting={false}
          />
        </Provider>
      );

      let value = '0078889';
      const inputField = wrapper.find(Field).find('input[name="finishedProductCode"]');

      inputField.simulate('change', { target: { value } });

      jestExpect(setProductExistToMock).toHaveBeenCalledWith('finishedProductCode', true);
    });

    test('should call setProductExistsTo Action on error callback', () => {
      const store = createReduxStore({});
      const DecoratedComponent = reduxForm({ form: 'test' })(MeatRequestByProductFormComponent);
      const getProductMock = jest.fn((arg, success) => success());
      const setProductExistsToMock = jest.fn();

      const wrapper = mount(
        <Provider store={store}>
          <DecoratedComponent
            clearProduct={clearProduct}
            finishedProductExists={true}
            generateMeatRequest={generateMeatRequest}
            getSourceMeatOrderPreview={getSourceMeatOrderPreview}
            handleSubmit={handleSubmit}
            setProductExistTo={setProductExistsToMock}
            getStations={getStations}
            finishedProductInfo={finishedProductInfo}
            products={{}}
            clearSourceMeatOrderPreview={() => {}}
            pristine={true}
            stationOptions={[]}
            stations={[]}
            submitting={false}
            getProduct={getProductMock}
            invalid={false}
            clearMeatRequestByFinishedProduct={() => {}}
            reset={() => {}}
            showProductSourceMeatTable={true}
            requesting={false}
          />
        </Provider>
      );

      const inputField = wrapper.find(Field).find('input[name="finishedProductCode"]');

      inputField.simulate('blur', { target: { value: '0078889' } });

      jestExpect(setProductExistsToMock).toHaveBeenCalledWith('finishedProductCode', false);
    });

    describe('rendering message for Product Component', () => {
      test('should pass NOT_A_PRODUCT_CODE when product does not exist', () => {
        const productsExist = {
          finishedProductCode: false
        };

        const wrapper = shallow(
          <MeatRequestByProductFormComponent
            clearProduct={clearProduct}
            finishedProductExists={true}
            generateMeatRequest={generateMeatRequest}
            getSourceMeatOrderPreview={getSourceMeatOrderPreview}
            handleSubmit={handleSubmit}
            productsExist={productsExist}
            getStations={getStations}
            finishedProductInfo={finishedProductInfo}
            products={{}}
            clearSourceMeatOrderPreview={() => {}}
            pristine={true}
            stationOptions={[]}
            stations={[]}
            submitting={false}
            invalid={false}
            clearMeatRequestByFinishedProduct={() => {}}
            reset={() => {}}
            showProductSourceMeatTable={true}
            requesting={false}
          />
        );

        const productField = wrapper.find(Field).at(1);

        jestExpect(productField.props().message).toEqual(NOT_A_PRODUCT_CODE);
      });

      test('should pass null when product does exist', () => {
        const productsExist = {
          finishedProductCode: true
        };

        const wrapper = shallow(
          <MeatRequestByProductFormComponent
            clearProduct={clearProduct}
            finishedProductExists={true}
            generateMeatRequest={generateMeatRequest}
            getSourceMeatOrderPreview={getSourceMeatOrderPreview}
            handleSubmit={handleSubmit}
            getStations={getStations}
            productsExist={productsExist}
            products={{}}
            clearSourceMeatOrderPreview={() => {}}
            pristine={true}
            stationOptions={[]}
            stations={[]}
            submitting={false}
            invalid={false}
            clearMeatRequestByFinishedProduct={() => {}}
            reset={() => {}}
            showProductSourceMeatTable={true}
            requesting={false}
            byproductMessage={null}
          />
        );

        const productField = wrapper.find(Field).at(1);

        jestExpect(productField.props().message).toEqual(null);
      });

      test('should show by product message', () => {
        const productsExist = {
          finishedProductCode: true
        };

        const byproductMessage = 'Must be produced item';

        const wrapper = shallow(
          <MeatRequestByProductFormComponent
            clearProduct={clearProduct}
            finishedProductExists={true}
            generateMeatRequest={generateMeatRequest}
            getSourceMeatOrderPreview={getSourceMeatOrderPreview}
            handleSubmit={handleSubmit}
            getStations={getStations}
            productsExist={productsExist}
            products={{}}
            clearSourceMeatOrderPreview={() => {}}
            pristine={true}
            stationOptions={[]}
            stations={[]}
            submitting={false}
            invalid={false}
            clearMeatRequestByFinishedProduct={() => {}}
            reset={() => {}}
            showProductSourceMeatTable={true}
            requesting={false}
            byproductMessage={byproductMessage}
          />
        );

        const productField = wrapper.find(Field).at(1);

        jestExpect(productField.props().message).toEqual(byproductMessage);
      });

      test('should return null if no product available', () => {
        jestExpect(getByproductMessage(null)).toEqual(null);
      });

      test('should return null when product is finished product', () => {
        const finishedProduct = productFactory.build({ code: '0078889' });
        jestExpect(getByproductMessage(finishedProduct)).toEqual(null);
      });

      test('should return message when product is source product', () => {
        const finishedProduct = productFactory.build({ code: '0078889', productOutput: 'SOURCE' });
        jestExpect(getByproductMessage(finishedProduct)).toEqual('Must be produced item');
      });

      test('should return message when product is byproduct only product', () => {
        const finishedProduct = productFactory.build({
          code: '0078889',
          productOutput: 'BYPRODUCT_ONLY'
        });
        jestExpect(getByproductMessage(finishedProduct)).toEqual(
          'Cannot request meat by finished # for byproduct only items'
        );
      });
    });
  });

  test('check product and source meat info in cleared in store', () => {
    const clearMeatRequestByFinishedProduct = jest.fn();
    const component = new MeatRequestByProductFormComponent({
      clearMeatRequestByFinishedProduct
    });

    component.componentWillUnmount();

    jestExpect(clearMeatRequestByFinishedProduct).toHaveBeenCalledTimes(1);
  });
});
