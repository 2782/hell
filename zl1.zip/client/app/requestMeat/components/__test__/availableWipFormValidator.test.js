import Validator from '../availableWipFormValidator';

describe('submission validation', () => {
  test('should throw submission error when cannot reserve for another room', () => {
    const errorResponse = {
      error: {
        details: [
          {
            field: 'roomCode',
            issue: 'CANNOT_CHANGE',
            location: 'body',
            type: null
          }
        ]
      }
    };

    try {
      Validator.processErrorResponse(errorResponse);
    } catch ({ errors }) {
      jestExpect(errors.barcode).toEqual(
        'This box of WIP is reserved for another room. Cannot bring it into the room.'
      );
    }
  });

  test('should throw submission error when box with barcode is not found', () => {
    const errorResponse = {
      exceptionClass: 'com.sysco.prime.exception.NotFoundException',
      exceptionMessage: '[find Box] with barcode 2111148 Not Found',
      method: 'PUT',
      path: '/api/boxes/wip/2111148/room/A',
      status: 404,
      statusText: 'Not Found'
    };

    try {
      Validator.processErrorResponse(errorResponse);
    } catch ({ errors }) {
      jestExpect(errors.barcode).toEqual('Invalid Barcode');
    }
  });

  test('should throw submission error when another error takes place', () => {
    const errorResponse = {
      exceptionClass: 'com.sysco.prime.exception.InvalidValue',
      exceptionMessage: '',
      method: 'PUT',
      path: '/api/boxes/wip/2111148/room/A',
      status: 404,
      statusText: 'Invalid Found'
    };

    try {
      Validator.processErrorResponse(errorResponse);
    } catch ({ errors }) {
      jestExpect(errors.barcode).toEqual('Cannot bring WIP in portion room.');
    }
  });
});
