import _ from 'lodash';
import { SubmissionError } from 'redux-form';
import {
  exactLength,
  productExists,
  required,
  validate,
  wholeNumber
} from '../../shared/formValidations';

export const validateSubmission = (values, props) => {
  const { stationCode, sourceProductCode } = values;
  const { sourceProductExists } = props;
  let errors = {};

  errors = validate(errors, sourceProductCode, 'sourceProductCode', [
    required,
    wholeNumber,
    exactLength(7),
    productExists(sourceProductExists)
  ]);
  errors = validate(errors, stationCode, 'stationCode', [required]);

  if (!_.isEmpty(errors)) {
    throw new SubmissionError(Object.assign({}, errors, {}));
  }
};
