import _ from 'lodash';
import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { Button, Divider, Form, Grid, Table } from 'semantic-ui-react';
import {
  generateMeatRequest,
  getSourceMeatOrderPreview,
  getStations,
  clearMeatRequestByFinishedProduct
} from '../actions/meatRequestActions';
import { Field, formValueSelector, reduxForm, SubmissionError } from 'redux-form';
import ProductDuplicate from '../../shared/components/product/ProductDuplicate';
import { normalizeProductCode } from '../../shared/components/product/normalizer';
import FormElement from '../../shared/FormElement';
import {
  isQuantityInRangeBottomInclusive,
  isQuantityInRange,
  isQuantityValid,
  validateMeatRequest
} from './meatRequestValidator';
import {
  nonNegativeNumber,
  number,
  positiveNumber,
  required,
  wholeNumber
} from '../../shared/validation/formFieldValidations';
import { NOT_A_PRODUCT_CODE } from '../../../config/errorMessage';
import { getProduct, setProductExistTo } from '../../shared/components/product/actionsDuplicate';
import RequestMeatAdditiveTable from './RequestMeatAdditiveTable';
import {
  generateAdditivesInitialValues,
  generateStationOptions
} from '../selectors/meatRequestByProductFormSelector';
import { reportingTableHelpers } from '../../productActivity/helpers';
import { validateSubmission } from './meatRequestByProductFormValidator';

export class MeatRequestByProductFormComponent extends React.Component {
  constructor(props) {
    super(props);

    this.handleFinishedProductCodeBlur = this.handleFinishedProductCodeBlur.bind(this);
    this.handleUnitOfMeasureChange = this.handleUnitOfMeasureChange.bind(this);
    this.handleQuantityChange = this.handleQuantityChange.bind(this);
    this.handleProductCodeChange = this.handleProductCodeChange.bind(this);
    this.previewSourceMeatOrder = this.previewSourceMeatOrder.bind(this);
    this.isProductInfoValid = this.isProductInfoValid.bind(this);
    this.submit = this.submit.bind(this);
  }

  componentDidUpdate(prevProps) {
    const { clearMeatRequestByFinishedProduct } = this.props;

    if (
      (prevProps.finishedProductInfo && !this.props.finishedProductInfo) ||
      (prevProps.finishedProductInfo &&
        this.props.finishedProductInfo &&
        this.props.finishedProductInfo.code !== prevProps.finishedProductInfo.code)
    ) {
      clearMeatRequestByFinishedProduct();
    }
  }

  submit(values) {
    const { showProductSourceMeatTable, byproductMessage } = this.props;
    validateSubmission(values);
    if (byproductMessage !== null) {
      return;
    }

    if (!showProductSourceMeatTable) {
      return this.previewSourceMeatOrder(values);
    } else {
      return this.requestSourceMeatOrder(values);
    }
  }

  requestSourceMeatOrder(values) {
    const {
      reset,
      clearMeatRequestByFinishedProduct,
      finishedProductInfo,
      sourceMeatOrderPreview,
      generateMeatRequest,
      stations
    } = this.props;
    const selectedStation = _.find(stations, item => {
      return item.stationCode === values.stationCode;
    });

    validateMeatRequest(values);

    const request = [
      {
        targetProductCode: finishedProductInfo.code,
        targetProductDesc: finishedProductInfo.description,
        productCode: sourceMeatOrderPreview.productCode,
        productDesc: sourceMeatOrderPreview.productDesc,
        quantity: values.sourceMeatQuantity,
        additives: _.get(values, 'additives', []),
        stationId: selectedStation.id,
        unitOfMeasure: 'CASE'
      }
    ];

    return generateMeatRequest(
      request,
      () => {
        clearMeatRequestByFinishedProduct();
        reset();
      },
      error => {
        throw new SubmissionError({
          _error: error.message
        });
      }
    );
  }

  componentDidMount() {
    const { getStations } = this.props;
    getStations();
  }

  componentWillUnmount() {
    const { clearMeatRequestByFinishedProduct } = this.props;
    clearMeatRequestByFinishedProduct();
  }

  handleFinishedProductCodeBlur(event, normalizedProductCode, prevValue, fieldName) {
    const { getProduct, setProductExistTo } = this.props;
    if (!_.isEmpty(normalizedProductCode)) {
      getProduct(normalizedProductCode, () => setProductExistTo(fieldName, false));
    }
  }

  handleProductCodeChange(event, productCode, prevValue, fieldName) {
    const { setProductExistTo } = this.props;
    if (!_.isEmpty(productCode)) {
      setProductExistTo(fieldName, true);
    }
  }

  isProductInfoValid() {
    const { finishedProductInfo, quantity } = this.props;

    return finishedProductInfo && finishedProductInfo.code && quantity > 0;
  }

  handleUnitOfMeasureChange(input, event) {
    const { finishedProductCode, quantity } = this.props;

    this.previewSourceMeatOrder({
      finishedProductCode,
      quantity,
      unitOfMeasure: event
    });
  }

  handleQuantityChange(input, event) {
    const { finishedProductCode, unitOfMeasure } = this.props;

    this.previewSourceMeatOrder({
      finishedProductCode,
      quantity: event,
      unitOfMeasure
    });
  }

  previewSourceMeatOrder(values) {
    const { getSourceMeatOrderPreview, invalidProductType } = this.props;

    if (!this.isProductInfoValid() || !isQuantityValid(values.quantity) || invalidProductType) {
      return;
    }

    const productInfoInput = {
      productCode: values.finishedProductCode,
      quantity: values.quantity,
      unitOfMeasure: values.unitOfMeasure
    };
    getSourceMeatOrderPreview(productInfoInput);
  }

  showFormError() {
    if (this.props.error) {
      return <span className={'ui red message meat-request-error'}>{this.props.error}</span>;
    }
  }

  renderSourceMeatPreview() {
    const { sourceMeatProductCode, sourceMeatProductDesc, sourceMeatProductUom } = this.props;

    return (
      <div>
        <div>
          <Table columns={3} fixed size='small'>
            <Table.Header>
              <Table.Row>
                <Table.HeaderCell width={5} textAlign='left'>
                  Source Product
                </Table.HeaderCell>
                <Table.HeaderCell width={8}>&nbsp;</Table.HeaderCell>
                <Table.HeaderCell width={3} textAlign='left'>
                  Quantity
                </Table.HeaderCell>
                <Table.HeaderCell width={3}>U/M</Table.HeaderCell>
              </Table.Row>
            </Table.Header>
            <Table.Body>
              <Table.Row key={'source-product'}>
                <Table.Cell width={5} className={'source-number'}>
                  {sourceMeatProductCode}
                </Table.Cell>
                <Table.Cell width={8} className={'source-description'}>
                  {sourceMeatProductDesc}
                </Table.Cell>
                <Table.Cell width={3} textAlign='left'>
                  <Field
                    component={FormElement}
                    name='sourceMeatQuantity'
                    pid='request-meat-source-meat-quantity'
                    as={Form.Input}
                    type='text'
                    validate={[
                      required,
                      number,
                      wholeNumber,
                      nonNegativeNumber,
                      isQuantityInRangeBottomInclusive
                    ]}
                    fluid
                  />
                </Table.Cell>
                <Table.Cell width={3} className={'source-uom'}>
                  {reportingTableHelpers.formatUnitOfMeasure(sourceMeatProductUom)}
                </Table.Cell>
              </Table.Row>
            </Table.Body>
          </Table>
        </div>
      </div>
    );
  }

  render() {
    const {
      handleSubmit,
      stationOptions,
      productsExist,
      products,
      finishedProductCode,
      showProductSourceMeatTable,
      additives,
      submitting,
      pristine,
      invalid,
      requesting,
      byproductMessage,
      invalidProductType
    } = this.props;
    return (
      <div className='meat-request-form-wrapper'>
        <Form pid='meat-request-form' size={'large'} onSubmit={handleSubmit(this.submit)}>
          <Form.Group>
            <Field
              component={FormElement}
              name='stationCode'
              pid='request-meat-station-code'
              as={Form.Select}
              options={stationOptions}
              type='text'
              label='station'
            />
          </Form.Group>

          <Divider hidden />

          <Grid>
            <Grid.Row>
              <Grid.Column>
                <Field
                  component={ProductDuplicate}
                  name='finishedProductCode'
                  pid='request-meat-finished-product-code'
                  namespace={'meatRequestByProductForm-finishedProductCode'}
                  label='product #'
                  product={products[finishedProductCode] || {}}
                  normalize={normalizeProductCode}
                  message={
                    _.get(productsExist, 'finishedProductCode', true)
                      ? byproductMessage
                      : NOT_A_PRODUCT_CODE
                  }
                  onBlur={this.handleFinishedProductCodeBlur}
                  onChange={this.handleProductCodeChange}
                />
              </Grid.Column>
            </Grid.Row>
          </Grid>

          <Divider hidden />

          <Form.Group>
            <Field
              component={FormElement}
              width={3}
              name='quantity'
              pid='request-meat-quantity'
              as={Form.Input}
              validate={[required, number, wholeNumber, positiveNumber, isQuantityInRange]}
              type='text'
              onChange={this.handleQuantityChange}
              label='quantity'
            />
            <Field
              component={FormElement}
              className={'request-meat-unit-of-measure'}
              width={4}
              name='unitOfMeasure'
              pid='request-meat-unit-of-measure'
              as={Form.Select}
              options={unitOfMeasuresOptions}
              type='text'
              onChange={this.handleUnitOfMeasureChange}
              label='Unit of Measure'
            />
          </Form.Group>

          {showProductSourceMeatTable ? this.renderSourceMeatPreview() : null}
          {showProductSourceMeatTable && !_.isEmpty(additives) ? (
            <RequestMeatAdditiveTable additives={additives} />
          ) : null}

          <Divider hidden />

          <Button
            primary
            size={'large'}
            loading={submitting}
            disabled={submitting || pristine || invalid || requesting || invalidProductType}
            id='save-request-meat-button'
            className='submit'
          >
            Submit
          </Button>

          <Divider hidden />

          {this.showFormError()}
        </Form>
      </div>
    );
  }
}

MeatRequestByProductFormComponent.propTypes = {
  stationOptions: PropTypes.array.isRequired,
  stations: PropTypes.array.isRequired,
  generateMeatRequest: PropTypes.func.isRequired,
  finishedProductInfo: PropTypes.object,
  byproductMessage: PropTypes.string,

  unitOfMeasure: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  quantity: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  sourceMeatQuantity: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  getSourceMeatOrderPreview: PropTypes.func.isRequired,
  clearMeatRequestByFinishedProduct: PropTypes.func.isRequired,
  getStations: PropTypes.func.isRequired,
  reset: PropTypes.func.isRequired,
  setProductExistTo: PropTypes.func,
  getProduct: PropTypes.func,
  sourceMeatOrderPreview: PropTypes.object,
  error: PropTypes.string,
  handleSubmit: PropTypes.func.isRequired,
  submitting: PropTypes.bool.isRequired,
  pristine: PropTypes.bool.isRequired,
  invalid: PropTypes.bool.isRequired,
  sourceMeatProductDesc: PropTypes.string,
  sourceMeatProductCode: PropTypes.string,
  sourceMeatProductUom: PropTypes.string,
  productsExist: PropTypes.object,
  products: PropTypes.object,
  finishedProductCode: PropTypes.string,
  additives: PropTypes.array,
  showProductSourceMeatTable: PropTypes.bool.isRequired,
  keydown: PropTypes.object,
  requesting: PropTypes.bool.isRequired,
  invalidProductType: PropTypes.bool
};

const unitOfMeasuresOptions = [
  { key: 1, text: 'CASE', value: 'CASE' },
  { key: 2, text: 'PIECE', value: 'PIECE' }
];

export const getByproductMessage = finishedProductInfo => {
  if (_.isUndefined(finishedProductInfo) || _.isNull(finishedProductInfo)) {
    return null;
  } else {
    if (finishedProductInfo.productOutput === 'BYPRODUCT_ONLY') {
      return 'Cannot request meat by finished # for byproduct only items';
    } else if (finishedProductInfo.productOutput === 'SOURCE') {
      return 'Must be produced item';
    } else {
      return null;
    }
  }
};

const selector = formValueSelector('meatRequestByProductForm');
const mapStateToProps = state => {
  const finishedProductCode = selector(state, 'finishedProductCode');
  const {
    stations,
    sourceMeatOrderPreview,
    showProductSourceMeatTable,
    requesting
  } = state.meatRequestInfo;
  const productsExist = state.productDuplicate.productsExist;
  const products = state.productDuplicate.products;
  const finishedProductInfo = products[finishedProductCode];
  const initialAdditiveQuantities = generateAdditivesInitialValues(sourceMeatOrderPreview);
  const byproductMessage = getByproductMessage(finishedProductInfo);
  const invalidProductType = byproductMessage !== null;

  return {
    initialValues: {
      unitOfMeasure: 'CASE',
      sourceMeatQuantity: sourceMeatOrderPreview.quantity,
      showProductSourceMeatTable: false,
      additives: initialAdditiveQuantities
    },
    finishedProductInfo,
    quantity: selector(state, 'quantity'),
    unitOfMeasure: selector(state, 'unitOfMeasure'),
    sourceMeatProductDesc: _.get(sourceMeatOrderPreview, 'productDesc', ''),
    sourceMeatProductCode: _.get(sourceMeatOrderPreview, 'productCode', ''),
    sourceMeatProductUom: _.get(sourceMeatOrderPreview, 'unitOfMeasure', ''),
    finishedProductCode,
    productsExist,
    products,
    sourceMeatOrderPreview,
    sourceMeatQuantity: sourceMeatOrderPreview ? sourceMeatOrderPreview.quantity : '',
    additives: sourceMeatOrderPreview ? sourceMeatOrderPreview.additives : [],
    stationOptions: generateStationOptions(stations),
    stations,
    showProductSourceMeatTable,
    requesting,
    byproductMessage,
    invalidProductType
  };
};

const mapDispatchToProps = dispatch =>
  bindActionCreators(
    {
      clearMeatRequestByFinishedProduct,
      getSourceMeatOrderPreview,
      generateMeatRequest,
      getStations,
      setProductExistTo,
      getProduct
    },
    dispatch
  );

const MeatRequestByProductForm = connect(
  mapStateToProps,
  mapDispatchToProps
)(
  reduxForm({
    form: 'meatRequestByProductForm',
    enableReinitialize: true,
    keepDirtyOnReinitialize: true
  })(MeatRequestByProductFormComponent)
);

export default MeatRequestByProductForm;
