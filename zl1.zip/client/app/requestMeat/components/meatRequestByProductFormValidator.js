import _ from 'lodash';
import { SubmissionError } from 'redux-form';
import { required, validate } from '../../shared/formValidations';

export const validateSubmission = values => {
  const { finishedProductCode } = values;
  let errors = {};

  errors = validate(errors, finishedProductCode, 'finishedProductCode', [required]);

  if (!_.isEmpty(errors)) {
    throw new SubmissionError(Object.assign({}, errors, {}));
  }
};
