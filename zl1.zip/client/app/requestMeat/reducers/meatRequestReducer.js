import {
  CLEAR_MEAT_REQUEST_BY_BLEND_PRICING_MODEL,
  BLEND_SOURCE_MEAT_TABLE_DISPLAYED,
  PRODUCT_SOURCE_MEAT_TABLE_DISPLAYED,
  GET_BLENDS,
  GET_BLEND_PRICING_MODEL,
  GRABBED_WIP_BOXES,
  RESET_CUT_STATIONS_INFO,
  RESET_SOURCE_MEAT_ORDER_PREVIEW,
  UPDATE_CUT_STATIONS_INFO,
  UPDATE_SOURCE_MEAT_ORDER_PREVIEW,
  UPDATE_SOURCE_PRODUCT_INFO,
  UPDATED_WIP_SORTING,
  CLEAR_MEAT_REQUEST_BY_FINISHED_PRODUCT,
  REGISTER_BARCODE_FIELD,
  RESET_MEAT_REQUEST,
  MEAT_REQUESTED,
  SET_SELECTED_BLEND
} from '../actions/meatRequestActionTypes';

export const initialState = {
  barcodeField: {
    getRenderedComponent: () => ({
      focusInput: () => {}
    })
  },
  stations: [],
  sourceMeatOrderPreview: {},
  blends: [],
  selectedBlend: null,
  blendPricingModel: {},
  sourceProductInfo: {},
  showBlendSourceMeatTable: false,
  showProductSourceMeatTable: false,
  requesting: false,
  wipBoxes: null
};

export default (state = initialState, action) => {
  switch (action.type) {
    case UPDATE_CUT_STATIONS_INFO:
      return {
        ...state,
        stations: action.payload
      };
    case RESET_CUT_STATIONS_INFO:
      return {
        ...state,
        stations: []
      };

    case RESET_SOURCE_MEAT_ORDER_PREVIEW:
      return {
        ...state,
        sourceMeatOrderPreview: {}
      };

    case UPDATE_SOURCE_MEAT_ORDER_PREVIEW:
      return {
        ...state,
        sourceMeatOrderPreview: action.payload
      };

    case GET_BLENDS:
      return {
        ...state,
        blends: action.payload
      };

    case GET_BLEND_PRICING_MODEL:
      return {
        ...state,
        blendPricingModel: action.payload
      };

    case CLEAR_MEAT_REQUEST_BY_BLEND_PRICING_MODEL:
      return {
        ...state,
        blendPricingModel: {},
        sourceProductInfo: {},
        showBlendSourceMeatTable: false,
        selectedBlend: null
      };

    case UPDATE_SOURCE_PRODUCT_INFO:
      return {
        ...state,
        sourceProductInfo: action.payload
      };

    case BLEND_SOURCE_MEAT_TABLE_DISPLAYED:
      return {
        ...state,
        showBlendSourceMeatTable: true
      };

    case PRODUCT_SOURCE_MEAT_TABLE_DISPLAYED:
      return {
        ...state,
        showProductSourceMeatTable: true
      };

    case GRABBED_WIP_BOXES:
      return {
        ...state,
        wipBoxes: action.payload
      };

    case UPDATED_WIP_SORTING:
      return {
        ...state,
        ...action.payload
      };

    case CLEAR_MEAT_REQUEST_BY_FINISHED_PRODUCT:
      return {
        ...state,
        sourceMeatOrderPreview: {},
        showProductSourceMeatTable: false
      };

    case REGISTER_BARCODE_FIELD:
      return {
        ...state,
        barcodeField: action.payload
      };

    case RESET_MEAT_REQUEST:
      return {
        ...state,
        requesting: false
      };

    case MEAT_REQUESTED:
      return {
        ...state,
        requesting: true
      };

    case SET_SELECTED_BLEND:
      return {
        ...state,
        selectedBlend: action.payload
      };

    default:
      return state;
  }
};
