import { CHANGE_REPORT_TYPE, GET_ALL_FISCAL_CALENDARS } from '../actions/reportingActionTypes';

const initialState = {
  reportType: null,
  fiscalCalendars: []
};

export default (state = initialState, action) => {
  switch (action.type) {
    case CHANGE_REPORT_TYPE:
      return {
        ...state,
        reportType: action.payload
      };
    case GET_ALL_FISCAL_CALENDARS:
      return {
        ...state,
        fiscalCalendars: action.payload
      };
    default:
      return state;
  }
};
