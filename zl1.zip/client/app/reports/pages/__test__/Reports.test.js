import React from 'react';
import Reports, { getDisabledDays, getFiscalCalendarWeekNumber } from '../Reports';
import { createReduxStore } from '../../../store';
import { Provider } from 'react-redux';
import { mount } from 'enzyme';
import semanticUI from '../../../../test-helpers/semantic-ui';
import reportingResource from '../../../shared/api/reportingResources';
import {
  PRODUCT_IN_AND_OUT_REPORT,
  PROFITABILITY_REPORT,
  WEEKLY_RECAP_REPORT
} from '../../components/reportType';
import moment from 'moment';
import settingsResources from '../../../shared/api/settingsResources';
import portionRoomFactory from '../../../../test-factories/portionRoomFactory';
import { DEFAULT_DISPLAY_DATE_FORMAT } from '../../../shared/util/dateUtil';

jest.mock('../../../shared/api/reportingResources', () => ({
  downloadProfitabilityReport: jest.fn(() => Promise.resolve([])),
  downloadWeeklyRecapReport: jest.fn(() => Promise.resolve([])),
  downloadProductInAndOutReport: jest.fn(() => Promise.resolve([])),
  downloadCuttingStationProductivityReport: jest.fn(() => Promise.resolve([])),
  downloadHouseParReport: jest.fn(() => Promise.resolve([])),
  downloadYieldCostSummaryReport: jest.fn(() => Promise.resolve([])),
  downloadScaleSummary: jest.fn(() => Promise.resolve([])),
  downloadWipSpoil: jest.fn(() => Promise.resolve([])),
  downloadFinishedGoodMarketCostReport: jest.fn(() => Promise.resolve([]))
}));
jest.mock('../../../shared/api/settingsResources');

describe('Reports', () => {
  let portionRooms;
  beforeEach(() => {
    portionRooms = [
      portionRoomFactory.build({ code: 'A', description: 'Room A', roomType: 'CUTTING' }),
      portionRoomFactory.build({ code: 'B', description: 'Room B', roomType: 'CUTTING' }),
      portionRoomFactory.build({ code: 'C', description: 'Room C', roomType: 'CUTTING' }),
      portionRoomFactory.build({ code: 'D', description: 'Room D', roomType: 'GRINDING' })
    ];

    settingsResources.getRooms.mockResolvedValue({
      data: portionRooms
    });
  });

  afterEach(() => {
    settingsResources.getRooms.mockReset();
  });

  test('should send form values in request to download profitability report', () => {
    const form = mount(
      <Provider
        store={createReduxStore({
          portionRoomsInfo: { currentPortionRoom: { code: 'A' } }
        })}
      >
        <Reports />
      </Provider>
    );

    semanticUI.selectOption(form, 'reportType', 0);
    semanticUI.changeInput(form, 'reportDate', '06-25-2018');

    form.find('form').simulate('submit');

    jestExpect(reportingResource.downloadProfitabilityReport).toHaveBeenCalledWith({
      reportType: 'profitability',
      reportDate: '2018-06-25',
      fileDate: '06-25-2018',
      roomCode: 'A'
    });
  });

  test('should not show room drop down when room select is not one of reports that need room', async done => {
    let form = mount(
      <Provider
        store={createReduxStore({
          portionRoomsInfo: { currentPortionRoom: {} }
        })}
      >
        <Reports />
      </Provider>
    );

    semanticUI.selectOption(form, 'reportType', 1);
    form = form.update();

    semanticUI.changeInput(form, 'reportDate', '08-05-2018');
    jestExpect(semanticUI.doesSelectExist(form, 'room')).toEqual(false);
    done();
  });

  test('should show room list when currentPortionRoom is empty and one of reports that need room is selected', () => {
    reportingResource.downloadProfitabilityReport.mockReset();
    reportingResource.downloadProfitabilityReport.mockImplementation(() =>
      Promise.resolve({ data: [] })
    );

    let form = mount(
      <Provider
        store={createReduxStore({
          portionRoomsInfo: { currentPortionRoom: {} },
          settingsInfo: { rooms: portionRooms }
        })}
      >
        <Reports />
      </Provider>
    );

    semanticUI.selectOption(form, 'reportType', 0);
    form = form.update();

    const listOfOptions = semanticUI.getDropDownSelectionOptionsText(form, 'room');

    jestExpect(listOfOptions).toEqual(['A - Room A', 'B - Room B', 'C - Room C', 'D - Room D']);
  });

  test('should show room list when currentPortionRoom is a costing room', () => {
    reportingResource.downloadProfitabilityReport.mockReset();
    reportingResource.downloadProfitabilityReport.mockImplementation(() =>
      Promise.resolve({ data: [] })
    );

    let form = mount(
      <Provider
        store={createReduxStore({
          portionRoomsInfo: { currentPortionRoom: { code: 'A', roomType: 'COSTING' } },
          settingsInfo: { rooms: portionRooms }
        })}
      >
        <Reports />
      </Provider>
    );

    semanticUI.selectOption(form, 'reportType', 0);
    form = form.update();
    jestExpect(semanticUI.doesSelectExist(form, 'room')).toEqual(true);
  });

  test('should submit with room information from drop down when report which needs a room is selected', () => {
    reportingResource.downloadProfitabilityReport.mockReset();
    reportingResource.downloadProfitabilityReport.mockImplementation(() =>
      Promise.resolve({ data: [] })
    );

    let form = mount(
      <Provider
        store={createReduxStore({
          portionRoomsInfo: { currentPortionRoom: {} },
          settingsInfo: { rooms: portionRooms }
        })}
      >
        <Reports />
      </Provider>
    );

    form = form.update();

    semanticUI.selectOption(form, 'reportType', 0);
    semanticUI.changeInput(form, 'reportDate', '08-05-2018');
    semanticUI.selectOption(form, 'room', 1);

    form.find('form').simulate('submit');

    jestExpect(reportingResource.downloadProfitabilityReport).toHaveBeenCalledTimes(1);
    jestExpect(reportingResource.downloadProfitabilityReport).toHaveBeenCalledWith({
      reportType: 'profitability',
      reportDate: '2018-08-05',
      fileDate: '08-05-2018',
      roomCode: 'B',
      room: 'B'
    });
  });

  test('should send form values in request to download weekly recap report', () => {
    const form = mount(
      <Provider
        store={createReduxStore({
          portionRoomsInfo: { currentPortionRoom: { code: 'A' } },
          reportsInfo: {
            reportType: 'portionRoomWeekly',
            fiscalCalendars: [
              {
                startDate: '2018-07-01',
                nextStartDate: '2019-07-07'
              },
              {
                startDate: '2019-07-07',
                nextStartDate: '2019-09-08'
              },
              {
                startDate: '2019-09-08',
                nextStartDate: null
              }
            ]
          }
        })}
      >
        <Reports />
      </Provider>
    );

    semanticUI.selectOption(form, 'reportType', 1);
    semanticUI.changeInput(form, 'reportDate', '08-05-2018');

    form.find('form').simulate('submit');

    jestExpect(reportingResource.downloadWeeklyRecapReport).toHaveBeenCalledTimes(1);
    jestExpect(reportingResource.downloadWeeklyRecapReport).toHaveBeenCalledWith({
      reportType: 'portionRoomWeekly',
      reportDate: '2018-08-05',
      fileDate: '08-05-2018'
    });
  });

  test('should send form values in request to download cutting station productivity report', () => {
    const form = mount(
      <Provider
        store={createReduxStore({
          portionRoomsInfo: { currentPortionRoom: { code: 'A' } }
        })}
      >
        <Reports />
      </Provider>
    );

    semanticUI.selectOption(form, 'reportType', 2);
    semanticUI.changeInput(form, 'reportDate', '09-01-2018');

    form.find('form').simulate('submit');

    jestExpect(reportingResource.downloadCuttingStationProductivityReport).toHaveBeenCalledWith({
      roomCode: 'A',
      reportType: 'Cutting-Station-Productivity',
      reportDate: '2018-09-01',
      fileDate: '09-01-2018'
    });
  });

  test('should send form values in request to download product in-and-out report', () => {
    const form = mount(
      <Provider
        store={createReduxStore({
          portionRoomsInfo: { currentPortionRoom: { code: 'A' } }
        })}
      >
        <Reports />
      </Provider>
    );

    semanticUI.selectOption(form, 'reportType', 3);
    semanticUI.changeInput(form, 'reportDate', '09-01-2018');

    form.find('form').simulate('submit');

    jestExpect(reportingResource.downloadProductInAndOutReport).toHaveBeenCalledWith({
      roomCode: 'A',
      reportYearMonth: '2018-09'
    });
  });

  test('should send form values in request to download yield cost summary report', () => {
    const form = mount(
      <Provider
        store={createReduxStore({
          portionRoomsInfo: { currentPortionRoom: { code: 'A' } },
          reportsInfo: {
            reportType: 'Yield-Cost-Summary',
            fiscalCalendars: [
              {
                startDate: '2018-07-01',
                nextStartDate: '2019-07-07'
              },
              {
                startDate: '2019-07-07',
                nextStartDate: '2019-09-08'
              },
              {
                startDate: '2019-09-08',
                nextStartDate: null
              }
            ]
          }
        })}
      >
        <Reports />
      </Provider>
    );

    semanticUI.selectOption(form, 'reportType', 4);
    semanticUI.changeInput(form, 'reportDate', '09-16-2018');

    form.find('form').simulate('submit');

    jestExpect(reportingResource.downloadYieldCostSummaryReport).toHaveBeenCalledWith({
      reportType: 'Yield-Cost-Summary',
      reportDate: '2018-09-16',
      fileDate: '09-16-2018'
    });
  });

  test('should send form values in request to download house par report', () => {
    const form = mount(
      <Provider
        store={createReduxStore({
          portionRoomsInfo: { currentPortionRoom: { code: 'A' } },
          reportsInfo: {
            reportType: 'House-Par',
            fiscalCalendars: [
              {
                startDate: '2018-07-01',
                nextStartDate: '2019-07-07'
              },
              {
                startDate: '2019-07-07',
                nextStartDate: '2019-09-08'
              },
              {
                startDate: '2019-09-08',
                nextStartDate: null
              }
            ]
          }
        })}
      >
        <Reports />
      </Provider>
    );

    semanticUI.selectOption(form, 'reportType', 5);
    semanticUI.changeInput(form, 'reportDate', '11-25-2018');

    form.find('form').simulate('submit');

    jestExpect(reportingResource.downloadHouseParReport).toHaveBeenCalledWith({
      reportType: 'House-Par',
      reportDate: '2018-11-25',
      fileDate: '11-25-2018'
    });
  });

  test('should send form values in request to download scale summary report', () => {
    const form = mount(
      <Provider
        store={createReduxStore({
          portionRoomsInfo: { currentPortionRoom: { code: 'A' } }
        })}
      >
        <Reports />
      </Provider>
    );

    semanticUI.selectOption(form, 'reportType', 6);
    semanticUI.changeInput(form, 'reportDate', '11-24-2018');
    semanticUI.changeInput(form, 'endDate', '11-25-2018');

    form.find('form').simulate('submit');

    jestExpect(reportingResource.downloadScaleSummary).toHaveBeenCalledTimes(1);
    jestExpect(reportingResource.downloadScaleSummary).toHaveBeenCalledWith({
      reportType: 'Scale-Summary',
      reportDate: '2018-11-24',
      endDate: '2018-11-25',
      fileDate: '11-25-2018'
    });
  });

  test('should send form values in request to download wip spoil report', () => {
    const form = mount(
      <Provider
        store={createReduxStore({
          portionRoomsInfo: { currentPortionRoom: { code: 'A' } }
        })}
      >
        <Reports />
      </Provider>
    );

    semanticUI.selectOption(form, 'reportType', 8);
    semanticUI.changeInput(form, 'reportDate', '11-24-2018');
    semanticUI.changeInput(form, 'endDate', '11-25-2018');

    form.find('form').simulate('submit');

    jestExpect(reportingResource.downloadWipSpoil).toHaveBeenCalledTimes(1);
    jestExpect(reportingResource.downloadWipSpoil).toHaveBeenCalledWith({
      reportType: 'WIP-Spoil',
      reportDate: '2018-11-24',
      endDate: '2018-11-25',
      fileDate: '11-25-2018'
    });
  });

  test('should render error when date is not sunday', () => {
    const errorReponse = { error: {} };
    reportingResource.downloadWeeklyRecapReport.mockImplementation((arg, success, fail) =>
      fail(errorReponse)
    );

    const form = mount(
      <Provider
        store={createReduxStore({
          portionRoomsInfo: { currentPortionRoom: { code: 'A' } }
        })}
      >
        <Reports />
      </Provider>
    );

    semanticUI.selectOption(form, 'reportType', 1);
    semanticUI.changeInput(form, 'reportDate', '08-04-2018');

    form.find('form').simulate('submit');

    jestExpect(semanticUI.findErrorLabels(form).props().children).toEqual('Date must be a Sunday');
  });

  test('should render error when date is not in Display format (MM-DD-YYYY)', () => {
    const errorReponse = { error: {} };
    reportingResource.downloadWeeklyRecapReport.mockImplementation((arg, success, fail) =>
      fail(errorReponse)
    );

    const form = mount(
      <Provider
        store={createReduxStore({
          portionRoomsInfo: { currentPortionRoom: { code: 'A' } }
        })}
      >
        <Reports />
      </Provider>
    );

    semanticUI.selectOption(form, 'reportType', 1);
    semanticUI.changeInput(form, 'reportDate', '2018-08-04');

    form.find('form').simulate('submit');

    jestExpect(semanticUI.findErrorLabels(form).props().children).toEqual('Invalid date format');
  });

  test('should send form values in request to download Finished Good Market Cost report', () => {
    const store = createReduxStore({ portionRoomsInfo: { currentPortionRoom: { code: 'A' } } });

    const form = mount(
      <Provider store={store}>
        <Reports />
      </Provider>
    );

    semanticUI.selectOption(form, 'reportType', 7);

    form.find('form').simulate('submit');

    jestExpect(reportingResource.downloadFinishedGoodMarketCostReport).toHaveBeenCalledTimes(1);
  });

  describe('test date picker relate functions', () => {
    const todayDate = moment().format(DEFAULT_DISPLAY_DATE_FORMAT);

    test('should get disabled days when reportType is PROFITABILITY_REPORT', () => {
      const disabledDays = getDisabledDays(PROFITABILITY_REPORT);
      jestExpect(moment(disabledDays[0].after).format(DEFAULT_DISPLAY_DATE_FORMAT)).toEqual(
        todayDate
      );
    });

    test('should get disabled days when reportType is WEEKLYRECAP_REPORT', () => {
      const disabledDays = getDisabledDays(WEEKLY_RECAP_REPORT);

      jestExpect(disabledDays[0].daysOfWeek).toEqual([1, 2, 3, 4, 5, 6]);
      jestExpect(moment(disabledDays[0].after).format(DEFAULT_DISPLAY_DATE_FORMAT)).toEqual(
        todayDate
      );
    });

    test('should get disabled days when reportType is PRODUCT_IN_OUT_REPORT', () => {
      const disabledDays = getDisabledDays(PRODUCT_IN_AND_OUT_REPORT);
      jestExpect(moment(disabledDays[0].after).format(DEFAULT_DISPLAY_DATE_FORMAT)).toEqual(
        todayDate
      );
    });

    test('should get disabled days when reportType is invalid', () => {
      const disabledDays = getDisabledDays('in valid type');

      const expected = [];
      jestExpect(disabledDays).toEqual(expected);
    });

    test('should get correct fiscal calendar week number with given date and active fiscal calendar', () => {
      const sundayOfWeek = '2018-08-12';
      const fiscalCalendars = [
        {
          startDate: '2018-08-01',
          nextStartDate: '2019-07-01'
        }
      ];

      const weekNumber = getFiscalCalendarWeekNumber(sundayOfWeek, fiscalCalendars);
      jestExpect(weekNumber).toEqual('WK3');
    });

    test('should get correct fiscal calendar week number when given active fiscal calendar and nextStartDate is null', () => {
      const sundayOfWeek = '2018-08-12';
      const fiscalCalendars = [
        {
          startDate: '2018-08-01',
          nextStartDate: null
        }
      ];

      const weekNumber = getFiscalCalendarWeekNumber(sundayOfWeek, fiscalCalendars);
      jestExpect(weekNumber).toEqual('WK3');
    });

    test('should return empty fiscal calendar week number when given date not in active fiscal calendar', () => {
      const sundayOfWeek = '2017-08-12';
      const fiscalCalendars = [
        {
          startDate: '2018-08-01',
          nextStartDate: '2019-07-01'
        }
      ];

      const weekNumber = getFiscalCalendarWeekNumber(sundayOfWeek, fiscalCalendars);
      jestExpect(weekNumber).toEqual('');
    });
  });
});
