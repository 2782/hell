import React from 'react';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import { F4 } from '../../shared/components/pageFooters';
import { bindActionCreators } from 'redux';
import { setHeaderAndFooter } from '../../shared/actions/actions';
import { REPORTS } from '../../shared/components/pageTitles';
import { Field, reduxForm, stopSubmit } from 'redux-form';
import { Button, Divider, Dropdown, Form, Grid } from 'semantic-ui-react';
import FormElement from '../../shared/FormElement';
import {
  changeReportType,
  downloadReport,
  getAllFiscalCalendars
} from '../actions/reportingActions';
import {
  mustBeValidDateFormat,
  notFutureDate,
  reportDateMustSunday
} from '../../shared/validation/formFieldValidations';
import { validateScaleDates, validateSubmission } from '../components/reportsValidator';
import {
  CUTTING_STATION_PRODUCTIVITY_REPORT,
  FINISHED_GOOD_MARKET_COST_REPORT,
  HOUSE_PAR_REPORT,
  PRODUCT_IN_AND_OUT_REPORT,
  PROFITABILITY_REPORT,
  SCALE_SUMMARY_REPORT,
  WEEKLY_RECAP_REPORT,
  YIELD_MODEL_GROUP_COST_SUMMARY_REPORT,
  WIP_SPOIL_REPORT
} from '../components/reportType';
import FormDayPickerInput from '../../shared/FormDayPickerInput';
import { DEFAULT_DISPLAY_DATE_FORMAT, getSaturdayOfLastWeek } from '../../shared/util/dateUtil';
import moment from 'moment';
import * as _ from 'lodash';
import { getRooms } from '../../settings/actions/settingsActions';

const reportTypeOptions = [
  { key: 0, value: PROFITABILITY_REPORT, text: 'Profitability Report' },
  { key: 1, value: WEEKLY_RECAP_REPORT, text: 'Portion Room Weekly Report' },
  {
    key: 2,
    value: CUTTING_STATION_PRODUCTIVITY_REPORT,
    text: 'Cutting Station Productivity Report'
  },
  { key: 3, value: PRODUCT_IN_AND_OUT_REPORT, text: 'Product In-And-Out Report' },
  { key: 4, value: YIELD_MODEL_GROUP_COST_SUMMARY_REPORT, text: 'Yield Cost Summary' },
  { key: 5, value: HOUSE_PAR_REPORT, text: 'House Par Weekly Report' },
  { key: 6, value: SCALE_SUMMARY_REPORT, text: 'Scale Summary Report' },
  { key: 7, value: FINISHED_GOOD_MARKET_COST_REPORT, text: 'Finished Good Market Cost' },
  { key: 8, value: WIP_SPOIL_REPORT, text: 'WIP Spoil Report' }
];

export const getDayPickerProps = (reportType, fiscalCalendars) => {
  switch (reportType) {
    case SCALE_SUMMARY_REPORT:
    case WIP_SPOIL_REPORT:
    case PROFITABILITY_REPORT:
    case CUTTING_STATION_PRODUCTIVITY_REPORT:
    case PRODUCT_IN_AND_OUT_REPORT:
      return {
        showOutsideDays: true,
        disabledDays: getDisabledDays(reportType)
      };
    case WEEKLY_RECAP_REPORT:
    case YIELD_MODEL_GROUP_COST_SUMMARY_REPORT:
    case HOUSE_PAR_REPORT:
      return {
        showWeekNumbers: true,
        fixedWeeks: true,
        showOutsideDays: true,
        disabledDays: getDisabledDays(reportType),
        renderWeek: (weekNumber, week) => {
          return getFiscalCalendarWeekNumber(week[0], fiscalCalendars);
        }
      };
    default:
      return {};
  }
};

export const checkRequiresRoom = reportType => {
  switch (reportType) {
    case PROFITABILITY_REPORT:
    case CUTTING_STATION_PRODUCTIVITY_REPORT:
    case PRODUCT_IN_AND_OUT_REPORT:
      return true;
    case SCALE_SUMMARY_REPORT:
    case WIP_SPOIL_REPORT:
    case WEEKLY_RECAP_REPORT:
    case YIELD_MODEL_GROUP_COST_SUMMARY_REPORT:
    case HOUSE_PAR_REPORT:
    default:
      return false;
  }
};

const mustBeforeThanThisWeek = value => {
  return moment(value, DEFAULT_DISPLAY_DATE_FORMAT).isAfter(moment(getSaturdayOfLastWeek()), 'day')
    ? 'Cannot be in future'
    : undefined;
};

const mustSetFiscalCalendar = (value, values, props) => {
  const isBetweenFiscalCalendar = _.find(props.fiscalCalendars, fiscalCalendar => {
    const startDate = moment(fiscalCalendar.startDate);
    const nextStartDate = moment(fiscalCalendar.nextStartDate);

    let currentDate = null;

    if (!_.isNull(fiscalCalendar.startDate) && !_.isNull(fiscalCalendar.nextStartDate)) {
      if (value.toString().length > 10) {
        currentDate = moment(value);
      } else {
        currentDate = moment(value, 'MM-DD-YYYY');
      }
      return moment(currentDate.format('MM-DD-YYYY'), 'MM-DD-YYYY').isBetween(
        startDate,
        nextStartDate,
        null,
        '[]'
      );
    }
  });

  if (isBetweenFiscalCalendar) {
    return '';
  } else {
    return 'No fiscal calendar set. Contact system administrator.';
  }
};

export const getFiscalCalendar = (sundayDate, fiscalCalendars) => {
  return _.find(fiscalCalendars, fiscalCalendar => {
    const startDate = moment(fiscalCalendar.startDate);
    const nextStartDate = moment(fiscalCalendar.nextStartDate);

    if (
      (!nextStartDate.isValid() && sundayDate.isAfter(startDate)) ||
      (nextStartDate.isValid() && sundayDate.isBetween(startDate, nextStartDate))
    ) {
      return true;
    }

    return false;
  });
};

export const getFiscalCalendarWeekNumber = (sundayOfWeek, fiscalCalendars) => {
  const sundayDate = moment(sundayOfWeek);
  const fiscalCalendar = getFiscalCalendar(sundayDate, fiscalCalendars);

  if (fiscalCalendar) {
    const startDate = moment(fiscalCalendar.startDate);
    const weekNumber = Math.round(sundayDate.diff(startDate, 'days') / 7) + 1;
    return `WK${weekNumber}`;
  } else {
    return '';
  }
};

export const getDisabledDays = reportType => {
  switch (reportType) {
    case SCALE_SUMMARY_REPORT:
    case WIP_SPOIL_REPORT:
    case PROFITABILITY_REPORT:
    case CUTTING_STATION_PRODUCTIVITY_REPORT:
    case PRODUCT_IN_AND_OUT_REPORT:
      return [{ after: new Date() }];
    case WEEKLY_RECAP_REPORT:
    case YIELD_MODEL_GROUP_COST_SUMMARY_REPORT:
    case HOUSE_PAR_REPORT:
      return [{ daysOfWeek: [1, 2, 3, 4, 5, 6] }, { after: getSaturdayOfLastWeek() }];
    default:
      return [];
  }
};

const noScrollDropdown = props => <Dropdown {...props} selection scrolling />;

const noScrollFormSelect = props => <Form.Field {...props} control={noScrollDropdown} />;

export const validatesReportType = reportType => {
  switch (reportType) {
    case SCALE_SUMMARY_REPORT:
    case WIP_SPOIL_REPORT:
    case PROFITABILITY_REPORT:
    case CUTTING_STATION_PRODUCTIVITY_REPORT:
    case PRODUCT_IN_AND_OUT_REPORT:
      return [mustBeValidDateFormat, notFutureDate];
    case WEEKLY_RECAP_REPORT:
    case YIELD_MODEL_GROUP_COST_SUMMARY_REPORT:
    case HOUSE_PAR_REPORT:
      return [
        mustBeValidDateFormat,
        mustBeforeThanThisWeek,
        reportDateMustSunday,
        mustSetFiscalCalendar
      ];
    default:
      return [];
  }
};

export class Reports extends React.Component {
  constructor(props) {
    super(props);

    this.submit = this.submit.bind(this);
  }

  componentDidMount() {
    const {
      setHeaderAndFooter,
      getAllFiscalCalendars,
      isPortionRoomSelected,
      getRooms
    } = this.props;
    setHeaderAndFooter({
      header: REPORTS,
      footer: F4
    });

    getAllFiscalCalendars();
    if (!isPortionRoomSelected) {
      getRooms();
    }
  }

  componentWillUnmount() {
    const { changeReportType } = this.props;
    changeReportType('');
  }

  submit(values) {
    const { downloadReport } = this.props;
    const { reportType } = values;

    validateSubmission(values, this.props, checkRequiresRoom(reportType));

    return downloadReport(values);
  }

  render() {
    const {
      handleSubmit,
      submitting,
      pristine,
      valid,
      reportType,
      changeReportType,
      fiscalCalendars,
      isPortionRoomSelected,
      portionRoomOptions
    } = this.props;

    const isDateRange = reportType === SCALE_SUMMARY_REPORT || reportType === WIP_SPOIL_REPORT;

    return (
      <div className='page-content report-page'>
        <Form noValidate size={'large'} onSubmit={handleSubmit(this.submit)}>
          <Divider hidden className='divider-medium' />
          <Grid relaxed columns='equal'>
            <Grid.Row verticalAlign='top'>
              <Grid.Column width={7}>
                <Field
                  component={FormElement}
                  as={noScrollFormSelect}
                  name='reportType'
                  onChange={(event, newValue) => {
                    changeReportType(newValue);
                  }}
                  autoFocus={true}
                  label='Report Type'
                  options={reportTypeOptions}
                  type='text'
                />
              </Grid.Column>
              {reportType !== FINISHED_GOOD_MARKET_COST_REPORT ? (
                <Grid.Column>
                  <Field
                    component={FormDayPickerInput}
                    name='reportDate'
                    as={Form.Input}
                    label={isDateRange ? 'Date Range' : 'Report Date'}
                    formatString={DEFAULT_DISPLAY_DATE_FORMAT}
                    placeholder={DEFAULT_DISPLAY_DATE_FORMAT}
                    dayPickerProps={getDayPickerProps(reportType, fiscalCalendars)}
                    validate={validatesReportType(reportType)}
                  />
                </Grid.Column>
              ) : null}

              {isDateRange ? (
                <React.Fragment>
                  <div className='dateSplitter'>—</div>
                  <Grid.Column>
                    <Field
                      component={FormDayPickerInput}
                      name='endDate'
                      as={Form.Input}
                      label={'\u00A0'}
                      formatString={DEFAULT_DISPLAY_DATE_FORMAT}
                      placeholder={DEFAULT_DISPLAY_DATE_FORMAT}
                      dayPickerProps={getDayPickerProps(reportType, fiscalCalendars)}
                      validate={validatesReportType(reportType)}
                    />
                  </Grid.Column>
                </React.Fragment>
              ) : null}
              {!isPortionRoomSelected && checkRequiresRoom(reportType) ? (
                <React.Fragment>
                  <Grid.Column>
                    <Field
                      component={FormElement}
                      name='room'
                      pid='report-page-portion-room'
                      as={Form.Select}
                      options={portionRoomOptions}
                      type='text'
                      label='room'
                    />
                  </Grid.Column>
                </React.Fragment>
              ) : null}
            </Grid.Row>
            <Grid.Row>
              <Grid.Column>
                <Button
                  primary
                  size={'large'}
                  loading={submitting}
                  disabled={submitting || pristine || !valid}
                >
                  Download
                </Button>
              </Grid.Column>
            </Grid.Row>
          </Grid>
        </Form>
      </div>
    );
  }
}

export const generatePortionRoomOptions = portionRooms => {
  let sortedRooms = _.sortBy(portionRooms, 'description');
  return sortedRooms.map(({ code, description }, index) => {
    return { key: index, text: `${code} - ${description}`, value: code };
  });
};

Reports.propTypes = {
  getRooms: PropTypes.func.isRequired,
  setHeaderAndFooter: PropTypes.func,
  handleSubmit: PropTypes.func.isRequired,
  downloadReport: PropTypes.func.isRequired,
  getAllFiscalCalendars: PropTypes.func.isRequired,
  submitting: PropTypes.bool.isRequired,
  pristine: PropTypes.bool.isRequired,
  valid: PropTypes.bool.isRequired,
  reportType: PropTypes.string,
  changeReportType: PropTypes.func.isRequired,
  fiscalCalendars: PropTypes.array.isRequired,
  isPortionRoomSelected: PropTypes.bool,
  portionRoomOptions: PropTypes.array
};

const hasNonCostingRoom = portionRoom => {
  return (
    portionRoom != null &&
    !_.isEmpty(portionRoom.currentPortionRoom) &&
    portionRoom.currentPortionRoom.roomType != 'COSTING'
  );
};

const mapStateToProps = state => {
  const reportInfo = state.reportsInfo;
  const currentPortionRoom = state.portionRoomsInfo.currentPortionRoom;
  const portionRooms = state.settingsInfo.rooms;
  const isPortionRoomSelected = hasNonCostingRoom(state.portionRoomsInfo);

  return {
    reportType: reportInfo.reportType,
    fiscalCalendars: reportInfo.fiscalCalendars,
    currentPortionRoom,
    isPortionRoomSelected,
    portionRoomOptions:
      !isPortionRoomSelected && portionRooms ? generatePortionRoomOptions(portionRooms) : []
  };
};

const mapDispatchToProps = dispatch =>
  bindActionCreators(
    {
      getRooms,
      setHeaderAndFooter,
      downloadReport,
      changeReportType,
      getAllFiscalCalendars
    },
    dispatch
  );

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(
  reduxForm({
    form: 'reports',
    validate: validateScaleDates,
    onChange: (values, dispatch, props) => {
      if (props.submitFailed) {
        dispatch(stopSubmit('reports'));
      }
    }
  })(Reports)
);
