export const CHANGE_REPORT_TYPE = 'report/changeReportType';
export const GET_ALL_FISCAL_CALENDARS = 'report/getAllFiscalCalendars';
