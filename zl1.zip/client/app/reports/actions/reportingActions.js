import reportingResources from '../../shared/api/reportingResources';
import fileDownload from 'js-file-download';
import { reset, SubmissionError } from 'redux-form';

import _ from 'lodash';
import {
  CUTTING_STATION_PRODUCTIVITY_REPORT,
  FINISHED_GOOD_MARKET_COST_REPORT,
  HOUSE_PAR_REPORT,
  PRODUCT_IN_AND_OUT_REPORT,
  PROFITABILITY_REPORT,
  SCALE_SUMMARY_REPORT,
  WEEKLY_RECAP_REPORT,
  YIELD_MODEL_GROUP_COST_SUMMARY_REPORT,
  WIP_SPOIL_REPORT
} from '../components/reportType';
import { CHANGE_REPORT_TYPE, GET_ALL_FISCAL_CALENDARS } from './reportingActionTypes';
import fiscalCalendarResources from '../../shared/api/fiscalCalendarResources';
import moment from 'moment';
import { DEFAULT_DISPLAY_DATE_FORMAT, displayDateToIsoDate } from '../../shared/util/dateUtil';

const mapReportDateError = (errors, errorDetails) => {
  const errorDetailsForReportDate = errorDetails.find(detail => detail.field === 'reportDate');

  const errorType = errorDetailsForReportDate && errorDetailsForReportDate.issue;

  switch (errorType) {
    case 'DATE_IS_NOT_PORTION_ROOM_WORKING_DAY':
      errors = {
        reportDate: 'This portion room was not opened on the requested working day.',
        ...errors
      };
      break;
  }

  return errors;
};

export const downloadReport = values => {
  const modifiedValues = { ...values };
  if (modifiedValues.reportDate) {
    modifiedValues.reportDate = displayDateToIsoDate(values.reportDate);
    modifiedValues.fileDate = values.reportDate;
  }
  switch (values.reportType) {
    case PROFITABILITY_REPORT:
      return downloadProfitabilityReport(modifiedValues);
    case WEEKLY_RECAP_REPORT:
      return downloadWeeklyRecapReport(modifiedValues);
    case CUTTING_STATION_PRODUCTIVITY_REPORT:
      return downloadCuttingStationProductivityReport(modifiedValues);
    case PRODUCT_IN_AND_OUT_REPORT:
      return downloadProductInAndOutReport(modifiedValues);
    case YIELD_MODEL_GROUP_COST_SUMMARY_REPORT:
      return downloadYieldCostSummaryReport(modifiedValues);
    case HOUSE_PAR_REPORT:
      return downloadHouseParReport(modifiedValues);
    case SCALE_SUMMARY_REPORT:
      modifiedValues.endDate = displayDateToIsoDate(values.endDate);
      modifiedValues.fileDate = values.endDate;
      return downloadScaleSummary(modifiedValues);
    case WIP_SPOIL_REPORT:
      modifiedValues.endDate = displayDateToIsoDate(values.endDate);
      modifiedValues.fileDate = values.endDate;
      return downloadWipSpoil(modifiedValues);
    case FINISHED_GOOD_MARKET_COST_REPORT:
      return downloadFinishedGoodMarketCost(modifiedValues);
    default:
      return;
  }
};

const hasNonCostingRoom = currentPortionRoom => {
  return (
    currentPortionRoom && !_.isEmpty(currentPortionRoom) && currentPortionRoom.roomType != 'COSTING'
  );
};

export const downloadProductInAndOutReport = ({ reportType, reportDate, room }) => (
  dispatch,
  getState
) => {
  const currentPortionRoom = getState().portionRoomsInfo.currentPortionRoom;
  const roomCode = hasNonCostingRoom(currentPortionRoom) ? currentPortionRoom.code : room;
  const fileDate = moment(reportDate).format('MM-YYYY');
  const reportYearMonth = moment(reportDate).format('YYYY-MM');

  return reportingResources
    .downloadProductInAndOutReport({ roomCode, reportYearMonth: reportYearMonth })
    .then(response =>
      fileDownload(response, `${reportType}-Report-${fileDate}-Room-${roomCode}.xlsx`)
    );
};

export const downloadProfitabilityReport = values => (dispatch, getState) => {
  const { room } = values;
  const currentPortionRoom = getState().portionRoomsInfo.currentPortionRoom;
  const roomCode = hasNonCostingRoom(currentPortionRoom) ? currentPortionRoom.code : room;

  return reportingResources
    .downloadProfitabilityReport({ roomCode, ...values })
    .then(response =>
      fileDownload(response, `${values.reportType}Report-${values.fileDate}-Room-${roomCode}.xlsx`)
    )
    .catch(error => {
      let errors = {};
      const errorDetails = _.get(error, 'error.details', []);
      errors = mapReportDateError(errors, errorDetails);
      throw new SubmissionError({ _error: 'Submission Failed!', ...errors });
    });
};

export const downloadWeeklyRecapReport = values => () => {
  return reportingResources
    .downloadWeeklyRecapReport(values)
    .then(response => fileDownload(response, `${values.reportType}Report-${values.fileDate}.xlsx`))
    .catch(() => {
      throw new SubmissionError({ _error: 'Submission Failed!' });
    });
};

export const downloadCuttingStationProductivityReport = values => (dispatch, getState) => {
  const { room } = values;
  const currentPortionRoom = getState().portionRoomsInfo.currentPortionRoom;
  const roomCode = hasNonCostingRoom(currentPortionRoom) ? currentPortionRoom.code : room;

  return reportingResources
    .downloadCuttingStationProductivityReport({ roomCode, ...values })
    .then(response =>
      fileDownload(response, `${values.reportType}-Report-${values.fileDate}-Room-${roomCode}.xlsx`)
    )
    .catch(error => {
      let errors = {};
      const errorDetails = _.get(error, 'error.details', []);
      errors = mapReportDateError(error, errorDetails);
      throw new SubmissionError({ _error: 'Submission Failed!', ...errors });
    });
};

export const downloadYieldCostSummaryReport = values => () => {
  return reportingResources
    .downloadYieldCostSummaryReport(values)
    .then(response => fileDownload(response, `${values.reportType}-Report-${values.fileDate}.xlsx`))
    .catch(() => {
      throw new SubmissionError({ _error: 'Submission Failed!' });
    });
};

export const downloadHouseParReport = values => () => {
  return reportingResources
    .downloadHouseParReport(values)
    .then(response => fileDownload(response, `${values.reportType}-Report-${values.fileDate}.xlsx`))
    .catch(() => {
      throw new SubmissionError({ _error: 'Submission Failed!' });
    });
};

export const downloadScaleSummary = values => () => {
  return reportingResources
    .downloadScaleSummary(values)
    .then(response => fileDownload(response, `${values.reportType}-Report-${values.fileDate}.csv`))
    .catch(() => {
      throw new SubmissionError({ _error: 'Submission Failed!' });
    });
};

export const downloadWipSpoil = values => () => {
  return reportingResources
    .downloadWipSpoil(values)
    .then(response => fileDownload(response, `${values.reportType}-Report-${values.fileDate}.xlsx`))
    .catch(() => {
      throw new SubmissionError({ _error: 'Submission Failed!' });
    });
};

export const downloadFinishedGoodMarketCost = values => () => {
  return reportingResources
    .downloadFinishedGoodMarketCostReport()
    .then(response =>
      fileDownload(
        response,
        `${values.reportType}-Report-${moment().format(DEFAULT_DISPLAY_DATE_FORMAT)}.csv`
      )
    )
    .catch(() => {
      throw new SubmissionError({ _error: 'Submission Failed!' });
    });
};

export const changeReportType = reportType => {
  return dispatch => {
    dispatch({
      type: CHANGE_REPORT_TYPE,
      payload: reportType
    });
    dispatch(reset('reports'));
  };
};

export const getAllFiscalCalendars = () => {
  return dispatch => {
    fiscalCalendarResources.getAllFiscalCalendars(response => {
      dispatch({
        type: GET_ALL_FISCAL_CALENDARS,
        payload: response.data
      });
    });
  };
};
