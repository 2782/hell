import grindOrdersReducer from '../grindOrdersReducer';
import {
  GRINDING_ORDERS_GRABBED,
  EDIT_QUANTITY_STOPPED,
  EDIT_QUANTITY_STARTED,
  UPDATE_GRINDING_ORDER_QUANTITY
} from '../../actions/grindActionTypes';

describe('grindOrdersReducer', () => {
  let initState;
  beforeEach(() => {
    initState = {
      grindOrdersInfo: null,
      shouldEditQuantity: false,
      selectedGrindOrder: null
    };
  });

  test('should return initState when handle unexpect action', () => {
    let unexpectAction = { type: 'unexpect' };
    jestExpect(grindOrdersReducer(undefined, unexpectAction)).toEqual(initState);
  });

  test('should update grindOrder state when having grabbed grinding orders', () => {
    const payload = [{ id: 1, deliveryDate: '2017-10-22' }, { id: 2, deliveryDate: '2017-10-23' }];

    const result = {
      ...initState,
      grindOrdersInfo: [
        { id: 1, deliveryDate: '2017-10-22' },
        { id: 2, deliveryDate: '2017-10-23' }
      ]
    };
    jestExpect(
      grindOrdersReducer(undefined, {
        type: GRINDING_ORDERS_GRABBED,
        payload: payload
      })
    ).toEqual(result);
  });

  test('should update grindOrdersInfo state when having UPDATE_GRINDING_ORDER_QUANTITY', () => {
    const payload = { id: 1, deliveryDate: '2017-10-22', qtyInBoxes: 12 };

    const initState1 = {
      ...initState,
      grindOrdersInfo: [
        { id: 1, deliveryDate: '2017-10-22', qtyInBoxes: 10 },
        { id: 2, deliveryDate: '2017-10-23', qtyInBoxes: 11 }
      ]
    };

    const result = {
      ...initState,
      grindOrdersInfo: [
        { id: 1, deliveryDate: '2017-10-22', qtyInBoxes: 12 },
        { id: 2, deliveryDate: '2017-10-23', qtyInBoxes: 11 }
      ]
    };
    jestExpect(
      grindOrdersReducer(initState1, {
        type: UPDATE_GRINDING_ORDER_QUANTITY,
        payload: payload
      })
    ).toEqual(result);
  });

  describe('EDIT_QUANTITY_STARTED', () => {
    test('should set shouldEditQuantity to true', () => {
      const currentGrindOrder = {
        id: 444
      };
      const result = {
        ...initState,
        shouldEditQuantity: true,
        selectedGrindOrder: currentGrindOrder
      };

      jestExpect(
        grindOrdersReducer(undefined, { type: EDIT_QUANTITY_STARTED, payload: currentGrindOrder })
      ).toEqual(result);
    });
  });

  describe('EDIT_QUANTITY_STOPPED', () => {
    test('should set shouldEditQuantity to false', () => {
      const result = {
        ...initState,
        shouldEditQuantity: false
      };

      jestExpect(grindOrdersReducer(undefined, { type: EDIT_QUANTITY_STOPPED })).toEqual(result);
    });
  });
});
