import {
  EDIT_QUANTITY_STARTED,
  EDIT_QUANTITY_STOPPED,
  GRINDING_ORDERS_GRABBED,
  UPDATE_GRINDING_ORDER_QUANTITY
} from '../actions/grindActionTypes';

import * as _ from 'lodash';

const initialState = {
  grindOrdersInfo: null,
  shouldEditQuantity: false,
  selectedGrindOrder: null
};

export default (state = initialState, action) => {
  switch (action.type) {
    case GRINDING_ORDERS_GRABBED: {
      return {
        ...state,
        grindOrdersInfo: action.payload
      };
    }

    case EDIT_QUANTITY_STARTED: {
      return {
        ...state,
        shouldEditQuantity: true,
        selectedGrindOrder: action.payload
      };
    }

    case EDIT_QUANTITY_STOPPED: {
      return {
        ...state,
        shouldEditQuantity: false
      };
    }

    case UPDATE_GRINDING_ORDER_QUANTITY: {
      const updatedGrindOrder = action.payload;
      const updatedGrindOrdersInfo = _.map(state.grindOrdersInfo, grindOrder => {
        return grindOrder.id === updatedGrindOrder.id ? updatedGrindOrder : grindOrder;
      });

      return {
        ...state,
        grindOrdersInfo: updatedGrindOrdersInfo
      };
    }

    default:
      return state;
  }
};
