import { GRIND_ORDER_WITH_SAME_BLEND_AND_DIFFERENT_SHIP_DATE } from '../../../../test-factories/grindingOrderFactory';
import grindOrderValidator from '../grindOrderValidator';

describe('grindOrderValidator', () => {
  describe('validateQuantity', () => {
    it('should return true when quantity is less than qtyInBoxes', () => {
      const selectedGrindOrder = GRIND_ORDER_WITH_SAME_BLEND_AND_DIFFERENT_SHIP_DATE;
      const result = grindOrderValidator.validateQuantity(selectedGrindOrder, 1);
      jestExpect(result).toBe(true);
    });

    it('should return false when quantity is more than qtyInBoxes', () => {
      const selectedGrindOrder = GRIND_ORDER_WITH_SAME_BLEND_AND_DIFFERENT_SHIP_DATE;
      const result = grindOrderValidator.validateQuantity(selectedGrindOrder, 4);
      jestExpect(result).toBe(false);
    });
  });
});
