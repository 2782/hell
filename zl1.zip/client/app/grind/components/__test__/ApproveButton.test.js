import React from 'react';
import { PortionRoomState } from '../../../landingPage/reducers/portionRoomReducer';
import { Button } from 'semantic-ui-react';
import { shallow } from 'enzyme';
import { ApproveButton } from '../ApproveButton';
import { GRIND_ORDER_WITH_NO_QTY_IN_BOXES } from '../../../../test-factories/grindingOrderFactory';
import GrindOrderFactory from '../../../../test-factories/grindingOrderFactory';

describe('ApproveButton', () => {
  it('should not show approve button for non-grinding rooms', () => {
    const approveButton = shallow(
      <ApproveButton
        grindOrdersInfo={[{ aFake: 'order' }]}
        isGrindingRoom={false}
        submitting={false}
        portionRoomState={PortionRoomState.CAN_CLOSE}
      />
    );

    jestExpect(approveButton.get(0)).toEqual(null);
  });

  it('should not show approve button when there are no orders', () => {
    const approveButton = shallow(
      <ApproveButton
        grindOrdersInfo={[]}
        isGrindingRoom={true}
        submitting={false}
        portionRoomState={PortionRoomState.CAN_CLOSE}
      />
    );

    jestExpect(approveButton.get(0)).toEqual(null);
  });

  it('should not show approve button when there are orders with no qtyInBoxes', () => {
    const approveButton = shallow(
      <ApproveButton
        grindOrdersInfo={[GRIND_ORDER_WITH_NO_QTY_IN_BOXES]}
        isGrindingRoom={true}
        submitting={false}
        portionRoomState={PortionRoomState.CAN_CLOSE}
      />
    );

    jestExpect(approveButton.get(0)).toEqual(null);
  });

  it('should disable approve button for grinding rooms when the room is closed', () => {
    const approveButton = shallow(
      <ApproveButton
        grindOrdersInfo={[GrindOrderFactory.build()]}
        isGrindingRoom={true}
        submitting={false}
        portionRoomState={PortionRoomState.CAN_OPEN}
      />
    );

    jestExpect(approveButton.find(Button)).toBeDisabled();
  });

  it('should disable approve button for grinding rooms when already approved for the day', () => {
    const approveButton = shallow(
      <ApproveButton
        grindOrdersInfo={[GrindOrderFactory.build()]}
        isGrindingRoom={true}
        submitting={false}
        portionRoomState={PortionRoomState.CAN_CLOSE}
      />
    );

    jestExpect(approveButton.find(Button)).toBeDisabled();
  });

  it('should enable approve button for grinding rooms when not yet approved for the day', () => {
    const approveButton = shallow(
      <ApproveButton
        grindOrdersInfo={[{ aFake: 'order' }]}
        isGrindingRoom={true}
        submitting={false}
        portionRoomState={PortionRoomState.CAN_APPROVE}
      />
    );

    jestExpect(approveButton.find(Button)).not.toBeDisabled();
  });
});
