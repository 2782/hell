const validateQuantity = (grindOrder, value) => value <= grindOrder.qtyInBoxes;

const grindOrderValidator = {
  validateQuantity
};

export default grindOrderValidator;
