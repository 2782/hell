import grindOrdersResources from '../../../shared/api/grindOrdersResources';
import batchResources from '../../../shared/api/batchResources';
import {
  approveGrindOrders,
  editQuantity,
  getGrindOrders,
  getGrindOrdersWithBatches,
  getStockAllocationAlert,
  stopEditingQuantity,
  updateGrindOrder
} from '../grindActions';
import {
  GRINDING_ORDERS_APPROVED,
  GRINDING_ORDERS_GRABBED,
  EDIT_QUANTITY_STOPPED,
  EDIT_QUANTITY_STARTED,
  STOCK_ALLOCATION_ALERT,
  GRINDING_ORDERS_NOT_APPROVED,
  UPDATE_GRINDING_ORDER_QUANTITY
} from '../grindActionTypes';

import { UPDATE_BATCHES } from '../../../batch/actions/batchActionTypes';
import GrindOrderFactory from '../../../../test-factories/grindingOrderFactory';
import blendFactory from '../../../../test-factories/blendFactory';
import BatchFactory from '../../../../test-factories/batch';
import portionRoomsResources from '../../../shared/api/portionRoomsResources';

jest.mock('../../../shared/api/grindOrdersResources');
jest.mock('../../../shared/api/batchResources');
jest.mock('../../../shared/api/portionRoomsResources');

const batch = BatchFactory.build();

const getState = () => {
  return {
    portionRoomsInfo: {
      currentPortionRoom: {
        code: 'A'
      },
      portionRooms: [
        {
          code: 'A',
          lastOpenedAt: '07-05-2018'
        }
      ]
    }
  };
};

describe('grindActions', () => {
  let dispatch, response, batchResponse;
  grindOrdersResources.approveGrindOrders.mockResolvedValue({});

  beforeEach(() => {
    dispatch = jest.fn();
    response = { data: [{ blend: blendFactory.build() }] };
    batchResponse = { data: [batch] };

    grindOrdersResources.getGrindOrders.mockImplementation((arg, callback) => callback(response));
    batchResources.getBatchesByBlendNames.mockImplementation((arg1, arg2, callback) =>
      callback(batchResponse)
    );
  });

  afterEach(() => {
    grindOrdersResources.getGrindOrders.mockReset();
    batchResources.getBatchesByBlendNames.mockReset();
  });

  test('should dispatch EDIT_QUANTITY_STARTED', () => {
    const currentGrindOrder = {
      id: 444
    };
    editQuantity(currentGrindOrder)(dispatch);

    jestExpect(dispatch).toHaveBeenCalledWith({
      type: EDIT_QUANTITY_STARTED,
      payload: currentGrindOrder
    });
  });

  test('should dispatch EDIT_QUANTITY_STOPPED', () => {
    stopEditingQuantity()(dispatch);

    jestExpect(dispatch).toHaveBeenCalledWith({
      type: EDIT_QUANTITY_STOPPED
    });
  });

  describe('getGrindOrders()', () => {
    test('should grab grind orders with batches', () => {
      getGrindOrdersWithBatches()(dispatch, getState);

      jestExpect(dispatch).toHaveBeenCalledTimes(2);
      jestExpect(dispatch).toHaveBeenNthCalledWith(1, {
        type: GRINDING_ORDERS_GRABBED,
        payload: response.data
      });

      jestExpect(dispatch).toHaveBeenNthCalledWith(2, {
        type: UPDATE_BATCHES,
        payload: batchResponse.data
      });
    });

    test('should grab grind orders without batches', () => {
      getGrindOrders()(dispatch, getState);

      jestExpect(dispatch).toHaveBeenCalledTimes(1);
      jestExpect(dispatch).toHaveBeenNthCalledWith(1, {
        type: GRINDING_ORDERS_GRABBED,
        payload: response.data
      });
    });
  });

  describe('updateGrindOrder', () => {
    let updatedGrindOrder;
    beforeEach(() => {
      updatedGrindOrder = GrindOrderFactory.build();

      grindOrdersResources.updateGrindOrder.mockImplementation((order, callback) =>
        callback(1, undefined)
      );
    });

    afterEach(() => {
      grindOrdersResources.updateGrindOrder.mockReset();
    });

    test('should make api call to update selected grind order', () => {
      updateGrindOrder(updatedGrindOrder)(dispatch);

      jestExpect(grindOrdersResources.updateGrindOrder.mock.calls[0][0]).toEqual(updatedGrindOrder);
    });

    test('should dispatch EDIT_QUANTITY_STOPPED action', () => {
      updateGrindOrder(updatedGrindOrder)(dispatch);

      jestExpect(dispatch).toHaveBeenNthCalledWith(1, { type: EDIT_QUANTITY_STOPPED });
    });

    test('should dispatch UPDATE_GRINDING_ORDER_QUANTITY action', () => {
      updateGrindOrder(updatedGrindOrder)(dispatch);

      jestExpect(dispatch).toHaveBeenNthCalledWith(2, {
        type: UPDATE_GRINDING_ORDER_QUANTITY,
        payload: updatedGrindOrder
      });
    });
  });

  describe('approveGrindOrders', () => {
    test('should approve grind orders for the day', async () => {
      await approveGrindOrders()(dispatch, getState);

      jestExpect(dispatch).toBeCalledWith({
        type: GRINDING_ORDERS_APPROVED
      });
    });

    test('should call GRINDING_ORDERS_NOT_APPROVED if error', async () => {
      grindOrdersResources.approveGrindOrders.mockRejectedValueOnce({ data: 'foobar' });

      await approveGrindOrders()(dispatch, getState);

      jestExpect(dispatch).toHaveBeenNthCalledWith(1, {
        type: GRINDING_ORDERS_APPROVED
      });
      jestExpect(dispatch).toHaveBeenNthCalledWith(2, {
        type: GRINDING_ORDERS_NOT_APPROVED
      });
      jestExpect(grindOrdersResources.approveGrindOrders.mock.calls[0][0]).toEqual('A');
    });
  });

  describe('getStockAllocationAlert', () => {
    test('should get stock allocation alert', async () => {
      portionRoomsResources.getStockAllocationAlert.mockResolvedValueOnce({ data: true });

      await getStockAllocationAlert('A')(dispatch);

      jestExpect(dispatch).toHaveBeenNthCalledWith(1, {
        type: STOCK_ALLOCATION_ALERT,
        payload: true
      });
      jestExpect(dispatch).toHaveBeenNthCalledWith(2, {
        type: 'ERROR',
        payload: 'STOCK_ALLOCATION_ALERT'
      });
    });

    test('should not get stock allocation alert when response is false', async () => {
      portionRoomsResources.getStockAllocationAlert.mockResolvedValueOnce({ data: false });

      await getStockAllocationAlert('A')(dispatch);
      jestExpect(dispatch).toHaveBeenNthCalledWith(1, {
        type: STOCK_ALLOCATION_ALERT,
        payload: false
      });
    });
  });
});
