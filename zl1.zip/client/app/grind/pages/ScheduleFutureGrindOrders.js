import React from 'react';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import { reduxForm } from 'redux-form';
import ScheduleFutureGrindOrdersTable from '../../overview/components/ScheduleFutureGrindOrdersTable';
import { SCHEDULE_GRIND_ORDERS } from '../../shared/components/pageTitles';
import {
  clear,
  getFutureLineItems,
  scheduleGrindOrdersToProduceToday,
  setUserProjectedQuantitiesRemaining,
  generateGrindingOrdersFromHousePar,
  clearUserProjectedQuantitiesRemaining
} from '../../overview/actions/orderOverviewActions';
import {
  replacePath,
  setHeaderAndFooter,
  showModal,
  showNoCostWarningModal
} from '../../shared/actions/actions';
import { SCHEDULE_FUTURE_GRINDING_ORDERS_FOOTER } from '../../shared/components/pageFooters';
import { Button, Divider, Form } from 'semantic-ui-react';
import _ from 'lodash';
import { validateSubmission } from '../../overview/components/scheduleFutureOrdersFormValidator';
import { PortionRoomState } from '../../landingPage/reducers/portionRoomReducer';
import { TotalPounds } from '../../overview/components/TotalPounds';
import { getGrindOrders, getStockAllocationAlert } from '../actions/grindActions';
import { getAvailableGrindingHousePar } from '../../settings/actions/settingsActions';
import { HOUSE_PAR, LINE_ITEM } from '../../../config/orderSource';

const ordersForCurrentAndNextWorkingDay = (orders, currentAndNextWorkingDay) => {
  return _.filter(orders, order => {
    return currentAndNextWorkingDay.includes(order.customerOrder.shipDate);
  });
};

const getOrdersWithoutCost = orders => {
  return _.filter(orders, order => !order.product.cost || order.product.cost === 0);
};

const removeOrdersWithoutCosts = orders => {
  return _.filter(orders, order => !!order.product.cost && order.product.cost !== 0);
};

const maybeMutateUserProjectedQuantitiesRemaining = (
  overrides,
  { itemId, quantityRemaining, type },
  inputtedValue
) => {
  const foundIndex = overrides.findIndex(override => override.itemId === itemId);
  if (inputtedValue) {
    const updatedQuantityRemaining = {
      itemId,
      orderQuantityRemaining: inputtedValue,
      type: type,
      quantityRemaining: quantityRemaining - inputtedValue
    };
    if (-1 === foundIndex) {
      overrides.push(updatedQuantityRemaining);
    } else {
      overrides.splice(foundIndex, 1, updatedQuantityRemaining);
    }
  } else {
    if (-1 === foundIndex) {
      return false;
    }
    overrides.splice(foundIndex, 1);
  }

  return true;
};

export const isActionableForLineItem = orders => {
  return !_.isEmpty(orders) && 0 !== _.sumBy(orders, 'quantityRemaining');
};

export const isActionableForHousePar = housepars => {
  return !_.isEmpty(housepars) && 0 !== _.sumBy(housepars, 'quantity');
};

export const SubmitButton = ({
  futureOrders,
  grindHousePars,
  userProjectedQuantitiesRemaining,
  submitting,
  pristine,
  isApprovedForDay,
  roomIsDisabled
}) => {
  if (!isActionableForLineItem(futureOrders) && !isActionableForHousePar(grindHousePars)) {
    return null;
  }

  const disabled =
    (isApprovedForDay && !roomIsDisabled) ||
    (submitting || (userProjectedQuantitiesRemaining.length === 0 ? pristine : false));
  return (
    <Button primary size={'large'} loading={submitting} disabled={disabled}>
      Submit
    </Button>
  );
};
SubmitButton.propTypes = {
  futureOrders: PropTypes.array,
  grindHousePars: PropTypes.array,
  userProjectedQuantitiesRemaining: PropTypes.array,
  submitting: PropTypes.bool.isRequired,
  pristine: PropTypes.bool.isRequired,
  isApprovedForDay: PropTypes.bool.isRequired,
  roomIsDisabled: PropTypes.bool.isRequired
};

export class ScheduleFutureOrdersComponent extends React.Component {
  constructor(props) {
    super(props);

    this.onSubmit = this.onSubmit.bind(this);
    this.updateTotalPoundsWithUserProjection = this.updateTotalPoundsWithUserProjection.bind(this);
    this.updateUserProjectQuantitiesRemainingForLineItem = this.updateUserProjectQuantitiesRemainingForLineItem.bind(
      this
    );
    this.updateUserProjectQuantitiesRemainingForHousePar = this.updateUserProjectQuantitiesRemainingForHousePar.bind(
      this
    );
  }

  componentDidMount() {
    const { getStockAllocationAlert, roomCode } = this.props;
    const { getGrindOrders, getFutureLineItems, getAvailableGrindingHousePar } = this.props;

    this.props.setHeaderAndFooter({
      header: SCHEDULE_GRIND_ORDERS,
      footer: SCHEDULE_FUTURE_GRINDING_ORDERS_FOOTER
    });

    getStockAllocationAlert(roomCode);
    getGrindOrders();
    getFutureLineItems(this.updateUserProjectQuantitiesRemainingForLineItem);
    getAvailableGrindingHousePar(this.updateUserProjectQuantitiesRemainingForHousePar);
  }

  componentWillUnmount() {
    this.props.clear();
    this.props.clearUserProjectedQuantitiesRemaining();
  }

  onSubmit(values) {
    const { futureOrders, grindHousePars, showModal } = this.props;

    validateSubmission(values, this.props);

    const scheduledItems = this.generateScheduledItems(futureOrders, values);
    const submitOrders = _.filter(futureOrders, futureOrder =>
      _.keys(scheduledItems).includes(futureOrder.itemId.toString())
    );
    const onHoldOrders = _.filter(submitOrders, submitOrder =>
      _.get(submitOrder, 'customerOrder.onHold', false)
    );
    const houseParItems = this.generateHouseParItems(grindHousePars, values);

    if (!_.isEmpty(onHoldOrders)) {
      const onHoldCustomerIds = _.map(
        onHoldOrders,
        onHoldOrder => onHoldOrder.customerOrder.customer.customerCode
      ).join(', ');
      const warningMsgInMiddle = 'on credit hold. Are you sure you want to produce orders for';
      const onHoldOrderItemIds = _.map(onHoldOrders, onHoldOrder => onHoldOrder.itemId);
      const warningMsg =
        onHoldOrderItemIds.length > 1
          ? `Customers ${onHoldCustomerIds} are ${warningMsgInMiddle} these customers?`
          : `Customer ${onHoldCustomerIds} is ${warningMsgInMiddle} this customer?`;
      showModal({
        header: 'Customer on Credit Hold',
        content: warningMsg,
        cancelButton: 'No',
        cancelAction: () => {
          const unHoldOrders = _.omit(scheduledItems, onHoldOrderItemIds);

          if (!_.isEmpty(unHoldOrders)) {
            return this.scheduleUnHoldGrindOrders(unHoldOrders, houseParItems);
          }
        },
        confirmButton: 'Yes',
        confirmAction: () => this.scheduleUnHoldGrindOrders(scheduledItems, houseParItems)
      });
    } else {
      return this.scheduleUnHoldGrindOrders(scheduledItems, houseParItems);
    }
  }

  generateScheduledItems(futureOrders, submitValues) {
    return _.reduce(
      futureOrders,
      (result, item) => {
        const toProduceToday = _.get(submitValues, `${item.itemId}-${LINE_ITEM}-toGrindToday`, 0);
        if (toProduceToday > 0) {
          result[item.itemId] = toProduceToday;
        }
        return result;
      },
      {}
    );
  }

  generateHouseParItems(grindHousePars, submitValues) {
    return _.reduce(
      grindHousePars,
      (result, par) => {
        const toGenerateToday = _.get(submitValues, `${par.id}-${HOUSE_PAR}-toGrindToday`, 0);
        if (toGenerateToday > 0) {
          result[par.id] = toGenerateToday;
        }
        return result;
      },
      {}
    );
  }

  scheduleUnHoldGrindOrders(scheduledItems, houseParItems) {
    const {
      scheduleGrindOrdersToProduceToday,
      generateGrindingOrdersFromHousePar,
      replacePath
    } = this.props;
    return scheduleGrindOrdersToProduceToday(scheduledItems, () => {
      return generateGrindingOrdersFromHousePar(houseParItems, () =>
        replacePath('/grinding/grinding-orders')
      );
    });
  }

  updateUserProjectQuantitiesRemainingForLineItem(futureLineItemsResponseData) {
    const {
      userProjectedQuantitiesRemaining,
      currentAndNextWorkingDay,
      setUserProjectedQuantitiesRemaining,
      showNoCostWarningModal
    } = this.props;

    const orders = ordersForCurrentAndNextWorkingDay(
      futureLineItemsResponseData,
      currentAndNextWorkingDay
    );

    const productsWithoutACost = _.uniq(
      getOrdersWithoutCost(orders).map(order => order.product.code)
    );

    if (!_.isEmpty(productsWithoutACost)) {
      showNoCostWarningModal(productsWithoutACost);
    }

    const ordersWithProductCosts = removeOrdersWithoutCosts(orders);

    const userProjectedQuantitiesRemainingForLineItem = ordersWithProductCosts.map(order => {
      return {
        itemId: order.itemId,
        type: LINE_ITEM,
        orderQuantityRemaining: order.quantityRemaining,
        quantityRemaining: 0
      };
    });

    const updatedUserProjectedQuantitiesRemaining = userProjectedQuantitiesRemaining.concat(
      userProjectedQuantitiesRemainingForLineItem
    );

    setUserProjectedQuantitiesRemaining(updatedUserProjectedQuantitiesRemaining);
  }

  updateUserProjectQuantitiesRemainingForHousePar(housePars) {
    const { userProjectedQuantitiesRemaining, setUserProjectedQuantitiesRemaining } = this.props;

    const userProjectedQuantitiesRemainingForHousePar = housePars.map(par => {
      return {
        itemId: par.id,
        type: HOUSE_PAR,
        orderQuantityRemaining: par.quantity,
        quantityRemaining: 0
      };
    });

    const updatedUserProjectedQuantitiesRemaining = userProjectedQuantitiesRemaining.concat(
      userProjectedQuantitiesRemainingForHousePar
    );

    setUserProjectedQuantitiesRemaining(updatedUserProjectedQuantitiesRemaining);
  }

  updateTotalPoundsWithUserProjection = item => event => {
    const { userProjectedQuantitiesRemaining, setUserProjectedQuantitiesRemaining } = this.props;
    const updates = [...userProjectedQuantitiesRemaining];

    if (maybeMutateUserProjectedQuantitiesRemaining(updates, item, event.target.value)) {
      setUserProjectedQuantitiesRemaining(updates);
    }
  };

  render() {
    const { handleSubmit, futureOrders } = this.props;

    return (
      <div className='future-order-review-page' tabIndex='-1' ref={ref => (this.ref = ref)}>
        {futureOrders === null ? null : (
          <div>
            <Form size={'large'} onSubmit={handleSubmit(this.onSubmit)}>
              <ScheduleFutureGrindOrdersTable
                {...this.props}
                inputFocus={ref => (this.firstInputReference = ref)}
                updateTotalPounds={this.updateTotalPoundsWithUserProjection}
              />

              <Divider hidden />

              <SubmitButton {...this.props} />
            </Form>

            <TotalPounds {...this.props} />
          </div>
        )}
      </div>
    );
  }
}

ScheduleFutureOrdersComponent.propTypes = {
  futureOrders: PropTypes.array,
  grindOrders: PropTypes.array,
  grindHousePars: PropTypes.array,
  userProjectedQuantitiesRemaining: PropTypes.array,
  stockAllocationAlert: PropTypes.bool,
  getFutureLineItems: PropTypes.func.isRequired,
  getAvailableGrindingHousePar: PropTypes.func.isRequired,
  getStockAllocationAlert: PropTypes.func,
  getGrindOrders: PropTypes.func.isRequired,
  clear: PropTypes.func.isRequired,
  setHeaderAndFooter: PropTypes.func.isRequired,
  scheduleGrindOrdersToProduceToday: PropTypes.func.isRequired,
  generateGrindingOrdersFromHousePar: PropTypes.func.isRequired,
  currentAndNextWorkingDay: PropTypes.array,
  setUserProjectedQuantitiesRemaining: PropTypes.func.isRequired,
  showModal: PropTypes.func,
  clearUserProjectedQuantitiesRemaining: PropTypes.func.isRequired,
  isApprovedForDay: PropTypes.bool,
  roomIsDisabled: PropTypes.bool,
  roomCode: PropTypes.string,
  submitting: PropTypes.bool,
  pristine: PropTypes.bool,
  handleSubmit: PropTypes.func.isRequired,
  reset: PropTypes.func,
  replacePath: PropTypes.func,
  showNoCostWarningModal: PropTypes.func
};

const mapStateToProps = state => {
  const grindOrders = state.grindOrdersInfo.grindOrdersInfo;
  const futureOrders = state.cutOrderOverview.futureOrders;
  const grindHousePars = state.settingsInfo.grindingHousePars;
  const userProjectedQuantitiesRemaining = state.cutOrderOverview.userProjectedQuantitiesRemaining;
  const isApprovedForDay = state.portionRoomsInfo.currentPortionRoom.approved === true;
  const roomCode = state.portionRoomsInfo.currentPortionRoom.code;
  const roomIsDisabled =
    state.portionRoomsInfo.currentPortionRoom.portionRoomState === PortionRoomState.DISABLED;
  const operatingDates = state.operatingDates;
  const currentAndNextWorkingDay = [operatingDates.firstDay, operatingDates.secondDay];
  const stockAllocationAlert = state.portionRoomsInfo.stockAllocationAlert;

  const initialValues = {};

  userProjectedQuantitiesRemaining.forEach(userEntry => {
    const key = `${userEntry.itemId}-${userEntry.type}-toGrindToday`;
    initialValues[key] = userEntry.orderQuantityRemaining;
  });

  return {
    initialValues,
    grindOrders,
    futureOrders,
    grindHousePars,
    userProjectedQuantitiesRemaining,
    isApprovedForDay,
    roomIsDisabled,
    currentAndNextWorkingDay,
    roomCode,
    stockAllocationAlert
  };
};

const mapDispatchToProps = dispatch =>
  bindActionCreators(
    {
      getGrindOrders,
      getFutureLineItems,
      getAvailableGrindingHousePar,
      setUserProjectedQuantitiesRemaining,
      clearUserProjectedQuantitiesRemaining,
      clear,
      setHeaderAndFooter,
      replacePath,
      scheduleGrindOrdersToProduceToday,
      generateGrindingOrdersFromHousePar,
      getStockAllocationAlert,
      showNoCostWarningModal,
      showModal
    },
    dispatch
  );

const ScheduleFutureGrindOrders = connect(
  mapStateToProps,
  mapDispatchToProps
)(
  reduxForm({
    form: 'scheduleFutureGrindOrdersForm',
    enableReinitialize: true
  })(ScheduleFutureOrdersComponent)
);

export default ScheduleFutureGrindOrders;
