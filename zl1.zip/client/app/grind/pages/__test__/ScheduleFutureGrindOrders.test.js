import React from 'react';
import { mount, shallow } from 'enzyme';
import { Provider } from 'react-redux';
import { createReduxStore } from '../../../store';
import ScheduleFutureGrindOrders, {
  ScheduleFutureOrdersComponent,
  SubmitButton
} from '../ScheduleFutureGrindOrders';
import ScheduleFutureGrindOrdersTable from '../../../overview/components/ScheduleFutureGrindOrdersTable';
import lineItemsResources from '../../../shared/api/lineItemsResources';
import settingsResources from '../../../shared/api/settingsResources';
import grindOrdersResources from '../../../shared/api/grindOrdersResources';
import CustomerOrderFactory from '../../../../test-factories/customerOrder';
import CustomerFactory from '../../../../test-factories/customerFactory';
import LineItemFactory from '../../../../test-factories/lineItemFactory';
import GrindingHouseParFactory from '../../../../test-factories/grindingHousePar';
import { getTestStateForGrindingRoom } from '../../../../test-factories/testState';
import semanticUI from '../../../../test-helpers/semantic-ui';
import { Button } from 'semantic-ui-react';
import { replacePath, showModal, showNoCostWarningModal } from '../../../shared/actions/actions';
import { TotalPounds } from '../../../overview/components/TotalPounds';
import portionRoomsResources from '../../../shared/api/portionRoomsResources';
import productFactory from '../../../../test-factories/productFactory';
import { reduxForm } from 'redux-form';

jest.mock('../../../shared/actions/actions', () => ({
  replacePath: jest.fn(() => ({ type: 'MOCK_CHANGE_PATH' })),
  setHeaderAndFooter: jest.fn(() => ({ type: 'MOCK_SET_HEADER_AND_FOOTER' })),
  showNoCostWarningModal: jest.fn(() => ({ type: 'MOCK_SHOW_NO_COST_WARNING_MODAL' })),
  showModal: jest.fn(() => ({ type: 'MOCK_SHOW_MODAL' }))
}));
jest.mock('../../../shared/api/grindOrdersResources');
jest.mock('../../../shared/api/lineItemsResources');
jest.mock('../../../shared/api/settingsResources');
jest.mock('../../../shared/api/portionRoomsResources');

const customer = CustomerFactory.build({ name: 'GRILLED CHEESE FACTORY' });

const productWithoutACost = productFactory.build({ cost: null });
const productWithCostZero = productFactory.build({ code: '0000508', cost: 0 });

const lineItemResponse = {
  data: [
    LineItemFactory.build({
      itemId: 100,
      customerOrder: CustomerOrderFactory.build({ customer: customer, onHold: false }),
      quantityRemaining: 2
    }),
    LineItemFactory.build({
      itemId: 101,
      customerOrder: CustomerOrderFactory.build({ customer: customer, onHold: false }),
      quantityRemaining: 1
    }),
    LineItemFactory.build({
      itemId: 102,
      customerOrder: CustomerOrderFactory.build({
        customer: CustomerFactory.build({ name: 'GRILLED CHEESE FACTORY', customerCode: '54321' }),
        onHold: true
      }),
      quantityRemaining: 1,
      cuttingInstruction: 'Order for product without a cost',
      product: productWithoutACost
    }),
    LineItemFactory.build({
      itemId: 103,
      customerOrder: CustomerOrderFactory.build({
        customer: CustomerFactory.build({ name: 'GRILLED CHEESE FACTORY', customerCode: '12345' }),
        onHold: true
      }),
      quantityRemaining: 1,
      cuttingInstruction: 'Order for product with cost zero',
      product: productWithCostZero
    })
  ]
};

const grindHouseParResponse = {
  data: [GrindingHouseParFactory.build()]
};

describe('scheduleFutureGrindOrders', () => {
  beforeEach(() => {
    jest.useFakeTimers();
    lineItemsResources.getFutureLineItems.mockImplementation((arg, success) =>
      success(lineItemResponse)
    );
    grindOrdersResources.scheduleGrindOrdersToProduceToday.mockImplementation((arg, success) =>
      success()
    );
    grindOrdersResources.generateGrindingOrdersFromHousePar.mockImplementation(
      (arg1, arg2, success) => success({})
    );
    settingsResources.getAvailableGrindingHousePar.mockImplementation((arg, success) =>
      success(grindHouseParResponse)
    );
    portionRoomsResources.getStockAllocationAlert.mockResolvedValue({ data: false });
  });

  afterEach(() => {
    replacePath.mockClear(); // NB - mockReset destroys the mock, mockRestore undoes it
    lineItemsResources.getFutureLineItems.mockReset();
    settingsResources.getAvailableGrindingHousePar.mockReset();
    grindOrdersResources.scheduleGrindOrdersToProduceToday.mockReset();
    grindOrdersResources.generateGrindingOrdersFromHousePar.mockReset();
    portionRoomsResources.getStockAllocationAlert.mockReset();
  });

  describe('when there are future orders', () => {
    let wrapper, store;

    beforeEach(() => {
      store = createReduxStore({
        portionRoomsInfo: {
          currentPortionRoom: {
            roomType: 'CUTTING',
            code: 'D'
          }
        },
        cutOrderOverview: {
          userProjectedQuantitiesRemaining: []
        }
      });
      wrapper = mount(
        <Provider store={store}>
          <ScheduleFutureGrindOrders />
        </Provider>
      );
    });

    test('should render schedule future orders and userProjectedQuantitiesRemaining for grinding room', () => {
      store = createReduxStore(getTestStateForGrindingRoom());

      const dispatchSpy = jest.spyOn(store, 'dispatch');

      const grindingWrapper = mount(
        <Provider store={store}>
          <ScheduleFutureGrindOrders />
        </Provider>
      );

      jestExpect(dispatchSpy).toHaveBeenCalledWith({ type: 'MOCK_SHOW_NO_COST_WARNING_MODAL' });
      jestExpect(showNoCostWarningModal).toHaveBeenCalledWith([
        productWithoutACost.code,
        productWithCostZero.code
      ]);

      const jestExpectedUserProjectedQuantitiesRemaining = [
        {
          itemId: 1,
          type: 'HOUSE_PAR',
          orderQuantityRemaining: 12,
          quantityRemaining: 0
        }
      ];

      let futureOrderOverviewTable = grindingWrapper.find(ScheduleFutureGrindOrdersTable);
      let totalPounds = grindingWrapper.find(TotalPounds);

      jestExpect(futureOrderOverviewTable).toExist();
      jestExpect(totalPounds).toExist();
      jestExpect(futureOrderOverviewTable).toHaveProp({ futureOrders: lineItemResponse.data });
      jestExpect(totalPounds).toHaveProp({ futureOrders: lineItemResponse.data });
      jestExpect(totalPounds).toHaveProp({
        userProjectedQuantitiesRemaining: jestExpectedUserProjectedQuantitiesRemaining
      });
    });

    test('should clear userProjectedQuantitiesRemaining when unmounting', () => {
      let DecoratedComponent = reduxForm({ form: 'testForm' })(ScheduleFutureOrdersComponent);

      const clearUserProjectedQuantitiesRemaining = jest.fn();
      const clear = jest.fn();

      wrapper = mount(
        <Provider store={createReduxStore({})}>
          <DecoratedComponent
            setHeaderAndFooter={() => {}}
            getGrindOrders={() => {}}
            getFutureLineItems={() => {}}
            clear={clear}
            getAvailableGrindingHousePar={() => {}}
            getStockAllocationAlert={() => {}}
            clearUserProjectedQuantitiesRemaining={clearUserProjectedQuantitiesRemaining}
            scheduleGrindOrdersToProduceToday={() => {}}
            generateGrindingOrdersFromHousePar={() => {}}
            setUserProjectedQuantitiesRemaining={() => {}}
            isApprovedForDay={true}
            roomIsDisabled={false}
          />
        </Provider>
      );

      wrapper.unmount();

      jestExpect(clear).toHaveBeenCalledTimes(1);
      jestExpect(clearUserProjectedQuantitiesRemaining).toHaveBeenCalledTimes(1);
    });

    test('should go to Orders to Grind summary if submitting worked for grind orders', () => {
      store = createReduxStore({
        portionRoomsInfo: {
          currentPortionRoom: {
            roomType: 'GRINDING'
          }
        },
        function: {}
      });

      const wrapper = mount(
        <Provider store={store}>
          <ScheduleFutureGrindOrders />
        </Provider>
      );

      semanticUI.changeInput(wrapper, '100-LINE_ITEM-toGrindToday', '2');
      wrapper.find('form').simulate('submit');

      jestExpect(replacePath).toBeCalledWith('/grinding/grinding-orders');
    });

    test('should fill out form, submit values to API, reset form when submit successfully', () => {
      semanticUI.changeInput(wrapper, '100-LINE_ITEM-toGrindToday', '2');
      semanticUI.changeInput(wrapper, '1-HOUSE_PAR-toGrindToday', '3');

      wrapper.find('form').simulate('submit');

      jestExpect(grindOrdersResources.scheduleGrindOrdersToProduceToday.mock.calls[0][0]).toEqual({
        '100': '2'
      });
      jestExpect(grindOrdersResources.generateGrindingOrdersFromHousePar.mock.calls[0][0]).toEqual({
        '1': '3'
      });
      jestExpect(lineItemsResources.getFutureLineItems).toHaveBeenCalledTimes(1);
    });

    test('should fill out form, submit values to API successfully when having hold and multiple unhold orders ', () => {
      semanticUI.changeInput(wrapper, '100-LINE_ITEM-toGrindToday', '2');
      semanticUI.changeInput(wrapper, '1-HOUSE_PAR-toGrindToday', '3');
      semanticUI.changeInput(wrapper, '103-LINE_ITEM-toGrindToday', '1');
      semanticUI.changeInput(wrapper, '102-LINE_ITEM-toGrindToday', '1');

      wrapper.find('form').simulate('submit');

      jestExpect(showModal).toHaveBeenCalledWith(
        jestExpect.objectContaining({
          header: 'Customer on Credit Hold',
          content:
            'Customers 54321, 12345 are on credit hold. Are you sure you want to produce orders for these customers?',
          cancelButton: 'No',
          cancelAction: jestExpect.any(Function),
          confirmButton: 'Yes',
          confirmAction: jestExpect.any(Function)
        })
      );
    });

    test('should fill out form, submit values to API successfully when having hold and single unhold orders ', () => {
      semanticUI.changeInput(wrapper, '100-LINE_ITEM-toGrindToday', '2');
      semanticUI.changeInput(wrapper, '1-HOUSE_PAR-toGrindToday', '3');
      semanticUI.changeInput(wrapper, '103-LINE_ITEM-toGrindToday', '1');

      wrapper.find('form').simulate('submit');

      jestExpect(showModal).toHaveBeenCalledWith(
        jestExpect.objectContaining({
          header: 'Customer on Credit Hold',
          content:
            'Customer 12345 is on credit hold. Are you sure you want to produce orders for this customer?',
          cancelButton: 'No',
          cancelAction: jestExpect.any(Function),
          confirmButton: 'Yes',
          confirmAction: jestExpect.any(Function)
        })
      );
    });

    test('should not submit values to API when submit validation failed', () => {
      semanticUI.changeInput(wrapper, '100-LINE_ITEM-toGrindToday', 'abc');
      wrapper.find('form').simulate('submit');

      jestExpect(grindOrdersResources.scheduleGrindOrdersToProduceToday).not.toHaveBeenCalledWith();
    });
  });

  describe('when there are no future orders', () => {
    test('should not show Future orders table nor empty table message when futureOrders is null', () => {
      lineItemsResources.getFutureLineItems.mockImplementation(() => {});
      const store = createReduxStore({
        portionRoomsInfo: {
          currentPortionRoom: {
            roomType: 'GRINDING'
          }
        },
        cutOrderOverview: {
          futureOrders: null,
          userProjectedQuantitiesRemaining: []
        }
      });

      const wrapper = mount(
        <Provider store={store}>
          <ScheduleFutureGrindOrders />
        </Provider>
      );

      jestExpect(wrapper.find('.prime-list-empty-message')).not.toExist();
      jestExpect(wrapper.find(ScheduleFutureGrindOrdersTable)).not.toExist();
    });
  });
});

describe('Submit button', () => {
  test('should disable submit when the days grind orders are already approved', () => {
    const submitButton = shallow(
      <SubmitButton
        futureOrders={lineItemResponse.data}
        userProjectedQuantitiesRemaining={[
          {
            itemId: lineItemResponse.data[0].itemId,
            orderQuantityRemaining: lineItemResponse.data[0].quantityRemaining,
            quantityRemaining: 0
          }
        ]}
        submitting={false}
        pristine={true}
        isApprovedForDay={true}
        roomIsDisabled={false}
      />
    );

    jestExpect(submitButton.find(Button)).toBeDisabled();
  });

  test('should disable submit when pristine', () => {
    const submitButton = shallow(
      <SubmitButton
        futureOrders={lineItemResponse.data}
        userProjectedQuantitiesRemaining={[]}
        submitting={false}
        pristine={true}
        isApprovedForDay={false}
        roomIsDisabled={false}
      />
    );

    jestExpect(submitButton.find(Button)).toBeDisabled();
  });

  test('should enable submit when the days grind orders are not yet approved', () => {
    const submitButton = shallow(
      <SubmitButton
        futureOrders={lineItemResponse.data}
        userProjectedQuantitiesRemaining={[
          {
            itemId: lineItemResponse.data[0].itemId,
            orderQuantityRemaining: lineItemResponse.data[0].quantityRemaining,
            quantityRemaining: 0
          }
        ]}
        submitting={false}
        pristine={true}
        isApprovedForDay={false}
        roomIsDisabled={false}
      />
    );

    jestExpect(submitButton.find(Button)).not.toBeDisabled();
  });

  test('should not display when there are no orders to act on', () => {
    const submitButton = shallow(
      <SubmitButton
        futureOrders={[]}
        userProjectedQuantitiesRemaining={[]}
        submitting={false}
        pristine={true}
        isApprovedForDay={false}
        roomIsDisabled={false}
      />
    );

    jestExpect(submitButton.type()).toBeNull();
  });

  test('should not display when there are no grind house par to act on', () => {
    const submitButton = shallow(
      <SubmitButton
        futureOrders={[]}
        grindHousePars={[]}
        userProjectedQuantitiesRemaining={[]}
        submitting={false}
        pristine={true}
        isApprovedForDay={false}
        roomIsDisabled={false}
      />
    );

    jestExpect(submitButton.type()).toBeNull();
  });

  test('should display when there are grind house pars to act on', () => {
    const submitButton = shallow(
      <SubmitButton
        futureOrders={[]}
        grindHousePars={grindHouseParResponse.data}
        userProjectedQuantitiesRemaining={[]}
        submitting={false}
        pristine={true}
        isApprovedForDay={false}
        roomIsDisabled={false}
      />
    );

    jestExpect(submitButton.find(Button)).toBeDisabled();
  });
});
