import React from 'react';
import ViewGrindOrdersSummary, {
  mapStateToProps,
  ViewGrindOrdersSummaryComponent,
  GrindOrderSummaryContent,
  Batches,
  CreateButton
} from '../ViewGrindOrdersSummary';
import { GRIND_ORDERS } from '../../../shared/components/pageTitles';
import { TAB_SHIFTTAB_F4 } from '../../../shared/components/pageFooters';
import { PortionRoomState } from '../../../landingPage/reducers/portionRoomReducer';
import GrindOrderFactory, {
  GRIND_ORDER_WITH_NATURAL_BLEND_1_2_GRIND,
  GRIND_ORDER_WITH_SAME_BLEND_AND_DIFFERENT_SHIP_DATE,
  GRIND_WITH_90_THREE_THIRTY_TWO_GRIND_SIZE_F19_TABLE,
  GRIND_WITH_KOBE_THREE_EIGHTS_GRIND_SIZE_F6_TABLE,
  GRIND_WITH_NATURAL_BLEND_3_16_GRIND_F19_TABLE,
  GRIND_WITH_NOLAN_75_25_GRIND
} from '../../../../test-factories/grindingOrderFactory';
import BatchFactory from '../../../../test-factories/batch';
import { Table, Button } from 'semantic-ui-react';
import EmptyListMessage from '../../../shared/components/EmptyListMessage';
import { mount, shallow } from 'enzyme';
import { createReduxStore } from '../../../store';
import { Provider } from 'react-redux';
import blendFactory from '../../../../test-factories/blendFactory';

const batches = [
  BatchFactory.build({ blendName: 'A', grindSize: '3/32', finished: true, batchNumber: 1 }),
  BatchFactory.build({ blendName: 'A', grindSize: '3/32', batchNumber: 2 }),
  BatchFactory.build({ blendName: 'A', grindSize: '2/16' }),
  BatchFactory.build({ blendName: 'B', grindSize: '2/16' })
];

describe('ViewGrindOrdersSummary', () => {
  beforeEach(() => {
    jest.useFakeTimers();
  });

  describe('mount component', () => {
    let grindOrders;

    beforeEach(() => {
      grindOrders = [
        GrindOrderFactory.build(),
        GRIND_ORDER_WITH_SAME_BLEND_AND_DIFFERENT_SHIP_DATE,
        GRIND_WITH_NATURAL_BLEND_3_16_GRIND_F19_TABLE,
        GRIND_WITH_NOLAN_75_25_GRIND,
        GRIND_ORDER_WITH_NATURAL_BLEND_1_2_GRIND
      ];
    });

    test('grabs orders from the API', () => {
      const getGrindOrdersWithBatchesSpy = jest.fn();
      const changePathSpy = jest.fn();
      const setHeaderAndFooterSpy = jest.fn();

      const form = new ViewGrindOrdersSummaryComponent({
        getGrindOrdersWithBatches: getGrindOrdersWithBatchesSpy,
        setHeaderAndFooter: setHeaderAndFooterSpy,
        changePath: changePathSpy
      });

      form.componentDidMount();

      jestExpect(getGrindOrdersWithBatchesSpy).toBeCalled();
      jestExpect(setHeaderAndFooterSpy).toBeCalledWith({
        header: GRIND_ORDERS,
        footer: TAB_SHIFTTAB_F4
      });
    });

    test('should render header correctly', () => {
      const store = createReduxStore({
        grindOrdersInfo: { grindOrdersInfo: grindOrders },
        portionRoomsInfo: {
          currentPortionRoom: {
            portionRoomState: PortionRoomState.CAN_CLOSE,
            currentPortionRoom: { roomType: 'CUTTING' }
          }
        }
      });

      let wrapper = mount(
        <Provider store={store}>
          <ViewGrindOrdersSummary />
        </Provider>
      );

      jestExpect(wrapper.find(Table.HeaderCell).at(0)).toHaveText('Machine');
      jestExpect(wrapper.find(Table.HeaderCell).at(1)).toHaveText('Batch');
      jestExpect(wrapper.find(Table.HeaderCell).at(2)).toHaveText('Pounds');
      jestExpect(wrapper.find(Table.HeaderCell).at(3)).toHaveText('Status');
    });

    test('shows a summary ordered by blend name, grind size and machine name', () => {
      const wrapper = mount(
        <Table>
          <GrindOrderSummaryContent
            grindOrdersInfo={grindOrders}
            batchesInfo={batches}
            createBatch={() => {}}
          />
        </Table>
      );

      const nolanCell = wrapper
        .find(Table.Row)
        .at(0)
        .find(Table.Cell);
      jestExpect(nolanCell.at(0)).toHaveText('BLEND1002 Nolan - Trim 75/25 3/16');
      jestExpect(nolanCell.at(2)).toHaveText('20');

      const createButton = wrapper
        .find(Table.Row)
        .at(2)
        .find(Table.Cell);
      jestExpect(createButton.at(3).find(Button)).toHaveText('Create');

      const naturalHalfCell = wrapper
        .find(Table.Row)
        .at(3)
        .find(Table.Cell);
      jestExpect(naturalHalfCell.at(0)).toHaveText('BLEND1004 Natural 1/2');
      jestExpect(naturalHalfCell.at(2)).toHaveText('20');

      const naturalHalfGroundBeefCell = wrapper
        .find(Table.Row)
        .at(4)
        .find(Table.Cell);
      jestExpect(naturalHalfGroundBeefCell.at(0)).toHaveText('VMAG');
      jestExpect(naturalHalfGroundBeefCell.at(2)).toHaveText('20');

      const naturalThreeSixteenthCell = wrapper
        .find(Table.Row)
        .at(6)
        .find(Table.Cell);
      jestExpect(naturalThreeSixteenthCell.at(0)).toHaveText('BLEND1004 Natural 3/16');
      jestExpect(naturalThreeSixteenthCell.at(2)).toHaveText('70');

      const naturalF19Cell = wrapper
        .find(Table.Row)
        .at(7)
        .find(Table.Cell);
      jestExpect(naturalF19Cell.at(0)).toHaveText('F19');
      jestExpect(naturalF19Cell.at(2)).toHaveText('20');

      const naturalGroundBeefCell = wrapper
        .find(Table.Row)
        .at(8)
        .find(Table.Cell);
      jestExpect(naturalGroundBeefCell.at(0)).toHaveText('VMAG');
      jestExpect(naturalGroundBeefCell.at(2)).toHaveText('50');
    });

    test('shows a check for order if blend name has numbers', () => {
      const wrapper = mount(
        <Table>
          <GrindOrderSummaryContent
            grindOrdersInfo={[
              GRIND_WITH_90_THREE_THIRTY_TWO_GRIND_SIZE_F19_TABLE,
              GRIND_WITH_KOBE_THREE_EIGHTS_GRIND_SIZE_F6_TABLE,
              GRIND_WITH_NATURAL_BLEND_3_16_GRIND_F19_TABLE
            ]}
            batchesInfo={batches}
            createBatch={() => {}}
          />
        </Table>
      );

      const naturalThreeSixteenthCell = wrapper
        .find(Table.Row)
        .at(0)
        .find(Table.Cell);
      jestExpect(naturalThreeSixteenthCell.at(0)).toHaveText('BLEND1004 Natural 3/16');
      jestExpect(naturalThreeSixteenthCell.at(2)).toHaveText('20');

      const naturalThreeSixteenthMachineCell = wrapper
        .find(Table.Row)
        .at(1)
        .find(Table.Cell);
      jestExpect(naturalThreeSixteenthMachineCell.at(0)).toHaveText('F19');
      jestExpect(naturalThreeSixteenthMachineCell.at(2)).toHaveText('20');

      const createButton = wrapper
        .find(Table.Row)
        .at(2)
        .find(Table.Cell);
      jestExpect(createButton.at(3).find(Button)).toHaveText('Create');

      const kobeThreeEightCell = wrapper
        .find(Table.Row)
        .at(3)
        .find(Table.Cell);
      jestExpect(kobeThreeEightCell.at(0)).toHaveText('BLEND1006 Kobe 3/8');
      jestExpect(kobeThreeEightCell.at(2)).toHaveText('20');

      const kobeThreeEightMachineCell = wrapper
        .find(Table.Row)
        .at(4)
        .find(Table.Cell);
      jestExpect(kobeThreeEightMachineCell.at(0)).toHaveText('F6');
      jestExpect(kobeThreeEightMachineCell.at(2)).toHaveText('20');

      const ninetyThreeThirtyTwoCell = wrapper
        .find(Table.Row)
        .at(6)
        .find(Table.Cell);
      jestExpect(ninetyThreeThirtyTwoCell.at(0)).toHaveText('BLEND1012 90% 3/32');
      jestExpect(ninetyThreeThirtyTwoCell.at(2)).toHaveText('20');

      const ninetyThreeThirtyTwoMachineCell = wrapper
        .find(Table.Row)
        .at(7)
        .find(Table.Cell);
      jestExpect(ninetyThreeThirtyTwoMachineCell.at(0)).toHaveText('F19');
      jestExpect(ninetyThreeThirtyTwoMachineCell.at(2)).toHaveText('20');
    });

    test('shows batches table row', () => {
      const wrapper = mount(
        <Table>
          <Table.Body>
            <Batches batchesInfo={batches} blendName={'A'} grindSize={'3/32'} />
          </Table.Body>
        </Table>
      );

      const batchCell1 = wrapper
        .find(Table.Row)
        .at(0)
        .find(Table.Cell);
      jestExpect(batchCell1.at(1)).toHaveText('Batch #1');
      jestExpect(batchCell1.at(2)).toHaveText('12.13');
      jestExpect(batchCell1.at(3)).toHaveText('Finished');

      const batchCell2 = wrapper
        .find(Table.Row)
        .at(1)
        .find(Table.Cell);
      jestExpect(batchCell2.at(1)).toHaveText('Batch #2');
      jestExpect(batchCell2.at(2)).toHaveText('12.13');
    });

    test('shows create button', () => {
      const wrapper = mount(
        <Table>
          <Table.Body>
            <CreateButton
              batchesInfo={batches}
              blend={blendFactory.build()}
              grindSize={'3/32'}
              createBatch={() => {}}
            />
          </Table.Body>
        </Table>
      );

      const batchCell1 = wrapper
        .find(Table.Row)
        .at(0)
        .find(Table.Cell);
      jestExpect(batchCell1.at(3).find(Button)).toHaveText('Create');
    });

    test('should render Empty Table with no grind order', () => {
      const wrapper = shallow(
        <ViewGrindOrdersSummaryComponent
          getGrindOrdersWithBatches={() => {}}
          setHeaderAndFooter={() => {}}
          grindOrdersInfo={[]}
          changePath={() => {}}
          goBack={() => {}}
        />
      );

      jestExpect(wrapper.find(EmptyListMessage)).toExist();
    });
  });

  describe('Translating state into props', () => {
    test('should copy over the grind orders', () => {
      const state = {
        grindOrdersInfo: {
          grindOrdersInfo: 'abc'
        },
        portionRoomsInfo: {
          currentPortionRoom: {}
        },
        batches: {
          info: {
            batches: []
          }
        }
      };

      jestExpect(mapStateToProps(state).grindOrdersInfo).toBe('abc');
    });

    test('should see if the portion room is open', () => {
      const state = {
        grindOrdersInfo: {},
        portionRoomsInfo: {
          currentPortionRoom: {
            portionRoomState: PortionRoomState.CAN_CLOSE
          }
        },
        batches: {
          info: {
            batches: []
          }
        }
      };

      jestExpect(mapStateToProps(state).isRoomOpen).toBe(true);
    });

    test('should see if the portion room is not open', () => {
      const state = {
        grindOrdersInfo: {},
        portionRoomsInfo: {
          currentPortionRoom: {
            portionRoomState: PortionRoomState.CAN_OPEN
          }
        },
        batches: {
          info: {
            batches: []
          }
        }
      };

      jestExpect(mapStateToProps(state).isRoomOpen).toBe(false);
    });

    test('should note that this is not a grinding room', () => {
      const state = {
        grindOrdersInfo: {},
        portionRoomsInfo: {
          currentPortionRoom: {
            roomType: 'CUTTING'
          }
        },
        batches: {
          info: {
            batches: []
          }
        }
      };

      jestExpect(mapStateToProps(state).isGrindingRoom).toBe(false);
    });

    test('should note that this is a grinding room', () => {
      const state = {
        grindOrdersInfo: {},
        portionRoomsInfo: {
          currentPortionRoom: {
            roomType: 'GRINDING'
          }
        },
        batches: {
          info: {
            batches: []
          }
        }
      };

      jestExpect(mapStateToProps(state).isGrindingRoom).toBe(true);
    });
  });

  describe('auto-refresh data', () => {
    let viewGrindOrdersSummaryComponent;

    beforeEach(() => {
      viewGrindOrdersSummaryComponent = new ViewGrindOrdersSummaryComponent({
        setHeaderAndFooter: () => {},
        getGrindOrdersWithBatches: () => {}
      });
    });

    afterEach(() => {
      jest.clearAllTimers();
    });

    test('should call setInterval when componentDidMount', () => {
      viewGrindOrdersSummaryComponent.componentDidMount();
      jestExpect(setInterval).toHaveBeenCalledTimes(1);
    });

    test('should call clearInterval when componentWillUnmount', () => {
      viewGrindOrdersSummaryComponent.componentWillUnmount();
      jestExpect(clearInterval).toHaveBeenCalledTimes(1);
    });
  });
});
