import PropTypes from 'prop-types';
import React from 'react';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import { Route, Switch } from 'react-router-dom';
import { replacePath, setHeaderAndFooter } from '../../shared/actions/actions';
import SideNavigation from '../../shared/components/SideNavigation';
import ProductSetup from '../../productSetup/pages/ProductSetup';
import IncompleteProductSetup from '../../incompleteProductSetup/pages/IncompleteProductSetup';
import ProductSearch from '../../productSearch/pages/ProductSearch';
import _ from 'lodash';
import ProductActivity from '../../productActivity/pages/ProductActivity';
import ProductActivityDetails from '../../productActivity/pages/ProductActivityDetails';
import subscriber, { f2BehaviorForSideNavigation } from '../../shared/functionKeys/subscriber';

class ProductBase extends React.Component {
  constructor(props) {
    super(props);

    this.subRouteLinks = this.subRouteLinks.bind(this);
  }

  subRouteLinks() {
    const { match, role } = this.props;
    const subRoutes = [
      {
        path: '/product-search',
        name: 'Product Search',
        allowedRoles: ['ROLE_PORTION_ROOM_MEMBER', 'ROLE_ADMIN', 'ROLE_COSTING'],
        toPath: () => this.props.replacePath(`${match.url}/product-search`)
      },
      {
        path: '/product-activity',
        name: 'Product Activity',
        allowedRoles: ['ROLE_PORTION_ROOM_MEMBER', 'ROLE_ADMIN'],
        toPath: () => this.props.replacePath(`${match.url}/product-activity`)
      },
      {
        path: '/product-setup',
        name: 'Product Setup',
        allowedRoles: ['ROLE_ADMIN', 'ROLE_COSTING'],
        toPath: () => this.props.replacePath(`${match.url}/product-setup`)
      },
      {
        path: '/incomplete-products',
        name: 'Incomplete Products',
        allowedRoles: ['ROLE_ADMIN', 'ROLE_COSTING'],
        toPath: () => this.props.replacePath(`${match.url}/incomplete-products`)
      }
    ];
    return _.filter(subRoutes, subRoute => subRoute.allowedRoles.includes(role));
  }

  render() {
    const { match } = this.props;

    return (
      <div className='page-content side-navigation-page left-right'>
        <SideNavigation
          links={this.subRouteLinks()}
          currentPath={this.props.location.pathname}
          ref={ref => (this.sideNavigation = ref)}
        />

        <div className='right'>
          <Switch>
            <Route exact path={`${match.url}/product-search`} component={ProductSearch} />
            <Route exact path={`${match.url}/product-activity`} component={ProductActivity} />
            <Route
              path={`${match.url}/product-activity/details`}
              component={ProductActivityDetails}
            />
            <Route exact path={`${match.url}/product-setup`} component={ProductSetup} />
            <Route
              exact
              path={`${match.url}/incomplete-products`}
              component={IncompleteProductSetup}
            />
          </Switch>
        </div>
      </div>
    );
  }
}

ProductBase.propTypes = {
  role: PropTypes.string,
  replacePath: PropTypes.func.isRequired,
  match: PropTypes.object.isRequired,
  keydown: PropTypes.object,
  location: PropTypes.object.isRequired,
  setHeaderAndFooter: PropTypes.func.isRequired
};

const mapStateToProps = state => ({
  role: state.login.role
});

const mapDispatchToProps = dispatch =>
  bindActionCreators(
    {
      replacePath,
      setHeaderAndFooter
    },
    dispatch
  );

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(
  subscriber(ProductBase, {
    f2Behavior: f2BehaviorForSideNavigation,
    targetComponent: 'ProductBase',
    uris: {
      F2: [
        '#/product/product-search',
        '#/product/product-activity',
        '#/product/product-setup',
        '#/product/incomplete-products'
      ]
    }
  })
);
