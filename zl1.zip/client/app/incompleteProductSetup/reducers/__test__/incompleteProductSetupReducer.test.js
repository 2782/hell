import { GET_INCOMPLETE_PRODUCTS } from '../../actions/incompleteProductSetupActionTypes';

import incompleteProductSetupReducer from '../incompleteProductSetupReducer';

describe('incompleteProductSetupReducer', () => {
  let initState;
  beforeEach(() => {
    initState = {
      incompleteProducts: [],
      loading: true
    };
  });

  test('should initialize with the correct initial state', () => {
    jestExpect(incompleteProductSetupReducer(undefined, { type: 'UNEXPECTED' })).toEqual(initState);
  });

  test('given I receive some incomplete products, the state should be updated', () => {
    let incompleteProducts = [
      {
        code: '0079007',
        description: 'FLEMINGS CAB PRHOUSE STK',
        portionSize: '2 OZ',
        tableAssigned: true,
        priceModelAssigned: false,
        createdAt: '07-16'
      },
      {
        code: '0202013',
        description: 'SLICED PORK BELLY 9MM',
        portionSize: '32 OZ',
        tableAssigned: true,
        priceModelAssigned: false,
        createdAt: '07-16'
      }
    ];

    jestExpect(
      incompleteProductSetupReducer(initState, {
        type: GET_INCOMPLETE_PRODUCTS,
        payload: incompleteProducts
      })
    ).toEqual({ ...initState, incompleteProducts: incompleteProducts });
  });
});
