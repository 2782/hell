import React from 'react';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import { changePath, replacePath, setHeaderAndFooter } from '../../shared/actions/actions';
import { TAB_SHIFTTAB_F4_F2 } from '../../shared/components/pageFooters';
import { INCOMPLETE_PRODUCT_SETUP } from '../../shared/components/pageTitles';
import IncompleteProductSetupTable from '../components/IncompleteProductSetupTable';
import { getIncompleteProducts } from '../actions/incompleteProductSetupActions';
import { getProduct } from '../../shared/components/product/actionsDuplicate';
import { initFinishedProductCode } from '../../createYieldModel/actions/cuttingYieldModelActions';
import { initialize } from 'redux-form';
import { PRODUCT_SETUP_FORM } from '../../productSetup/pages/ProductSetup';

export class IncompleteProductSetupPage extends React.Component {
  componentDidMount() {
    const { setHeaderAndFooter, getIncompleteProducts } = this.props;
    setHeaderAndFooter({
      header: INCOMPLETE_PRODUCT_SETUP,
      footer: TAB_SHIFTTAB_F4_F2
    });
    getIncompleteProducts();

    this.ref.focus();
  }

  setupTable(productCode) {
    this.props.getProduct(productCode);
    this.props.initialize(PRODUCT_SETUP_FORM, { productCode: productCode });

    this.props.replacePath('/product/product-setup');
  }

  setupPriceModel(productCode) {
    this.props.initFinishedProductCode(productCode);
    this.props.changePath('/yield-model/create');
  }

  render() {
    return (
      <div
        className={'page-content incomplete-product-setup-table'}
        tabIndex={0}
        ref={ref => (this.ref = ref)}
      >
        <IncompleteProductSetupTable
          incompleteProducts={this.props.incompleteProducts}
          setupTable={this.setupTable.bind(this)}
          setupPriceModel={this.setupPriceModel.bind(this)}
          loading={this.props.loading}
        />
      </div>
    );
  }
}

IncompleteProductSetupPage.propTypes = {
  setHeaderAndFooter: PropTypes.func,
  getIncompleteProducts: PropTypes.func.isRequired,
  incompleteProducts: PropTypes.array,
  changePath: PropTypes.func,
  replacePath: PropTypes.func,
  getProduct: PropTypes.func,
  switchTab: PropTypes.func,
  initFinishedProductCode: PropTypes.func,
  initialize: PropTypes.func,
  loading: PropTypes.bool
};

const mapStateToProps = state => ({
  incompleteProducts: state.incompleteProductSetup.incompleteProducts,
  loading: state.incompleteProductSetup.loading
});

const mapDispatchToProps = dispatch =>
  bindActionCreators(
    {
      setHeaderAndFooter,
      getIncompleteProducts,
      changePath,
      replacePath,
      getProduct,
      initFinishedProductCode,
      initialize
    },
    dispatch
  );

const IncompleteProductSetup = connect(
  mapStateToProps,
  mapDispatchToProps
)(IncompleteProductSetupPage);

export default IncompleteProductSetup;
