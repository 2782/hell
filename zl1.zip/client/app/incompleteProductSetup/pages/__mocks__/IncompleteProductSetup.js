import React from 'react';

class IncompleteProductSetup extends React.Component {
  render() {
    return <div>Fake incomplete product page</div>;
  }
}

export default IncompleteProductSetup;
