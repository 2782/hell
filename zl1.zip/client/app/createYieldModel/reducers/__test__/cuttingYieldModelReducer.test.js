import cuttingYieldModelReducer from '../cuttingYieldModelReducer';
import {
  CHECK_BYPRODUCT_COST_AND_LABOR,
  CUTTING_YIELD_MODEL_CLEARED,
  UPDATE_YIELD_MODEL,
  GET_ACTUAL_YIELD_TESTS,
  GET_ACTUAL_YIELD_TESTS_FAILED,
  CALCULATED_COSTS_ON_CUTTING_YIELD_MODEL
} from '../../actions/cuttingYieldModelActionTypes';
import CuttingYieldModelFactory from '../../../../test-factories/cuttingYieldModel';
import yieldModelTestsFactory from '../../../../test-factories/yieldModelTests';

describe('cuttingYieldModelReducer', () => {
  let initState, yieldModel, yieldModelTests;

  beforeEach(() => {
    initState = {
      yieldModel: {
        byproductCredit: 0,
        finishedProductCost: 0,
        estimatedYield: 100,
        additives: 0
      },
      pricingModelCostsAndLabors: {},
      actualYieldTests: {},
      actualYieldTestsAvailableStatus: -1
    };

    yieldModel = CuttingYieldModelFactory.build({
      finishedProductCode: '0007889',
      sourceProductCode: '0007891'
    });

    yieldModelTests = yieldModelTestsFactory.build();
  });

  test('should return initial reducer state when first initialized', () => {
    jestExpect(cuttingYieldModelReducer(undefined, { type: 'unexpect' })).toEqual(initState);
  });

  test('should return initial reducer state when action type unknown', () => {
    jestExpect(cuttingYieldModelReducer(initState, { type: 'unexpect' })).toEqual(initState);
  });

  describe('UPDATE_YIELD_MODEL', () => {
    test('should update yield model', () => {
      jestExpect(
        cuttingYieldModelReducer(initState, {
          type: UPDATE_YIELD_MODEL,
          payload: yieldModel
        })
      ).toEqual({
        ...initState,
        yieldModel: yieldModel,
        finishedProductIsReadOnly: true,
        sourceProductIsReadOnly: true
      });
    });

    test('should not update yield model', () => {
      jestExpect(
        cuttingYieldModelReducer(initState, {
          type: UPDATE_YIELD_MODEL,
          payload: {}
        })
      ).toEqual({
        ...initState,
        yieldModel: {},
        finishedProductIsReadOnly: false,
        sourceProductIsReadOnly: false
      });
    });
  });

  test('should clear yield model and pricing model confirmation when dispatch action CLEAR_YIELD_MODEL_INFO', () => {
    jestExpect(
      cuttingYieldModelReducer(
        { yieldModel: yieldModel, pricingModelConfirmationShowing: true },
        {
          type: CUTTING_YIELD_MODEL_CLEARED
        }
      )
    ).toEqual({
      ...initState
    });
  });

  test('should check byproduct cost and labor', () => {
    const previousValues = {
      yieldModel,
      pricingModelCostsAndLabors: {
        '0078889': { productCode: '0078889', cost: false, labor: false },
        '0078891': { productCode: '0078891', cost: true, labor: true }
      },
      actualYieldTests: {},
      actualYieldTestsAvailableStatus: -1
    };
    jestExpect(
      cuttingYieldModelReducer(previousValues, {
        type: CHECK_BYPRODUCT_COST_AND_LABOR,
        payload: { productCode: '0078889', cost: true, labor: false }
      })
    ).toEqual({
      ...initState,
      yieldModel,
      pricingModelCostsAndLabors: {
        '0078889': { productCode: '0078889', cost: true, labor: false },
        '0078891': { productCode: '0078891', cost: true, labor: true }
      }
    });
  });

  test('should get actual yield tests', () => {
    const previousValues = {
      yieldModel,
      pricingModelCostsAndLabors: {},
      actualYieldTests: {},
      actualYieldTestsAvailableStatus: -1
    };
    jestExpect(
      cuttingYieldModelReducer(previousValues, {
        type: GET_ACTUAL_YIELD_TESTS,
        payload: yieldModelTests
      })
    ).toEqual({
      ...initState,
      yieldModel,
      actualYieldTests: yieldModelTests,
      actualYieldTestsAvailableStatus: 1
    });
  });

  test('should not get actual yield tests if there is no yield test available', () => {
    const previousValues = {
      yieldModel,
      pricingModelCostsAndLabors: {},
      actualYieldTests: {},
      actualYieldTestsAvailableStatus: -1
    };
    jestExpect(
      cuttingYieldModelReducer(previousValues, {
        type: GET_ACTUAL_YIELD_TESTS_FAILED
      })
    ).toEqual({
      ...initState,
      yieldModel,
      actualYieldTests: {},
      actualYieldTestsAvailableStatus: 0
    });
  });

  test('should update the finishedProductCost on the pre-existing yield model', () => {
    const previousValues = {
      yieldModel,
      pricingModelCostsAndLabors: {},
      actualYieldTests: {},
      actualYieldTestsAvailableStatus: -1
    };

    const previewYieldModel = {
      ...yieldModel,
      finishedProductCost: 'NEW_COST',
      additives: 'NEW_ADDITIVES',
      byproductCredit: 'NEW_CREDIT',
      estimatedYield: 'NEW_YIELD'
    };

    jestExpect(
      cuttingYieldModelReducer(previousValues, {
        type: CALCULATED_COSTS_ON_CUTTING_YIELD_MODEL,
        payload: previewYieldModel
      })
    ).toEqual({
      ...previousValues,
      yieldModel: {
        ...yieldModel,
        finishedProductCost: 'NEW_COST',
        additives: 'NEW_ADDITIVES',
        byproductCredit: 'NEW_CREDIT',
        estimatedYield: 'NEW_YIELD'
      }
    });
  });
});
