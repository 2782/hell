import yieldModelResources from '../../shared/api/yieldModelResources';
import _ from 'lodash';
import {
  GET_BLENDS,
  GRABBED_GRINDING_YIELD_MODEL_FINISHED_COST,
  GRINDING_YIELD_MODEL_CLEARED,
  UPDATE_YIELD_MODEL
} from './grindingYieldModelActionTypes';

const buildPayload = (values, sourceProducts) => {
  return {
    ...values,
    sourceProducts: _.filter(
      sourceProducts,
      sourceProduct =>
        !_.isEmpty(sourceProduct) &&
        !_.isEmpty(sourceProduct.code) &&
        (!_.isEmpty(sourceProduct.blendPercentage) || _.isNumber(sourceProduct.blendPercentage))
    )
  };
};

export const calculateFinishedCost = ({ sourceProducts, ...values }) => dispatch => {
  const grindingYieldModel = buildPayload(values, sourceProducts);

  return yieldModelResources
    .calculateGrindingYieldModelFinishedCost(grindingYieldModel)
    .then(response => {
      const finishedCost = response.data;
      dispatch({
        type: GRABBED_GRINDING_YIELD_MODEL_FINISHED_COST,
        payload: {
          finishedCost
        }
      });
    });
};

export const createGrindingYieldModel = (
  { sourceProducts, ...values },
  rejectCallback = () => {}
) => dispatch => {
  const grindingYieldModel = buildPayload(values, sourceProducts);

  return yieldModelResources.createGrindingYieldModel(
    grindingYieldModel,
    updatedModel =>
      dispatch({
        type: UPDATE_YIELD_MODEL,
        payload: {
          ...updatedModel,
          finishedCost: updatedModel.cost
        }
      }),
    rejectCallback
  );
};

export const yieldModelAlreadyExists = values => () => {
  const realBlend = values.sourceProducts
    ? { ...values, sourceProducts: values.sourceProducts.filter(product => product.code) }
    : null;
  return yieldModelResources.checkGrindingYieldModelExists(realBlend).then(grindingYieldModel => {
    return grindingYieldModel;
  });
};

export const updateGrindingYieldModelInfo = yieldModel => ({
  type: UPDATE_YIELD_MODEL,
  payload: yieldModel
});

export const clearGrindingYieldModel = () => (dispatch, getState) => {
  const {
    location: { pathname }
  } = getState().router;

  if (!pathname.includes('/yield-model/changelog')) {
    dispatch({
      type: GRINDING_YIELD_MODEL_CLEARED
    });
  }
};

export const getBlends = () => dispatch => {
  return yieldModelResources.getBlends().then(response => {
    dispatch({
      type: GET_BLENDS,
      payload: response.data
    });
  });
};
