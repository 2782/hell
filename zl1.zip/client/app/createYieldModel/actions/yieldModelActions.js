import { CHANGE_YIELD_MODEL_TYPE } from './yieldModelActionTypes';

export const changeYieldModelType = yieldModelType => {
  return dispatch => {
    dispatch({
      type: CHANGE_YIELD_MODEL_TYPE,
      payload: yieldModelType
    });
  };
};
