import React from 'react';
import * as _ from 'lodash';
import PropTypes from 'prop-types';
import { Table, Divider } from 'semantic-ui-react';
import { formatNumberToTwoDecimalPlacesString } from '../../shared/util/dataUtil';

const formatValue = value => {
  return _.eq(value, 0) ? '0.00' : formatNumberToTwoDecimalPlacesString(value);
};

const FinishedProductYieldTestCompareTable = props => {
  const {
    estimatedYield,
    finishedProductCost,
    actualYieldPercent,
    actualUnitCostPerLb,
    OneYearYieldTestList,
    lastDate
  } = props;
  let estimatedYieldVariance = formatValue(actualYieldPercent - estimatedYield);
  let finishedProductCostVariance = formatValue(finishedProductCost - actualUnitCostPerLb);

  return (
    <div>
      <Divider hidden />
      <Divider hidden />
      <div className='yield-tests-comparison' pid='yield-tests-comparison'>
        Yield Test Comparison - 12 Month Average
      </div>
      <div>
        {OneYearYieldTestList.length} TESTS IN AVERAGE - LAST TEST ON {lastDate}
      </div>
      <Table
        className='yield-test-finished-products'
        collapsing
        pid='yield-test-finished-products-table'
      >
        <Table.Header>
          <Table.Row className='theader'>
            <Table.HeaderCell />
            <Table.HeaderCell
              className='th'
              pid='yield-test-finished-products-table__header-yield-percent'
            >
              YIELD
              <br />
              PERCENT
            </Table.HeaderCell>
            <Table.HeaderCell
              className='th'
              pid='yield-test-finished-products-table__header-unit-cost'
            >
              UNIT COST
              <br />
              PER LB
            </Table.HeaderCell>
          </Table.Row>
        </Table.Header>
        <Table.Body>
          <Table.Row>
            <Table.Cell
              className='first-td-middle'
              pid='yield-test-finished-products-table__label-model'
            >
              MODEL
            </Table.Cell>
            <Table.Cell
              className='other-td'
              pid='yield-test-finished-products-table__yield-pecent-model'
            >
              {formatValue(estimatedYield)}
            </Table.Cell>
            <Table.Cell
              className='other-td'
              pid='yield-test-finished-products-table__unit-cost-model'
            >
              {formatValue(finishedProductCost)}
            </Table.Cell>
          </Table.Row>
          <Table.Row>
            <Table.Cell
              className='first-td-middle'
              pid='yield-test-finished-products-table__label-actual'
            >
              YIELD TEST AVERAGE
            </Table.Cell>
            <Table.Cell
              className='other-td'
              pid='yield-test-finished-products-table__yield-pecent-actual'
            >
              {formatValue(actualYieldPercent)}
            </Table.Cell>
            <Table.Cell
              className='other-td'
              pid='yield-test-finished-products-table__unit-cost-actual'
            >
              {formatValue(actualUnitCostPerLb)}
            </Table.Cell>
          </Table.Row>
          <Table.Row>
            <Table.Cell
              className='first-td-bottom'
              pid='yield-test-finished-products-table__label-variance'
            >
              VARIANCE
            </Table.Cell>
            <Table.Cell
              className='other-td'
              pid='yield-test-finished-products-table__yield-pecent-variance'
            >
              {estimatedYieldVariance}
            </Table.Cell>
            <Table.Cell
              className='other-td'
              pid='yield-test-finished-products-table__unit-cost-variance'
            >
              {finishedProductCostVariance}
            </Table.Cell>
          </Table.Row>
        </Table.Body>
      </Table>
    </div>
  );
};

FinishedProductYieldTestCompareTable.propTypes = {
  estimatedYield: PropTypes.number,
  finishedProductCost: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  actualYieldPercent: PropTypes.number,
  OneYearYieldTestList: PropTypes.array,
  lastDate: PropTypes.string,
  actualUnitCostPerLb: PropTypes.number
};

export default FinishedProductYieldTestCompareTable;
