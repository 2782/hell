import React from 'react';
import PropTypes from 'prop-types';
import _ from 'lodash';
import { Field, formValueSelector } from 'redux-form';
import { Form, Label, Table } from 'semantic-ui-react';
import ProductDuplicate from '../../shared/components/product/ProductDuplicate';
import {
  normalizeProductCode,
  normalizeToTwoDecimalPlaces
} from '../../shared/components/product/normalizer';
import FormElement from '../../shared/FormElement';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import {
  getProduct,
  setProductExistTo,
  setAdditiveSourceItem
} from '../../shared/components/product/actionsDuplicate';
import { NOT_A_PRODUCT_CODE, MUST_BE_A_SOURCE_ITEM } from '../../../config/errorMessage';
import {
  formatNumberToTwoDecimalPlacesString,
  formatNumberToTwoDecimalPlacesStringIncludeZero,
  zeroIfInvalid
} from '../../shared/util/dataUtil';

export class AdditiveTableComponent extends React.Component {
  constructor(props) {
    super(props);
    this.handleProductCodeChange = this.handleProductCodeChange.bind(this);
  }

  componentDidUpdate() {
    const { fields, products, setAdditiveSourceItem } = this.props;
    let noEmptyAdditiveProductCodes = _.every(fields.getAll(), field => {
      return _.get(field, 'productCode', '') !== '';
    });

    if (noEmptyAdditiveProductCodes) {
      fields.push({});
    }

    let sourceItem = true;
    fields.map((additive, index) => {
      const additiveInfo = fields.get(index);
      const productInformation = products[additiveInfo.productCode];
      if (productInformation !== undefined) {
        const isSourceItem =
          productInformation.productOutput !== undefined &&
          productInformation.productOutput === 'SOURCE';
        if (!isSourceItem) {
          sourceItem = isSourceItem;
        }
      }
    });

    setAdditiveSourceItem(sourceItem);
  }

  componentWillUnmount() {
    const { fields, setProductExistTo } = this.props;
    fields.getAll().forEach((field, index) => {
      const additiveProductCode = _.get(field, 'productCode', '');
      if (!_.isEmpty(additiveProductCode)) {
        setProductExistTo(`yieldAdditives[${index}].productCode`, true);
      }
    });
  }

  handleAddNewAdditiveOnBlur(event, productCode, fieldName, index) {
    const { fields, getProduct, setProductExistTo } = this.props;
    if (_.isEmpty(productCode)) {
      if (fields.length - 1 !== index) {
        event.preventDefault();
        fields.remove(index);
      }
    } else {
      getProduct(productCode, () => setProductExistTo(fieldName, false));
    }
  }

  handleProductCodeChange(event, productCode, prevValue, fieldName) {
    const { setProductExistTo } = this.props;
    if (!_.isEmpty(productCode)) {
      setProductExistTo(fieldName, true);
    }
  }

  getNotification() {
    const {
      message,
      meta: { error, warning, dirty, invalid, submitFailed }
    } = this.props;
    if (invalid && (dirty || submitFailed) && !message) {
      return (
        (error && (
          <Label basic color='red' pointing>
            {error}
          </Label>
        )) ||
        (warning && (
          <Label basic color='orange' pointing>
            {warning}
          </Label>
        ))
      );
    } else {
      return (
        message && (
          <Label basic color='red' pointing>
            {message}
          </Label>
        )
      );
    }
  }

  render() {
    const { fields, products, productsExist } = this.props;

    return (
      <div>
        <Table columns={3} fixed size='small'>
          <Table.Header>
            <Table.Row>
              <Table.HeaderCell width={10}>ADDITIVES</Table.HeaderCell>
              <Table.HeaderCell width={3}>WEIGHT (LBS)</Table.HeaderCell>
              <Table.HeaderCell width={3}>COST</Table.HeaderCell>
            </Table.Row>
          </Table.Header>
          <Table.Body>
            {fields.map((additive, index) => {
              const additiveInfo = fields.get(index);
              const productInformation = products[additiveInfo.productCode] || {};
              const nonSourceItem =
                productInformation.productOutput !== undefined &&
                productInformation.productOutput !== 'SOURCE';
              return (
                <Table.Row key={_.get(additiveInfo, 'id', additive)}>
                  <Table.Cell width={10} className={'additive'}>
                    <Field
                      component={ProductDuplicate}
                      useDotDotDot={false}
                      descriptionFontSize={'15px'}
                      name={`${additive}.productCode`}
                      namespace={`createYieldModel-additive-${index}`}
                      normalize={normalizeProductCode}
                      maxLength={7}
                      message={
                        _.get(productsExist, `${additive}.productCode`, true)
                          ? nonSourceItem
                            ? MUST_BE_A_SOURCE_ITEM
                            : null
                          : NOT_A_PRODUCT_CODE
                      }
                      onBlur={(event, productCode, prevValue, fieldName) =>
                        this.handleAddNewAdditiveOnBlur(event, productCode, fieldName, index)
                      }
                      onChange={this.handleProductCodeChange}
                      hideDescriptionLabel={true}
                      product={productInformation}
                    />
                  </Table.Cell>
                  <Table.Cell width={3}>
                    <Field
                      component={FormElement}
                      name={`${additive}.weight`}
                      className={'additive-weight'}
                      as={Form.Input}
                      normalize={normalizeToTwoDecimalPlaces}
                    />
                  </Table.Cell>
                  <Table.Cell width={3} className={'additive-cost'}>
                    {additiveInfo.cost}
                  </Table.Cell>
                </Table.Row>
              );
            })}
          </Table.Body>
        </Table>
        {this.getNotification()}
      </div>
    );
  }
}

const initNewYieldAdditive = (products, yieldAdditivesFromForm) => {
  _.forEach(yieldAdditivesFromForm, formYieldAdditive => {
    const product = formYieldAdditive.productCode && products[formYieldAdditive.productCode];
    if (product) {
      formYieldAdditive.cost = formatNumberToTwoDecimalPlacesStringIncludeZero(
        zeroIfInvalid(product.cost)
      );
    }
  });
};

const initialYieldAdditives = (yieldAdditives, products, yieldAdditivesFromForm) => {
  const formattedYieldAdditives = _.map(yieldAdditives, yieldAdditive => {
    yieldAdditive.weight = formatNumberToTwoDecimalPlacesString(yieldAdditive.weight);
    return yieldAdditive;
  });

  const initializedYieldAdditives =
    formattedYieldAdditives && !_.isEmpty(formattedYieldAdditives) ? formattedYieldAdditives : [{}];

  if (yieldAdditivesFromForm) {
    initNewYieldAdditive(products, yieldAdditivesFromForm);
  }

  return _.isEmpty(initializedYieldAdditives[0])
    ? initializedYieldAdditives
    : initializedYieldAdditives.concat([{}]);
};

const selector = formValueSelector('createCuttingYieldModelForm');
export const additivesMapStateToPropsForYieldModelForm = state => {
  const { yieldAdditives } = state.cuttingYieldModelInfo.yieldModel;
  const products = state.productDuplicate.products ? state.productDuplicate.products : {};
  const productsExist = state.productDuplicate.productsExist || {};
  const formYieldAdditives = selector(state, 'yieldAdditives');
  const initYieldAdditives = initialYieldAdditives(yieldAdditives, products, formYieldAdditives);

  return {
    initialValues: {
      yieldAdditives: initYieldAdditives
    },
    products,
    productsExist
  };
};

AdditiveTableComponent.propTypes = {
  fields: PropTypes.object.isRequired,
  meta: PropTypes.object.isRequired,
  message: PropTypes.string,
  getProduct: PropTypes.func,
  setProductExistTo: PropTypes.func,
  productsExist: PropTypes.object.isRequired,
  products: PropTypes.object.isRequired,
  setAdditiveSourceItem: PropTypes.func
};

const mapDispatchToProps = dispatch =>
  bindActionCreators(
    {
      getProduct,
      setProductExistTo,
      setAdditiveSourceItem
    },
    dispatch
  );

const AdditiveTable = connect(
  null,
  mapDispatchToProps
)(AdditiveTableComponent);

export default AdditiveTable;
