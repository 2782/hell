import Validator, {
  validateFieldArray,
  validateSubmission
} from '../grindingYieldModelFormValidator';

describe('submission validation', () => {
  let props;

  beforeEach(() => {
    props = {
      products: {
        ['0204002']: {},
        ['0204001']: {
          cost: 21.0
        },
        ['0204000']: {
          cost: 21.0
        },
        ['0078889']: {
          cost: 22.0
        }
      }
    };
  });

  test('should validate successfully when all the fields are present', () => {
    validateSubmission(
      {
        blend: 'Natural',
        pricingModel: false,
        sourceProducts: [
          { code: '0204000', blendPercentage: '100.00' },
          { code: '', blendPercentage: '' }
        ]
      },
      props
    );
  });

  test('should fail if cost is missing for an item', () => {
    try {
      validateSubmission(
        {
          blend: 'Natural',
          pricingModel: false,
          sourceProducts: [
            { code: '0204002', blendPercentage: '100.00' },
            { code: '', blendPercentage: '' }
          ]
        },
        props
      );
    } catch ({ errors }) {
      jestExpect(errors.sourceProducts[0].code).toEqual('Item does not have a cost');
      jestExpect(errors._error).toEqual('Submission Failed!');
      return;
    }
    throw new Error('Expected SubmissionError to be thrown.');
  });

  test('should check that source products are unique when present', () => {
    try {
      validateSubmission(
        {
          sourceProducts: [
            { code: '0204000', blendPercentage: '50.00' },
            { code: '0204000', blendPercentage: '50.00' },
            { code: '', blendPercentage: '' }
          ]
        },
        props
      );
    } catch ({ errors }) {
      jestExpect(errors.sourceProducts[0].code).toEqual('Source is already listed');
      jestExpect(errors.sourceProducts[1].code).toEqual('Source is already listed');
      jestExpect(errors._error).toEqual('Submission Failed!');
      return;
    }
    throw new Error('Expected SubmissionError to be thrown.');
  });

  test('should check that at least one fully filled out sourceProduct is present', () => {
    try {
      validateSubmission(
        {
          sourceProducts: [{ code: '', blendPercentage: '' }]
        },
        props
      );
    } catch ({ errors }) {
      jestExpect(errors.sourceProducts[0].code).toEqual('Required');
      jestExpect(errors.sourceProducts[0].blendPercentage).toEqual('Required');
      jestExpect(errors._error).toEqual('Submission Failed!');
      return;
    }

    throw new Error('Expected SubmissionError to be thrown.');
  });

  test('should not error when at least one partially filled out sourceProduct exists', () => {
    try {
      validateSubmission(
        {
          sourceProducts: [
            { code: '0078889', blendPercentage: '' },
            { code: '', blendPercentage: '20%' },
            { code: '', blendPercentage: '' }
          ]
        },
        props
      );
    } catch ({ errors }) {
      jestExpect(errors.sourceProducts.length).toEqual(2);
      jestExpect(errors.sourceProducts[0].blendPercentage).toEqual('Required');
      jestExpect(errors.sourceProducts[1].code).toEqual('Required');
      jestExpect(errors._error).toEqual('Submission Failed!');
      return;
    }

    throw new Error('Expected SubmissionError to be thrown.');
  });

  test('should throw error when source products blend percentage does not sum to 100%', () => {
    try {
      validateSubmission(
        {
          blend: 'Natural',
          pricingModel: false,
          sourceProducts: [
            { code: '0204000', blendPercentage: '40.0' },
            { code: '0204001', blendPercentage: '20.0' },
            { code: '', blendPercentage: '' }
          ]
        },
        props
      );
    } catch ({ errors }) {
      jestExpect(errors.sourceProducts[0]).toEqual({});
      jestExpect(errors.sourceProducts[1].blendPercentage).toEqual('Source blend % is invalid');
      jestExpect(errors._error).toEqual('Submission Failed!');
      return;
    }
    throw new Error('Expected SubmissionError to be thrown.');
  });

  test('should check all required field are present', () => {
    try {
      validateSubmission({}, props);
    } catch ({ errors }) {
      jestExpect(errors.pricingModel).toEqual('Required');
      jestExpect(errors.blend).toEqual('Required');
      jestExpect(errors.sourceProducts[0].code).toEqual('Required');
      jestExpect(errors.sourceProducts[0].blendPercentage).toEqual('Required');
      jestExpect(errors._error).toEqual('Submission Failed!');
      return;
    }
    throw new Error('Expected SubmissionError to be thrown.');
  });

  test('should throw submission error when blend name is invalid', () => {
    const errorResponse = {
      error: {
        details: [
          {
            field: 'blend',
            value: 'Fast furious',
            issue: 'NOT_EXIST',
            location: 'body',
            type: 'field'
          }
        ]
      }
    };

    try {
      Validator.processErrorResponse(errorResponse);
    } catch ({ errors }) {
      jestExpect(errors.blend).toEqual('Invalid Blend Name');
      jestExpect(errors._error).toEqual('Submission Failed!');
    }
  });

  test('should throw submission error when grinding yield model is not unique', () => {
    const errorResponse = {
      error: {
        details: [
          {
            field: 'grinding yield model',
            value: null,
            issue: 'UNIQUE',
            location: 'body',
            type: null
          }
        ]
      }
    };

    try {
      Validator.processErrorResponse(errorResponse);
    } catch ({ errors }) {
      jestExpect(errors.blend).toEqual('Model already exists');
      jestExpect(errors._error).toEqual('Submission Failed!');
    }
  });

  describe('Source products validation', () => {
    test('should not complain when everything is fine', () => {
      const errors = validateFieldArray(
        {},
        [{ code: '0204000', blendPercentage: '100.00' }],
        props
      );

      jestExpect(errors).toEqual({ sourceProducts: [{}] });
    });

    test('should complain when product code is missing', () => {
      const errors = validateFieldArray({}, [{ code: '', blendPercentage: '100.00' }], props);

      jestExpect(errors).toEqual({ sourceProducts: [{ code: 'Required' }] });
    });

    test('should complain when blend percentage is missing', () => {
      const errors = validateFieldArray({}, [{ code: '0204000', blendPercentage: '' }], props);

      jestExpect(errors).toEqual({ sourceProducts: [{ blendPercentage: 'Required' }] });
    });

    test('should ignore empty rows', () => {
      const errors = validateFieldArray(
        {},
        [{}, { code: '0204000', blendPercentage: '100.00' }],
        props
      );

      jestExpect(errors).toEqual({ sourceProducts: [{}] });
    });

    test('should not show blend percentage error when onBlur is called', () => {
      const errors = validateFieldArray(
        {},
        [
          {
            code: '0204000',
            blendPercentage: '10.00'
          },
          {
            code: '0204001',
            blendPercentage: '100.00'
          },
          {}
        ],
        props,
        'onBlur'
      );

      jestExpect(errors).toEqual({
        sourceProducts: [{}, {}]
      });
    });

    test('should position error on last filled in row when blend percentage is not 100%', () => {
      const errors = validateFieldArray(
        {},
        [
          {
            code: '0204000',
            blendPercentage: '10.00'
          },
          {
            code: '0204001',
            blendPercentage: '100.00'
          },
          {}
        ],
        props,
        'onSubmit'
      );

      jestExpect(errors).toEqual({
        sourceProducts: [
          {},
          {
            blendPercentage: 'Source blend % is invalid'
          }
        ]
      });
    });
  });
});
