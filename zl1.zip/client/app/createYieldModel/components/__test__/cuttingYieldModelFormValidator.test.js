import Validator from '../cuttingYieldModelFormValidator';
import { BYPRODUCT_ONLY_PRODUCT, NOT_A_PRODUCTION_PRODUCT } from '../../../../config/errorMessage';

describe('yieldModelFormValidator', () => {
  const VALID_FINISHED_PRODUCT_CODE = '0678545';
  const VALID_SOURCE_PRODUCT_CODE = '0076676';
  const VALID_LABOR = '1.42';
  const VALID_ADDITIVES = '7.8';
  const VALID_IS_PRICING_MODEL = true;

  describe('submission validation', () => {
    test('should call submit with given values', () => {
      const values = {
        finishedProductCode: VALID_FINISHED_PRODUCT_CODE,
        sourceProductCode: VALID_SOURCE_PRODUCT_CODE,
        labor: VALID_LABOR,
        additives: VALID_ADDITIVES,
        pricingModel: VALID_IS_PRICING_MODEL,
        pickupPercent: '',
        yieldByproducts: [
          { byproductCode: '0078889', yieldPercentage: '40' },
          { byproductCode: '0079007', yieldPercentage: '50' }
        ]
      };

      Validator.validateSubmission(values, {
        finishedProductExists: true,
        sourceProductExists: true,
        finishedProductIsProduction: true
      });
    });

    test('should check that all fields are required', () => {
      try {
        Validator.validateSubmission({}, {});
        fail('Expected SubmissionError to be thrown.');
      } catch ({ errors }) {
        jestExpect(errors).toEqual({
          finishedProductCode: 'Required',
          sourceProductCode: 'Required',
          _error: 'Submission Failed!'
        });
      }
    });

    test('should validate that yield and source product code are wholeNumber', () => {
      const values = {
        finishedProductCode: 'abc123',
        sourceProductCode: '#adf00123.1'
      };

      try {
        Validator.validateSubmission(values, {});
        fail('Expected SubmissionError to be thrown.');
      } catch ({ errors }) {
        jestExpect(errors).toEqual({
          finishedProductCode: 'Only whole number characters',
          sourceProductCode: 'Only whole number characters',
          _error: 'Submission Failed!'
        });
      }
    });

    test('should validate that yield and source product code are exactly 7 characters', () => {
      const values = {
        finishedProductCode: '0123123123',
        sourceProductCode: '01231'
      };

      try {
        Validator.validateSubmission(values, {
          finishedProductExists: true,
          sourceProductExists: true,
          finishedProductIsProduction: true
        });
        fail('Expected SubmissionError to be thrown.');
      } catch ({ errors }) {
        jestExpect(errors).toEqual({
          finishedProductCode: 'Must be 7 characters',
          sourceProductCode: 'Must be 7 characters',
          _error: 'Submission Failed!'
        });
      }
    });

    test('should allow pickup percent less than 100 ', () => {
      const values = {
        finishedProductCode: VALID_FINISHED_PRODUCT_CODE,
        sourceProductCode: VALID_SOURCE_PRODUCT_CODE,
        pickupPercent: '99.99'
      };

      Validator.validateSubmission(values, {
        finishedProductExists: true,
        sourceProductExists: true,
        finishedProductIsProduction: true
      });
    });

    test('should validate pickup percent is less than 0', () => {
      const values = {
        finishedProductCode: VALID_FINISHED_PRODUCT_CODE,
        sourceProductCode: VALID_SOURCE_PRODUCT_CODE,
        pickupPercent: '-1'
      };

      try {
        Validator.validateSubmission(values, {
          finishedProductExists: true,
          sourceProductExists: true,
          finishedProductIsProduction: true
        });
        fail('Expected SubmissionError to be thrown.');
      } catch ({ errors }) {
        jestExpect(errors).toEqual({
          pickupPercent: 'Pickup % is invalid',
          _error: 'Submission Failed!'
        });
      }
    });

    test('should not allow pickup percent of 100', () => {
      const values = {
        finishedProductCode: VALID_FINISHED_PRODUCT_CODE,
        sourceProductCode: VALID_SOURCE_PRODUCT_CODE,
        pickupPercent: '100'
      };

      try {
        Validator.validateSubmission(values, {
          finishedProductExists: true,
          sourceProductExists: true,
          finishedProductIsProduction: true
        });
        fail('Expected SubmissionError to be thrown.');
      } catch ({ errors }) {
        jestExpect(errors).toEqual({
          pickupPercent: 'Pickup % is invalid',
          _error: 'Submission Failed!'
        });
      }
    });

    test('should validate that labor, and additives are numbers', () => {
      const values = {
        labor: 'ab',
        additives: 'FDFd'
      };

      try {
        Validator.validateSubmission(values, {});
        fail('Expected SubmissionError to be thrown.');
      } catch ({ errors }) {
        jestExpect(errors).toMatchObject({
          labor: 'Must be a number',
          additives: 'Must be a number',
          _error: 'Submission Failed!'
        });
      }
    });

    test('should validate that finished product cost greater than 0 when it is small than 0', () => {
      try {
        Validator.validateSubmission({}, { finishedProductCost: -12 });
        fail('Expected SubmissionError to be thrown.');
      } catch ({ errors }) {
        jestExpect(errors).toMatchObject({
          finishedProductCost: 'Must be a positive number',
          _error: 'Submission Failed!'
        });
      }
    });

    test('should validate that finished product cost greater than 0 when it is equal 0', () => {
      try {
        Validator.validateSubmission({}, { finishedProductCost: 0 });
        fail('Expected SubmissionError to be thrown.');
      } catch ({ errors }) {
        jestExpect(errors).toMatchObject({
          finishedProductCost: 'Must be a positive number',
          _error: 'Submission Failed!'
        });
      }
    });

    test('should validate that by product value greater equal than 0 when it is small than 0', () => {
      try {
        Validator.validateSubmission({}, { byproductValue: -12 });
        fail('Expected SubmissionError to be thrown.');
      } catch ({ errors }) {
        jestExpect(errors).toMatchObject({
          byproductValue: 'Must be greater than 0',
          _error: 'Submission Failed!'
        });
      }
    });

    test('should validate that product codes are not the same', () => {
      const values = {
        finishedProductCode: '0078889',
        sourceProductCode: '0078889'
      };

      try {
        Validator.validateSubmission(values, {
          finishedProductExists: true,
          sourceProductExists: true,
          finishedProductIsProduction: true
        });
        fail('Expected SubmissionError to be thrown.');
      } catch ({ errors }) {
        jestExpect(errors).toEqual({
          sourceProductCode: 'Source cannot be the same as Finished product',
          _error: 'Submission Failed!'
        });
      }
    });

    test('should validate that finished product is a production product', () => {
      const values = {
        finishedProductCode: '0078889',
        sourceProductCode: '0078891'
      };

      try {
        Validator.validateSubmission(values, {
          finishedProductExists: true,
          sourceProductExists: true,
          productOutput: 'SOURCE'
        });
        fail('Expected SubmissionError to be thrown.');
      } catch ({ errors }) {
        jestExpect(errors).toEqual({
          finishedProductCode: NOT_A_PRODUCTION_PRODUCT,
          _error: 'Submission Failed!'
        });
      }
    });

    test('should validate that finished product is a byproduct only product', () => {
      const values = {
        finishedProductCode: '0078889',
        sourceProductCode: '0078891'
      };

      try {
        Validator.validateSubmission(values, {
          finishedProductExists: true,
          sourceProductExists: true,
          productOutput: 'BYPRODUCT_ONLY'
        });
        jest.fail('Expected SubmissionError to be thrown.');
      } catch ({ errors }) {
        jestExpect(errors).toEqual({
          finishedProductCode: BYPRODUCT_ONLY_PRODUCT,
          _error: 'Submission Failed!'
        });
      }
    });
  });

  describe('form validation', () => {
    describe('byproducts', () => {
      test('should show error message in last row', () => {
        const yieldByproducts = [
          { byproductCode: '0078889', yieldPercentage: '85' },
          { byproductCode: '0079007', yieldPercentage: '50' }
        ];
        const errors = Validator.positionYieldPercentageErrorOnLastFilledInRow(yieldByproducts);
        jestExpect(errors).toEqual([{}, { yieldPercentage: 'Yield % is invalid' }]);
      });

      test('should validate yieldByproducts percentage total less than 100', () => {
        const values = {
          finishedProductCode: '0214101',
          sourceProductCode: '0078889',
          yieldByproducts: [
            { byproductCode: '0078888', yieldPercentage: '50' },
            { byproductCode: '0079007', yieldPercentage: '50' }
          ]
        };
        const errors = Validator.validateFields(values);
        jestExpect(errors.yieldByproducts).toEqual([{}, { yieldPercentage: 'Yield % is invalid' }]);
      });

      test('should not validate yieldByproducts without a byproduct code', () => {
        const values = {
          finishedProductCode: '0214101',
          sourceProductCode: '0078889',
          yieldByproducts: [{ yieldPercentage: '' }]
        };
        const errors = Validator.validateFields(values);
        jestExpect(errors).toEqual({});
      });

      test('should validate yieldByproducts product code is required with yield percentage ', () => {
        const values = {
          finishedProductCode: '0214101',
          sourceProductCode: '0078889',
          yieldByproducts: [{ yieldPercentage: '12' }]
        };
        const errors = Validator.validateFields(values);
        jestExpect(errors).toEqual({ yieldByproducts: [{ byproductCode: 'Required' }] });
      });

      test('should validate yieldByproducts product code is required with cost ', () => {
        const values = {
          finishedProductCode: '0214101',
          sourceProductCode: '0078889',
          yieldByproducts: [{ cost: '12' }]
        };
        const errors = Validator.validateFields(values);
        jestExpect(errors).toEqual({ yieldByproducts: [{ byproductCode: 'Required' }] });
      });

      test('should validate yieldByproducts product code is required with labor ', () => {
        const values = {
          finishedProductCode: '0214101',
          sourceProductCode: '0078889',
          yieldByproducts: [{ labor: '12' }]
        };
        const errors = Validator.validateFields(values);
        jestExpect(errors).toEqual({ yieldByproducts: [{ byproductCode: 'Required' }] });
      });

      test('should validate yieldByproducts byproduct is not same with finished product code', () => {
        const values = {
          finishedProductCode: '0079007',
          sourceProductCode: '0078889',
          yieldByproducts: [{ byproductCode: '0079007', yieldPercentage: '10' }]
        };
        const errors = Validator.validateFields(values);
        jestExpect(errors.yieldByproducts[0]).toEqual({
          byproductCode: 'Duplicate item number.'
        });
      });

      test('should validate yieldByproducts byproduct is not same with source product code', () => {
        const values = {
          finishedProductCode: '0079007',
          sourceProductCode: '0078889',
          yieldByproducts: [{ byproductCode: '0078889', yieldPercentage: '10' }]
        };
        const errors = Validator.validateFields(values);
        jestExpect(errors.yieldByproducts[0]).toEqual({
          byproductCode: 'Duplicate item number.'
        });
      });

      test('should validate yieldByproducts percentage is between 0 and 100', () => {
        const values = {
          finishedProductCode: '0214101',
          sourceProductCode: '0078889',
          yieldByproducts: [
            { byproductCode: '0079007', yieldPercentage: '10' },
            { byproductCode: '0068205', yieldPercentage: '-1' }
          ]
        };
        const errors = Validator.validateFields(values);
        jestExpect(errors.yieldByproducts[1]).toEqual({ yieldPercentage: 'Yield % is invalid' });
      });

      test('should validate byproduct should unique', () => {
        const values = {
          finishedProductCode: '0214101',
          sourceProductCode: '0078889',
          yieldByproducts: [
            { byproductCode: '0079001', yieldPercentage: '10' },
            { byproductCode: '0079002', yieldPercentage: '10' },
            { byproductCode: '0079003', yieldPercentage: '10' },
            { byproductCode: '0079002', yieldPercentage: '10' },
            { byproductCode: '0079005', yieldPercentage: '1' }
          ]
        };
        const errors = Validator.validateFields(values);
        jestExpect(errors.yieldByproducts[1]).toEqual({
          byproductCode: 'Byproduct is already listed.'
        });
        jestExpect(errors.yieldByproducts[3]).toEqual({
          byproductCode: 'Byproduct is already listed.'
        });
      });
    });

    describe('additives', () => {
      test('should not validate yieldAdditives without a product code', () => {
        const values = {
          yieldAdditives: [{ weight: '' }]
        };
        const errors = Validator.validateFields(values);
        jestExpect(errors).toEqual({});
      });

      test('should validate yieldAdditives product code is required with weight', () => {
        const values = {
          yieldAdditives: [{ weight: '12' }]
        };
        const errors = Validator.validateFields(values);
        jestExpect(errors).toEqual({ yieldAdditives: [{ productCode: 'Required' }] });
      });

      test('should validate yieldAdditives weight is greater than 0', () => {
        const values = {
          yieldAdditives: [
            { productCode: '0079006', weight: '' },
            { productCode: '0079007', weight: '10' },
            { productCode: '0068205', weight: '0' },
            { productCode: '0068206', weight: '-1' }
          ]
        };
        const errors = Validator.validateFields(values);
        jestExpect(errors.yieldAdditives[0]).toEqual({ weight: 'Required' });
        jestExpect(errors.yieldAdditives[1]).toEqual({});
        jestExpect(errors.yieldAdditives[2]).toEqual({ weight: 'Invalid quantity' });
        jestExpect(errors.yieldAdditives[3]).toEqual({ weight: 'Invalid quantity' });
      });

      test('should validate yieldAdditives can not be duplicated', () => {
        const values = {
          yieldAdditives: [
            { productCode: '0079006', weight: '2' },
            { productCode: '0079007', weight: '10' },
            { productCode: '0079006', weight: '3' }
          ]
        };
        const errors = Validator.validateFields(values);
        jestExpect(errors.yieldAdditives[0]).toEqual({
          productCode: 'Additive is already listed.'
        });
        jestExpect(errors.yieldAdditives[1]).toEqual({});
        jestExpect(errors.yieldAdditives[2]).toEqual({
          productCode: 'Additive is already listed.'
        });
      });

      test('should validate byProducts and yieldAdditives can not be duplicated', () => {
        const values = {
          yieldAdditives: [
            { productCode: '0079006', weight: '2' },
            { productCode: '0079007', weight: '10' }
          ],
          yieldByproducts: [
            { byproductCode: '0079007', yieldPercentage: '10' },
            { byproductCode: '0079001', yieldPercentage: '10' }
          ]
        };
        const errors = Validator.validateFields(values);
        jestExpect(errors.yieldAdditives[0]).toEqual({});
        jestExpect(errors.yieldAdditives[1]).toEqual({
          productCode: 'Duplicate item number.'
        });

        jestExpect(errors.yieldByproducts[0]).toEqual({
          byproductCode: 'Duplicate item number.'
        });
        jestExpect(errors.yieldByproducts[1]).toEqual({});
      });

      test('should validate yieldAdditives can not be the same as finished product', () => {
        const values = {
          finishedProductCode: '0079006',
          sourceProductCode: '0079007',
          yieldAdditives: [{ productCode: '0079006', weight: '2' }]
        };
        const errors = Validator.validateFields(values);
        jestExpect(errors.yieldAdditives[0]).toEqual({ productCode: 'Duplicate item number.' });
      });

      test('should validate yieldAdditives can not be the same as source product', () => {
        const values = {
          finishedProductCode: '0079007',
          sourceProductCode: '0079006',
          yieldAdditives: [{ productCode: '0079006', weight: '2' }]
        };
        const errors = Validator.validateFields(values);
        jestExpect(errors.yieldAdditives[0]).toEqual({ productCode: 'Duplicate item number.' });
      });
    });

    describe('sourceLbs', () => {
      test('should validate source Lbs Required when yieldAdditives exist', () => {
        const values = {
          yieldAdditives: [{ productCode: '0079006', weight: '12' }]
        };
        const errors = Validator.validateFields(values);

        jestExpect(errors.sourceLbs).toEqual('Required');
      });

      test('should validate source Lbs optional when yieldAdditives not exist', () => {
        const values = {
          yieldAdditives: []
        };
        const errors = Validator.validateFields(values);

        jestExpect(errors.sourceLbs).toEqual(undefined);
      });

      test('should validate source Lbs valid when given valid value', () => {
        const values = {
          yieldAdditives: [{ productCode: '0079006', weight: '12' }],
          sourceLbs: '20'
        };
        const errors = Validator.validateFields(values);

        jestExpect(errors.sourceLbs).toEqual(undefined);
      });

      test('should validate source Lbs valid when greater than sum of Additives', () => {
        const values = {
          yieldAdditives: [
            { productCode: '0079006', weight: '12' },
            { productCode: '0079007', weight: '15' }
          ],
          sourceLbs: '20'
        };
        const errors = Validator.validateFields(values);

        jestExpect(errors.sourceLbs).toEqual('Invalid quantity');
      });

      test('should validate source Lbs invalid when less than sum of Additives', () => {
        const values = {
          yieldAdditives: [
            { productCode: '0079006', weight: '12' },
            { productCode: '0079007', weight: '5' }
          ],
          sourceLbs: '20'
        };
        const errors = Validator.validateFields(values);

        jestExpect(errors.sourceLbs).toEqual(undefined);
      });

      test('should validate source Lbs invalid when given invalid value', () => {
        const values = {
          yieldAdditives: [{ productCode: '0079006', weight: '12' }],
          sourceLbs: '-20'
        };
        const errors = Validator.validateFields(values);

        jestExpect(errors.sourceLbs).toEqual('Invalid quantity');

        const values1 = {
          yieldAdditives: [{ productCode: '0079006', weight: '12' }],
          sourceLbs: '0'
        };
        const errors1 = Validator.validateFields(values1);

        jestExpect(errors1.sourceLbs).toEqual('Invalid quantity');

        const values2 = {
          yieldAdditives: [{ productCode: '0079006', weight: '12' }],
          sourceLbs: '12.89'
        };
        const errors2 = Validator.validateFields(values2);

        jestExpect(errors2.sourceLbs).toEqual('Invalid quantity');
      });
    });
  });

  describe('process error response from API', () => {
    test('throws a SubmissionError for finishedProduct is not a production item', () => {
      const values = {
        finishedProductCode: '0078889',
        sourceProductCode: '0078889',
        yieldByproducts: [{ byproductCode: '0079001', yieldPercentage: '10' }]
      };
      const errorResponse = {
        error: {
          details: [
            {
              issue: 'PRODUCT_IS_NOT_PRODUCTION_ITEM',
              field: 'finishedProductCode',
              value: '0078889'
            }
          ]
        }
      };

      try {
        Validator.processErrorResponse(errorResponse, values);
        fail('Expected SubmissionError to be thrown.');
      } catch ({ errors }) {
        jestExpect(errors.finishedProductCode).toEqual(
          'Not a production item. Cannot create yield model for this product'
        );
      }
    });

    test('throws a SubmissionError for finishedProduct is byproduct only item', () => {
      const values = {
        finishedProductCode: '0078889',
        sourceProductCode: '0078889',
        yieldByproducts: [{ byproductCode: '0079001', yieldPercentage: '10' }]
      };
      const errorResponse = {
        error: {
          details: [
            {
              issue: 'PRODUCT_IS_BYPRODUCT_ONLY_ITEM',
              field: 'finishedProductCode',
              value: '0078889'
            }
          ]
        }
      };

      try {
        Validator.processErrorResponse(errorResponse, values);
        fail('Expected SubmissionError to be thrown.');
      } catch ({ errors }) {
        jestExpect(errors.finishedProductCode).toEqual(
          'Byproduct only items cannot have pricing model.'
        );
      }
    });

    test('throws a SubmissionError for not known response', () => {
      const values = {
        finishedProductCode: '0078889',
        sourceProductCode: '0078889',
        yieldByproducts: [{ byproductCode: '0079001', yieldPercentage: '10' }]
      };
      const errorResponse = {
        error: {
          details: [
            {
              issue: 'ANOTHER_ISSUE',
              field: 'finishedProductCode',
              value: '0078889'
            }
          ]
        }
      };

      try {
        Validator.processErrorResponse(errorResponse, values);
        fail('Expected SubmissionError to be thrown.');
      } catch ({ errors }) {
        jestExpect(errors).toEqual({
          _error: 'Cannot create yield model for this product.',
          yieldByproducts: [{}]
        });
      }
    });

    test('throws a SubmissionError for byproduct code does not exist', () => {
      const values = {
        finishedProductCode: '0078889',
        sourceProductCode: '0068205',
        yieldByproducts: [
          { byproductCode: '0022222', yieldPercentage: '10' },
          { byproductCode: '0204000', yieldPercentage: '5' }
        ]
      };
      const errorResponse = {
        error: {
          details: [
            {
              field: 'yieldByproducts[0].byproductCode',
              value: '0022222',
              issue: 'NOT_EXIST',
              location: 'body'
            }
          ]
        }
      };
      try {
        Validator.processErrorResponse(errorResponse, values);
        fail('Expected SubmissionError to be thrown.');
      } catch ({ errors }) {
        jestExpect(errors.yieldByproducts[0]).toEqual({ byproductCode: 'Product does not exist.' });
      }
    });

    test('throws a SubmissionError for byproduct code that is not production item', () => {
      const values = {
        finishedProductCode: '0078889',
        sourceProductCode: '0068205',
        yieldByproducts: [
          { byproductCode: '0022222', yieldPercentage: '10' },
          { byproductCode: '0204000', yieldPercentage: '5' }
        ]
      };
      const errorResponse = {
        error: {
          details: [
            {
              field: 'yieldByproducts[0].byproductCode',
              value: '0022222',
              issue: 'PRODUCT_IS_NOT_PRODUCTION_ITEM',
              location: 'body'
            }
          ]
        }
      };
      try {
        Validator.processErrorResponse(errorResponse, values);
        fail('Expected SubmissionError to be thrown.');
      } catch ({ errors }) {
        jestExpect(errors.yieldByproducts[0]).toEqual({ byproductCode: 'Must be produced item.' });
      }
    });

    test('throws a SubmissionError for finishedProduct if its already in a product group', () => {
      const values = {
        finishedProductCode: '0078889',
        sourceProductCode: '0078889',
        yieldByproducts: [{ byproductCode: '0079001', yieldPercentage: '10' }]
      };
      const errorResponse = {
        error: {
          details: [
            {
              issue: 'IN_PRODUCT_GROUP',
              field: 'finishedProductCode',
              value: '0078889'
            }
          ]
        }
      };

      try {
        Validator.processErrorResponse(errorResponse, values);
        fail('Expected SubmissionError to be thrown.');
      } catch ({ errors }) {
        jestExpect(errors.finishedProductCode).toEqual(
          'N/A. Finished product is part of Yield Model Product Group'
        );
      }
    });

    test('throws a Submission error for both a finishedProduct', () => {
      const values = {
        finishedProductCode: '0204000',
        sourceProductCode: '0078889',
        yieldByproducts: [
          {
            byproductCode: '0068205',
            yieldPercentage: '5.0'
          },
          {
            byproductCode: '0204001',
            yieldPercentage: '10.0'
          }
        ]
      };

      const errorResponse = {
        error: {
          details: [
            {
              issue: 'PRODUCT_IS_NOT_PRODUCTION_ITEM',
              field: 'finishedProductCode',
              value: '0204000'
            }
          ]
        }
      };

      try {
        Validator.processErrorResponse(errorResponse, values);
        fail('Expected SubmissionError to be thrown.');
      } catch ({ errors }) {
        jestExpect(errors.finishedProductCode).toEqual(
          'Not a production item. Cannot create yield model for this product'
        );
      }
    });

    test('throws a Submission error for finishedProductCost error', () => {
      const values = {
        finishedProductCode: '0204000',
        sourceProductCode: '0078889',
        yieldByproducts: [
          {
            byproductCode: '0068205',
            yieldPercentage: '5.0'
          },
          {
            byproductCode: '0204001',
            yieldPercentage: '10.0'
          }
        ]
      };

      const errorResponse = {
        error: {
          details: [
            {
              field: 'finishedProductCost',
              issue: 'must be greater than 0.00',
              value: '-10'
            }
          ]
        }
      };

      try {
        Validator.processErrorResponse(errorResponse, values);
        fail('Expected SubmissionError to be thrown.');
      } catch ({ errors }) {
        jestExpect(errors.finishedProductCost).toEqual('must be greater than 0.00');
      }
    });
  });

  describe('Source product cost validation', () => {
    test('should have sourceProductCode warning', () => {
      jestExpect(
        Validator.validateSourceProduct({
          sourceProductCode: '0079007',
          productsDuplicate: {
            '0079007': {}
          }
        })
      ).toEqual('Source product does not have a cost');
    });

    test('should have Source cannot be the same as Finished product warning', () => {
      jestExpect(
        Validator.validateSourceProduct({
          sourceProductCode: '0079007',
          finishedProductCode: '0079007'
        })
      ).toEqual('Source cannot be the same as Finished product');
    });

    test('should not have sourceProductCode warning when source product cost exist', () => {
      jestExpect(
        Validator.validateSourceProduct({
          sourceProductCode: '0079007',
          productsDuplicate: {
            '0079007': {}
          },
          sourceProductCost: 15.01
        })
      ).toBeUndefined();
    });

    test('should not have sourceProductCode warning when sourceProduct does not exist', () => {
      jestExpect(
        Validator.validateSourceProduct({
          sourceProductCode: '0079007',
          productsDuplicate: {
            notASourceProductCode: {}
          }
        })
      ).toBeUndefined();
    });
  });
});
