import React from 'react';
import { mount } from 'enzyme';
import { reduxForm } from 'redux-form';
import { Provider } from 'react-redux';
import { createReduxStore } from '../../../store';
import FinishedProductYieldTestCompareTable from '../FinishedProductYieldTestCompareTable';

describe('finishedProductYeildTestCompareTable', () => {
  let wrapper,
    Decorated,
    store,
    estimatedYield,
    finishedProductCost,
    actualYieldPercent,
    actualUnitCostPerLb,
    OneYearYieldTestList,
    lastDate;

  beforeEach(() => {
    estimatedYield = 76.76;
    finishedProductCost = 17.23;
    actualYieldPercent = 82.6;
    actualUnitCostPerLb = 15.6;
    OneYearYieldTestList = [
      {
        createdat: '02/06/2018'
      },
      {
        createdat: '02/06/2019'
      }
    ];
    lastDate = '20/06/2019';
    Decorated = reduxForm({ form: 'testForm' })(FinishedProductYieldTestCompareTable);
    store = createReduxStore({
      cuttingYieldModelInfo: {}
    });

    wrapper = mount(
      <Provider store={store}>
        <Decorated
          estimatedYield={estimatedYield}
          finishedProductCost={finishedProductCost}
          actualYieldPercent={actualYieldPercent}
          actualUnitCostPerLb={actualUnitCostPerLb}
          OneYearYieldTestList={OneYearYieldTestList}
          lastDate={lastDate}
        />
      </Provider>
    );
  });

  test('Yield Test Comparison - 12 Month Average should show', () => {
    const comparison = wrapper.find('[pid="yield-tests-comparison"]');
    jestExpect(comparison.at(0)).toHaveText('Yield Test Comparison - 12 Month Average');
  });

  test('should set value in table', () => {
    const tableHeader = wrapper.find('TableHeader');
    jestExpect(tableHeader).toExist();
    jestExpect(tableHeader.find('TableHeaderCell')).toHaveLength(3);
    jestExpect(tableHeader.find('TableHeaderCell').at(0)).toHaveText('');
    jestExpect(tableHeader.find('TableHeaderCell').at(1)).toHaveText('YIELDPERCENT');
    jestExpect(tableHeader.find('TableHeaderCell').at(2)).toHaveText('UNIT COSTPER LB');

    const tableBody = wrapper.find('TableBody');
    jestExpect(tableBody.find('TableRow')).toHaveLength(3);

    const row1 = tableBody.find('TableRow').at(0);
    jestExpect(row1.find('TableCell').at(0)).toHaveText('MODEL');
    jestExpect(row1.find('TableCell').at(1)).toHaveText('76.76');
    jestExpect(row1.find('TableCell').at(2)).toHaveText('17.23');

    const row2 = tableBody.find('TableRow').at(1);
    jestExpect(row2.find('TableCell').at(0)).toHaveText('YIELD TEST AVERAGE');
    jestExpect(row2.find('TableCell').at(1)).toHaveText('82.60');
    jestExpect(row2.find('TableCell').at(2)).toHaveText('15.60');

    const row3 = tableBody.find('TableRow').at(2);
    jestExpect(row3.find('TableCell').at(0)).toHaveText('VARIANCE');
    jestExpect(row3.find('TableCell').at(1)).toHaveText('5.84');
    jestExpect(row3.find('TableCell').at(2)).toHaveText('1.63');
  });

  test('percent and cost same, variance should be 0', () => {
    estimatedYield = 76.76;
    finishedProductCost = 17.23;
    actualYieldPercent = 76.76;
    actualUnitCostPerLb = 17.23;

    wrapper = mount(
      <Provider store={store}>
        <Decorated
          estimatedYield={estimatedYield}
          finishedProductCost={finishedProductCost}
          actualYieldPercent={actualYieldPercent}
          actualUnitCostPerLb={actualUnitCostPerLb}
          OneYearYieldTestList={OneYearYieldTestList}
          lastDate={lastDate}
        />
      </Provider>
    );

    const tableHeader = wrapper.find('TableHeader');
    jestExpect(tableHeader).toExist();
    jestExpect(tableHeader.find('TableHeaderCell')).toHaveLength(3);
    jestExpect(tableHeader.find('TableHeaderCell').at(0)).toHaveText('');
    jestExpect(tableHeader.find('TableHeaderCell').at(1)).toHaveText('YIELDPERCENT');
    jestExpect(tableHeader.find('TableHeaderCell').at(2)).toHaveText('UNIT COSTPER LB');

    const tableBody = wrapper.find('TableBody');
    jestExpect(tableBody.find('TableRow')).toHaveLength(3);

    const row1 = tableBody.find('TableRow').at(0);
    jestExpect(row1.find('TableCell').at(0)).toHaveText('MODEL');
    jestExpect(row1.find('TableCell').at(1)).toHaveText('76.76');
    jestExpect(row1.find('TableCell').at(2)).toHaveText('17.23');

    const row2 = tableBody.find('TableRow').at(1);
    jestExpect(row2.find('TableCell').at(0)).toHaveText('YIELD TEST AVERAGE');
    jestExpect(row2.find('TableCell').at(1)).toHaveText('76.76');
    jestExpect(row2.find('TableCell').at(2)).toHaveText('17.23');

    const row3 = tableBody.find('TableRow').at(2);
    jestExpect(row3.find('TableCell').at(0)).toHaveText('VARIANCE');
    jestExpect(row3.find('TableCell').at(1)).toHaveText('0.00');
    jestExpect(row3.find('TableCell').at(2)).toHaveText('0.00');
  });
});
