import React from 'react';
import PropTypes from 'prop-types';
import { mount, shallow } from 'enzyme';
import ByproductTable, {
  byproductsMapStateToPropsForYieldModelForm,
  ByproductTableComponent
} from '../ByproductTable';
import { Field, FieldArray, Form, reduxForm } from 'redux-form';
import { connect, Provider } from 'react-redux';
import store, { createReduxStore } from '../../../store';
import semanticUI from '../../../../test-helpers/semantic-ui';
import { normalizeToTwoDecimalPlaces } from '../../../shared/components/product/normalizer';
import productFactory from '../../../../test-factories/productFactory';
import { NOT_A_PRODUCT_CODE } from '../../../../config/errorMessage';

describe('byProductTable', () => {
  let wrapper,
    fields,
    fieldNames,
    Decorated,
    removeSpy,
    pushSpy,
    fieldValue,
    products,
    productsExist;

  describe('with reduxForm decoration', () => {
    class ByproductsWrapper extends React.Component {
      render() {
        const { handleSubmit, products, productsExist } = this.props;
        return (
          <Form onSubmit={handleSubmit}>
            <FieldArray
              name={'yieldByproducts'}
              component={ByproductTable}
              props={{ products, productsExist }}
            />
          </Form>
        );
      }
    }

    ByproductsWrapper.propTypes = {
      handleSubmit: PropTypes.func.isRequired,
      products: PropTypes.object.isRequired,
      productsExist: PropTypes.object.isRequired
    };

    const DecoratedByproductsWrapper = connect(byproductsMapStateToPropsForYieldModelForm)(
      reduxForm({
        form: 'createCuttingYieldModelForm'
      })(ByproductsWrapper)
    );

    beforeEach(() => {
      const byproducts = [
        {
          byproductCode: '0079006',
          byproductPercentage: '30.00',
          id: 100,
          cost: 12.8,
          labor: 29.8
        },
        {
          byproductCode: '0565109',
          byproductPercentage: '8.00',
          id: 100,
          cost: 10.38,
          labor: 1.25
        }
      ];

      const store = createReduxStore({
        productDuplicate: {
          products: {
            '0079006': productFactory.build({ code: '0079006' }),
            '0565109': productFactory.build({ code: '0565109' })
          },
          productsExist: {}
        },
        cuttingYieldModelInfo: {
          pricingModelCostsAndLabors: {
            '0079006': { productCode: '0079006', cost: true, labor: false },
            '0565109': { productCode: '0565109', cost: false, labor: true }
          },
          yieldModel: {
            yieldByproducts: byproducts
          }
        }
      });

      wrapper = mount(
        <Provider store={store}>
          <DecoratedByproductsWrapper />
        </Provider>
      );
    });

    test('should remove row for byproduct when no product code on blur', () => {
      semanticUI.changeInput(wrapper, 'yieldByproducts[0].byproductCode', '');

      jestExpect(semanticUI.doesInputExist(wrapper, 'yieldByproducts[0].byproductCode')).toEqual(
        true
      );
      jestExpect(semanticUI.getInputValue(wrapper, 'yieldByproducts[0].byproductCode')).toEqual(
        '0565109'
      );
      jestExpect(semanticUI.doesInputExist(wrapper, 'yieldByproducts[1].byproductCode')).toEqual(
        true
      );
      jestExpect(semanticUI.getInputValue(wrapper, 'yieldByproducts[1].byproductCode')).toEqual('');

      jestExpect(semanticUI.doesInputExist(wrapper, 'yieldByproducts[2].byproductCode')).toEqual(
        false
      );
    });

    test('should add row for new byproduct when on blur', () => {
      semanticUI.changeInput(wrapper, 'yieldByproducts[2].byproductCode', '0078891');
      jestExpect(semanticUI.doesInputExist(wrapper, 'yieldByproducts[0].byproductCode')).toEqual(
        true
      );
      jestExpect(semanticUI.getInputValue(wrapper, 'yieldByproducts[0].byproductCode')).toEqual(
        '0079006'
      );
      jestExpect(semanticUI.doesInputExist(wrapper, 'yieldByproducts[1].byproductCode')).toEqual(
        true
      );
      jestExpect(semanticUI.getInputValue(wrapper, 'yieldByproducts[1].byproductCode')).toEqual(
        '0565109'
      );
      jestExpect(semanticUI.doesInputExist(wrapper, 'yieldByproducts[2].byproductCode')).toEqual(
        true
      );
      jestExpect(semanticUI.getInputValue(wrapper, 'yieldByproducts[2].byproductCode')).toEqual(
        '0078891'
      );
      jestExpect(semanticUI.doesInputExist(wrapper, 'yieldByproducts[3].byproductCode')).toEqual(
        true
      );
      jestExpect(semanticUI.getInputValue(wrapper, 'yieldByproducts[3].byproductCode')).toEqual('');
    });
  });

  describe('without reduxForm decoration', () => {
    beforeEach(() => {
      removeSpy = jest.fn();
      pushSpy = jest.fn();
      fieldValue = [
        {
          byproductCode: '0078889',
          byproductPercentage: '30.00',
          id: 100,
          cost: 12.8,
          labor: 29.8
        },
        { byproductCode: '0214101', byproductPercentage: '99.99', id: 101, cost: '', labor: '' }
      ];

      products = {
        '0078889': productFactory.build({ code: '0078889' }),
        '0214101': productFactory.build({ code: '0214101' })
      };
      productsExist = {
        'yieldByproducts[0].byproductCode': true,
        'yieldByproducts[1].byproductCode': true
      };
      fieldNames = ['yieldByproducts[0]', 'yieldByproducts[1]'];
      fields = {
        getAll: () => fieldValue,
        get: index => fieldValue[index],
        map: callback => fieldNames.map((name, idx) => callback(name, idx)),
        push: pushSpy,
        forEach: callback => {
          fieldValue.forEach((field, index) => callback(field, index));
        },
        remove: removeSpy,
        length: fieldValue.length
      };
      Decorated = reduxForm({ form: 'testForm' })(ByproductTable);
      const store = createReduxStore({
        cuttingYieldModelInfo: {
          pricingModelCostsAndLabors: {
            '0078889': { productCode: '0078889', cost: true, labor: false },
            '0214101': { productCode: '0214101', cost: false, labor: true }
          }
        }
      });

      wrapper = mount(
        <Provider store={store}>
          <Decorated
            fields={fields}
            meta={{ dirty: true, invalid: true, error: 'Error Message', submitFailed: false }}
            products={products}
            productsExist={productsExist}
          />
        </Provider>
      );
    });

    test('should set initial value', () => {
      const tableHeader = wrapper.find('TableHeader');
      jestExpect(tableHeader.find('TableHeaderCell')).toHaveLength(4);
      jestExpect(tableHeader.find('TableHeaderCell').at(0)).toHaveText('BYPRODUCTS');
      jestExpect(tableHeader.find('TableHeaderCell').at(1)).toHaveText('YIELD %');
      jestExpect(tableHeader.find('TableHeaderCell').at(2)).toHaveText('COST');
      jestExpect(tableHeader.find('TableHeaderCell').at(3)).toHaveText('LABOR');

      const tableBody = wrapper.find('TableBody');
      jestExpect(tableBody.find('TableRow')).toHaveLength(2);

      const row1 = tableBody.find('TableRow').at(0);

      jestExpect(
        row1
          .find('TableCell')
          .at(0)
          .find('Field')
      ).toHaveProp({ name: 'yieldByproducts[0].byproductCode' });
      jestExpect(
        row1
          .find('TableCell')
          .at(0)
          .find('Field')
      ).toHaveProp({ hideDescriptionLabel: true });
      jestExpect(
        row1
          .find('TableCell')
          .at(1)
          .find('Field')
      ).toHaveProp({ name: 'yieldByproducts[0].yieldPercentage' });
      jestExpect(
        row1
          .find('TableCell')
          .at(1)
          .find('Field')
      ).toHaveProp({ normalize: normalizeToTwoDecimalPlaces });
      jestExpect(
        row1
          .find('TableCell')
          .at(2)
          .find('Field')
      ).toHaveProp({ name: 'yieldByproducts[0].cost' });
      jestExpect(
        row1
          .find('TableCell')
          .at(2)
          .find('Field')
      ).toHaveProp({ normalize: normalizeToTwoDecimalPlaces });
      jestExpect(
        row1
          .find('TableCell')
          .at(2)
          .find('Field')
      ).toHaveProp({ className: 'yield-byproduct-cost' });
      jestExpect(
        row1
          .find('TableCell')
          .at(3)
          .find('Field')
      ).toHaveProp({ name: 'yieldByproducts[0].labor' });
      jestExpect(
        row1
          .find('TableCell')
          .at(3)
          .find('Field')
      ).toHaveProp({ normalize: normalizeToTwoDecimalPlaces });
      jestExpect(
        row1
          .find('TableCell')
          .at(3)
          .find('Field')
      ).toHaveProp({ className: 'yield-byproduct-labor not-same' });
      const row2 = tableBody.find('TableRow').at(1);
      jestExpect(
        row2
          .find('TableCell')
          .at(0)
          .find('Field')
      ).toHaveProp({ name: 'yieldByproducts[1].byproductCode' });
      jestExpect(
        row2
          .find('TableCell')
          .at(1)
          .find('Field')
      ).toHaveProp({ name: 'yieldByproducts[1].yieldPercentage' });
      jestExpect(
        row2
          .find('TableCell')
          .at(2)
          .find('Field')
      ).toHaveProp({ className: 'yield-byproduct-cost not-same' });
    });

    test('should show error when invalid', () => {
      jestExpect(wrapper.find('Label')).toHaveLength(1);
      jestExpect(wrapper.find('Label')).toHaveText('Error Message');
    });

    test('should show error when submit failed', () => {
      wrapper = mount(
        <Provider store={store}>
          <Decorated
            fields={fields}
            meta={{ dirty: false, invalid: true, error: 'Error Message', submitFailed: true }}
            products={products}
            productsExist={productsExist}
          />
        </Provider>
      );
      jestExpect(wrapper.find('Label')).toHaveLength(1);
      jestExpect(wrapper.find('Label')).toHaveText('Error Message');
    });

    test('should call setProductTo action on change', () => {
      const setProductExistToSpy = jest.fn();
      wrapper = shallow(
        <ByproductTableComponent
          setProductExistTo={setProductExistToSpy}
          fields={fields}
          meta={{}}
          pricingModelCostsAndLabors={{}}
          products={{}}
          productsExist={{}}
          clearByproductCost={() => {}}
        />
      );

      const fieldName = 'yieldByproducts[0].byproductCode';
      wrapper
        .find(Field)
        .at(0)
        .simulate('change', { target: { value: '' } }, '09281', '0928', fieldName);

      jestExpect(setProductExistToSpy).toBeCalledWith(fieldName, true);
    });

    test('should call getProduct action on blur', () => {
      const getProductMock = jest.fn();
      wrapper = shallow(
        <ByproductTableComponent
          setProductExistTo={() => {}}
          fields={fields}
          getProduct={getProductMock}
          meta={{}}
          pricingModelCostsAndLabors={{}}
          products={{}}
          productsExist={{}}
          clearByproductCost={() => {}}
        />
      );

      const fieldName = 'yieldByproducts[0].byproductCode';
      wrapper
        .find(Field)
        .at(0)
        .simulate(
          'blur',
          { target: { value: '' }, preventDefault: () => {} },
          '0928167',
          '092816',
          fieldName
        );

      jestExpect(getProductMock).toHaveBeenCalledWith('0928167', jestExpect.any(Function));
    });

    test('should call setProductExistTo action on unsuccessful getProduct call on blur', () => {
      const getProductStub = jest.fn();
      const setProductExistToSpy = jest.fn();
      wrapper = shallow(
        <ByproductTableComponent
          setProductExistTo={setProductExistToSpy}
          fields={fields}
          getProduct={getProductStub}
          meta={{}}
          pricingModelCostsAndLabors={{}}
          products={{}}
          productsExist={{}}
          clearByproductCost={() => {}}
        />
      );

      const fieldName = 'yieldByproducts[0].byproductCode';
      getProductStub.mockImplementation((productCode, callback) => callback());
      wrapper
        .find(Field)
        .at(0)
        .simulate(
          'blur',
          { target: { value: '' }, preventDefault: () => {} },
          '0928167',
          '092816',
          fieldName
        );

      jestExpect(setProductExistToSpy).toBeCalledWith(fieldName, false);
    });

    describe('rendering message for Product Component', () => {
      test('should pass NOT_A_PRODUCT_CODE when product does not exist', () => {
        productsExist = {
          'yieldByproducts[0].byproductCode': false
        };

        const setProductExistToSpy = jest.fn();
        const wrapper = shallow(
          <ByproductTableComponent
            setProductExistTo={setProductExistToSpy}
            fields={fields}
            getProduct={jest.fn()}
            meta={{}}
            pricingModelCostsAndLabors={{}}
            products={{}}
            productsExist={productsExist}
            clearByproductCost={() => {}}
          />
        );

        const productField = wrapper.find(Field).at(0);

        jestExpect(productField).toHaveProp({ message: NOT_A_PRODUCT_CODE });
      });

      test('should pass null when product does exist', () => {
        productsExist = {
          'yieldByproducts[0].byproductCode': true
        };

        const setProductExistToSpy = jest.fn();
        const wrapper = shallow(
          <ByproductTableComponent
            setProductExistTo={setProductExistToSpy}
            fields={fields}
            getProduct={jest.fn()}
            meta={{}}
            pricingModelCostsAndLabors={{}}
            products={{}}
            productsExist={productsExist}
            clearByproductCost={() => {}}
          />
        );

        const productField = wrapper.find(Field).at(0);

        jestExpect(productField).toHaveProp({ message: null });
      });
    });

    describe('componentWillUnmount', () => {
      test('should call setProductExistsTo for byproduct upon unmount', () => {
        const setProductExistToSpy = jest.fn();
        const wrapper = shallow(
          <ByproductTableComponent
            setProductExistTo={setProductExistToSpy}
            fields={fields}
            getProduct={jest.fn()}
            meta={{}}
            pricingModelCostsAndLabors={{}}
            products={{}}
            productsExist={productsExist}
            clearByproductCost={() => {}}
          />
        );

        wrapper.unmount();

        jestExpect(setProductExistToSpy.mock.calls[0]).toEqual([
          'yieldByproducts[0].byproductCode',
          true
        ]);
        jestExpect(setProductExistToSpy.mock.calls[1]).toEqual([
          'yieldByproducts[1].byproductCode',
          true
        ]);
      });
    });
  });
});
