import React, { Fragment } from 'react';
import { mount, shallow } from 'enzyme';
import { Provider } from 'react-redux';
import { createReduxStore } from '../../../store';
import Validator from '../cuttingYieldModelFormValidator';
import CuttingYieldModelForm, {
  CuttingYieldModelFormComponent,
  SaveButton
} from '../CuttingYieldModelForm';
import CuttingYieldModelFactory from '../../../../test-factories/cuttingYieldModel';
import yieldModelResources from '../../../shared/api/yieldModelResources';
import productFactory from '../../../../test-factories/productFactory';
import semanticUI from '../../../../test-helpers/semantic-ui';
import productResources from '../../../shared/api/productResources';
import { Field, reduxForm } from 'redux-form';
import {
  PRICING_MODEL_CONFIRMATION_MESSAGE,
  PRICING_MODEL_MOVE_CONFIRMATION_MESSAGE
} from '../../../yieldModelProductGroup/components/yieldGroupMessages';
import { Modal } from 'semantic-ui-react';
import ConfirmationModal from '../../../shared/components/ConfirmationModal';
import costResources from '../../../shared/api/costResources';

jest.mock('../../../shared/api/costResources');
jest.mock('../../../shared/api/productResources');
jest.mock('../../../shared/api/yieldModelResources');
jest.mock('../cuttingYieldModelFormValidator');

describe('CuttingYieldModelForm', () => {
  afterEach(() => {
    costResources.getCostByProductCode.mockReset();
    productResources.getProductInfo.mockReset();
    yieldModelResources.createOrUpdateCuttingYieldModel.mockReset();
    yieldModelResources.calculateCuttingYieldModelFinishedCost.mockReset();
    yieldModelResources.getYieldModel.mockReset();
    yieldModelResources.getActualYieldTests.mockReset();
    Validator.validateSubmission.mockReset();
    Validator.validateFields.mockReset();
  });

  beforeEach(() => {
    const cuttingYieldModel = CuttingYieldModelFactory.build({});
    yieldModelResources.calculateCuttingYieldModelFinishedCost.mockImplementation(yieldModel =>
      Promise.resolve({
        data: {
          ...yieldModel,
          estimatedYield: cuttingYieldModel.estimatedYield,
          byproductCredit: cuttingYieldModel.byproductCredit,
          additives: cuttingYieldModel.additives,
          finishedProductCost: 35.16
        }
      })
    );
    yieldModelResources.getYieldModel.mockResolvedValue(cuttingYieldModel);
    yieldModelResources.createOrUpdateCuttingYieldModel.mockImplementation(yieldModel =>
      Promise.resolve({
        data: {
          ...yieldModel,
          estimatedYield: cuttingYieldModel.estimatedYield,
          byproductCredit: cuttingYieldModel.byproductCredit,
          additives: cuttingYieldModel.additives,
          finishedProductCost: 35.16
        }
      })
    );
  });

  describe('Mount Rendering: Subcutaneous Testing', () => {
    let form, store;

    beforeEach(() => {
      store = createReduxStore({});
    });

    test('should initialize form value when no yield model in store', async () => {
      store = createReduxStore({});
      form = mount(
        <Provider store={store}>
          <CuttingYieldModelForm shouldAsyncValidate={() => false} />
        </Provider>
      );

      await waitForAsyncTasks();
      form = form.update();

      jestExpect(semanticUI.getInputValue(form, 'finishedProductCode')).toEqual('');
      jestExpect(semanticUI.getInputValue(form, 'sourceProductCode')).toEqual('');
      jestExpect(semanticUI.getInputValue(form, 'labor')).toEqual('');
      jestExpect(semanticUI.getLabelProp(form, 'additives', 'value')).toEqual('0.00');
      jestExpect(semanticUI.getCheckBoxValue(form, 'pricingModel')).toEqual(false);
      jestExpect(semanticUI.getLabelProp(form, 'ESTIMATED YIELD %', 'value')).toEqual('100.00');
      jestExpect(semanticUI.getLabelProp(form, 'BYPRODUCT CREDIT', 'value')).toEqual('0.00');
      jestExpect(semanticUI.getLabelProp(form, 'UNIT COST PER LB', 'value')).toEqual('0.00');
      jestExpect(semanticUI.getInputValue(form, 'sourceLbs')).toEqual('');
      jestExpect(semanticUI.getInputValue(form, 'pickupPercent')).toEqual('');
    });

    test('should initialize form value when have yieldModel in store', async () => {
      store = createReduxStore({
        cuttingYieldModelInfo: {
          yieldModel: CuttingYieldModelFactory.build({
            yieldModelCurrentPricingModel: true,
            pricingModel: true
          }),
          pricingModelCostsAndLabors: {
            '0079006': { productCode: '0079006', cost: 1.23, labor: 1.2 },
            '0214101': { productCode: '0214101', cost: 3.2, labor: 1.34 }
          },
          actualYieldTests: {},
          actualYieldTestsAvailableStatus: -1,
          finishedProductIsReadOnly: true,
          sourceProductIsReadOnly: true
        },
        productDuplicate: {
          products: {
            '0079007': {
              code: '0079007',
              cost: 15.01
            }
          },
          productsExist: {
            sourceProductCode: true
          },
          additiveSourceItem: true
        }
      });

      form = mount(
        <Provider store={store}>
          <CuttingYieldModelForm shouldAsyncValidate={() => false} />
        </Provider>
      );

      await waitForAsyncTasks();
      form = form.update();

      jestExpect(semanticUI.getLabelProp(form, 'Finished Product #', 'value')).toEqual('0078889');
      jestExpect(semanticUI.getLabelProp(form, 'Source Product #', 'value')).toEqual('0079007');

      jestExpect(semanticUI.getInputValue(form, 'labor')).toEqual('2.59');
      jestExpect(semanticUI.getLabelProp(form, 'additives', 'value')).toEqual('0.12');
      jestExpect(semanticUI.getLabelProp(form, 'Pricing Model', 'value')).toEqual('YES');
      jestExpect(semanticUI.getLabelProp(form, 'ESTIMATED YIELD %', 'value')).toEqual('49.99');
      jestExpect(semanticUI.getLabelProp(form, 'BYPRODUCT CREDIT', 'value')).toEqual('0.07');
      jestExpect(semanticUI.getLabelProp(form, 'UNIT COST PER LB', 'value')).toEqual('35.16');
      jestExpect(semanticUI.getInputValue(form, 'sourceLbs')).toEqual('20');
      jestExpect(semanticUI.getInputValue(form, 'pickupPercent')).toEqual(5.5);
    });

    test('should get yield model when change to source product', async () => {
      productResources.getProductInfo.mockImplementation((productCode, callback) => {
        if (productCode === '0202013') {
          callback({ data: productFactory.build({ code: '0202013', cost: 99.98 }) });
        }
      });
      yieldModelResources.getYieldModel.mockResolvedValue({});

      store = createReduxStore({
        cuttingYieldModelInfo: {
          yieldModel: CuttingYieldModelFactory.build({ pricingModel: false }),
          pricingModelCostsAndLabors: {
            '0079006': { productCode: '0079006', cost: 1.23, labor: 1.2 },
            '0214101': { productCode: '0214101', cost: 3.2, labor: 1.34 }
          },
          actualYieldTests: {},
          actualYieldTestsAvailableStatus: -1
        }
      });
      form = mount(
        <Provider store={store}>
          <CuttingYieldModelForm />
        </Provider>
      );

      semanticUI.changeInput(form, 'sourceProductCode', '202013');

      await waitForAsyncTasks();
      form = form.update();

      jestExpect(yieldModelResources.getYieldModel).toBeCalledWith('0078889', '0202013');
    });

    test('should called getYieldByproductsInfo and getYieldAdditivesInfo when yield model is retrieved from resource', () => {
      productResources.getProductInfo.mockImplementation((productCode, callback) => {
        if (productCode === '0202013') {
          callback({ data: productFactory.build({ code: '0202013', cost: 99.98 }) });
        }
        if (productCode === '0079006') {
          callback({
            data: productFactory.build({ code: '0079006', description: 'PRIME T-BONE for 0079006' })
          });
        }
        if (productCode === '4181840') {
          callback({
            data: productFactory.build({ code: '4181840', description: 'PRIME T-BONE for 4181840' })
          });
        }
      });
      const yieldModel = CuttingYieldModelFactory.build({
        id: 127,
        finishedProductCode: '0078889',
        sourceProductCode: '0079007',
        yieldByproducts: [
          { byproductCode: '0079006', yieldPercentage: '30.01', cost: '1.23', labor: '4.50' }
        ],
        yieldAdditives: [{ productCode: '4181840', weight: '15.00' }]
      });

      yieldModelResources.getYieldModel.mockResolvedValue(yieldModel);

      costResources.getCostByProductCode.mockImplementation((productCode, callback) =>
        callback({
          cost: 1.23,
          labor: 1.2
        })
      );

      store = createReduxStore({
        cuttingYieldModelInfo: {
          yieldModel: CuttingYieldModelFactory.build({
            pricingModel: false,
            yieldByproducts: [
              {
                byproductCode: '0079006',
                byproductCredit: '1.25',
                yieldPercentage: '30.01',
                cost: '1.23',
                labor: '1.20',
                packaging: 1.5,
                overhead: 0.38
              }
            ]
          }),
          pricingModelCostsAndLabors: {},
          actualYieldTests: {},
          actualYieldTestsAvailableStatus: -1
        }
      });
      form = mount(
        <Provider store={store}>
          <CuttingYieldModelForm />
        </Provider>
      );

      semanticUI.changeInput(form, 'sourceProductCode', '202013');

      jestExpect(costResources.getCostByProductCode.mock.calls[0][0]).toEqual('0079006');
      jestExpect(yieldModelResources.getYieldModel).toBeCalledWith('0078889', '0202013');
      jestExpect(semanticUI.getInputValue(form, 'yieldByproducts[0].byproductCode')).toEqual(
        '0079006'
      );
      jestExpect(
        form
          .find('[pid="yieldByproducts_0__byproductCodeDescription"]')
          .at(0)
          .props()
      ).toEqual(jestExpect.objectContaining({ value: 'PRIME T-BONE for 0079006' }));

      jestExpect(semanticUI.getInputValue(form, 'yieldAdditives[0].productCode')).toEqual(
        '4181840'
      );
      jestExpect(
        form
          .find('[pid="yieldAdditives_0__productCodeDescription"]')
          .at(0)
          .props()
      ).toEqual(jestExpect.objectContaining({ value: 'PRIME T-BONE for 4181840' }));
    });

    test('should fill out form, cancel and not submit values to API', async () => {
      jest.setTimeout(15000);
      productResources.getProductInfo.mockImplementation((productCode, callback) => {
        if (productCode === '0078889') {
          callback({ data: productFactory.build({ code: '0078889' }) });
        }
        if (productCode === '0079007') {
          callback({ data: productFactory.build({ code: '0079007', cost: 1.23 }) });
        }
        if (productCode === '0079006') {
          callback({ data: productFactory.build({ code: '0079006', cost: 1.23 }) });
        }
        if (productCode === '0214101') {
          callback({ data: productFactory.build({ code: '0214101', cost: 1.23 }) });
        }
      });

      store = createReduxStore({
        productDuplicate: {
          products: {
            '0078889': {
              code: '0078889',
              cost: 12.44
            },
            '0079007': {
              code: '0079007',
              cost: 1.23
            },
            '0214101': {
              code: '0214101',
              cost: 1.23
            },
            '0079006': {
              code: '0079006',
              cost: 1.23
            }
          },
          additiveSourceItem: true
        },
        confirmationModal: {
          showing: false
        },
        cuttingYieldModelInfo: {
          yieldModel: {
            finishedProductCode: '0078889',
            sourceProductCode: '0079007',
            pricingModel: false
          },
          pricingModelCostsAndLabors: {},
          actualYieldTests: {},
          actualYieldTestsAvailableStatus: -1
        }
      });

      form = mount(
        <Provider store={store}>
          <Fragment>
            <ConfirmationModal />
            <CuttingYieldModelForm />
          </Fragment>
        </Provider>
      );

      semanticUI.changeInput(form, 'finishedProductCode', '78889');
      semanticUI.changeInput(form, 'sourceProductCode', '79007');
      semanticUI.changeInput(form, 'labor', '1.5');
      semanticUI.changeInput(form, 'pricingModel', true);
      semanticUI.changeInput(form, 'yieldByproducts[0].byproductCode', '0079006');
      semanticUI.changeInput(form, 'yieldByproducts[0].yieldPercentage', '30.01');
      semanticUI.changeInput(form, 'yieldByproducts[1].byproductCode', '0214101');
      semanticUI.changeInput(form, 'yieldByproducts[1].yieldPercentage', '20');

      form.find('form').simulate('submit');

      await waitForAsyncTasks();
      form = form.update();

      form
        .find(Modal)
        .props()
        .children[2].props.children[0].props.onClick();
      form = form.update();

      jestExpect(semanticUI.getCheckBoxValue(form, 'pricingModel')).toEqual(false);

      jestExpect(yieldModelResources.createOrUpdateCuttingYieldModel).not.toBeCalled();
      jestExpect(semanticUI.getLabelProp(form, 'BYPRODUCT CREDIT', 'value')).toEqual('0.07');
      jestExpect(semanticUI.getLabelProp(form, 'additives', 'value')).toEqual('0.12');
      jestExpect(semanticUI.getLabelProp(form, 'UNIT COST PER LB', 'value')).toEqual('35.16');
    });

    test('should fill out form, ok from show modal and submit values to API', async () => {
      jest.setTimeout(10000);
      productResources.getProductInfo.mockImplementation((productCode, callback) => {
        if (productCode === '0078889') {
          callback({ data: productFactory.build({ code: '0078889', cost: 1.23 }) });
        }
        if (productCode === '0079007') {
          callback({ data: productFactory.build({ code: '0079007', cost: 1.23 }) });
        }
        if (productCode === '0079006') {
          callback({ data: productFactory.build({ code: '0079006', cost: 1.23 }) });
        }
        if (productCode === '0214101') {
          callback({ data: productFactory.build({ code: '0214101', cost: 1.23 }) });
        }
      });

      store = createReduxStore({});

      form = mount(
        <Provider store={store}>
          <Fragment>
            <ConfirmationModal />
            <CuttingYieldModelForm />
          </Fragment>
        </Provider>
      );

      semanticUI.changeInput(form, 'finishedProductCode', '78889');
      semanticUI.changeInput(form, 'sourceProductCode', '79007');
      semanticUI.changeInput(form, 'labor', '1.5');
      semanticUI.changeInput(form, 'pricingModel', true);
      semanticUI.changeInput(form, 'yieldByproducts[0].byproductCode', '0079006');
      semanticUI.changeInput(form, 'yieldByproducts[0].yieldPercentage', '30.01');
      semanticUI.changeInput(form, 'yieldByproducts[1].byproductCode', '0214101');
      semanticUI.changeInput(form, 'yieldByproducts[1].yieldPercentage', '20');
      semanticUI.changeInput(form, 'pickupPercent', '5.5');

      form.find('form').simulate('submit');

      await waitForAsyncTasks(form);

      form
        .find(Modal)
        .props()
        .children[2].props.children[1].props.onClick();

      jestExpect(yieldModelResources.createOrUpdateCuttingYieldModel).toHaveBeenCalledWith({
        sourceProductCode: '0079007',
        finishedProductCode: '0078889',
        labor: 1.5,
        packaging: 0,
        overhead: 0,
        pricingModel: true,
        yieldByproducts: [
          {
            byproductCode: '0079006',
            cost: 1.23,
            id: undefined,
            labor: 0,
            overhead: 0,
            packaging: 0,
            yieldPercentage: 30.01
          },
          {
            byproductCode: '0214101',
            cost: 1.23,
            id: undefined,
            labor: 0,
            overhead: 0,
            packaging: 0,
            yieldPercentage: 20
          }
        ],
        yieldAdditives: [],
        sourceLbs: '',
        pickupPercent: 5.5
      });
    });

    test('should not submit successfully when finishedProductCode does not exist in API', () => {
      productResources.getProductInfo.mockImplementation((productCode, callback, errorCallback) => {
        if (productCode === '0072821') {
          errorCallback();
        } else {
          callback({
            data: productFactory.build({ code: '0062885', cost: 15.1 })
          });
        }
      });

      store = createReduxStore({});
      form = mount(
        <Provider store={store}>
          <CuttingYieldModelForm />
        </Provider>
      );

      semanticUI.changeInput(form, 'finishedProductCode', '72821');

      semanticUI.changeInput(form, 'sourceProductCode', '62885');

      semanticUI.changeInput(form, 'labor', '2.1');
      semanticUI.changeInput(form, 'pricingModel', true);

      form.find('form').simulate('submit');

      jestExpect(yieldModelResources.createOrUpdateCuttingYieldModel).not.toBeCalled();
    });

    describe('componentWillUnmount', () => {
      test('should clear yield model data upon unmount', () => {
        const yieldModel = CuttingYieldModelFactory.build();
        store = createReduxStore({
          router: { location: { pathname: '/other/pathname' } },
          yieldModelInfo: { yieldModel: yieldModel, pricingModelConfirmationShowing: true }
        });
        form = mount(
          <Provider store={store}>
            <CuttingYieldModelForm />
          </Provider>
        );

        form.unmount();
        jestExpect(store.getState().cuttingYieldModelInfo.yieldModel).toEqual({
          additives: 0,
          byproductCredit: 0,
          estimatedYield: 100,
          finishedProductCost: 0
        });
      });

      test('should call setProductExistsTo for finished product upon unmount', () => {
        const setProductExistToSpy = jest.fn();
        const wrapper = shallow(
          <CuttingYieldModelFormComponent
            getActualYieldTests={() => {}}
            getYieldModel={() => {}}
            getProduct={() => {}}
            setProductExistTo={setProductExistToSpy}
            finishedProductCode={'1928374'}
            sourceProductCode={''}
            productsDuplicate={{}}
            initialValues={{}}
            clearYieldModelInfo={() => {}}
            handleSubmit={() => {}}
            submitting={false}
            pristine={true}
            hideModal={jest.fn()}
            additiveSourceItem={true}
          />
        );

        wrapper.unmount();
        jestExpect(setProductExistToSpy).toBeCalledWith('finishedProductCode', true);
      });

      test('should call setProductExistsTo for sourceProductCode upon unmount', () => {
        const setProductExistToSpy = jest.fn();
        const wrapper = shallow(
          <CuttingYieldModelFormComponent
            getActualYieldTests={() => {}}
            getYieldModel={() => {}}
            getProduct={() => {}}
            setProductExistTo={setProductExistToSpy}
            finishedProductCode={''}
            sourceProductCode={'1928374'}
            productsDuplicate={{}}
            initialValues={{}}
            clearYieldModelInfo={() => {}}
            handleSubmit={() => {}}
            submitting={false}
            pristine={true}
            hideModal={jest.fn()}
            additiveSourceItem={true}
          />
        );

        wrapper.unmount();
        jestExpect(setProductExistToSpy).toBeCalledWith('sourceProductCode', true);
      });
    });
  });

  describe('Mount Unit Testing', () => {
    let form, store, DecoratedComponent, createOrUpdateCuttingYieldModelSpy;

    beforeEach(() => {
      store = createReduxStore({});
      DecoratedComponent = reduxForm({ form: 'testform' })(CuttingYieldModelFormComponent);
      createOrUpdateCuttingYieldModelSpy = jest.fn();

      form = mount(
        <Provider store={store}>
          <DecoratedComponent
            passProductCodesTo={() => {}}
            getYieldModel={() => {}}
            clearYieldModelInfo={() => {}}
            isYieldModelCurrentPricingModel={false}
            getProduct={() => {}}
            productsDuplicate={{}}
            products={{}}
            getActualYieldTests={() => {}}
            initialValues={{}}
            createOrUpdateCuttingYieldModel={createOrUpdateCuttingYieldModelSpy}
            productsExist={{}}
            additiveSourceItem={true}
          />
        </Provider>
      );
    });

    ['finishedProductCode', 'sourceProductCode'].forEach(field => {
      test(`should call setProductExistsTo Action onChange of ${field}`, () => {
        const setProductExistsToSpy = jest.fn();
        const createOrUpdateCuttingYieldModelSpy = jest.fn();
        const wrapper = mount(
          <Provider store={store}>
            <DecoratedComponent
              passProductCodesTo={() => {}}
              getYieldModel={() => {}}
              clearYieldModelInfo={() => {}}
              isYieldModelCurrentPricingModel={false}
              getProduct={() => {}}
              productsDuplicate={{}}
              products={{}}
              productsExist={{}}
              getActualYieldTests={() => {}}
              initialValues={{}}
              createOrUpdateCuttingYieldModel={createOrUpdateCuttingYieldModelSpy}
              setProductExistTo={setProductExistsToSpy}
              additiveSourceItem={true}
            />
          </Provider>
        );

        let value = '0078889';
        const inputField = wrapper.find(Field).find(`input[name='${field}']`);

        inputField.simulate('change', { target: { value } });

        jestExpect(setProductExistsToSpy).toBeCalledWith(field, true);
      });
    });

    test('should call createOrUpdateCuttingYieldModel when submit is triggered', () => {
      createOrUpdateCuttingYieldModelSpy.mockResolvedValue();

      form.find('form').simulate('submit');

      jestExpect(createOrUpdateCuttingYieldModelSpy).toBeCalledTimes(1);
    });

    test('should have a save button', () => {
      const productsDuplicate = {
        '0078889': {
          code: '0078889',
          cost: 15.01,
          productGroup: {
            name: '0079007',
            primaryProductCode: '0079007',
            memberProductCodes: ['0079007', '0078889']
          }
        },
        '2857102': {
          code: '2857102',
          cost: 2.0
        }
      };

      const wrapper = shallow(
        <CuttingYieldModelFormComponent
          passProductCodesTo={() => {}}
          getYieldModel={() => {}}
          clearYieldModelInfo={() => {}}
          createOrUpdateCuttingYieldModel={() => {}}
          unsetPricingModel={() => {}}
          isYieldModelCurrentPricingModel={false}
          submitting={false}
          pristine={true}
          getActualYieldTests={() => {}}
          finishedProductCode={'0078889'}
          sourceProductCode={'2857102'}
          productsDuplicate={productsDuplicate}
          products={{}}
          handleSubmit={() => {}}
          initialValues={{}}
          getProduct={() => {}}
          additiveSourceItem={true}
        />
      );

      jestExpect(wrapper.find(SaveButton)).toExist();
    });
  });

  describe('showModal', () => {
    test('should show correct confirmation warning if product is part of product group', () => {
      const showModalMock = jest.fn();
      const props = {
        initialValues: {},
        finishedProductCode: '0078889',
        productsDuplicate: {
          '0078889': {
            code: '0078889',
            cost: 15.01,
            productGroup: {
              name: '0079007',
              primaryProductCode: '0079007',
              memberProductCodes: ['0079007', '0078889']
            }
          }
        },
        hideModal: jest.fn(),
        showModal: showModalMock,
        changeFieldValue: jest.fn()
      };

      const values = {
        finishedProductCode: '0078889',
        sourceProductCode: '0079007',
        yieldByproducts: [
          { byproductCode: '0079006', yieldPercentage: '30.01', cost: '1.23', labor: '4.50' }
        ],
        yieldAdditives: [{ productCode: '4181840', weight: '15.00' }]
      };

      const formComponent = new CuttingYieldModelFormComponent(props);

      formComponent.createPricingModelConfirmationModal(values);

      jestExpect(showModalMock).toHaveBeenCalledWith(
        jestExpect.objectContaining({
          header: 'Continue with setting as pricing model?',
          content: PRICING_MODEL_MOVE_CONFIRMATION_MESSAGE,
          cancelButton: 'Cancel',
          cancelAction: jestExpect.any(Function),
          confirmButton: 'OK',
          confirmAction: jestExpect.any(Function)
        })
      );
    });

    test(
      'should show correct show pricing model confirmation message when ' +
        'a product is not member of a group',
      () => {
        const showModalMock = jest.fn();
        const props = {
          initialValues: {},
          finishedProductCode: '0078889',
          productsDuplicate: {
            '0078889': {
              code: '0078889',
              cost: 15.01,
              productGroup: {
                name: '0078889',
                primaryProductCode: '0078889'
              }
            }
          },
          hideModal: jest.fn(),
          showModal: showModalMock,
          changeFieldValue: jest.fn()
        };
        const values = {
          finishedProductCode: '0078889',
          sourceProductCode: '0079007',
          yieldByproducts: [
            { byproductCode: '0079006', yieldPercentage: '30.01', cost: '1.23', labor: '4.50' }
          ],
          yieldAdditives: [{ productCode: '4181840', weight: '15.00' }]
        };

        const formComponent = new CuttingYieldModelFormComponent(props);

        formComponent.createPricingModelConfirmationModal(values);

        jestExpect(showModalMock).toHaveBeenCalledWith(
          jestExpect.objectContaining({
            header: 'Continue with setting as pricing model?',
            content: PRICING_MODEL_CONFIRMATION_MESSAGE,
            cancelButton: 'Cancel',
            cancelAction: jestExpect.any(Function),
            confirmButton: 'OK',
            confirmAction: jestExpect.any(Function)
          })
        );
      }
    );
  });

  describe('Show yield model cost error', () => {
    let wrapper;

    beforeEach(() => {
      wrapper = shallow(
        <CuttingYieldModelFormComponent
          getActualYieldTests={() => {}}
          passProductCodesTo={() => {}}
          getYieldModel={() => {}}
          clearYieldModelInfo={() => {}}
          createOrUpdateCuttingYieldModel={() => {}}
          unsetPricingModel={() => {}}
          isYieldModelCurrentPricingModel={false}
          submitting={false}
          pristine={true}
          productsDuplicate={{}}
          products={{}}
          handleSubmit={() => {}}
          initialValues={{}}
          getProduct={() => {}}
          additiveSourceItem={true}
        />
      );
    });

    test('should not show finished product cost error when the form no error', () => {
      wrapper.setProps({
        finishedProductCostError: 'must be greater than 0'
      });

      jestExpect(wrapper.find('span.yield-model-cost-error').exists()).toEqual(false);
    });

    test('should not show finished product cost error when the form no finishedProductCostError', () => {
      wrapper.setProps({
        error: 'Cannot create yield model for this product.'
      });

      jestExpect(wrapper.find('span.yield-model-cost-error').exists()).toEqual(false);
    });

    test('should show finished product cost error when the form has finishedProductCostError and error', () => {
      wrapper.setProps({
        error: 'Cannot create yield model for this product.',
        finishedProductCostError: 'must be greater than 0'
      });

      jestExpect(wrapper.find('span.yield-model-cost-error').text()).toEqual(
        'Unit cost/lb cannot be 0 or less'
      );
    });

    test('should not show by product value error when the form no error', () => {
      wrapper.setProps({
        byproductValueError: 'must be greater than 0'
      });

      jestExpect(wrapper.find('span.yield-model-cost-error').exists()).toEqual(false);
    });

    test('should not show by product value error when the form no byproductValueError', () => {
      wrapper.setProps({
        error: 'Cannot create yield model for this product.'
      });

      jestExpect(wrapper.find('span.yield-model-cost-error').exists()).toEqual(false);
    });

    test('should show by product value error when the form has byproductValueError and error', () => {
      wrapper.setProps({
        error: 'Cannot create yield model for this product.',
        byproductValueError: 'must be greater than 0'
      });

      jestExpect(wrapper.find('span.yield-model-cost-error').text()).toEqual(
        'Byproduct credit value cannot be less than 0.'
      );
    });
  });

  describe('Shallow Rendering: Unit Testing', () => {
    let wrapper;

    beforeEach(() => {
      wrapper = shallow(
        <CuttingYieldModelFormComponent
          getActualYieldTests={() => {}}
          passProductCodesTo={() => {}}
          getYieldModel={() => {}}
          clearYieldModelInfo={() => {}}
          createOrUpdateCuttingYieldModel={() => {}}
          pricingModelConfirmationShowing={false}
          unsetPricingModel={() => {}}
          isYieldModelCurrentPricingModel={false}
          submitting={false}
          pristine={true}
          productsDuplicate={{}}
          products={{}}
          handleSubmit={() => {}}
          initialValues={{}}
          getProduct={() => {}}
          additiveSourceItem={true}
        />
      );
    });

    test('should make finished product uneditible', () => {
      wrapper.setProps({
        finishedProductIsReadOnly: true
      });

      jestExpect(
        wrapper
          .find(Field)
          .at(0)
          .props().readonly
      ).toEqual(true);
    });

    test('should make finished product editible', () => {
      wrapper.setProps({
        finishedProductIsReadOnly: false
      });

      jestExpect(
        wrapper
          .find(Field)
          .at(0)
          .props().readonly
      ).toEqual(false);
    });

    test('should make source product uneditible', () => {
      wrapper.setProps({
        sourceProductIsReadOnly: true
      });

      jestExpect(
        wrapper
          .find(Field)
          .at(1)
          .props().readonly
      ).toEqual(true);
    });

    test('should make source product editible', () => {
      wrapper.setProps({
        sourceProductIsReadOnly: false
      });

      jestExpect(
        wrapper
          .find(Field)
          .at(1)
          .props().readonly
      ).toEqual(false);
    });

    test('PricingModelCheckBox should take in required parameters', () => {
      wrapper.setProps({
        isYieldModelCurrentPricingModel: true
      });

      jestExpect(
        wrapper.find('.price-model-check').props().isYieldModelCurrentPricingModel
      ).toEqual(true);
    });

    test('should display -no yield test- available', () => {
      wrapper.setProps({
        finishedProductIsReadOnly: true,
        sourceProductIsReadOnly: true,
        actualYieldTestsAvailableStatus: 0
      });

      jestExpect(wrapper.find('[pid="actual-yield-test-not-available"]').text()).toEqual(
        jestExpect.stringContaining('No yield tests have been performed in the last 12 months')
      );
      jestExpect(wrapper.find('[pid="yield-test-compare-tables"]').exists()).toEqual(false);
    });

    test('should display comparison table', () => {
      const cuttingYieldModel = CuttingYieldModelFactory.build({});
      wrapper.setProps({
        finishedProductIsReadOnly: true,
        sourceProductIsReadOnly: true,
        actualYieldTestsAvailableStatus: 1,
        actualYieldTestList: cuttingYieldModel.actualYieldTestList
      });

      jestExpect(wrapper.find('[pid="actual-yield-test-not-available"]').exists()).toEqual(false);
      jestExpect(wrapper.find('[pid="yield-test-compare-tables"]').exists()).toEqual(true);
    });

    test('should not show table or -no yield test- message ', () => {
      wrapper.setProps({
        finishedProductIsReadOnly: true,
        sourceProductIsReadOnly: true,
        actualYieldTestsAvailableStatus: -1
      });

      jestExpect(wrapper.find('[pid="actual-yield-test-not-available"]').exists()).toEqual(false);
      jestExpect(wrapper.find('[pid="yield-test-compare-tables"]').exists()).toEqual(false);
    });
  });
});

describe('SaveButton', () => {
  test('should allow saving', () => {
    let it = shallow(
      <SaveButton
        submitting={false}
        pristine={false}
        productsDuplicate={{
          1234567: {},
          7654321: {}
        }}
        finishedProductCode={'1234567'}
        sourceProductCode={'7654321'}
        sourceProductCost={22.0}
        additiveSourceItem={true}
      />
    );

    jestExpect(it).not.toBeDisabled();
  });

  test('should prevent double clicking during save', () => {
    let it = shallow(
      <SaveButton
        submitting={true}
        pristine={false}
        productsDuplicate={{
          1234567: {},
          7654321: {}
        }}
        finishedProductCode={'1234567'}
        sourceProductCode={'7654321'}
        additiveSourceItem={true}
      />
    );

    jestExpect(it).toBeDisabled();
  });

  test('should prevent saving without changes', () => {
    let it = shallow(
      <SaveButton
        submitting={false}
        pristine={true}
        productsDuplicate={{
          1234567: {},
          7654321: {}
        }}
        finishedProductCode={'1234567'}
        sourceProductCode={'7654321'}
        additiveSourceItem={true}
      />
    );

    jestExpect(it).toBeDisabled();
  });

  test('should prevent saving without a real finished product', () => {
    let it = shallow(
      <SaveButton
        submitting={false}
        pristine={false}
        productsDuplicate={{
          7654321: {}
        }}
        finishedProductCode={'1234567'}
        sourceProductCode={'7654321'}
        additiveSourceItem={true}
      />
    );

    jestExpect(it).toBeDisabled();
  });

  test('should prevent saving without a real source product', () => {
    let it = shallow(
      <SaveButton
        submitting={false}
        pristine={false}
        productsDuplicate={{
          1234567: {}
        }}
        finishedProductCode={'1234567'}
        sourceProductCode={'7654321'}
        additiveSourceItem={true}
      />
    );

    jestExpect(it).toBeDisabled();
  });

  test('should prevent saving without a sourceProductCost', () => {
    let it = shallow(
      <SaveButton
        submitting={false}
        pristine={false}
        productsDuplicate={{
          1234567: {},
          7654321: {}
        }}
        finishedProductCode={'1234567'}
        sourceProductCode={'7654321'}
        sourceProductCost={12}
        additiveSourceItem={false}
      />
    );

    jestExpect(it).toBeDisabled();
  });

  test('should prevent saving without a sourceProductCost', () => {
    let it = shallow(
      <SaveButton
        submitting={false}
        pristine={false}
        productsDuplicate={{
          1234567: {},
          7654321: {}
        }}
        finishedProductCode={'1234567'}
        sourceProductCode={'7654321'}
        additiveSourceItem={true}
      />
    );

    jestExpect(it).toBeDisabled();
  });
});
