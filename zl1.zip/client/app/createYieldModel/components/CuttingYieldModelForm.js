import React from 'react';
import moment from 'moment';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import _ from 'lodash';
import { bindActionCreators } from 'redux';
import {
  change,
  Field,
  FieldArray,
  formValueSelector,
  getFormSubmitErrors,
  reduxForm
} from 'redux-form';
import { Button, Divider, Form, Grid, Icon } from 'semantic-ui-react';
import FormLabel from '../../shared/FormLabel';
import {
  normalizeProductCode,
  normalizeToTwoDecimalPlaces
} from '../../shared/components/product/normalizer';
import ProductDuplicate from '../../shared/components/product/ProductDuplicate';
import { getProduct, setProductExistTo } from '../../shared/components/product/actionsDuplicate';
import {
  calculateFinishedCost,
  checkByProduct,
  clearYieldModelInfo,
  createOrUpdateCuttingYieldModel,
  getActualYieldTests,
  getYieldModel
} from '../actions/cuttingYieldModelActions';
import Validator from './cuttingYieldModelFormValidator';
import PricingModelCheckBox from './PricingModelCheckBox';
import ByproductTable, { byproductsMapStateToPropsForYieldModelForm } from './ByproductTable';
import {
  formatNumberToTwoDecimalPlacesString,
  formatNumberToTwoDecimalPlacesStringIncludeZero,
  zeroIfInvalid
} from '../../shared/util/dataUtil';
import {
  PRICING_MODEL_CONFIRMATION_MESSAGE,
  PRICING_MODEL_MOVE_CONFIRMATION_MESSAGE
} from '../../yieldModelProductGroup/components/yieldGroupMessages';
import { NOT_A_PRODUCT_CODE } from '../../../config/errorMessage';
import AdditiveTable, { additivesMapStateToPropsForYieldModelForm } from './AdditiveTable';
import FormElement from '../../shared/FormElement';
import ByproductYieldTestCompareTable from './ByproductYieldTestCompareTable';
import FinishedProductYieldTestCompareTable from './FinishedProductYieldTestCompareTable';
import CuttingYieldModelPricingFactors from './CuttingYieldModelPricingFactors';
import { toPrecision } from '../../shared/util/floatUtil';
import { hideModal, showModal } from '../../shared/actions/actions';

const CUTTING_YIELD_MODEL_FORM_NAME = 'createCuttingYieldModelForm';
const selector = formValueSelector(CUTTING_YIELD_MODEL_FORM_NAME);

export const SaveButton = ({
  submitting,
  asyncValidating,
  pristine,
  productsDuplicate,
  finishedProductCode,
  sourceProductCode,
  sourceProductCost,
  additiveSourceItem
}) => {
  const disabled =
    submitting ||
    pristine ||
    !(productsDuplicate[finishedProductCode] && productsDuplicate[sourceProductCode]) ||
    !sourceProductCost ||
    !additiveSourceItem;
  return (
    <Button
      primary
      size={'large'}
      loading={submitting || Boolean(asyncValidating)}
      disabled={disabled}
    >
      <Icon className='icon-save' />
      Save
    </Button>
  );
};

SaveButton.propTypes = {
  submitting: PropTypes.bool.isRequired,
  pristine: PropTypes.bool.isRequired,
  asyncValidating: PropTypes.oneOfType([PropTypes.string, PropTypes.bool]),
  productsDuplicate: PropTypes.object.isRequired,
  finishedProductCode: PropTypes.string,
  sourceProductCode: PropTypes.string,
  sourceProductCost: PropTypes.number,
  additiveSourceItem: PropTypes.bool
};

const getYieldModelCostErrorsMessage = props => {
  const { error, finishedProductCostError, byproductValueError } = props;

  let errorMessage = null;

  if (error && finishedProductCostError) {
    errorMessage = 'Unit cost/lb cannot be 0 or less';
  }

  if (error && byproductValueError) {
    errorMessage = 'Byproduct credit value cannot be less than 0.';
  }

  return (
    errorMessage && <span className={'ui red message yield-model-cost-error'}>{errorMessage}</span>
  );
};

const oneYearYieldTestList = actualYieldTestList => {
  return actualYieldTestList.filter(actualYieldTest =>
    moment(actualYieldTest.createdAt).isAfter(moment(moment().subtract(1, 'years')))
  );
};

const calculateLastDate = actualYieldTestList => {
  let lastDate = actualYieldTestList[0].createdAt;
  actualYieldTestList.forEach(function(yieldTest) {
    if (moment(yieldTest.createdAt).isAfter(moment(lastDate))) {
      lastDate = yieldTest.createdAt;
    }
  });
  return moment(lastDate).format('MM/DD/YYYY');
};

const yieldTestBeforeOneYear = lastDate => {
  return (
    <div>
      <Divider hidden />
      <div pid='actual-yield-test-not-available'>
        No yield tests have been performed in the last 12 months. Last yield test performed{' '}
        {lastDate}
      </div>
      <Divider hidden />
    </div>
  );
};

const oneYearYieldTestCompareTable = (props, OneYearYieldTestList, lastDate) => {
  return (
    <div pid='yield-test-compare-tables'>
      <FinishedProductYieldTestCompareTable
        {...props}
        OneYearYieldTestList={OneYearYieldTestList}
        lastDate={lastDate}
      />
      <ByproductYieldTestCompareTable {...props} />
    </div>
  );
};

const yieldTestCompareTable = (props, actualYieldTestList) => {
  const OneYearYieldTestList = oneYearYieldTestList(actualYieldTestList);
  const lastDate = calculateLastDate(actualYieldTestList);
  return (
    <div>
      {_.isEmpty(OneYearYieldTestList)
        ? yieldTestBeforeOneYear(lastDate)
        : oneYearYieldTestCompareTable(props, OneYearYieldTestList, lastDate)}
    </div>
  );
};

const yieldTestNotAvailable = (
  actualYieldTestsAvailableStatus,
  finishedProductIsReadOnly,
  sourceProductIsReadOnly
) => {
  if (
    actualYieldTestsAvailableStatus === 0 &&
    finishedProductIsReadOnly &&
    sourceProductIsReadOnly
  ) {
    return (
      <div>
        <Divider hidden />
        <div pid='actual-yield-test-not-available'>
          No yield tests have been performed in the last 12 months
        </div>
        <Divider hidden />
      </div>
    );
  }
};

const createYieldModelAndHandleError = (values, props) => {
  const { createOrUpdateCuttingYieldModel } = props;

  const cuttingYieldModelData = buildCuttingYieldModelData(values);
  return createOrUpdateCuttingYieldModel(cuttingYieldModelData);
};

export class CuttingYieldModelFormComponent extends React.Component {
  constructor(props) {
    super(props);
    this.getYieldByproductsInfo = this.getYieldByproductsInfo.bind(this);
    this.handleProductCodeChange = this.handleProductCodeChange.bind(this);
    this.handleFinishedProductCodeBlur = this.handleFinishedProductCodeBlur.bind(this);
    this.handleSourceProductCodeBlur = this.handleSourceProductCodeBlur.bind(this);
    this.submitWithConfirmation = this.submitWithConfirmation.bind(this);
  }

  componentDidMount() {
    const {
      getProduct,
      initialValues,
      getActualYieldTests,
      yieldModelId,
      calculateFinishedCost
    } = this.props;

    if (yieldModelId && initialValues.sourceProductCode) {
      getActualYieldTests(yieldModelId);
    }

    if (initialValues.sourceProductCode) {
      getProduct(initialValues.sourceProductCode);
    }

    if (initialValues.finishedProductCode) {
      getProduct(initialValues.finishedProductCode);
    }

    if (initialValues.yieldByproducts) {
      this.getYieldByproductsInfo(initialValues.yieldByproducts);
    }

    if (initialValues.yieldAdditives) {
      this.getYieldAdditivesInfo(initialValues.yieldAdditives);
    }

    if (!_.isEmpty(initialValues.finishedProductCode)) {
      calculateFinishedCost(initialValues);
    }
  }

  componentWillUnmount() {
    const { finishedProductCode, sourceProductCode, clearYieldModelInfo, hideModal } = this.props;
    if (!_.isEmpty(finishedProductCode)) {
      this.props.setProductExistTo('finishedProductCode', true);
    }

    if (!_.isEmpty(sourceProductCode)) {
      this.props.setProductExistTo('sourceProductCode', true);
    }

    clearYieldModelInfo();
    hideModal();
  }

  getYieldByproductsInfo(yieldByproducts) {
    const { getProduct, checkByProduct } = this.props;
    if (yieldByproducts && !_.isEmpty(yieldByproducts)) {
      yieldByproducts.forEach(yieldModelByProduct => {
        const byProductCode = yieldModelByProduct.byproductCode;
        if (byProductCode) {
          getProduct(byProductCode);
        }

        const { pricingModelCostsAndLabors } = this.props;

        if (
          !_.isEmpty(yieldModelByProduct) &&
          (_.isEmpty(pricingModelCostsAndLabors) ||
            _.isEmpty(pricingModelCostsAndLabors[yieldModelByProduct.byproductCode]))
        ) {
          checkByProduct(yieldModelByProduct);
        }
      });
    }
  }

  getYieldAdditivesInfo(yieldAdditives) {
    const { getProduct } = this.props;
    if (yieldAdditives && !_.isEmpty(yieldAdditives)) {
      yieldAdditives.forEach(yieldModelAdditive => {
        const productCode = yieldModelAdditive.productCode;
        if (productCode) {
          getProduct(productCode);
        }
      });
    }
  }

  submitWithConfirmation(values) {
    const { pricingModel } = values;
    const { isYieldModelCurrentPricingModel } = this.props;

    Validator.validateSubmission(values, this.props);

    if (!isYieldModelCurrentPricingModel && pricingModel) {
      this.createPricingModelConfirmationModal(values);
    } else {
      return createYieldModelAndHandleError(values, this.props);
    }
  }

  createPricingModelConfirmationModal(values) {
    const { finishedProductCode, productsDuplicate, showModal, changeFieldValue } = this.props;
    const product = productsDuplicate[finishedProductCode];
    const doesProductHaveProductGroup = product && product.productGroup;
    const isProductGroupDifferentThanCurrentProduct =
      doesProductHaveProductGroup && product.productGroup.name !== finishedProductCode;

    let content = isProductGroupDifferentThanCurrentProduct
      ? PRICING_MODEL_MOVE_CONFIRMATION_MESSAGE
      : PRICING_MODEL_CONFIRMATION_MESSAGE;

    showModal({
      confirmButton: 'OK',
      content,
      cancelButton: 'Cancel',
      header: 'Continue with setting as pricing model?',
      confirmAction: () => createYieldModelAndHandleError(values, this.props),
      cancelAction: () => changeFieldValue('pricingModel', false)
    });
  }

  handleProductCodeChange(event, productCode, prevValue, fieldName) {
    const { setProductExistTo } = this.props;
    if (!_.isEmpty(productCode)) {
      setProductExistTo(fieldName, true);
    }
  }

  handleFinishedProductCodeBlur(event, normalizedProductCode, prevValue, fieldName) {
    const { getYieldModel, getProduct, setProductExistTo } = this.props;
    if (!_.isEmpty(normalizedProductCode)) {
      getProduct(normalizedProductCode, () => setProductExistTo(fieldName, false));
    }

    return getYieldModel(normalizedProductCode, null, selector).then(
      yieldModel => {
        this.getYieldByproductsInfo(yieldModel.yieldByproducts);
      },
      () => {
        // No-Op on error
      }
    );
  }

  handleSourceProductCodeBlur(event, normalizedProductCode, prevValue, fieldName) {
    const { getYieldModel, getProduct, setProductExistTo } = this.props;

    if (!_.isEmpty(normalizedProductCode)) {
      getProduct(normalizedProductCode, () => setProductExistTo(fieldName, false));
    }
    return getYieldModel(null, normalizedProductCode, selector).then(
      yieldModel => {
        this.getYieldByproductsInfo(yieldModel.yieldByproducts);
      },
      () => {
        // No-Op on error
      }
    );
  }

  render() {
    const {
      handleSubmit,
      isYieldModelCurrentPricingModel,
      products,
      productsDuplicate,
      finishedProductCode,
      sourceProductCode,
      estimatedYield,
      finishedProductCost,
      byproductValue,
      sourceProductCost,
      productsExist,
      finishedProductIsReadOnly,
      sourceProductIsReadOnly,
      additivesValue,
      actualYieldTestsAvailableStatus,
      actualYieldTestList
    } = this.props;

    return (
      <div className={'create-yield-model-form'}>
        <Form size={'large'} onSubmit={handleSubmit(this.submitWithConfirmation)}>
          <Divider hidden />
          <Grid>
            <Grid.Row>
              <Grid.Column width={11}>
                <Field
                  component={ProductDuplicate}
                  name='finishedProductCode'
                  autoFocus={true}
                  useDotDotDot={false}
                  descriptionFontSize={'15px'}
                  label='Finished Product #'
                  product={productsDuplicate[finishedProductCode] || {}}
                  normalize={normalizeProductCode}
                  maxLength={7}
                  message={
                    _.get(productsExist, 'finishedProductCode', true) ? null : NOT_A_PRODUCT_CODE
                  }
                  onBlur={this.handleFinishedProductCodeBlur}
                  onChange={this.handleProductCodeChange}
                  readonly={finishedProductIsReadOnly}
                />

                <Divider hidden />

                <Field
                  component={ProductDuplicate}
                  useDotDotDot={false}
                  descriptionFontSize={'15px'}
                  name='sourceProductCode'
                  label='Source Product #'
                  product={productsDuplicate[sourceProductCode] || {}}
                  normalize={normalizeProductCode}
                  maxLength={7}
                  message={
                    _.get(productsExist, 'sourceProductCode', true)
                      ? Validator.validateSourceProduct(this.props)
                      : NOT_A_PRODUCT_CODE
                  }
                  onBlur={this.handleSourceProductCodeBlur}
                  onChange={this.handleProductCodeChange}
                  readonly={sourceProductIsReadOnly}
                />
              </Grid.Column>
              <Grid.Column width={2}>
                <FormLabel
                  label='ESTIMATED YIELD %'
                  value={formatNumberToTwoDecimalPlacesStringIncludeZero(estimatedYield)}
                  width={16}
                />
                <FormLabel
                  label='BYPRODUCT CREDIT'
                  value={formatNumberToTwoDecimalPlacesStringIncludeZero(byproductValue)}
                  width={16}
                />
              </Grid.Column>
              <Grid.Column width={3}>
                <FormLabel
                  width={10}
                  label='UNIT COST PER LB'
                  value={formatNumberToTwoDecimalPlacesStringIncludeZero(finishedProductCost)}
                />
              </Grid.Column>
            </Grid.Row>
          </Grid>

          <Divider hidden />

          <Form.Group>
            <CuttingYieldModelPricingFactors
              sourceProductCost={sourceProductCost}
              additives={additivesValue}
            />
            <Field
              component={PricingModelCheckBox}
              className='price-model-check'
              isYieldModelCurrentPricingModel={isYieldModelCurrentPricingModel}
              name='pricingModel'
              label='Pricing Model'
              width={3}
            />
          </Form.Group>

          <Divider hidden />

          <Form.Group>
            <FieldArray
              name={'yieldByproducts'}
              component={ByproductTable}
              props={{ products, productsExist }}
            />
          </Form.Group>

          <Divider hidden />

          <Form.Group>
            <FieldArray
              name={'yieldAdditives'}
              component={AdditiveTable}
              props={{ products, productsExist }}
            />
          </Form.Group>

          <Divider hidden />

          <Form.Group>
            <Field component={FormElement} name='sourceLbs' as={Form.Input} label='Source Lbs' />
            <Field
              component={FormElement}
              name='pickupPercent'
              as={Form.Input}
              label='Pickup %'
              normalize={normalizeToTwoDecimalPlaces}
            />
          </Form.Group>

          <Divider hidden />

          <Form.Group>
            <SaveButton {...this.props} />
            {getYieldModelCostErrorsMessage(this.props)}
          </Form.Group>
        </Form>

        {!_.isEmpty(actualYieldTestList)
          ? yieldTestCompareTable(this.props, actualYieldTestList)
          : yieldTestNotAvailable(
              actualYieldTestsAvailableStatus,
              finishedProductIsReadOnly,
              finishedProductIsReadOnly
            )}
      </div>
    );
  }
}

CuttingYieldModelFormComponent.propTypes = {
  finishedProductCode: PropTypes.string,
  sourceProductCode: PropTypes.string,
  getYieldModel: PropTypes.func.isRequired,
  changeFieldValue: PropTypes.func,
  clearYieldModelInfo: PropTypes.func.isRequired,
  createOrUpdateCuttingYieldModel: PropTypes.func,
  sourceProductCost: PropTypes.number,
  productOutput: PropTypes.oneOf(['FINISHED', 'SOURCE', 'BYPRODUCT_ONLY']),
  isYieldModelCurrentPricingModel: PropTypes.bool,
  estimatedYield: PropTypes.number,
  getProduct: PropTypes.func.isRequired,
  setProductExistTo: PropTypes.func,
  byproductValue: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  finishedProductCost: PropTypes.number,
  additivesValue: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  products: PropTypes.object,
  productsDuplicate: PropTypes.object.isRequired,
  yieldModel: PropTypes.object,
  submitting: PropTypes.bool,
  handleSubmit: PropTypes.func.isRequired,
  initialValues: PropTypes.object,
  finishedProductCostError: PropTypes.string,
  byproductValueError: PropTypes.string,
  error: PropTypes.string,
  productsExist: PropTypes.object,
  finishedProductIsReadOnly: PropTypes.bool,
  sourceProductIsReadOnly: PropTypes.bool,
  yieldModelId: PropTypes.number,
  getActualYieldTests: PropTypes.func.isRequired,
  actualYieldPercent: PropTypes.number,
  actualUnitCostPerLb: PropTypes.number,
  actualByproducts: PropTypes.array,
  actualYieldTestList: PropTypes.array,
  actualYieldTestsAvailableStatus: PropTypes.number,
  calculateFinishedCost: PropTypes.func,
  byproductCredit: PropTypes.number,
  showModal: PropTypes.func,
  hideModal: PropTypes.func,
  pricingModelCostsAndLabors: PropTypes.object,
  checkByProduct: PropTypes.func,
  additiveSourceItem: PropTypes.bool.isRequired
};

const mapDispatchToProps = dispatch => {
  const changeFieldValue = (field, value) =>
    dispatch(change(CUTTING_YIELD_MODEL_FORM_NAME, field, value));
  return bindActionCreators(
    {
      getYieldModel,
      getProduct,
      setProductExistTo,
      clearYieldModelInfo,
      changeFieldValue,
      createOrUpdateCuttingYieldModel,
      getActualYieldTests,
      calculateFinishedCost,
      showModal,
      hideModal,
      checkByProduct
    },
    dispatch
  );
};

export const mapStateToProps = state => {
  const {
    id,
    labor,
    packaging,
    overhead,
    finishedProductCode,
    sourceProductCode,
    pricingModel,
    additives,
    byproductCredit,
    estimatedYield,
    yieldModelCurrentPricingModel,
    sourceLbs,
    finishedProductCost,
    pickupPercent
  } = state.cuttingYieldModelInfo.yieldModel;
  const {
    actualYieldPercent,
    actualUnitCostPerLb,
    actualByproducts,
    actualYieldTestList
  } = state.cuttingYieldModelInfo.actualYieldTests;
  const actualYieldTestsAvailableStatus =
    state.cuttingYieldModelInfo.actualYieldTestsAvailableStatus;
  const yieldModelId = id;
  const productsDuplicate = state.productDuplicate.products;

  const products = state.productDuplicate.products ? state.productDuplicate.products : {};
  const productsExist = state.productDuplicate.productsExist || {};
  const additiveSourceItem = state.productDuplicate.additiveSourceItem;

  const initFinishedProductCode = state.cuttingYieldModelInfo.initFinishedProductCode;

  const formFinishedProductCode = selector(state, 'finishedProductCode');
  const formSourceProductCode = selector(state, 'sourceProductCode');

  const sourceProductCost = _.get(
    state.productDuplicate,
    `products[${formSourceProductCode}].cost`
  );
  const productOutput = _.get(
    state.productDuplicate,
    `products[${formFinishedProductCode}].productOutput`
  );

  const {
    finishedProductIsReadOnly,
    sourceProductIsReadOnly,
    pricingModelCostsAndLabors
  } = state.cuttingYieldModelInfo;

  const additivesState = additivesMapStateToPropsForYieldModelForm(state);
  const byproductsState = byproductsMapStateToPropsForYieldModelForm(state);

  return {
    initialValues: {
      labor: formatNumberToTwoDecimalPlacesString(labor),
      packaging: formatNumberToTwoDecimalPlacesString(packaging),
      overhead: formatNumberToTwoDecimalPlacesString(overhead),
      finishedProductCode: finishedProductCode || initFinishedProductCode,
      sourceProductCode,
      pricingModel: !!pricingModel,
      sourceLbs: sourceLbs || '',
      pickupPercent: pickupPercent || '',
      ...additivesState.initialValues,
      ...byproductsState.initialValues
    },
    pricingModelCostsAndLabors,
    isYieldModelCurrentPricingModel: !!yieldModelCurrentPricingModel,
    productOutput,
    sourceProductCost,
    productsDuplicate,
    products,
    finishedProductCost,
    estimatedYield: estimatedYield,
    byproductValue: byproductCredit,
    additivesValue: additives,
    finishedProductCode: formFinishedProductCode,
    sourceProductCode: formSourceProductCode,
    finishedProductCostError: getFormSubmitErrors(CUTTING_YIELD_MODEL_FORM_NAME)(state)
      .finishedProductCost,
    byproductValueError: getFormSubmitErrors(CUTTING_YIELD_MODEL_FORM_NAME)(state).byproductValue,
    productsExist,
    finishedProductIsReadOnly,
    sourceProductIsReadOnly,
    yieldModelId,
    actualYieldPercent,
    actualUnitCostPerLb,
    actualByproducts,
    actualYieldTestList,
    actualYieldTestsAvailableStatus,
    additiveSourceItem
  };
};

const onSubmit = (values, dispatch, props) => {
  const { createOrUpdateCuttingYieldModel } = props;

  Validator.validateSubmission(values, props);

  const cuttingYieldModelData = buildCuttingYieldModelData(values);
  return createOrUpdateCuttingYieldModel(cuttingYieldModelData);
};

export const asyncValidate = (values, dispatch, props) => {
  return updateFinishedCost(values, props);
};

const updateFinishedCost = (values, props) => {
  const errors = Validator.validateFields(values);

  if (_.isEmpty(errors)) {
    const cuttingYieldModelData = buildCuttingYieldModelData(values);
    return props.calculateFinishedCost(cuttingYieldModelData);
  }
  return Promise.reject(errors);
};

const buildCuttingYieldModelData = values => {
  const {
    finishedProductCode,
    sourceProductCode,
    labor,
    packaging,
    overhead,
    pricingModel,
    yieldByproducts,
    yieldAdditives,
    sourceLbs,
    pickupPercent
  } = values;

  const preciseYieldByproducts = yieldByproducts
    .filter(yieldByproduct => !_.isEmpty(yieldByproduct) && yieldByproduct.byproductCode)
    .map(yieldByproduct => {
      const {
        id,
        byproductCode,
        cost,
        labor,
        overhead,
        packaging,
        yieldPercentage
      } = yieldByproduct;
      return {
        id,
        byproductCode,
        cost: toPrecision(zeroIfInvalid(cost), 2),
        labor: toPrecision(zeroIfInvalid(labor), 2),
        packaging: toPrecision(zeroIfInvalid(packaging), 2),
        overhead: toPrecision(zeroIfInvalid(overhead), 2),
        yieldPercentage: toPrecision(zeroIfInvalid(yieldPercentage), 2)
      };
    });

  const preciseYieldAdditives = yieldAdditives
    .filter(yieldAdditive => !_.isEmpty(yieldAdditive) && yieldAdditive.productCode)
    .map(yieldAdditive => {
      const { id, productCode, cost, weight } = yieldAdditive;
      return {
        id,
        productCode,
        weight: toPrecision(zeroIfInvalid(weight), 2),
        cost: toPrecision(zeroIfInvalid(cost), 2)
      };
    });

  return {
    sourceProductCode: sourceProductCode,
    finishedProductCode: finishedProductCode,
    labor: toPrecision(zeroIfInvalid(labor), 2),
    packaging: toPrecision(zeroIfInvalid(packaging), 2),
    overhead: toPrecision(zeroIfInvalid(overhead), 2),
    pricingModel,
    yieldByproducts: preciseYieldByproducts,
    yieldAdditives: preciseYieldAdditives,
    sourceLbs,
    pickupPercent: pickupPercent && toPrecision(pickupPercent, 2)
  };
};

const CuttingYieldModelForm = connect(
  mapStateToProps,
  mapDispatchToProps
)(
  reduxForm({
    form: CUTTING_YIELD_MODEL_FORM_NAME,
    asyncValidate,
    enableReinitialize: true,
    asyncBlurFields: [
      'finishedProductCode',
      'sourceProductCode',
      'labor',
      'packaging',
      'overhead',
      'additives',
      'pricingModel',
      'sourceLbs',
      'pickupPercent',
      'yieldByproducts[].byproductCode', // byProductCode only blur
      'yieldByproducts[].yieldPercentage',
      'yieldByproducts[].labor',
      'yieldByproducts[].cost',
      'yieldAdditives[].weight',
      'yieldAdditives[].productCode'
    ],
    asyncChangeFields: [
      'finishedProductCode',
      'sourceProductCode',
      'labor',
      'packaging',
      'overhead',
      'additives',
      'pricingModel',
      'sourceLbs',
      'pickupPercent',
      'yieldByproducts[].yieldPercentage',
      'yieldByproducts[].labor',
      'yieldByproducts[].cost',
      'yieldAdditives[].weight',
      'yieldAdditives[].productCode'
    ],
    onSubmit
  })(CuttingYieldModelFormComponent)
);

export default CuttingYieldModelForm;
