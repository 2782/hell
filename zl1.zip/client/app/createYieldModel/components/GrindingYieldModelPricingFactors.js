import React, { Fragment } from 'react';
import { Field } from 'redux-form';
import { normalizeToTwoDecimalPlaces } from '../../shared/components/product/normalizer';
import { Form } from 'semantic-ui-react';
import FormElement from '../../shared/FormElement';

const GrindingYieldModelPricingFactors = () => {
  return (
    <Fragment>
      <Field
        component={FormElement}
        name='wastePercentage'
        as={Form.Input}
        type='text'
        label='waste %'
        width={2}
        normalize={normalizeToTwoDecimalPlaces}
      />
      <Field
        component={FormElement}
        name='labor'
        as={Form.Input}
        type='text'
        label='Labor'
        width={2}
        normalize={normalizeToTwoDecimalPlaces}
      />
      <Field
        component={FormElement}
        name='additives'
        as={Form.Input}
        type='text'
        label='additives'
        width={2}
        normalize={normalizeToTwoDecimalPlaces}
      />
      <Field
        component={FormElement}
        name='packaging'
        as={Form.Input}
        type='text'
        label='packaging'
        width={2}
        normalize={normalizeToTwoDecimalPlaces}
      />
      <Field
        component={FormElement}
        name='overhead'
        as={Form.Input}
        type='text'
        label='overhead'
        width={2}
        normalize={normalizeToTwoDecimalPlaces}
      />
    </Fragment>
  );
};

export default GrindingYieldModelPricingFactors;
