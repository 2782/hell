import settingsResources from '../../shared/api/settingsResources';
import {
  ALL_CUSTOMERS_RECEIVED,
  CLEAR_CUSTOMER,
  CLEAR_HOUSE_PAR,
  CLEAR_PROFILE_INFO,
  CLEAR_STATION,
  CLEAR_TABLE,
  DELETE_HOLIDAY,
  EDITING_ALLOWED,
  EDITING_OVER,
  GET_ACTIVE_FISCAL_CALENDAR,
  GET_CUSTOMER,
  GET_PROFILE,
  GRABBED_SUB_PRIMAL,
  HIDE_ERROR,
  SHOW_ERROR,
  SUBPRIMAL_EXISTS_FLAG_CHANGED,
  UPDATE_GRINDING_HOUSE_PARS,
  UPDATE_HOLIDAYS,
  UPDATE_HOUSE_PAR,
  UPDATE_HOUSE_PARS,
  UPDATE_ROOMS,
  UPDATE_STATION,
  UPDATE_STATIONS,
  UPDATE_TABLE,
  UPDATE_TABLES,
  UPDATE_WEEKEND,
  UPDATE_WEEKENDS
} from './settingsActionTypes';
import { replacePath } from '../../shared/actions/actions';
import fiscalCalendarResources from '../../shared/api/fiscalCalendarResources';
import _ from 'lodash';
import { processErrorResponse } from '../components/customerPackOffLabelSettingValidator';
import { displayDateToIsoDate, isoDateToDisplayDate } from '../../shared/util/dateUtil';
import { processTableErrorResponse } from '../components/createTableValidator';

export const getStations = () => {
  return dispatch => {
    settingsResources.getStations(response => {
      dispatch({
        type: UPDATE_STATIONS,
        payload: response.data
      });
    });
  };
};

export const clearStation = () => dispatch => {
  dispatch({
    type: CLEAR_STATION
  });
};

export const clearTable = () => dispatch => {
  dispatch({
    type: CLEAR_TABLE
  });
};

export const getStation = stationId => {
  return dispatch => {
    settingsResources.getStation(stationId, response => {
      dispatch({
        type: UPDATE_STATION,
        payload: response.data
      });
    });
  };
};

export const createStation = (station, rejectCallback = () => {}) => {
  return dispatch => {
    return settingsResources.createStation(
      station,
      () => dispatch(replacePath('/settings/stations')),
      rejectCallback
    );
  };
};

export const updateStation = (station, rejectCallback = () => {}) => {
  return dispatch => {
    return settingsResources.updateStation(
      station,
      () => dispatch(replacePath('/settings/stations')),
      rejectCallback
    );
  };
};

export const createRoom = (room, rejectCallback) => {
  return dispatch => {
    return settingsResources.createRoom(
      room,
      () => dispatch(replacePath('/settings/rooms')),
      rejectCallback
    );
  };
};

export const createOrUpdateHousePar = (housePar, rejectCallback) => {
  const resource = housePar.id
    ? settingsResources.updateHousePar
    : settingsResources.createHousePar;
  const removeUnusableParConfig = housePar => {
    return _.omitBy(housePar, value => {
      return value === '' || parseInt(value) === 0;
    });
  };

  return dispatch => {
    return resource(
      removeUnusableParConfig(housePar),
      () => dispatch(replacePath('/settings/house-pars')),
      rejectCallback
    );
  };
};

export const getHousePar = productCode => {
  return dispatch => {
    return settingsResources.getHousePar(productCode, response => {
      dispatch({
        type: UPDATE_HOUSE_PAR,
        payload: response.data
      });
    });
  };
};

export const deleteHousePar = productCode => {
  return dispatch => {
    return settingsResources.deleteHousePar(productCode, () => {
      getHousePars()(dispatch);
    });
  };
};

export const getWeekends = () => {
  return dispatch => {
    settingsResources.getWeekends(response => {
      dispatch({
        type: UPDATE_WEEKENDS,
        payload: response
      });
    });
  };
};

export const updateWeekend = data => {
  return dispatch => {
    settingsResources.updateSystemConfig(data, response => {
      dispatch({
        type: UPDATE_WEEKEND,
        payload: response
      });
    });
  };
};

export const createHoliday = holiday => {
  return dispatch => {
    holiday.date = displayDateToIsoDate(holiday.date);
    settingsResources.createHoliday(
      holiday,
      () => {
        dispatch(getHolidays());
      },
      error => {
        dispatch({
          type: SHOW_ERROR,
          payload: error
        });
      }
    );
  };
};

export const showError = errorMsg => {
  return dispatch => {
    dispatch({
      type: SHOW_ERROR,
      payload: { message: errorMsg, showing: true }
    });
  };
};

export const hideError = () => {
  return dispatch => {
    dispatch({
      type: HIDE_ERROR
    });
  };
};

export const getHolidays = () => {
  return dispatch => {
    settingsResources.getHolidays(response => {
      response.data.map(a => (a.date = isoDateToDisplayDate(a.date)));
      dispatch({
        type: UPDATE_HOLIDAYS,
        payload: response.data
      });
    });
  };
};

export const allowToEditHoliday = holidayData => dispatch => {
  dispatch({
    type: EDITING_ALLOWED,
    payload: holidayData
  });
};

export const cancelEditingHoliday = () => dispatch => {
  dispatch({
    type: EDITING_OVER
  });
};

export const editHoliday = (id, values) => dispatch => {
  const modifiedValues = { ...values, date: displayDateToIsoDate(values.date) };
  return settingsResources.editHoliday(modifiedValues, id).then(response => {
    dispatch({
      type: EDITING_OVER
    });
    return response.data;
  });
};

export const deleteHoliday = id => {
  return dispatch => {
    settingsResources.deleteHoliday(id, () => {
      dispatch({
        type: DELETE_HOLIDAY,
        payload: id
      });
    });
  };
};

export const getTables = () => {
  return dispatch => {
    settingsResources.getTables(response => {
      dispatch({
        type: UPDATE_TABLES,
        payload: response.data
      });
    });
  };
};

export const getProfile = () => {
  return dispatch => {
    settingsResources.getProfile(response => {
      dispatch({
        type: GET_PROFILE,
        payload: response.data
      });
    });
  };
};

export const getTable = tableId => {
  return dispatch => {
    settingsResources.getTable(tableId, response => {
      dispatch({
        type: UPDATE_TABLE,
        payload: {
          ...response.data
        }
      });
    });
  };
};

export const createTable = table => dispatch => {
  const request = {
    tableCode: table.tableCode,
    tableDescription: table.tableDescription,
    tableOpenTime: table.tableOpenTime,
    tableCloseTime: table.tableCloseTime,
    poundsPerHour: table.poundsPerHour,
    station: {
      id: table.station.id
    }
  };

  return settingsResources.createTable(request).then(
    () => dispatch(replacePath('/settings/tables')),
    error => {
      processTableErrorResponse(_.get(error, 'response.data', {}));
      return Promise.reject('Create Table failed!');
    }
  );
};

export const updateTable = (tableId, table) => dispatch => {
  const request = {
    tableCode: table.tableCode,
    tableDescription: table.tableDescription,
    tableOpenTime: table.tableOpenTime,
    tableCloseTime: table.tableCloseTime,
    poundsPerHour: table.poundsPerHour,
    station: {
      id: table.station.id
    }
  };

  return settingsResources.updateTable(tableId, request).then(
    () => dispatch(replacePath('/settings/tables')),
    error => {
      processTableErrorResponse(_.get(error, 'response.data', {}));
      return Promise.reject('Update Table failed!');
    }
  );
};

export const getRooms = () => dispatch => {
  return settingsResources.getRooms().then(response => {
    dispatch({
      type: UPDATE_ROOMS,
      payload: response.data
    });
  });
};

export const createOrUpdateProfile = profile => {
  return dispatch => {
    settingsResources.createOrUpdateProfile(
      profile,
      () => {
        dispatch({
          type: GET_PROFILE,
          payload: profile
        });
      },
      error => {
        dispatch({
          type: SHOW_ERROR,
          payload: error
        });
      }
    );
  };
};

export const clearProfileInfo = () => {
  return dispatch => {
    dispatch({
      type: CLEAR_PROFILE_INFO
    });
  };
};

export const getHousePars = () => {
  return dispatch => {
    settingsResources.getHousePars(response => {
      dispatch({
        type: UPDATE_HOUSE_PARS,
        payload: response.data
      });
    });
  };
};

export const clearHousePar = () => dispatch => {
  dispatch({
    type: CLEAR_HOUSE_PAR
  });
};

export const getActiveFiscalCalendar = () => {
  return dispatch => {
    fiscalCalendarResources.getActiveFiscalCalendar(response => {
      response.data.nextStartDate = isoDateToDisplayDate(response.data.nextStartDate);
      response.data.startDate = isoDateToDisplayDate(response.data.startDate);
      dispatch({
        type: GET_ACTIVE_FISCAL_CALENDAR,
        payload: response.data
      });
    });
  };
};

export const updateActiveFiscalCalendar = (data, rejectCallback = () => {}) => {
  return dispatch => {
    data.nextStartDate = displayDateToIsoDate(data.nextStartDate);
    fiscalCalendarResources.updateActiveFiscalCalendar(
      data,
      response => {
        response.data.nextStartDate = isoDateToDisplayDate(response.data.nextStartDate);
        response.data.startDate = isoDateToDisplayDate(response.data.startDate);
        dispatch({
          type: GET_ACTIVE_FISCAL_CALENDAR,
          payload: response.data
        });
      },
      rejectCallback
    );
  };
};

export const getAvailableGrindingHousePar = (successCallback = () => {}) => {
  return (dispatch, getState) => {
    const roomCode = getState().portionRoomsInfo.currentPortionRoom.code;
    settingsResources.getAvailableGrindingHousePar(roomCode, response => {
      dispatch({
        type: UPDATE_GRINDING_HOUSE_PARS,
        payload: response.data
      });
      successCallback(response.data);
    });
  };
};

export const getCustomers = () => dispatch => {
  return settingsResources.getCustomers().then(response => {
    dispatch({
      type: ALL_CUSTOMERS_RECEIVED,
      payload: response.data
    });
  });
};

export const getCustomer = customerCode => dispatch => {
  return settingsResources.getCustomer(customerCode).then(response => {
    dispatch({
      type: GET_CUSTOMER,
      payload: response.data
    });
  });
};

export const setupCustomer = data => (dispatch, getState) => {
  const selectedFile = getState().uploadFileReducer.selectedFile;

  return settingsResources.setupCustomer(data, selectedFile).then(
    response => {
      dispatch({
        type: GET_CUSTOMER,
        payload: response.data
      });
      dispatch(replacePath('/settings/customers-packoff-display'));
    },
    error => {
      processErrorResponse(_.get(error, 'response.data', {}));
      return Promise.reject('Customer Packoff Label Setting failed!');
    }
  );
};

export const clearCustomer = () => dispatch => {
  dispatch({
    type: CLEAR_CUSTOMER
  });
};

export const getSubPrimal = (subPrimalCode, errorCallback) => {
  return dispatch => {
    return settingsResources.getSubPrimal(
      subPrimalCode,
      response => {
        dispatch({
          type: GRABBED_SUB_PRIMAL,
          payload: response.data
        });
      },
      errorCallback
    );
  };
};

export const setSubPrimalExistTo = (fieldName, flag) => dispatch => {
  return dispatch({
    type: SUBPRIMAL_EXISTS_FLAG_CHANGED,
    payload: {
      fieldName: fieldName,
      flag: flag
    }
  });
};
