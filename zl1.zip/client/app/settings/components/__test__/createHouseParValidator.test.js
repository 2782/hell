import {
  processErrorResponse,
  processProductCodeError,
  validateSubmission
} from '../createHouseParValidator';
import {
  CREATE_HOUSE_PAR_MESSAGE,
  NOT_A_PRODUCTION_PRODUCT,
  PRODUCT_LACKS_PRICING_MODEL,
  PRODUCT_SETUP_IS_INCOMPLETE,
  UPDATE_HOUSE_PAR_MESSAGE
} from '../../../../config/errorMessage';
import productFactory from '../../../../test-factories/productFactory';

const product = productFactory.build();

describe('createHouseParValidator', () => {
  const VALID_PRODUCT_CODE = '0078889';

  describe('submission validation', () => {
    test('should call submit with given values', () => {
      validateSubmission(
        {
          productCode: VALID_PRODUCT_CODE,
          monday: 1
        },
        {
          product: product,
          productIsProduction: true,
          productHasPricingModel: true
        }
      );
    });

    test('should check that some fields are required', () => {
      try {
        validateSubmission({}, {});
        jest.fail('Expected SubmissionError to be thrown.');
      } catch ({ errors }) {
        jestExpect(errors).toEqual({
          productCode: 'Required',
          monday: 'At least one field required',
          _error: CREATE_HOUSE_PAR_MESSAGE
        });
      }
    });

    test('should validate that product code are wholeNumber', () => {
      const values = {
        productCode: 'abc123',
        monday: 1
      };

      try {
        validateSubmission(values, {
          product: product,
          productIsProduction: true,
          productHasPricingModel: true
        });
        jest.fail('Expected SubmissionError to be thrown.');
      } catch ({ errors }) {
        jestExpect(errors).toEqual({
          productCode: 'Only whole number characters',
          _error: CREATE_HOUSE_PAR_MESSAGE
        });
      }
    });

    test('should validate that product code are exactly 7 characters', () => {
      const values = {
        productCode: '0123123123',
        monday: 1
      };

      try {
        validateSubmission(values, {
          product: product,
          productIsProduction: true,
          productHasPricingModel: true
        });
        jest.fail('Expected SubmissionError to be thrown.');
      } catch ({ errors }) {
        jestExpect(errors).toEqual({
          productCode: 'Must be 7 characters',
          _error: CREATE_HOUSE_PAR_MESSAGE
        });
      }
    });

    test('should validate that product is production', () => {
      const values = {
        productCode: VALID_PRODUCT_CODE,
        monday: 1
      };

      try {
        validateSubmission(values, {
          product: product,
          productIsProduction: false,
          productHasPricingModel: true
        });
        jest.fail('Expected SubmissionError to be thrown.');
      } catch ({ errors }) {
        jestExpect(errors).toEqual({
          productCode: NOT_A_PRODUCTION_PRODUCT,
          _error: CREATE_HOUSE_PAR_MESSAGE
        });
      }
    });

    test('should validate that product has a pricing model', () => {
      const values = {
        productCode: VALID_PRODUCT_CODE,
        monday: 1
      };

      try {
        validateSubmission(values, {
          product: product,
          productIsProduction: true,
          productHasPricingModel: false
        });
        jest.fail('Expected SubmissionError to be thrown.');
      } catch ({ errors }) {
        jestExpect(errors).toEqual({
          productCode: PRODUCT_LACKS_PRICING_MODEL,
          _error: CREATE_HOUSE_PAR_MESSAGE
        });
      }
    });

    test('should validate that product has max and min weight', () => {
      const values = {
        productCode: VALID_PRODUCT_CODE,
        monday: 1
      };

      try {
        validateSubmission(values, {
          product: productFactory.build({ maxWeight: null, minWeight: null }),
          productIsProduction: true,
          productHasPricingModel: true
        });
        jest.fail('Expected SubmissionError to be thrown.');
      } catch ({ errors }) {
        jestExpect(errors).toEqual({
          productCode: PRODUCT_SETUP_IS_INCOMPLETE,
          _error: CREATE_HOUSE_PAR_MESSAGE
        });
      }
    });

    test('should check that par config At least one field required', () => {
      try {
        validateSubmission(
          {
            productCode: VALID_PRODUCT_CODE
          },
          {
            productIsProduction: true,
            product: product,
            productHasPricingModel: true
          }
        );
        jest.fail('Expected SubmissionError to be thrown.');
      } catch ({ errors }) {
        jestExpect(errors).toEqual({
          monday: 'At least one field required',
          _error: CREATE_HOUSE_PAR_MESSAGE
        });
      }
    });
  });

  describe('processing API errors', () => {
    test('should throw generic submission failed error message when there is no UI-processable issue for create', () => {
      try {
        processErrorResponse(
          {
            update: false,
            error: {
              details: [
                {
                  issue: 'SOME_OTHER_ISSUE',
                  value: '0079002'
                }
              ]
            }
          },
          {
            productCode: 'SOME_OTHER_ISSUE',
            monday: 1
          }
        );
        jest.fail();
      } catch ({ errors }) {
        jestExpect(errors).toEqual({ _error: CREATE_HOUSE_PAR_MESSAGE });
      }
    });

    test('should throw generic submission failed error message when there is no UI-processable issue for update', () => {
      try {
        processErrorResponse(
          {
            update: true,
            error: {
              details: [
                {
                  issue: 'SOME_OTHER_ISSUE',
                  value: '0079002'
                }
              ]
            }
          },
          {
            productCode: 'SOME_OTHER_ISSUE',
            monday: 1
          }
        );
        jest.fail();
      } catch ({ errors }) {
        jestExpect(errors).toEqual({ _error: UPDATE_HOUSE_PAR_MESSAGE });
      }
    });
  });

  describe('processing product code errors', () => {
    test('should return errors without product code error if not productCode error ', () => {
      const errors = {};
      const newErrors = processProductCodeError(errors, [], {}, false);
      jestExpect(newErrors).toEqual(errors);
    });

    test('should return NOT_A_PRODUCTION_PRODUCT error ', () => {
      const errors = {};
      const errorDetails = [
        {
          field: 'productCode',
          issue: 'PRODUCT_IS_NOT_PRODUCTION_ITEM',
          value: '0079002'
        }
      ];
      const newErrors = processProductCodeError(errors, errorDetails, {}, false);
      jestExpect(newErrors).toEqual({ productCode: NOT_A_PRODUCTION_PRODUCT });
    });

    test('should return PRODUCT_LACKS_PRICING_MODEL error ', () => {
      const errors = {};
      const errorDetails = [
        {
          field: 'productCode',
          issue: 'PRODUCT_LACKS_PRICING_MODEL',
          value: '0079002'
        }
      ];
      const newErrors = processProductCodeError(errors, errorDetails, {}, false);
      jestExpect(newErrors).toEqual({ productCode: PRODUCT_LACKS_PRICING_MODEL });
    });

    test('should return UPDATE_HOUSE_PAR_MESSAGE error when return productCode UNIQUE issue', () => {
      const errors = {};
      const errorDetails = [
        {
          field: 'productCode',
          issue: 'UNIQUE',
          value: '0079002'
        }
      ];
      const newErrors = processProductCodeError(errors, errorDetails, {}, false);
      jestExpect(newErrors).toEqual({ productCode: UPDATE_HOUSE_PAR_MESSAGE });
    });

    test('should return UPDATE_HOUSE_PAR_MESSAGE error when others and update is true', () => {
      const errors = {};
      const errorDetails = [
        {
          field: 'productCode',
          issue: 'SOME_ERROR',
          value: '0079002'
        }
      ];
      const newErrors = processProductCodeError(errors, errorDetails, {}, true);
      jestExpect(newErrors).toEqual({ productCode: UPDATE_HOUSE_PAR_MESSAGE });
    });

    test('should return CREATE_HOUSE_PAR_MESSAGE error when others and update is false', () => {
      const errors = {};
      const errorDetails = [
        {
          field: 'productCode',
          issue: 'SOME_ERROR',
          value: '0079002'
        }
      ];
      const newErrors = processProductCodeError(errors, errorDetails, {}, false);
      jestExpect(newErrors).toEqual({ productCode: CREATE_HOUSE_PAR_MESSAGE });
    });
  });
});
