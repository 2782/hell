import React from 'react';
import { shallow } from 'enzyme';
import { Button, Table } from 'semantic-ui-react';
import EmptyTableMessage from '../../../shared/components/EmptyTableMessage';
import MaintenanceTable from '../MaintenanceTable';
import { renderMaintenanceTableBody } from '../../utils/renderTable';

describe('MaintenanceTable', () => {
  let wrapper;

  const portionRooms = [
    {
      id: 9999999,
      code: 'Q',
      description: 'Goat',
      portionRoomStatus: 'closed',
      roomType: 'CUTTING',
      openable: true
    },
    {
      id: 8888888,
      code: 'B',
      description: 'Steak',
      portionRoomStatus: 'open',
      roomType: 'CUTTING',
      openable: false
    }
  ];

  const createButtonValue = data => {
    return <div>{data.id}</div>;
  };

  const portionRoomColumns = [
    {
      key: 'code',
      pid: 'room-code',
      width: '2',
      headerText: 'Room'
    },
    {
      key: 'description',
      pid: 'room-description',
      width: '6',
      headerText: 'Description'
    },
    {
      key: 'roomType',
      pid: 'room-type',
      width: '5',
      headerText: 'Room Type'
    },
    {
      key: 'createButton',
      pid: 'create-button',
      headerText: (
        <Button primary size={'medium'}>
          <i className='icon-plus' />
          {' New '}
        </Button>
      ),
      value: createButtonValue
    }
  ];

  beforeEach(() => {
    wrapper = mount(
      <MaintenanceTable
        columns={portionRoomColumns}
        items={portionRooms}
        tableBody={renderMaintenanceTableBody}
      />
    );
  });

  test('should render header row', () => {
    const wrapperHeader = wrapper.find(Table.Header);

    jestExpect(wrapperHeader.find('th').at(0)).toHaveText('Room');
    jestExpect(wrapperHeader.find('th').at(1)).toHaveText('Description');
    jestExpect(wrapperHeader.find('th').at(2)).toHaveText('Room Type');
    jestExpect(wrapperHeader.find('th').at(3)).toIncludeText('New');
    jestExpect(
      wrapperHeader
        .find('th')
        .at(3)
        .find('.icon-plus')
    ).toHaveHTML('<i class="icon-plus"></i>');
  });

  test('should render the code, description and room type, with evaluating function in last collumn', () => {
    const wrapperBody = wrapper.find(Table.Body);
    const wrapperItemRow = wrapperBody.find(Table.Row).at(1);

    const firstPortionRoomItem = portionRooms[1];
    jestExpect(wrapperItemRow.find('[pid="maintenance__room-code"]').at(0)).toHaveText(
      firstPortionRoomItem.code
    );
    jestExpect(wrapperItemRow.find('[pid="maintenance__room-description"]').at(0)).toHaveText(
      firstPortionRoomItem.description
    );
    jestExpect(wrapperItemRow.find('[pid="maintenance__room-type"]').at(0)).toHaveText(
      firstPortionRoomItem.roomType
    );
    jestExpect(wrapperItemRow.find('[pid="maintenance__create-button"]').at(0)).toHaveText(
      '8888888'
    );
  });

  test('should render Empty Table with no items', () => {
    const wrapper = shallow(
      <MaintenanceTable
        columns={portionRoomColumns}
        items={[]}
        tableBody={renderMaintenanceTableBody}
      />
    );

    jestExpect(wrapper.find(EmptyTableMessage)).toExist();
  });

  test('should render headers if items is null', () => {
    const wrapper = shallow(
      <MaintenanceTable
        columns={portionRoomColumns}
        items={null}
        tableBody={renderMaintenanceTableBody}
      />
    );

    jestExpect(wrapper.find(EmptyTableMessage)).not.toExist();
    jestExpect(wrapper.find(Table.Header)).toExist();
    jestExpect(wrapper.find(Table.Body)).not.toExist();
  });
});
