import {
  processTableErrorResponse,
  validateField,
  validateSubmission
} from '../createTableValidator';
import { INVALID_TIME_MESSAGE, MUST_BE_UNIQUE_MESSAGE } from '../../../../config/errorMessage';

describe('createTableValidator', () => {
  describe('processTableErrorResponse', () => {
    test('should parse the error response for tableCode', () => {
      const errorResponse = {
        timestamp: 1569522047705,
        method: 'POST',
        path: '/api/portion-room-tables',
        status: 422,
        statusText: 'Unprocessable Entity',
        exceptionClass: 'com.sysco.prime.exception.InvalidValueException',
        exceptionMessage: 'table code must be unique',
        error: {
          name: 'VALIDATION_ERROR',
          details: [
            { field: 'tableCode', value: null, issue: 'UNIQUE', location: 'body', type: null }
          ],
          message: 'Saving portion room failed.'
        }
      };

      try {
        processTableErrorResponse(errorResponse);
      } catch ({ errors }) {
        jestExpect(errors).toEqual({
          tableCode: MUST_BE_UNIQUE_MESSAGE
        });
      }
    });
  });

  describe('should validate tableOpenTime and tableCloseTime', () => {
    test('should validate failed when tableOpenTime is before than tableCloseTime', () => {
      try {
        const values = { tableCloseTime: '12:34', tableOpenTime: '13:10' };
        validateSubmission(values);
        fail('Expected SubmissionError to be thrown.');
      } catch ({ errors }) {
        jestExpect(errors).toEqual({
          tableCloseTime: 'Close time should be greater than open time',
          _error: 'Submission Failed!'
        });
      }
    });

    test('should validate failed when tableOpenTime has not been fill out', () => {
      try {
        const values = { tableCloseTime: '12:34', tableOpenTime: '' };
        validateSubmission(values);
        fail('Expected SubmissionError to be thrown.');
      } catch ({ errors }) {
        jestExpect(errors).toEqual({
          tableOpenTime: INVALID_TIME_MESSAGE,
          _error: 'Submission Failed!'
        });
      }
    });

    test('should validate successfully when tableCloseTime has not been fill out and tableOpenTime is filled', () => {
      try {
        const values = { tableCloseTime: '', tableOpenTime: '13:10' };
        validateSubmission(values);
      } catch ({ errors }) {
        jestExpect(errors).toEqual({
          tableCloseTime: INVALID_TIME_MESSAGE,
          _error: 'Submission Failed!'
        });
      }
    });

    test('should return error message  when close time greater than open time', () => {
      const values = {
        tableCloseTime: '12:34',
        tableOpenTime: '13:10'
      };
      const errors = validateField(values);

      jestExpect(errors).toEqual({
        tableCloseTime: 'Close time should be greater than open time'
      });
    });

    test('should return error message when open time is empty', () => {
      const values = {
        tableCloseTime: '12:00',
        tableOpenTime: ''
      };
      const errors = validateField(values);

      jestExpect(errors).toEqual({
        tableOpenTime: INVALID_TIME_MESSAGE
      });
    });
  });
});
