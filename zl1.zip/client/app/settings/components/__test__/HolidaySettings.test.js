import { mount } from 'enzyme';
import React from 'react';
import HolidaySettings from '../HolidaySettings';
import { Provider } from 'react-redux';
import { createReduxStore } from '../../../store';
import semanticUI from '../../../../test-helpers/semantic-ui';

const christmas = {
  index: 2,
  data: {
    date: '12-25-2018',
    description: 'Christmas'
  }
};

const mlk = {
  index: 0,
  data: {
    date: '01-15-2018',
    description: 'Martin Luther King Jr. Day'
  }
};

const independenceDay = {
  index: 1,
  data: {
    date: '07-04-2018',
    description: 'Independence Day'
  }
};

const holidays = [mlk, independenceDay, christmas];

describe('HolidaySettings', () => {
  let wrapper, createHoliday, hideError, onBack, handleSubmitSpy;

  beforeEach(() => {
    onBack = jest.fn();
    createHoliday = jest.fn();
    hideError = jest.fn();
    handleSubmitSpy = jest.fn();
    wrapper = mount(
      <Provider store={createReduxStore({})}>
        <HolidaySettings
          holidays={holidays}
          today={'2018-02-11'}
          createHoliday={createHoliday}
          deleteHoliday={() => {}}
          handleSubmit={handleSubmitSpy}
          hideError={hideError}
          onBack={onBack}
        />
      </Provider>
    );
  });

  describe('on render', () => {
    test('should render description input field with max length of 30 characters', () => {
      jestExpect(
        wrapper
          .find('form')
          .at(0)
          .find('input')
          .at(1)
          .props().maxLength
      ).toEqual(30);
    });
  });

  describe('on submit', () => {
    test('should send appropriate values to submit', () => {
      wrapper
        .find('input')
        .at(0)
        .simulate('change', { target: { value: '09-09-2019' } });
      wrapper
        .find('input')
        .at(1)
        .simulate('change', { target: { value: 'Labor Day' } });

      wrapper
        .find('form')
        .at(0)
        .simulate('submit');
      jestExpect(handleSubmitSpy).toHaveBeenCalled();
    });

    test('should call createHoliday', () => {
      wrapper = mount(
        <Provider store={createReduxStore({})}>
          <HolidaySettings
            holidays={holidays}
            today={'2018-02-11'}
            createHoliday={createHoliday}
            deleteHoliday={() => {}}
            hideError={hideError}
            onBack={onBack}
          />
        </Provider>
      );
      let userInput = { date: '10-10-2018', description: '3r fadf 3f asd#D' };
      semanticUI.changeInput(wrapper, 'date', '10-10-2018');
      wrapper
        .find('input')
        .at(1)
        .simulate('change', { target: { value: '3r fadf 3f asd#D' } });

      wrapper
        .find('form')
        .at(0)
        .simulate('submit');

      jestExpect(createHoliday).toHaveBeenCalledWith(userInput);
    });

    test('should reset state to empty strings', () => {
      wrapper = mount(
        <Provider store={createReduxStore({})}>
          <HolidaySettings
            holidays={holidays}
            today={'2018-02-11'}
            createHoliday={createHoliday}
            deleteHoliday={() => {}}
            hideError={hideError}
            onBack={onBack}
          />
        </Provider>
      );
      wrapper
        .find('input')
        .at(0)
        .simulate('change', { target: { value: '10-10-2018' } });
      wrapper
        .find('input')
        .at(1)
        .simulate('change', { target: { value: '3r fadf 3f asd#D' } });

      jestExpect(
        wrapper
          .find('input')
          .at(0)
          .props().value
      ).toEqual('10-10-2018');
      jestExpect(
        wrapper
          .find('input')
          .at(1)
          .props().value
      ).toEqual('3r fadf 3f asd#D');

      wrapper
        .find('form')
        .at(0)
        .simulate('submit');
      jestExpect(
        wrapper
          .find('input')
          .at(0)
          .props().value
      ).toEqual('');
      jestExpect(
        wrapper
          .find('input')
          .at(1)
          .props().value
      ).toEqual('');
    });
  });

  describe('on render', () => {
    test('should render inputs to add holiday', () => {
      jestExpect(wrapper.find('input').length).toEqual(2);
      jestExpect(
        wrapper
          .find('.field')
          .at(0)
          .find('input')
          .props().name
      ).toEqual('date');
      jestExpect(
        wrapper
          .find('.field')
          .at(1)
          .find('input')
          .props().name
      ).toEqual('description');
    });

    test('should render holidays in table', () => {
      jestExpect(wrapper.find('tr[pid="holiday-0"]')).toExist();
      jestExpect(wrapper.find('tr[pid="holiday-1"]')).toExist();
      jestExpect(wrapper.find('tr[pid="holiday-2"]')).toExist();
    });

    test('should render holidays with dates and descriptions in table in chronological order', () => {
      const mlkRow = wrapper.find('tr[pid="holiday-0"]');
      const independenceDayRow = wrapper.find('tr[pid="holiday-1"]');
      const christmasRow = wrapper.find('tr[pid="holiday-2"]');

      jestExpect(mlkRow.find('td').at(0)).toHaveText(mlk.data.date);
      jestExpect(mlkRow.find('td').at(1)).toHaveText(mlk.data.description);
      jestExpect(independenceDayRow.find('td').at(0)).toHaveText(independenceDay.data.date);
      jestExpect(independenceDayRow.find('td').at(1)).toHaveText(independenceDay.data.description);
      jestExpect(christmasRow.find('td').at(0)).toHaveText(christmas.data.date);
      jestExpect(christmasRow.find('td').at(1)).toHaveText(christmas.data.description);
    });
  });

  describe('on click of plus button', () => {
    test('should not add holiday when date input is invalid', () => {
      let state = { date: 'ACb1 23@#', description: '3r fadf 3f asd#D' };
      wrapper.setState(state);

      wrapper.find('.icon-plus').simulate('click');

      jestExpect(createHoliday).not.toHaveBeenCalled();
      jestExpect(wrapper.state()).toEqual({ date: 'ACb1 23@#', description: '3r fadf 3f asd#D' });
    });
  });
});
