import { processErrorResponse, validateSubmission } from '../createStationFormValidator';

describe('createStationFormValidator', () => {
  describe('#validateSubmission', () => {
    test('should submit values if values are valid', () => {
      const values = {
        stationCode: '33',
        name: 'Pork',
        room: 'AB',
        printer: '10.1.1.1',
        type: 'PRODUCTION',
        userId: ''
      };

      validateSubmission(values);
    });

    test('should verify that stationCode, name, room, type and printer are all required', () => {
      const values = {};

      try {
        validateSubmission(values);
      } catch ({ errors }) {
        jestExpect(errors).toEqual({
          stationCode: 'Required',
          name: 'Required',
          room: 'Required',
          printer: 'Required',
          type: 'Required',
          _error: 'Submission Failed!'
        });
      }
    });

    test('should verify stationCode is a positive number when not given a number', () => {
      const values = {
        stationCode: 'bo'
      };

      try {
        validateSubmission(values);
      } catch ({ errors }) {
        jestExpect(errors).toMatchObject({
          stationCode: 'Must be a positive number',
          _error: 'Submission Failed!'
        });
      }
    });

    test('should verify stationCode has a max length of 2 ', () => {
      const values = {
        stationCode: '1234'
      };

      try {
        validateSubmission(values);
      } catch ({ errors }) {
        jestExpect(errors).toMatchObject({
          stationCode: 'Maximum 2 characters',
          _error: 'Submission Failed!'
        });
      }
    });

    test('should verify stationCode is a positive number when given a negative number', () => {
      const values = {
        stationCode: '-9'
      };

      try {
        validateSubmission(values);
      } catch ({ errors }) {
        jestExpect(errors).toMatchObject({
          stationCode: 'Must be a positive number',
          _error: 'Submission Failed!'
        });
      }
    });

    test('should verify name has a max length of 12 ', () => {
      const values = {
        name: 'Johnathon Smith'
      };

      try {
        validateSubmission(values);
      } catch ({ errors }) {
        jestExpect(errors).toMatchObject({
          name: 'Maximum 12 characters',
          _error: 'Submission Failed!'
        });
      }
    });

    test('should verify user id is required if type is PACKOFF', () => {
      const values = {
        stationCode: '33',
        name: 'Pork',
        room: 'AB',
        printer: '10.1.1.1',
        type: 'PACKOFF'
      };

      try {
        validateSubmission(values);
      } catch ({ errors }) {
        jestExpect(errors).toEqual({
          userId: 'Required',
          _error: 'Submission Failed!'
        });
      }
    });

    test('should verify user id has a maximum length of 20', () => {
      const values = {
        stationCode: '33',
        name: 'Pork',
        room: 'AB',
        printer: '10.1.1.1',
        type: 'PACKOFF',
        userId: '01234567890012345678901'
      };

      try {
        validateSubmission(values);
      } catch ({ errors }) {
        jestExpect(errors).toEqual({
          userId: 'Maximum 20 characters',
          _error: 'Submission Failed!'
        });
      }
    });
  });

  describe('#processErrorResponse', () => {
    test('should throw exception when having errors', () => {
      const errorResponse = {
        error: {
          details: [
            {
              value: 'StationExistValidation',
              issue: 'Station exist validation issue',
              type: 'model'
            },
            {
              value: 'UserAssignedValidation',
              issue: 'User assigned validation issue',
              type: 'model'
            },
            {
              value: 'INVALID',
              issue: 'User assigned validation issue',
              type: 'model',
              field: 'printer'
            },
            {
              value: 'INVALID',
              issue: 'User assigned validation issue',
              type: 'model',
              field: 'retailPrinter'
            }
          ]
        }
      };

      try {
        processErrorResponse(errorResponse);
      } catch ({ errors }) {
        jestExpect(errors).toEqual({
          stationCode: 'Station exist validation issue',
          userId: 'User assigned validation issue',
          printer: 'Invalid IP Address',
          retailPrinter: 'Invalid IP Address',
          _error: 'Submission Failed!'
        });
      }
    });

    test('should throw exception when IP address is invalid', () => {
      const errorResponse = {
        error: {
          details: [
            {
              field: 'printer',
              value: 'PRINTER-66',
              issue: 'INVALID',
              location: 'body',
              type: 'field'
            }
          ]
        }
      };

      try {
        processErrorResponse(errorResponse);
      } catch ({ errors }) {
        jestExpect(errors).toEqual({
          printer: 'Invalid IP Address',
          _error: 'Submission Failed!'
        });
      }
    });
  });
});
