import _ from 'lodash';
import { SubmissionError } from 'redux-form';
import { maxLength, positiveNumber, required, validate } from '../../shared/formValidations';

export const validateSubmission = values => {
  const { stationCode, name, room, printer, type, userId } = values;
  let errors = {};

  errors = validate(errors, stationCode, 'stationCode', [required, positiveNumber, maxLength(2)]);
  errors = validate(errors, name, 'name', [required, maxLength(12)]);
  errors = validate(errors, room, 'room', [required]);
  errors = validate(errors, printer, 'printer', [required]);
  errors = validate(errors, type, 'type', [required]);

  if ('PACKOFF' === type) {
    errors = validate(errors, userId, 'userId', [required, maxLength(20)]);
  }

  if (!_.isEmpty(errors)) {
    throw new SubmissionError({ ...errors, _error: 'Submission Failed!' });
  }
};

export const processErrorResponse = errorResponse => {
  let errors = {};
  const errorDetails = _.get(errorResponse, 'error.details', []);
  errors = processModelErrors(errorDetails, errors);
  errors = processFieldErrors(errorDetails, errors);

  throw new SubmissionError({ ...errors, _error: 'Submission Failed!' });
};

const processFieldErrors = (errorDetails, errors) => {
  const fieldErrors = _.filter(errorDetails, errorDetail => 'field' === errorDetail.type);

  _.forEach(fieldErrors, fieldError => {
    const issue = fieldError.issue;

    switch (issue) {
      case 'INVALID':
        if ('printer' === fieldError.field) {
          errors = { ...errors, printer: 'Invalid IP Address' };
        }
        if ('retailPrinter' === fieldError.field) {
          errors = { ...errors, retailPrinter: 'Invalid IP Address' };
        }
        break;
    }
  });

  return errors;
};

const processModelErrors = (errorDetails, errors) => {
  const modelErrors = _.filter(errorDetails, errorDetail => 'model' === errorDetail.type);

  _.forEach(modelErrors, fieldError => {
    const type = fieldError.value;

    switch (type) {
      case 'StationExistValidation':
        errors = { ...errors, stationCode: fieldError.issue };
        break;
      case 'UserAssignedValidation':
        errors = { ...errors, userId: fieldError.issue };
        break;
      case 'INVALID':
        if ('printer' === fieldError.field) {
          errors = { ...errors, printer: 'Invalid IP Address' };
        }
        if ('retailPrinter' === fieldError.field) {
          errors = { ...errors, retailPrinter: 'Invalid IP Address' };
        }
        break;
    }
  });

  return errors;
};
