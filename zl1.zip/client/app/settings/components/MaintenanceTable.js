import React from 'react';
import * as _ from 'lodash';
import { Table } from 'semantic-ui-react';
import PropTypes from 'prop-types';
import EmptyTableMessage from '../../shared/components/EmptyTableMessage';

export const ERROR_MESSAGE =
  'Items should not be undefined. Give data provided as items initial state.';

export const iconButton = {
  cursor: 'pointer'
};

const renderTable = (columns, content) => {
  return (
    <Table size='small' columns={16} selectable>
      <Table.Header>
        <Table.Row>
          {columns.map((column, index) => {
            return (
              <Table.HeaderCell
                key={`${column.key}-${index}`}
                pid={`maintenance__header-${column.pid}`}
                textAlign={column.textAlign}
                colSpan={column.colSpan}
                width={column.width}
              >
                {column.headerText}
              </Table.HeaderCell>
            );
          })}
        </Table.Row>
      </Table.Header>
      {content}
    </Table>
  );
};

const MaintenanceTable = ({ columns, items, tableBody }) => {
  const content = tableBody(columns, items);
  const overviewTable = renderTable(columns, content);

  if (_.isNull(items)) {
    return <div>{overviewTable}</div>;
  } else if (_.isUndefined(items)) {
    throw new Error(ERROR_MESSAGE);
  }

  return (
    <div>
      {_.isEmpty(items) ? (
        <div>
          {overviewTable}
          <EmptyTableMessage key={'prime-maintenance-table-empty-message'} />
        </div>
      ) : (
        overviewTable
      )}
    </div>
  );
};

MaintenanceTable.defaultProps = {
  items: null
};

MaintenanceTable.propTypes = {
  columns: PropTypes.array.isRequired,
  items: PropTypes.array,
  tableBody: PropTypes.func.isRequired
};

export default MaintenanceTable;
