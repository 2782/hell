import _ from 'lodash';
import {
  ALL_CUSTOMERS_RECEIVED,
  EDITING_ALLOWED,
  CLEAR_CUSTOMER,
  CLEAR_HOUSE_PAR,
  CLEAR_PROFILE_INFO,
  CLEAR_STATION,
  CLEAR_TABLE,
  DELETE_HOLIDAY,
  GET_ACTIVE_FISCAL_CALENDAR,
  GET_CUSTOMER,
  GET_PROFILE,
  GRABBED_SUB_PRIMAL,
  HIDE_ERROR,
  EDITING_OVER,
  SHOW_ERROR,
  SUBPRIMAL_EXISTS_FLAG_CHANGED,
  UPDATE_GRINDING_HOUSE_PARS,
  UPDATE_HOLIDAYS,
  UPDATE_HOUSE_PAR,
  UPDATE_HOUSE_PARS,
  UPDATE_ROOMS,
  UPDATE_STATION,
  UPDATE_STATIONS,
  UPDATE_TABLE,
  UPDATE_TABLES,
  UPDATE_WEEKEND,
  UPDATE_WEEKENDS
} from '../actions/settingsActionTypes';
import { addIndexToData } from '../../shared/util/indexUtil';
import { states } from '../../shared/staticInfo/states';

const initialState = {
  holidays: [],
  rooms: null,
  table: {},
  station: {},
  stations: null,
  tables: null,
  profile: {},
  states: states,
  error: { message: '', showing: false },
  weekends: [
    {
      key: 'saturday',
      value: false,
      id: 1
    },
    {
      key: 'sunday',
      value: false,
      id: 2
    }
  ],
  housePars: [],
  grindingHousePars: [],
  housePar: {},
  activeFiscalCalendar: {},
  customer: {},
  customers: [],
  subPrimals: {},
  subPrimalsExist: {},
  editableHoliday: {},
  allowedToEdit: false
};

export default (state = initialState, action) => {
  switch (action.type) {
    case UPDATE_HOLIDAYS:
      return {
        ...state,
        holidays: addIndexToData(action.payload)
      };

    case EDITING_ALLOWED:
      return {
        ...state,
        editableHoliday: action.payload,
        allowedToEdit: true
      };
    case EDITING_OVER:
      return {
        ...state,
        editableHoliday: {},
        allowedToEdit: false
      };
    case UPDATE_WEEKENDS:
      return {
        ...state,
        weekends: action.payload
      };

    case UPDATE_STATION:
      return {
        ...state,
        station: action.payload
      };

    case ALL_CUSTOMERS_RECEIVED:
      return {
        ...state,
        customers: action.payload
      };

    case GET_CUSTOMER:
      return {
        ...state,
        customer: action.payload
      };

    case CLEAR_CUSTOMER:
      return {
        ...state,
        customer: initialState.customer
      };

    case UPDATE_TABLE:
      return {
        ...state,
        table: action.payload
      };

    case CLEAR_STATION:
      return {
        ...state,
        station: initialState.station
      };

    case CLEAR_TABLE:
      return {
        ...state,
        table: initialState.table
      };

    case UPDATE_STATIONS:
      return {
        ...state,
        stations: action.payload
      };

    case UPDATE_WEEKEND:
      return {
        ...state,
        weekends: action.payload
      };

    case DELETE_HOLIDAY:
      return {
        ...state,
        holidays: state.holidays.filter(holiday => {
          return holiday.data.id !== action.payload;
        })
      };

    case UPDATE_TABLES:
      return {
        ...state,
        tables: action.payload
      };

    case SHOW_ERROR:
      return {
        ...state,
        error: { message: action.payload.message, showing: true }
      };

    case HIDE_ERROR:
      return {
        ...state,
        error: { message: '', showing: false }
      };

    case UPDATE_ROOMS:
      return {
        ...state,
        rooms: action.payload
      };

    case GET_PROFILE:
      return {
        ...state,
        profile: action.payload
      };
    case UPDATE_HOUSE_PARS:
      return {
        ...state,
        housePars: action.payload
      };
    case UPDATE_HOUSE_PAR:
      return {
        ...state,
        housePar: action.payload
      };
    case CLEAR_HOUSE_PAR:
      return {
        ...state,
        housePar: initialState.housePar
      };
    case UPDATE_GRINDING_HOUSE_PARS:
      return {
        ...state,
        grindingHousePars: action.payload
      };

    case GET_ACTIVE_FISCAL_CALENDAR:
      return {
        ...state,
        activeFiscalCalendar: action.payload
      };
    case GRABBED_SUB_PRIMAL: {
      const subPrimal = action.payload;
      return {
        ...state,
        subPrimals: { ...state.subPrimals, [_.toUpper(subPrimal.subPrimalCode)]: subPrimal }
      };
    }
    case SUBPRIMAL_EXISTS_FLAG_CHANGED:
      return {
        ...state,
        subPrimalsExist: {
          ...state.subPrimalsExist,
          [action.payload.fieldName]: action.payload.flag
        }
      };
    case CLEAR_PROFILE_INFO:
      return {
        ...state,
        profile: {}
      };

    default:
      return state;
  }
};
