import {
  CLEAR_TARE_PACKAGES,
  GRABBED_BOX_TYPES,
  GRABBED_FILM_TYPES,
  GRABBED_TARE_PACKAGE,
  GRABBED_TARE_PACKAGES,
  GRABBED_DEFAULT_TARE_PACKAGE
} from '../actions/tarePackagesActionTypes';
import _ from 'lodash';

const initState = {
  boxTypes: [],
  filmTypes: [],
  tarePackages: null,
  confirmationShowing: false,
  tarePackage: null,
  defaultTarePackage: null
};

const tarePackagesReducer = (state = initState, action) => {
  switch (action.type) {
    case GRABBED_BOX_TYPES:
      return {
        ...state,
        boxTypes: action.payload
      };
    case GRABBED_FILM_TYPES:
      return {
        ...state,
        filmTypes: action.payload
      };
    case GRABBED_TARE_PACKAGES:
      return {
        ...state,
        tarePackages: action.payload
      };
    case GRABBED_DEFAULT_TARE_PACKAGE:
      return {
        ...state,
        defaultTarePackage: action.payload
      };
    case 'SHOW_TARE_PACKAGE_CONFIRMATION':
      return {
        ...state,
        confirmationShowing: true
      };
    case 'HIDE_TARE_PACKAGE_CONFIRMATION':
      return {
        ...state,
        confirmationShowing: false
      };
    case GRABBED_TARE_PACKAGE:
      return {
        ...state,
        tarePackage: action.payload
      };
    case CLEAR_TARE_PACKAGES:
      return initState;
    default:
      return state;
  }
};

export const createBoxTypeByIdSelector = state => boxTypeId => {
  const boxTypes = state.tarePackages.boxTypes;

  return boxTypeId && !_.isEmpty(boxTypes)
    ? boxTypes.find(boxType => boxType.id === boxTypeId)
    : undefined;
};

export const createFilmTypeByIdSelector = state => filmTypeId => {
  const boxTypes = state.tarePackages.filmTypes;

  return filmTypeId && !_.isEmpty(boxTypes)
    ? boxTypes.find(boxType => boxType.id === filmTypeId)
    : undefined;
};

export default tarePackagesReducer;
