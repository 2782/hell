import React from 'react';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import { bindActionCreators } from 'redux';
import { createRoom } from '../actions/settingsActions';
import FormElement from '../../shared/FormElement';
import { Field, reduxForm } from 'redux-form';
import { Button, Divider, Form, Grid, Icon } from 'semantic-ui-react';
import { exactLength6, required, wholeNumber } from '../../shared/validation/formFieldValidations';
import subscriber from '../../shared/functionKeys/subscriber';
import { normalizeToSixDigits } from '../../shared/components/product/normalizer';
import { processErrorResponse } from './roomValidator';
import {
  alpahanumericButNotZero,
  noStartingSpaces
} from '../../shared/normalizers/formFieldNormalizers';

export const roomTypeOptions = [
  { key: 0, value: 'CUTTING', text: 'Cutting' },
  { key: 1, value: 'GRINDING', text: 'Grinding' }
];

class CreateRoom extends React.Component {
  constructor(props) {
    super(props);
  }

  onSubmit(values) {
    return this.props.createRoom({ ...values, code: values.code.toUpperCase() }, error => {
      processErrorResponse(error);
    });
  }

  render() {
    const { handleSubmit, submitting, pristine } = this.props;
    return (
      <div className={'create-room-wrapper'}>
        <Form size={'large'} onSubmit={handleSubmit(this.onSubmit.bind(this))}>
          <Form.Group>
            <Field
              component={FormElement}
              name='code'
              pid='room-code'
              as={Form.Input}
              format={value => value && value.toUpperCase()}
              autoFocus={true}
              validate={[required]}
              type='text'
              label='ROOM #'
              width={6}
              maxLength={2}
              normalize={alpahanumericButNotZero}
            />
            <Field
              component={FormElement}
              name='customerNumber'
              className='customer-number'
              normalize={normalizeToSixDigits}
              as={Form.Input}
              type='text'
              label='CUSTOMER NUMBER'
              validate={[required, wholeNumber, exactLength6]}
              maxLength={6}
              width={4}
            />
          </Form.Group>
          <Form.Group>
            <Field
              component={FormElement}
              name='description'
              pid='room-description'
              as={Form.Input}
              validate={[required]}
              type='text'
              label='DESCRIPTION'
              width={8}
              maxLength={35}
              normalize={noStartingSpaces}
            />
          </Form.Group>
          <Grid>
            <Grid.Row>
              <Grid.Column width={8}>
                <Field
                  component={FormElement}
                  pid='create-room__room-type'
                  as={Form.Select}
                  name='roomType'
                  options={roomTypeOptions}
                  type='text'
                  validate={[required]}
                  label='ROOM TYPE'
                />
              </Grid.Column>
            </Grid.Row>
          </Grid>

          <Divider hidden />

          <Button primary size={'large'} loading={submitting} disabled={submitting || pristine}>
            <Icon className='icon-save' />
            Save
          </Button>

          <Divider hidden />
        </Form>
      </div>
    );
  }
}

CreateRoom.propTypes = {
  createRoom: PropTypes.func.isRequired,
  submitting: PropTypes.bool.isRequired,
  pristine: PropTypes.bool.isRequired,
  handleSubmit: PropTypes.func.isRequired,
  error: PropTypes.string
};

const mapStateToProps = () => ({
  initialValues: {
    code: '',
    description: '',
    roomType: '',
    customerNumber: ''
  }
});

const mapDispatchToProps = dispatch =>
  bindActionCreators(
    {
      createRoom
    },
    dispatch
  );

export const f4Behavior = props => {
  props.replacePath('/settings/rooms');
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(
  reduxForm({
    form: 'createRoom'
  })(
    subscriber(CreateRoom, {
      f4Behavior,
      targetComponent: 'CreateRoom',
      uris: {
        F4: ['#/settings/rooms/create', '#/settings/rooms/create/*']
      }
    })
  )
);
