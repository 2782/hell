import _ from 'lodash';
import { SubmissionError } from 'redux-form';
import {
  exactLength,
  wholeNumber,
  required,
  validate,
  alphanumeric,
  maxLength
} from '../../shared/formValidations';

export const validateSubmission = values => {
  const {
    plantNumber,
    name,
    address,
    city,
    zipCode,
    establishmentNumber,
    vendorShipFrom,
    sequenceNumber
  } = values;
  let errors = {};

  errors = validate(errors, plantNumber, 'plantNumber', [required, wholeNumber, exactLength(3)]);
  errors = validate(errors, name, 'name', [required]);
  errors = validate(errors, address, 'address', [required]);
  errors = validate(errors, city, 'city', [required]);
  errors = validate(errors, zipCode, 'zipCode', [required, wholeNumber, exactLength(5)]);
  errors = validate(errors, establishmentNumber, 'establishmentNumber', [required, alphanumeric]);
  errors = validate(errors, vendorShipFrom, 'vendorShipFrom', [
    required,
    wholeNumber,
    maxLength(6)
  ]);
  errors = validate(errors, sequenceNumber, 'sequenceNumber', [
    required,
    wholeNumber,
    maxLength(2)
  ]);

  if (!_.isEmpty(errors)) {
    throw new SubmissionError({ ...errors, _error: 'Submission Failed!' });
  }
};
