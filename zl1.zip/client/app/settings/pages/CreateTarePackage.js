import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import {
  clearTarePackages,
  createTarePackage,
  getAllBoxTypes,
  getAllFilmTypes,
  getTarePackage,
  showConfirmation
} from '../actions/tarePackagesActions';
import { Button, Form, Grid } from 'semantic-ui-react';
import _ from 'lodash';
import FormLabel from '../../shared/FormLabel';
import { Field, formValueSelector, reduxForm, SubmissionError } from 'redux-form';
import FormElement from '../../shared/FormElement';
import CheckBox from '../../shared/components/CheckBox';
import TarePackageConfirmation from '../utils/TarePackageConfirmation';
import ErrorLabel from '../../shared/components/ErrorLabel';
import subscriber from '../../shared/functionKeys/subscriber';
import {
  createBoxTypeByIdSelector,
  createFilmTypeByIdSelector
} from '../reducers/tarePackagesReducer';
import { submit } from 'redux-form';

export const generateBoxTypeOptions = boxTypes => {
  let sortedBoxTypes = _.sortBy(boxTypes, 'boxDescription');
  return sortedBoxTypes.map((boxType, index) => {
    const { boxDescription } = boxType;
    return { key: index, text: boxDescription, value: boxType.id };
  });
};

export const generateFilmTypeOptions = filmTypes => {
  let sortedFilmTypes = _.sortBy(filmTypes, 'filmDescription');
  return sortedFilmTypes.map((filmType, index) => {
    const { filmDescription } = filmType;
    return { key: index, text: filmDescription, value: filmType.id };
  });
};

const onSubmit = (values, dispatch, props) => {
  const {
    createTarePackage,
    match: {
      params: { tareId }
    },
    selectedBoxType,
    selectedFilmType
  } = props;

  return createTarePackage(
    {
      defaulted: values.defaulted,
      filmType: selectedFilmType,
      boxType: selectedBoxType,
      id: tareId
    },
    () => {
      throw new SubmissionError({ _error: 'Submission failed - duplicate package' });
    }
  );
};

const formName = 'tarePackageForm';

export class CreateTarePackageComponent extends React.Component {
  constructor(props) {
    super(props);

    this.submit = this.submit.bind(this);
  }

  componentDidMount() {
    const {
      getAllBoxTypes,
      getAllFilmTypes,
      getTarePackage,
      match: {
        params: { tareId }
      }
    } = this.props;

    if (!_.isEmpty(tareId)) {
      getTarePackage(tareId);
    }

    getAllBoxTypes();
    getAllFilmTypes();
  }

  componentWillUnmount() {
    this.props.clearTarePackages();
  }

  submit(values) {
    const { showConfirmation, dispatch } = this.props;

    if (values.defaulted) {
      showConfirmation();
    } else {
      return dispatch(submit(formName)); // remote submit the form
    }
  }

  render() {
    const {
      boxTypeOptions,
      filmTypeOptions,
      selectedBoxType,
      selectedFilmType,
      handleSubmit,
      error,
      pristine,
      submitting
    } = this.props;
    return (
      <Form pid='tare-packages-form' size={'large'} onSubmit={handleSubmit(this.submit)}>
        <Grid>
          <Grid.Row>
            <Grid.Column width={7}>
              <Field
                component={FormElement}
                placeholder='Select box type...'
                as={Form.Select}
                name='boxTypeId'
                pid='tare-packages__box-description'
                options={boxTypeOptions}
                label='Box Description'
              />
            </Grid.Column>
            <Grid.Column width={6}>
              <FormLabel
                pid='tare-packages__box-tare'
                width={6}
                label='Box Tare'
                value={selectedBoxType && selectedBoxType.boxTare}
              />
            </Grid.Column>
          </Grid.Row>
          <Grid.Row>
            <Grid.Column width={7}>
              <Field
                component={FormElement}
                placeholder='Select film type...'
                as={Form.Select}
                name='filmTypeId'
                pid='tare-packages__film-description'
                options={filmTypeOptions}
                label='Film Description'
              />
            </Grid.Column>
            <Grid.Column width={6}>
              <FormLabel
                pid='tare-packages__film-tare'
                width={6}
                label='Film Tare'
                value={selectedFilmType && selectedFilmType.filmTare}
              />
            </Grid.Column>
          </Grid.Row>
          <Grid.Row>
            <Grid.Column width={7}>
              <Field
                component={CheckBox}
                label='Default'
                pid='tare-packages__defaulted'
                name='defaulted'
              />
            </Grid.Column>
          </Grid.Row>
          <Grid.Row>
            <TarePackageConfirmation formToSubmitRemotely={formName} />
            <Grid.Column width={13}>
              <Button
                name='submit'
                primary
                size={'large'}
                loading={submitting}
                disabled={submitting || pristine || !selectedBoxType || !selectedFilmType}
                className='submit'
              >
                SUBMIT
              </Button>
            </Grid.Column>
          </Grid.Row>
          <Grid.Row>
            <Grid.Column>
              <ErrorLabel className='error' isInvalid={!!error} errorMessage={error} />
            </Grid.Column>
          </Grid.Row>
        </Grid>
      </Form>
    );
  }
}

CreateTarePackageComponent.propTypes = {
  getAllBoxTypes: PropTypes.func,
  getAllFilmTypes: PropTypes.func,
  createTarePackage: PropTypes.func,
  getTarePackage: PropTypes.func,
  clearTarePackages: PropTypes.func,
  selectedBoxType: PropTypes.shape({
    boxDescription: PropTypes.string,
    boxTare: PropTypes.number,
    id: PropTypes.number
  }),
  selectedFilmType: PropTypes.shape({
    filmDescription: PropTypes.string,
    filmTare: PropTypes.number,
    id: PropTypes.number
  }),

  handleSubmit: PropTypes.func,
  error: PropTypes.string,
  showConfirmation: PropTypes.func,
  match: PropTypes.object,
  submitting: PropTypes.bool,
  pristine: PropTypes.bool,

  filmTypeOptions: PropTypes.array,
  boxTypeOptions: PropTypes.array,
  dispatch: PropTypes.func
};

const tarePackageFormSelector = formValueSelector(formName);

const mapStateToProps = state => {
  const getBoxTypeById = createBoxTypeByIdSelector(state);
  const getFilmTypeById = createFilmTypeByIdSelector(state);

  const allBoxTypes = state.tarePackages.boxTypes;
  const allFilmTypes = state.tarePackages.filmTypes;
  const { boxTypeId, filmTypeId } = tarePackageFormSelector(state, 'boxTypeId', 'filmTypeId');

  const selectedBoxType = getBoxTypeById(boxTypeId);
  const selectedFilmType = getFilmTypeById(filmTypeId);

  const tarePackage = state.tarePackages.tarePackage;
  return {
    initialValues: {
      defaulted: _.get(tarePackage, 'defaulted', false),
      filmTypeId: _.get(tarePackage, 'filmType.id', ''),
      boxTypeId: _.get(tarePackage, 'boxType.id', '')
    },
    boxTypeOptions: generateBoxTypeOptions(allBoxTypes),
    filmTypeOptions: generateFilmTypeOptions(allFilmTypes),
    selectedBoxType,
    selectedFilmType
  };
};

const mapDispatchToProps = dispatch =>
  bindActionCreators(
    {
      getAllBoxTypes,
      getAllFilmTypes,
      showConfirmation,
      createTarePackage,
      getTarePackage,
      clearTarePackages
    },
    dispatch
  );

export const f4Behavior = props => {
  props.replacePath('/settings/tare-packages');
};

const CreateTarePackage = connect(
  mapStateToProps,
  mapDispatchToProps
)(
  reduxForm({
    form: formName,
    enableReinitialize: true,
    onSubmit
  })(
    subscriber(CreateTarePackageComponent, {
      f4Behavior,
      targetComponent: 'CreateTarePackage',
      uris: {
        F4: ['#/settings/tare-packages/create', '#/settings/tare-packages/create/*']
      }
    })
  )
);

export default CreateTarePackage;
