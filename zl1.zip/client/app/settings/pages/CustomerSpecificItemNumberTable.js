import React, { Fragment } from 'react';
import PropTypes from 'prop-types';
import _ from 'lodash';
import { Field } from 'redux-form';
import { Form, Label, Table } from 'semantic-ui-react';
import FormElement from '../../shared/FormElement';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import {
  getProductPromise,
  setProductExistTo
} from '../../shared/components/product/actionsDuplicate';
import ProductDuplicate from '../../shared/components/product/ProductDuplicate';
import { NOT_A_PRODUCT_CODE } from '../../../config/errorMessage';
import { normalizeProductCode } from '../../shared/components/product/normalizer';
import { maxLength } from '../../shared/validation/formFieldValidations';

const maxLen = maxLength(8);

export class CustomerSpecificItemNumberTableComponent extends React.Component {
  constructor(props) {
    super(props);
    this.handleChange = this.handleChange.bind(this);
  }

  componentDidUpdate() {
    const { fields } = this.props;
    let noEmptyFields = _.every(fields.getAll(), field => {
      return _.get(field, 'productCode', '') !== '';
    });

    if (noEmptyFields) {
      fields.push({});
    }
  }

  componentWillUnmount() {
    const { fields } = this.props;
    fields.getAll().forEach(field => {
      const productCode = _.get(field, 'productCode', '');
      if (!_.isEmpty(productCode)) {
        setProductExistTo(productCode, true);
      }
    });
  }

  handleOnBlur(event, productCode, fieldName, index) {
    const { fields, getProductPromise, setProductExistTo } = this.props;

    if (_.isEmpty(productCode)) {
      if (fields.length - 1 !== index) {
        event.preventDefault();
        fields.remove(index);
      }
    } else {
      getProductPromise(productCode, () => setProductExistTo(productCode, false));
    }
  }

  handleChange(event, productCode) {
    const { setProductExistTo } = this.props;
    if (!_.isEmpty(productCode)) {
      setProductExistTo(productCode, true);
    }
  }

  getNotification() {
    const {
      message,
      meta: { error, warning, dirty, invalid, submitFailed }
    } = this.props;
    if (invalid && (dirty || submitFailed) && !message) {
      return (
        (error && (
          <Label basic color='red' pointing>
            {error}
          </Label>
        )) ||
        (warning && (
          <Label basic color='orange' pointing>
            {warning}
          </Label>
        ))
      );
    } else {
      return (
        message && (
          <Label basic color='red' pointing>
            {message}
          </Label>
        )
      );
    }
  }

  render() {
    const { fields, productsExist, products } = this.props;

    return (
      <div>
        <Table columns={3} fixed size='small'>
          <Table.Header>
            <Table.Row>
              <Table.HeaderCell width={10}>SUPC</Table.HeaderCell>
              <Table.HeaderCell width={6}>Customer Item Number</Table.HeaderCell>
            </Table.Row>
          </Table.Header>
          <Table.Body>
            {fields.map((field, index) => {
              const { productCode } = fields.get(index);

              const productInformation = products[productCode] || {};
              return (
                <Table.Row key={index}>
                  <Table.Cell className='customer-product-code'>
                    <Fragment>
                      <Field
                        component={ProductDuplicate}
                        name={`${field}.productCode`}
                        normalize={normalizeProductCode}
                        maxLength={7}
                        message={
                          _.get(productsExist, productCode, true) ? null : NOT_A_PRODUCT_CODE
                        }
                        onBlur={(event, value, prevValue, fieldName) =>
                          this.handleOnBlur(event, value, fieldName, index)
                        }
                        onChange={this.handleChange}
                        product={productInformation}
                        useDotDotDot={false}
                        hideDescriptionLabel={true}
                        descriptionFontSize='15px'
                        className='customer-setup-input'
                      />
                    </Fragment>
                  </Table.Cell>
                  <Table.Cell className='customer-item-number'>
                    <Field
                      component={FormElement}
                      name={`${field}.itemNumber`}
                      as={Form.Input}
                      validate={[maxLen]}
                      className='customer-setup-input'
                    />
                  </Table.Cell>
                </Table.Row>
              );
            })}
          </Table.Body>
        </Table>
        {this.getNotification()}
      </div>
    );
  }
}

CustomerSpecificItemNumberTableComponent.propTypes = {
  fields: PropTypes.oneOfType([PropTypes.object, PropTypes.array]).isRequired,
  meta: PropTypes.object.isRequired,
  message: PropTypes.string,
  products: PropTypes.object,
  getProductPromise: PropTypes.func,
  setProductExistTo: PropTypes.func,
  productsExist: PropTypes.object
};

const mapStateToProps = state => {
  const products = state.productDuplicate.products;
  const productsExist = state.productDuplicate.productsExist || {};

  return { products, productsExist };
};

const mapDispatchToProps = dispatch =>
  bindActionCreators(
    {
      getProductPromise,
      setProductExistTo
    },
    dispatch
  );

const CustomerSpecificItemNumberTable = connect(
  mapStateToProps,
  mapDispatchToProps
)(CustomerSpecificItemNumberTableComponent);

export default CustomerSpecificItemNumberTable;
