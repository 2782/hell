import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import MaintenanceTable from '../components/MaintenanceTable';
import { getCustomers } from '../actions/settingsActions';
import { bindActionCreators } from 'redux';
import { Button } from 'semantic-ui-react';
import { replacePath } from '../../shared/actions/actions';
import { renderCustomerPackoffDisplay } from '../utils/renderTable';
import _ from 'lodash';

export class CustomerPackoffSetupMaintenanceComponent extends React.Component {
  constructor(props) {
    super(props);

    this.createCustomerPackoffSettings = this.createCustomerPackoffSettings.bind(this);
  }

  componentDidMount() {
    this.props.getCustomers();
  }

  createCustomerPackoffSettings() {
    this.props.replacePath('/settings/customers-packoff-display/customer-setup');
  }

  render() {
    const { allCustomers } = this.props;
    const columns = [
      {
        key: 'name',
        pid: 'customer-packoff-label-name',
        width: '6',
        headerText: 'Customer',
        value: item => {
          return (
            <div>
              <div>{item.name}</div> {item.customerCode}
            </div>
          );
        }
      },
      {
        key: 'dateTypeDisplayName',
        pid: 'customer-packoff-label-date-type',
        width: '3',
        headerText: 'Date Type'
      },
      {
        key: 'dateValue',
        pid: 'customer-packoff-label-days',
        width: '3',
        headerText: 'Number of Days',
        textAlign: 'right'
      },
      {
        key: 'createButton',
        pid: 'customer-packoff-label-create-button',
        width: '3',
        headerText: (
          <Button primary size={'small'} onClick={this.createCustomerPackoffSettings}>
            {'New'}
          </Button>
        ),
        textAlign: 'center'
      }
    ];

    if (_.isEmpty(allCustomers)) {
      return null;
    } else {
      return (
        <div>
          <MaintenanceTable
            items={allCustomers}
            columns={columns}
            tableBody={renderCustomerPackoffDisplay}
          />
        </div>
      );
    }
  }
}

CustomerPackoffSetupMaintenanceComponent.propTypes = {
  allCustomers: PropTypes.array,
  getCustomers: PropTypes.func.isRequired,
  replacePath: PropTypes.func
};

const mapStateToProps = state => {
  const allCustomers = _.sortBy(state.settingsInfo.customers, ['name']);

  return {
    allCustomers
  };
};

const mapDispatchToProps = dispatch =>
  bindActionCreators(
    {
      getCustomers,
      replacePath
    },
    dispatch
  );

const CustomerPackoffSetupMaintenance = connect(
  mapStateToProps,
  mapDispatchToProps
)(CustomerPackoffSetupMaintenanceComponent);

export default CustomerPackoffSetupMaintenance;
