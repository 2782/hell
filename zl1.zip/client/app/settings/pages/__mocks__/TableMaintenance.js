import React from 'react';

class TableMaintenance extends React.Component {
  render() {
    return <div>Fake TableMaintenance Component</div>;
  }
}

export default TableMaintenance;
