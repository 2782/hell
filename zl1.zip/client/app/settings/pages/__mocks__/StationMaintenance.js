import React from 'react';

class StationMaintenance extends React.Component {
  render() {
    return <div>Fake StationMaintenance Component</div>;
  }
}

export default StationMaintenance;
