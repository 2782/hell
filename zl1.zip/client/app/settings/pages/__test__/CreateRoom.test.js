import React from 'react';
import { mount } from 'enzyme';
import CreateRoom, { f4Behavior } from '../CreateRoom';
import settingsResources from '../../../shared/api/settingsResources';
import semanticUI from '../../../../test-helpers/semantic-ui';
import { createReduxStore } from '../../../store';
import { Provider } from 'react-redux';

jest.mock('../../../shared/api/settingsResources');

describe('createRoom', () => {
  let form;

  afterEach(() => {
    settingsResources.createRoom.mockReset();
  });

  test('should only set initial value on the redux form', () => {
    settingsResources.createRoom.mockImplementation((arg, success) => success(1, { data: {} }));

    form = mount(
      <Provider store={createReduxStore({})}>
        <CreateRoom />
      </Provider>
    );

    jestExpect(semanticUI.getInputValue(form, 'code')).toEqual('');
    jestExpect(semanticUI.getInputValue(form, 'description')).toEqual('');
    jestExpect(semanticUI.getSelectValue(form, 'roomType')).toEqual(undefined);
    jestExpect(semanticUI.getInputValue(form, 'customerNumber')).toEqual('');
  });

  test('should fill out form and save successfully', () => {
    settingsResources.createRoom.mockImplementation((arg, success) => success({ data: {} }));

    form = mount(
      <Provider store={createReduxStore({})}>
        <CreateRoom />
      </Provider>
    );

    semanticUI.changeInput(form, 'code', '42');
    semanticUI.changeInput(form, 'description', 'Pork');
    semanticUI.selectOption(form, 'roomType', 0);
    semanticUI.changeInput(form, 'customerNumber', '000170');

    form.find('form').simulate('submit');

    jestExpect(settingsResources.createRoom.mock.calls[0][0]).toEqual({
      code: '42',
      description: 'Pork',
      roomType: 'CUTTING',
      customerNumber: '000170'
    });
  });

  test('should show error when save room failed', () => {
    settingsResources.createRoom.mockImplementation((arg, success, fail) =>
      fail({
        error: {
          details: [
            {
              field: 'code',
              value: '42',
              issue: 'UNIQUE',
              location: 'body',
              type: 'field'
            }
          ]
        }
      })
    );

    form = mount(
      <Provider store={createReduxStore({})}>
        <CreateRoom />
      </Provider>
    );

    semanticUI.changeInput(form, 'code', '42');
    semanticUI.changeInput(form, 'description', 'Pork');
    semanticUI.selectOption(form, 'roomType', 1);
    semanticUI.changeInput(form, 'customerNumber', '000170');

    form.find('form').simulate('submit');

    jestExpect(settingsResources.createRoom.mock.calls[0][0]).toEqual({
      code: '42',
      description: 'Pork',
      roomType: 'GRINDING',
      customerNumber: '000170'
    });
    jestExpect(form.find('.label')).toHaveText('Room code must be unique');
  });

  test('should go return to room maintenance on f4', () => {
    const props = { replacePath: jest.fn() };

    f4Behavior(props);

    jestExpect(props.replacePath).toHaveBeenCalledWith('/settings/rooms');
  });
});
