import React from 'react';
import { mount } from 'enzyme';
import CreateTarePackage, { CreateTarePackageComponent, f4Behavior } from '../CreateTarePackage';
import { Provider } from 'react-redux';
import { createReduxStore } from '../../../store';
import tarePackagesResources from '../../../shared/api/tarePackagesResources';
import semanticUI from '../../../../test-helpers/semantic-ui';
import { Confirm } from 'semantic-ui-react';
import boxTypeFactory from '../../../../test-factories/boxTypeFactory';
import filmTypeFactory from '../../../../test-factories/filmTypeFactory';
import tarePackageFactory from '../../../../test-factories/tarePackageFactory';

jest.mock('../../../shared/api/tarePackagesResources');

describe('CreateTarePackage', () => {
  let form, store;

  beforeEach(() => {
    store = createReduxStore();
    tarePackagesResources.createTarePackage.mockResolvedValue({});
    tarePackagesResources.getAllBoxTypes.mockResolvedValue({});
    tarePackagesResources.getAllFilmTypes.mockResolvedValue({});
  });

  afterEach(() => {
    tarePackagesResources.createTarePackage.mockReset();
    tarePackagesResources.getAllBoxTypes.mockReset();
    tarePackagesResources.getAllFilmTypes.mockReset();
  });

  test('should call for all Box and Film types upon mount', () => {
    mount(
      <Provider store={store}>
        <CreateTarePackage match={{ params: {} }} />
      </Provider>
    );

    jestExpect(tarePackagesResources.getAllBoxTypes).toHaveBeenCalledTimes(1);
    jestExpect(tarePackagesResources.getAllFilmTypes).toHaveBeenCalledTimes(1);
  });

  test('should call get tare package when tare id exists', () => {
    mount(
      <Provider store={store}>
        <CreateTarePackage match={{ params: { tareId: '123' } }} />
      </Provider>
    );

    jestExpect(tarePackagesResources.getAllBoxTypes).toHaveBeenCalledTimes(1);
    jestExpect(tarePackagesResources.getAllFilmTypes).toHaveBeenCalledTimes(1);
    jestExpect(tarePackagesResources.getTarePackage.mock.calls[0][0]).toEqual('123');
  });

  test('should render a dropdown list for box and film', async () => {
    const boxTypes = [
      boxTypeFactory.build({
        boxDescription: 'black #10',
        boxTare: 1.062,
        id: 1231231
      }),
      boxTypeFactory.build({
        boxDescription: '#1',
        boxTare: 0.692,
        id: 1293443
      })
    ];
    const filmTypes = [
      filmTypeFactory.build({
        filmDescription: 'Grand Hotel',
        filmTare: 1.062,
        id: 12312
      }),
      filmTypeFactory.build({
        filmDescription: 'History of the World part 1',
        filmTare: 0.692,
        id: 12399
      })
    ];

    store = createReduxStore({
      tarePackages: {
        boxTypes,
        filmTypes,
        confirmationShowing: false
      }
    });

    let wrapper = mount(
      <Provider store={store}>
        <CreateTarePackage match={{ params: {} }} />
      </Provider>
    );

    await waitForAsyncTasks(form);

    const boxTypeOptions = semanticUI.getDropDownSelectionOptionsText(wrapper, 'boxTypeId');
    const filmTypeOptions = semanticUI.getDropDownSelectionOptionsText(wrapper, 'filmTypeId');

    jestExpect(boxTypeOptions).toEqual([boxTypes[1].boxDescription, boxTypes[0].boxDescription]);
    jestExpect(filmTypeOptions).toEqual([
      filmTypes[0].filmDescription,
      filmTypes[1].filmDescription
    ]);
  });

  test('should initialize form with boxType and filmType when editing an existing tare', async () => {
    const boxId = 11;

    const boxTypes = [
      boxTypeFactory.build({ boxDescription: 'black #10', id: 10 }),
      boxTypeFactory.build({ boxDescription: 'Box trying to edit', id: boxId }),
      boxTypeFactory.build({ id: 12 })
    ];
    const filmId = 14;

    const filmTypes = [
      filmTypeFactory.build({ filmDescription: 'Grand Hotel', id: 13 }),
      filmTypeFactory.build({ filmDescription: 'Film trying to edit', id: filmId }),
      filmTypeFactory.build({ id: 15 })
    ];

    store = createReduxStore({
      tarePackages: {
        boxTypes,
        filmTypes,
        confirmationShowing: false,
        tarePackage: tarePackageFactory.build({
          boxType: boxTypeFactory.build({ id: boxId }),
          filmType: filmTypeFactory.build({ id: filmId })
        })
      }
    });

    let wrapper = mount(
      <Provider store={store}>
        <CreateTarePackage match={{ params: {} }} />
      </Provider>
    );

    const currentlySelectedBoxType = semanticUI.getSelectText(wrapper, 'boxTypeId');
    const currentlySelectedFilmType = semanticUI.getSelectText(wrapper, 'filmTypeId');

    jestExpect(currentlySelectedBoxType).toEqual('Box trying to edit');
    jestExpect(currentlySelectedFilmType).toEqual('Film trying to edit');
  });

  test('should display the box and film tare in form labels when selecting a boxType and filmType', async () => {
    const boxTypesResponse = [
      boxTypeFactory.build({
        boxDescription: 'black #10',
        boxTare: 1.01,
        id: 1231231
      }),
      boxTypeFactory.build({
        boxDescription: '#1',
        boxTare: 1.02,
        id: 1293443
      })
    ];
    const filmTypesResponse = [
      filmTypeFactory.build({
        filmDescription: 'Grand Hotel',
        filmTare: 0.01,
        id: 12312
      }),
      filmTypeFactory.build({
        filmDescription: 'History of the World part 1',
        filmTare: 0.02,
        id: 12399
      })
    ];

    store = createReduxStore({
      tarePackages: {
        boxTypes: boxTypesResponse,
        filmTypes: filmTypesResponse,
        confirmationShowing: false
      }
    });

    let wrapper = mount(
      <Provider store={store}>
        <CreateTarePackage match={{ params: {} }} />
      </Provider>
    );

    semanticUI.selectOption(wrapper, 'boxTypeId', 0);
    semanticUI.selectOption(wrapper, 'filmTypeId', 0);

    const boxTare = semanticUI.getTextForLabelWithName(wrapper, 'Box Tare');
    const filmTare = semanticUI.getTextForLabelWithName(wrapper, 'Film Tare');

    jestExpect(boxTare).toEqual('1.02');
    jestExpect(filmTare).toEqual('0.01');
  });

  describe('submitting', () => {
    let boxTypesResponse, filmTypesResponse;
    beforeEach(() => {
      boxTypesResponse = [
        boxTypeFactory.build({
          boxDescription: 'black #10',
          boxTare: 1.062,
          id: 1231231
        }),
        boxTypeFactory.build({
          boxDescription: '#1',
          boxTare: 0.692,
          id: 1293443
        })
      ];
      filmTypesResponse = [
        filmTypeFactory.build({
          filmDescription: 'Grand Hotel',
          filmTare: 1.062,
          id: 12312
        }),
        filmTypeFactory.build({
          filmDescription: 'History of the World part 1',
          filmTare: 0.692,
          id: 12399
        })
      ];

      store = createReduxStore({
        tarePackages: {
          boxTypes: boxTypesResponse,
          filmTypes: filmTypesResponse,
          confirmationShowing: false
        }
      });
    });

    test('should submit form', () => {
      form = mount(
        <Provider store={store}>
          <CreateTarePackage match={{ params: { tareId: '123' } }} />
        </Provider>
      );

      semanticUI.selectOption(form, 'boxTypeId', 0);
      semanticUI.selectOption(form, 'filmTypeId', 0);

      form.find('form').simulate('submit');

      jestExpect(tarePackagesResources.createTarePackage.mock.calls[0][0]).toEqual({
        boxType: {
          boxDescription: '#1',
          boxTare: 0.692,
          id: 1293443
        },
        filmType: {
          filmDescription: 'Grand Hotel',
          filmTare: 1.062,
          id: 12312
        },
        defaulted: false,
        id: '123'
      });
    });

    test('should show confirmation if defaulted is true', () => {
      form = mount(
        <Provider store={store}>
          <CreateTarePackage match={{ params: {} }} />
        </Provider>
      );

      semanticUI.selectOption(form, 'boxTypeId', 0);
      semanticUI.selectOption(form, 'filmTypeId', 0);
      semanticUI.check(form, 'defaulted');

      form.find('form').simulate('submit');

      jestExpect(form.find(Confirm)).toExist();
    });

    test('clear store', () => {
      let component;
      const clearTarePackagesSpy = jest.fn();
      component = new CreateTarePackageComponent({
        clearTarePackages: clearTarePackagesSpy
      });

      component.componentWillUnmount();

      jestExpect(clearTarePackagesSpy).toHaveBeenCalledTimes(1);
    });
  });

  test('should go return to tare package maintenance on f4', () => {
    const props = { replacePath: jest.fn() };

    f4Behavior(props);

    jestExpect(props.replacePath).toHaveBeenCalledWith('/settings/tare-packages');
  });
});
