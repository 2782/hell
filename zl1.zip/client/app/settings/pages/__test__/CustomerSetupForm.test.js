import React from 'react';
import { Provider } from 'react-redux';
import { mount } from 'enzyme';
import semanticUI from '../../../../test-helpers/semantic-ui';
import { createReduxStore } from '../../../store';
import customerFactory from '../../../../test-factories/customerFactory';
import CustomerSetupForm, { asyncValidate, CustomerSetup } from '../CustomerSetupForm';
import settingsResources from '../../../shared/api/settingsResources';
import { getCustomer } from '../../actions/settingsActions';
import { NOT_A_CUSTOMER_CODE } from '../../../../config/errorMessage';
import { GET_CUSTOMER } from '../../actions/settingsActionTypes';
import productResources from '../../../shared/api/productResources';
import productFactory from '../../../../test-factories/productFactory';
import { Button } from 'semantic-ui-react';
import { selectUploadFile } from '../../../uploadFile/fileUploadActions';

jest.mock('../../../shared/api/settingsResources');
jest.mock('../../../shared/api/productResources');

const customer = customerFactory.build({
  dateType: 'FREEZEBY',
  dateValue: 15,
  subPrimals: [{ subPrimalCode: '123', dateValue: 99 }],
  customerSpecificItemNumbers: [
    {
      itemNumber: '12312',
      productCode: '2111203'
    }
  ]
});

const customerWithImage = customerFactory.build({
  dateType: 'FREEZEBY',
  dateValue: 15,
  subPrimals: [{ subPrimalCode: '123', dateValue: 99 }],
  customerSpecificItemNumbers: [
    {
      itemNumber: '12312',
      productCode: '2111203'
    }
  ],
  customerImageFile: {
    fileName: 'usda-bug.png',
    fileType: 'image/png',
    data: 'xx',
    id: 3,
    createdAt: '1970-01-01T09:16:46.938',
    updatedAt: null
  }
});

const product = productFactory.build({});

describe('customer setup', () => {
  let form;
  let store;

  beforeEach(() => {
    store = createReduxStore();
    form = mount(
      <Provider store={store}>
        <CustomerSetupForm />
      </Provider>
    );

    settingsResources.getCustomer.mockResolvedValue({ data: customer });
    productResources.getProductInfoPromise.mockResolvedValue({ data: product });
  });

  afterEach(() => {
    settingsResources.getCustomer.mockReset();
    productResources.getProductInfoPromise.mockReset();
  });

  test('shows defaults when no customer is loaded', async () => {
    jestExpect(semanticUI.getInputValue(form, 'customerCode')).toEqual('');
    jestExpect(semanticUI.getSelectValue(form, 'dateType')).toEqual('NONE');
    jestExpect(
      semanticUI.getInputValue(form, 'customerSpecificItemNumbers[0].productCode')
    ).toEqual('');
    jestExpect(semanticUI.getInputValue(form, 'customerSpecificItemNumbers[0].itemNumber')).toEqual(
      ''
    );
    jestExpect(form.find(Button).at(0)).toBeDisabled();
  });

  test('shows keep disable button if customer is not loaded', async () => {
    semanticUI.changeInput(form, 'customerCode', '99998');
    jestExpect(form.find(Button).at(0)).toBeDisabled();
  });

  describe('customer logo', () => {
    test('Enable save button when file upload is selected when an existing image does not exist', async () => {
      settingsResources.getCustomer.mockResolvedValue({ data: customer });
      semanticUI.changeInput(form, 'customerCode', '99998');
      await waitForAsyncTasks(form);

      semanticUI.changeInput(form, 'includeCustomerLogo', true);
      jestExpect(form.find(Button).at(0)).toBeDisabled();

      store.dispatch(selectUploadFile({ target: { files: ['a fake file'] } }));

      await waitForAsyncTasks(form);

      jestExpect(form.find(Button).at(0)).not.toBeDisabled();
    });

    test('Enable save button when file upload is selected when an existing image does exist', async () => {
      settingsResources.getCustomer.mockResolvedValue({ data: customerWithImage });

      semanticUI.changeInput(form, 'customerCode', '99998');
      await waitForAsyncTasks(form);

      jestExpect(semanticUI.getCheckBoxValue(form, 'includeCustomerLogo')).toEqual(true);

      jestExpect(form.find(Button).at(0)).toBeDisabled();

      store.dispatch(selectUploadFile({ target: { files: ['a fake file'] } }));

      await waitForAsyncTasks(form);

      jestExpect(form.find(Button).at(0)).not.toBeDisabled();
    });

    test('Enable save button when file upload is unchecked if customer has an existing image', async () => {
      settingsResources.getCustomer.mockResolvedValue({ data: customerWithImage });

      semanticUI.changeInput(form, 'customerCode', '99998');
      await waitForAsyncTasks(form);

      semanticUI.changeInput(form, 'includeCustomerLogo', false);

      jestExpect(form.find(Button).at(0)).not.toBeDisabled();
    });

    test('Enable disable save when check box with file and then unselect', async () => {
      semanticUI.changeInput(form, 'customerCode', '99998');
      await waitForAsyncTasks(form);

      semanticUI.changeInput(form, 'includeCustomerLogo', true);
      jestExpect(form.find(Button).at(0)).toBeDisabled();

      store.dispatch(selectUploadFile({ target: { files: ['a fake file'] } }));
      await waitForAsyncTasks(form);

      semanticUI.changeInput(form, 'includeCustomerLogo', false);
      jestExpect(form.find(Button).at(0)).toBeDisabled();
    });

    test('Enable save button when file upload is selected when an existing image does exist', async () => {
      settingsResources.getCustomer.mockResolvedValue({ data: customerWithImage });
      settingsResources.setupCustomer.mockImplementation(
        jest.fn(() => Promise.resolve({ data: customerWithImage }))
      );

      semanticUI.changeInput(form, 'customerCode', '99998');
      await waitForAsyncTasks(form);

      semanticUI.selectOption(form, 'dateType', 0);
      jestExpect(form.find(Button).at(0)).not.toBeDisabled();

      form.find('form').simulate('submit');

      await waitForAsyncTasks();

      jestExpect(settingsResources.setupCustomer.mock.calls[0][0]).toEqual({
        customerCode: '99998',
        dateType: 'NONE',
        dateValue: undefined,
        includeCustomerLogo: true,
        subPrimals: [],
        customerSpecificItemNumbers: [{ itemNumber: '12312', productCode: '2111203' }]
      });
      settingsResources.setupCustomer.mockReset();
    });

    test('Disable save button when error is displayed', async () => {
      settingsResources.getSubPrimal.mockImplementation((subprimalCode, success) => {
        success({ data: { subPrimalCode: '123', subPrimalDescription: 'BEEF SHORT RIBS' } });
      });
      settingsResources.getCustomer.mockResolvedValue({ data: customer });
      settingsResources.setupCustomer.mockReset();
      settingsResources.setupCustomer.mockImplementation(
        jest.fn(() =>
          Promise.reject({
            response: {
              data: {
                exceptionClass: 'org.opensaml.xml.validation.ValidationException',
                exceptionMessage:
                  'org.springframework.web.multipart.support.StandardMultipartHttpServletRequest$StandardMultipartFile@51f3279e is Invalid file type. Only PNG, JPG or BMP images are allowed. for setupCustomer.file',
                method: 'POST',
                path: '/api/customers/setup',
                status: 0,
                statusText: '',
                timestamp: 1561484647438
              }
            }
          })
        )
      );

      semanticUI.changeInput(form, 'customerCode', '99998');
      await waitForAsyncTasks(form);

      semanticUI.changeInput(form, 'includeCustomerLogo', true);
      jestExpect(form.find(Button).at(0)).toBeDisabled();

      store.dispatch(selectUploadFile({ target: { files: ['a fake file'] } }));
      await waitForAsyncTasks(form);
      jestExpect(form.find(Button).at(0)).not.toBeDisabled();

      form.find('form').simulate('submit');
      await waitForAsyncTasks();

      form.update();

      jestExpect(form.find(Button).at(0)).toBeDisabled();
      jestExpect(form.find('.red .message')).toHaveText(
        'Invalid file type. Only JPG, JPEG, PNG or BMP images are allowed.'
      );

      semanticUI.selectOption(form, 'dateType', 1);
      jestExpect(form.find(Button).at(0)).toBeDisabled();

      settingsResources.setupCustomer.mockReset();
    });
  });

  describe('subprimal codes', () => {
    test('submit form values without blank rows', async () => {
      settingsResources.setupCustomer.mockImplementation(
        jest.fn(() => Promise.resolve({ data: customer }))
      );

      semanticUI.changeInput(form, 'customerCode', '99998');

      await waitForAsyncTasks(form);

      form.find('form').simulate('submit');

      await waitForAsyncTasks();

      jestExpect(settingsResources.setupCustomer.mock.calls[0][0]).toEqual({
        customerCode: '99998',
        dateType: 'FREEZEBY',
        dateValue: '15',
        includeCustomerLogo: false,
        subPrimals: [{ subPrimalCode: '123', dateValue: '99', default: false }],
        customerSpecificItemNumbers: [{ itemNumber: '12312', productCode: '2111203' }]
      });
    });

    test('loads existing subprimal code and description when customers current date type is selected', async () => {
      settingsResources.getSubPrimal.mockImplementation((subprimalCode, success) => {
        success({ data: { subPrimalCode: '123', subPrimalDescription: 'BEEF SHORT RIBS' } });
      });

      semanticUI.changeInput(form, 'customerCode', '99998');

      await waitForAsyncTasks(form);

      semanticUI.selectOption(form, 'dateType', 1);

      jestExpect(form).toContainMatchingElement('.subprimal-table');
      jestExpect(semanticUI.getInputValue(form, 'subPrimals[0].dateValue')).toEqual('15');
      jestExpect(semanticUI.getInputValue(form, 'subPrimals[1].subPrimalCode')).toEqual('123');
      jestExpect(semanticUI.getInputValue(form, 'subPrimals[1].dateValue')).toEqual('99');
      jestExpect(form.find('td .subPrimal-description').at(1)).toHaveText('BEEF SHORT RIBS');
    });

    test('clears the subprimal table when date type other than current date type is selected', async () => {
      semanticUI.changeInput(form, 'customerCode', '99998');

      await waitForAsyncTasks(form);

      semanticUI.selectOption(form, 'dateType', 2);

      jestExpect(semanticUI.getInputValue(form, 'subPrimals[0].dateValue')).toEqual('');
    });

    test('hides the subprimal table completely when NONE date type is selected', async () => {
      semanticUI.changeInput(form, 'customerCode', '99998');

      await waitForAsyncTasks(form);

      semanticUI.selectOption(form, 'dateType', 0);

      jestExpect(semanticUI.getSelectValue(form, 'dateType')).toEqual('NONE');

      jestExpect(form).not.toContainMatchingElement('.subprimal-table');
    });

    test('should add another row after entering a subprimal code and date', async () => {
      semanticUI.changeInput(form, 'customerCode', '99998');

      await waitForAsyncTasks(form);

      jestExpect(semanticUI.getInputValue(form, 'subPrimals[1].subPrimalCode')).toEqual('123');
      semanticUI.changeInput(form, 'subPrimals[2].subPrimalCode', '109');

      jestExpect(semanticUI.getInputValue(form, 'subPrimals[3].subPrimalCode')).toEqual('');
      jestExpect(semanticUI.getInputValue(form, 'subPrimals[3].dateValue')).toEqual('');
    });

    test('shows invalid subprimal code message when bad code entered in new row', async () => {
      settingsResources.getSubPrimal.mockImplementation((subprimalCode, success, fail) => {
        if (subprimalCode === '123') {
          return success({
            data: { subPrimalCode: '123', subPrimalDescription: 'BEEF SHORT RIBS' }
          });
        }
        return fail(); // call fail if code entered is not 123
      });

      semanticUI.changeInput(form, 'customerCode', '99998');

      await waitForAsyncTasks();
      form = form.update(form);

      semanticUI.changeInput(form, 'subPrimals[2].subPrimalCode', '109');

      jestExpect(semanticUI.findErrorLabels(form)).toExist();
      jestExpect(semanticUI.findErrorLabels(form)).toHaveText('Invalid subprimal code');
    });

    test('replacing existing good subprimal code with bad code first shows error messages', async () => {
      settingsResources.getSubPrimal.mockImplementation((subprimalCode, success, fail) => {
        if (subprimalCode === '123') {
          return success({
            data: { subPrimalCode: '123', subPrimalDescription: 'BEEF SHORT RIBS' }
          });
        }
        return fail();
      });

      semanticUI.changeInput(form, 'customerCode', '99998');

      await waitForAsyncTasks();
      form = form.update(form);

      const firstSubPrimalField = 'subPrimals[1].subPrimalCode';

      jestExpect(semanticUI.getInputValue(form, firstSubPrimalField)).toEqual('123');

      semanticUI.typeInput(form, firstSubPrimalField, '1'); // typing clears error message
      jestExpect(semanticUI.findErrorLabels(form)).not.toExist();

      semanticUI.changeInput(form, firstSubPrimalField, '109'); // blurring away will render error message

      jestExpect(semanticUI.findErrorLabels(form)).toExist();
      jestExpect(semanticUI.findErrorLabels(form)).toHaveText('Invalid subprimal code');

      semanticUI.typeInput(form, firstSubPrimalField, '1'); // typing again clears error message
      jestExpect(semanticUI.findErrorLabels(form)).not.toExist();
    });

    test('when duplicate subprimal code added show error message on all duplicates', async () => {
      settingsResources.getSubPrimal.mockImplementation((subprimalCode, success) =>
        success({
          data: { subPrimalCode: '123', subPrimalDescription: 'BEEF SHORT RIBS' }
        })
      );

      semanticUI.changeInput(form, 'customerCode', '99998');

      await waitForAsyncTasks();
      form = form.update(form);

      const firstSubPrimalField = 'subPrimals[1].subPrimalCode';
      const duplicateSubPrimalField = 'subPrimals[2].subPrimalCode';

      jestExpect(semanticUI.getInputValue(form, firstSubPrimalField)).toEqual('123');

      semanticUI.typeInput(form, duplicateSubPrimalField, '123'); // field gets marked as touched validation errors
      jestExpect(semanticUI.findErrorLabels(form)).toExist();
      jestExpect(semanticUI.findErrorLabels(form)).toHaveLength(2);
    });

    test('should show selected sell by', async () => {
      let sellByCustomer = {
        name: 'GRILLED CHEESE FACTORY',
        customerCode: '99998',
        lineOne: '1390 Enclave Parkway',
        lineTwo: 'Houston, TX 77077-2099',
        city: 'Houston',
        country: 'TX',
        dateType: 'SELLBY',
        dateValue: 15,
        postalCode: '75835',
        routingGroups: 1
      };
      settingsResources.getCustomer.mockResolvedValueOnce({ data: sellByCustomer });

      semanticUI.changeInput(form, 'customerCode', '99998');

      await waitForAsyncTasks();
      form = form.update();

      jestExpect(semanticUI.getSelectValue(form, 'dateType')).toEqual('SELLBY');
    });
  });

  describe('customer specific items numbers', () => {
    test('should populate form with existing products and their description from customer', async () => {
      const product = productFactory.build({ code: '2111203' });

      productResources.getProductInfoPromise.mockResolvedValue({
        data: product
      });

      semanticUI.changeInput(form, 'customerCode', '99998');
      await waitForAsyncTasks(form);

      jestExpect(
        semanticUI.getInputValue(form, 'customerSpecificItemNumbers[0].productCode')
      ).toEqual('2111203');

      const firstRowProductDescription = form
        .find('[pid="customerSpecificItemNumbers_0__productCodeDescription"]')
        .at(0);

      jestExpect(firstRowProductDescription).toHaveText(product.description);
    });

    test('should populate description of existing customer product', async () => {
      productResources.getProductInfoPromise.mockResolvedValue({ data: product });

      semanticUI.changeInput(form, 'customerCode', '99998');
      await waitForAsyncTasks(form);

      semanticUI.changeInput(form, 'customerSpecificItemNumbers[1].productCode', product.code);

      await waitForAsyncTasks(form);

      const secondRowProductDescription = form
        .find('[pid="customerSpecificItemNumbers_1__productCodeDescription"]')
        .at(0);

      jestExpect(secondRowProductDescription).toHaveText(product.description);
    });

    test('should show invalid product message if entered product is invalid', async () => {
      productResources.getProductInfoPromise.mockResolvedValueOnce({ data: product });
      productResources.getProductInfoPromise.mockRejectedValueOnce();

      semanticUI.changeInput(form, 'customerCode', '99998');
      await waitForAsyncTasks(form);

      semanticUI.changeInput(form, 'customerSpecificItemNumbers[1].productCode', product.code);

      await waitForAsyncTasks(form);

      jestExpect(semanticUI.findErrorLabels(form)).toHaveLength(1);
      jestExpect(semanticUI.findErrorLabels(form)).toHaveText('Invalid Item Number');
    });

    test('product code required message shows when item number is filled', async () => {
      semanticUI.changeInput(form, 'customerCode', '99998');
      await waitForAsyncTasks(form);

      semanticUI.changeInput(form, 'customerSpecificItemNumbers[1].productCode', '');
      semanticUI.changeInput(form, 'customerSpecificItemNumbers[1].itemNumber', 'abc');

      jestExpect(semanticUI.findErrorLabels(form)).toHaveLength(1);
      jestExpect(semanticUI.findErrorLabels(form)).toHaveText('Required');
    });

    test('customer item number required message shows when product code is filled', async () => {
      settingsResources.getCustomer.mockResolvedValue({ data: customer });

      semanticUI.changeInput(form, 'customerCode', '99998');
      await waitForAsyncTasks(form);

      semanticUI.changeInput(form, 'customerSpecificItemNumbers[1].productCode', '4102218');
      semanticUI.changeInput(form, 'customerSpecificItemNumbers[1].itemNumber', '');

      jestExpect(semanticUI.findErrorLabels(form)).toHaveLength(1);
      jestExpect(semanticUI.findErrorLabels(form)).toHaveText('Required');
    });
  });
});
test('should call clearCustomer when componentWillUnmount', () => {
  let clearCustomerSpy = jest.fn();
  let clearState = jest.fn();

  const customerSetup = new CustomerSetup({
    getCustomer: () => {},
    setupCustomer: () => {},
    clearState: clearState,
    clearCustomer: clearCustomerSpy,
    handleSubmit: () => {}
  });

  customerSetup.componentWillUnmount();

  jestExpect(clearCustomerSpy).toHaveBeenCalled();
  jestExpect(clearState).toHaveBeenCalled();
});

test('async validate dispatches actions on successful customer retrieval', async () => {
  settingsResources.getCustomer.mockResolvedValue({ data: 'it worked!' });
  const dispatch = jest.fn();

  const values = { customerCode: '99998' };
  const wrappedFunction = code => getCustomer(code)(dispatch);
  const props = { getCustomer: wrappedFunction };

  await asyncValidate(values, jest.fn(), props);

  jestExpect(dispatch).toHaveBeenCalledWith({
    type: GET_CUSTOMER,
    payload: 'it worked!'
  });
});

test('async validate returns object with error message to redux form when customer not found', async () => {
  settingsResources.getCustomer.mockRejectedValue({ error: 'something' });
  const dispatch = jest.fn();

  const values = { customerCode: '99998' };
  const wrappedFunction = code => getCustomer(code)(dispatch);
  const props = { getCustomer: wrappedFunction };

  const result = await asyncValidate(values, jest.fn(), props);

  jestExpect(result).toEqual({ customerCode: NOT_A_CUSTOMER_CODE });
});
