import WorkdaySettings from '../WorkdaySettings';
import { mount } from 'enzyme';
import React from 'react';
import settingsResources from '../../../shared/api/settingsResources';
import store from '../../../store';
import { Provider } from 'react-redux';
import operatingDatesResource from '../../../shared/api/operatingDatesResource';
import semanticUI from '../../../../test-helpers/semantic-ui';

jest.mock('../../../shared/api/settingsResources');
jest.mock('../../../shared/api/operatingDatesResource');

const weekendsResponse = [
  {
    key: 'sunday',
    value: false,
    id: 2
  },
  {
    key: 'saturday',
    value: true,
    id: 1
  }
];

const operatingDatesResponse = {
  data: {
    today: '2018-02-11',
    first: '2018-02-11',
    second: '2018-02-12'
  }
};

const getSettingsState = () => {
  return store.getState().settingsInfo;
};

describe('WorkdaySettings', () => {
  let wrapper,
    eidIso,
    eidDisplay,
    mlkIso,
    mlkDisplay,
    independenceDayIso,
    independenceDayDisplay,
    thanksgivingIso,
    thanksgivingDisplay;

  beforeEach(() => {
    eidIso = {
      date: '2018-06-14',
      description: 'Eid',
      id: 375
    };

    eidDisplay = {
      date: '06-14-2018',
      description: 'Eid',
      id: 375
    };

    mlkIso = {
      date: '2018-01-15',
      description: 'Martin Luther King Jr. Day',
      id: 772
    };

    mlkDisplay = {
      date: '01-15-2018',
      description: 'Martin Luther King Jr. Day',
      id: 772
    };

    independenceDayIso = {
      date: '2018-07-04',
      description: 'Independence Day',
      id: 179
    };

    independenceDayDisplay = {
      date: '07-04-2018',
      description: 'Independence Day',
      id: 179
    };

    thanksgivingIso = {
      date: '2018-11-22',
      description: 'Thanksgiving',
      id: 444
    };

    thanksgivingDisplay = {
      date: '11-22-2018',
      description: 'Thanksgiving',
      id: 444
    };

    const getHolidaysResponse = {
      data: [mlkIso, eidIso, independenceDayIso]
    };

    const createHolidayResponse = {
      data: thanksgivingIso
    };

    settingsResources.getHolidays.mockImplementation(callback => callback(getHolidaysResponse));
    settingsResources.createHoliday.mockImplementation((holiday, callback) =>
      callback(createHolidayResponse)
    );
    settingsResources.getWeekends.mockImplementation(callback => callback(weekendsResponse));
    settingsResources.deleteHoliday.mockImplementation((id, callback) => callback());
    operatingDatesResource.getOperatingDates.mockImplementation((roomCode, callback) =>
      callback(operatingDatesResponse)
    );

    wrapper = mount(
      <Provider store={store}>
        <WorkdaySettings />
      </Provider>
    );
  });

  afterEach(() => {
    settingsResources.getHolidays.mockReset();
    settingsResources.createHoliday.mockReset();
    settingsResources.getWeekends.mockReset();
    settingsResources.deleteHoliday.mockReset();
    operatingDatesResource.getOperatingDates.mockReset();
  });

  describe('on mount', () => {
    test('should get holidays and save response to settings store', () => {
      jestExpect(getSettingsState().holidays).toEqual([
        { index: 0, data: mlkDisplay },
        { index: 1, data: eidDisplay },
        { index: 2, data: independenceDayDisplay }
      ]);
    });

    test('should get weekends and save response to settings store', () => {
      jestExpect(getSettingsState().weekends).toEqual([
        { key: 'sunday', value: false, id: 2 },
        { key: 'saturday', value: true, id: 1 }
      ]);
    });
  });

  describe('on render', () => {
    test('should pass holidays to HolidaySettings child', () => {
      jestExpect(wrapper.find('HolidaySettingsComponent')).toExist();

      jestExpect(wrapper.find('HolidayTableComponent')).toHaveProp({
        holidays: [
          { index: 0, data: mlkDisplay },
          { index: 1, data: eidDisplay },
          { index: 2, data: independenceDayDisplay }
        ]
      });
    });

    test('should pass weekends to WeekendsSettings child', () => {
      jestExpect(wrapper.find('WeekendSettings')).toExist();

      jestExpect(wrapper.find('WeekendSettings')).toHaveProp({
        weekends: [{ key: 'sunday', value: false, id: 2 }, { key: 'saturday', value: true, id: 1 }]
      });
    });
  });

  describe('on click', () => {
    test('should create and update holidays', () => {
      const getHolidaysResponseAfterUpdate = {
        data: [mlkDisplay, eidDisplay, independenceDayDisplay, thanksgivingDisplay]
      };

      settingsResources.getHolidays.mockImplementation(callback =>
        callback(getHolidaysResponseAfterUpdate)
      );
      semanticUI.changeInput(wrapper, 'date', thanksgivingDisplay.date);
      wrapper
        .find('form')
        .find('input')
        .at(1)
        .simulate('change', { target: { value: thanksgivingDisplay.description } });

      wrapper
        .find('form')
        .at(0)
        .simulate('submit');

      jestExpect(wrapper.find('HolidayTableComponent').props().holidays).toEqual([
        { index: 0, data: mlkDisplay },
        { index: 1, data: eidDisplay },
        { index: 2, data: independenceDayDisplay },
        { index: 3, data: thanksgivingDisplay }
      ]);
    });

    test('should delete newly created holidays', () => {
      const getHolidaysResponseAfterUpdate = {
        data: [mlkDisplay, eidDisplay, independenceDayDisplay, thanksgivingDisplay]
      };
      settingsResources.getHolidays.mockImplementation(callback =>
        callback(getHolidaysResponseAfterUpdate)
      );
      semanticUI.changeInput(wrapper, 'date', thanksgivingDisplay.date);
      wrapper
        .find('form')
        .find('input')
        .at(1)
        .simulate('change', { target: { value: thanksgivingDisplay.description } });

      wrapper
        .find('form')
        .at(0)
        .simulate('submit');

      wrapper
        .find('tr[pid="holiday-3"]')
        .children()
        .get(3)
        .props.children.props.onClick();
      wrapper.update();

      jestExpect(wrapper.find('HolidayTableComponent').props().holidays).toEqual([
        { index: 0, data: mlkDisplay },
        { index: 1, data: eidDisplay },
        { index: 2, data: independenceDayDisplay }
      ]);
    });

    test('should delete holidays', () => {
      wrapper
        .find('tr[pid="holiday-0"]')
        .children()
        .get(3)
        .props.children.props.onClick();
      wrapper.update();

      jestExpect(wrapper.find('HolidayTableComponent').props().holidays).toEqual([
        { index: 1, data: eidDisplay },
        { index: 2, data: independenceDayDisplay }
      ]);
    });

    test('should not update holidays when data is invalid', () => {
      semanticUI.changeInput(wrapper, 'date', '2017-01-01');
      wrapper
        .find('input')
        .at(0)
        .simulate('change', { target: { value: 'Date before current date' } });

      wrapper
        .find('form')
        .at(0)
        .simulate('submit');

      jestExpect(wrapper.find('HolidayTableComponent').props().holidays).toEqual([
        { index: 0, data: mlkDisplay },
        { index: 1, data: eidDisplay },
        { index: 2, data: independenceDayDisplay }
      ]);
    });

    test('should not create when description field is empty', () => {
      semanticUI.changeInput(wrapper, 'date', thanksgivingDisplay.date);
      wrapper
        .find('form')
        .find('input')
        .at(1)
        .simulate('change', { target: { value: '' } });

      wrapper
        .find('form')
        .at(0)
        .simulate('submit');

      jestExpect(wrapper.find('HolidayTableComponent').props().holidays).toEqual([
        { index: 0, data: mlkDisplay },
        { index: 1, data: eidDisplay },
        { index: 2, data: independenceDayDisplay }
      ]);
    });
  });
});

describe('error handling', () => {
  let wrapper, thanksgiving;

  afterEach(() => {
    settingsResources.createHoliday.mockReset();
    operatingDatesResource.getOperatingDates.mockReset();
  });

  beforeEach(() => {
    settingsResources.createHoliday.mockImplementationOnce((holiday, success, failure) =>
      failure({
        message: 'nonsense',
        showing: true
      })
    );
    operatingDatesResource.getOperatingDates.mockImplementationOnce((arg, callback) =>
      callback(operatingDatesResponse)
    );
    wrapper = mount(
      <Provider store={store}>
        <WorkdaySettings />
      </Provider>
    );

    thanksgiving = {
      date: '2018-11-22',
      description: 'Thanksgiving',
      id: 444
    };
  });

  test('should notify user when there is an error', () => {
    semanticUI.changeInput(wrapper, 'date', '11-11-2018');
    wrapper
      .find('form')
      .find('input')
      .at(1)
      .simulate('change', { target: { value: thanksgiving.description } });

    wrapper
      .find('form')
      .at(0)
      .simulate('submit');

    jestExpect(wrapper.find('.instruction')).toHaveText('nonsense');
  });

  test('should notify user invalid date when data is invalid', () => {
    semanticUI.changeInput(wrapper, 'date', '2017-01-01');
    wrapper
      .find('input')
      .at(0)
      .simulate('change', { target: { value: 'Date before current date' } });

    wrapper
      .find('form')
      .at(0)
      .simulate('submit');

    jestExpect(wrapper.find('.pointing')).toHaveText('Please enter valid date');
  });
});
