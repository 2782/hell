import React from 'react';
import { createReduxStore } from '../../../store';
import { mount } from 'enzyme';
import { Provider } from 'react-redux';
import FiscalCalenderSetup from '../FiscalCalendarSetup';
import semanticUI from '../../../../test-helpers/semantic-ui';

describe('fiscalCalendarSetup', () => {
  let store, state, form;

  test('should render', () => {
    state = {};
    store = createReduxStore(state);
    form = mount(
      <Provider store={store}>
        <FiscalCalenderSetup />
      </Provider>
    );
    jestExpect(form.find('div[pid="fiscal-calendar_current_start_date"]').find('span')).toHaveText(
      ''
    );
    jestExpect(semanticUI.getInputValue(form, 'nextStartDate')).toEqual('');
  });

  test('should render with initial states', () => {
    state = {
      settingsInfo: {
        activeFiscalCalendar: {
          id: 1,
          startDate: '07-02-2017',
          nextStartDate: '07-01-2018'
        }
      }
    };

    store = createReduxStore(state);
    form = mount(
      <Provider store={store}>
        <FiscalCalenderSetup />
      </Provider>
    );

    jestExpect(form.find('div[pid="fiscal-calendar_current_start_date"]').find('span')).toHaveText(
      '07-02-2017'
    );
    jestExpect(semanticUI.getInputValue(form, 'nextStartDate')).toEqual('07-01-2018');
  });
});
