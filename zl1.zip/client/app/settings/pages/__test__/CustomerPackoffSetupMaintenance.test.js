import React from 'react';
import { mount, shallow } from 'enzyme';
import MaintenanceTable from '../../components/MaintenanceTable';
import CustomerPackoffSetupMaintenance, {
  CustomerPackoffSetupMaintenanceComponent
} from '../CustomerPackoffSetupMaintenance';
import { Button, Table } from 'semantic-ui-react';
import { createReduxStore } from '../../../store';
import customerFactory from '../../../../test-factories/customerFactory';

describe('customerPackoffSetupMaintenance', () => {
  test('should render Maintenance table', () => {
    const fakeCustomers = [{ customer1: 'foo', customer2: 'bar' }];
    const wrapper = shallow(
      <CustomerPackoffSetupMaintenanceComponent
        allCustomers={fakeCustomers}
        getCustomers={() => {}}
      />
    );

    jestExpect(wrapper.find(MaintenanceTable)).toHaveLength(1);
  });

  test('should pass down customers to item prop in Maintenance table', () => {
    const fakeCustomers = [{ customer1: 'foo', customer2: 'bar' }];
    const wrapper = shallow(
      <CustomerPackoffSetupMaintenanceComponent
        allCustomers={fakeCustomers}
        getCustomers={() => {}}
      />
    );

    jestExpect(wrapper.find(MaintenanceTable)).toHaveProp({ items: fakeCustomers });
  });

  test('should call getCustomers action on mount', () => {
    const getCustomersSpy = jest.fn();
    shallow(
      <CustomerPackoffSetupMaintenanceComponent getCustomers={getCustomersSpy} allCustomers={[]} />
    );

    jestExpect(getCustomersSpy).toHaveBeenCalledTimes(1);
  });

  test('should be able to call replace path action on button click', () => {
    const fakeCustomers = [{ customer1: 'foo', customer2: 'bar' }];
    const replacePathSpy = jest.fn();
    const wrapper = mount(
      <CustomerPackoffSetupMaintenanceComponent
        replacePath={replacePathSpy}
        allCustomers={fakeCustomers}
        getCustomers={() => {}}
      />
    );

    const newButton = wrapper.find(Button);

    newButton.simulate('click');

    jestExpect(replacePathSpy).toHaveBeenCalledWith(
      '/settings/customers-packoff-display/customer-setup'
    );
  });

  test('should render customer packoff settings sorted by name filtering out dateType NONE', () => {
    let customerZ = customerFactory.build({
      name: 'Z Customer',
      customerCode: '123',
      dateTypeDisplayName: 'FREEZE BY',
      dateType: 'FREEZEBY',
      dateValue: 3
    });

    let customerA = customerFactory.build({
      name: 'A Customer',
      customerCode: '123',
      dateTypeDisplayName: 'BEST BY',
      dateType: 'BESTBY',
      dateValue: 17
    });

    let customerC = customerFactory.build({
      name: 'C Customer',
      customerCode: '199',
      dateTypeDisplayName: 'NONE',
      dateType: 'NONE',
      dateValue: 17
    });

    const replacePathSpy = jest.fn();
    let mockStore = createReduxStore({
      settingsInfo: { customers: [customerZ, customerA, customerC] }
    });
    const wrapper = mount(
      <CustomerPackoffSetupMaintenance
        store={mockStore}
        allCustomer={[customerZ, customerA, customerC]}
        getCustomers={() => {}}
        replacePath={replacePathSpy}
      />
    );

    const tableBodies = wrapper.find(Table.Body);
    jestExpect(tableBodies).toHaveLength(1);

    let firstCustomerRow = tableBodies
      .at(0)
      .find(Table.Row)
      .at(0);
    jestExpect(firstCustomerRow.find(Table.Cell).at(0)).toHaveText('A Customer 123');
    jestExpect(firstCustomerRow.find(Table.Cell).at(1)).toHaveText('BEST BY');
    jestExpect(firstCustomerRow.find(Table.Cell).at(2)).toHaveText('17');

    let secondCustomerRow = tableBodies
      .at(0)
      .find(Table.Row)
      .at(1);
    jestExpect(secondCustomerRow.find(Table.Cell).at(0)).toHaveText('Z Customer 123');
    jestExpect(secondCustomerRow.find(Table.Cell).at(1)).toHaveText('FREEZE BY');
    jestExpect(secondCustomerRow.find(Table.Cell).at(2)).toHaveText('3');
  });
});
