import { validateSubmission } from '../profileValidator';
import profileFactory from '../../../../test-factories/Profile';

describe('profileValidator', () => {
  let values;

  test('should validate successfully and call submit', () => {
    values = profileFactory.build();
    validateSubmission(values);
  });

  test('should validate successfully and call submit with capital letter', () => {
    values = profileFactory.build({ establishmentNumber: 'zA1' });
    validateSubmission(values);
  });

  test('should throw error when plantNumber is empty', () => {
    const values = profileFactory.build({ plantNumber: '' });

    try {
      validateSubmission(values);
      fail('Validator should have thrown');
    } catch ({ errors }) {
      jestExpect(errors).toEqual({
        plantNumber: 'Required',
        _error: 'Submission Failed!'
      });
    }
  });

  test('should throw error when plantNumber length is not 3', () => {
    const values = profileFactory.build({ plantNumber: '1234' });

    try {
      validateSubmission(values);
      fail('Validator should have thrown');
    } catch ({ errors }) {
      jestExpect(errors).toEqual({
        plantNumber: 'Must be 3 characters',
        _error: 'Submission Failed!'
      });
    }
  });

  test('should throw error when plantNumber is not wholeNumber', () => {
    const values = profileFactory.build({ plantNumber: 'abc' });

    try {
      validateSubmission(values);
      fail('Validator should have thrown');
    } catch ({ errors }) {
      jestExpect(errors).toEqual({
        plantNumber: 'Only whole number characters',
        _error: 'Submission Failed!'
      });
    }
  });

  test('should throw error when city is empty', () => {
    const values = profileFactory.build({ city: '' });

    try {
      validateSubmission(values);
      fail('Validator should have thrown');
    } catch ({ errors }) {
      jestExpect(errors).toEqual({
        city: 'Required',
        _error: 'Submission Failed!'
      });
    }
  });

  test('should throw error when name is empty', () => {
    const values = profileFactory.build({ name: '' });

    try {
      validateSubmission(values);
      fail('Validator should have thrown');
    } catch ({ errors }) {
      jestExpect(errors).toEqual({
        name: 'Required',
        _error: 'Submission Failed!'
      });
    }
  });

  test('should throw error when address is empty', () => {
    const values = profileFactory.build({ address: '' });

    try {
      validateSubmission(values);
      fail('Validator should have thrown');
    } catch ({ errors }) {
      jestExpect(errors).toEqual({
        address: 'Required',
        _error: 'Submission Failed!'
      });
    }
  });

  test('should throw error when zipCode is empty', () => {
    const values = profileFactory.build({ zipCode: '' });

    try {
      validateSubmission(values);
      fail('Validator should have thrown');
    } catch ({ errors }) {
      jestExpect(errors).toEqual({
        zipCode: 'Required',
        _error: 'Submission Failed!'
      });
    }
  });

  test('should throw error when zipCode length is not wholeNumber', () => {
    const values = profileFactory.build({ zipCode: 'abcd' });

    try {
      validateSubmission(values);
      fail('Validator should have thrown');
    } catch ({ errors }) {
      jestExpect(errors).toEqual({
        zipCode: 'Only whole number characters',
        _error: 'Submission Failed!'
      });
    }
  });

  test('should throw error when zipCode length is not 5', () => {
    const values = profileFactory.build({ zipCode: '123456' });

    try {
      validateSubmission(values);
      fail('Validator should have thrown');
    } catch ({ errors }) {
      jestExpect(errors).toEqual({
        zipCode: 'Must be 5 characters',
        _error: 'Submission Failed!'
      });
    }
  });

  test('should throw error when establishmentNumber is empty', () => {
    const values = profileFactory.build({ establishmentNumber: '' });

    try {
      validateSubmission(values);
      fail('Validator should have thrown');
    } catch ({ errors }) {
      jestExpect(errors).toEqual({
        establishmentNumber: 'Required',
        _error: 'Submission Failed!'
      });
    }
  });

  test('should throw error when establishmentNumber has other character besides number and letters', () => {
    const values = profileFactory.build({ establishmentNumber: 'y&1Z3' });

    try {
      validateSubmission(values);
      fail('Validator should have thrown');
    } catch ({ errors }) {
      jestExpect(errors).toEqual({
        establishmentNumber: 'Only numbers or letters',
        _error: 'Submission Failed!'
      });
    }
  });

  test('should throw error when vendorShipFrom has no value', () => {
    const values = profileFactory.build({ vendorShipFrom: '' });

    try {
      validateSubmission(values);
      fail('Validator should have thrown');
    } catch ({ errors }) {
      jestExpect(errors).toEqual({
        vendorShipFrom: 'Required',
        _error: 'Submission Failed!'
      });
    }
  });

  test('should throw error when vendorShipFrom has more than 6 characters', () => {
    const values = profileFactory.build({ vendorShipFrom: '1234567' });

    try {
      validateSubmission(values);
      fail('Validator should have thrown');
    } catch ({ errors }) {
      jestExpect(errors).toEqual({
        vendorShipFrom: 'Maximum 6 characters',
        _error: 'Submission Failed!'
      });
    }
  });

  test('should throw error when vendorShipFrom has other than number characters', () => {
    const values = profileFactory.build({ vendorShipFrom: '1s2' });

    try {
      validateSubmission(values);
      fail('Validator should have thrown');
    } catch ({ errors }) {
      jestExpect(errors).toEqual({
        vendorShipFrom: 'Only whole number characters',
        _error: 'Submission Failed!'
      });
    }
  });

  test('should throw error when sequenceNumber has no value', () => {
    const values = profileFactory.build({ sequenceNumber: '' });

    try {
      validateSubmission(values);
      fail('Validator should have thrown');
    } catch ({ errors }) {
      jestExpect(errors).toEqual({
        sequenceNumber: 'Required',
        _error: 'Submission Failed!'
      });
    }
  });

  test('should throw error when sequenceNumber has more than 2 characters', () => {
    const values = profileFactory.build({ sequenceNumber: '123' });

    try {
      validateSubmission(values);
      fail('Validator should have thrown');
    } catch ({ errors }) {
      jestExpect(errors).toEqual({
        sequenceNumber: 'Maximum 2 characters',
        _error: 'Submission Failed!'
      });
    }
  });

  test('should throw error when sequenceNumber has other than number characters', () => {
    const values = profileFactory.build({ sequenceNumber: '1s' });

    try {
      validateSubmission(values);
      fail('Validator should have thrown');
    } catch ({ errors }) {
      jestExpect(errors).toEqual({
        sequenceNumber: 'Only whole number characters',
        _error: 'Submission Failed!'
      });
    }
  });
});
