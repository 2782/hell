jest.mock('../../../shared/errors/ErrorNotification');

import React from 'react';
import { mount } from 'enzyme';
import configureStore from 'redux-mock-store';
import thunk from 'redux-thunk';
import SidebarNavigation from '../../../shared/components/SideNavigation';
import Administration from '../Administration';
import { createReduxStore } from '../../../store';

let middleware = [thunk];
const createStore = configureStore(middleware);

describe('Administration', () => {
  let wrapper;
  let mockStore = createStore({
    function: {}
  });

  test('should be aware of all relevant sidebar nav links', () => {
    wrapper = mount(
      <Administration
        location={{ pathname: '/settings/profile' }}
        match={{ url: '/settings' }}
        store={mockStore}
      />
    );
    const sidebar = wrapper.find(SidebarNavigation);
    jestExpect(sidebar).toHaveProp({
      currentPath: '/settings/profile',
      links: [
        {
          path: '/profile',
          toPath: jestExpect.any(Function),
          name: 'profile',
          category: 'company'
        },
        {
          path: '/workday',
          toPath: jestExpect.any(Function),
          name: 'workday/holidays',
          category: 'company'
        },
        {
          path: '/fiscal-calendar-setup',
          toPath: jestExpect.any(Function),
          name: 'Fiscal Calendar',
          category: 'corporate'
        },
        {
          path: '/tables',
          toPath: jestExpect.any(Function),
          name: 'table maintenance',
          category: 'portion room'
        },
        {
          path: '/stations',
          toPath: jestExpect.any(Function),
          name: 'station maintenance',
          category: 'portion room'
        },
        {
          path: '/rooms',
          toPath: jestExpect.any(Function),
          name: 'room maintenance',
          category: 'portion room'
        },
        {
          path: '/house-pars',
          toPath: jestExpect.any(Function),
          name: 'house par',
          category: 'portion room'
        },
        {
          path: '/customers-packoff-display',
          toPath: jestExpect.any(Function),
          name: 'customer packoff label',
          category: 'portion room'
        },
        {
          path: '/tare-packages',
          toPath: jestExpect.any(Function),
          name: 'tare setup',
          category: 'packaging'
        }
      ]
    });
  });

  test('should set subRouteByProductInfoLinks and currentPath for SideNavigation', () => {
    wrapper = mount(
      <Administration
        location={{ pathname: '/settings/profile' }}
        match={{ url: '/settings' }}
        store={mockStore}
      />
    );

    let sideNavigation = wrapper.find('SideNavigation');
    jestExpect(sideNavigation).toHaveProp({
      currentPath: '/settings/profile',
      links: [
        {
          path: '/profile',
          toPath: jestExpect.any(Function),
          name: 'profile',
          category: 'company'
        },
        {
          path: '/workday',
          toPath: jestExpect.any(Function),
          name: 'workday/holidays',
          category: 'company'
        },
        {
          path: '/fiscal-calendar-setup',
          toPath: jestExpect.any(Function),
          name: 'Fiscal Calendar',
          category: 'corporate'
        },
        {
          path: '/tables',
          toPath: jestExpect.any(Function),
          name: 'table maintenance',
          category: 'portion room'
        },
        {
          path: '/stations',
          toPath: jestExpect.any(Function),
          name: 'station maintenance',
          category: 'portion room'
        },
        {
          path: '/rooms',
          toPath: jestExpect.any(Function),
          name: 'room maintenance',
          category: 'portion room'
        },
        {
          path: '/house-pars',
          toPath: jestExpect.any(Function),
          name: 'house par',
          category: 'portion room'
        },
        {
          path: '/customers-packoff-display',
          toPath: jestExpect.any(Function),
          name: 'customer packoff label',
          category: 'portion room'
        },
        {
          path: '/tare-packages',
          toPath: jestExpect.any(Function),
          name: 'tare setup',
          category: 'packaging'
        }
      ]
    });
  });

  describe('lifecycle functions', () => {
    test('scroll page to top at component mount', () => {
      const scrollToTop = jest.fn();
      const setPageConfig = jest.fn();
      const componentDidMount = jest.fn(() => ({ setPageConfig, scrollToTop }));
      const store = createReduxStore();
      const component = new Administration({ store });
      component.componentDidMount = componentDidMount;
      component.componentDidMount().scrollToTop();
      jestExpect(scrollToTop).toBeCalled();
    });

    test('scroll page to top on component update', () => {
      const scrollToTop = jest.fn();
      const setTimeout = jest.fn(scrollToTop);
      const componentWillUpdate = jest.fn(() => ({ setTimeout, scrollToTop }));
      const store = createReduxStore();
      const component = new Administration({ store });
      component.componentWillUpdate = componentWillUpdate;
      component.componentWillUpdate().setTimeout();
      jestExpect(setTimeout).toBeCalled();
      jestExpect(scrollToTop).toBeCalled();
    });
  });
});
