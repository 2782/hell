import { processErrorResponse } from '../roomValidator';

describe('roomValidator', () => {
  test('should processErrorResponse', () => {
    const errorResponse = {
      error: {
        name: 'VALIDATION_ERROR',
        details: [
          {
            field: 'code',
            value: 'null',
            issue: 'REQUIRED',
            location: 'body',
            type: 'field'
          },
          {
            field: 'description',
            value: 'null',
            issue: 'Required',
            location: 'body',
            type: 'field'
          },
          {
            field: 'customerNumber',
            value: 'null',
            issue: 'Required',
            location: 'body',
            type: 'field'
          },
          {
            field: 'roomType',
            value: 'null',
            issue: 'Required',
            location: 'body',
            type: 'field'
          }
        ]
      }
    };

    try {
      processErrorResponse(errorResponse);
      jest.fail('Expected SubmissionError to be thrown.');
    } catch ({ errors }) {
      jestExpect(errors).toEqual({
        code: 'Required',
        description: 'Required',
        customerNumber: 'Required',
        roomType: 'Required',
        _error: 'Submission Failed!'
      });
    }
  });

  test('should processErrorResponse when issue is ALPHA_NUMERIC ', () => {
    const errorResponse = {
      error: {
        name: 'VALIDATION_ERROR',
        details: [
          {
            field: 'code',
            value: 'null',
            issue: 'ALPHA_NUMERIC',
            location: 'body',
            type: 'field'
          }
        ]
      }
    };

    try {
      processErrorResponse(errorResponse);
      jest.fail('Expected SubmissionError to be thrown.');
    } catch ({ errors }) {
      jestExpect(errors.code).toEqual('Only alphanumeric characters');
    }
  });

  test('should processErrorResponse when issue is LENGTH and field is code ', () => {
    const errorResponse = {
      error: {
        name: 'VALIDATION_ERROR',
        details: [
          {
            field: 'code',
            value: 'null',
            issue: 'LENGTH',
            location: 'body',
            type: 'field'
          }
        ]
      }
    };

    try {
      processErrorResponse(errorResponse);
      jest.fail('Expected SubmissionError to be thrown.');
    } catch ({ errors }) {
      jestExpect(errors.code).toEqual('Maximum 2 characters');
    }
  });

  test('should processErrorResponse when issue is NON_ZERO', () => {
    const errorResponse = {
      error: {
        name: 'VALIDATION_ERROR',
        details: [
          {
            field: 'code',
            value: 'null',
            issue: 'NON_ZERO',
            location: 'body',
            type: 'field'
          }
        ]
      }
    };

    try {
      processErrorResponse(errorResponse);
      jest.fail('Expected SubmissionError to be thrown.');
    } catch ({ errors }) {
      jestExpect(errors.code).toEqual('Must not be zero');
    }
  });

  test('should processErrorResponse when issue is UNIQUE and field is code', () => {
    const errorResponse = {
      error: {
        name: 'VALIDATION_ERROR',
        details: [
          {
            field: 'code',
            value: 'null',
            issue: 'UNIQUE',
            location: 'body',
            type: 'field'
          }
        ]
      }
    };

    try {
      processErrorResponse(errorResponse);
      jest.fail('Expected SubmissionError to be thrown.');
    } catch ({ errors }) {
      jestExpect(errors.code).toEqual('Room code must be unique');
    }
  });

  test('should processErrorResponse when issue is NOT_EXIST and field is customerNumber', () => {
    const errorResponse = {
      error: {
        name: 'VALIDATION_ERROR',
        details: [
          {
            field: 'customerNumber',
            value: 'null',
            issue: 'NOT_EXIST',
            location: 'body',
            type: 'field'
          }
        ]
      }
    };

    try {
      processErrorResponse(errorResponse);
      jest.fail('Expected SubmissionError to be thrown.');
    } catch ({ errors }) {
      jestExpect(errors.customerNumber).toEqual('Invalid Customer Number');
    }
  });

  test('should processErrorResponse when issue is INVALID and field is customerNumber', () => {
    const errorResponse = {
      error: {
        name: 'VALIDATION_ERROR',
        details: [
          {
            field: 'customerNumber',
            value: 'null',
            issue: 'INVALID',
            location: 'body',
            type: 'field'
          }
        ]
      }
    };

    try {
      processErrorResponse(errorResponse);
      jest.fail('Expected SubmissionError to be thrown.');
    } catch ({ errors }) {
      jestExpect(errors.customerNumber).toEqual('Must be internal customer');
    }
  });
});
