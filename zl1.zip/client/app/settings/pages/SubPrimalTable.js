import React, { Fragment } from 'react';
import PropTypes from 'prop-types';
import _ from 'lodash';
import { Field } from 'redux-form';
import { Form, Label, Table } from 'semantic-ui-react';
import FormElement from '../../shared/FormElement';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import { getSubPrimal, setSubPrimalExistTo } from '../actions/settingsActions';

const getErrorMessage = (subPrimalsExist, subPrimalField) => {
  if (_.get(subPrimalsExist, `${subPrimalField}.subPrimalCode`, true)) {
    return null;
  } else {
    return (
      <Label basic color='red' pointing>
        Invalid subprimal code
      </Label>
    );
  }
};

export class SubPrimalTableComponent extends React.Component {
  constructor(props) {
    super(props);
    this.handleSubPrimalCodeChange = this.handleSubPrimalCodeChange.bind(this);
  }

  componentDidUpdate() {
    const { fields } = this.props;
    let noEmptySubPrimalCodes = _.every(fields.getAll(), field => {
      return _.get(field, 'subPrimalCode', '') !== '';
    });

    if (noEmptySubPrimalCodes) {
      fields.push({});
    }
  }

  componentWillUnmount() {
    const { fields, setSubPrimalExistTo } = this.props;
    fields.getAll().forEach((field, index) => {
      const subPrimalCode = _.get(field, 'subPrimalCode', '');
      if (!_.isEmpty(subPrimalCode)) {
        setSubPrimalExistTo(`subPrimals[${index}].subPrimalCode`, true);
      }
    });
  }

  handleAddNewSubPrimalOnBlur(event, subPrimalCode, fieldName, index) {
    const { fields, getSubPrimal, setSubPrimalExistTo } = this.props;
    if (_.isEmpty(subPrimalCode)) {
      if (fields.length - 1 !== index) {
        event.preventDefault();
        fields.remove(index);
      }
    } else {
      getSubPrimal(subPrimalCode, () => setSubPrimalExistTo(fieldName, false));
    }
  }

  handleSubPrimalCodeChange(event, subPrimalCode, prevValue, fieldName) {
    const { setSubPrimalExistTo } = this.props;
    if (!_.isEmpty(subPrimalCode)) {
      setSubPrimalExistTo(fieldName, true);
    }
  }

  getNotification() {
    const {
      message,
      meta: { error, warning, dirty, invalid, submitFailed }
    } = this.props;
    if (invalid && (dirty || submitFailed) && !message) {
      return (
        (error && (
          <Label basic color='red' pointing>
            {error}
          </Label>
        )) ||
        (warning && (
          <Label basic color='orange' pointing>
            {warning}
          </Label>
        ))
      );
    } else {
      return (
        message && (
          <Label basic color='red' pointing>
            {message}
          </Label>
        )
      );
    }
  }

  render() {
    const { fields, subPrimals, subPrimalsExist } = this.props;

    return (
      <div className='subprimal-table'>
        <Table columns={3} fixed size='small'>
          <Table.Header>
            <Table.Row>
              <Table.HeaderCell width={4}>SUBPRIMAL</Table.HeaderCell>
              <Table.HeaderCell width={6}>DESCRIPTION</Table.HeaderCell>
              <Table.HeaderCell width={6}># OF DAYS (AFTER PACKOFF)</Table.HeaderCell>
            </Table.Row>
          </Table.Header>
          <Table.Body>
            {fields.map((subPrimalField, index) => {
              const subPrimalInfo = fields.get(index);
              const subPrimal = _.get(subPrimals, _.toUpper(subPrimalInfo.subPrimalCode), {});
              return (
                <Table.Row key={index}>
                  <Table.Cell className='subPrimal-code'>
                    {subPrimalInfo.default ? (
                      subPrimalInfo.subPrimalCode
                    ) : (
                      <Fragment>
                        <Field
                          component={FormElement}
                          name={`${subPrimalField}.subPrimalCode`}
                          as={Form.Input}
                          onBlur={(event, subPrimalCode, prevValue, fieldName) =>
                            this.handleAddNewSubPrimalOnBlur(event, subPrimalCode, fieldName, index)
                          }
                          onChange={this.handleSubPrimalCodeChange}
                          className='customer-setup-input'
                        />
                        {getErrorMessage(subPrimalsExist, subPrimalField)}
                      </Fragment>
                    )}
                  </Table.Cell>
                  <Table.Cell className='subPrimal-description'>
                    {subPrimal.subPrimalDescription}
                  </Table.Cell>
                  <Table.Cell className='subprimal-date-value'>
                    <Field
                      component={FormElement}
                      name={`${subPrimalField}.dateValue`}
                      as={Form.Input}
                      className='customer-setup-input'
                    />
                  </Table.Cell>
                </Table.Row>
              );
            })}
          </Table.Body>
        </Table>
        {this.getNotification()}
      </div>
    );
  }
}

SubPrimalTableComponent.propTypes = {
  fields: PropTypes.object.isRequired,
  meta: PropTypes.object.isRequired,
  message: PropTypes.string,
  getSubPrimal: PropTypes.func.isRequired,
  setSubPrimalExistTo: PropTypes.func.isRequired,
  subPrimals: PropTypes.object,
  subPrimalsExist: PropTypes.object
};

const mapDispatchToProps = dispatch =>
  bindActionCreators(
    {
      getSubPrimal,
      setSubPrimalExistTo
    },
    dispatch
  );

const SubPrimalTable = connect(
  null,
  mapDispatchToProps
)(SubPrimalTableComponent);

export default SubPrimalTable;
