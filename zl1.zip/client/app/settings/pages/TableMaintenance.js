import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { getTables } from '../actions/settingsActions';
import { replacePath } from '../../shared/actions/actions';
import { renderTableMaintenanceTableBody } from '../utils/renderTable';
import MaintenanceTable, { iconButton } from '../components/MaintenanceTable';
import { Button } from 'semantic-ui-react';

class TableMaintenance extends React.Component {
  constructor(props) {
    super(props);

    this.createTable = this.createTable.bind(this);
  }

  componentDidMount() {
    const { getTables } = this.props;
    getTables();
  }

  createTable() {
    this.props.replacePath('/settings/tables/create');
  }

  editTable(tableId) {
    this.props.replacePath(`/settings/tables/create/${tableId}`);
  }

  getTableColumns() {
    return [
      {
        key: 'tableCode',
        pid: 'table-id',
        width: '1',
        headerText: 'Table',
        textAlign: 'right'
      },
      {
        key: 'tableDescription',
        pid: 'table-description',
        width: '3',
        headerText: 'Description'
      },
      {
        key: 'poundsPerHour',
        pid: 'table-pounds-per-hour',
        width: '1',
        headerText: 'LBS/HR',
        textAlign: 'right'
      },
      {
        key: 'hours',
        pid: 'table-hours-range',
        width: '4',
        headerText: 'Hours',
        textAlign: 'left'
      },
      {
        key: 'stationName',
        pid: 'table-station-name',
        width: '2',
        headerText: 'Station',
        textAlign: 'left'
      },
      {
        key: 'room',
        pid: 'table-room',
        width: '2',
        headerText: 'Room',
        textAlign: 'left'
      },
      {
        key: 'tableId',
        pid: 'table-create-button',
        width: '3',
        headerText: (
          <Button primary size={'small'} onClick={this.createTable}>
            {'New'}
          </Button>
        ),
        textAlign: 'center',
        value: data => (
          <a onClick={this.editTable.bind(this, data.tableId)}>
            <i style={iconButton} className='icon-edit' />
          </a>
        )
      }
    ];
  }

  sortAlphabetically() {
    return this.props.tables ? this.props.tables : null;
  }

  render() {
    return (
      <MaintenanceTable
        items={this.sortAlphabetically()}
        columns={this.getTableColumns()}
        tableBody={renderTableMaintenanceTableBody}
      />
    );
  }
}

TableMaintenance.propTypes = {
  tables: PropTypes.array,
  getTables: PropTypes.func.isRequired,
  replacePath: PropTypes.func.isRequired
};

const mapStateToProps = state => ({
  tables: state.settingsInfo.tables
});

const mapDispatchToProps = dispatch =>
  bindActionCreators(
    {
      getTables,
      replacePath
    },
    dispatch
  );

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(TableMaintenance);
