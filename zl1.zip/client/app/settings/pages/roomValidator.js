import _ from 'lodash';
import { SubmissionError } from 'redux-form';

export const processErrorResponse = errorResponse => {
  let errors = {};
  const errorDetails = _.get(errorResponse, 'error.details', []);
  errors = processFieldErrors(errorDetails, errors);

  throw new SubmissionError({ ...errors, _error: 'Submission Failed!' });
};

const processFieldErrors = (errorDetails, errors) => {
  const fieldErrors = _.filter(errorDetails, errorDetail => 'field' === errorDetail.type);

  _.forEach(fieldErrors, fieldError => {
    const { issue, field } = fieldError;

    switch (issue) {
      case 'REQUIRED':
        errors = { ...errors, [field]: 'Required' };
        break;
      case 'ALPHA_NUMERIC':
        errors = { ...errors, [field]: 'Only alphanumeric characters' };
        break;
      case 'LENGTH':
        if (field === 'code') {
          errors = { ...errors, [field]: 'Maximum 2 characters' };
        }
        break;
      case 'NON_ZERO':
        errors = { ...errors, [field]: 'Must not be zero' };
        break;
      case 'UNIQUE':
        if (field === 'code') {
          errors = { ...errors, [field]: 'Room code must be unique' };
        }
        break;
      case 'NOT_EXIST':
        if (field === 'customerNumber') {
          errors = { ...errors, [field]: 'Invalid Customer Number' };
        }
        break;
      case 'INVALID':
        if (field === 'customerNumber') {
          errors = { ...errors, [field]: 'Must be internal customer' };
        }
        break;
      default:
        errors = { ...errors, [field]: issue };
        break;
    }
  });

  return errors;
};
