import React from 'react';
import { Confirm } from 'semantic-ui-react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { submit } from 'redux-form';
import { hideConfirmation } from '../actions/tarePackagesActions';

export const TarePackageConfirmationComponent = ({
  confirmationShowing,
  dispatch,
  formToSubmitRemotely
}) => (
  <Confirm
    open={confirmationShowing}
    content={
      'If you save this as the default, ' +
      'any previously defined default package will no longer be the default, ' +
      'and all unassigned products will use this box and film tare instead.'
    }
    header={'Continue with setting as default?'}
    confirmButton='Yes'
    onConfirm={() => {
      dispatch(hideConfirmation());
      dispatch(submit(formToSubmitRemotely));
    }}
    cancelButton='No'
    onCancel={() => {
      dispatch(hideConfirmation());
    }}
  />
);

TarePackageConfirmationComponent.propTypes = {
  confirmationShowing: PropTypes.bool.isRequired,
  dispatch: PropTypes.func.isRequired,
  formToSubmitRemotely: PropTypes.string.isRequired
};

const mapStateToProps = state => {
  return {
    confirmationShowing: state.tarePackages.confirmationShowing
  };
};

const TarePackageConfirmation = connect(mapStateToProps)(TarePackageConfirmationComponent);

export default TarePackageConfirmation;
