import React from 'react';

import { createReduxStore } from '../../../store';
import { Provider } from 'react-redux';
import { mount, shallow } from 'enzyme';
import TarePackageConfirmation, {
  TarePackageConfirmationComponent
} from '../TarePackageConfirmation';
import { hideConfirmation } from '../../actions/tarePackagesActions';
import { Confirm } from 'semantic-ui-react';
import { submit } from 'redux-form';

jest.mock('../../actions/tarePackagesActions', () => ({
  hideConfirmation: () => ({
    type: 'MOCK_HIDE_MODEL_CONFIRMATION'
  })
}));

test('should call createORUpdateYieldModel action on okay from confirm component', () => {
  const store = createReduxStore({
    yieldModelInfo: {
      confirmationShowing: true
    }
  });
  const dispatchSpy = jest.spyOn(store, 'dispatch');

  const form = mount(
    <Provider store={store}>
      <TarePackageConfirmation formToSubmitRemotely='mockForm' />
    </Provider>
  );

  form
    .find(Confirm)
    .props()
    .onConfirm();

  jestExpect(dispatchSpy).toHaveBeenCalledWith(hideConfirmation());
  jestExpect(dispatchSpy).toHaveBeenCalledWith(submit('mockForm'));
});

test('should not show confirmation when confirmationShowing is false', () => {
  const wrapper = shallow(
    <TarePackageConfirmationComponent
      formToSubmitRemotely='mockForm'
      dispatch={jest.fn()}
      confirmationShowing={false}
    />
  );

  jestExpect(wrapper.find(Confirm).props().open).toEqual(false);
});

test('should show confirmation when confirmationShowing is true', () => {
  const wrapper = shallow(
    <TarePackageConfirmationComponent
      formToSubmitRemotely='mockForm'
      dispatch={jest.fn()}
      confirmationShowing={true}
    />
  );

  wrapper.setProps({ confirmationShowing: true });

  jestExpect(wrapper.find(Confirm).props().open).toEqual(true);
});
