import { getProductsByDescriptions, clearProducts } from '../productSearchActions';
import {
  UPDATE_PRODUCTS,
  CLEAR_PRODUCTS,
  PRODUCT_RECEIVED,
  PRODUCT_REQUESTED
} from '../productSearchActionTypes';
import productResources from '../../../shared/api/productResources';
import productFactory from '../../../../test-factories/productFactory';

jest.mock('../../../shared/api/productResources');

describe('productSearchAction', () => {
  let dispatch;
  const products = [productFactory.build(), productFactory.build()];

  beforeEach(() => {
    dispatch = jest.fn();
    productResources.getProductsByDescriptions.mockImplementation((arg, fn) => fn(products));
  });

  afterEach(() => {
    productResources.getProductsByDescriptions.mockReset();
  });

  test('should dispatch action on successful callback for getAllPiecesPackages', () => {
    getProductsByDescriptions()(dispatch);

    jestExpect(dispatch).toHaveBeenNthCalledWith(3, {
      type: UPDATE_PRODUCTS,
      payload: products
    });
    jestExpect(dispatch).toHaveBeenNthCalledWith(2, {
      type: PRODUCT_REQUESTED
    });
    jestExpect(dispatch).toHaveBeenNthCalledWith(1, {
      type: PRODUCT_RECEIVED
    });
  });

  test('should dispatch CLEAR_PRODUCTS action  for clearProducts', () => {
    clearProducts()(dispatch);

    jestExpect(dispatch).toHaveBeenNthCalledWith(1, {
      type: CLEAR_PRODUCTS
    });
  });
});
