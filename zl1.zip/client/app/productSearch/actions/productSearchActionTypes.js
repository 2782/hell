export const UPDATE_PRODUCTS = 'product-search/updateProducts';
export const CLEAR_PRODUCTS = 'product-search/clearProducts';
export const PRODUCT_RECEIVED = 'product-search/productReceived';
export const PRODUCT_REQUESTED = 'product-search/productRequested';
