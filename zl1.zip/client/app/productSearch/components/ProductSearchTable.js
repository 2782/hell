import { Table } from 'semantic-ui-react';
import PropTypes from 'prop-types';
import React from 'react';
import _ from 'lodash';
import EmptyTableMessage from '../../shared/components/EmptyTableMessage';

export const ProductSearchTable = ({ products }) => {
  return (
    <Table size='small' columns={10} fixed>
      <ProductSearchTableHeader />
      <ProductSearchTableBody products={products} />
    </Table>
  );
};

ProductSearchTable.propTypes = {
  products: PropTypes.array
};

export const RenderEmptyTable = () => {
  let emptyTableContent = (
    <EmptyTableMessage className={'prime-list-empty-message'} message={'No results found'} />
  );
  return (
    <div>
      <Table size='small' columns={10} fixed>
        <ProductSearchTableHeader />
      </Table>
      {emptyTableContent}
    </div>
  );
};

const ProductSearchTableHeader = () => {
  return (
    <Table.Header>
      <Table.Row>
        <Table.HeaderCell colSpan={3} width={3}>
          PRODUCT #
        </Table.HeaderCell>
        <Table.HeaderCell colSpan={6} width={6}>
          DESCRIPTION
        </Table.HeaderCell>
        <Table.HeaderCell colSpan={2} width={2} textAlign='right'>
          SIZE
        </Table.HeaderCell>
      </Table.Row>
    </Table.Header>
  );
};

const ProductSearchTableBody = ({ products }) => {
  return (
    <Table.Body key={'product-search-table-content'}>
      {_.map(products, (product, itemIndex) => {
        const portionSize = _.get(product, 'productPortionSize.portionSize');
        return (
          <Table.Row
            pid={`product-search__table-row-${itemIndex}`}
            key={`product-search__table-row-${itemIndex}`}
          >
            <Table.Cell colSpan={3} width={3}>
              {product.code}
            </Table.Cell>
            <Table.Cell colSpan={6} width={6}>
              {product.description}
            </Table.Cell>
            <Table.Cell colSpan={2} width={2} textAlign='right'>
              {portionSize}
            </Table.Cell>
          </Table.Row>
        );
      })}
    </Table.Body>
  );
};

ProductSearchTableBody.propTypes = {
  products: PropTypes.array
};
