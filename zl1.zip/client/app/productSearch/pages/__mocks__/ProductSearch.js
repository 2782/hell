import React from 'react';

class ProductSearch extends React.Component {
  render() {
    return <div>Fake product search page</div>;
  }
}

export default ProductSearch;
