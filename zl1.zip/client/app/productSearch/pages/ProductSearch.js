import _ from 'lodash';
import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { Field, reduxForm } from 'redux-form';
import { Divider, Form, Loader } from 'semantic-ui-react';
import FormElement from '../../shared/FormElement';
import { bindActionCreators } from 'redux';
import { clearProducts, getProductsByDescriptions } from '../actions/productSearchActions';
import { setHeaderAndFooter } from '../../shared/actions/actions';
import { PRODUCT_SEARCH } from '../../shared/components/pageTitles';
import { F4_F2 } from '../../shared/components/pageFooters';
import { RenderEmptyTable, ProductSearchTable } from '../components/ProductSearchTable';

export class ProductSearchPage extends React.Component {
  constructor(props) {
    super(props);
  }

  componentDidMount() {
    this.props.setHeaderAndFooter({
      header: PRODUCT_SEARCH,
      footer: F4_F2
    });
  }

  componentWillUnmount() {
    this.props.clearProducts();
  }

  submit(values) {
    const { descriptions } = values;
    if (descriptions) {
      this.props.getProductsByDescriptions(descriptions);
    }
  }

  render() {
    const { handleSubmit, products, loading } = this.props;
    let loadingContent = null;
    if (loading) {
      loadingContent = <Loader size='large' active inline='centered' />;
    }
    return (
      <div className='page-content product-search-page'>
        <Form
          pid='product-description-input-form'
          size={'large'}
          onSubmit={handleSubmit(this.submit.bind(this))}
        >
          <Divider hidden className='divider-medium' />
          <Field
            as={Form.Input}
            component={FormElement}
            name='descriptions'
            className='product-description'
            pid='product-description-input'
            placeholder='keyword 1, keyword 2, keyword 3 | Enter to search'
            width={12}
          />
        </Form>

        <Divider hidden />
        {_.isNull(products) ? (
          <ProductSearchTable products={products} />
        ) : _.isEmpty(products) ? (
          <RenderEmptyTable />
        ) : (
          <ProductSearchTable products={products} />
        )}
        {loadingContent}
      </div>
    );
  }
}

ProductSearchPage.propTypes = {
  getProductsByDescriptions: PropTypes.func,
  clearProducts: PropTypes.func,
  setHeaderAndFooter: PropTypes.func,
  handleSubmit: PropTypes.func,
  products: PropTypes.array,
  loading: PropTypes.bool
};

const mapStateToProps = state => ({
  products: state.productsInfo.products,
  loading: state.productsInfo.loading
});

const mapDispatchToProps = dispatch =>
  bindActionCreators(
    {
      getProductsByDescriptions,
      setHeaderAndFooter,
      clearProducts
    },
    dispatch
  );

const ProductSearch = connect(
  mapStateToProps,
  mapDispatchToProps
)(
  reduxForm({
    form: 'productSearch'
  })(ProductSearchPage)
);

export default ProductSearch;
