import productSearchReducer from '../productSearchReducer';
import { CLEAR_PRODUCTS, UPDATE_PRODUCTS } from '../../actions/productSearchActionTypes';
import productFactory from '../../../../test-factories/productFactory';

const products = [productFactory.build(), productFactory.build()];

describe('productSearchReducer', () => {
  let initState;

  beforeEach(() => {
    initState = {
      products: null,
      loading: false
    };
  });

  test('should return init state when action not defined', () => {
    jestExpect(
      productSearchReducer(initState, { type: 'ACTION-NOT-DEFINED', payload: {} })
    ).toEqual(initState);
  });

  test('should return new state when dispatch UPDATE_PRODUCTS action', () => {
    const expectedState = {
      ...initState,
      products
    };

    jestExpect(
      productSearchReducer(initState, {
        type: UPDATE_PRODUCTS,
        payload: products
      })
    ).toEqual(expectedState);
  });

  test('should return new state when dispatch CLEAR_PRODUCTS action', () => {
    const expectedState = {
      ...initState,
      products: null
    };

    jestExpect(
      productSearchReducer(initState, {
        type: CLEAR_PRODUCTS
      })
    ).toEqual(expectedState);
  });
});
