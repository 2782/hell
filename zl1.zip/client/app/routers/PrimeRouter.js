import React from 'react';
import { Route, Switch } from 'react-router-dom';
import { ConnectedRouter } from 'react-router-redux';
import { history } from '../store';

import MainNavigation from '../landingPage/pages/MainNavigation';
import withAuthorization from '../shared/util/Authorization';

import CutOrdersSelection from '../cut/pages/CutOrdersSelection';
import PackOrdersSelection from '../pack/pages/PackOrdersSelection';
import CutOrdersConfirmation from '../cut/pages/CutOrdersConfirmation';
import CutOrdersSourceMeat from '../cut/pages/CutOrdersSourceMeat';
import CutOrdersSourceMeatRequest from '../cut/pages/CutOrdersSourceMeatRequest';
import OrderToPack from '../pack/pages/OrderToPack';
import PackOffStock from '../pack/pages/PackOffStock';
import PackWIP from '../pack/pages/PackWIP';
import CutTableSummary from '../cut/pages/CutTableSummary';
import CutStationSummary from '../cut/pages/CutStationSummary';
import MeatRequest from '../requestMeat/pages/MeatRequest';
import OrderOverview from '../overview/pages/OrderOverview';
import Administration from '../settings/pages/Administration';
import ViewGrindOrdersSummary from '../grind/pages/ViewGrindOrdersSummary';
import CreateBatch from '../batch/pages/CreateBatch';
import SearchBatch from '../batch/pages/SearchBatch';
import SelectPortionRooms from '../landingPage/pages/SelectPortionRooms';
import ScheduleFutureCutOrders from '../overview/pages/ScheduleFutureCutOrders';
import GrindNavPage from '../grind/pages/GrindNavPage';
import Reprint from '../reprint/pages/Reprint';
import BatchOverview from '../batch/pages/BatchOverview';
import ProductBase from '../product/pages/ProductBase';
import Reports from '../reports/pages/Reports';
import YieldModel from '../yieldModel/pages/YieldModel';
import YieldTest from '../yieldTest/pages/YieldTest';
import config from '../../../config/env';
import UploadCostContainer from '../uploadFile/UploadCostContainer';

class PrimeRouter extends React.Component {
  render() {
    return (
      <ConnectedRouter history={history}>
        <Switch>
          {config.importCostsToggle ? (
            <Route
              path='/import-costs'
              component={withAuthorization(UploadCostContainer, ['ROLE_ADMIN'])}
            />
          ) : null}
          <Route
            path='/main-navigation'
            component={withAuthorization(MainNavigation, [
              'ROLE_ADMIN',
              'ROLE_PORTION_ROOM_MEMBER'
            ])}
          />
          <Route
            path='/cut/stations/:stationId(\d+)/tables/:tableId(\d+)/source-meat/request'
            component={withAuthorization(CutOrdersSourceMeatRequest, [
              'ROLE_ADMIN',
              'ROLE_PORTION_ROOM_MEMBER'
            ])}
          />
          <Route
            path='/cut/stations/:stationId(\d+)/tables/:tableId(\d+)/source-meat'
            component={withAuthorization(CutOrdersSourceMeat, [
              'ROLE_ADMIN',
              'ROLE_PORTION_ROOM_MEMBER'
            ])}
          />
          <Route
            path='/cut/stations/:stationId(\d+)/tables/:tableId(\d+)/select'
            component={withAuthorization(CutOrdersSelection, [
              'ROLE_ADMIN',
              'ROLE_PORTION_ROOM_MEMBER'
            ])}
          />
          <Route
            path='/cut/stations/:stationId(\d+)/tables/:tableId(\d+)/confirm'
            component={withAuthorization(CutOrdersConfirmation, [
              'ROLE_ADMIN',
              'ROLE_PORTION_ROOM_MEMBER'
            ])}
          />
          <Route
            path='/cut/stations/:stationId(\d+)/tables'
            component={withAuthorization(CutTableSummary, [
              'ROLE_ADMIN',
              'ROLE_PORTION_ROOM_MEMBER'
            ])}
          />
          <Route
            path='/cut/stations'
            component={withAuthorization(CutStationSummary, [
              'ROLE_ADMIN',
              'ROLE_PORTION_ROOM_MEMBER'
            ])}
          />
          <Route
            path='/meat-request'
            component={withAuthorization(MeatRequest, ['ROLE_ADMIN', 'ROLE_PORTION_ROOM_MEMBER'])}
          />
          <Route
            path='/pack/orders/:orderId(\d+)'
            component={withAuthorization(OrderToPack, ['ROLE_ADMIN', 'ROLE_PORTION_ROOM_MEMBER'])}
          />
          <Route
            path='/pack/orders'
            component={withAuthorization(PackOrdersSelection, [
              'ROLE_ADMIN',
              'ROLE_PORTION_ROOM_MEMBER'
            ])}
          />
          <Route path='/settings' component={withAuthorization(Administration, ['ROLE_ADMIN'])} />
          <Route path='/yield-model' component={withAuthorization(YieldModel, ['ROLE_ADMIN'])} />
          <Route
            path='/yield-test'
            component={withAuthorization(YieldTest, ['ROLE_ADMIN', 'ROLE_PORTION_ROOM_MEMBER'])}
          />
          <Route
            path='/pack/pack-off-stock'
            component={withAuthorization(PackOffStock, ['ROLE_ADMIN', 'ROLE_PORTION_ROOM_MEMBER'])}
          />
          <Route
            path='/pack/pack-wip'
            component={withAuthorization(PackWIP, ['ROLE_ADMIN', 'ROLE_PORTION_ROOM_MEMBER'])}
          />
          <Route
            path='/cut-orders'
            component={withAuthorization(OrderOverview, ['ROLE_ADMIN', 'ROLE_PORTION_ROOM_MEMBER'])}
          />
          <Route
            path='/future-orders/cutting/schedule'
            component={withAuthorization(ScheduleFutureCutOrders, [
              'ROLE_ADMIN',
              'ROLE_PORTION_ROOM_MEMBER'
            ])}
          />
          <Route
            path='/grinding-orders'
            component={withAuthorization(ViewGrindOrdersSummary, [
              'ROLE_ADMIN',
              'ROLE_PORTION_ROOM_MEMBER'
            ])}
          />
          <Route
            path='/batch/create'
            component={withAuthorization(CreateBatch, ['ROLE_ADMIN', 'ROLE_PORTION_ROOM_MEMBER'])}
          />
          <Route
            path='/batch/:batchNumber(\d+)'
            component={withAuthorization(BatchOverview, ['ROLE_ADMIN', 'ROLE_PORTION_ROOM_MEMBER'])}
          />
          <Route
            path='/batch/search'
            component={withAuthorization(SearchBatch, ['ROLE_ADMIN', 'ROLE_PORTION_ROOM_MEMBER'])}
          />
          <Route
            path='/product'
            component={withAuthorization(ProductBase, ['ROLE_ADMIN', 'ROLE_PORTION_ROOM_MEMBER'])}
          />
          <Route path='/grinding' component={withAuthorization(GrindNavPage, ['ROLE_ADMIN'])} />
          <Route path='/reports' component={withAuthorization(Reports, ['ROLE_ADMIN'])} />
          <Route
            path='/reprint'
            component={withAuthorization(Reprint, ['ROLE_ADMIN', 'ROLE_PORTION_ROOM_MEMBER'])}
          />
          <Route path='/' component={SelectPortionRooms} />
        </Switch>
      </ConnectedRouter>
    );
  }
}

export default PrimeRouter;
