import React from 'react';
import { Route, Switch } from 'react-router-dom';
import { ConnectedRouter } from 'react-router-redux';
import { history } from '../store';

import withCostingAuthorization from '../shared/util/CostingAuthorization';
import CostingMainNavigation from '../landingPage/pages/CostingMainNavigation';

import ProductBase from '../product/pages/ProductBase';
import Reports from '../reports/pages/Reports';
import YieldModel from '../yieldModel/pages/YieldModel';
import YieldTest from '../yieldTest/pages/YieldTest';
import UploadCostContainer from '../uploadFile/UploadCostContainer';

class CostingPrimeRouter extends React.Component {
  render() {
    return (
      <ConnectedRouter history={history}>
        <Switch>
          <Route path='/yield-model' component={withCostingAuthorization(YieldModel)} />
          <Route path='/yield-test' component={withCostingAuthorization(YieldTest)} />
          <Route path='/reports' component={withCostingAuthorization(Reports)} />
          <Route path='/product' component={withCostingAuthorization(ProductBase)} />
          <Route path='/import-costs' component={withCostingAuthorization(UploadCostContainer)} />
          <Route path='/' component={CostingMainNavigation} />
        </Switch>
      </ConnectedRouter>
    );
  }
}

export default CostingPrimeRouter;
