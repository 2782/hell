import { UPDATE_BATCH } from '../batchActionTypes';
import batchResources from '../../../shared/api/batchResources';
import BatchFactory from '../../../../test-factories/batch';
import {
  createOrUpdateBatch,
  finishGrindBatch,
  finishMarinationBatch,
  searchBatches,
  resetBatches
} from '../batchActions';
import { SHOW_ERROR } from '../../../settings/actions/settingsActionTypes';
import { returnToPreviousPage } from '../../../shared/actions/actions';
import { searchBatchesSuccess, clearSearchBatches } from '../batchActionCreators';

jest.mock('../../../shared/actions/actions', () => ({
  returnToPreviousPage: jest.fn()
}));
jest.mock('../../../shared/api/batchResources');

describe('Batch Actions', () => {
  let dispatch, batch;

  beforeEach(() => {
    batch = BatchFactory.build();
    dispatch = jest.fn();
  });

  afterEach(() => {
    batchResources.create.mockReset();
    batchResources.update.mockReset();
    batchResources.finishMarination.mockReset();
    batchResources.finishGrind.mockReset();
    returnToPreviousPage.mockReset();
  });

  describe('crateOrUpdate', () => {
    test('should dispatch createOrUpdate action and call create method', () => {
      batchResources.create.mockImplementation((data, success) => success({ data: batch }));

      createOrUpdateBatch(batch)(dispatch);

      jestExpect(batchResources.create).toHaveBeenCalledTimes(1);
      jestExpect(dispatch).toHaveBeenNthCalledWith(1, {
        type: UPDATE_BATCH,
        payload: batch
      });
      jestExpect(returnToPreviousPage).toBeCalledTimes(1);
    });

    test('should dispatch createOrUpdate action and call create method', () => {
      batchResources.create.mockImplementation((data, success, error) =>
        error({ message: 'error' })
      );

      createOrUpdateBatch(batch)(dispatch);

      jestExpect(batchResources.create).toHaveBeenCalledTimes(1);
      jestExpect(dispatch).toHaveBeenCalledWith({
        type: SHOW_ERROR,
        payload: { message: 'error' }
      });
    });

    test('should dispatch createOrUpdate action and call update method', () => {
      batch = BatchFactory.build({ id: 123 });
      batchResources.update.mockImplementation((data, success) => success({ data: batch }));

      createOrUpdateBatch(batch)(dispatch);

      jestExpect(batchResources.update).toHaveBeenCalledTimes(1);
      jestExpect(dispatch).toBeCalledWith({
        type: UPDATE_BATCH,
        payload: batch
      });
      jestExpect(returnToPreviousPage).toBeCalledTimes(1);
    });

    test('should dispatch createOrUpdate action and call update method', () => {
      batch = BatchFactory.build({ id: 123 });
      batchResources.update.mockImplementation((data, success, error) =>
        error({ message: 'error' })
      );

      createOrUpdateBatch(batch)(dispatch);

      jestExpect(batchResources.update).toHaveBeenCalledTimes(1);
      jestExpect(dispatch).toBeCalledWith({
        type: SHOW_ERROR,
        payload: { message: 'error' }
      });
    });
  });

  describe('finish batch', () => {
    test('should dispatch createOrUpdate action and call finish marination method, successfully', () => {
      batch = BatchFactory.build({ id: 123, finished: true });
      batchResources.finishMarination.mockImplementation((data, success) =>
        success({ data: batch })
      );

      finishMarinationBatch(batch)(dispatch);

      jestExpect(batchResources.finishMarination).toHaveBeenCalledTimes(1);
      jestExpect(dispatch).toHaveBeenCalledWith({
        type: UPDATE_BATCH,
        payload: batch
      });
      jestExpect(returnToPreviousPage).toHaveBeenCalled();
    });

    test('should dispatch createOrUpdate action and call finish marination method, with error', () => {
      batch = BatchFactory.build({ id: 123, finished: true });
      batchResources.finishMarination.mockImplementation((data, success, error) =>
        error({ message: 'error' })
      );

      finishMarinationBatch(batch)(dispatch);

      jestExpect(batchResources.finishMarination).toHaveBeenCalledTimes(1);
      jestExpect(dispatch).toHaveBeenCalledWith({
        type: SHOW_ERROR,
        payload: { message: 'error' }
      });
    });

    test('should dispatch createOrUpdate action and call finish marination method, successfully', () => {
      batch = BatchFactory.build({ id: 123, finished: true });
      batchResources.finishGrind.mockImplementation((data, success) => success({ data: batch }));

      finishGrindBatch(batch)(dispatch);

      jestExpect(batchResources.finishGrind).toHaveBeenCalledTimes(1);
      jestExpect(dispatch).toHaveBeenCalledWith({
        type: UPDATE_BATCH,
        payload: batch
      });
      jestExpect(returnToPreviousPage).toHaveBeenCalled();
    });

    test('should dispatch createOrUpdate action and call finish marination method, with error', () => {
      batch = BatchFactory.build({ id: 123, finished: true });
      batchResources.finishGrind.mockImplementation((data, success, error) =>
        error({ message: 'error' })
      );

      finishGrindBatch(batch)(dispatch);

      jestExpect(batchResources.finishGrind).toHaveBeenCalledTimes(1);
      jestExpect(dispatch).toHaveBeenCalledWith({
        type: SHOW_ERROR,
        payload: { message: 'error' }
      });
    });
  });

  describe('search batch', () => {
    test('should dispatch searchBatchesSucceeded when resource resolves', async () => {
      const values = { productionDateStart: '01-01-2018', productionDateEnd: '01-01-2018' };
      const expectedData = { data: [batch] };

      batchResources.search.mockResolvedValue(expectedData);

      await searchBatches(values)(dispatch);

      jestExpect(dispatch).toBeCalledWith(searchBatchesSuccess(expectedData));
    });
  });

  describe('reset batch', () => {
    test('should dispatch clearSearchBatches when reset batch', () => {
      resetBatches()(dispatch);

      jestExpect(dispatch).toBeCalledWith(clearSearchBatches());
    });
  });
});
