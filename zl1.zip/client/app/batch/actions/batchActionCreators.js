import { SEARCH_BATCHES_CLEARED, SEARCH_BATCHES_SUCCEEDED } from './batchActionTypes';

export const searchBatchesSuccess = response => {
  return {
    type: SEARCH_BATCHES_SUCCEEDED,
    payload: response.data
  };
};

export const clearSearchBatches = () => {
  return { type: SEARCH_BATCHES_CLEARED };
};
