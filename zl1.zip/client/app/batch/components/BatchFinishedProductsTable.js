import React from 'react';
import PropTypes from 'prop-types';
import _ from 'lodash';
import { Field } from 'redux-form';
import { Label, Table } from 'semantic-ui-react';
import ProductDuplicate from '../../shared/components/product/ProductDuplicate';
import { normalizeProductCode } from '../../shared/components/product/normalizer';

class BatchFinishedProductsTable extends React.Component {
  constructor(props) {
    super(props);

    this.onChange = this.onChange.bind(this);
    this.onBlur = this.onBlur.bind(this);
  }

  onChange(event, nextValue, prevValue, fieldName) {
    const { fields } = this.props;

    let index = 0;
    if (fieldName && fieldName.match('finishedProducts.*\\.finishedProductCode$')) {
      const regex = /finishedProducts\[([\w-]*)].finishedProductCode/;
      index = parseInt(fieldName.match(regex)[1]);
    }

    if (index === fields.length - 1 && _.isEmpty(prevValue) && !_.isEmpty(nextValue)) {
      fields.push('');
    }
  }

  onBlur(event, productCode, index) {
    const { fields } = this.props;

    if (_.isEmpty(productCode)) {
      if (fields.length - 1 !== index) {
        event.preventDefault();
        fields.remove(index);
      }
    }
  }

  render() {
    const {
      fields,
      products,
      meta: { error, warning, dirty, invalid, submitFailed }
    } = this.props;

    return (
      <div>
        <Table columns={3} fixed size='small'>
          <Table.Header>
            <Table.Row>
              <Table.HeaderCell width={11}>Product</Table.HeaderCell>
            </Table.Row>
          </Table.Header>
          <Table.Body>
            {fields.map((fieldString, index) => {
              const key = `existing-product-${index}`;
              const product = products[fields.get(index).finishedProductCode] || {};

              return (
                <Table.Row key={key}>
                  <Table.Cell width={11}>
                    <Field
                      component={ProductDuplicate}
                      name={`${fieldString}.finishedProductCode`}
                      normalize={normalizeProductCode}
                      onChange={this.onChange}
                      onBlur={(event, productCode) => this.onBlur(event, productCode, index)}
                      hideDescriptionLabel={true}
                      product={product}
                    />
                  </Table.Cell>
                </Table.Row>
              );
            })}
          </Table.Body>
        </Table>
        {(invalid &&
          (dirty || submitFailed) &&
          (error && (
            <Label basic color='red' pointing>
              {error}
            </Label>
          ))) ||
          (warning && (
            <Label basic color='orange' pointing>
              {warning}
            </Label>
          ))}
      </div>
    );
  }
}

BatchFinishedProductsTable.propTypes = {
  fields: PropTypes.object.isRequired,
  meta: PropTypes.object.isRequired,
  products: PropTypes.object.isRequired,
  message: PropTypes.string,
  getProduct: PropTypes.func.isRequired,
  batchNumber: PropTypes.oneOfType([PropTypes.string, PropTypes.number])
};

export default BatchFinishedProductsTable;
