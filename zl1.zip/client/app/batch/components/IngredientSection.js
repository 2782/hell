import React from 'react';
import PropTypes from 'prop-types';
import { Field, FieldArray } from 'redux-form';
import { Button, Divider, Form, Grid, Label } from 'semantic-ui-react';
import FormElement from '../../shared/FormElement';
import {
  normalizeProductCode,
  normalizeToTwoDecimalPlaces
} from '../../shared/components/product/normalizer';
import Product from '../../shared/components/product/product';
import _ from 'lodash';
import CheckBox from '../../shared/components/CheckBox';

export default function IngredientSection({ totalIngredientWeight, batchNumber }) {
  return (
    <div>
      <div>Ingredients</div>
      <Divider hidden />
      <FieldArray
        name={'ingredients'}
        component={IngredientList}
        props={{ totalIngredientWeight, batchNumber }}
      />
    </div>
  );
}

IngredientSection.propTypes = {
  totalIngredientWeight: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  batchNumber: PropTypes.oneOfType([PropTypes.string, PropTypes.number])
};

export function IngredientList({
  fields,
  totalIngredientWeight,
  batchNumber,
  message,
  meta: { error, warning, dirty, invalid, submitFailed }
}) {
  return (
    <div className={'create-batch-ingredient-list create-batch-section'}>
      {fields.map((ingredient, index) => {
        const ingredientData = fields.get(index);
        const productNamespace = `batchForm-ingredient-${index}`;
        const ingredientId = _.get(ingredientData, 'id', '');
        const key = ingredientId ? `${batchNumber}-existing-product-${index}` : ingredient;

        return (
          <div key={key} className={'create-batch-ingredient'}>
            <Grid>
              <Grid.Row>
                <Grid.Column>
                  <Field
                    component={Product}
                    name={`${ingredient}.ingredientProductCode`}
                    namespace={productNamespace}
                    label='Ingredient #'
                    normalize={normalizeProductCode}
                  />
                </Grid.Column>
              </Grid.Row>

              <Grid.Row>
                <Grid.Column width={3}>
                  <Field
                    component={FormElement}
                    name={`${ingredient}.vendor`}
                    as={Form.Input}
                    type='text'
                    label='Vendor'
                  />
                </Grid.Column>
                <Grid.Column width={3}>
                  <Field
                    component={FormElement}
                    name={`${ingredient}.poNumber`}
                    as={Form.Input}
                    type='text'
                    label='PO #'
                  />
                </Grid.Column>
                <Grid.Column width={3}>
                  <Field
                    component={FormElement}
                    name={`${ingredient}.actualLbs`}
                    as={Form.Input}
                    normalize={normalizeToTwoDecimalPlaces}
                    type='text'
                    label='Actual Lbs'
                  />
                </Grid.Column>
                <Grid.Column width={3}>
                  <Field component={CheckBox} label='Allergens' name={`${ingredient}.allergens`} />
                </Grid.Column>
              </Grid.Row>
            </Grid>

            <Divider hidden />
          </div>
        );
      })}

      <Divider hidden />

      <Button type='button' secondary onClick={() => fields.push({})}>
        Add Ingredient
      </Button>

      <Divider hidden />

      <div>{`Total ingredient weight: ${totalIngredientWeight} lbs`} </div>

      <Divider hidden />

      {invalid && (dirty || submitFailed) && !message
        ? (error && (
            <Label basic color='red' pointing>
              {error}
            </Label>
          )) ||
          (warning && (
            <Label basic color='orange' pointing>
              {warning}
            </Label>
          ))
        : message && (
            <Label basic color='red' pointing>
              {message}
            </Label>
          )}
    </div>
  );
}

IngredientList.propTypes = {
  fields: PropTypes.oneOfType([PropTypes.object, PropTypes.array]),
  totalIngredientWeight: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  message: PropTypes.string,
  meta: PropTypes.object,
  batchNumber: PropTypes.oneOfType([PropTypes.string, PropTypes.number])
};
