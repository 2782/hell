import _ from 'lodash';
import { SubmissionError } from 'redux-form';
import {
  alphanumeric,
  isAlreadyExisted,
  isStopTimeAfterStartTime,
  positiveNumber,
  productExists,
  required,
  validate,
  validateTime,
  wholeNumber
} from '../../shared/formValidations';
import { getDuplicatedSubset } from '../../shared/util/dataUtil';

export const validateMarinationSubmission = (values, props, toFinish) => {
  let errors = validateSubmission(values, props, toFinish);

  errors = validateIngredients(values.ingredients, errors, toFinish);

  errors = validateFinishedProducts(values.finishedProducts, errors, toFinish);

  if (!_.isEmpty(errors)) {
    throw new SubmissionError(Object.assign({}, errors, { _error: 'Submission Failed!' }));
  }
};

export const validateGrindSubmission = (values, props, toFinish) => {
  let errors = validateSubmission(values, props, toFinish);

  if (!_.isEmpty(errors)) {
    throw new SubmissionError(Object.assign({}, errors, { _error: 'Submission Failed!' }));
  }
};

export const validateSubmission = (values, props, toFinish) => {
  const { tumbler, tumblerStartTime, tumblerStopTime } = values;
  const { sourceMeatProductExist } = props;
  let errors = {};

  errors = validate(errors, tumbler, 'tumbler', [required, wholeNumber]);

  errors = validateFinishBatch(values, errors, toFinish);

  if (_.isEmpty(errors)) {
    errors = validate(errors, tumblerStopTime, 'tumblerStopTime', [
      isStopTimeAfterStartTime(tumblerStartTime)
    ]);
  }

  if (!_.has(errors, 'sourceMeats')) {
    errors = validateSourceMeats(values.sourceMeats, sourceMeatProductExist, errors);
  }

  return errors;
};

export const validateFinishBatch = (values, errors, toFinish) => {
  if (!toFinish) {
    return errors;
  }

  const {
    tumblerStartTime,
    tumblerStopTime,
    startBatchTemp,
    finishedBatchTemp,
    sourceMeats
  } = values;

  errors = validate(errors, tumblerStartTime, 'tumblerStartTime', [required, validateTime]);
  errors = validate(errors, tumblerStopTime, 'tumblerStopTime', [required, validateTime]);
  errors = validate(errors, startBatchTemp, 'startBatchTemp', [required]);
  errors = validate(errors, finishedBatchTemp, 'finishedBatchTemp', [required]);

  if (!sourceMeats || _.isEmpty(sourceMeats)) {
    errors.sourceMeats = {
      _error: 'One or more fields are missing, please check and finish again'
    };
  } else {
    const sourceMeatArrayErrors = [];

    sourceMeats.forEach((item, itemIndex) => {
      let sourceMeatErrors = {};

      sourceMeatErrors = validate(sourceMeatErrors, item.poNumber, 'poNumber', [required]);
      sourceMeatErrors = validate(sourceMeatErrors, item.lotNumber, 'lotNumber', [required]);
      sourceMeatErrors = validate(sourceMeatErrors, item.meatTemp, 'meatTemp', [required]);
      sourceMeatErrors = validate(sourceMeatErrors, item.actualLbs, 'actualLbs', [required]);
      sourceMeatErrors = validate(sourceMeatErrors, item.vendor, 'vendor', [required]);
      sourceMeatErrors = validate(
        sourceMeatErrors,
        item.establishmentNumber,
        'establishmentNumber',
        [required]
      );
      sourceMeatErrors = validate(sourceMeatErrors, item.harvestDate, 'harvestDate', [required]);
      sourceMeatErrors = validate(sourceMeatErrors, item.sourceProductCode, 'sourceProductCode', [
        required
      ]);

      if (!_.isEmpty(sourceMeatErrors)) {
        sourceMeatArrayErrors[itemIndex] = sourceMeatErrors;
      }
    });

    if (!_.isEmpty(sourceMeatArrayErrors)) {
      errors.sourceMeats = sourceMeatArrayErrors;
    }
  }

  return errors;
};

export const validateFinishedProducts = (values, errors, toFinish) => {
  if (toFinish && (_.isEmpty(values) || !_.some(values, value => !_.isEmpty(value)))) {
    return {
      ...errors,
      finishedProducts: { _error: 'One or more fields are missing, please check and finish again' }
    };
  }

  return { ...errors, ...validateFieldArray({ finishedProducts: values }) };
};

export const validateFieldArray = values => {
  let errors = {};
  const { tumblerStartTime, tumblerStopTime } = values;
  const finishedProducts = _.filter(
    values.finishedProducts,
    finishedProduct => finishedProduct && !_.isEmpty(finishedProduct)
  );

  if (tumblerStartTime) {
    errors = validate(errors, tumblerStartTime, 'tumblerStartTime', [validateTime]);
  }

  if (tumblerStopTime) {
    errors = validate(errors, tumblerStopTime, 'tumblerStopTime', [validateTime]);
  }

  if (tumblerStartTime && tumblerStopTime) {
    errors = validate(errors, tumblerStopTime, 'tumblerStopTime', [
      isStopTimeAfterStartTime(tumblerStartTime)
    ]);
  }

  if (!_.isEmpty(finishedProducts)) {
    const finishedProductsArrayErrors = [];
    const duplicatedByproductCode = getDuplicatedSubset(
      _.map(finishedProducts, 'finishedProductCode')
    );

    finishedProducts.forEach((item, itemIndex) => {
      let finishedProductErrors = {};

      finishedProductErrors = validate(
        finishedProductErrors,
        item.finishedProductCode,
        'finishedProductCode',
        [isAlreadyExisted(duplicatedByproductCode, 'Finish Product is already listed')]
      );

      finishedProductsArrayErrors[itemIndex] = finishedProductErrors;
    });

    if (_.filter(finishedProductsArrayErrors, row => !_.isEmpty(row)).length > 0) {
      errors.finishedProducts = finishedProductsArrayErrors;
      return errors;
    }
  }
  return errors;
};

export const validateSourceMeats = (values, sourceMeatProductExist, errors) => {
  const sourceMeats = _.filter(values, sourceMeat => sourceMeat && !_.isEmpty(sourceMeat));

  if (!_.isEmpty(sourceMeats)) {
    const sourceMeatArrayErrors = [];

    sourceMeats.forEach((item, itemIndex) => {
      let sourceMeatErrors = {};

      sourceMeatErrors = validate(sourceMeatErrors, item.poNumber, 'poNumber', [alphanumeric]);
      sourceMeatErrors = validate(sourceMeatErrors, item.lotNumber, 'lotNumber', [alphanumeric]);
      sourceMeatErrors = validate(sourceMeatErrors, item.meatTemp, 'meatTemp', [positiveNumber]);
      sourceMeatErrors = validate(sourceMeatErrors, item.actualLbs, 'actualLbs', [positiveNumber]);
      sourceMeatErrors = validate(
        sourceMeatErrors,
        item.establishmentNumber,
        'establishmentNumber',
        [alphanumeric]
      );

      sourceMeatErrors = validate(sourceMeatErrors, item.sourceProductCode, 'sourceProductCode', [
        required,
        productExists(sourceMeatProductExist[item.sourceProductCode])
      ]);

      if (!_.isEmpty(sourceMeatErrors)) {
        sourceMeatArrayErrors[itemIndex] = sourceMeatErrors;
      }
    });

    if (!_.isEmpty(sourceMeatArrayErrors)) {
      errors.sourceMeats = sourceMeatArrayErrors;
    }
  }
  return errors;
};

export const validateIngredients = (values, errors, toFinish) => {
  if (
    toFinish &&
    (_.isEmpty(values) || !_.some(values, value => !_.isEmpty(_.omit(value, 'allergens'))))
  ) {
    return {
      ...errors,
      ingredients: { _error: 'One or more fields are missing, please check and finish again' }
    };
  }

  const ingredients = _.filter(
    values,
    ingredient => ingredient && !_.isEmpty(_.omit(ingredient, 'allergens'))
  );
  if (ingredients || !_.isEmpty(ingredients)) {
    const ingredientArrayErrors = [];

    ingredients.forEach((item, itemIndex) => {
      let ingredientErrors = {};

      ingredientErrors = validate(
        ingredientErrors,
        item.ingredientProductCode,
        'ingredientProductCode',
        [required]
      );
      ingredientErrors = validate(ingredientErrors, item.vendor, 'vendor', [required]);
      ingredientErrors = validate(ingredientErrors, item.poNumber, 'poNumber', [required]);
      ingredientErrors = validate(ingredientErrors, item.actualLbs, 'actualLbs', [
        required,
        positiveNumber
      ]);

      if (!_.isEmpty(ingredientErrors)) {
        ingredientArrayErrors[itemIndex] = ingredientErrors;
      }
    });

    if (!_.isEmpty(ingredientArrayErrors)) {
      errors.ingredients = ingredientArrayErrors;
    }
  }
  return errors;
};
