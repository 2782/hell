import _ from 'lodash';
import moment from 'moment';
import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { createOrUpdateBatch, finishMarinationBatch } from '../actions/batchActions';
import { FieldArray, formValueSelector, reduxForm } from 'redux-form';
import { Button, Divider, Form, Grid, Icon } from 'semantic-ui-react';
import FormLabel from '../../shared/FormLabel';
import { formatNumberToTwoDecimalPlacesString } from '../../shared/util/dataUtil';
import { validateFieldArray, validateMarinationSubmission } from './batchFormValidator';
import BatchInfo from './BatchInfo';
import SourceMeatSection from './SourceMeatSection';
import { getProduct } from '../../shared/components/product/actionsDuplicate';
import {
  calcTotalIngredientWeightLbs,
  calcTotalSourceMeatLbs,
  calcTumblerTimes
} from './batchUtils';
import BatchFinishedProductsTable from './BatchFinishedProductsTable';
import IngredientSection from './IngredientSection';
import { DEFAULT_DISPLAY_DATE_FORMAT } from '../../shared/util/dateUtil';

const formName = 'batchForm';

export class CreateMarinationBatchForm extends React.Component {
  constructor(props) {
    super(props);
  }

  componentDidMount() {
    const { initialValues, products, getProduct } = this.props;

    initialValues.finishedProducts.forEach(finishedProduct => {
      if (_.isUndefined(products[finishedProduct.finishedProductCode])) {
        getProduct(finishedProduct.finishedProductCode);
      }
    });
  }

  handleFinish(values) {
    const { finishMarinationBatch, roomCode } = this.props;

    this.handleSubmit(values, roomCode, true, finishMarinationBatch);
  }

  handleSave(values) {
    const { createOrUpdateBatch, roomCode } = this.props;

    this.handleSubmit(values, roomCode, false, createOrUpdateBatch);
  }

  handleSubmit(values, roomCode, finished, callback) {
    const submitSourceMeats = _.filter(values.sourceMeats, sourceMeat => !_.isEmpty(sourceMeat));

    validateMarinationSubmission(
      { ...values, sourceMeats: submitSourceMeats },
      this.props,
      finished
    );

    const submitValues = generateSubmitValues(values, submitSourceMeats, roomCode);

    callback({ ...submitValues, finished });
  }

  render() {
    const {
      isNewBatch,
      productionDate,
      tumblerTimes,
      totalSourceWeight,
      batchNumber,
      handleSubmit,
      submitting,
      pristine,
      finished,
      products,
      totalIngredientWeight,
      totalLbsOfBatch
    } = this.props;

    const needDisableFinishButton = submitting || finished;

    return (
      <div className='create-batch-form'>
        <Form size={'large'}>
          <Divider hidden className='divider-medium' />
          <Grid>
            <Grid.Row>
              <Grid.Column width={5}>
                <FormLabel
                  label='Batch #'
                  value={batchNumber ? batchNumber.toString() : 'Pending'}
                  width={10}
                />
              </Grid.Column>
              <Grid.Column width={6}>
                <FormLabel label='Production Date' value={productionDate} width={10} />
              </Grid.Column>
            </Grid.Row>
          </Grid>

          <Divider hidden />

          <BatchInfo isGrinder={false} tumblerTimes={tumblerTimes} lbsOfBatch={totalLbsOfBatch} />

          <Divider hidden />

          <SourceMeatSection totalSourceWeight={totalSourceWeight} batchNumber={batchNumber} />

          <Divider hidden />

          <div>
            <IngredientSection
              totalIngredientWeight={totalIngredientWeight}
              batchNumber={batchNumber}
            />
            <div>Finished Products</div>
            <Divider hidden />
            <FieldArray
              name={'finishedProducts'}
              component={BatchFinishedProductsTable}
              props={{ products, getProduct, batchNumber }}
            />
            <Divider hidden />
          </div>

          <Button
            primary
            size={'large'}
            loading={submitting}
            disabled={submitting || (!isNewBatch && pristine)}
            onClick={handleSubmit(values => {
              this.handleSave(values);
            })}
            className={'save-batch-button'}
            pid={'create-batch-save-button'}
          >
            <Icon className='icon-save' />
            Save
          </Button>

          <Button
            primary
            size={'large'}
            className={'finish-batch-button'}
            pid={'create-batch-finish-button'}
            loading={submitting}
            disabled={needDisableFinishButton}
            onClick={handleSubmit(values => {
              this.handleFinish(values);
            })}
          >
            Finish
          </Button>

          <Divider hidden />
        </Form>
      </div>
    );
  }
}

CreateMarinationBatchForm.propTypes = {
  products: PropTypes.object,
  initialValues: PropTypes.object,
  submitting: PropTypes.bool.isRequired,
  pristine: PropTypes.bool.isRequired,
  handleSubmit: PropTypes.func.isRequired,
  productionDate: PropTypes.string,
  tumblerTimes: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  createOrUpdateBatch: PropTypes.func.isRequired,
  totalSourceWeight: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  totalIngredientWeight: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  totalLbsOfBatch: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  sourceMeatProductExist: PropTypes.object,
  batchNumber: PropTypes.number,
  batch: PropTypes.object,
  finished: PropTypes.bool,
  changeFieldValue: PropTypes.func,
  finishMarinationBatch: PropTypes.func.isRequired,
  getProduct: PropTypes.func.isRequired,
  isNewBatch: PropTypes.bool,
  roomCode: PropTypes.string,
  invalid: PropTypes.bool
};

export const generateSubmitValues = (formValues, submitSourceMeats, roomCode) => {
  const submitIngredients = _.filter(
    formValues.ingredients,
    ingredient => !_.isEmpty(ingredient) && !_.isEmpty(ingredient.ingredientProductCode)
  );
  const submitFinishedProducts = _.filter(
    formValues.finishedProducts,
    finishedProduct => !_.isEmpty(finishedProduct)
  );

  return {
    ...formValues,
    sourceMeats: submitSourceMeats,
    ingredients: submitIngredients,
    finishedProducts: submitFinishedProducts,
    portionRoomCode: roomCode
  };
};

const mapDispatchToProps = dispatch => {
  return bindActionCreators(
    {
      getProduct,
      createOrUpdateBatch,
      finishMarinationBatch
    },
    dispatch
  );
};

const getInitialSourceMeats = batch => {
  const initialSourceMeats = _.map(_.get(batch, 'sourceMeats', []), sourceMeat => {
    return {
      ...sourceMeat,
      actualLbs: formatNumberToTwoDecimalPlacesString(_.get(sourceMeat, 'actualLbs', '')),
      meatTemp: formatNumberToTwoDecimalPlacesString(_.get(sourceMeat, 'meatTemp', ''))
    };
  });
  return initialSourceMeats.length > 0 ? initialSourceMeats : [{}];
};

const getInitialIngredients = batch => {
  const initialIngredients = _.map(_.get(batch, 'ingredients', []), ingredient => {
    return {
      ...ingredient,
      actualLbs: formatNumberToTwoDecimalPlacesString(_.get(ingredient, 'actualLbs', '')),
      allergens: _.get(ingredient, 'allergens', false)
    };
  });
  return initialIngredients.length > 0 ? initialIngredients : [{ allergens: false }];
};

const selector = formValueSelector(formName);
const mapStateToProps = (state, ownProps) => {
  const { portionRooms, currentPortionRoom } = state.portionRoomsInfo;
  const currentDate = _.get(
    _.find(portionRooms, { code: currentPortionRoom.code }),
    'lastOpenedAt'
  );
  const { batch } = ownProps;

  const batchNumber = selector(state, 'batchNumber');

  const tumblerStartTime = selector(state, 'tumblerStartTime');
  const tumblerStopTime = selector(state, 'tumblerStopTime');
  const tumblerTimes = calcTumblerTimes(tumblerStartTime, tumblerStopTime);
  const products = state.productDuplicate.products ? state.productDuplicate.products : {};
  const sourceMeats = selector(state, 'sourceMeats');
  const ingredients = selector(state, 'ingredients');
  const totalSourceWeight = calcTotalSourceMeatLbs(sourceMeats);
  const totalIngredientWeight = calcTotalIngredientWeightLbs(ingredients);

  const produceDate = _.get(batch, 'productionDate', currentDate);
  const formattedProductDate = moment(
    new Date(
      produceDate && produceDate != currentDate ? produceDate.replace(/-/g, '/') : produceDate
    )
  ).format(DEFAULT_DISPLAY_DATE_FORMAT);

  const isNewBatch = _.isEmpty(batch);
  const roomCode = _.get(batch, 'portionRoomCode', currentPortionRoom.code);

  const sourceMeatProductExist = _.reduce(
    sourceMeats,
    (result, sourceMeat, index) => {
      const sourceProductInfo = state.product[`${formName}-sourceMeat-${index}`] || {};
      if (!_.isEmpty(sourceMeat)) {
        result[sourceMeat.sourceProductCode] = !_.isEmpty(sourceProductInfo.description);
      }

      return result;
    },
    {}
  );

  const initialSourceMeats = getInitialSourceMeats(batch);
  const initialIngredients = getInitialIngredients(batch);

  const initialFinishedProducts = [];
  const existingFinishedProducts = _.get(batch, 'finishedProducts', []);

  existingFinishedProducts.forEach(product => initialFinishedProducts.push(product));
  initialFinishedProducts.push({});

  return {
    initialValues: {
      id: _.get(batch, 'id', ''),
      batchNumber: _.get(batch, 'batchNumber', undefined),
      productionDate: formattedProductDate,
      tumbler: _.get(batch, 'tumbler', ''),
      tumblerStartTime: _.get(batch, 'tumblerStartTime', ''),
      tumblerStopTime: _.get(batch, 'tumblerStopTime', ''),
      startBatchTemp: formatNumberToTwoDecimalPlacesString(_.get(batch, 'startBatchTemp', '')),
      finishedBatchTemp: formatNumberToTwoDecimalPlacesString(
        _.get(batch, 'finishedBatchTemp', '')
      ),
      allergens: _.get(batch, 'allergens', false),
      sourceMeats: initialSourceMeats,
      ingredients: initialIngredients,
      finishedProducts: initialFinishedProducts,
      finished: _.get(batch, 'finished', false)
    },
    products,
    batchNumber,
    productionDate: formattedProductDate,
    totalSourceWeight: formatNumberToTwoDecimalPlacesString(totalSourceWeight) || '',
    totalIngredientWeight: formatNumberToTwoDecimalPlacesString(totalIngredientWeight) || '',
    totalLbsOfBatch:
      formatNumberToTwoDecimalPlacesString(totalSourceWeight + totalIngredientWeight) || '',
    finished: _.get(batch, 'finished', false),
    isNewBatch,
    tumblerTimes,
    sourceMeatProductExist,
    roomCode
  };
};

const getFinishedProduct = (blurredField, values, props) => {
  const regex = /finishedProducts\[([\w-]*)].finishedProductCode/;
  const index = parseInt(blurredField.match(regex)[1]);
  const value = values.finishedProducts[index].finishedProductCode;
  return !_.isEmpty(value)
    ? props.getProduct(value, () => {
        let finishedProductErrors = Array.apply(null, { length: index + 1 }).map(() => ({}));
        finishedProductErrors[index] = { finishedProductCode: 'Invalid Item Number' };
        return { finishedProducts: finishedProductErrors };
      })
    : Promise.resolve();
};

export const asyncValidate = (values, dispatch, props, blurredField) => {
  if (blurredField && blurredField.match('finishedProducts.*\\.finishedProductCode')) {
    return getFinishedProduct(blurredField, values, props);
  }
  return Promise.resolve();
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(
  reduxForm({
    form: formName,
    asyncValidate,
    validate: validateFieldArray,
    enableReinitialize: true,
    asyncBlurFields: ['finishedProducts[].finishedProductCode']
  })(CreateMarinationBatchForm)
);
