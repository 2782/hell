import {
  validateFieldArray,
  validateFinishedProducts,
  validateIngredients,
  validateSubmission
} from '../batchFormValidator';
import BatchFactory from '../../../../test-factories/batch';

describe('batchFormValidator', () => {
  let batch, sourceMeatProductExist, sourceMeat;

  beforeEach(() => {
    batch = BatchFactory.build();
    sourceMeatProductExist = { '0078889': true };
    sourceMeat = {
      poNumber: '12',
      lotNumber: '12',
      sourceProductCode: '0078889',
      meatTemp: '12.12',
      vendor: '122',
      actualLbs: '12.13',
      establishmentNumber: 'ab1',
      harvestDate: '2018-12-12'
    };
  });

  describe('submission validation', () => {
    test('should call submit with given values', () => {
      validateSubmission(
        batch,
        {
          sourceMeatProductExist
        },
        false
      );
    });

    test('should check that fields are required', () => {
      const errors = validateSubmission({}, { sourceMeatProductExist: {} }, false);
      jestExpect(errors.tumbler).toEqual('Required');
    });

    describe('should validate tumblerStopTime, tumblerStopTime', () => {
      test('should validate failed when tumblerStopTime is before than tumblerStopTime', () => {
        batch = BatchFactory.build({ tumblerStopTime: '12:34', tumblerStartTime: '13:10' });
        const errors = validateSubmission(batch, { sourceMeatProductExist: {} }, false);
        jestExpect(errors.tumblerStopTime).toEqual('Stop time should be greater than start time');
      });

      test('should validate failed when tumblerStartTime has not been fill out', () => {
        batch = BatchFactory.build({ tumblerStopTime: '12:34', tumblerStartTime: '--' });
        const errors = validateSubmission(batch, { sourceMeatProductExist: {} }, true);
        jestExpect(errors.tumblerStartTime).toEqual('Invalid time format');
      });

      test('should validate successfully when tumblerStopTime has not been fill out and tumblerStopTime is filled', () => {
        batch = BatchFactory.build({ tumblerStopTime: '--' });
        const errors = validateSubmission(batch, { sourceMeatProductExist }, true);
        jestExpect(errors.tumblerStopTime).toEqual('Invalid time format');
      });
    });

    describe('should validate for source meats', () => {
      [
        { scenario: 'withSpecChar', qty: 'abc&', errorMessage: 'Only numbers or letters' },
        { scenario: 'negative', qty: '-3', errorMessage: 'Only numbers or letters' },
        { scenario: 'decimal', qty: '3.12', errorMessage: 'Only numbers or letters' }
      ].forEach(({ scenario, qty, errorMessage }) => {
        test(`should validate failed when poNumber is ${scenario}`, () => {
          batch = BatchFactory.build({ sourceMeats: [{ ...sourceMeat, poNumber: qty }] });
          const errors = validateSubmission(batch, { sourceMeatProductExist }, false);
          jestExpect(errors.sourceMeats[0].poNumber).toEqual(errorMessage);
        });
      });

      [
        { scenario: 'withSpecChar', qty: 'abc&', errorMessage: 'Only numbers or letters' },
        { scenario: 'negative', qty: '-3', errorMessage: 'Only numbers or letters' },
        { scenario: 'decimal', qty: '3.12', errorMessage: 'Only numbers or letters' }
      ].forEach(({ scenario, qty, errorMessage }) => {
        test(`should validate failed when establishmentNumber is ${scenario}`, () => {
          batch = BatchFactory.build({
            sourceMeats: [{ ...sourceMeat, establishmentNumber: qty }]
          });
          const errors = validateSubmission(
            batch,
            {
              sourceMeatProductExist
            },
            false
          );
          jestExpect(errors.sourceMeats[0].establishmentNumber).toEqual(errorMessage);
        });
      });

      [
        { scenario: 'withSpecChar', qty: 'abc&', errorMessage: 'Only numbers or letters' },
        { scenario: 'negative', qty: '-3', errorMessage: 'Only numbers or letters' },
        { scenario: 'decimal', qty: '3.12', errorMessage: 'Only numbers or letters' }
      ].forEach(({ scenario, qty, errorMessage }) => {
        test(`should validate failed when lotNumber is ${scenario}`, () => {
          batch = BatchFactory.build({ sourceMeats: [{ ...sourceMeat, lotNumber: qty }] });
          const errors = validateSubmission(batch, { sourceMeatProductExist }, false);
          jestExpect(errors.sourceMeats[0].lotNumber).toEqual(errorMessage);
        });
      });

      [
        { scenario: 'alphanumeric', qty: 'abc', errorMessage: 'Must be a positive number' },
        { scenario: 'negative', qty: '-3', errorMessage: 'Must be a positive number' }
      ].forEach(({ scenario, qty, errorMessage }) => {
        test(`should validate failed when meatTemp is ${scenario}`, () => {
          batch = BatchFactory.build({ sourceMeats: [{ ...sourceMeat, meatTemp: qty }] });
          const errors = validateSubmission(batch, { sourceMeatProductExist }, false);
          jestExpect(errors.sourceMeats[0].meatTemp).toEqual(errorMessage);
        });
      });

      [
        { scenario: 'alphanumeric', qty: 'abc', errorMessage: 'Must be a positive number' },
        { scenario: 'negative', qty: '-3', errorMessage: 'Must be a positive number' }
      ].forEach(({ scenario, qty, errorMessage }) => {
        test(`should validate failed when actualLbs is ${scenario}`, () => {
          batch = BatchFactory.build({ sourceMeats: [{ ...sourceMeat, actualLbs: qty }] });
          const errors = validateSubmission(batch, { sourceMeatProductExist }, false);
          jestExpect(errors.sourceMeats[0].actualLbs).toEqual(errorMessage);
        });
      });

      test('should not fail if sourceMeat does not exist when saving only - not finish', () => {
        batch = BatchFactory.build({ sourceMeats: [] });
        const errors = validateSubmission(
          batch,
          { sourceMeatProductExist: { '0078889': false } },
          false
        );
        jestExpect(errors).toEqual({});
      });

      test('should not fail validation when vendor does not exist and saving', () => {
        batch = BatchFactory.build({ sourceMeats: [{ ...sourceMeat, vendor: '' }] });
        const errors = validateSubmission(
          batch,
          { sourceMeatProductExist: { '0078889': true } },
          false
        );
        jestExpect(errors).toEqual({});
      });

      test('should fail when vendor is required and finishing', () => {
        batch = BatchFactory.build({ sourceMeats: [{ ...sourceMeat, vendor: '' }] });
        const errors = validateSubmission(batch, { sourceMeatProductExist: {} }, true);
        jestExpect(errors.sourceMeats[0].vendor).toEqual('Required');
      });

      test('should validate failed when source product is required', () => {
        batch = BatchFactory.build({ sourceMeats: [{ ...sourceMeat, sourceProductCode: '' }] });
        const errors = validateSubmission(batch, { sourceMeatProductExist: {} }, false);
        jestExpect(errors.sourceMeats[0].sourceProductCode).toEqual('Required');
      });

      test('should validate failed when source product code does not exist', () => {
        batch = BatchFactory.build({
          sourceMeats: [{ ...sourceMeat, sourceProductCode: '0078889' }]
        });
        const errors = validateSubmission(
          batch,
          { sourceMeatProductExist: { '0078889': false } },
          false
        );
        jestExpect(errors.sourceMeats[0].sourceProductCode).toEqual('Invalid Item Number');
      });

      test('should validate successfully when source meat is valid', () => {
        batch = BatchFactory.build({ sourceMeats: [sourceMeat] });
        const errors = validateSubmission(batch, { sourceMeatProductExist }, false);
        jestExpect(errors).toEqual({});
      });
    });

    describe('should check for all required fields when finishing a batch', () => {
      test('should failed when there is no source meat', () => {
        batch = BatchFactory.build({ sourceMeats: [] });
        const errors = validateSubmission(batch, { sourceMeatProductExist: {} }, true);
        jestExpect(errors.sourceMeats._error).toEqual(
          'One or more fields are missing, please check and finish again'
        );
      });

      test('should fail when some batch info fields are missing', () => {
        batch = BatchFactory.build({
          tumblerStartTime: '',
          tumblerStopTime: '',
          startBatchTemp: '',
          finishedBatchTemp: ''
        });
        const errors = validateSubmission(batch, { sourceMeatProductExist: {} }, true);
        jestExpect(errors.tumblerStartTime).toEqual('Required');
        jestExpect(errors.tumblerStopTime).toEqual('Required');
        jestExpect(errors.startBatchTemp).toEqual('Required');
        jestExpect(errors.finishedBatchTemp).toEqual('Required');
      });

      test('should fail when some source meat fields are missing', () => {
        batch = BatchFactory.build({ sourceMeats: [sourceMeat, { sourceProductCode: '' }] });
        const errors = validateSubmission(batch, { sourceMeatProductExist }, true);
        jestExpect(errors.sourceMeats[1].sourceProductCode).toEqual('Required');
        jestExpect(errors.sourceMeats[1].poNumber).toEqual('Required');
        jestExpect(errors.sourceMeats[1].lotNumber).toEqual('Required');
        jestExpect(errors.sourceMeats[1].meatTemp).toEqual('Required');
        jestExpect(errors.sourceMeats[1].actualLbs).toEqual('Required');
        jestExpect(errors.sourceMeats[1].establishmentNumber).toEqual('Required');
        jestExpect(errors.sourceMeats[1].harvestDate).toEqual('Required');
      });
    });

    describe('should validate finished product code', () => {
      test('should return error message when no finishedProducts are provided on finish', () => {
        const finishedProducts = [{}];
        const errors = validateFinishedProducts(finishedProducts, {}, true);

        jestExpect(errors).toEqual({
          finishedProducts: {
            _error: 'One or more fields are missing, please check and finish again'
          }
        });
      });

      test('should return empty message when no finishedProducts are provided on save', () => {
        const finishedProducts = [{}];
        const errors = validateFieldArray(
          {
            tumblerStartTime: '--',
            tumblerStopTime: '--',
            finishedProducts
          },
          {},
          false
        );

        jestExpect(errors).toEqual({
          tumblerStartTime: 'Invalid time format',
          tumblerStopTime: 'Invalid time format'
        });
      });

      test('should return error message  when there is duplicate product codes', () => {
        const values = {
          tumblerStopTime: '--',
          tumblerStartTime: '--',
          finishedProducts: [
            {
              finishedProductCode: '4102218'
            },
            { finishedProductCode: '4102218' }
          ]
        };
        const errors = validateFieldArray(values);

        jestExpect(errors).toEqual({
          finishedProducts: [
            { finishedProductCode: 'Finish Product is already listed' },
            { finishedProductCode: 'Finish Product is already listed' }
          ],
          tumblerStartTime: 'Invalid time format',
          tumblerStopTime: 'Invalid time format'
        });
      });

      test('should return error message  when stop time greater than start time', () => {
        const values = {
          tumblerStartTime: '03:03',
          tumblerStopTime: '02:02'
        };
        const errors = validateFieldArray(values);

        jestExpect(errors).toEqual({
          tumblerStopTime: 'Stop time should be greater than start time'
        });
      });

      test('should return empty when there is no duplicate product codes', () => {
        const values = {
          tumblerStartTime: '--',
          tumblerStopTime: '--',
          finishedProducts: [
            {
              finishedProductCode: '4102218'
            },
            { finishedProductCode: '4102219' }
          ]
        };
        const errors = validateFieldArray(values);

        jestExpect(errors).toEqual({
          tumblerStartTime: 'Invalid time format',
          tumblerStopTime: 'Invalid time format'
        });
      });
    });

    describe('should validate ingredients', () => {
      test('should return error message when no ingredients are provided on finish', () => {
        const ingredients = [
          {
            allergens: false
          }
        ];
        const errors = validateIngredients(ingredients, {}, true);

        jestExpect(errors).toEqual({
          ingredients: { _error: 'One or more fields are missing, please check and finish again' }
        });
      });

      test('should return error message when required fields are missing', () => {
        const ingredients = [
          {
            ingredientProductCode: '123456',
            vendor: null,
            poNumber: null,
            actualLbs: null
          }
        ];
        const errors = validateIngredients(ingredients, {}, false);

        jestExpect(errors).toEqual({
          ingredients: [
            {
              vendor: 'Required',
              poNumber: 'Required',
              actualLbs: 'Required'
            }
          ]
        });
      });

      test('should return empty when not validating finished and no fields exist', () => {
        const ingredients = [
          {
            allergens: false
          }
        ];
        const errors = validateIngredients(ingredients, {}, false);

        jestExpect(errors).toEqual({});
      });

      test('should return empty when required fields are exist', () => {
        const ingredients = [
          {
            ingredientProductCode: '4102218',
            vendor: '001',
            poNumber: '002',
            actualLbs: 10
          }
        ];
        const errors = validateIngredients(ingredients, {}, false);

        jestExpect(errors).toEqual({});
      });
    });
  });
});
