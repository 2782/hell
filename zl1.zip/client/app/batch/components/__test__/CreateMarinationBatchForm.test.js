import { mount } from 'enzyme';
import React from 'react';
import { createReduxStore } from '../../../store';
import { Provider } from 'react-redux';
import CreateMarinationBatchForm, { generateSubmitValues } from '../CreateMarinationBatchForm';
import semanticUI from '../../../../test-helpers/semantic-ui';
import batchResources from '../../../shared/api/batchResources';
import { MARINATION_BATCH } from '../../../../test-factories/batch';
import productResources from '../../../shared/api/productResources';
import productFactory from '../../../../test-factories/productFactory';

jest.mock('../../../shared/api/batchResources');
jest.mock('../../../shared/api/productResources');

describe('createMarinationBatchForm', () => {
  let form, savedBatch, unsavedBatch;

  beforeEach(() => {
    productResources.getProductInfo.mockImplementation((arg, success) => {
      return success({ data: productFactory.build({ code: '0078889' }) });
    });
  });

  afterEach(() => {
    batchResources.create.mockReset();
    batchResources.update.mockReset();
    batchResources.finishMarination.mockReset();
    productResources.getProductInfo.mockReset();
  });

  describe('for cutting room', () => {
    let storeForCuttingRoom;
    beforeEach(() => {
      savedBatch = MARINATION_BATCH;
      unsavedBatch = { ...MARINATION_BATCH, batchNumber: null };

      storeForCuttingRoom = createReduxStore({
        portionRoomsInfo: {
          currentPortionRoom: {
            code: 'A',
            roomType: 'CUTTING'
          },
          portionRooms: [
            {
              code: 'A',
              lastOpenedAt: '2018-07-05T11:01:00.216-05:00'
            }
          ]
        }
      });
      form = mount(
        <Provider store={storeForCuttingRoom}>
          <CreateMarinationBatchForm />
        </Provider>
      );
    });

    describe('should render input component', () => {
      test('should render input component without initialValue for cutting room', () => {
        jestExpect(semanticUI.findLabelWithName(form, 'Batch #')).toHaveProp('value', 'Pending');
        jestExpect(semanticUI.findLabelWithName(form, 'Blend Name')).not.toExist();
        jestExpect(semanticUI.findLabelWithName(form, 'Production Date')).toHaveProp(
          'value',
          '07-05-2018'
        );
        jestExpect(semanticUI.getInputValue(form, 'tumbler')).toEqual('');
        jestExpect(semanticUI.getInputValue(form, 'startBatchTemp')).toEqual('');
        jestExpect(semanticUI.getInputValue(form, 'finishedBatchTemp')).toEqual('');
        jestExpect(semanticUI.getInputValue(form, 'tumblerStartTime')).toEqual('');
        jestExpect(semanticUI.getInputValue(form, 'tumblerStopTime')).toEqual('');
        jestExpect(semanticUI.findLabelWithName(form, 'Lbs of Batch')).toHaveProp('value', '');

        jestExpect(semanticUI.getInputValue(form, 'sourceMeats[0].sourceProductCode')).toEqual('');
        jestExpect(semanticUI.getInputValue(form, 'sourceMeats[0].poNumber')).toEqual('');
        jestExpect(semanticUI.getInputValue(form, 'sourceMeats[0].lotNumber')).toEqual('');
        jestExpect(semanticUI.getInputValue(form, 'sourceMeats[0].vendor')).toEqual('');
        jestExpect(semanticUI.getInputValue(form, 'sourceMeats[0].meatTemp')).toEqual('');
        jestExpect(semanticUI.getInputValue(form, 'sourceMeats[0].actualLbs')).toEqual('');
        jestExpect(semanticUI.getInputValue(form, 'sourceMeats[0].establishmentNumber')).toEqual(
          ''
        );
        jestExpect(semanticUI.getInputValue(form, 'sourceMeats[0].harvestDate')).toEqual('');

        jestExpect(semanticUI.getInputValue(form, 'ingredients[0].ingredientProductCode')).toEqual(
          ''
        );
        jestExpect(semanticUI.getInputValue(form, 'ingredients[0].vendor')).toEqual('');
        jestExpect(semanticUI.getInputValue(form, 'ingredients[0].poNumber')).toEqual('');
        jestExpect(semanticUI.getInputValue(form, 'ingredients[0].actualLbs')).toEqual('');
        jestExpect(semanticUI.getCheckBoxValue(form, 'ingredients[0].allergens')).toEqual(false);

        jestExpect(
          semanticUI.getInputValue(form, 'finishedProducts[0].finishedProductCode')
        ).toEqual('');
      });

      test('should render input component with initialValue for cutting room', () => {
        form = mount(
          <Provider store={storeForCuttingRoom}>
            <CreateMarinationBatchForm batch={unsavedBatch} />
          </Provider>
        );

        const findLabelWithName = createFindLabelWithNameSelector(form);
        const getInputValue = createGetInputValueSelector(form);

        jestExpect(findLabelWithName('Batch #')).toHaveProp('value', 'Pending');
        jestExpect(findLabelWithName('Blend Name')).not.toExist();
        jestExpect(findLabelWithName('Production Date')).toHaveProp('value', '05-29-2018');
        jestExpect(getInputValue('tumbler')).toEqual('123');
        jestExpect(getInputValue('startBatchTemp')).toEqual('23.20');
        jestExpect(getInputValue('finishedBatchTemp')).toEqual('27.40');
        jestExpect(getInputValue('tumblerStartTime')).toEqual('14:58');
        jestExpect(getInputValue('tumblerStopTime')).toEqual('16:43');
        jestExpect(findLabelWithName('Lbs of Batch')).toHaveProp('value', '24.26');

        jestExpect(getInputValue('sourceMeats[0].sourceProductCode')).toEqual('0078889');
        jestExpect(getInputValue('sourceMeats[0].poNumber')).toEqual('12');
        jestExpect(getInputValue('sourceMeats[0].lotNumber')).toEqual('11');
        jestExpect(getInputValue('sourceMeats[0].vendor')).toEqual('vendor name');
        jestExpect(getInputValue('sourceMeats[0].meatTemp')).toEqual('12.12');
        jestExpect(getInputValue('sourceMeats[0].actualLbs')).toEqual('12.13');
        jestExpect(getInputValue('sourceMeats[0].establishmentNumber')).toEqual('ab1');
        jestExpect(getInputValue('sourceMeats[0].harvestDate')).toEqual('12-12-2018');

        jestExpect(getInputValue('ingredients[0].ingredientProductCode')).toEqual('0078889');
        jestExpect(getInputValue('ingredients[0].vendor')).toEqual('vendor name');
        jestExpect(getInputValue('ingredients[0].poNumber')).toEqual('12');
        jestExpect(getInputValue('ingredients[0].actualLbs')).toEqual('12.13');
        jestExpect(semanticUI.getCheckBoxValue(form, 'ingredients[0].allergens')).toEqual(true);

        jestExpect(getInputValue('finishedProducts[0].finishedProductCode')).toEqual('4391102');
      });

      test('should fill out form and create batch for cutting room', () => {
        form = mount(
          <Provider store={storeForCuttingRoom}>
            <CreateMarinationBatchForm
              shouldAsyncValidate={() => false}
              blendName='kobe'
              grindSize='3/16'
            />
          </Provider>
        );
        semanticUI.changeInput(form, 'tumbler', '234');
        semanticUI.changeInput(form, 'tumblerStartTime', '11:20');
        semanticUI.changeInput(form, 'tumblerStopTime', '12:20');

        form
          .find('.save-batch-button')
          .at(0)
          .simulate('click');
        form = form.update();

        jestExpect(batchResources.create.mock.calls[0][0]).toEqual({
          allergens: false,
          batchNumber: undefined,
          finished: false,
          finishedBatchTemp: '',
          finishedProducts: [],
          id: '',
          ingredients: [],
          portionRoomCode: 'A',
          productionDate: '2018-07-05',
          sourceMeats: [],
          startBatchTemp: '',
          tumbler: '234',
          tumblerStartTime: '11:20',
          tumblerStopTime: '12:20'
        });
      });

      test('should not submit when source meat is invalid', () => {
        form = mount(
          <Provider store={storeForCuttingRoom}>
            <CreateMarinationBatchForm />
          </Provider>
        );
        semanticUI.changeInput(form, 'tumbler', '234');
        semanticUI.changeInput(form, 'tumblerStartTime', '11:20');
        semanticUI.changeInput(form, 'tumblerStopTime', '12:20');
        semanticUI.changeInput(form, 'sourceMeats[0].poNumber', 'xx');

        form.find('form').simulate('submit');

        jestExpect(batchResources.create).not.toHaveBeenCalled();
      });

      test('should not finish when has empty fields', () => {
        form = mount(
          <Provider store={storeForCuttingRoom}>
            <CreateMarinationBatchForm />
          </Provider>
        );
        semanticUI.changeInput(form, 'tumbler', '234');
        semanticUI.changeInput(form, 'tumblerStartTime', '11:20');
        semanticUI.changeInput(form, 'tumblerStopTime', '12:20');
        semanticUI.changeInput(form, 'sourceMeats[0].poNumber', 'xx');

        const finishButton = form.find('button').at(3);
        finishButton.simulate('click');
        finishButton.simulate('submit');

        jestExpect(batchResources.create).not.toHaveBeenCalled();
      });

      test('should fill out form and finish an existing batch', () => {
        savedBatch = MARINATION_BATCH;

        storeForCuttingRoom = createReduxStore({
          portionRoomsInfo: {
            currentPortionRoom: {
              code: 'A',
              roomType: 'CUTTING'
            }
          }
        });
        form = mount(
          <Provider store={storeForCuttingRoom}>
            <CreateMarinationBatchForm shouldAsyncValidate={() => false} batch={savedBatch} />
          </Provider>
        );

        semanticUI.changeInput(form, 'tumbler', '234');

        const finishButton = form.find('button').at(3);
        finishButton.simulate('click');
        finishButton.simulate('submit');

        jestExpect(batchResources.finishMarination.mock.calls[0][0]).toEqual({
          allergens: false,
          batchNumber: 123,
          finished: true,
          finishedBatchTemp: '27.40',
          finishedProducts: [{ finishedProductCode: '4391102' }],
          id: 12,
          ingredients: [
            {
              actualLbs: '12.13',
              allergens: true,
              id: 12,
              ingredientProductCode: '0078889',
              poNumber: '12',
              vendor: 'vendor name'
            }
          ],
          portionRoomCode: 'A',
          productionDate: '2018-05-29',
          sourceMeats: [
            {
              actualLbs: '12.13',
              establishmentNumber: 'ab1',
              harvestDate: '2018-12-12',
              id: 12,
              lotNumber: '11',
              meatTemp: '12.12',
              poNumber: '12',
              sourceProductCode: '0078889',
              vendor: 'vendor name'
            }
          ],
          startBatchTemp: '23.20',
          tumbler: '234',
          tumblerStartTime: '14:58',
          tumblerStopTime: '16:43'
        });
      });

      test('should update batch main info for cutting room', () => {
        form = mount(
          <Provider store={storeForCuttingRoom}>
            <CreateMarinationBatchForm shouldAsyncValidate={() => false} batch={savedBatch} />
          </Provider>
        );

        semanticUI.changeInput(form, 'tumbler', '234');
        semanticUI.changeInput(form, 'tumblerStartTime', '11:20');
        semanticUI.changeInput(form, 'tumblerStopTime', '12:20');

        form
          .find('.save-batch-button')
          .at(0)
          .simulate('click');

        jestExpect(batchResources.update.mock.calls[0][0]).toEqual({
          id: 12,
          batchNumber: 123,
          tumbler: '234',
          allergens: false,
          tumblerStartTime: '11:20',
          tumblerStopTime: '12:20',
          finishedBatchTemp: '27.40',
          startBatchTemp: '23.20',
          portionRoomCode: 'A',
          sourceMeats: [
            {
              id: 12,
              poNumber: '12',
              lotNumber: '11',
              sourceProductCode: '0078889',
              meatTemp: '12.12',
              actualLbs: '12.13',
              vendor: 'vendor name',
              establishmentNumber: 'ab1',
              harvestDate: '2018-12-12'
            }
          ],
          ingredients: [
            {
              id: 12,
              vendor: 'vendor name',
              poNumber: '12',
              ingredientProductCode: '0078889',
              actualLbs: '12.13',
              allergens: true
            }
          ],
          finishedProducts: [
            {
              finishedProductCode: '4391102'
            }
          ],
          productionDate: '2018-05-29',
          finished: false
        });
      });
    });
  });
});

describe('generate submit values', () => {
  it('should filter the blank finished product rows', () => {
    const formValues = { finishedProducts: [''] };

    const result = generateSubmitValues(formValues, null, null);

    jestExpect(result.finishedProducts).toEqual([]);
  });
});

function createFindLabelWithNameSelector(wrapper) {
  return function(name) {
    return semanticUI.findLabelWithName(wrapper, name);
  };
}

function createGetInputValueSelector(wrapper) {
  return function(name) {
    return semanticUI.getInputValue(wrapper, name);
  };
}
