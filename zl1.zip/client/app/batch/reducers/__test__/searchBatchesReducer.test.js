import BatchFactory from '../../../../test-factories/batch';
import searchBatchesReducer from '../searchBatchesReducer';
import { clearSearchBatches, searchBatchesSuccess } from '../../actions/batchActionCreators';

const batch = BatchFactory.build();

describe('searchBatchesReducer', () => {
  let initState;
  beforeEach(() => {
    initState = {
      batches: []
    };
  });

  test('should update state on successful search', () => {
    const testResponse = { data: [batch] };

    jestExpect(searchBatchesReducer(initState, searchBatchesSuccess(testResponse))).toEqual({
      batches: testResponse.data
    });
  });

  test('should clear search results', () => {
    const state = {
      batches: [{ batch1: 'something' }]
    };

    jestExpect(searchBatchesReducer(state, clearSearchBatches())).toEqual(initState);
  });
});
