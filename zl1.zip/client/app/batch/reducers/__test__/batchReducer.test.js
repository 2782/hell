import { UPDATE_BATCH, UPDATE_BATCHES } from '../../actions/batchActionTypes';
import BatchFactory from '../../../../test-factories/batch';
import batchReducer from '../batchReducer';

const batch = BatchFactory.build();

describe('batchReducer', () => {
  let initState;
  beforeEach(() => {
    initState = {
      batch: {},
      batches: [],
      isFinishing: false
    };
  });

  test('should update batch when receiving action UPDATE_BATCH', () => {
    const result = batchReducer(initState, {
      type: UPDATE_BATCH,
      payload: batch
    });
    jestExpect(result).toEqual({
      ...initState,
      batch: batch
    });
  });

  test('should update batches when revice action UPDATE_BATCHES', () => {
    const result = batchReducer(initState, {
      type: UPDATE_BATCHES,
      payload: [batch]
    });
    jestExpect(result).toEqual({
      ...initState,
      batches: [batch]
    });
  });
});
