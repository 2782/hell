import React from 'react';
import SearchBatch, { asyncValidate, SearchBatchComponent } from '../SearchBatch';
import { createReduxStore } from '../../../store';
import { Provider } from 'react-redux';
import { F4 } from '../../../shared/components/pageFooters';
import semanticUI from '../../../../test-helpers/semantic-ui';
import { searchBatches } from '../../actions/batchActions';
import BatchFactory from '../../../../test-factories/batch';
import { searchBatchesSuccess } from '../../actions/batchActionCreators';
import productResources from '../../../shared/api/productResources';
import { initialize } from 'redux-form';
import { isoDateToDisplayDate } from '../../../shared/util/dateUtil';

jest.mock('../../actions/batchActions');
jest.mock('../../../shared/api/productResources');

jest.mock('../../../requestMeat/actions/meatRequestActions', () => ({
  getBlends: jest.fn(() => ({
    type: 'getBlends',
    payload: [
      {
        name: 'NATURAL',
        displayName: 'Natural'
      }
    ]
  }))
}));

describe('Search Batch', () => {
  test('should fill out form and submit', () => {
    const batch1 = BatchFactory.build({
      tumblerStartTime: '14:58',
      tumblerStopTime: '16:43'
    });

    const formattedBatchStart = '2:58 PM';
    const formattedBatchStop = '4:43 PM';

    const batches = [batch1];

    searchBatches.mockImplementation(() => searchBatchesSuccess({ data: batches }));

    productResources.getProductInfoPromise.mockResolvedValue({ data: 'Mock product data' });

    const store = createReduxStore({});

    const dispatchSpy = jest.spyOn(store, 'dispatch');

    const wrapper = mount(
      <Provider store={store}>
        <SearchBatch shouldAsyncValidate={() => false} />
      </Provider>
    );

    const searchInputFields = {
      productionDateStart: '06-25-2018',
      productionDateEnd: '06-25-2018',
      sourcePurchaseOrderNumber: '69109750',
      sourceNumber: '123',
      finishedOrBlend: 'NATURAL'
    };

    semanticUI.changeInput(wrapper, 'productionDateStart', searchInputFields.productionDateStart);
    semanticUI.changeInput(wrapper, 'productionDateEnd', searchInputFields.productionDateEnd);
    semanticUI.changeInput(
      wrapper,
      'sourcePurchaseOrderNumber',
      searchInputFields.sourcePurchaseOrderNumber
    );
    semanticUI.changeInput(wrapper, 'sourceNumber', searchInputFields.sourceNumber);
    semanticUI.changeInput(wrapper, 'finishedOrBlend', searchInputFields.finishedOrBlend);

    const searchButton = wrapper.find('button[pid="search-batch-button"]');

    searchButton.simulate('submit');

    jestExpect(dispatchSpy).toHaveBeenCalledWith(searchBatches());
    jestExpect(searchBatches).toHaveBeenCalledWith(searchInputFields);

    const batchTableHeader = semanticUI.findTable(wrapper, 0).find('th');

    jestExpect(batchTableHeader.at(0)).toHaveText('Date');
    jestExpect(batchTableHeader.at(1)).toHaveText('Room');
    jestExpect(batchTableHeader.at(2)).toHaveText('Type');
    jestExpect(batchTableHeader.at(3)).toHaveText('Batch #');
    jestExpect(batchTableHeader.at(4)).toHaveText('Source PO #');
    jestExpect(batchTableHeader.at(5)).toHaveText('Start Time');
    jestExpect(batchTableHeader.at(6)).toHaveText('Stop Time');
    jestExpect(batchTableHeader.at(7)).toHaveText('Status');

    const batchTableBody = wrapper.find('tbody').at(0);

    const findCellRowAndColumnIndex = createCellSelector(batchTableBody);

    jestExpect(findCellRowAndColumnIndex(0, 0)).toHaveText(
      isoDateToDisplayDate(batch1.productionDate)
    );
    jestExpect(findCellRowAndColumnIndex(0, 1)).toHaveText('D');
    jestExpect(findCellRowAndColumnIndex(0, 2)).toHaveText('GRINDING');
    jestExpect(findCellRowAndColumnIndex(0, 3)).toHaveText(batch1.batchNumber.toString());
    jestExpect(findCellRowAndColumnIndex(0, 4)).toHaveText(
      batch1.sourceMeats[0].poNumber.toString()
    );
    jestExpect(findCellRowAndColumnIndex(0, 5)).toHaveText(formattedBatchStart);
    jestExpect(findCellRowAndColumnIndex(0, 6)).toHaveText(formattedBatchStop);
    jestExpect(findCellRowAndColumnIndex(0, 7)).toHaveText('UNFINISHED');

    function createCellSelector(tableBody) {
      return function(row, column) {
        return semanticUI.findTableColumnWithRowIndex(tableBody, row, column);
      };
    }
  });

  test('sets up header and footer and fetches batch names', () => {
    const setHeaderAndFooter = jest.fn();
    const getBlends = jest.fn();
    const submit = jest.fn();
    const scrollToTop = jest.fn();

    const component = new SearchBatchComponent({
      setHeaderAndFooter,
      getBlends,
      submit
    });

    component.scrollToTop = scrollToTop;

    component.componentDidMount();

    jestExpect(setHeaderAndFooter).toBeCalledWith({
      header: 'Search Batches',
      footer: F4
    });

    jestExpect(getBlends).toBeCalled();
    jestExpect(scrollToTop).toBeCalled();
  });

  test('it returns error to redux form when source item not exist', async () => {
    const getProductPromise = jest.fn();
    getProductPromise.mockImplementation((productCode, errorHandler) => {
      return errorHandler();
    });

    const values = { sourceNumber: '123232' };
    const dispatch = jest.fn();

    const errors = await asyncValidate(values, dispatch, { getProductPromise });

    jestExpect(errors).toEqual({
      sourceNumber: 'Invalid Item Number'
    });
  });

  test('it returns error to redux form when finished item item not exist', async () => {
    const getProductPromise = jest.fn();
    getProductPromise.mockImplementation((productCode, errorHandler) => {
      return errorHandler();
    });

    const values = { finishedOrBlend: '123232' };
    const dispatch = jest.fn();

    const errors = await asyncValidate(values, dispatch, {
      getProductPromise,
      blendNames: ['HALAL']
    });

    jestExpect(errors).toEqual({
      finishedOrBlend: 'Invalid product # / blend name'
    });
  });

  test('it not returns error to redux form when blend exist', async () => {
    const getProductPromise = jest.fn();
    getProductPromise.mockRejectedValue({});

    const values = { finishedOrBlend: 'halal' };
    const dispatch = jest.fn();

    const errors = await asyncValidate(values, dispatch, {
      getProductPromise,
      blendNames: ['HALAL']
    });

    jestExpect(errors).toEqual({});
  });

  test('it returns error to for both source and finished', async () => {
    const getProductPromise = jest.fn();
    getProductPromise.mockImplementation((productCode, errorHandler) => {
      return errorHandler();
    });

    const values = { sourceNumber: '123232', finishedOrBlend: '123232' };
    const dispatch = jest.fn();

    const errors = await asyncValidate(values, dispatch, {
      getProductPromise,
      blendNames: ['HALAL']
    });

    jestExpect(errors).toEqual({
      sourceNumber: 'Invalid Item Number',
      finishedOrBlend: 'Invalid product # / blend name'
    });
  });

  test('does not submit the form when form mounts without values', () => {
    const store = createReduxStore({});

    searchBatches.mockImplementation(() => ({ type: 'MOCK_SEARCH_BATCHES' }));

    const dispatchSpy = jest.spyOn(store, 'dispatch');

    mount(
      <Provider store={store}>
        <SearchBatch shouldAsyncValidate={() => false} />
      </Provider>
    );

    jestExpect(dispatchSpy).not.toHaveBeenCalledWith(searchBatches({}));
  });

  test('submits the form on mount to receive fresh search results', () => {
    const store = createReduxStore({});

    searchBatches.mockImplementation(() => ({ type: 'MOCK_SEARCH_BATCHES' }));

    const dispatchSpy = jest.spyOn(store, 'dispatch');

    mount(
      <Provider store={store}>
        <SearchBatch shouldAsyncValidate={() => false} />
      </Provider>
    );

    jestExpect(dispatchSpy).not.toHaveBeenCalledWith(searchBatches({}));
  });

  test('submits the form on mount when form has remembered previous search results', () => {
    const store = createReduxStore({});

    searchBatches.mockImplementation(() => ({ type: 'MOCK_SEARCH_BATCHES' }));

    const dispatchSpy = jest.spyOn(store, 'dispatch');

    const formValues = {
      productionDateStart: '10-09-2018',
      productionDateEnd: '10-09-2018'
    };

    store.dispatch(initialize('searchBatch', formValues));

    mount(
      <Provider store={store}>
        <SearchBatch shouldAsyncValidate={() => false} />
      </Provider>
    );

    jestExpect(searchBatches).toHaveBeenCalledWith(formValues);
    jestExpect(dispatchSpy).toHaveBeenCalledWith(searchBatches(formValues));
  });

  test('does not submit the form when form mounts when start date after end date', () => {
    const store = createReduxStore({});

    searchBatches.mockImplementation(() => ({ type: 'MOCK_SEARCH_BATCHES' }));

    const dispatchSpy = jest.spyOn(store, 'dispatch');

    const wrapper = mount(
      <Provider store={store}>
        <SearchBatch shouldAsyncValidate={() => false} />
      </Provider>
    );

    const searchButton = wrapper.find('button[pid="search-batch-button"]');
    searchButton.simulate('submit');
    jestExpect(dispatchSpy).not.toHaveBeenCalledWith(searchBatches({}));
  });

  describe('componentDidUpdate', () => {
    test('should call "resetBatches" action when invalid = ture', () => {
      const resetBatches = jest.fn();
      const invalid = true;

      const component = new SearchBatchComponent({
        resetBatches,
        invalid
      });

      component.componentDidUpdate();

      jestExpect(resetBatches).toBeCalledTimes(1);
    });

    test('should call "resetBatches" action when invalid = false', () => {
      const resetBatches = jest.fn();
      const invalid = false;

      const component = new SearchBatchComponent({
        resetBatches,
        invalid
      });

      component.componentDidUpdate();

      jestExpect(resetBatches).not.toBeCalled();
    });
  });
});
