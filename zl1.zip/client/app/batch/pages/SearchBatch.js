import React from 'react';
import { Field, reduxForm } from 'redux-form';
import { Button, Divider, Form, Grid } from 'semantic-ui-react';
import FormDayPickerInput from '../../shared/FormDayPickerInput';
import { SEARCH_BATCHES } from '../../shared/components/pageTitles';
import { F4 } from '../../shared/components/pageFooters';
import { bindActionCreators } from 'redux';
import { setHeaderAndFooter } from '../../shared/actions/actions';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import FormElement from '../../shared/FormElement';
import { searchBatches, resetBatches } from '../actions/batchActions';
import { SearchBatchesTable } from '../components/SearchBatchesTable';
import { notFutureDate } from '../../shared/validation/formFieldValidations';
import { getProductPromise } from '../../shared/components/product/actionsDuplicate';
import _ from 'lodash';
import moment from 'moment';
import { getBlends } from '../../requestMeat/actions/meatRequestActions';
import { DEFAULT_DISPLAY_DATE_FORMAT } from '../../shared/util/dateUtil';
import { validate, validateDate } from '../../shared/formValidations';

export const FORM = 'searchBatch';

export class SearchBatchComponent extends React.Component {
  componentDidMount() {
    const { setHeaderAndFooter, getBlends, submit } = this.props;

    setHeaderAndFooter({
      header: SEARCH_BATCHES,
      footer: F4
    });

    this.scrollToTop();

    getBlends();

    submit(FORM);
  }

  scrollToTop() {
    if (this.scrollToTopRef && this.scrollToTopRef.scrollIntoView) {
      this.scrollToTopRef.scrollIntoView({
        behavior: 'smooth',
        block: 'start',
        inline: 'nearest'
      });
    }
  }
  componentDidUpdate() {
    const { invalid, resetBatches } = this.props;
    if (invalid) {
      resetBatches();
    }
  }

  render() {
    const { handleSubmit, batches, submitting, invalid, pristine } = this.props;

    return (
      <div className='page-content batch-search-page' ref={node => (this.scrollToTopRef = node)}>
        <Form size='large' onSubmit={handleSubmit}>
          <Divider hidden className='divider-medium' />
          <Grid relaxed>
            <Grid.Row>
              <Grid.Column width={4}>
                <Field
                  component={FormDayPickerInput}
                  as={Form.Input}
                  name='productionDateStart'
                  label='Production Start Date'
                  formatString={DEFAULT_DISPLAY_DATE_FORMAT}
                  placeholder={DEFAULT_DISPLAY_DATE_FORMAT}
                  dayPickerProps={{
                    showOutsideDays: true,
                    disabledDays: [{ after: new Date() }]
                  }}
                  validate={[notFutureDate]}
                />
              </Grid.Column>
              <Grid.Column width={4}>
                <Field
                  component={FormDayPickerInput}
                  as={Form.Input}
                  name='productionDateEnd'
                  label='Production End Date'
                  formatString={DEFAULT_DISPLAY_DATE_FORMAT}
                  placeholder={DEFAULT_DISPLAY_DATE_FORMAT}
                  dayPickerProps={{
                    showOutsideDays: true,
                    disabledDays: [{ after: new Date() }]
                  }}
                  validate={[notFutureDate]}
                />
              </Grid.Column>
            </Grid.Row>
            <Grid.Row>
              <Grid.Column width={3}>
                <Field
                  component={FormElement}
                  as={Form.Input}
                  name='sourcePurchaseOrderNumber'
                  type='text'
                  label='Source PO #'
                />
              </Grid.Column>
              <Grid.Column width={3}>
                <Field
                  component={FormElement}
                  as={Form.Input}
                  name='sourceNumber'
                  type='text'
                  label='Source #'
                />
              </Grid.Column>

              <Grid.Column width={4}>
                <Field
                  component={FormElement}
                  as={Form.Input}
                  name='finishedOrBlend'
                  type='text'
                  label='Finished # Or Blend'
                />
              </Grid.Column>
            </Grid.Row>
            <Grid.Row>
              <Grid.Column>
                <Button
                  primary
                  size={'large'}
                  pid={'search-batch-button'}
                  type='submit'
                  disabled={submitting || pristine || invalid}
                >
                  Search
                </Button>
              </Grid.Column>
            </Grid.Row>
          </Grid>
        </Form>
        <Divider hidden />

        <SearchBatchesTable batches={batches} />
      </div>
    );
  }
}

SearchBatchComponent.propTypes = {
  setHeaderAndFooter: PropTypes.func,
  handleSubmit: PropTypes.func,
  searchBatches: PropTypes.func,
  batches: PropTypes.array,
  submitting: PropTypes.bool,
  invalid: PropTypes.bool,
  pristine: PropTypes.bool,
  getBlends: PropTypes.func,
  resetBatches: PropTypes.func,
  values: PropTypes.object,
  submit: PropTypes.func
};

const mapStateToProps = state => {
  const { blends } = state.meatRequestInfo;
  const blendNames = _.map(blends, blend => blend.name);

  return {
    batches: state.batches.search.batches,
    blendNames: blendNames
  };
};

export const asyncValidate = (values, dispatch, props) => {
  const sourceNumberPromise = !_.isEmpty(values.sourceNumber)
    ? props.getProductPromise(values.sourceNumber, () => {
        return { sourceNumber: 'Invalid Item Number' };
      })
    : Promise.resolve();

  const finishedOrBlendPromise =
    !_.isEmpty(values.finishedOrBlend) &&
    !_.includes(props.blendNames, values.finishedOrBlend.toUpperCase())
      ? props.getProductPromise(values.finishedOrBlend, () => {
          return { finishedOrBlend: 'Invalid product # / blend name' };
        })
      : Promise.resolve();

  return Promise.all([sourceNumberPromise, finishedOrBlendPromise]).then(data =>
    _.reduce(data, _.merge)
  );
};

const endDateAfterStartDate = values => {
  const { productionDateStart, productionDateEnd } = values;
  let errors = {};

  if (productionDateStart) {
    errors = validate(errors, productionDateStart, 'productionDateStart', [
      validateDate(DEFAULT_DISPLAY_DATE_FORMAT)
    ]);
  }
  if (productionDateEnd) {
    errors = validate(errors, productionDateEnd, 'productionDateEnd', [
      validateDate(DEFAULT_DISPLAY_DATE_FORMAT)
    ]);
  }
  if (
    Object.getOwnPropertyNames(errors).length === 0 &&
    Boolean(productionDateStart) &&
    moment(new Date(productionDateStart)).isAfter(moment(new Date(productionDateEnd)), 'day')
  ) {
    errors.productionDateEnd = 'Must be after start date';
  }
  return errors;
};

const mapDispatchToProps = dispatch =>
  bindActionCreators(
    {
      setHeaderAndFooter,
      searchBatches,
      getProductPromise,
      getBlends,
      resetBatches
    },
    dispatch
  );

const onSubmit = (values, dispatch) => {
  return !_.isEmpty(values) && dispatch(searchBatches(values));
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(
  reduxForm({
    onSubmit,
    destroyOnUnmount: false,
    form: FORM,
    asyncValidate,
    asyncBlurFields: ['sourceNumber', 'finishedOrBlend'],
    validate: endDateAfterStartDate
  })(SearchBatchComponent)
);
