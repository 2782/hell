import { CLEAR_SEARCH_YIELD_MODELS_PAGE } from '../../searchYieldModel/actions/searchYieldModelActionTypes';
import {
  SEARCH_YIELD_MODEL_RESULTS,
  UPDATE_FINISHED_PRODUCT_INFO,
  UPDATE_YIELD_MODEL_PRODUCT_INFO,
  YIELD_MODEL_RECEIVED,
  YIELD_MODEL_REQUESTED
} from '../actions/searchYieldModelActionTypes';

const initialState = {
  finishedProduct: null,
  yieldModels: null,
  productInfoForYieldModels: null,
  pricingModelOfProductGroup: null,
  yieldModelType: null,
  loading: false
};

export default (state = initialState, action) => {
  switch (action.type) {
    case CLEAR_SEARCH_YIELD_MODELS_PAGE:
      return initialState;
    case SEARCH_YIELD_MODEL_RESULTS:
      return {
        ...state,
        yieldModels: action.yieldModelPayload,
        pricingModelOfProductGroup: action.pricingModelPayload,
        yieldModelType: action.yieldModelTypePayload
      };
    case UPDATE_FINISHED_PRODUCT_INFO:
      return {
        ...state,
        finishedProduct: action.finishedProductPayload
      };
    case UPDATE_YIELD_MODEL_PRODUCT_INFO:
      return {
        ...state,
        productInfoForYieldModels: action.productInfoPayload
      };
    case YIELD_MODEL_REQUESTED:
      return {
        ...state,
        loading: true
      };
    case YIELD_MODEL_RECEIVED:
      return {
        ...state,
        loading: false
      };
    default:
      return state;
  }
};
