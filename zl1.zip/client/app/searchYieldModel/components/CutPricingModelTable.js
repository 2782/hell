import React from 'react';
import PropTypes from 'prop-types';
import { toPrecision } from '../../shared/util/floatUtil';
import { Table } from 'semantic-ui-react';
import DotDotDot from 'react-dotdotdot';

const CutPricingModelTable = ({ pricingModel, onSelectYieldModel, newYieldTest }) => {
  return pricingModel && pricingModel.sourceProductDescription ? (
    <div>
      <div className='yield-model-table-title'>Yield Model Group Results</div>
      <Table size='small' selectable>
        <Table.Header>
          <Table.Row>
            <Table.HeaderCell width={3} textAlign={'center'}>
              PRICING MODEL
            </Table.HeaderCell>
            <Table.HeaderCell width={5}>PRIMARY PRODUCT</Table.HeaderCell>
            <Table.HeaderCell width={4}>SOURCE PRODUCT</Table.HeaderCell>
            <Table.HeaderCell width={2} textAlign={'right'}>
              YIELD %
            </Table.HeaderCell>
            <Table.HeaderCell width={2} textAlign={'center'}>
              YIELD TEST
            </Table.HeaderCell>
          </Table.Row>
        </Table.Header>
        <Table.Body>
          <Table.Row onClick={() => onSelectYieldModel(pricingModel, 'cutting')}>
            <Table.Cell
              width={3}
              textAlign={'center'}
              pid={'yield-model-table-group-results__pricing'}
            >
              {<i className='icon-checked' />}
            </Table.Cell>
            <Table.Cell
              width={5}
              pid={'yield-model-table-group-results__finishedProduct'}
              title={`${pricingModel.finishedProductDescription}`}
            >
              <DotDotDot clamp={1}>
                {`${pricingModel.finishedProductCode} ${pricingModel.finishedProductDescription}`}
              </DotDotDot>
            </Table.Cell>
            <Table.Cell
              width={4}
              pid={'yield-model-table-group-results__sourceProduct'}
              title={pricingModel.sourceProductDescription}
            >
              <DotDotDot clamp={1}>
                {`${pricingModel.sourceProductCode} ${pricingModel.sourceProductDescription}`}
              </DotDotDot>
            </Table.Cell>
            <Table.Cell
              width={2}
              textAlign={'right'}
              pid={'yield-model-table-group-results__estimatedYield'}
            >
              {toPrecision(pricingModel.estimatedYield, 2)}
            </Table.Cell>
            <Table.Cell
              width={2}
              textAlign={'center'}
              className={'new-yield-test'}
              onClick={e => {
                e.stopPropagation();
                newYieldTest(pricingModel);
              }}
            >
              <i className='icon-add' />
            </Table.Cell>
          </Table.Row>
        </Table.Body>
      </Table>
    </div>
  ) : null;
};

CutPricingModelTable.propTypes = {
  pricingModel: PropTypes.shape({
    sourceProductDescription: PropTypes.string,
    finishedProductDescription: PropTypes.string,
    finishedProductCode: PropTypes.string,
    estimatedYield: PropTypes.string.isRequired
  }),
  onSelectYieldModel: PropTypes.func,
  newYieldTest: PropTypes.func
};

export default CutPricingModelTable;
