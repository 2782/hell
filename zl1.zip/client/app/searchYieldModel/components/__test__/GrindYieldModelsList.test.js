import React from 'react';
import GrindYieldModelsList from '../GrindYieldModelsList';
import { Table } from 'semantic-ui-react';
import { grindYieldModels } from '../../../shared/testData/yieldModel';
import semanticUI from '../../../../test-helpers/semantic-ui';

jest.mock('../../../shared/errors/ErrorNotification');

describe('GrindYieldModelsList', () => {
  let wrapper;
  const onSelectYieldModel = jest.fn();

  describe('render correct component for grinding yield model', () => {
    grindYieldModels[0].grindYieldModelSourceProductDescriptions = ['0078891 desc for 0078891'];
    grindYieldModels[1].grindYieldModelSourceProductDescriptions = ['0078892 desc for 0078892'];

    beforeEach(() => {
      wrapper = mount(
        <GrindYieldModelsList
          yieldModelResult={grindYieldModels}
          onSelectYieldModel={onSelectYieldModel}
        />
      );
    });

    test('should render title', () => {
      const tableTitle = wrapper.find('.yield-model-table-title');

      jestExpect(tableTitle).toHaveText('Blend Results');
    });

    test('should render header', () => {
      const wrapperHeader = semanticUI.findTable(wrapper, 0).find('th');

      jestExpect(wrapperHeader.at(0)).toHaveText('PRICING MODEL');
      jestExpect(wrapperHeader.at(1)).toHaveText('BLEND');
      jestExpect(wrapperHeader.at(2)).toHaveText('SOURCE PRODUCT');
    });

    test('should render correct component content', () => {
      const yieldModelListRows = wrapper.find(Table.Body).find(Table.Row);

      jestExpect(yieldModelListRows.length).toEqual(2);
      jestExpect(
        yieldModelListRows
          .at(0)
          .find(Table.Cell)
          .at(0)
          .find('.icon-checked')
      ).not.toExist();
      jestExpect(
        yieldModelListRows
          .at(0)
          .find(Table.Cell)
          .at(1)
      ).toHaveText('Natural');
      jestExpect(
        yieldModelListRows
          .at(0)
          .find(Table.Cell)
          .at(2)
          .find('div')
          .props().children
      ).toEqual('0078891 desc for 0078891');

      jestExpect(
        yieldModelListRows
          .at(1)
          .find(Table.Cell)
          .at(0)
          .find('.icon-checked')
      ).toExist();
      jestExpect(
        yieldModelListRows
          .at(1)
          .find(Table.Cell)
          .at(1)
      ).toHaveText('BLEND1004 - NATURAL');
      jestExpect(
        yieldModelListRows
          .at(1)
          .find(Table.Cell)
          .at(2)
          .find('div')
      ).toHaveText('0078892 desc for 0078892');
    });

    test('should call click method when click on table row', () => {
      wrapper
        .find(Table.Body)
        .find(Table.Row)
        .at(0)
        .simulate('click');

      jestExpect(onSelectYieldModel).toHaveBeenCalledTimes(1);
    });
  });
});
