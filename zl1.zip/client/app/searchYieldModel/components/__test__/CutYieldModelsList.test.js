import React from 'react';
import { shallow } from 'enzyme';
import CutYieldModelsList from '../CutYieldModelsList';
import { Table } from 'semantic-ui-react';

jest.mock('../../../shared/errors/ErrorNotification');

describe('cutYieldModelsList', () => {
  let wrapper;
  const yieldModelResult = [
    {
      id: 12,
      pricingModel: false,
      sourceProductCode: '0078891',
      sourceProductDescription: 'desc for 0078891',
      estimatedYield: 13
    },
    {
      id: 11,
      pricingModel: true,
      sourceProductCode: '0078892',
      sourceProductDescription: 'desc for 0078892',
      estimatedYield: 34.1
    },
    {
      id: 10,
      pricingModel: false,
      sourceProductCode: '0078893',
      sourceProductDescription: 'desc for 0078893',
      estimatedYield: 26.4
    }
  ];

  const onSelectYieldModel = jest.fn();

  test('should not render anything when yield model result is null', () => {
    wrapper = shallow(
      <CutYieldModelsList
        yieldModelResult={null}
        onSelectYieldModel={onSelectYieldModel}
        newYieldTest={() => {}}
      />
    );

    jestExpect(wrapper.find(Table).exists()).toEqual(false);
  });

  test('should not render anything when yield model result length is 0', () => {
    wrapper = shallow(
      <CutYieldModelsList
        yieldModelResult={[]}
        onSelectYieldModel={onSelectYieldModel}
        newYieldTest={() => {}}
      />
    );

    jestExpect(wrapper.find(Table).exists()).toEqual(false);
  });

  describe('render correct component for cutting yield model', () => {
    beforeEach(() => {
      wrapper = shallow(
        <CutYieldModelsList
          yieldModelResult={yieldModelResult}
          onSelectYieldModel={onSelectYieldModel}
          newYieldTest={() => {}}
        />
      );
    });

    test('should render title', () => {
      const tableTitle = wrapper.find('.yield-model-table-title').text();

      jestExpect(tableTitle).toEqual('Finished Product Results');
    });

    test('should render header', () => {
      const wrapperHeader = wrapper.find(Table.Header).html();

      jestExpect(wrapperHeader).toEqual(jestExpect.stringContaining('PRICING MODEL'));
      jestExpect(wrapperHeader).toEqual(jestExpect.stringContaining('SOURCE PRODUCT'));
      jestExpect(wrapperHeader).toEqual(jestExpect.stringContaining('YIELD %'));
      jestExpect(wrapperHeader).toEqual(jestExpect.stringContaining('YIELD TEST'));
    });

    test('should render correct component content', () => {
      const yieldModelListRows = wrapper.find(Table.Body).find(Table.Row);

      jestExpect(yieldModelListRows.length).toEqual(3);
      jestExpect(
        yieldModelListRows
          .at(0)
          .find(Table.Cell)
          .at(0)
          .find('.icon-checked')
          .exists()
      ).toEqual(false);
      jestExpect(
        yieldModelListRows
          .at(0)
          .find(Table.Cell)
          .at(1)
          .props().children
      ).toEqual('0078891 desc for 0078891');
      jestExpect(
        yieldModelListRows
          .at(0)
          .find(Table.Cell)
          .at(2)
          .props().children
      ).toEqual(13);
      jestExpect(
        yieldModelListRows
          .at(0)
          .find(Table.Cell)
          .at(3)
          .find('i.icon-add')
          .exists()
      ).toEqual(true);
      jestExpect(
        yieldModelListRows
          .at(1)
          .find(Table.Cell)
          .at(0)
          .find('.icon-checked')
          .exists()
      ).toEqual(true);
      jestExpect(
        yieldModelListRows
          .at(1)
          .find(Table.Cell)
          .at(1)
          .props().children
      ).toEqual('0078892 desc for 0078892');
      jestExpect(
        yieldModelListRows
          .at(1)
          .find(Table.Cell)
          .at(2)
          .props().children
      ).toEqual(34.1);
      jestExpect(
        yieldModelListRows
          .at(1)
          .find(Table.Cell)
          .at(3)
          .find('i.icon-add')
          .exists()
      ).toEqual(true);
    });

    test('should call click method when click on table row', () => {
      wrapper
        .find(Table.Body)
        .find(Table.Row)
        .at(0)
        .simulate('click');

      jestExpect(onSelectYieldModel).toHaveBeenCalled();
    });
  });
});
