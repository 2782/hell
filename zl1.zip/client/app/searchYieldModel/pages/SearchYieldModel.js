import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import _ from 'lodash';
import ProductDuplicate from '../../shared/components/product/ProductDuplicate';
import CutYieldModelsList from '../components/CutYieldModelsList';
import { changePath, setHeaderAndFooter } from '../../shared/actions/actions';
import {
  clearSearchYieldModelsPage,
  searchYieldModelsByBlend,
  searchYieldModelsByFinishedProductCode,
  receiveYieldModels,
  requestYieldModels
} from '../actions/searchYieldModelActions';
import { SEARCH_YIELD_MODELS } from '../../shared/components/pageTitles';
import {
  clearYieldModelInfo,
  updateCuttingYieldModelInfo
} from '../../createYieldModel/actions/cuttingYieldModelActions';
import { SEARCH_YIELD_MODELS_FOOTER } from '../../shared/components/pageFooters';
import { Field, reduxForm, SubmissionError } from 'redux-form';
import { Button, Divider, Form, Grid, Loader } from 'semantic-ui-react';
import CutPricingModelTable from '../components/CutPricingModelTable';
import GrindPricingModelTable from '../components/GrindPricingModelTable';
import EmptyTableMessage from '../../shared/components/EmptyTableMessage';
import { changeYieldModelType } from '../../createYieldModel/actions/yieldModelActions';
import { updateGrindingYieldModelInfo } from '../../createYieldModel/actions/grindingYieldModelActions';
import GrindYieldModelsList from '../components/GrindYieldModelsList';
import { newYieldTest } from '../../yieldTest/actions/yieldTestActions';

class SearchYieldModel extends Component {
  constructor(props) {
    super(props);
    this.switchToYieldModelPage = this.switchToYieldModelPage.bind(this);
    this.newYieldTest = this.newYieldTest.bind(this);
  }

  componentDidMount() {
    this.props.setHeaderAndFooter({
      header: SEARCH_YIELD_MODELS,
      footer: SEARCH_YIELD_MODELS_FOOTER
    });
  }

  componentWillUnmount() {
    this.props.clearSearchYieldModelsPage();
  }

  switchToYieldModelPage(yieldModel, yieldModelType) {
    const {
      updateCuttingYieldModelInfo,
      updateGrindingYieldModelInfo,
      changeYieldModelType
    } = this.props;

    changeYieldModelType(yieldModelType);
    if (yieldModelType === 'cutting') {
      updateCuttingYieldModelInfo(yieldModel);
    } else {
      updateGrindingYieldModelInfo(yieldModel);
    }

    this.toYieldModelPage();
  }

  toYieldModelPage() {
    this.props.changePath('/yield-model/create');
  }

  newYieldTest(yieldModel) {
    this.props.newYieldTest(yieldModel);
    this.props.changePath('/yield-test');
  }

  toCreateYieldModelPage() {
    this.props.clearYieldModelInfo();
    this.toYieldModelPage();
  }

  submit(values) {
    const {
      searchYieldModelsByFinishedProductCode,
      searchYieldModelsByBlend,
      requestYieldModels,
      receiveYieldModels
    } = this.props;

    if (values.finishedProductCodeOrBlend) {
      const finishedProductCodeOrBlend = values.finishedProductCodeOrBlend.trim().toUpperCase();
      requestYieldModels();
      return searchYieldModelsByFinishedProductCode(finishedProductCodeOrBlend, () => {
        return searchYieldModelsByBlend(finishedProductCodeOrBlend, () => {
          receiveYieldModels();
          throw new SubmissionError({
            _error: 'Submission Failed!',
            finishedProductCodeOrBlend: 'Invalid product # / blend name'
          });
        });
      });
    }
  }

  shouldRenderTables() {
    const { pricingModel, yieldModelResult } = this.props;
    return (
      (pricingModel &&
        (pricingModel.sourceProductDescription ||
          pricingModel.grindYieldModelSourceProductDescriptions)) ||
      (yieldModelResult && yieldModelResult.length > 0)
    );
  }

  renderPricingModelTable() {
    const { pricingModel } = this.props;

    const isCutPricingModel = pricingModel && pricingModel.finishedProductCode;
    const isGrindingPricingModel =
      pricingModel && pricingModel.grindYieldModelSourceProductDescriptions;

    return isCutPricingModel || isGrindingPricingModel ? (
      <Grid.Row>
        <Grid.Column width={16}>
          {isCutPricingModel ? (
            <CutPricingModelTable
              pricingModel={pricingModel}
              onSelectYieldModel={this.switchToYieldModelPage}
              newYieldTest={this.newYieldTest}
            />
          ) : (
            <GrindPricingModelTable
              pricingModel={pricingModel}
              onSelectYieldModel={this.switchToYieldModelPage}
            />
          )}
        </Grid.Column>
      </Grid.Row>
    ) : null;
  }

  renderYieldModelList() {
    const { yieldModelResult, yieldModelType } = this.props;

    return (
      <Grid.Row>
        <Grid.Column width={16}>
          {yieldModelType === 'cutting' ? (
            <CutYieldModelsList
              yieldModelResult={yieldModelResult}
              onSelectYieldModel={this.switchToYieldModelPage}
              newYieldTest={this.newYieldTest}
            />
          ) : (
            <GrindYieldModelsList
              yieldModelResult={yieldModelResult}
              onSelectYieldModel={this.switchToYieldModelPage}
            />
          )}
        </Grid.Column>
      </Grid.Row>
    );
  }

  render() {
    const {
      yieldModelResult,
      finishedProductInfo,
      pricingModel,
      handleSubmit,
      loading
    } = this.props;
    let tableContent = (
      <EmptyTableMessage className={'prime-list-empty-message'} message={'No results found'} />
    );

    let loadingContent = null;
    if (loading) {
      loadingContent = <Loader size='large' active inline='centered' />;
    }

    if (_.isNull(pricingModel) && _.isNull(yieldModelResult)) {
      tableContent = null;
    }

    if (this.shouldRenderTables()) {
      tableContent = (
        <Grid>
          {this.renderPricingModelTable()}
          {this.renderYieldModelList()}
        </Grid>
      );
    }

    return (
      <div className='page-content search-yield-model-page'>
        <Grid>
          <Grid.Row>
            <Grid.Column width={13}>
              <Form
                pid='search-yield-model-form'
                size={'large'}
                onSubmit={handleSubmit(this.submit.bind(this))}
              >
                <Field
                  autoFocus={true}
                  component={ProductDuplicate}
                  name='finishedProductCodeOrBlend'
                  pid='finish-product-code-or-blend'
                  namespace={'searchYieldModel-productCode'}
                  label='FINISHED PRODUCT # OR BLEND'
                  product={finishedProductInfo || {}}
                  onChange={this.props.clearSearchYieldModelsPage.bind(this)}
                />
              </Form>
            </Grid.Column>
            <Grid.Column width={3}>
              <Button
                primary
                size={'large'}
                className={'create-yield-model'}
                onClick={this.toCreateYieldModelPage.bind(this)}
              >
                New
              </Button>
            </Grid.Column>
          </Grid.Row>
        </Grid>

        <Divider hidden />
        {loadingContent}
        {tableContent}
      </div>
    );
  }
}

SearchYieldModel.propTypes = {
  setHeaderAndFooter: PropTypes.func,
  searchYieldModelsByFinishedProductCode: PropTypes.func,
  searchYieldModelsByBlend: PropTypes.func,
  updateCuttingYieldModelInfo: PropTypes.func,
  updateGrindingYieldModelInfo: PropTypes.func,
  changeYieldModelType: PropTypes.func,
  finishedProductInfo: PropTypes.object,
  clearSearchYieldModelsPage: PropTypes.func,
  yieldModelResult: PropTypes.array,
  pricingModel: PropTypes.object,
  changePath: PropTypes.func,
  handleSubmit: PropTypes.func,
  yieldModelType: PropTypes.string,
  clearYieldModelInfo: PropTypes.func,
  newYieldTest: PropTypes.func,
  loading: PropTypes.bool,
  requestYieldModels: PropTypes.func,
  receiveYieldModels: PropTypes.func
};

const getGrindYieldModelSourceProductDescriptions = (yieldModel, products) => {
  if (!_.isNull(yieldModel.blend) && !_.isEmpty(yieldModel.sourceProducts)) {
    return _.map(yieldModel.sourceProducts, sourceProduct => {
      return `${sourceProduct.code} ${_.get(products, sourceProduct.code, '')}`;
    });
  }
  return null;
};

const generateYieldModelResult = (yieldModels, products) => {
  if (_.isNull(yieldModels) || _.isNull(products)) {
    return null;
  }

  return _(yieldModels)
    .map(yieldModel => {
      return {
        ...yieldModel,
        sourceProductDescription: _.get(products, `${yieldModel.sourceProductCode}`, ''),
        grindYieldModelSourceProductDescriptions: getGrindYieldModelSourceProductDescriptions(
          yieldModel,
          products
        )
      };
    })
    .sortBy('sourceProductCode')
    .value();
};

const generatePricingModelResult = (pricingModel, products) => {
  if (_.isNull(pricingModel) || _.isNull(products)) {
    return null;
  }

  return {
    ...pricingModel,
    sourceProductDescription: _.get(products, `${pricingModel.sourceProductCode}`, ''),
    finishedProductDescription: _.get(products, `${pricingModel.finishedProductCode}`, ''),
    grindYieldModelSourceProductDescriptions: getGrindYieldModelSourceProductDescriptions(
      pricingModel,
      products
    )
  };
};

const mapStateToProps = state => ({
  initialValues: {
    finishedProductCodeOrBlend: _.get(state, 'searchYieldModels.finishedProduct.code', '')
  },
  finishedProductInfo: state.searchYieldModels.finishedProduct,
  loading: state.searchYieldModels.loading,
  yieldModelResult: generateYieldModelResult(
    state.searchYieldModels.yieldModels,
    state.searchYieldModels.productInfoForYieldModels
  ),
  pricingModel: generatePricingModelResult(
    state.searchYieldModels.pricingModelOfProductGroup,
    state.searchYieldModels.productInfoForYieldModels
  ),
  yieldModelType: state.searchYieldModels.yieldModelType
});

const mapDispatchToProps = dispatch =>
  bindActionCreators(
    {
      updateCuttingYieldModelInfo,
      updateGrindingYieldModelInfo,
      changePath,
      clearSearchYieldModelsPage,
      setHeaderAndFooter,
      searchYieldModelsByFinishedProductCode,
      searchYieldModelsByBlend,
      changeYieldModelType,
      clearYieldModelInfo,
      newYieldTest,
      requestYieldModels,
      receiveYieldModels
    },
    dispatch
  );

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(
  reduxForm({
    form: 'searchYieldModel',
    enableReinitialize: true
  })(SearchYieldModel)
);
