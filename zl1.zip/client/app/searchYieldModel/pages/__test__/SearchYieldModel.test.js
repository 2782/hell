import yieldModelResources from '../../../shared/api/yieldModelResources';
import {
  CUTTING_YIELD_MODEL_CLEARED,
  UPDATE_YIELD_MODEL as UPDATE_CUT_YIELD_MODEL
} from '../../../createYieldModel/actions/cuttingYieldModelActionTypes';
import { UPDATE_YIELD_MODEL as UPDATE_GRIND_YIELD_MODEL } from '../../../createYieldModel/actions/grindingYieldModelActionTypes';
import React from 'react';
import thunk from 'redux-thunk';
import { mount } from 'enzyme';
import { Provider } from 'react-redux';
import configureStore from 'redux-mock-store';
import CutYieldModelsList from '../../components/CutYieldModelsList';
import SearchYieldModel from '../SearchYieldModel';
import { createReduxStore } from '../../../store';
import { push } from 'react-router-redux';
import CutPricingModelTable from '../../components/CutPricingModelTable';
import YieldModelFactory from '../../../../test-factories/yieldModel';
import productFactory from '../../../../test-factories/productFactory';
import EmptyTableMessage from '../../../shared/components/EmptyTableMessage';
import { grindYieldModels } from '../../../shared/testData/yieldModel';
import { CHANGE_YIELD_MODEL_TYPE } from '../../../createYieldModel/actions/yieldModelActionTypes';
import productResources from '../../../shared/api/productResources';
import GrindYieldModelsList from '../../components/GrindYieldModelsList';
import { NEW_YIELD_TEST } from '../../../yieldTest/actions/yieldTestActionTypes';

jest.mock('../../../shared/components/Header');
jest.mock('../../../shared/errors/ErrorNotification');
jest.mock('../../../shared/api/productResources');
jest.mock('../../../shared/api/yieldModelResources');

const createStore = configureStore([thunk]);
const pricingModel = YieldModelFactory.build({
  finishedProductCode: '0068205',
  sourceProductCode: '0078891'
});
const yieldModel1 = YieldModelFactory.build({ sourceProductCode: '0078891' });
const yieldModel2 = YieldModelFactory.build({ sourceProductCode: '0078892' });
const finishedProduct = productFactory.build({ code: '0078889' });

describe('search yield model page', () => {
  let wrapper, mockStore;

  beforeEach(() => {
    mockStore = createStore({
      searchYieldModels: {
        finishedProduct: finishedProduct,
        yieldModelResult: [],
        pricingModelOfProductGroup: {},
        productInfoForYieldModels: null
      }
    });

    wrapper = mount(
      <Provider store={mockStore}>
        <SearchYieldModel />
      </Provider>
    );
  });

  describe('initial component for cutting yield model', () => {
    beforeEach(() => {
      mockStore = createStore({
        router: { location: { pathname: '/yield-model' } },
        searchYieldModels: {
          finishedProduct: finishedProduct,
          yieldModels: [yieldModel1, yieldModel2],
          productInfoForYieldModels: {
            '0078891': 'source product desc',
            '0068205': 'finished product desc'
          },
          pricingModelOfProductGroup: pricingModel,
          yieldModelType: 'cutting'
        }
      });

      wrapper = mount(
        <Provider store={mockStore}>
          <SearchYieldModel />
        </Provider>
      );
    });

    test('generate yield model list and sort by sourceProductCode', () => {
      jestExpect(wrapper.find(CutYieldModelsList).prop('yieldModelResult')).toEqual([
        {
          ...yieldModel1,
          sourceProductDescription: 'source product desc',
          grindYieldModelSourceProductDescriptions: null
        },
        {
          ...yieldModel2,
          sourceProductDescription: '',
          grindYieldModelSourceProductDescriptions: null
        }
      ]);
    });

    test('init pricing model of product group', () => {
      jestExpect(wrapper.find(CutPricingModelTable).prop('pricingModel')).toEqual({
        ...pricingModel,
        sourceProductDescription: 'source product desc',
        finishedProductDescription: 'finished product desc',
        grindYieldModelSourceProductDescriptions: null
      });
    });

    test('should render create yield model button there', () => {
      jestExpect(wrapper.find('button.create-yield-model').exists()).toEqual(true);
    });

    test('should change path to "/yield-model/create" when click new button', () => {
      mockStore.clearActions();

      wrapper.find('button.create-yield-model').simulate('click');

      const actions = mockStore.getActions();
      jestExpect(actions[0]).toEqual({
        type: CUTTING_YIELD_MODEL_CLEARED
      });
      jestExpect(actions[1]).toEqual(push('/yield-model/create'));
    });
  });

  describe('initial component for grinding yield model', () => {
    beforeEach(() => {
      mockStore = createStore({
        searchYieldModels: {
          yieldModels: grindYieldModels,
          productInfoForYieldModels: {
            '0078891': 'source product desc',
            '0068205': 'finished product desc'
          },
          pricingModelOfProductGroup: null,
          yieldModelType: 'grinding'
        }
      });

      wrapper = mount(
        <Provider store={mockStore}>
          <SearchYieldModel />
        </Provider>
      );
    });

    test('generate yield model list', () => {
      jestExpect(wrapper.find(GrindYieldModelsList).prop('yieldModelResult')).toEqual([
        {
          ...grindYieldModels[0],
          sourceProductDescription: '',
          grindYieldModelSourceProductDescriptions: [
            '0078891 source product desc',
            '0078891 source product desc'
          ]
        },
        {
          ...grindYieldModels[1],
          sourceProductDescription: '',
          grindYieldModelSourceProductDescriptions: ['0078891 source product desc']
        }
      ]);
    });
  });

  describe('switch to yield model page', () => {
    test('should switch to cutting yield model page when call switchToYieldModelPage()', () => {
      mockStore.clearActions();
      wrapper
        .find('SearchYieldModel')
        .instance()
        .switchToYieldModelPage(pricingModel, 'cutting');

      const actions = mockStore.getActions();

      jestExpect(actions[0]).toEqual({
        type: CHANGE_YIELD_MODEL_TYPE,
        payload: 'cutting'
      });
      jestExpect(actions[1]).toEqual({
        type: UPDATE_CUT_YIELD_MODEL,
        payload: pricingModel
      });
      jestExpect(actions[2]).toEqual(push('/yield-model/create'));
    });

    test('should switch to grinding yield model page when call switchToYieldModelPage()', () => {
      mockStore.clearActions();
      wrapper
        .find('SearchYieldModel')
        .instance()
        .switchToYieldModelPage(grindYieldModels[0], 'grinding');

      const actions = mockStore.getActions();

      const expectedYieldModel = grindYieldModels[0];

      jestExpect(actions[0]).toEqual({
        type: CHANGE_YIELD_MODEL_TYPE,
        payload: 'grinding'
      });
      jestExpect(actions[1]).toEqual({
        type: UPDATE_GRIND_YIELD_MODEL,
        payload: expectedYieldModel
      });
      jestExpect(actions[2]).toEqual(push('/yield-model/create'));
    });
  });

  describe('yield test', () => {
    test('should switch to new yield test page when call newYieldTest', () => {
      mockStore.clearActions();
      wrapper
        .find('SearchYieldModel')
        .instance()
        .newYieldTest(pricingModel);

      const actions = mockStore.getActions();

      jestExpect(actions[0]).toEqual({
        type: NEW_YIELD_TEST,
        payload: pricingModel
      });
      jestExpect(actions[1]).toEqual(push('/yield-test'));
    });
  });

  describe('get yield model result', () => {
    beforeEach(() => {
      const store = createReduxStore({
        searchYieldModels: {
          pricingModelOfProductGroup: pricingModel,
          yieldModels: [yieldModel1, yieldModel2],
          productInfoForYieldModels: {
            '0078891': '0078891 source product desc',
            '0078892': '0078891 source product desc',
            '0068205': 'finished product desc'
          },
          finishedProduct: { code: '0078889' },
          yieldModelType: 'cutting'
        }
      });

      wrapper = mount(
        <Provider store={store}>
          <SearchYieldModel />
        </Provider>
      );
    });

    test('should show search result when submit after product code input', () => {
      jestExpect(wrapper.find(CutYieldModelsList).exists()).toEqual(true);
      jestExpect(wrapper.find(CutPricingModelTable).exists()).toEqual(true);
    });
  });

  describe('show empty message', () => {
    beforeEach(() => {
      const store = createReduxStore({
        searchYieldModels: {
          pricingModelOfProductGroup: {},
          yieldModels: [],
          productInfoForYieldModels: [],
          finishedProduct: { code: '0078889' }
        }
      });

      wrapper = mount(
        <Provider store={store}>
          <SearchYieldModel />
        </Provider>
      );
    });

    test('should show search result when submit after product code input', () => {
      jestExpect(wrapper.find(CutYieldModelsList).exists()).toEqual(false);
      jestExpect(wrapper.find(CutPricingModelTable).exists()).toEqual(false);
      jestExpect(wrapper.find(EmptyTableMessage).exists()).toEqual(true);
    });
  });

  describe('finished product code or blend invalid', () => {
    beforeEach(() => {
      const store = createReduxStore({
        searchYieldModels: {
          pricingModelOfProductGroup: null,
          yieldModels: [],
          productInfoForYieldModels: {},
          finishedProduct: { code: '0078889' },
          yieldModelType: null
        }
      });

      wrapper = mount(
        <Provider store={store}>
          <SearchYieldModel />
        </Provider>
      );
    });

    afterEach(() => {
      productResources.getProductInfoPromise.mockReset();
      yieldModelResources.searchYieldModelsByBlend.mockReset();
    });

    test('should show error when input finished product code or blend no exist', async () => {
      productResources.getProductInfoPromise.mockRejectedValue({});
      yieldModelResources.searchYieldModelsByFinishedProductCode.mockRejectedValue({});
      yieldModelResources.searchYieldModelsByBlend.mockImplementation(() => Promise.reject({}));

      wrapper.find('form').simulate('submit');
      await waitForAsyncTasks();
      wrapper = wrapper.update();

      jestExpect(wrapper.find('.pointing').text()).toEqual('Invalid product # / blend name');
    });
  });
});
