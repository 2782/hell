import {
  clearSearchYieldModelsPage,
  searchYieldModelsByBlend,
  searchYieldModelsByFinishedProductCode
} from '../searchYieldModelActions';
import _ from 'lodash';
import {
  CLEAR_SEARCH_YIELD_MODELS_PAGE,
  SEARCH_YIELD_MODEL_RESULTS,
  UPDATE_FINISHED_PRODUCT_INFO,
  UPDATE_YIELD_MODEL_PRODUCT_INFO,
  YIELD_MODEL_RECEIVED
} from '../searchYieldModelActionTypes';
import yieldModelResources from '../../../shared/api/yieldModelResources';
import { productInfo1, productInfo2 } from '../../../shared/testData/product';
import { grindYieldModel, grindYieldModels } from '../../../shared/testData/yieldModel';
import productResources from '../../../shared/api/productResources';
import CuttingYieldModelFactory from '../../../../test-factories/cuttingYieldModel';
import { transformCuttingYieldModelNumerics } from '../../../createYieldModel/actions/cuttingYieldModelActions';

jest.mock('../../../shared/api/yieldModelResources');
jest.mock('../../../shared/api/productResources');

describe('searchYieldModelActions', () => {
  let dispatch, yieldModel, yieldModels;

  beforeEach(() => {
    yieldModel = CuttingYieldModelFactory.build({});
    yieldModels = [
      CuttingYieldModelFactory.build({ code: '4545454' }),
      CuttingYieldModelFactory.build({ code: '5454545' })
    ];
    dispatch = jest.fn();
  });

  describe('clear Search Yield Models Page', () => {
    test('should dispatch CLEAR_SEARCH_YIELD_MODELS_PAGE', () => {
      clearSearchYieldModelsPage()(dispatch);

      jestExpect(dispatch).toBeCalledWith({
        type: CLEAR_SEARCH_YIELD_MODELS_PAGE
      });
    });
  });

  describe('search cutting yield model', () => {
    afterEach(() => {
      yieldModelResources.searchYieldModelsByFinishedProductCode.mockReset();
      productResources.getProductInfoPromise.mockReset();
      productResources.getProductInfoByProductCodesPromise.mockReset();
    });

    test('should get related yield models and pricing model of the primary product in the product group', async () => {
      productResources.getProductInfoPromise.mockResolvedValue({ data: productInfo1 });
      yieldModelResources.searchYieldModelsByFinishedProductCode.mockResolvedValue({
        data: {
          finishedProductResults: yieldModels,
          yieldModelGroupResult: yieldModel
        }
      });
      productResources.getProductInfoByProductCodesPromise.mockResolvedValue({
        data: [productInfo2]
      });

      await searchYieldModelsByFinishedProductCode('0078889')(dispatch);

      jestExpect(dispatch).toHaveBeenNthCalledWith(1, {
        type: UPDATE_FINISHED_PRODUCT_INFO,
        finishedProductPayload: productInfo1
      });
      jestExpect(dispatch).toHaveBeenNthCalledWith(2, {
        type: SEARCH_YIELD_MODEL_RESULTS,
        yieldModelPayload: _.map(yieldModels, transformCuttingYieldModelNumerics),
        pricingModelPayload: transformCuttingYieldModelNumerics(yieldModel),
        yieldModelTypePayload: 'cutting'
      });
      jestExpect(dispatch).toHaveBeenNthCalledWith(4, {
        type: UPDATE_YIELD_MODEL_PRODUCT_INFO,
        productInfoPayload: { '0078891': 'QB, PRIME T-BONE STEAK 206' }
      });
      jestExpect(dispatch).toHaveBeenNthCalledWith(3, {
        type: YIELD_MODEL_RECEIVED
      });
    });

    test('should get empty', async () => {
      productResources.getProductInfoPromise.mockResolvedValue({ data: null });
      yieldModelResources.searchYieldModelsByFinishedProductCode.mockResolvedValue({
        data: {
          finishedProductResults: null,
          yieldModelGroupResult: null
        }
      });
      productResources.getProductInfoByProductCodesPromise.mockResolvedValue({ data: null });

      await searchYieldModelsByFinishedProductCode('0078889')(dispatch);

      jestExpect(dispatch).toBeCalledWith({
        type: UPDATE_FINISHED_PRODUCT_INFO,
        finishedProductPayload: {}
      });
      jestExpect(dispatch).toBeCalledWith({
        type: SEARCH_YIELD_MODEL_RESULTS,
        yieldModelPayload: [],
        pricingModelPayload: {},
        yieldModelTypePayload: 'cutting'
      });
      jestExpect(dispatch).toBeCalledWith({
        type: UPDATE_YIELD_MODEL_PRODUCT_INFO,
        productInfoPayload: {}
      });
    });
  });

  describe('search grinding yield model', () => {
    afterEach(() => {
      yieldModelResources.searchYieldModelsByBlend.mockReset();
      productResources.getProductInfoByProductCodes.mockReset();
    });

    test('should get related grinding yield models and pricing model of the blend', async () => {
      yieldModelResources.searchYieldModelsByBlend.mockResolvedValue({
        data: {
          grindingYieldModelResults: grindYieldModels
        }
      });

      productResources.getProductInfoByProductCodesPromise.mockResolvedValue({
        data: [productInfo2]
      });

      await searchYieldModelsByBlend('Natural')(dispatch);

      jestExpect(dispatch).toBeCalledWith({
        type: SEARCH_YIELD_MODEL_RESULTS,
        yieldModelPayload: grindYieldModels,
        pricingModelPayload: null,
        yieldModelTypePayload: 'grinding'
      });
      jestExpect(dispatch).toBeCalledWith({
        type: UPDATE_YIELD_MODEL_PRODUCT_INFO,
        productInfoPayload: { '0078891': 'QB, PRIME T-BONE STEAK 206' }
      });
    });
  });

  test('should get related pricing yield model of the product in the grinding product group', async () => {
    productResources.getProductInfoPromise.mockResolvedValue({ data: productInfo1 });
    yieldModelResources.searchYieldModelsByFinishedProductCode.mockResolvedValue({
      data: {
        grindingYieldModelGroupResult: grindYieldModel
      }
    });
    productResources.getProductInfoByProductCodesPromise.mockResolvedValue({
      data: [productInfo2]
    });

    await searchYieldModelsByFinishedProductCode('0078889')(dispatch);

    jestExpect(dispatch).toBeCalledWith({
      type: UPDATE_FINISHED_PRODUCT_INFO,
      finishedProductPayload: productInfo1
    });
    jestExpect(dispatch).toBeCalledWith({
      type: SEARCH_YIELD_MODEL_RESULTS,
      yieldModelPayload: [],
      pricingModelPayload: grindYieldModel,
      yieldModelTypePayload: 'cutting'
    });
    jestExpect(dispatch).toBeCalledWith({
      type: UPDATE_YIELD_MODEL_PRODUCT_INFO,
      productInfoPayload: { '0078891': 'QB, PRIME T-BONE STEAK 206' }
    });
  });
});
