export const CLEAR_SEARCH_YIELD_MODELS_PAGE = 'yieldModel/clearPage';
export const SEARCH_YIELD_MODEL_RESULTS = 'yieldModels/search';
export const UPDATE_FINISHED_PRODUCT_INFO = 'yieldModels/updateFinishedProductInfo';
export const UPDATE_YIELD_MODEL_PRODUCT_INFO = 'yieldModels/updateYieldModelProductInfo';
export const YIELD_MODEL_RECEIVED = 'yieldModels/yieldModelReceived';
export const YIELD_MODEL_REQUESTED = 'yieldModels/yieldModelRequested';
