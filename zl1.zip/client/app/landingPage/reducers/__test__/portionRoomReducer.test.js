import portionRoomReducer, { PortionRoomState } from '../portionRoomReducer';
import {
  CANNOT_CLOSE_PORTION_ROOM,
  CLOSE_PORTION_ROOM,
  OPEN_PORTION_ROOM,
  RESET_CURRENT_PORTION_ROOM,
  UPDATE_CURRENT_PORTION_ROOM,
  UPDATE_PORTION_ROOMS,
  USER_DISMISSED_CLOSE_WARNING
} from '../../actions/landingPageActionTypes';
import portionRoomFactory from '../../../../test-factories/portionRoomFactory';
import {
  GRINDING_ORDERS_APPROVED,
  GRINDING_ORDERS_NOT_APPROVED,
  STOCK_ALLOCATION_ALERT
} from '../../../grind/actions/grindActionTypes';

describe('portionRoomReducer', () => {
  let initState, portionRoom;
  beforeEach(() => {
    initState = {
      cannotClosePortionRoom: false,
      portionRooms: [],
      currentPortionRoom: {},
      openingOrClosing: false,
      unfinishableBatches: [],
      cannotCloseReason: null,
      stockAllocationAlert: false
    };

    portionRoom = portionRoomFactory.build(
      { code: 'A' },
      { portionRoomState: PortionRoomState.CAN_OPEN }
    );
  });

  test('should return initState as default', () => {
    let unexpectAction = { type: 'unexpect' };
    jestExpect(portionRoomReducer(undefined, unexpectAction)).toEqual(initState);
  });

  test('should update current portion room when dispatch action UPDATE_CURRENT_PORTION_ROOM', () => {
    jestExpect(
      portionRoomReducer(initState, {
        type: UPDATE_CURRENT_PORTION_ROOM,
        payload: portionRoom
      })
    ).toEqual({
      ...initState,
      currentPortionRoom: portionRoom
    });
  });

  test('should reset current portion room when dispatch action RESET_CURRENT_PORTION_ROOM', () => {
    initState = {
      currentPortionRoom: portionRoom
    };

    jestExpect(
      portionRoomReducer(initState, {
        type: RESET_CURRENT_PORTION_ROOM
      })
    ).toEqual({
      ...initState,
      currentPortionRoom: {}
    });
  });

  test('should open portion room when dispatch action OPEN_PORTION_ROOM', () => {
    portionRoom = portionRoomFactory.build(
      { code: 'A' },
      { portionRoomState: PortionRoomState.CAN_OPEN }
    );
    initState = { currentPortionRoom: portionRoom, openingOrClosing: true };

    jestExpect(
      portionRoomReducer(initState, {
        type: OPEN_PORTION_ROOM
      })
    ).toEqual({
      ...initState,
      currentPortionRoom: {
        ...portionRoom,
        portionRoomState: PortionRoomState.CAN_CLOSE
      },
      openingOrClosing: false
    });
  });

  test('should close portion room when dispatch action CLOSE_PORTION_ROOM', () => {
    portionRoom = portionRoomFactory.build(
      { code: 'A' },
      { portionRoomState: PortionRoomState.CAN_CLOSE }
    );
    initState = { currentPortionRoom: portionRoom, openingOrClosing: true };

    jestExpect(
      portionRoomReducer(initState, {
        type: CLOSE_PORTION_ROOM
      })
    ).toEqual({
      ...initState,
      currentPortionRoom: {
        ...portionRoom,
        portionRoomState: PortionRoomState.DISABLED
      },
      openingOrClosing: false
    });
  });

  test('should update portion rooms with portion room state info when dispatch action UPDATE_PORTION_ROOMS', () => {
    const portionRoomCanOpen = portionRoomFactory.build({
      code: 'A',
      portionRoomStatus: 'closed',
      openable: true,
      approved: false,
      roomType: 'CUTTING'
    });
    const portionRoomCanClosed = portionRoomFactory.build({
      code: 'A',
      portionRoomStatus: 'opened',
      openable: false,
      approved: false,
      roomType: 'CUTTING'
    });
    const portionRoomDisable = portionRoomFactory.build({
      code: 'A',
      portionRoomStatus: 'closed',
      openable: false,
      approved: false,
      roomType: 'CUTTING'
    });
    const grindingRoomApproved = portionRoomFactory.build({
      code: 'A',
      portionRoomStatus: 'opened',
      openable: false,
      approved: true,
      roomType: 'GRINDING'
    });
    const grindingRoomOpenUnapproved = portionRoomFactory.build({
      code: 'A',
      portionRoomStatus: 'opened',
      openable: false,
      approved: false,
      roomType: 'GRINDING'
    });

    jestExpect(
      portionRoomReducer(initState, {
        type: UPDATE_PORTION_ROOMS,
        payload: [
          portionRoomCanOpen,
          portionRoomCanClosed,
          portionRoomDisable,
          grindingRoomApproved,
          grindingRoomOpenUnapproved
        ]
      })
    ).toEqual({
      ...initState,
      portionRooms: [
        {
          ...portionRoomCanOpen,
          portionRoomState: PortionRoomState.CAN_OPEN
        },
        {
          ...portionRoomCanClosed,
          portionRoomState: PortionRoomState.CAN_CLOSE
        },
        {
          ...portionRoomDisable,
          portionRoomState: PortionRoomState.DISABLED
        },
        {
          ...grindingRoomApproved,
          portionRoomState: PortionRoomState.CAN_CLOSE
        },
        {
          ...grindingRoomOpenUnapproved,
          portionRoomState: PortionRoomState.CAN_APPROVE
        }
      ]
    });
  });

  test('should update cannotClosePortionRoom to true when dispatch action CANNOT_CLOSE_PORTION_ROOM', () => {
    const initialState = { ...initState, openingOrClosing: true };

    const batches = [{ id: 1, batchNumber: 2 }];

    jestExpect(
      portionRoomReducer(initialState, {
        type: CANNOT_CLOSE_PORTION_ROOM,
        payload: { closed: true, batches: batches, reason: 'UNFINISHED_BATCHES' }
      })
    ).toEqual({
      ...initState,
      cannotClosePortionRoom: true,
      unfinishableBatches: batches,
      cannotCloseReason: 'UNFINISHED_BATCHES',
      openingOrClosing: false
    });
  });

  test('should update cannotClosePortionRoom to false when dispatch action USER_DISMISSED_CLOSE_WARNING', () => {
    const initState = {
      cannotClosePortionRoom: true
    };
    jestExpect(
      portionRoomReducer(initState, {
        type: USER_DISMISSED_CLOSE_WARNING
      })
    ).toEqual({
      ...initState,
      cannotClosePortionRoom: false,
      cannotCloseReason: null
    });
  });

  test('should mark the current room as having approved grind orders for the day set portionRoomState to CAN_CLOSE', () => {
    jestExpect(
      portionRoomReducer(
        {
          ...initState,
          currentPortionRoom: {
            portionRoomState: PortionRoomState.CAN_APPROVE,
            approved: false
          }
        },
        {
          type: GRINDING_ORDERS_APPROVED
        }
      )
    ).toEqual({
      ...initState,
      currentPortionRoom: {
        portionRoomState: PortionRoomState.CAN_CLOSE,
        approved: true
      }
    });
  });

  test('GRINDING_ORDERS_NOT_APPROVED', () => {
    jestExpect(
      portionRoomReducer(
        {
          ...initState,
          currentPortionRoom: {
            portionRoomState: PortionRoomState.CAN_CLOSE,
            approved: true
          }
        },
        {
          type: GRINDING_ORDERS_NOT_APPROVED
        }
      )
    ).toEqual({
      ...initState,
      currentPortionRoom: {
        portionRoomState: PortionRoomState.CAN_APPROVE,
        approved: false
      }
    });
  });

  test('should update openingOrClosingState', () => {
    const OPEN_OR_CLOSE_PORTION_ROOM_REQUESTED = 'OPEN_OR_CLOSE_PORTION_ROOM_REQUSTED';

    const initialState = {
      cannotClosePortionRoom: false,
      portionRooms: [],
      currentPortionRoom: {},
      openingOrClosing: false
    };

    const newState = portionRoomReducer(initialState, {
      type: OPEN_OR_CLOSE_PORTION_ROOM_REQUESTED
    });

    const expectedState = {
      cannotClosePortionRoom: false,
      portionRooms: [],
      currentPortionRoom: {},
      openingOrClosing: true
    };

    jestExpect(newState).toEqual(expectedState);
  });

  test('should show stock allocation alert', () => {
    const expectedState = { ...initState, stockAllocationAlert: true };

    const newState = portionRoomReducer(initState, { type: STOCK_ALLOCATION_ALERT, payload: true });

    jestExpect(newState).toEqual(expectedState);
  });
});
