import {
  CANNOT_CLOSE_PORTION_ROOM,
  CLOSE_PORTION_ROOM,
  OPEN_OR_CLOSE_PORTION_ROOM_REQUESTED,
  OPEN_PORTION_ROOM,
  RESET_CURRENT_PORTION_ROOM,
  UPDATE_CURRENT_PORTION_ROOM,
  UPDATE_PORTION_ROOMS,
  USER_DISMISSED_CLOSE_WARNING
} from '../actions/landingPageActionTypes';

import {
  GRINDING_ORDERS_APPROVED,
  GRINDING_ORDERS_NOT_APPROVED,
  STOCK_ALLOCATION_ALERT
} from '../../grind/actions/grindActionTypes';

function updatePortionRoomStatus(portionRoom) {
  const opened = portionRoom.portionRoomStatus === 'opened';
  const openable = portionRoom.openable;
  const approved = portionRoom.approved;
  if (opened) {
    if ('GRINDING' === portionRoom.roomType && !approved) {
      return PortionRoomState.CAN_APPROVE;
    }
    return PortionRoomState.CAN_CLOSE;
  } else {
    return openable ? PortionRoomState.CAN_OPEN : PortionRoomState.DISABLED;
  }
}

function mergeStatusInPortionRooms(portionRooms) {
  return portionRooms.map(room => {
    return Object.assign(room, {
      portionRoomState: updatePortionRoomStatus(room),
      portionRoomStatus: undefined,
      openable: undefined
    });
  });
}

export const PortionRoomState = Object.freeze({
  CAN_OPEN: 0,
  CAN_CLOSE: 1,
  DISABLED: 2,
  CAN_APPROVE: 3
});

const initialState = {
  cannotClosePortionRoom: false,
  portionRooms: [],
  currentPortionRoom: {},
  unfinishableBatches: [],
  cannotCloseReason: null,
  openingOrClosing: false,
  stockAllocationAlert: false
};

export default (state = initialState, action) => {
  switch (action.type) {
    case OPEN_OR_CLOSE_PORTION_ROOM_REQUESTED: {
      return {
        ...state,
        openingOrClosing: true
      };
    }
    case UPDATE_CURRENT_PORTION_ROOM: {
      return {
        ...state,
        currentPortionRoom: action.payload
      };
    }

    case RESET_CURRENT_PORTION_ROOM: {
      return {
        ...state,
        currentPortionRoom: {}
      };
    }

    case CANNOT_CLOSE_PORTION_ROOM: {
      return {
        ...state,
        unfinishableBatches: action.payload.batches,
        cannotCloseReason: action.payload.reason,
        cannotClosePortionRoom: true,
        openingOrClosing: false
      };
    }

    case USER_DISMISSED_CLOSE_WARNING: {
      return {
        ...state,
        cannotClosePortionRoom: false,
        cannotCloseReason: null
      };
    }

    case CLOSE_PORTION_ROOM: {
      return {
        ...state,
        currentPortionRoom: {
          ...state.currentPortionRoom,
          portionRoomState: PortionRoomState.DISABLED
        },
        openingOrClosing: false
      };
    }

    case OPEN_PORTION_ROOM: {
      return {
        ...state,
        currentPortionRoom: {
          ...state.currentPortionRoom,
          portionRoomState:
            state.currentPortionRoom.roomType === 'GRINDING'
              ? PortionRoomState.CAN_APPROVE
              : PortionRoomState.CAN_CLOSE
        },
        openingOrClosing: false
      };
    }

    case UPDATE_PORTION_ROOMS: {
      return {
        ...state,
        portionRooms: mergeStatusInPortionRooms(action.payload)
      };
    }

    case GRINDING_ORDERS_APPROVED: {
      return {
        ...state,
        currentPortionRoom: {
          ...state.currentPortionRoom,
          portionRoomState: PortionRoomState.CAN_CLOSE,
          approved: true
        }
      };
    }

    case GRINDING_ORDERS_NOT_APPROVED: {
      return {
        ...state,
        currentPortionRoom: {
          ...state.currentPortionRoom,
          portionRoomState: PortionRoomState.CAN_APPROVE,
          approved: false
        }
      };
    }

    case STOCK_ALLOCATION_ALERT: {
      return {
        ...state,
        stockAllocationAlert: action.payload
      };
    }

    default:
      return state;
  }
};
