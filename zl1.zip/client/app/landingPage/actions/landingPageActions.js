import _ from 'lodash';
import {
  CANNOT_CLOSE_PORTION_ROOM,
  CLOSE_PORTION_ROOM,
  OPEN_OR_CLOSE_PORTION_ROOM_REQUESTED,
  OPEN_PORTION_ROOM,
  RESET_CURRENT_PORTION_ROOM,
  UPDATE_CURRENT_PORTION_ROOM,
  UPDATE_PORTION_ROOMS,
  USER_DISMISSED_CLOSE_WARNING
} from './landingPageActionTypes';
import portionRoomsResources from '../../shared/api/portionRoomsResources';
import yieldModelResources from '../../shared/api/yieldModelResources';

export const getCostingRoom = () => dispatch => {
  return portionRoomsResources.getCostingRoom().then(response => {
    dispatch({
      type: UPDATE_CURRENT_PORTION_ROOM,
      payload: response.data
    });
  });
};

export const selectPortionRoom = portionRoom => ({
  type: UPDATE_CURRENT_PORTION_ROOM,
  payload: portionRoom
});

export const resetCurrentPortionRoom = () => ({
  type: RESET_CURRENT_PORTION_ROOM
});

export const getPortionRooms = () => dispatch => {
  return portionRoomsResources.getPortionRooms().then(response => {
    dispatch({
      type: UPDATE_PORTION_ROOMS,
      payload: response.data
    });
  });
};

export const openPortionRoom = () => (dispatch, getState) => {
  dispatch({
    type: OPEN_OR_CLOSE_PORTION_ROOM_REQUESTED
  });

  const currentPortionRoom = getState().portionRoomsInfo.currentPortionRoom;
  const roomId = currentPortionRoom.id;

  return portionRoomsResources.openPortionRoom(roomId).then(response => {
    dispatch({
      type: OPEN_PORTION_ROOM
    });

    dispatch({
      type: UPDATE_PORTION_ROOMS,
      payload: response.data
    });

    if ('CUTTING' === currentPortionRoom.roomType) {
      return portionRoomsResources
        .getStockAllocationAlert(currentPortionRoom.code)
        .then(({ data }) => {
          if (data) {
            dispatch({
              type: 'ERROR',
              payload: 'STOCK_ALLOCATION_ALERT'
            });
          }
        });
    }
  });
};

export const closePortionRoom = (evenUnfinishedOrders, evenSusPoUnavailable) => (
  dispatch,
  getState
) => {
  dispatch({
    type: OPEN_OR_CLOSE_PORTION_ROOM_REQUESTED
  });

  const roomId = getState().portionRoomsInfo.currentPortionRoom.id;
  const closingPortionRoomResponse = portionRoomsResources.closePortionRoom(
    roomId,
    evenUnfinishedOrders,
    evenSusPoUnavailable
  );

  return closingPortionRoomResponse.then(response => {
    const closeable = _.get(response.data, 'closed');
    if (!closeable) {
      dispatch({
        type: CANNOT_CLOSE_PORTION_ROOM,
        payload: response.data
      });
    } else {
      dispatch({
        type: CLOSE_PORTION_ROOM
      });
    }
  });
};

export const dismissPortionRoomWarning = () => ({
  type: USER_DISMISSED_CLOSE_WARNING
});

export const runYieldModel = () => {
  return yieldModelResources.runYieldModel();
};
