import { MainMenu } from '../MainMenu';
import React from 'react';
import { mount } from 'enzyme';
import { createReduxStore } from '../../../store';

describe('MainMenu', () => {
  let wrapper, links, changePath, resetCurrentPortionRoom;

  beforeEach(() => {
    links = [
      [
        {
          path: '/path/00/00',
          icon: 'icon-knife',
          text: 'Orders to Cut Today',
          id: 'Orders to Cut Today',
          isDisabled: false,
          onEnter: jest.fn()
        },
        {
          path: '/path/00/01',
          icon: 'icon-box',
          text: 'Orders to Pack Today',
          id: 'Orders to Pack Today',
          isDisabled: true,
          onEnter: jest.fn()
        }
      ],

      [
        {
          path: '/path/01/00',
          icon: 'icon-box',
          text: 'Orders to Pack Today',
          id: 'Orders to Pack Today',
          isDisabled: false,
          onEnter: jest.fn()
        }
      ]
    ];

    changePath = jest.fn();
    resetCurrentPortionRoom = jest.fn();
    wrapper = mount(
      <MainMenu
        links={links}
        changePath={changePath}
        resetCurrentPortionRoom={resetCurrentPortionRoom}
      />
    );
  });

  describe('on enter', () => {
    test('should call on enter for link when link is enabled', () => {
      wrapper.state({ focusedRowIndex: 0, focusedColumnIndex: 0 });
      wrapper.instance().onEnter();

      jestExpect(links[0][0].onEnter).toBeCalled();
    });

    test('should not call on enter for link when link is disabled', () => {
      wrapper.state({ focusedRowIndex: 0, focusedColumnIndex: 1 });
      wrapper.instance().onEnter();

      jestExpect(links[0][1].onEnter).not.toBeCalled();
    });
  });

  describe('create component', () => {
    test('should focus top left options', () => {
      jestExpect(wrapper.find('[index="0-0"]').prop('isFocused')).toBeTruthy();
    });
  });

  describe('on arrow keys', () => {
    describe('onArrowLeft', () => {
      test('when init position is 0 0', () => {
        wrapper.instance().onArrowLeft();
        wrapper.update();
        jestExpect(wrapper.find('[index="0-0"]').prop('isFocused')).toBeTruthy();
      });

      test('when init position is 0 1', () => {
        wrapper.setState({ focusedRowIndex: 0, focusedColumnIndex: 1 });
        wrapper.instance().onArrowLeft();
        wrapper.update();
        jestExpect(wrapper.find('[index="0-0"]').prop('isFocused')).toBeTruthy();
      });
    });

    describe('onArrowRight', () => {
      test('when init position is 0 0', () => {
        wrapper.instance().onArrowRight();
        wrapper.update();
        jestExpect(wrapper.find('[index="0-1"]').prop('isFocused')).toBeTruthy();
      });

      test('when init position is 0 1', () => {
        wrapper.setState({ focusedRowIndex: 0, focusedColumnIndex: 1 });
        wrapper.instance().onArrowRight();
        wrapper.update();
        jestExpect(wrapper.find('[index="0-1"]').prop('isFocused')).toBeTruthy();
      });
    });

    describe('onArrowUp', () => {
      test('when init position is 0 0', () => {
        wrapper.instance().onArrowUp();
        wrapper.update();
        jestExpect(wrapper.find('[index="0-0"]').prop('isFocused')).toBeTruthy();
      });

      test('when init position is 1 0', () => {
        wrapper.setState({ focusedRowIndex: 1, focusedColumnIndex: 0 });
        wrapper.instance().onArrowUp();
        wrapper.update();
        jestExpect(wrapper.find('[index="0-0"]').prop('isFocused')).toBeTruthy();
      });
    });

    describe('onArrowDown', () => {
      test('when init position is 0 0', () => {
        wrapper.instance().onArrowDown();
        wrapper.update();
        jestExpect(wrapper.find('[index="1-0"]').prop('isFocused')).toBeTruthy();
      });

      test('when init position is 1 0', () => {
        wrapper.setState({ focusedRowIndex: 1, focusedColumnIndex: 0 });
        wrapper.instance().onArrowDown();
        wrapper.update();
        jestExpect(wrapper.find('[index="1-0"]').prop('isFocused')).toBeTruthy();
      });
    });
  });

  describe('scroll-to-top on component mount', () => {
    test('scroll page to top', () => {
      const scrollToTop = jest.fn();
      const componentDidMount = jest.fn(() => ({ scrollToTop }));
      const store = createReduxStore();
      const component = new MainMenu({ store });
      component.componentDidMount = componentDidMount;
      component.componentDidMount().scrollToTop();
      jestExpect(scrollToTop).toBeCalled();
    });
  });
});
