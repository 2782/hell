import React from 'react';
import PropTypes from 'prop-types';
import { Button } from 'semantic-ui-react';
import NativeListener from 'react-native-listener';

export default class FocusedModalButton extends React.Component {
  constructor(props) {
    super(props);

    this.onEnter = this.onEnter.bind(this);
  }

  onEnter(event, action) {
    if ('Enter' === event.key) {
      event.stopPropagation();
      action();
    }
  }

  render() {
    const { action, buttonText, active } = this.props;

    return (
      // See https://medium.com/@ericclemmons/react-event-preventdefault-78c28c950e46
      <NativeListener onKeyDown={event => this.onEnter(event, action)}>
        <Button
          tabIndex={0}
          autoFocus={active}
          key={buttonText}
          active={active}
          positive={active}
          onClick={action}
        >
          {buttonText}
        </Button>
      </NativeListener>
    );
  }
}

FocusedModalButton.propTypes = {
  action: PropTypes.func.isRequired,
  buttonText: PropTypes.string.isRequired,
  active: PropTypes.bool.isRequired
};
