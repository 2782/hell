import React from 'react';

class MainMenu extends React.Component {
  render() {
    return null;
  }
}

export default MainMenu;
