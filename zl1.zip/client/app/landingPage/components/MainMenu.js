import React from 'react';
import PropTypes from 'prop-types';
import keydown from 'react-keydown';
import { DOWN, ENTER, LEFT, RIGHT, UP } from '../../../config/keymap';
import MenuOption from './MenuOption';
import { changePath } from '../../shared/actions/actions';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import { resetCurrentPortionRoom } from '../actions/landingPageActions';
import subscriber from '../../shared/functionKeys/subscriber';

export class MainMenu extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      focusedRowIndex: 0,
      focusedColumnIndex: 0
    };
  }

  componentDidMount() {
    this.scrollToTop();
  }

  @keydown(ENTER)
  onEnter() {
    let link = this.props.links[this.state.focusedRowIndex][this.state.focusedColumnIndex];
    if (!link.isDisabled) {
      link.onEnter();
    }
  }

  @keydown(LEFT)
  onArrowLeft() {
    this._arrowMove(this.state.focusedRowIndex, this.state.focusedColumnIndex - 1);
  }

  @keydown(UP)
  onArrowUp() {
    this._arrowMove(this.state.focusedRowIndex - 1, this.state.focusedColumnIndex);
  }

  @keydown(RIGHT)
  onArrowRight() {
    this._arrowMove(this.state.focusedRowIndex, this.state.focusedColumnIndex + 1);
  }

  @keydown(DOWN)
  onArrowDown() {
    this._arrowMove(this.state.focusedRowIndex + 1, this.state.focusedColumnIndex);
  }

  scrollToTop() {
    if (this.scrollToTopRef && this.scrollToTopRef.scrollIntoView) {
      this.scrollToTopRef.scrollIntoView({
        behavior: 'smooth',
        block: 'start',
        inline: 'nearest'
      });
    }
  }

  _arrowMove(nextFocusedRow, nextFocusedColumn) {
    if (
      nextFocusedRow >= 0 &&
      nextFocusedColumn >= 0 &&
      nextFocusedRow < this.props.links.length &&
      nextFocusedColumn < this.props.links[nextFocusedRow].length
    ) {
      this.setState({
        focusedRowIndex: nextFocusedRow,
        focusedColumnIndex: nextFocusedColumn
      });
    }
  }

  _isFocused(rowIndex, columnIndex) {
    return rowIndex === this.state.focusedRowIndex && columnIndex === this.state.focusedColumnIndex;
  }

  _formattedLinks(links) {
    return links.map((row, rowIndex) => {
      return row.map((link, columnIndex) => {
        return {
          ...link,
          rowIndex,
          columnIndex
        };
      });
    });
  }

  _linksToComponent(formattedLinks) {
    return formattedLinks.map((row, index) => {
      return (
        <div key={index} className='row'>
          {row.map(link => {
            return (
              <MenuOption
                key={`${link.rowIndex}-${link.columnIndex}`}
                index={`${link.rowIndex}-${link.columnIndex}`}
                id={link.id}
                icon={link.icon}
                onClick={link.onEnter}
                text={link.text}
                isDisabled={link.isDisabled}
                isFocused={this._isFocused(link.rowIndex, link.columnIndex)}
              />
            );
          })}
        </div>
      );
    });
  }

  render() {
    const formattedLinks = this._formattedLinks(this.props.links);
    const linkComponents = this._linksToComponent(formattedLinks);

    return (
      <div className='links' ref={node => (this.scrollToTopRef = node)}>
        {linkComponents}
      </div>
    );
  }
}

MainMenu.propTypes = {
  links: PropTypes.array.isRequired,
  changePath: PropTypes.func.isRequired,
  resetCurrentPortionRoom: PropTypes.func.isRequired
};

const mapDispatchToProps = dispatch =>
  bindActionCreators(
    {
      changePath,
      resetCurrentPortionRoom
    },
    dispatch
  );

export default connect(
  null,
  mapDispatchToProps
)(
  subscriber(MainMenu, {
    f4Behavior: props => {
      props.resetCurrentPortionRoom();
    },
    targetComponent: 'MainMenu',
    uris: {
      F4: ['#/main-navigation']
    }
  })
);
