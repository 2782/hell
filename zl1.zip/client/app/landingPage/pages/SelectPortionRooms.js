import React from 'react';
import PropTypes from 'prop-types';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import { getPortionRooms, selectPortionRoom } from '../actions/landingPageActions';
import { Grid, Ref, Table } from 'semantic-ui-react';
import { changePath, setHeaderAndFooter } from '../../shared/actions/actions';
import { SELECT_PORTION_ROOM } from '../../shared/components/pageTitles';
import { DOWN, ENTER, TAB, UP } from '../../../config/keymap';
import { SELECT_PORTION_ROOM_FOOTER } from '../../shared/components/pageFooters';
import subscriber from '../../shared/functionKeys/subscriber';

export class SelectPortionRooms extends React.Component {
  constructor(props) {
    super(props);
    this.rows = [];
    this.current = 0;
  }

  componentDidMount() {
    this.props.getPortionRooms();
  }

  hasUserIdAndRole() {
    const { userId, role } = this.props;

    return !(userId === null && (role === null || role === 'NO_ROLE_DEFINED'));
  }

  componentDidUpdate() {
    if (this.hasUserIdAndRole()) {
      this.props.setHeaderAndFooter({
        header: SELECT_PORTION_ROOM,
        footer: SELECT_PORTION_ROOM_FOOTER
      });

      this.focusOnCurrentRow();
    }
  }

  onClick(portionRoom) {
    this.props.selectPortionRoom(portionRoom);
    this.props.changePath('/main-navigation');
  }

  onMoveOrSubmit(e, portionRoom) {
    if (e.keyCode === ENTER[0]) {
      setTimeout(() => this.onClick(portionRoom), 1);
    } else if (e.keyCode === TAB[0] || e.keyCode === UP[0] || e.keyCode === DOWN[0]) {
      e.preventDefault();
      e.stopPropagation();
      this.moveFocus(e);
    }
  }

  moveFocus(e) {
    if (e.keyCode === TAB[0]) {
      if (!e.shiftKey) {
        ++this.current;
        if (this.current === this.rows.length) {
          this.current = 0;
        }
      } else {
        --this.current;
        if (this.current < 0) {
          this.current = this.rows.length - 1;
        }
      }
    } else if (e.keyCode === UP[0]) {
      if (0 === this.current) {
        return;
      }
      --this.current;
    } else {
      if (this.rows.length - 1 === this.current) {
        return;
      }
      ++this.current;
    }
    this.focusOnCurrentRow();
  }

  focusOnCurrentRow() {
    this.rows[this.current] && this.rows[this.current].focus();
  }

  render() {
    const { portionRooms } = this.props;

    if (!this.hasUserIdAndRole()) {
      return null;
    }

    return (
      <div className='page-content portion-rooms'>
        <Grid centered>
          <Grid.Column width={8}>
            <Table
              className='ui center aligned column row'
              striped
              celled
              columns={1}
              fixed
              singleLine
              size={'large'}
            >
              <Table.Header>
                <Table.Row>
                  <Table.HeaderCell>PORTION ROOMS</Table.HeaderCell>
                </Table.Row>
              </Table.Header>
              <Table.Body>
                {portionRooms.map((portionRoom, index) => this.portionRoomRow(portionRoom, index))}
              </Table.Body>
            </Table>
          </Grid.Column>
        </Grid>
      </div>
    );
  }

  portionRoomRow(portionRoom, index) {
    return (
      <Ref key={index} innerRef={node => this.rows.push(node)}>
        <Table.Row
          className={'portion-room-row'}
          tabIndex={0}
          onClick={() => this.onClick(portionRoom)}
          onKeyDown={e => this.onMoveOrSubmit(e, portionRoom)}
        >
          <Table.Cell>{displayForPortionRoom(portionRoom)}</Table.Cell>
        </Table.Row>
      </Ref>
    );
  }
}

SelectPortionRooms.propTypes = {
  portionRooms: PropTypes.array,
  getPortionRooms: PropTypes.func.isRequired,
  changePath: PropTypes.func.isRequired,
  selectPortionRoom: PropTypes.func.isRequired,
  setHeaderAndFooter: PropTypes.func.isRequired,
  role: PropTypes.string,
  userId: PropTypes.string
};

function displayForPortionRoom(portionRoom) {
  return `${portionRoom.code} - ${portionRoom.description}`;
}

function comparePortionRoomsByDisplay(a, b) {
  a = displayForPortionRoom(a);
  b = displayForPortionRoom(b);
  return a.localeCompare(b);
}

const mapStateToProps = state => ({
  userId: state.login.userId,
  role: state.login.role,
  portionRooms: state.portionRoomsInfo.portionRooms.sort(comparePortionRoomsByDisplay)
});

const mapDispatchToProps = dispatch =>
  bindActionCreators(
    {
      getPortionRooms,
      changePath,
      selectPortionRoom,
      setHeaderAndFooter
    },
    dispatch
  );

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(
  subscriber(SelectPortionRooms, {
    f4Behavior: () => {}, // Do not allow F4 at ROOT
    targetComponent: 'SelectPortionRooms',
    uris: {
      F4: ['#/']
    }
  })
);
