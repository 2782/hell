import { checkProductHasCost } from '../checkProductHasCost';
import { getCostByProductCode_promise } from '../../api/costResources';
import { showNoCostWarningModal } from '../actions';

jest.mock('../../api/costResources', () => ({
  getCostByProductCode_promise: jest.fn()
}));

jest.mock('../actions', () => ({
  showNoCostWarningModal: jest.fn(() => ({ type: 'MOCK_SHOW_MODAL_ACTION' }))
}));

describe('check product has cost action', () => {
  const PRODUCT_CODE = '0078889';

  test('when resource returns a cost do nothing', () => {
    const dispatch = jest.fn();

    getCostByProductCode_promise.mockImplementation(() =>
      Promise.resolve({ data: { cost: 12, labor: 20 } })
    );

    return checkProductHasCost(PRODUCT_CODE)(dispatch).then(() => {
      jestExpect(getCostByProductCode_promise).toHaveBeenCalledWith(PRODUCT_CODE);
      jestExpect(dispatch).not.toHaveBeenCalled();
    });
  });

  test('when resource does not return a cost, show modal with scary message', () => {
    const dispatch = jest.fn();
    getCostByProductCode_promise.mockImplementation(() => Promise.resolve({ data: null }));

    return checkProductHasCost(PRODUCT_CODE)(dispatch).then(() => {
      jestExpect(getCostByProductCode_promise).toHaveBeenCalledWith(PRODUCT_CODE);
      jestExpect(dispatch).toHaveBeenCalledWith(showNoCostWarningModal());
    });
  });

  test('when resource returns a cost of zero, show modal with message', () => {
    const dispatch = jest.fn();

    getCostByProductCode_promise.mockImplementation(() =>
      Promise.resolve({ data: { cost: 0, labor: 20 } })
    );

    return checkProductHasCost(PRODUCT_CODE)(dispatch).then(() => {
      jestExpect(getCostByProductCode_promise).toHaveBeenCalledWith(PRODUCT_CODE);
      jestExpect(dispatch).toHaveBeenCalledWith(showNoCostWarningModal());
    });
  });
});
