import portionRoomTableResources from '../../../shared/api/portionRoomTableResources';
import productResources from '../../../shared/api/productResources';
import {
  changePath,
  clearProductInfo,
  getOperatingDates,
  getPortionRoomTableInfo,
  getPrimeUserDetails,
  getProductInfo,
  returnToPreviousPage,
  setHeaderAndFooter,
  showNoCostWarningModal
} from '../actions';
import {
  RESET_PORTION_ROOM_TABLE,
  RESET_PRODUCT_INFO,
  UPDATE_OPERATING_DATES,
  UPDATE_PORTION_ROOM_TABLE,
  UPDATE_PRODUCT_INFO
} from '../../../shared/actions/actionTypes';
import operatingDatesResource from '../../api/operatingDatesResource';
import { SET_HEADER_AND_FOOTER } from '../actionTypes';
import loginResources from '../../api/loginResources';

jest.mock('../../api/loginResources', () => ({
  getPrimeUserDetails: jest.fn()
}));
jest.mock('../../api/operatingDatesResource');
jest.mock('../../../shared/api/portionRoomTableResources');
jest.mock('../../../shared/api/productResources');

describe('actions', () => {
  let dispatch;

  beforeEach(() => {
    dispatch = jest.fn();
  });

  describe('changePath()', () => {
    test('should dispatch push to new path when changing path', () => {
      dispatch(changePath('/hello/world'));
      jestExpect(dispatch).toBeCalledWith({
        type: '@@router/CALL_HISTORY_METHOD',
        payload: {
          method: 'push',
          args: ['/hello/world']
        }
      });
    });
  });

  describe('getPrimeUserDetails()', () => {
    test('should dispatch update to login info (user and role)', async () => {
      loginResources.getPrimeUserDetails.mockResolvedValue({
        data: { userId: 'USER_WITH_SOME_ID', role: 'ROLE_COSTING' }
      });

      await getPrimeUserDetails()(dispatch);

      jestExpect(dispatch).toBeCalledWith({
        type: 'UPDATE_LOGGED_IN_USER',
        payload: {
          role: 'ROLE_COSTING',
          userId: 'USER_WITH_SOME_ID'
        }
      });
    });
  });

  describe('returnToPreviousPage()', () => {
    test('should dispatch back when returning to previous page', () => {
      dispatch(returnToPreviousPage());
      jestExpect(dispatch).toBeCalledWith({
        type: '@@router/CALL_HISTORY_METHOD',
        payload: { method: 'goBack', args: [] }
      });
    });
  });

  test('should call getPortionRoomTableInfo and dispatch updatePortionRoomTable action with the result', () => {
    const portionRoomTableResponse = {
      data: {
        id: 1,
        tableCode: 1,
        tableDescription: 'table one',
        station: {
          id: 1,
          stationCode: 1,
          name: 'Lily'
        }
      }
    };
    portionRoomTableResources.getPortionRoomTable.mockImplementation((id, fn) =>
      fn(portionRoomTableResponse)
    );

    getPortionRoomTableInfo(1)(dispatch);

    jestExpect(dispatch).toBeCalledWith({
      type: RESET_PORTION_ROOM_TABLE
    });
    jestExpect(dispatch).toBeCalledWith({
      type: UPDATE_PORTION_ROOM_TABLE,
      payload: portionRoomTableResponse.data
    });
  });

  describe('getProductInfo()', () => {
    test('should call getProductInfo success and dispatch UPDATE_PRODUCT_INFO', () => {
      const productResponse = {
        data: {
          id: 20,
          code: '0000507',
          description: 'QB, PRIME T-BONE STEAK 205',
          table: {
            id: 21421402152,
            station: {
              name: 'QB CUTTER 2',
              room: 'QB',
              stationCode: 93,
              id: 21421402152
            },
            tableCode: 2,
            tableDescription: 'Table 2 at QB Portion',
            stationId: 21421402152
          },
          productOutput: 'FINISHED'
        }
      };

      productResources.getProductInfo.mockImplementation((code, fn) => fn(productResponse));

      getProductInfo('0000507')(dispatch);

      jestExpect(dispatch).toBeCalledWith({
        type: UPDATE_PRODUCT_INFO,
        payload: productResponse.data
      });
    });

    test('should call getProductInfo failed and dispatch RESET_PRODUCT_INFO', () => {
      productResources.getProductInfo.mockImplementation((code, succ, err) => err({}));

      getProductInfo('0000507')(dispatch);

      jestExpect(dispatch).toBeCalledWith({
        type: RESET_PRODUCT_INFO
      });
    });
  });

  test('clearProductInfo should dispatch RESET_PRODUCT_INFO', () => {
    dispatch(clearProductInfo());

    jestExpect(dispatch).toBeCalledWith({
      type: RESET_PRODUCT_INFO
    });
  });

  test('should call getOperatingDates and dispatch getOperatingDates action with the result', () => {
    operatingDatesResource.getOperatingDates.mockImplementation((room, fn) =>
      fn(operatingDatesResponse)
    );
    const operatingDatesResponse = {
      data: {
        first: '2017-12-22',
        second: '2017-12-25'
      }
    };
    const getState = () => ({ portionRoomsInfo: { currentPortionRoom: { code: 'A' } } });
    getOperatingDates()(dispatch, getState);

    jestExpect(operatingDatesResource.getOperatingDates).toHaveBeenCalledWith(
      'A',
      jestExpect.any(Function)
    );
    jestExpect(dispatch).toBeCalledWith({
      type: UPDATE_OPERATING_DATES,
      payload: operatingDatesResponse.data
    });
  });

  test('should call setHeaderAndFooter and dispatch SET_HEADER_AND_FOOTER', () => {
    const headerAndFooter = {
      header: 'My Header',
      footer: { f4: 'My footer F4' }
    };

    dispatch(setHeaderAndFooter(headerAndFooter));

    jestExpect(dispatch).toBeCalledWith({
      payload: headerAndFooter,
      type: SET_HEADER_AND_FOOTER
    });
  });

  test('it should show modal if no cost', () => {
    const productCodes = ['888888'];
    showNoCostWarningModal(productCodes, {})(dispatch);

    jestExpect(dispatch).toBeCalledWith(
      jestExpect.objectContaining({
        type: 'SHOW_CONFIRMATION_MODAL'
      })
    );
  });
});
