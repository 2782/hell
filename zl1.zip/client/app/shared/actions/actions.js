import portionRoomTableResources from '../../shared/api/portionRoomTableResources';
import {
  HIDE_CONFIRMATION_MODAL,
  RESET_PORTION_ROOM_TABLE,
  RESET_PRODUCT_INFO,
  SET_HEADER_AND_FOOTER,
  UPDATE_OPERATING_DATES,
  UPDATE_PORTION_ROOM_TABLE,
  UPDATE_PRODUCT_INFO
} from './actionTypes';

import { goBack, push, replace } from 'react-router-redux';
import operatingDatesResource from '../api/operatingDatesResource';
import productResources from '../api/productResources';
import isEmpty from 'lodash/isEmpty';
import loginResources from '../api/loginResources';

export const replacePath = path => replace(path);

export const changePath = path => push(path);

export const getPrimeUserDetails = () => dispatch =>
  loginResources.getPrimeUserDetails().then(({ data }) => {
    dispatch({
      type: 'UPDATE_LOGGED_IN_USER',
      payload: {
        userId: data.userId,
        role: data.role
      }
    });
  });

export const returnToPreviousPage = () => goBack();

export const hideModal = () => ({
  type: HIDE_CONFIRMATION_MODAL
});

export const showNoCostWarningModal = (productCodes = [], event = {}) => dispatch => {
  const formattedItemCodes = productCodes.reduce((acc, code) => (acc += ', ' + code), '');

  const modalOptions = {
    header: 'No Cost Assigned',
    content: `Item(s) ${formattedItemCodes} do not have a cost.
Products cannot be selected until a pricing model has been created. 
Please advise your Production Manager immediately.`,
    confirmButton: 'Ok',
    confirmAction: () => {
      if (!isEmpty(event)) {
        event.target.focus();
      }
      hideModal();
    }
  };

  return dispatch(showModal(modalOptions));
};

export const showModal = confirmationModal => ({
  type: 'SHOW_CONFIRMATION_MODAL',
  payload: confirmationModal
});

export const getPortionRoomTableInfo = tableId => {
  return dispatch => {
    dispatch({
      type: RESET_PORTION_ROOM_TABLE
    });
    portionRoomTableResources.getPortionRoomTable(tableId, response => {
      dispatch({
        type: UPDATE_PORTION_ROOM_TABLE,
        payload: response.data
      });
    });
  };
};

export const getOperatingDates = () => {
  return (dispatch, getState) => {
    const roomCode = getState().portionRoomsInfo.currentPortionRoom.code;
    operatingDatesResource.getOperatingDates(roomCode, response => {
      dispatch({
        type: UPDATE_OPERATING_DATES,
        payload: response.data
      });
    });
  };
};

export const clearProductInfo = () => ({
  type: RESET_PRODUCT_INFO
});

export const getProductInfo = productCode => {
  return dispatch => {
    productResources.getProductInfo(
      productCode,
      response => {
        dispatch({
          type: UPDATE_PRODUCT_INFO,
          payload: response.data
        });
      },
      () => {
        dispatch({
          type: RESET_PRODUCT_INFO
        });
      }
    );
  };
};

export const setHeaderAndFooter = payload => ({
  type: SET_HEADER_AND_FOOTER,
  payload
});

export default {
  showModal
};
