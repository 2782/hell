import config from '../../../../config/env';
import axios from 'axios';

const getPackOrders = (room, callback) => {
  const roomCode = room.currentPortionRoom.code;
  const orderType =
    room.currentPortionRoom.roomType.toLowerCase() === 'cutting' ? 'cut-orders' : 'orders/grind';

  const request = axios({
    method: 'get',
    url: `${config.api.target}/api/${orderType}?status=to-pack&room-code=${roomCode}`,
    headers: {
      'Content-type': 'application/json'
    }
  });

  return request.then(response => {
    callback(response);
  });
};

const packOrder = orderToPackInfo => {
  return axios({
    method: 'post',
    url: `${config.api.target}/api/boxes`,
    headers: {
      'Content-Type': 'application/json'
    },
    data: {
      ...orderToPackInfo,
      packType: 'NORMAL'
    }
  });
};

const packOffStock = stockBoxRequestBody => {
  return axios({
    method: 'post',
    url: `${config.api.target}/api/boxes/stock`,
    headers: {
      'Content-Type': 'application/json'
    },
    data: stockBoxRequestBody
  });
};

const packOffWIPBox = wipBoxRequestBody => {
  return axios({
    method: 'post',
    url: `${config.api.target}/api/boxes/pack-wip`,
    headers: {
      'Content-Type': 'application/json'
    },
    data: wipBoxRequestBody
  });
};

const getOrderToPack = cutOrderId => {
  return axios({
    method: 'get',
    url: `${config.api.target}/api/cut-orders/${cutOrderId}`,
    headers: {
      'Content-Type': 'application/json'
    }
  });
};

const checkPackOrderExistsForCutTicketAndRoom = (cutTicketCode, roomCode) => {
  return axios({
    method: 'get',
    url: `${config.api.target}/api/cut-orders/ticket/${cutTicketCode}/room/${roomCode}`,
    headers: {
      'Content-Type': 'application/json'
    }
  });
};

const checkPackOrderExistsForGrindTicketAndRoom = (grindTicketcode, roomCode) => {
  return axios({
    method: 'get',
    url: `${config.api.target}/api/orders/grind/ticket/${grindTicketcode}/room/${roomCode}`,
    headers: {
      'Content-Type': 'application/json'
    }
  });
};

const completeBanquetOrder = cutOrderId => {
  return axios({
    method: 'post',
    url: `${config.api.target}/api/cut-orders/${cutOrderId}/banquet/complete`,
    headers: {
      'Content-Type': 'application/json'
    }
  });
};

export default {
  getPackOrders,
  packOffStock,
  packOffWIPBox,
  getOrderToPack,
  completeBanquetOrder,
  packOrder,
  checkPackOrderExistsForCutTicketAndRoom,
  checkPackOrderExistsForGrindTicketAndRoom
};
