import axios from 'axios';
import config from '../../../../config/env';

const getAllPiecesPackages = callback => {
  const request = axios({
    method: 'get',
    url: `${config.api.target}/api/package/pieces-packages`,
    headers: {
      'Content-Type': 'application/json'
    }
  });

  request.then(response => callback(response));
};

export default {
  getAllPiecesPackages
};
