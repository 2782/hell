import moxios from 'moxios';
import grindOrdersResources from '../grindOrdersResources';
import grindingOrderFactory from '../../../../test-factories/grindingOrderFactory';
import GrindingHouseParFactory from '../../../../test-factories/grindingHousePar';

describe('grindOrdersResources', () => {
  let successCallback, currentPortionRoom;

  beforeEach(() => {
    successCallback = jest.fn();
    moxios.install();
    currentPortionRoom = 'A';
  });

  afterEach(() => {
    moxios.uninstall();
  });

  test('should get all grind orders', done => {
    grindOrdersResources.getGrindOrders(currentPortionRoom, successCallback);

    moxios.wait(() => {
      let request = moxios.requests.mostRecent();
      request.respondWith({ status: 200, response: 'data' }).then(response => {
        jestExpect(successCallback).toHaveBeenCalledWith(response);
        jestExpect(request.config).toMatchObject({
          method: 'get',
          url: '/api/orders/grind',
          params: { 'room-code': 'A', cancelled: false },
          headers: { 'Content-Type': 'application/json' }
        });
        done();
      });
    });
  });

  test('should approve grinding orders', done => {
    const roomCode = 'A';

    grindOrdersResources.approveGrindOrders(roomCode);

    moxios.wait(() => {
      let request = moxios.requests.mostRecent();
      request.respondWith({ status: 200 }).then(() => {
        jestExpect(request.config).toMatchObject({
          method: 'post',
          url: '/api/orders/grind/approve',
          params: { 'room-code': 'A' },
          headers: { 'Content-Type': 'application/json' }
        });
        done();
      });
    });
  });

  test('should schedule grind orders', done => {
    const scheduledMap = { 1: 23, 4: 56 };

    grindOrdersResources.scheduleGrindOrdersToProduceToday(scheduledMap, successCallback);

    moxios.wait(() => {
      let request = moxios.requests.mostRecent();
      request.respondWith({ status: 200 }).then(() => {
        jestExpect(successCallback).toHaveBeenCalled();
        jestExpect(request.config).toMatchObject({
          method: 'post',
          url: '/api/orders/grind/schedule',
          data: '{"1":23,"4":56}',
          headers: { 'Content-Type': 'application/json' }
        });
        done();
      });
    });
  });

  test('should update grinding order', done => {
    const grindOrder = grindingOrderFactory.build();
    grindOrder.id = 1;
    grindOrder.qtyInBoxes = 1;
    grindOrdersResources.updateGrindOrder(grindOrder, successCallback);

    moxios.wait(() => {
      let request = moxios.requests.mostRecent();
      request.respondWith({ status: 200 }).then(() => {
        jestExpect(successCallback).toHaveBeenCalled();
        jestExpect(request.config).toMatchObject({
          method: 'post',
          url: '/api/orders/grind/update/1/qtyInBoxes/1',
          headers: { 'Content-Type': 'application/json' }
        });
        done();
      });
    });
  });

  test('should generate grinding order from house par', done => {
    const grindHousePars = [GrindingHouseParFactory.build()];
    grindOrdersResources.generateGrindingOrdersFromHousePar(grindHousePars, 'D', successCallback);

    moxios.wait(() => {
      let request = moxios.requests.mostRecent();
      request.respondWith({ status: 201 }).then(() => {
        jestExpect(successCallback).toHaveBeenCalled();
        jestExpect(request.config).toMatchObject({
          method: 'post',
          url: '/api/orders/grind/house-pars/schedule',
          params: { 'room-code': 'D' },
          data: JSON.stringify(grindHousePars),
          headers: { 'Content-Type': 'application/json' }
        });
        done();
      });
    });
  });
});
