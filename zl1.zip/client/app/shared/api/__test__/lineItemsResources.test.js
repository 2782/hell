import moxios from 'moxios';
import lineItemsResources from '../lineItemsResources';

describe('lineItemsResources', () => {
  let successCallback;
  beforeEach(() => {
    successCallback = jest.fn();
    moxios.install();
  });

  afterEach(() => {
    moxios.uninstall();
  });

  test('should get future line items', done => {
    lineItemsResources.getFutureLineItems('A', successCallback);

    moxios.wait(() => {
      let request = moxios.requests.mostRecent();
      request.respondWith({ status: 200, response: 'data' }).then(response => {
        jestExpect(successCallback).toHaveBeenCalledWith(response);
        jestExpect(request.config).toMatchObject({
          method: 'get',
          url: '/api/line-items/future-items',
          params: { 'room-code': 'A' },
          headers: { 'Content-Type': 'application/json' }
        });
        done();
      });
    });
  });

  test('should schedule future orders to product today', done => {
    lineItemsResources.scheduleFutureOrdersToProduceToday({ 100: '2' }, successCallback);

    moxios.wait(() => {
      let request = moxios.requests.mostRecent();
      request.respondWith({ status: 200, response: 'data' }).then(response => {
        jestExpect(successCallback).toHaveBeenCalledWith(response);
        jestExpect(request.config).toMatchObject({
          method: 'post',
          url: '/api/line-items/future-items/schedule',
          headers: { 'Content-Type': 'application/json' },
          data: JSON.stringify({ 100: '2' })
        });
        done();
      });
    });
  });
});
