import moxios from 'moxios';
import cutOrdersResources from '../cutOrdersResources';

describe('cutOrdersResources', () => {
  let successCallback, currentPortionRoom;
  const STATION_ID = 125;

  beforeEach(() => {
    successCallback = jest.fn();
    moxios.install();
    currentPortionRoom = 'A';
  });

  afterEach(() => {
    moxios.uninstall();
  });

  test('should get all cancelled orders', done => {
    cutOrdersResources.getOverviewOfOrders(currentPortionRoom, 'Cancelled', null, successCallback);

    moxios.wait(() => {
      let request = moxios.requests.mostRecent();
      request.respondWith({ status: 200, response: 'data' }).then(response => {
        jestExpect(successCallback).toHaveBeenCalledWith(response);
        jestExpect(request.config).toMatchObject({
          method: 'get',
          url: '/api/cut-orders',
          params: {
            status: 'to-cut,to-pack,packed,dismissed',
            'room-code': 'A',
            cancelled: true
          },
          headers: { 'Content-Type': 'application/json' }
        });
        done();
      });
    });
  });

  test('should get cut orders with sus order number', done => {
    cutOrdersResources.getCutOrdersToPack('2019-07-09', '3401581', '123', '');

    moxios.wait(() => {
      let request = moxios.requests.mostRecent();
      request.respondWith({ status: 200, response: 'data' }).then(() => {
        jestExpect(request.config).toMatchObject({
          method: 'get',
          url: '/api/cut-orders/to-pack',
          params: {
            date: '2019-07-09',
            'product-code': '3401581',
            'sus-order-no': '123'
          },
          headers: { 'Content-Type': 'application/json' }
        });
        done();
      });
    });
  });

  test('should get all orders for overview with out station filter', done => {
    cutOrdersResources.getOverviewOfOrders(currentPortionRoom, 'All', null, successCallback);

    moxios.wait(() => {
      let request = moxios.requests.mostRecent();
      request.respondWith({ status: 200, response: 'data' }).then(response => {
        jestExpect(successCallback).toHaveBeenNthCalledWith(1, response);
        jestExpect(request.config).toMatchObject({
          method: 'get',
          url: '/api/cut-orders',
          params: {
            status: 'to-cut,to-pack,packed,dismissed',
            'room-code': 'A'
          },
          headers: { 'Content-Type': 'application/json' }
        });
        done();
      });
    });
  });

  test('should get all orders for overview with station-id is 125', done => {
    cutOrdersResources.getOverviewOfOrders(currentPortionRoom, 'All', STATION_ID, successCallback);

    moxios.wait(() => {
      let request = moxios.requests.mostRecent();
      request.respondWith({ status: 200, response: 'data' }).then(response => {
        jestExpect(successCallback).toHaveBeenCalledWith(response);
        jestExpect(request.config).toMatchObject({
          method: 'get',
          url: '/api/cut-orders',
          params: {
            status: 'to-cut,to-pack,packed,dismissed',
            'station-ids': STATION_ID,
            'room-code': 'A'
          },
          headers: { 'Content-Type': 'application/json' }
        });
        done();
      });
    });
  });

  test('should get completed orders for overview without station filter', done => {
    cutOrdersResources.getOverviewOfOrders(currentPortionRoom, 'Completed', null, successCallback);

    moxios.wait(() => {
      let request = moxios.requests.mostRecent();
      request.respondWith({ status: 200, response: 'data' }).then(response => {
        jestExpect(successCallback).toHaveBeenCalledWith(response);
        jestExpect(request.config).toMatchObject({
          method: 'get',
          url: '/api/cut-orders',
          params: {
            status: 'packed',
            'room-code': 'A'
          },
          headers: { 'Content-Type': 'application/json' }
        });
        done();
      });
    });
  });

  test('should get Selected to Cut orders for overview without station filter', done => {
    cutOrdersResources.getOverviewOfOrders(
      currentPortionRoom,
      'SelectedToCut',
      null,
      successCallback
    );

    moxios.wait(() => {
      let request = moxios.requests.mostRecent();
      request.respondWith({ status: 200, response: 'data' }).then(response => {
        jestExpect(successCallback).toHaveBeenCalledWith(response);
        jestExpect(request.config).toMatchObject({
          method: 'get',
          url: '/api/cut-orders',
          params: {
            status: 'to-pack',
            'room-code': 'A'
          },
          headers: { 'Content-Type': 'application/json' }
        });
        done();
      });
    });
  });

  test('should get New orders for overview without station filter', done => {
    cutOrdersResources.getOverviewOfOrders(currentPortionRoom, 'New', null, successCallback);

    moxios.wait(() => {
      let request = moxios.requests.mostRecent();
      request.respondWith({ status: 200, response: 'data' }).then(response => {
        jestExpect(successCallback).toHaveBeenCalledWith(response);
        jestExpect(request.config).toMatchObject({
          method: 'get',
          url: '/api/cut-orders',
          params: {
            status: 'to-cut',
            'room-code': 'A'
          },
          headers: { 'Content-Type': 'application/json' }
        });
        done();
      });
    });
  });

  test('should get orders for a given table id', done => {
    cutOrdersResources.getOrdersByTableId('A', 92, successCallback);

    moxios.wait(() => {
      let request = moxios.requests.mostRecent();
      request.respondWith({ status: 200, response: 'data' }).then(response => {
        jestExpect(successCallback).toHaveBeenCalledWith(response);
        jestExpect(request.config).toMatchObject({
          method: 'get',
          url: '/api/cut-orders?status=to-cut&table-id=92&room-code=A&cancelled=false',
          headers: { 'Content-Type': 'application/json' }
        });
        done();
      });
    });
  });

  test('should confirm cut orders to cut', done => {
    cutOrdersResources.confirmCutOrders('A', [12, 13, 26]);

    moxios.wait(() => {
      let request = moxios.requests.mostRecent();
      request.respondWith({ status: 200, response: 'data' }).then(() => {
        jestExpect(request.config).toMatchObject({
          method: 'patch',
          url: '/api/cut-orders?room-code=A'
        });
        jestExpect(JSON.parse(request.config.data)).toEqual([
          { cutOrderStatus: 'to-pack', id: 12 },
          { cutOrderStatus: 'to-pack', id: 13 },
          { cutOrderStatus: 'to-pack', id: 26 }
        ]);
        done();
      });
    });
  });

  test('should print cut tickets', done => {
    cutOrdersResources.printCutTickets([12, 13, 26]);

    moxios.wait(() => {
      let request = moxios.requests.mostRecent();
      request.respondWith({ status: 200, response: 'data' }).then(() => {
        jestExpect(request.config).toMatchObject({
          method: 'post',
          url: '/api/cut-tickets',
          headers: {
            'Content-Type': 'application/json',
            'Keep-Alive': 'timeout=120'
          }
        });
        jestExpect(JSON.parse(request.config.data)).toEqual([12, 13, 26]);
        done();
      });
    });
  });

  test('should reprint cut tickets', done => {
    cutOrdersResources.reprintCutTicket(26, 12);

    moxios.wait(() => {
      let request = moxios.requests.mostRecent();
      request.respondWith({ status: 200, response: 'data' }).then(() => {
        jestExpect(request.config).toMatchObject({
          method: 'post',
          url: '/api/cut-tickets/26/reprint',
          params: {
            stationCode: 12
          },
          headers: {
            'Content-Type': 'application/json'
          }
        });
        done();
      });
    });
  });

  test('should call success callback when dismissing a cancelled order succeeds', done => {
    cutOrdersResources.dismissCancelledOrder(10, successCallback);

    moxios.wait(() => {
      let request = moxios.requests.mostRecent();
      request.respondWith({ status: 200, response: 'data' }).then(() => {
        jestExpect(successCallback).toHaveBeenCalledTimes(1);
        done();
      });
    });
  });
});
