import moxios from 'moxios';
import scaleResources from '../../../shared/api/scaleResources';

describe('validate()', () => {
  let successCallback, errorCallback;

  beforeEach(() => {
    successCallback = jest.fn();
    errorCallback = jest.fn();
    moxios.install();
  });

  afterEach(() => {
    moxios.uninstall();
  });

  test('should return weight from api', done => {
    scaleResources.readWeight(successCallback, errorCallback);

    moxios.wait(() => {
      let request = moxios.requests.mostRecent();
      request.respondWith({ status: 200, response: '12.7lb' }).then(() => {
        jestExpect(successCallback).toHaveBeenCalledWith('12.7');
        jestExpect(errorCallback).not.toHaveBeenCalled();
        done();
      });
    });
  });

  test('should return appropriate error when value from api is in kilos', done => {
    scaleResources.readWeight(successCallback, errorCallback);

    moxios.wait(() => {
      let request = moxios.requests.mostRecent();
      request.respondWith({ status: 200, response: '12.2kg' }).then(() => {
        jestExpect(errorCallback).toHaveBeenNthCalledWith(
          1,
          new Error("Please set scale's unit of measure to pounds.")
        );
        done();
      });
    });
  });

  test('should return appropriate error when value from scale is negative', done => {
    scaleResources.readWeight(successCallback, errorCallback);

    moxios.wait(() => {
      let request = moxios.requests.mostRecent();
      request.respondWith({ status: 200, response: '-0.7lb' }).then(() => {
        jestExpect(errorCallback).toHaveBeenNthCalledWith(
          1,
          new Error('Weight cannot be negative.')
        );
        done();
      });
    });
  });

  test('should return appropriate error when value from scale is not connected', done => {
    scaleResources.readWeight(successCallback, errorCallback);

    moxios.wait(() => {
      let request = moxios.requests.mostRecent();
      request
        .respondWith({
          status: 500,
          response:
            '{"timestamp":1530826819842,"method":"GET","path":"/api/boxes/read-houston-scale","status":500,' +
            '"statusText":"Internal Server Error","exceptionClass":"org.springframework.web.client.ResourceAccessException",' +
            '"exceptionMessage":"I/O error on POST request for \\"http://10.242.138.200/action/status\\":' +
            ' Operation timed out (Connection timed out); nested exception is java.net.ConnectException: ' +
            'Operation timed out (Connection timed out)"}'
        })
        .then(() => {
          jestExpect(errorCallback).toHaveBeenNthCalledWith(
            1,
            new Error('Request failed with status code 500')
          );
          done();
        });
    });
  });
});
