import moxios from 'moxios';
import packOrdersResources from '../packOrdersResources';

describe('packOrdersResources', () => {
  let successCallback;

  beforeEach(() => {
    successCallback = jest.fn();
    moxios.install();
  });

  afterEach(() => {
    moxios.uninstall();
  });

  test('should get pack orders for table 19 in cutting room A', done => {
    const room = {
      currentPortionRoom: {
        code: 'A',
        roomType: 'CUTTING'
      }
    };
    packOrdersResources.getPackOrders(room, successCallback);

    moxios.wait(() => {
      let request = moxios.requests.mostRecent();
      request
        .respondWith({
          status: 200,
          response: 'data'
        })
        .then(response => {
          jestExpect(successCallback).toBeCalledWith(response);
          jestExpect(request.config.method).toEqual('get');
          jestExpect(request.config.url).toEqual('/api/cut-orders?status=to-pack&room-code=A');
          jestExpect(request.config.headers).toEqual(
            jestExpect.objectContaining({ 'Content-Type': 'application/json' })
          );
          done();
        });
    });
  });

  test('should get pack orders for table 19 in grinding room A', done => {
    const room = {
      currentPortionRoom: {
        code: 'A',
        roomType: 'GRINDING'
      }
    };
    packOrdersResources.getPackOrders(room, successCallback);

    moxios.wait(() => {
      let request = moxios.requests.mostRecent();
      request
        .respondWith({
          status: 200,
          response: 'data'
        })
        .then(response => {
          jestExpect(successCallback).toBeCalledWith(response);
          jestExpect(request.config.method).toEqual('get');
          jestExpect(request.config.url).toEqual('/api/orders/grind?status=to-pack&room-code=A');
          jestExpect(request.config.headers).toEqual(
            jestExpect.objectContaining({ 'Content-Type': 'application/json' })
          );
          done();
        });
    });
  });

  test('should check cut order exists for cut ticket code and room', async () => {
    moxios.wait(() => {
      const request = moxios.requests.mostRecent();
      request.respondWith({
        status: 200,
        response: 'data'
      });
    });

    const cutTicketCode = 'C1207920123';
    const roomCode = 'A';

    await packOrdersResources.checkPackOrderExistsForCutTicketAndRoom(cutTicketCode, roomCode);
    const request = moxios.requests.mostRecent();

    jestExpect(request.config.method).toEqual('get');
    jestExpect(request.config.url).toEqual(
      `/api/cut-orders/ticket/${cutTicketCode}/room/${roomCode}`
    );
    jestExpect(request.config.headers).toEqual(
      jestExpect.objectContaining({ 'Content-Type': 'application/json' })
    );
  });

  test('should check grind order exists for grind ticket code and room', async () => {
    moxios.wait(() => {
      const request = moxios.requests.mostRecent();
      request.respondWith({
        status: 200,
        response: 'data'
      });
    });

    const grindTicketCode = 'G01112181916172A';
    const roomCode = 'A';

    await packOrdersResources.checkPackOrderExistsForGrindTicketAndRoom(grindTicketCode, roomCode);
    const request = moxios.requests.mostRecent();

    jestExpect(request.config.method).toEqual('get');
    jestExpect(request.config.url).toEqual(
      `/api/orders/grind/ticket/${grindTicketCode}/room/${roomCode}`
    );
    jestExpect(request.config.headers).toEqual(
      jestExpect.objectContaining({ 'Content-Type': 'application/json' })
    );
  });

  test('should pack off order with pack order info', () => {
    moxios.wait(() => {
      const request = moxios.requests.mostRecent();
      request.respondWith({
        status: 200,
        response: 'data'
      });
    });

    return packOrdersResources
      .packOrder({
        cutOrderId: 134,
        weight: '13.40',
        packagingTare: '1.10',
        productCode: 'ABCDEFG'
      })
      .then(() => {
        const request = moxios.requests.mostRecent();
        jestExpect(request.config.method).toEqual('post');
        jestExpect(request.config.url).toEqual('/api/boxes');
        jestExpect(request.config.headers).toEqual(
          jestExpect.objectContaining({ 'Content-Type': 'application/json' })
        );
        jestExpect(JSON.parse(request.config.data)).toEqual({
          cutOrderId: 134,
          weight: '13.40',
          packagingTare: '1.10',
          productCode: 'ABCDEFG',
          packType: 'NORMAL'
        });
      });
  });

  test('should call rejection callback when request unsuccessful', () => {
    moxios.wait(() => {
      let request = moxios.requests.mostRecent();
      request.respondWith({
        status: 422,
        response: 'data'
      });
    });

    return packOrdersResources.packOrder({ payload: 'TEST_PAYLOAD' }).catch(error => {
      jestExpect(error.response.status).toEqual(422);
    });
  });

  test('should pack off stock with stock info', () => {
    moxios.wait(() => {
      const request = moxios.requests.mostRecent();
      request.respondWith({
        status: 200,
        response: 'data'
      });
    });

    return packOrdersResources.packOffStock({ key: 'value' }).then(() => {
      const request = moxios.requests.mostRecent();
      jestExpect(request.config.method).toEqual('post');
      jestExpect(request.config.url).toEqual('/api/boxes/stock');
      jestExpect(request.config.headers).toEqual(
        jestExpect.objectContaining({ 'Content-Type': 'application/json' })
      );
      jestExpect(JSON.parse(request.config.data)).toEqual({ key: 'value' });
    });
  });

  test('should pack off WIP box with incomplete box info', () => {
    moxios.wait(() => {
      const request = moxios.requests.mostRecent();
      request.respondWith({
        status: 200,
        response: 'data'
      });
    });

    return packOrdersResources.packOffWIPBox({ key: 'value' }).then(() => {
      const request = moxios.requests.mostRecent();
      jestExpect(request.config.method).toEqual('post');
      jestExpect(request.config.url).toEqual('/api/boxes/pack-wip');
      jestExpect(request.config.headers).toEqual(
        jestExpect.objectContaining({ 'Content-Type': 'application/json' })
      );
      jestExpect(JSON.parse(request.config.data)).toEqual({
        key: 'value'
      });
    });
  });

  test('should get order to pack given cut order id', () => {
    moxios.wait(() => {
      let request = moxios.requests.mostRecent();
      request.respondWith({
        status: 200,
        response: 'data'
      });
    });

    return packOrdersResources.getOrderToPack(142).then(() => {
      const request = moxios.requests.mostRecent();
      jestExpect(request.config.method).toEqual('get');
      jestExpect(request.config.url).toEqual('/api/cut-orders/142');
      jestExpect(request.config.headers).toEqual(
        jestExpect.objectContaining({ 'Content-Type': 'application/json' })
      );
    });
  });

  test('should complete banquet order', async () => {
    moxios.wait(() => {
      const request = moxios.requests.mostRecent();
      request.respondWith({
        status: 200,
        response: 'data'
      });
    });

    await packOrdersResources.completeBanquetOrder(73);
    const request = moxios.requests.mostRecent();

    jestExpect(request.config.method).toEqual('post');
    jestExpect(request.config.url).toEqual('/api/cut-orders/73/banquet/complete');
    jestExpect(request.config.headers).toEqual(
      jestExpect.objectContaining({ 'Content-Type': 'application/json' })
    );
  });
});
