import moxios from 'moxios';
import cutStationSummaryResources from '../cutStationSummaryResources';

describe('cutStationSummaryResources', () => {
  let successCallback;

  beforeEach(() => {
    successCallback = jest.fn();
    moxios.install();
  });

  afterEach(() => {
    moxios.uninstall();
  });

  test('should get cut station summary', done => {
    cutStationSummaryResources.getCutStationSummary('A', successCallback);

    moxios.wait(() => {
      let request = moxios.requests.mostRecent();
      request
        .respondWith({
          status: 200,
          response: 'data'
        })
        .then(response => {
          jestExpect(successCallback).toHaveBeenCalledWith(response);
          jestExpect(request.config).toMatchObject({
            method: 'get',
            url: '/api/cut-orders/summary/stations',
            params: { 'room-code': 'A' },
            headers: { 'Content-Type': 'application/json' }
          });
          done();
        });
    });
  });
});
