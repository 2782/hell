import moxios from 'moxios';
import portionRoomTableResources from '../portionRoomTableResources';

describe('portionRoomTableResources', () => {
  let successCallback;

  beforeEach(() => {
    successCallback = jest.fn();
    moxios.install();
  });

  afterEach(() => {
    moxios.uninstall();
  });

  test('should get portion room table for given table id', done => {
    portionRoomTableResources.getPortionRoomTable(14, successCallback);

    moxios.wait(() => {
      let request = moxios.requests.mostRecent();
      request
        .respondWith({
          status: 200,
          response: 'data'
        })
        .then(response => {
          jestExpect(successCallback).toHaveBeenCalledWith(response);
          jestExpect(request.config.method).toEqual('get');
          jestExpect(request.config.url).toEqual('/api/portion-room-tables/14');
          jestExpect(request.config.headers).toMatchObject({ 'Content-Type': 'application/json' });
          done();
        });
    });
  });
});
