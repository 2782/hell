import moxios from 'moxios';
import changelogResources from '../changelogResources';

describe('changelogResources', () => {
  beforeEach(() => {
    moxios.install();
  });

  afterEach(() => {
    moxios.uninstall();
  });

  describe('Cutting yield model change log', () => {
    test('should search cutting yield model change log with sort applied', done => {
      changelogResources.getCuttingYieldModelChangelog({
        finishedProductCode: '1234567',
        sourceProductCode: '1961172',
        page: 12,
        startDate: '2019-08-11',
        endDate: '2019-08-11',
        sortColumn: 'COLUMN_TO_SORT',
        sortDirection: 'COLUMN_SORT_DIRECTION'
      });

      moxios.wait(() => {
        let request = moxios.requests.mostRecent();
        request
          .respondWith({
            status: 200,
            response: 'data'
          })
          .then(() => {
            jestExpect(request.config).toMatchObject({
              method: 'get',
              url: '/api/cutting-yield-model-change-log',
              params: {
                'finished-product-code': '1234567',
                'source-product-code': '1961172',
                startDate: '2019-08-11',
                endDate: '2019-08-11',
                page: 12,
                size: 20,
                sort: 'COLUMN_TO_SORT,COLUMN_SORT_DIRECTION'
              }
            });
            done();
          });
      });
    });

    test('should search cutting yield model change log with user id and field name and with sort applied ', done => {
      changelogResources.getCuttingYieldModelChangelog({
        finishedProductCode: '1234567',
        sourceProductCode: '1961172',
        page: 12,
        startDate: '2019-08-11',
        endDate: '2019-08-11',
        userId: 'avir3442',
        fieldNames: 'ADDITIVES',
        sortColumn: 'COLUMN_TO_SORT',
        sortDirection: 'COLUMN_SORT_DIRECTION'
      });

      moxios.wait(() => {
        let request = moxios.requests.mostRecent();
        request
          .respondWith({
            status: 200,
            response: 'data'
          })
          .then(() => {
            jestExpect(request.config).toMatchObject({
              method: 'get',
              url: '/api/cutting-yield-model-change-log',
              params: {
                'finished-product-code': '1234567',
                'source-product-code': '1961172',
                startDate: '2019-08-11',
                endDate: '2019-08-11',
                userId: 'avir3442',
                'field-names': 'ADDITIVES',
                page: 12,
                size: 20,
                sort: 'COLUMN_TO_SORT,COLUMN_SORT_DIRECTION'
              }
            });
            done();
          });
      });
    });

    test('should search cutting yield model change log for user ids', done => {
      changelogResources.getAllUniqueUserIdNamesForCutting({
        finishedProductCode: '1234567',
        sourceProductCode: '1961172',
        startDate: '2019-08-11',
        endDate: '2019-08-11'
      });

      moxios.wait(() => {
        let request = moxios.requests.mostRecent();
        request
          .respondWith({
            status: 200,
            response: 'data'
          })
          .then(() => {
            jestExpect(request.config).toMatchObject({
              method: 'get',
              url: '/api/cutting-yield-model-change-log/user-ids',
              params: {
                'finished-product-code': '1234567',
                'source-product-code': '1961172',
                startDate: '2019-08-11',
                endDate: '2019-08-11'
              }
            });
            done();
          });
      });
    });

    test('should search cutting yield model change log for field names', done => {
      changelogResources.getAllUniqueFieldNamesForCutting({
        finishedProductCode: '1234567',
        sourceProductCode: '1961172',
        startDate: '2019-08-11',
        endDate: '2019-08-11'
      });

      moxios.wait(() => {
        let request = moxios.requests.mostRecent();
        request
          .respondWith({
            status: 200,
            response: 'data'
          })
          .then(() => {
            jestExpect(request.config).toMatchObject({
              method: 'get',
              url: '/api/cutting-yield-model-change-log/field-names',
              params: {
                'finished-product-code': '1234567',
                'source-product-code': '1961172',
                startDate: '2019-08-11',
                endDate: '2019-08-11'
              }
            });
            done();
          });
      });
    });

    test('should search cutting yield model change log dates', done => {
      changelogResources.getCuttingYieldModelChangelogDates({
        finishedProductCode: '1234567',
        sourceProductCode: '1961172'
      });

      moxios.wait(() => {
        let request = moxios.requests.mostRecent();
        request
          .respondWith({
            status: 200,
            response: 'data'
          })
          .then(() => {
            jestExpect(request.config).toMatchObject({
              method: 'get',
              url: '/api/cutting-yield-model-change-log/dates',
              params: {
                'finished-product-code': '1234567',
                'source-product-code': '1961172'
              }
            });
            done();
          });
      });
    });
  });

  describe('All Cutting Pricing yield model change log', () => {
    test('should search all cutting pricing yield model change log with sort applied', done => {
      changelogResources.getAllCuttingPricingYieldModelChangelog({
        page: 12,
        startDate: '2019-08-11',
        endDate: '2019-08-11',
        sortColumn: 'COLUMN_TO_SORT',
        sortDirection: 'COLUMN_SORT_DIRECTION'
      });

      moxios.wait(() => {
        let request = moxios.requests.mostRecent();
        request
          .respondWith({
            status: 200,
            response: 'data'
          })
          .then(() => {
            jestExpect(request.config).toMatchObject({
              method: 'get',
              url: '/api/all-cutting-yield-model-change-log',
              params: {
                startDate: '2019-08-11',
                endDate: '2019-08-11',
                'finished-product-code': '',
                page: 12,
                size: 20,
                sort: 'COLUMN_TO_SORT,COLUMN_SORT_DIRECTION'
              }
            });
            done();
          });
      });
    });

    test(
      'should search cutting pricing yield model change log with user id, field name, finished product ' +
        'code with sort applied ',
      done => {
        changelogResources.getAllCuttingPricingYieldModelChangelog({
          page: 12,
          startDate: '2019-08-11',
          endDate: '2019-08-11',
          userId: 'avir3442',
          finishedProductCode: '1961172',
          fieldNames: 'ADDITIVES',
          sortColumn: 'COLUMN_TO_SORT',
          sortDirection: 'COLUMN_SORT_DIRECTION'
        });

        moxios.wait(() => {
          let request = moxios.requests.mostRecent();
          request
            .respondWith({
              status: 200,
              response: 'data'
            })
            .then(() => {
              jestExpect(request.config).toMatchObject({
                method: 'get',
                url: '/api/all-cutting-yield-model-change-log',
                params: {
                  startDate: '2019-08-11',
                  endDate: '2019-08-11',
                  userId: 'avir3442',
                  'field-names': 'ADDITIVES',
                  'finished-product-code': '1961172',
                  page: 12,
                  size: 20,
                  sort: 'COLUMN_TO_SORT,COLUMN_SORT_DIRECTION'
                }
              });
              done();
            });
        });
      }
    );

    test('should search all cutting yield pricing model change log for user ids', done => {
      changelogResources.getAllUniqueUserIdNamesForAllCuttingPricing({
        startDate: '2019-08-11',
        endDate: '2019-08-11'
      });

      moxios.wait(() => {
        let request = moxios.requests.mostRecent();
        request
          .respondWith({
            status: 200,
            response: 'data'
          })
          .then(() => {
            jestExpect(request.config).toMatchObject({
              method: 'get',
              url: '/api/all-cutting-yield-model-change-log/user-ids',
              params: {
                startDate: '2019-08-11',
                endDate: '2019-08-11'
              }
            });
            done();
          });
      });
    });

    test('should search all cutting pricing yield model change log dates', done => {
      changelogResources.getAllCuttingPricingYieldModelChangelogDates();

      moxios.wait(() => {
        let request = moxios.requests.mostRecent();
        request
          .respondWith({
            status: 200,
            response: 'data'
          })
          .then(() => {
            jestExpect(request.config).toMatchObject({
              method: 'get',
              url: '/api/all-cutting-yield-model-change-log/dates'
            });
            done();
          });
      });
    });

    test('should search cutting yield model change log for field names', done => {
      changelogResources.getAllUniqueFieldNamesForAllCuttingPricing({
        startDate: '2019-08-11',
        endDate: '2019-08-11'
      });

      moxios.wait(() => {
        let request = moxios.requests.mostRecent();
        request
          .respondWith({
            status: 200,
            response: 'data'
          })
          .then(() => {
            jestExpect(request.config).toMatchObject({
              method: 'get',
              url: '/api/all-cutting-yield-model-change-log/field-names',
              params: {
                startDate: '2019-08-11',
                endDate: '2019-08-11'
              }
            });
            done();
          });
      });
    });
  });

  describe('Grinding yield model change log', () => {
    test('should search grinding yield model change log for user ids', done => {
      const blend = 'BLEND1-1014';
      const sourceProductCodes = '1961172';
      changelogResources.getAllUniqueUserIdNamesForGrinding({
        blend,
        sourceProductCodes,
        startDate: '2019-08-11',
        endDate: '2019-08-11'
      });

      moxios.wait(() => {
        let request = moxios.requests.mostRecent();
        request
          .respondWith({
            status: 200,
            response: 'data'
          })
          .then(() => {
            jestExpect(request.config).toMatchObject({
              method: 'get',
              url: '/api/grinding-yield-model-change-log/user-ids',
              params: {
                blend,
                'source-product-codes': sourceProductCodes,
                startDate: '2019-08-11',
                endDate: '2019-08-11'
              }
            });
            done();
          });
      });
    });

    test('should search grinding yield model change log for field names', done => {
      const blend = 'BLEND1-1014';
      const sourceProductCodes = '1961172';
      changelogResources.getAllUniqueUserIdNamesForGrinding({
        blend,
        sourceProductCodes,
        startDate: '2019-08-11',
        endDate: '2019-08-11'
      });

      moxios.wait(() => {
        let request = moxios.requests.mostRecent();
        request
          .respondWith({
            status: 200,
            response: 'data'
          })
          .then(() => {
            jestExpect(request.config).toMatchObject({
              method: 'get',
              url: '/api/grinding-yield-model-change-log/user-ids',
              params: {
                blend,
                'source-product-codes': sourceProductCodes,
                startDate: '2019-08-11',
                endDate: '2019-08-11'
              }
            });
            done();
          });
      });
    });

    test('should search grinding yield model change log with sort applied', done => {
      changelogResources.getGrindingYieldModelChangelog({
        blend: 'NATURAL',
        sourceProductCodes: '1961172',
        page: 12,
        startDate: '2019-08-11',
        endDate: '2019-08-11',
        sortColumn: 'COLUMN_TO_SORT',
        sortDirection: 'COLUMN_SORT_DIRECTION',
        userId: 'user-1'
      });

      moxios.wait(() => {
        let request = moxios.requests.mostRecent();
        request
          .respondWith({
            status: 200,
            response: 'data'
          })
          .then(() => {
            jestExpect(request.config).toMatchObject({
              method: 'get',
              url: '/api/grinding-yield-model-change-log',
              params: {
                blend: 'NATURAL',
                'source-product-codes': '1961172',
                startDate: '2019-08-11',
                endDate: '2019-08-11',
                page: 12,
                size: 20,
                sort: 'COLUMN_TO_SORT,COLUMN_SORT_DIRECTION',
                userId: 'user-1'
              }
            });
            done();
          });
      });
    });

    test('should search yield model grinding change log dates', done => {
      changelogResources.getGrindingYieldModelChangelogDates({
        blend: 'NATURAL',
        sourceProductCodes: '1961172,'
      });

      moxios.wait(() => {
        let request = moxios.requests.mostRecent();
        request
          .respondWith({
            status: 200,
            response: 'data'
          })
          .then(() => {
            jestExpect(request.config).toMatchObject({
              method: 'get',
              url: '/api/grinding-yield-model-change-log/dates',
              params: {
                blend: 'NATURAL',
                'source-product-codes': '1961172,'
              }
            });
            done();
          });
      });
    });
  });
});
