import moxios from 'moxios';
import operatingDatesResource from '../operatingDatesResource';

describe('operatingDatesResource', () => {
  let successCallback;

  beforeEach(() => {
    successCallback = jest.fn();
    moxios.install();
  });

  afterEach(() => {
    moxios.uninstall();
  });

  test('should get operating dates', done => {
    operatingDatesResource.getOperatingDates('A', successCallback);

    moxios.wait(() => {
      let request = moxios.requests.mostRecent();
      request
        .respondWith({
          status: 200,
          response: 'data'
        })
        .then(response => {
          jestExpect(successCallback).toHaveBeenCalledWith(response);
          jestExpect(request.config).toMatchObject({
            method: 'get',
            url: '/api/operating-dates/A',
            headers: { 'Content-Type': 'application/json' }
          });
          done();
        });
    });
  });
});
