import axios from 'axios';
import config from '../../../../config/env';
import { CREATE_BATCH_MESSAGE, FINISH_BATCH_MESSAGE } from '../../../config/errorMessage';

const create = (data, successCallback, errorCallback) => {
  const request = axios({
    method: 'post',
    url: `${config.api.target}/api/batches`,
    headers: {
      'Content-type': 'application/json'
    },
    data: data
  });

  return request
    .then(response => successCallback(response))
    .catch(() => {
      errorCallback({ message: CREATE_BATCH_MESSAGE });
    });
};

const update = (data, successCallback, errorCallback) => {
  const request = axios({
    method: 'put',
    url: `${config.api.target}/api/batches/${data.id}`,
    headers: {
      'Content-type': 'application/json'
    },
    data: data
  });

  return request
    .then(response => successCallback(response))
    .catch(() => {
      errorCallback({ message: CREATE_BATCH_MESSAGE });
    });
};

const finishMarination = (data, successCallback, errorCallback) => {
  const request = axios({
    method: 'post',
    url: `${config.api.target}/api/batches/marination/finish`,
    headers: {
      'Content-type': 'application/json'
    },
    data: data
  });

  return request
    .then(response => successCallback(response))
    .catch(() => {
      errorCallback({ message: FINISH_BATCH_MESSAGE });
    });
};

const finishGrind = (data, successCallback, errorCallback) => {
  const request = axios({
    method: 'post',
    url: `${config.api.target}/api/batches/grind/finish`,
    headers: {
      'Content-type': 'application/json'
    },
    data: data
  });

  return request
    .then(response => successCallback(response))
    .catch(() => {
      errorCallback({ message: FINISH_BATCH_MESSAGE });
    });
};

const getBatchesByBlendNames = (blendNames, produceDate, callback) => {
  const request = axios({
    method: 'get',
    url: encodeURI(
      `${config.api.target}/api/batches?blend-names=${blendNames.join(
        ','
      )}&produce-date=${produceDate}`
    ),
    headers: {
      'Content-Type': 'application/json'
    }
  });

  request.then(response => {
    callback(response);
  });
};

const search = values => {
  return axios({
    method: 'get',
    url: `${config.api.target}/api/batches/criteria`,
    headers: {
      'Content-Type': 'application/json'
    },
    params: buildParams(values)
  });
};

const buildParams = values => {
  const keyMap = {
    finishedOrBlend: 'finished-or-blend',
    productionDateEnd: 'end-production-date',
    productionDateStart: 'start-production-date',
    sourceNumber: 'source-number',
    sourcePurchaseOrderNumber: 'source-po-number'
  };

  const params = {};

  Object.keys(values).forEach(key => {
    params[keyMap[key]] = values[key];
  });

  return params;
};

export default {
  create,
  update,
  finishMarination,
  finishGrind,
  getBatchesByBlendNames,
  search
};
