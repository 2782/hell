import config from '../../../../config/env';
import axios from 'axios';

export const getCostByProductCode_promise = productCode => {
  return axios({
    method: 'get',
    url: `${config.api.target}/api/cost/${productCode}`,
    headers: {
      'Content-type': 'application/json'
    }
  });
};

export const uploadCosts = costsData => {
  return axios({
    method: 'post',
    url: `${config.api.target}/api/costs`,
    headers: {
      'Content-type': 'application/json'
    },
    data: costsData
  });
};

export const getCostByProductCode = (productCode, callback) => {
  const request = getCostByProductCode_promise(productCode);

  request.then(response => callback(response.data));
};

export default {
  getCostByProductCode,
  uploadCosts
};
