import config from '../../../../config/env';
import axios from 'axios';

const getFutureLineItems = (roomCode, callback) => {
  const request = axios({
    method: 'get',
    url: `${config.api.target}/api/line-items/future-items`,
    headers: {
      'Content-type': 'application/json'
    },
    params: {
      'room-code': roomCode
    }
  });

  return request.then(response => {
    callback(response);
  });
};

const scheduleFutureOrdersToProduceToday = (values, callback) => {
  const request = axios({
    method: 'post',
    url: `${config.api.target}/api/line-items/future-items/schedule`,
    headers: {
      'Content-type': 'application/json'
    },
    data: values
  });

  return request.then(response => {
    callback(response);
  });
};

export default {
  getFutureLineItems,
  scheduleFutureOrdersToProduceToday
};
