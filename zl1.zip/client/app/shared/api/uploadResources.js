import axios from 'axios';
import config from '../../../../config/env';

const loadYieldModels = yieldModels => {
  return axios({
    method: 'post',
    url: `${config.api.target}/api/yield-models/cutting`,
    data: yieldModels,
    headers: {
      'Content-type': 'application/json'
    }
  });
};

export default {
  loadYieldModels
};
