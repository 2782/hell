import config from '../../../../config/env';
import axios from 'axios';

const getStation = (stationId, callback) => {
  const request = axios({
    method: 'get',
    url: `${config.api.target}/api/stations/${stationId}`,
    headers: {
      'Content-type': 'application/json'
    }
  });

  return request.then(response => {
    callback(response);
  });
};

const getStationsByRoom = roomCode => {
  return axios({
    method: 'get',
    url: `${config.api.target}/api/stations`,
    headers: {
      'Content-type': 'application/json'
    },
    params: {
      'room-code': roomCode
    }
  });
};

export default {
  getStation,
  getStationsByRoom
};
