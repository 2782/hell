import _ from 'lodash';
import config from '../../../../config/env';
import axios from 'axios';

const getProductInfo = (productCode, successCallback, rejectCallback) => {
  const request = getProductInfoPromise(productCode);

  return request.then(
    response => successCallback(response),
    error => rejectCallback(_.get(error, 'response.data', {}))
  );
};

const getProductInfoPromise = productCode => {
  return axios({
    method: 'get',
    url: `${config.api.target}/api/products/by-code?productCode=${encodeURI(productCode)}`,
    headers: {
      'Content-type': 'application/json'
    }
  });
};

export const loadProductGroups = productGroups => {
  return axios({
    method: 'post',
    url: `${config.api.target}/api/products/groups/load`,
    data: productGroups,
    headers: {
      'Content-type': 'application/json'
    }
  });
};

const createCuttingProductGroup = (productGroup, successCallback, rejectCallback) => {
  const request = axios({
    method: 'post',
    url: `${config.api.target}/api/products/group/cutting`,
    data: productGroup,
    headers: {
      'Content-type': 'application/json'
    }
  });

  return request.then(
    response => successCallback(response.data),
    error => rejectCallback(_.get(error, 'response.data', {}))
  );
};

const createGrindProductGroup = (productGroup, successCallback, rejectCallback) => {
  const request = axios({
    method: 'post',
    url: `${config.api.target}/api/products/group/grinding`,
    data: productGroup,
    headers: {
      'Content-type': 'application/json'
    }
  });

  return request.then(
    response => successCallback(response.data),
    error => rejectCallback(_.get(error, 'response.data', {}))
  );
};

const setupProduct = productSetup => {
  return axios({
    method: 'post',
    url: `${config.api.target}/api/products/setup`,
    data: productSetup,
    headers: {
      'Content-type': 'application/json'
    }
  });
};

const getAllergens = () => {
  return axios({
    method: 'get',
    url: `${config.api.target}/api/products/allergens`,
    headers: {
      'Content-type': 'application/json'
    }
  });
};

const getProductInfoByProductCodesPromise = productCodes => {
  return axios({
    method: 'get',
    url: `${config.api.target}/api/products?product-codes=${productCodes}`,
    headers: {
      'Content-type': 'application/json'
    }
  });
};

const getProductInfoByProductCodes = (productCodes, successCallback, errorCallback) => {
  const request = getProductInfoByProductCodesPromise(productCodes);

  request.then(response => successCallback(response)).catch(error => errorCallback(error));
};

const getProductsByDescriptions = (descriptions, successCallback, errorCallback) => {
  const request = axios({
    method: 'get',
    url: `${config.api.target}/api/products/by-descriptions`,
    params: {
      descriptions: descriptions
    },
    headers: {
      'Content-type': 'application/json'
    }
  });

  return request.then(
    response => successCallback(response.data),
    error => errorCallback(_.get(error, 'response.data', {}))
  );
};

const lookupProductGroup = productGroupName => {
  return axios({
    method: 'get',
    url: encodeURI(`${config.api.target}/api/products/group/lookup`),
    params: {
      name: productGroupName
    },
    headers: {
      'Content-type': 'application/json'
    }
  });
};

export default {
  getAllergens,
  getProductInfo,
  getProductInfoPromise,
  createCuttingProductGroup,
  getProductInfoByProductCodes,
  getProductInfoByProductCodesPromise,
  setupProduct,
  createGrindProductGroup,
  getProductsByDescriptions,
  loadProductGroups,
  lookupProductGroup
};
