import config from '../../../../config/env';
import axios from 'axios';

const getCutTablesSummary = (roomCode, stationId, callback) => {
  const request = axios({
    method: 'get',
    url: `${config.api.target}/api/cut-orders/summary/tables`,
    headers: {
      'Content-type': 'application/json'
    },
    params: {
      status: 'to-cut',
      'station-id': stationId,
      'room-code': roomCode
    }
  });

  return request.then(response => {
    callback(response);
  });
};

export default {
  getCutTablesSummary
};
