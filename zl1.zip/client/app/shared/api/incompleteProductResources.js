import config from '../../../../config/env';
import axios from 'axios';

const getIncompleteProducts = () => {
  return axios({
    method: 'get',
    url: `${config.api.target}/api/products/incomplete`,
    headers: {
      'Content-type': 'application/json'
    }
  });
};

export default {
  getIncompleteProducts
};
