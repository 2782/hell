import axios from 'axios';
import config from '../../../../config/env';
import _ from 'lodash';

const getAllBoxTypes = callback => {
  const request = axios({
    method: 'get',
    url: `${config.api.target}/api/package/box-types`,
    headers: {
      'Content-Type': 'application/json'
    }
  });

  request.then(response => callback(response));
};

const getAllFilmTypes = callback => {
  const request = axios({
    method: 'get',
    url: `${config.api.target}/api/package/film-types`,
    headers: {
      'Content-Type': 'application/json'
    }
  });

  request.then(response => callback(response));
};

const createTarePackage = (values, successCallback, rejectCallback) => {
  const request = axios({
    method: 'post',
    url: `${config.api.target}/api/package/tare-packages`,
    headers: {
      'Content-Type': 'application/json'
    },
    data: { ...values }
  });

  return request
    .then(response => successCallback(response.data))
    .catch(error => {
      if (error) {
        rejectCallback(_.get(error, 'response.data', {}));
      }
    });
};

const getAllTarePackages = callback => {
  const request = axios({
    method: 'get',
    url: `${config.api.target}/api/package/tare-packages`,
    headers: {
      'Content-Type': 'application/json'
    }
  });

  request.then(response => callback(response));
};

const getTarePackage = (tareId, successCallback) => {
  const request = axios({
    method: 'get',
    url: `${config.api.target}/api/package/tare-package/${tareId}`,
    headers: {
      'Content-Type': 'application/json'
    }
  });

  request.then(response => successCallback(response));
};

const getDefaultTarePackage = successCallback => {
  const request = axios({
    method: 'get',
    url: `${config.api.target}/api/package/tare-package/default`,
    headers: {
      'Content-Type': 'application/json'
    }
  });

  request.then(response => successCallback(response));
};

export default {
  getAllBoxTypes,
  getAllFilmTypes,
  createTarePackage,
  getAllTarePackages,
  getDefaultTarePackage,
  getTarePackage
};
