import config from '../../../../config/env';
import axios from 'axios';

const getActiveFiscalCalendar = callback => {
  const request = axios({
    method: 'get',
    url: `${config.api.target}/api/fiscal-calendar/active`,
    headers: {
      'Content-type': 'application/json'
    }
  });

  return request.then(response => {
    callback(response);
  });
};

const getAllFiscalCalendars = callback => {
  const request = axios({
    method: 'get',
    url: `${config.api.target}/api/fiscal-calendar`,
    headers: {
      'Content-type': 'application/json'
    }
  });

  return request.then(response => {
    callback(response);
  });
};

const updateActiveFiscalCalendar = (data, successCallback, rejectCallback) => {
  const request = axios({
    method: 'put',
    url: `${config.api.target}/api/fiscal-calendar/${data.id}`,
    headers: {
      'Content-type': 'application/json'
    },
    data: data
  });

  return request.then(response => successCallback(response), error => rejectCallback(error));
};

export default {
  getActiveFiscalCalendar,
  updateActiveFiscalCalendar,
  getAllFiscalCalendars
};
