import React from 'react';
import * as _ from 'lodash';
import { Table } from 'semantic-ui-react';
import DotDotDot from 'react-dotdotdot';
import PropTypes from 'prop-types';
import moment from 'moment';
import EmptyTableMessage from '../../shared/components/EmptyTableMessage';
import { formatDate } from '../../shared/util/dateUtil';

function cutOrderSelectedAt(cutOrder) {
  const cutSelectedAt = new moment(cutOrder.cutSelectedAt);
  return cutOrder.cutSelectedAt ? (
    <div>
      {cutSelectedAt.format('hh:mm')}
      <div className='cut-selected-at-sub-script'>{cutSelectedAt.format('A')}</div>
    </div>
  ) : null;
}

function groupByTableCode(cutOrders) {
  return _.groupBy(cutOrders, cutOrder => cutOrder.portionRoomTable.tableCode);
}

function calculateToWeight(qtyInBoxes, qtyPacked) {
  let quantityToWeight = qtyInBoxes - qtyPacked;
  return quantityToWeight >= 0 ? quantityToWeight : 0;
}

const renderCutOrdersOverviewContent = cutOrders => {
  return _.map(groupByTableCode(cutOrders), (groupedCutOrders, index) => {
    return (
      <Table.Body key={`cut-orders-content-${index}`}>
        <Table.Row>
          <Table.Cell colSpan={1} width={1} active>
            {index}
          </Table.Cell>
          <Table.Cell colSpan={15} width={15}>
            {groupedCutOrders[0].portionRoomTable.tableDescription}
          </Table.Cell>
        </Table.Row>
        {_.map(_.sortBy(groupedCutOrders, ['deliveryDate']), cutOrder => {
          const portionSize = cutOrder.product.productPortionSize.portionSize;
          const productInfo = `${cutOrder.product.code} / ${portionSize}`;
          const customerName = _.get(cutOrder, 'customerOrder.customer.name', '');
          const customerCode = _.get(cutOrder, 'customerOrder.customer.customerCode', '');

          return (
            <Table.Row error={cutOrder.cancelled} key={cutOrder.id}>
              <Table.Cell colSpan={5} width={5}>
                <div pid='cut-order-overview__product-info'>{productInfo}</div>
                <DotDotDot
                  clamp={1}
                  title={cutOrder.product.description}
                  pid='cut-order-overview__product-description'
                >
                  {cutOrder.product.description}
                </DotDotDot>
              </Table.Cell>
              <Table.Cell colSpan={4} width={4} title={customerName}>
                <DotDotDot pid='cut-order-overview__customer-name' clamp={1} title={customerName}>
                  {customerName}
                </DotDotDot>
                <div pid='cut-order-overview__customer-order-id'>{customerCode}</div>
              </Table.Cell>
              <Table.Cell
                textAlign='center'
                pid='cut-order-overview__station-code'
                colSpan={2}
                width={2}
              >
                {cutOrder.portionRoomTable.station.stationCode}
              </Table.Cell>
              <Table.Cell
                textAlign='center'
                pid='cut-order-overview__delivery-date'
                colSpan={1}
                width={1}
              >
                {formatDate(cutOrder.deliveryDate)}
              </Table.Cell>
              <Table.Cell
                textAlign='center'
                error={cutOrder.updated}
                pid='cut-order-overview__to-cut'
                colSpan={1}
                width={1}
              >
                {cutOrder.qtyInBoxes}
              </Table.Cell>
              <Table.Cell
                textAlign='center'
                pid='cut-order-overview__to-weigh'
                colSpan={1}
                width={1}
              >
                {calculateToWeight(cutOrder.qtyInBoxes, cutOrder.qtyPacked)}
              </Table.Cell>
              <Table.Cell
                textAlign='center'
                pid='cut-order-overview__start-at'
                colSpan={2}
                width={2}
              >
                {cutOrderSelectedAt(cutOrder)}
              </Table.Cell>
            </Table.Row>
          );
        })}
      </Table.Body>
    );
  });
};

const renderCutOrdersOverview = content => {
  return (
    <Table size='small' columns={16} fixed selectable>
      <Table.Header>
        <Table.Row>
          <Table.HeaderCell colSpan={5} width={5}>
            Product
          </Table.HeaderCell>
          <Table.HeaderCell colSpan={4} width={4}>
            Customer
          </Table.HeaderCell>
          <Table.HeaderCell textAlign='center' colSpan={2} width={2}>
            Station
          </Table.HeaderCell>
          <Table.HeaderCell textAlign='center' colSpan={1} width={1}>
            Ship
            <br />
            Date
          </Table.HeaderCell>
          <Table.HeaderCell textAlign='center' colSpan={1} width={1}>
            To Cut
          </Table.HeaderCell>
          <Table.HeaderCell textAlign='center' colSpan={1} width={1}>
            To Weigh
          </Table.HeaderCell>
          <Table.HeaderCell textAlign='center' colSpan={2} width={2}>
            Started
            <br />
            At
          </Table.HeaderCell>
        </Table.Row>
      </Table.Header>
      {content}
    </Table>
  );
};

const CutOrderOverviewTable = ({ cutOrders }) => {
  const content = renderCutOrdersOverviewContent(cutOrders);
  const overviewTable = renderCutOrdersOverview(content);

  return (
    <div>
      {cutOrders === null ? null : _.isEmpty(cutOrders) ? (
        <EmptyTableMessage className='prime-cut-order-overview-empty-message' />
      ) : (
        overviewTable
      )}
    </div>
  );
};

CutOrderOverviewTable.propTypes = {
  cutOrders: PropTypes.array
};

export default CutOrderOverviewTable;
