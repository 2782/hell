import _ from 'lodash';
import { SubmissionError } from 'redux-form';
import {
  isLessThanEqual,
  number,
  positiveNumber,
  validate,
  wholeNumber
} from '../../shared/formValidations';
import { HOUSE_PAR, LINE_ITEM } from '../../../config/orderSource';

export const validateSubmission = (values, props) => {
  const { futureOrders, grindHousePars } = props;

  let errors = {};
  _.each(futureOrders, item => {
    const toCutToday = _.get(values, `${item.itemId}-toCutToday`, null);
    const toGrindToday = _.get(values, `${item.itemId}-${LINE_ITEM}-toGrindToday`, null);
    if (toCutToday) {
      errors = validate(
        errors,
        toCutToday,
        `${item.itemId}-toCutToday`,
        [number, positiveNumber, wholeNumber, isLessThanEqual(item.quantityRemaining)],
        'Invalid Quantity'
      );
    }
    if (toGrindToday) {
      errors = validate(
        errors,
        toGrindToday,
        `${item.itemId}-${LINE_ITEM}-toGrindToday`,
        [number, positiveNumber, wholeNumber, isLessThanEqual(item.quantityRemaining)],
        'Invalid Quantity'
      );
    }
  });

  _.each(grindHousePars, par => {
    const field = `${par.id}-${HOUSE_PAR}-toGrindToday`;
    const toGrindTodayForHousePar = _.get(values, field, null);
    if (toGrindTodayForHousePar) {
      errors = validate(
        errors,
        toGrindTodayForHousePar,
        field,
        [number, positiveNumber, wholeNumber, isLessThanEqual(par.quantity)],
        'Invalid Quantity'
      );
    }
  });

  if (!_.isEmpty(errors)) {
    throw new SubmissionError(Object.assign({}, errors, { _error: 'Submission Failed!' }));
  }
};
