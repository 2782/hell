import React from 'react';
import PropTypes from 'prop-types';
import { Table, Form } from 'semantic-ui-react';
import _ from 'lodash';
import { formatDate } from '../../shared/util/dateUtil';
import DotDotDot from 'react-dotdotdot';
import { Field } from 'redux-form';
import FormElement from '../../shared/FormElement';

const FutureCutOrdersTableContent = ({ futureOrders, inputFocus }) => {
  return (
    <Table.Body>
      {_.map(futureOrders, (order, index) => {
        const portionSize = _.get(order, 'product.productPortionSize.portionSize', '');
        const productInfo = `${order.product.code} / ${portionSize}`;
        const stationCode = _.get(order, 'product.table.station.stationCode', '');
        const tableCode = _.get(order, 'product.table.tableCode', '');
        const shipDate = formatDate(_.get(order, 'customerOrder.shipDate', ''));
        const customerName = _.get(order, 'customerOrder.customer.name', '');
        const customerCode = _.get(order, 'customerOrder.customer.customerCode', '');

        const isFirstToProduceTodayField = index === 0;

        return (
          <Table.Row key={`future-orders-content-${order.product.code}-${index}`}>
            <Table.Cell collapsing>
              <div>{productInfo}</div>
              <DotDotDot clamp={1} title={order.product.description}>
                {order.product.description}
              </DotDotDot>
            </Table.Cell>
            <Table.Cell collapsing title={customerName}>
              <DotDotDot clamp={1} title={customerName}>
                {customerName}
              </DotDotDot>
              <div>{customerCode}</div>
            </Table.Cell>
            <Table.Cell collapsing textAlign={'right'}>
              {stationCode}
            </Table.Cell>
            <Table.Cell collapsing textAlign={'right'}>
              {tableCode}
            </Table.Cell>
            <Table.Cell collapsing textAlign={'right'}>
              {shipDate}
            </Table.Cell>
            <Table.Cell collapsing textAlign={'right'}>
              {order.quantityRemaining}
            </Table.Cell>
            <Table.Cell collapsing className={'schedule-today'}>
              <Field
                width={10}
                component={FormElement}
                autoFocus={isFirstToProduceTodayField}
                withRef
                ref={isFirstToProduceTodayField ? inputFocus : null}
                name={`${order.itemId}-toCutToday`}
                as={Form.Input}
              />
            </Table.Cell>
          </Table.Row>
        );
      })}
    </Table.Body>
  );
};

FutureCutOrdersTableContent.propTypes = {
  futureOrders: PropTypes.array.isRequired,
  inputFocus: PropTypes.func.isRequired
};

export default FutureCutOrdersTableContent;
