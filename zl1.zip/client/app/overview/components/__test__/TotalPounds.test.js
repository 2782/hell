import React from 'react';
import { shallow } from 'enzyme';
import { TotalPounds, calculateTotalPounds } from '../TotalPounds';
import LineItemFactory from '../../../../test-factories/lineItemFactory';
import grindingOrderFactory from '../../../../test-factories/grindingOrderFactory';
import GrindingHouseParFactory from '../../../../test-factories/grindingHousePar';
import { LINE_ITEM, HOUSE_PAR } from '../../../../config/orderSource';

describe('calculate total pounds', () => {
  const noOverrides = [];

  test('should have 0 pounds for 0 orders', () => {
    const noOrders = [];

    jestExpect(calculateTotalPounds(noOrders, noOverrides)).toEqual(0);
  });

  test('should calculate weight for 1 order that has not been started', () => {
    const noOverrides = [];

    const futureOrders = [
      LineItemFactory.build({
        product: {
          weightPerBox: 12
        },
        quantity: 5,
        quantityInCases: 5,
        quantityRemaining: 5
      })
    ];

    const grindHousePars = [GrindingHouseParFactory.build()];

    const grindOrders = [];

    jestExpect(
      calculateTotalPounds(futureOrders, grindOrders, grindHousePars, noOverrides)
    ).toEqual(0);
  });

  test('should calculate weight for many orders that has been partially completed', () => {
    const futureOrders = [
      LineItemFactory.build({
        product: {
          weightPerBox: 12
        },
        quantity: 5,
        quantityInCases: 5,
        quantityRemaining: 2
      }),
      LineItemFactory.build({
        product: {
          weightPerBox: 8
        },
        quantity: 6,
        quantityInCases: 6,
        quantityRemaining: 4
      })
    ];

    const grindHousePars = [
      GrindingHouseParFactory.build({
        product: {
          weightPerBox: 12
        },
        quantity: 5
      })
    ];

    const grindOrders = [
      grindingOrderFactory.build({
        product: {
          weightPerBox: 12
        },
        qtyInBoxes: 3,
        status: 'TO_APPROVE'
      }),
      grindingOrderFactory.build({
        product: {
          weightPerBox: 8
        },
        qtyInBoxes: 2,
        status: 'TO_APPROVE'
      })
    ];

    jestExpect(
      calculateTotalPounds(futureOrders, grindOrders, grindHousePars, noOverrides)
    ).toEqual(52);
  });

  test('should calculate weight for an order that has unit pieces', () => {
    const futureOrders = [
      LineItemFactory.build({
        product: {
          weightPerBox: 10
        },
        quantity: 50,
        quantityInCases: 3,
        quantityRemaining: 3
      })
    ];
    const grindOrders = [];

    const grindHousePars = [];

    jestExpect(
      calculateTotalPounds(futureOrders, grindOrders, grindHousePars, noOverrides)
    ).toEqual(0);
  });

  test('should calculate weight when weight is fractional, and round up', () => {
    const futureOrders = [
      LineItemFactory.build({
        product: {
          weightPerBox: 12.34
        },
        quantity: 5,
        quantityInCases: 5,
        quantityRemaining: 2
      }),
      LineItemFactory.build({
        product: {
          weightPerBox: 8
        },
        quantity: 6,
        quantityInCases: 6,
        quantityRemaining: 4
      })
    ];
    const grindHousePars = [GrindingHouseParFactory.build()];
    const scheduledGrindOrders = [
      grindingOrderFactory.build({
        product: {
          weightPerBox: 12.34
        },
        qtyInBoxes: 3,
        status: 'TO_APPROVE'
      }),
      grindingOrderFactory.build({
        product: {
          weightPerBox: 8
        },
        qtyInBoxes: 2,
        status: 'TO_APPROVE'
      })
    ];

    jestExpect(
      calculateTotalPounds(futureOrders, scheduledGrindOrders, grindHousePars, noOverrides)
    ).toEqual(54);
  });
});

describe('display total pounds', () => {
  test('should display 0 total pounds when there are no orders', () => {
    const noOrders = [];
    const noUserEdits = [];
    const wrapper = shallow(
      <TotalPounds futureOrders={noOrders} userProjectedQuantitiesRemaining={noUserEdits} />
    );

    jestExpect(wrapper.find('[pid="scheduledFutureOrders__totalPounds"]').text()).toEqual(
      'Total Planned Pounds: 0'
    );
  });

  test('should display total pounds nicely for big numbers', () => {
    const userEdits = [
      {
        itemId: 1,
        orderQuantityRemaining: '500',
        type: LINE_ITEM,
        quantityRemaining: 0
      }
    ];

    const wrapper = shallow(
      <TotalPounds
        futureOrders={[
          {
            itemId: 1,
            product: {
              weightPerBox: 120
            },
            quantity: 500,
            quantityInCases: 500,
            quantityRemaining: 500
          }
        ]}
        grindHousePars={[]}
        userProjectedQuantitiesRemaining={userEdits}
      />
    );

    jestExpect(wrapper.find('[pid="scheduledFutureOrders__totalPounds"]').text()).toEqual(
      'Total Planned Pounds: 60,000'
    );
  });

  test('should only calculate for orders that are not completed', () => {
    const userEdits = [
      {
        itemId: 1,
        orderQuantityRemaining: '1',
        type: LINE_ITEM,
        quantityRemaining: 499
      },
      {
        itemId: 2,
        orderQuantityRemaining: '12',
        type: HOUSE_PAR,
        quantityRemaining: 499
      }
    ];

    const orderWithQuantityRemaining = {
      itemId: 1,
      product: {
        weightPerBox: 120
      },
      quantity: 500,
      quantityInCases: 500,
      quantityRemaining: 500
    };

    const completedOrder = {
      itemId: 10,
      product: {
        weightPerBox: 10
      },
      quantity: 500,
      quantityInCases: 500,
      quantityRemaining: 0
    };

    const grindHousePars = [
      GrindingHouseParFactory.build({
        product: {
          weightPerBox: 12
        },
        quantity: 5,
        id: 2
      })
    ];

    const wrapper = shallow(
      <TotalPounds
        futureOrders={[orderWithQuantityRemaining, completedOrder]}
        grindHousePars={grindHousePars}
        grindOrders={[]}
        userProjectedQuantitiesRemaining={userEdits}
      />
    );

    jestExpect(wrapper.find('[pid="scheduledFutureOrders__totalPounds"]').text()).toEqual(
      'Total Planned Pounds: 264'
    );
  });
});
