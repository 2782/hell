import { mount } from 'enzyme';
import React from 'react';
import ScheduleFutureCutOrdersTable, { sort } from '../ScheduleFutureCutOrdersTable';
import semanticUI from '../../../../test-helpers/semantic-ui';
import EmptyListMessage from '../../../shared/components/EmptyListMessage';
import { formatDate, getFutureDate } from '../../../shared/util/dateUtil';
import LineItemFactory, { futureLineItems } from '../../../../test-factories/lineItemFactory';
import { Field, reduxForm } from 'redux-form';
import store from '../../../store';
import { Provider } from 'react-redux';
import { Input, Table } from 'semantic-ui-react';
import productFactory from '../../../../test-factories/productFactory';
import TableFactory from '../../../../test-factories/portionRoomTableFactory';
import StationFactory from '../../../../test-factories/station';
import CustomerOrderFactory from '../../../../test-factories/customerOrder';
import CustomerFactory from '../../../../test-factories/customerFactory';

describe('scheduleFutureCutOrdersTable', () => {
  let wrapper, Decorated;
  let updateTotalPoundsMock = jest.fn();
  let handleSortMock = jest.fn();

  beforeEach(() => {
    Decorated = reduxForm({ form: 'testForm' })(ScheduleFutureCutOrdersTable);

    wrapper = mount(
      <Provider store={store}>
        <Decorated
          handleSort={handleSortMock}
          futureOrders={futureLineItems}
          updateTotalPounds={updateTotalPoundsMock}
          inputFocus={() => {}}
        />
      </Provider>
    );
  });

  afterEach(() => {
    updateTotalPoundsMock.mockReset();
  });

  describe('sorting', () => {
    let unsortedOrders;

    beforeEach(() => {
      unsortedOrders = [
        LineItemFactory.build({
          id: 1,
          quantityRemaining: 15,
          customerOrder: CustomerOrderFactory.build({
            shipDate: formatDate(getFutureDate(2)),
            customer: CustomerFactory.build({ name: 'Elton' })
          }),
          product: productFactory.build({
            code: '4100158',
            table: TableFactory.build({
              tableCode: 9,
              station: StationFactory.build({ stationCode: 15 })
            })
          })
        }),
        LineItemFactory.build({
          id: 2,
          quantityRemaining: 9,
          customerOrder: CustomerOrderFactory.build({
            shipDate: formatDate(getFutureDate(1)),
            customer: CustomerFactory.build({ name: 'Jason' })
          }),
          product: productFactory.build({
            code: '0078891',
            table: TableFactory.build({
              tableCode: 4,
              station: StationFactory.build({ stationCode: 21 })
            })
          })
        }),
        LineItemFactory.build({
          id: 3,
          quantityRemaining: 28,
          customerOrder: CustomerOrderFactory.build({
            shipDate: formatDate(getFutureDate(3)),
            customer: CustomerFactory.build({ name: 'Brian' })
          }),
          product: productFactory.build({
            code: '0202014',
            table: TableFactory.build({
              tableCode: 4,
              station: StationFactory.build({ stationCode: 4 })
            })
          })
        }),
        LineItemFactory.build({
          id: 4,
          quantityRemaining: 7,
          customerOrder: CustomerOrderFactory.build({
            shipDate: formatDate(getFutureDate(1)),
            customer: CustomerFactory.build({ name: 'Molly' })
          }),
          product: productFactory.build({
            code: '0018555',
            table: TableFactory.build({
              tableCode: 2,
              station: StationFactory.build({ stationCode: 9 })
            })
          })
        }),
        LineItemFactory.build({
          id: 5,
          quantityRemaining: 2,
          customerOrder: CustomerOrderFactory.build({
            shipDate: formatDate(getFutureDate(2)),
            customer: CustomerFactory.build({ name: 'Jol' })
          }),
          product: productFactory.build({
            code: '0202014',
            table: TableFactory.build({
              tableCode: 7,
              station: StationFactory.build({ stationCode: 4 })
            })
          })
        })
      ];
    });

    test('should return orders in default sort when column is null', () => {
      const orders = sort(unsortedOrders, null, null);

      jestExpect(orders.map(order => order.id)).toEqual([4, 2, 3, 5, 1]);
    });

    test('should return orders in sorted by product first', () => {
      const orders = sort(unsortedOrders, 'product', null);

      jestExpect(orders.map(order => order.id)).toEqual([4, 2, 3, 5, 1]);
    });

    test('should return orders in sorted by quantity remaining first', () => {
      const orders = sort(unsortedOrders, 'quantityRemaining', null);

      jestExpect(orders.map(order => order.id)).toEqual([5, 4, 2, 1, 3]);
    });

    test('should return orders in sorted by customer first', () => {
      const orders = sort(unsortedOrders, 'customer', null);

      jestExpect(orders.map(order => order.id)).toEqual([3, 1, 2, 5, 4]);
    });

    test('should return orders in sorted by shipDate first', () => {
      const orders = sort(unsortedOrders, 'shipDate', null);

      jestExpect(orders.map(order => order.id)).toEqual([4, 2, 5, 1, 3]);
    });

    test('should return orders in sorted by table first', () => {
      const orders = sort(unsortedOrders, 'table', null);

      jestExpect(orders.map(order => order.id)).toEqual([4, 2, 3, 5, 1]);
    });

    test('should return orders in sorted by station first', () => {
      const orders = sort(unsortedOrders, 'station', null);

      jestExpect(orders.map(order => order.id)).toEqual([3, 5, 4, 1, 2]);
    });
  });

  test('should handle sort when each header is clicked', () => {
    wrapper
      .find(Table.HeaderCell)
      .at(0)
      .simulate('click');
    jestExpect(handleSortMock).toHaveBeenCalledWith('product');

    wrapper
      .find(Table.HeaderCell)
      .at(1)
      .simulate('click');
    jestExpect(handleSortMock).toHaveBeenCalledWith('customer');

    wrapper
      .find(Table.HeaderCell)
      .at(2)
      .simulate('click');
    jestExpect(handleSortMock).toHaveBeenCalledWith('station');

    wrapper
      .find(Table.HeaderCell)
      .at(3)
      .simulate('click');
    jestExpect(handleSortMock).toHaveBeenCalledWith('table');

    wrapper
      .find(Table.HeaderCell)
      .at(4)
      .simulate('click');
    jestExpect(handleSortMock).toHaveBeenCalledWith('shipDate');

    wrapper
      .find(Table.HeaderCell)
      .at(5)
      .simulate('click');
    jestExpect(handleSortMock).toHaveBeenCalledWith('quantityRemaining');
  });

  test('should render correct table count', () => {
    jestExpect(semanticUI.findTables(wrapper)).toHaveLength(1);
    jestExpect(wrapper.find('tbody')).toHaveLength(1);
  });

  test('should render correct table header for cutting future orders', () => {
    jestExpect(semanticUI.findTable(wrapper, 0).find('th')).toHaveLength(7);
    jestExpect(
      semanticUI
        .findTable(wrapper, 0)
        .find('th')
        .at(0)
    ).toHaveText('Product');
    jestExpect(
      semanticUI
        .findTable(wrapper, 0)
        .find('th')
        .at(1)
    ).toHaveText('Customer');
    jestExpect(
      semanticUI
        .findTable(wrapper, 0)
        .find('th')
        .at(2)
    ).toHaveText('Station');
    jestExpect(
      semanticUI
        .findTable(wrapper, 0)
        .find('th')
        .at(3)
    ).toHaveText('Table');
    jestExpect(
      semanticUI
        .findTable(wrapper, 0)
        .find('th')
        .at(4)
    ).toHaveText('Ship Date');
    jestExpect(
      semanticUI
        .findTable(wrapper, 0)
        .find('th')
        .at(5)
    ).toHaveText('Quantity Remaining');
    jestExpect(
      semanticUI
        .findTable(wrapper, 0)
        .find('th')
        .at(6)
    ).toHaveText('To Cut Today');
  });

  test('should render correct table content for cutting future orders and group by table code in order of product', () => {
    let sortedWrapper = mount(
      <Provider store={store}>
        <Decorated
          sortColumn={'product'}
          handleSort={handleSortMock}
          futureOrders={futureLineItems}
          updateTotalPounds={updateTotalPoundsMock}
          inputFocus={() => {}}
        />
      </Provider>
    );
    const futureCutItemTable = sortedWrapper.find('tbody').at(0);

    jestExpect(futureCutItemTable.find('tr')).toHaveLength(5);
    jestExpect(semanticUI.findTableColumnWithRowIndex(futureCutItemTable, 0, 0, 'td')).toHaveText(
      '0078889 / 7 OZQB, PRIME T-BONE STEAK 205'
    );
    jestExpect(semanticUI.findTableColumnWithRowIndex(futureCutItemTable, 0, 1, 'td')).toHaveText(
      'GRILLED CHEESE FACTORY99998'
    );
  });

  test('should render correct table content for cutting future orders and group by table code', () => {
    const futureWorkingDay01 = formatDate(getFutureDate(1));
    const futureCutItemTable = wrapper.find('tbody').at(0);

    jestExpect(futureCutItemTable.find('tr')).toHaveLength(5);
    jestExpect(semanticUI.findTableColumnWithRowIndex(futureCutItemTable, 0, 0, 'td')).toHaveText(
      '0079007 / 7 OZQB, PRIME T-BONE STEAK 205'
    );
    jestExpect(semanticUI.findTableColumnWithRowIndex(futureCutItemTable, 0, 1, 'td')).toHaveText(
      'GRILLED CHEESE FACTORY99998'
    );
    jestExpect(semanticUI.findTableColumnWithRowIndex(futureCutItemTable, 0, 2, 'td')).toHaveText(
      '3'
    );
    jestExpect(semanticUI.findTableColumnWithRowIndex(futureCutItemTable, 0, 3, 'td')).toHaveText(
      '97'
    );
    jestExpect(semanticUI.findTableColumnWithRowIndex(futureCutItemTable, 0, 4, 'td')).toHaveText(
      futureWorkingDay01
    );
    jestExpect(semanticUI.findTableColumnWithRowIndex(futureCutItemTable, 0, 5, 'td')).toHaveText(
      '10'
    );
    jestExpect(semanticUI.findTableColumnWithRowIndex(futureCutItemTable, 0, 6, 'td')).toHaveText(
      ''
    );

    jestExpect(semanticUI.findTableColumnWithRowIndex(futureCutItemTable, 4, 0, 'td')).toHaveText(
      '0078889 / 7 OZQB, PRIME T-BONE STEAK 205'
    );
    jestExpect(semanticUI.findTableColumnWithRowIndex(futureCutItemTable, 4, 1, 'td')).toHaveText(
      'GRILLED CHEESE FACTORY99998'
    );
    jestExpect(semanticUI.findTableColumnWithRowIndex(futureCutItemTable, 4, 2, 'td')).toHaveText(
      '3'
    );
    jestExpect(semanticUI.findTableColumnWithRowIndex(futureCutItemTable, 4, 3, 'td')).toHaveText(
      '98'
    );
    jestExpect(semanticUI.findTableColumnWithRowIndex(futureCutItemTable, 4, 4, 'td')).toHaveText(
      futureWorkingDay01
    );
    jestExpect(semanticUI.findTableColumnWithRowIndex(futureCutItemTable, 4, 5, 'td')).toHaveText(
      '1'
    );
    jestExpect(semanticUI.findTableColumnWithRowIndex(futureCutItemTable, 4, 6, 'td')).toHaveText(
      ''
    );
  });

  test('should render correct row content for one cutting future orders', () => {
    const futureWorkingDay01 = formatDate(getFutureDate(1));

    const futureCutItemTable = wrapper.find('tbody').at(0);
    const futureCutItemTableRow = wrapper
      .find('tbody')
      .find('tr')
      .at(2);
    jestExpect(futureCutItemTableRow.find('td')).toHaveLength(7);
    jestExpect(semanticUI.findTableColumnWithRowIndex(futureCutItemTable, 4, 0, 'td')).toHaveText(
      '0078889 / 7 OZQB, PRIME T-BONE STEAK 205'
    );
    jestExpect(semanticUI.findTableColumnWithRowIndex(futureCutItemTable, 4, 1, 'td')).toHaveText(
      'GRILLED CHEESE FACTORY99998'
    );
    jestExpect(semanticUI.findTableColumnWithRowIndex(futureCutItemTable, 4, 2, 'td')).toHaveText(
      '3'
    );
    jestExpect(semanticUI.findTableColumnWithRowIndex(futureCutItemTable, 4, 3, 'td')).toHaveText(
      '98'
    );
    jestExpect(semanticUI.findTableColumnWithRowIndex(futureCutItemTable, 4, 4, 'td')).toHaveText(
      futureWorkingDay01
    );
    jestExpect(semanticUI.findTableColumnWithRowIndex(futureCutItemTable, 4, 5, 'td')).toHaveText(
      '1'
    );
    jestExpect(semanticUI.findTableColumnWithRowIndex(futureCutItemTable, 4, 6, 'td')).toHaveText(
      ''
    );
  });

  test('should set autoFocus to first to cut today field', () => {
    const futureCutItemTable = wrapper.find('tbody').at(0);
    jestExpect(futureCutItemTable.find('tr')).toHaveLength(5);
    jestExpect(
      semanticUI.findTableColumnWithRowIndex(futureCutItemTable, 0, 6, 'td').find(Input)
    ).toHaveProp('autoFocus', true);
    jestExpect(
      semanticUI.findTableColumnWithRowIndex(futureCutItemTable, 1, 6, 'td').find(Input)
    ).toHaveProp('autoFocus', false);
    jestExpect(
      semanticUI.findTableColumnWithRowIndex(futureCutItemTable, 2, 6, 'td').find(Input)
    ).toHaveProp('autoFocus', false);
  });

  test('should render future orders sorted by actual delivery date and quantity', () => {
    const futureWorkingDay01 = formatDate(getFutureDate(1));
    const futureWorkingDay02 = formatDate(getFutureDate(2));
    const futureWorkingDay03 = formatDate(getFutureDate(3));

    const futureOrderTable = wrapper.find('tbody').at(0);
    jestExpect(futureOrderTable.find('tr')).toHaveLength(5);
    jestExpect(semanticUI.findTableColumnWithRowIndex(futureOrderTable, 0, 4, 'td')).toHaveText(
      futureWorkingDay01
    );
    jestExpect(semanticUI.findTableColumnWithRowIndex(futureOrderTable, 0, 5, 'td')).toHaveText(
      '10'
    );
    jestExpect(semanticUI.findTableColumnWithRowIndex(futureOrderTable, 1, 4, 'td')).toHaveText(
      futureWorkingDay01
    );
    jestExpect(semanticUI.findTableColumnWithRowIndex(futureOrderTable, 1, 5, 'td')).toHaveText(
      '1'
    );
    jestExpect(semanticUI.findTableColumnWithRowIndex(futureOrderTable, 2, 4, 'td')).toHaveText(
      futureWorkingDay02
    );
    jestExpect(semanticUI.findTableColumnWithRowIndex(futureOrderTable, 3, 4, 'td')).toHaveText(
      futureWorkingDay03
    );
    jestExpect(semanticUI.findTableColumnWithRowIndex(futureOrderTable, 4, 4, 'td')).toHaveText(
      futureWorkingDay01
    );
  });

  test('should render empty list message when future orders are loading', () => {
    wrapper = mount(
      <ScheduleFutureCutOrdersTable
        futureOrders={null}
        inputFocus={() => {}}
        handleSort={() => {}}
      />
    );
    jestExpect(semanticUI.findTables(wrapper)).toHaveLength(0);
    jestExpect(wrapper.find(EmptyListMessage)).toExist();
  });

  test('should render empty list message when there are no future orders', () => {
    wrapper = mount(
      <ScheduleFutureCutOrdersTable futureOrders={[]} inputFocus={() => {}} handleSort={() => {}} />
    );
    jestExpect(semanticUI.findTables(wrapper)).toHaveLength(0);
    jestExpect(wrapper.find(EmptyListMessage)).toExist();
  });

  test('should render empty list message when there are future orders but no work to act on', () => {
    wrapper = mount(
      <ScheduleFutureCutOrdersTable
        futureOrders={[
          {
            quantityRemaining: 0
          }
        ]}
        inputFocus={() => {}}
        handleSort={() => {}}
      />
    );
    jestExpect(semanticUI.findTables(wrapper)).toHaveLength(0);
    jestExpect(wrapper.find(EmptyListMessage)).toExist();
  });

  test('should not call onBlur when is a cutting input field', () => {
    const firstField = wrapper.find(Field).at(0);

    firstField.simulate('blur');

    jestExpect(updateTotalPoundsMock).not.toHaveBeenCalled();
  });
});
