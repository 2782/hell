import React from 'react';
import { shallow } from 'enzyme';
import { Table } from 'semantic-ui-react';
import EmptyTableMessage from '../../../shared/components/EmptyTableMessage';
import CutOrderOverviewTable from '../CutOrderOverviewTable';
import {
  cutOrdersWithCustomerAndUserNameInStore,
  cutOrdersWithDifferentTableDescriptions
} from '../../../shared/testData/cutOrdersForTesting';
import moment from 'moment';
import semanticUI from '../../../../test-helpers/semantic-ui';

describe('CutOrderOverviewTable', () => {
  let wrapper;
  let timestamp = '2011-02-03T04:05:06.789';
  let shortTime = '04:05';
  let anteMeridian = 'AM';

  const cutOrders = cutOrdersWithCustomerAndUserNameInStore.map(cutOrder => ({
    ...cutOrder,
    cutSelectedAt: timestamp
  }));

  const cutOrderForToday = cutOrders[1];
  const cutOrderForTomorrow = cutOrders[0];

  beforeEach(() => {
    wrapper = mount(<CutOrderOverviewTable cutOrders={cutOrders} />);
  });

  test('should render header row', () => {
    const headerRow = semanticUI.findTable(wrapper, 0).find('th');

    jestExpect(headerRow.at(0)).toHaveText('Product');
    jestExpect(headerRow.at(1)).toHaveText('Customer');
    jestExpect(headerRow.at(2)).toHaveText('Station');
    jestExpect(headerRow.at(3)).toHaveText('ShipDate');
    jestExpect(headerRow.at(4)).toHaveText('To Cut');
    jestExpect(headerRow.at(5)).toHaveText('To Weigh');
    jestExpect(headerRow.at(6)).toHaveText('StartedAt');
  });

  test('should render cut order description', () => {
    const wrapperBody = wrapper.find(Table.Body);

    jestExpect(wrapperBody.find(Table.Row).at(0)).toIncludeText('Portion room table 77');
  });

  test('should render cutOrder1 second, and show product Info', () => {
    const wrapperBody = wrapper.find(Table.Body);
    const wrapperCutOrder1Row = wrapperBody.find(Table.Row).at(2);
    const portionSize = cutOrders[0].product.productPortionSize.portionSize;

    jestExpect(wrapperCutOrder1Row.find('[pid="cut-order-overview__product-info"]')).toHaveText(
      cutOrders[0].product.code + ' / ' + portionSize
    );
    jestExpect(
      wrapperCutOrder1Row.find('[pid="cut-order-overview__product-description"]')
    ).toHaveText(cutOrders[0].product.description);
  });

  test('should render cutOrder2 first, and show customer Info and addition details', () => {
    const wrapperBody = wrapper.find(Table.Body);
    const wrapperCutOrder2Row = wrapperBody.find(Table.Row).at(1);

    jestExpect(wrapperCutOrder2Row.find('[pid="cut-order-overview__customer-name"]')).toHaveText(
      cutOrders[1].customerOrder.customer.name
    );
    jestExpect(
      wrapperCutOrder2Row.find('[pid="cut-order-overview__customer-order-id"]')
    ).toHaveText(cutOrders[1].customerOrder.customer.customerCode);
    jestExpect(
      wrapperCutOrder2Row.find('[pid="cut-order-overview__station-code"]').at(0)
    ).toHaveText(cutOrders[1].portionRoomTable.station.stationCode.toString());
    jestExpect(
      wrapperCutOrder2Row.find('[pid="cut-order-overview__delivery-date"]').at(0)
    ).toHaveText(moment(cutOrders[1].deliveryDate).format('MM-DD'));
    jestExpect(wrapperCutOrder2Row.find('[pid="cut-order-overview__to-cut"]').at(0)).toHaveText(
      cutOrders[1].qtyInBoxes.toString()
    );
    jestExpect(wrapperCutOrder2Row.find('[pid="cut-order-overview__to-weigh"]').at(0)).toHaveText(
      (cutOrders[1].qtyInBoxes - cutOrders[1].qtyPacked).toString()
    );
    jestExpect(
      wrapperCutOrder2Row.find('[pid="cut-order-overview__start-at"]').at(0)
    ).toIncludeText(shortTime);
    jestExpect(
      wrapperCutOrder2Row.find('[pid="cut-order-overview__start-at"]').at(0)
    ).toIncludeText(anteMeridian);
  });

  test('should render cutOrder2 to-weigh cell to zero when qtyInBoxes - qtyPacked < 0 ', () => {
    const cutOrders = cutOrdersWithCustomerAndUserNameInStore.map(cutOrder => ({
      ...cutOrder,
      qtyInBoxes: 3,
      qtyPacked: 5
    }));

    let wrapper = mount(<CutOrderOverviewTable cutOrders={cutOrders} />);

    const wrapperBody = wrapper.find(Table.Body);
    const wrapperCutOrder2Row = wrapperBody.find(Table.Row).at(1);

    jestExpect(wrapperCutOrder2Row.find('[pid="cut-order-overview__to-weigh"]').at(0)).toHaveText(
      '0'
    );
  });

  test('should have orders sorted properly by date', () => {
    const wrapperBody = wrapper.find(Table.Body);

    jestExpect(
      wrapperBody
        .find(Table.Row)
        .at(1)
        .find('[pid="cut-order-overview__product-info"]')
    ).toIncludeText(cutOrderForToday.product.code);
    jestExpect(
      wrapperBody
        .find(Table.Row)
        .at(2)
        .find('[pid="cut-order-overview__product-info"]')
    ).toIncludeText(cutOrderForTomorrow.product.code);
  });

  test('should have orders grouped properly by table description', () => {
    const modifiedCutOrders = cutOrdersWithDifferentTableDescriptions.map(cutOrder => ({
      ...cutOrder,
      cutSelectedAt: timestamp
    }));

    wrapper = mount(<CutOrderOverviewTable cutOrders={modifiedCutOrders} />);
    const wrapperBody = wrapper.find(Table.Body);

    jestExpect(wrapperBody.find(Table.Row).at(0)).toIncludeText('Portion room table 77');
    jestExpect(wrapperBody.find(Table.Row).at(2)).toIncludeText('PORK');
  });

  test('should render Empty Table with no cutOrders', () => {
    const wrapper = shallow(<CutOrderOverviewTable cutOrders={[]} />);

    jestExpect(wrapper.find(EmptyTableMessage)).toExist();
  });

  test('should not render any table when cutOrders is null', () => {
    const wrapper = shallow(<CutOrderOverviewTable cutOrders={null} />);

    jestExpect(wrapper.find(EmptyTableMessage)).not.toExist();
    jestExpect(wrapper.find(Table)).not.toExist();
  });
});
