import React from 'react';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import { reduxForm } from 'redux-form';
import ScheduleFutureCutOrdersTable from '../components/ScheduleFutureCutOrdersTable';
import { SCHEDULE_FUTURE_ORDERS } from '../../shared/components/pageTitles';
import {
  clear,
  getFutureLineItems,
  scheduleFutureOrdersToProduceToday,
  handleSort,
  remainHoldOrdersQuantity,
  clearOnHoldOrdersQuantity
} from '../actions/orderOverviewActions';
import { changePath, setHeaderAndFooter, showModal } from '../../shared/actions/actions';
import { SCHEDULE_FUTURE_CUTTING_ORDERS_FOOTER } from '../../shared/components/pageFooters';
import { Button, Divider, Form } from 'semantic-ui-react';
import _ from 'lodash';
import { validateSubmission } from '../components/scheduleFutureOrdersFormValidator';
import { PortionRoomState } from '../../landingPage/reducers/portionRoomReducer';
import { POLLING_INTERVAL } from '../../shared/constants';

export const isActionable = orders => {
  if (!orders) {
    return false;
  } else if (0 === orders.map(o => o.quantityRemaining).reduce((a, b) => a + b, 0)) {
    return false;
  }
  return true;
};

export const SubmitButton = ({
  futureOrders,
  submitting,
  pristine,
  isApprovedForDay,
  roomIsDisabled
}) => {
  if (!isActionable(futureOrders)) {
    return null;
  }

  const disabled = (isApprovedForDay && !roomIsDisabled) || submitting || pristine;
  return (
    <Button primary size={'large'} loading={submitting} disabled={disabled}>
      Submit
    </Button>
  );
};
SubmitButton.propTypes = {
  futureOrders: PropTypes.array,
  submitting: PropTypes.bool.isRequired,
  pristine: PropTypes.bool.isRequired,
  isApprovedForDay: PropTypes.bool.isRequired,
  roomIsDisabled: PropTypes.bool.isRequired
};

export class ScheduleFutureCutOrdersComponent extends React.Component {
  constructor(props) {
    super(props);

    this.onSubmit = this.onSubmit.bind(this);
  }

  componentDidMount() {
    this.props.getFutureLineItems();
    this.props.setHeaderAndFooter({
      header: SCHEDULE_FUTURE_ORDERS,
      footer: SCHEDULE_FUTURE_CUTTING_ORDERS_FOOTER
    });
    this.ref.focus();

    this.intervalNumber = setInterval(() => {
      this.props.getFutureLineItems();
    }, POLLING_INTERVAL);
  }

  componentWillUnmount() {
    this.props.clear();
    clearInterval(this.intervalNumber);
  }

  onSubmit(values) {
    const { futureOrders, scheduleFutureOrdersToProduceToday, showModal } = this.props;

    validateSubmission(values, this.props);

    const submitValues = _.reduce(
      futureOrders,
      (result, item) => {
        const toProduceToday = _.get(values, `${item.itemId}-toCutToday`, 0);
        if (toProduceToday > 0) {
          result[item.itemId] = toProduceToday;
        }
        return result;
      },
      {}
    );

    const submitOrders = _.filter(futureOrders, futureOrder =>
      _.keys(submitValues).includes(futureOrder.itemId.toString())
    );
    const onHoldOrders = _.filter(submitOrders, submitOrder =>
      _.get(submitOrder, 'customerOrder.onHold', false)
    );

    if (!_.isEmpty(onHoldOrders)) {
      const onHoldCustomers = _.map(
        onHoldOrders,
        onHoldOrder => onHoldOrder.customerOrder.customer.customerCode
      );
      const onHoldCustomerIds = onHoldCustomers.join(', ');
      const warningMsgInMiddle = 'on credit hold. Are you sure you want to produce orders for';
      const onHoldOrderItemIds = _.map(onHoldOrders, onHoldOrder => onHoldOrder.itemId);
      const warningMsg =
        onHoldOrderItemIds.length > 1
          ? `Customers ${onHoldCustomerIds} are ${warningMsgInMiddle} these customers?`
          : `Customer ${onHoldCustomerIds} is ${warningMsgInMiddle} this customer?`;
      showModal({
        header: 'Customer on Credit Hold',
        content: warningMsg,
        cancelButton: 'No',
        cancelAction: () => {
          const holdOrders = _.pick(submitValues, onHoldOrderItemIds);
          const unHoldOrders = _.omit(submitValues, onHoldOrderItemIds);

          if (!_.isEmpty(unHoldOrders)) {
            scheduleFutureOrdersToProduceToday(unHoldOrders, () => this.resetForm(holdOrders));
          }
        },
        confirmButton: 'Yes',
        confirmAction: () =>
          scheduleFutureOrdersToProduceToday(submitValues, () => this.resetForm())
      });
    } else {
      scheduleFutureOrdersToProduceToday(submitValues, () => this.resetForm());
    }
  }

  resetForm(holdOrders) {
    this.props.getFutureLineItems(() => {
      this.props.reset();
      if (!_.isEmpty(holdOrders)) {
        this.props.remainHoldOrdersQuantity(holdOrders);
      }
      if (_.isUndefined(holdOrders)) {
        this.props.clearOnHoldOrdersQuantity();
      }
      this.firstInputReference.getRenderedComponent().focusInput();
    });
  }

  render() {
    const { handleSubmit, futureOrders } = this.props;

    return (
      <div
        className='page-content future-order-review-page'
        tabIndex='-1'
        ref={ref => (this.ref = ref)}
      >
        {futureOrders === null ? null : (
          <div>
            <Form size={'large'} onSubmit={handleSubmit(this.onSubmit)}>
              <ScheduleFutureCutOrdersTable
                {...this.props}
                inputFocus={ref => (this.firstInputReference = ref)}
              />

              <Divider hidden />

              <SubmitButton {...this.props} />
            </Form>
          </div>
        )}
      </div>
    );
  }
}

ScheduleFutureCutOrdersComponent.propTypes = {
  futureOrders: PropTypes.array,
  sortColumn: PropTypes.string,
  sortDirection: PropTypes.string,
  handleSort: PropTypes.func.isRequired,
  getFutureLineItems: PropTypes.func.isRequired,
  clear: PropTypes.func.isRequired,
  setHeaderAndFooter: PropTypes.func.isRequired,
  scheduleFutureOrdersToProduceToday: PropTypes.func.isRequired,
  remainHoldOrdersQuantity: PropTypes.func,
  currentAndNextWorkingDay: PropTypes.array,
  isApprovedForDay: PropTypes.bool,
  roomIsDisabled: PropTypes.bool,
  showModal: PropTypes.func,
  clearOnHoldOrdersQuantity: PropTypes.func,

  submitting: PropTypes.bool,
  pristine: PropTypes.bool,
  handleSubmit: PropTypes.func.isRequired,
  reset: PropTypes.func,
  changePath: PropTypes.func
};

const mapStateToProps = state => {
  const initialValues = {};
  const onHoldOrders = state.cutOrderOverview.onHoldOrders;
  _.forEach(onHoldOrders, (value, key) => {
    initialValues[`${key}-toCutToday`] = value;
  });

  const { futureOrders, sortColumn, sortDirection } = state.cutOrderOverview;
  const isApprovedForDay = state.portionRoomsInfo.currentPortionRoom.approved === true;
  const roomIsDisabled =
    state.portionRoomsInfo.currentPortionRoom.portionRoomState === PortionRoomState.DISABLED;
  const operatingDates = state.operatingDates;
  const currentAndNextWorkingDay = [operatingDates.firstDay, operatingDates.secondDay];

  return {
    initialValues,
    futureOrders,
    sortColumn,
    sortDirection,
    isApprovedForDay,
    roomIsDisabled,
    currentAndNextWorkingDay
  };
};

const mapDispatchToProps = dispatch =>
  bindActionCreators(
    {
      getFutureLineItems,
      clear,
      setHeaderAndFooter,
      handleSort,
      changePath,
      scheduleFutureOrdersToProduceToday,
      showModal,
      remainHoldOrdersQuantity,
      clearOnHoldOrdersQuantity
    },
    dispatch
  );

const ScheduleFutureCutOrders = connect(
  mapStateToProps,
  mapDispatchToProps
)(
  reduxForm({
    form: 'scheduleFutureCutOrdersForm',
    enableReinitialize: true
  })(ScheduleFutureCutOrdersComponent)
);

export default ScheduleFutureCutOrders;
