import React from 'react';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import CutOrderOverviewTable from '../components/CutOrderOverviewTable';
import { clear, getOverviewOfOrders, getStations } from '../actions/orderOverviewActions';
import { CUT_ORDERS_OVERVIEW } from '../../shared/components/pageTitles';
import { Field, formValueSelector, reduxForm } from 'redux-form';
import { Divider, Form, Grid } from 'semantic-ui-react';
import { setHeaderAndFooter } from '../../shared/actions/actions';
import { CUT_ORDERS_OVERVIEW_FOOTER } from '../../shared/components/pageFooters';
import FormElement from '../../shared/FormElement';
import { POLLING_INTERVAL } from '../../shared/constants';

const STATION_OPTION_ALL = {
  displayValue: 'All',
  id: NaN
};

export const statusOptions = [
  { key: 0, value: 'All', text: 'All' },
  { key: 1, value: 'New', text: 'New' },
  { key: 2, value: 'SelectedToCut', text: 'Selected to Cut' },
  { key: 3, value: 'Completed', text: 'Completed' },
  { key: 4, value: 'Cancelled', text: 'Cancelled' }
];

export class OrderReview extends React.Component {
  componentDidMount() {
    this.props.getStations();
    this.props.getOverviewOfOrders('All', null);
    this.props.setHeaderAndFooter({
      header: CUT_ORDERS_OVERVIEW,
      footer: CUT_ORDERS_OVERVIEW_FOOTER
    });
    this.ref.focus();

    this.intervalNumber = setInterval(() => {
      this.props.getOverviewOfOrders(this.props.statusValue, this.props.stationIdValue);
    }, POLLING_INTERVAL);
  }

  componentWillUnmount() {
    this.props.clear();
    clearInterval(this.intervalNumber);
  }

  generateStationOptions() {
    const { stations } = this.props;

    return stations.map((item, index) => ({
      key: index,
      value: item.id,
      text: item.displayValue
    }));
  }

  render() {
    const { getOverviewOfOrders, statusValue, stationIdValue, cutOrders } = this.props;

    return (
      <div className='page-content order-review-page' tabIndex='-1' ref={ref => (this.ref = ref)}>
        <Form size='large'>
          <Divider hidden className='divider-medium' />

          <Grid>
            <Grid.Row>
              <Grid.Column width={4}>
                <Field
                  component={FormElement}
                  as={Form.Select}
                  pid='order-review__station-filter'
                  name='station'
                  options={this.generateStationOptions()}
                  label='STATION'
                  onChange={(event, stationId) => {
                    getOverviewOfOrders(statusValue, isNaN(stationId) ? null : stationId);
                  }}
                />
              </Grid.Column>
              <Grid.Column width={4}>
                <Field
                  component={FormElement}
                  as={Form.Select}
                  pid='order-review__status-filter'
                  name='status'
                  options={statusOptions}
                  label='CUT ORDER STATUS'
                  onChange={(event, status) => {
                    getOverviewOfOrders(status, isNaN(stationIdValue) ? null : stationIdValue);
                  }}
                />
              </Grid.Column>
            </Grid.Row>
          </Grid>

          <Divider hidden />
        </Form>
        <CutOrderOverviewTable cutOrders={cutOrders} />
      </div>
    );
  }
}

OrderReview.propTypes = {
  cutOrders: PropTypes.array,
  stations: PropTypes.array.isRequired,
  getOverviewOfOrders: PropTypes.func.isRequired,
  getStations: PropTypes.func.isRequired,
  clear: PropTypes.func.isRequired,

  statusValue: PropTypes.string,
  stationIdValue: PropTypes.number,
  setHeaderAndFooter: PropTypes.func.isRequired
};

const selector = formValueSelector('orderReview');
const mapStateToProps = state => {
  const stationIdValue = selector(state, 'station');
  const statusValue = selector(state, 'status');

  const stations = [STATION_OPTION_ALL].concat(
    state.cutOrderOverview.stations.map(station => ({
      ...station,
      displayValue: station.stationCode + ' - ' + station.name
    }))
  );

  return {
    initialValues: {
      station: STATION_OPTION_ALL.id,
      status: 'All'
    },
    cutOrders: state.cutOrderOverview.cutOrders,
    stations,
    statusValue,
    stationIdValue
  };
};

const mapDispatchToProps = dispatch =>
  bindActionCreators(
    {
      getOverviewOfOrders,
      getStations,
      clear,
      setHeaderAndFooter
    },
    dispatch
  );

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(
  reduxForm({
    form: 'orderReview'
  })(OrderReview)
);
