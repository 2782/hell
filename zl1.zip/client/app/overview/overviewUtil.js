import * as _ from 'lodash';

export const onlyOrdersInProgress = orders => {
  return _.filter(orders, order => order.quantityRemaining > 0);
};
