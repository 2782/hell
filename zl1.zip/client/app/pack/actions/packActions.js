import packOrdersResources from '../../shared/api/packOrdersResources';

import {
  REGISTER_PRODUCT_CODE_FIELD,
  REGISTER_WEIGHT_FIELD,
  RESET_OVERRIDE_WEIGHT_RANGE_REQUEST,
  RESET_PACK_OFF_STOCK,
  RESET_PACK_ORDERS_INFO,
  RESET_WIP_BOXES,
  SHOW_OVERRIDE_WEIGHT_RANGE_REQUEST,
  UPDATE_PACK_OFF_STOCK,
  UPDATE_PACK_ORDERS_INFO,
  UPDATE_WIP_BOXES
} from './packActionTypes';

import { changePath } from '../../shared/actions/actions';
import { SubmissionError } from 'redux-form';
import _ from 'lodash';
import { formatNumberToTwoDecimalPlacesString } from '../../shared/util/dataUtil';

export const registerProductCodeField = productCodeField => ({
  type: REGISTER_PRODUCT_CODE_FIELD,
  payload: productCodeField
});

export const registerWeightField = weightField => {
  return {
    type: REGISTER_WEIGHT_FIELD,
    payload: weightField
  };
};

export const focusProductCodeField = () => (dispatch, getState) => {
  const { productCodeField } = getState().packBoxForm;
  productCodeField.getRenderedComponent().focusInput();
};

export const focusWeightField = () => (dispatch, getState) => {
  const { weightField } = getState().packBoxForm;
  weightField.getWrappedInstance().refocus();
};

export const showOverrideWeightRangeRequest = () => dispatch => {
  return dispatch({
    type: SHOW_OVERRIDE_WEIGHT_RANGE_REQUEST
  });
};

export const resetOverrideWeightRange = () => dispatch => {
  return dispatch({
    type: RESET_OVERRIDE_WEIGHT_RANGE_REQUEST
  });
};

export const clearPackedOffStock = () => ({
  type: RESET_PACK_OFF_STOCK
});

export const packOffWIPBox = formData => (dispatch, getState) => {
  const roomCode = getState().portionRoomsInfo.currentPortionRoom.code;
  return packOrdersResources
    .packOffWIPBox(initializeBoxWithFirstWeighing(roomCode, formData))
    .then(response => {
      dispatch({
        type: UPDATE_WIP_BOXES,
        payload: response.data
      });
    });
};

export const clearWIPBoxes = () => {
  return dispatch => {
    dispatch({
      type: RESET_WIP_BOXES
    });
  };
};

export const getPackOrdersInfo = () => {
  return (dispatch, getState) => {
    const room = getState().portionRoomsInfo;
    dispatch({
      type: RESET_PACK_ORDERS_INFO
    });

    return packOrdersResources.getPackOrders(room, packOrdersResponse => {
      dispatch({
        type: UPDATE_PACK_ORDERS_INFO,
        payload: sortCutOrders(packOrdersResponse.data)
      });
    });
  };
};

const sortCutOrders = cutOrders => {
  return _(cutOrders)
    .sortBy(['deliveryDate', 'productDescription'])
    .map(data => ({ data, orderId: data.id }))
    .value();
};

export const loadPackOrderByCutTicketAndRoom = (cutTicketCode, roomCode) => dispatch => {
  return packOrdersResources.checkPackOrderExistsForCutTicketAndRoom(cutTicketCode, roomCode).then(
    ({ data }) => dispatch(changePath(`/pack/orders/${data}`)),
    () => {
      throw new SubmissionError({
        ticketCode: 'Invalid Cut Ticket Barcode'
      });
    }
  );
};

const filterGrindOrders = (grindOrders, productCode) => ({
  type: UPDATE_PACK_ORDERS_INFO,
  payload: _.filter(grindOrders, grindOrder => grindOrder.data.product.code == productCode)
});

export const filterPackOrderByGrindTicketAndRoom = (
  grindOrders,
  grindTicketCode,
  roomCode
) => dispatch => {
  return packOrdersResources
    .checkPackOrderExistsForGrindTicketAndRoom(grindTicketCode, roomCode)
    .then(
      response => dispatch(filterGrindOrders(grindOrders, response.data)),
      () => {
        throw new SubmissionError({
          ticketCode: 'Invalid Grind Ticket Barcode'
        });
      }
    );
};

export const updatePackOffStock = response => ({
  type: UPDATE_PACK_OFF_STOCK,
  payload: response.data
});

export const packOffStock = formData => (dispatch, getState) => {
  const roomCode = getState().portionRoomsInfo.currentPortionRoom.code;
  return packOrdersResources
    .packOffStock(initializeBoxWithFirstWeighing(roomCode, formData))
    .then(response => dispatch(updatePackOffStock(response)));
};

function initializeBoxWithFirstWeighing(roomCode, formData) {
  return {
    productCode: formData.productCode,
    qtyToProduce: formData.qtyToProduce,
    packagingTare: formData.packagingTare,
    weighings: [
      {
        weight: formatNumberToTwoDecimalPlacesString(formData.weight),
        retailPieceTare: 0,
        overrideWeightRangeReasonCode: formData.overrideWeightRangeReasonCode,
        type: 'BOX'
      }
    ],
    roomCode
  };
}
