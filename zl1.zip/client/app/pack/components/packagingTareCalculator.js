import _ from 'lodash';
import { toPrecision } from '../../shared/util/floatUtil';

const BONEGUARD_PER_PIECE = 0.0137;

export const calculatePackagingTare = (product, defaultTarePackage = {}) => {
  const tarePackage = _.isEmpty(product) ? null : product.tarePackage || defaultTarePackage;

  if (_.isEmpty(tarePackage)) {
    return '';
  }

  const boxTare = _.get(tarePackage, 'boxType.boxTare', 0.0);
  const filmTare = _.get(tarePackage, 'filmType.filmTare', 0.0);
  const piecesPackageTare = _.get(product, 'piecesPackage.weight', 0.0);
  const piecesPerCase = _.get(product, 'productPortionSize.piecesPerCase', 0);
  const boneguardTare = _.get(product, 'boneguard', false)
    ? piecesPerCase * BONEGUARD_PER_PIECE
    : 0.0;

  return toPrecision(boxTare + filmTare + piecesPackageTare + boneguardTare).toFixed(2);
};

export const calculateRetailPieceTare = (retailSpecificTare, defaultTarePackage = {}) => {
  const tarePackage = _.isEmpty(retailSpecificTare) ? defaultTarePackage : retailSpecificTare;

  if (_.isEmpty(tarePackage)) {
    return '';
  }

  const boxTare = _.get(tarePackage, 'boxType.boxTare', 0.0);
  const filmTare = _.get(tarePackage, 'filmType.filmTare', 0.0);

  return toPrecision(boxTare + filmTare).toFixed(2);
};
