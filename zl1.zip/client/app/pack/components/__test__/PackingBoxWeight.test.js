import { shallow } from 'enzyme';
import React from 'react';
import PackingBoxWeight, { getFixedWeight } from '../PackingBoxWeight';
import productFactory from '../../../../test-factories/productFactory';
import retailSpecificFactory from '../../../../test-factories/retailSpecificFactory';

jest.mock('../../../shared/scale/scale');

describe('PackingBoxWeight', () => {
  test('should not display FormLabel if fixedWeight is null', () => {
    const renderer = shallow(
      <PackingBoxWeight
        formName={'Foo'}
        scaleRef={jest.fn()}
        netWeight={0}
        product={productFactory.build()}
      />
    );
    jestExpect(renderer).toMatchSnapshot();
  });

  test('should show display retail piece tare if product is retail', () => {
    const renderer = shallow(
      <PackingBoxWeight
        formName={'Foo'}
        scaleRef={jest.fn()}
        netWeight={0}
        retailPieceTare={'12.0'}
        product={productFactory.build({
          retailSpecific: retailSpecificFactory.build({})
        })}
      />
    );
    jestExpect(renderer).toMatchSnapshot();
  });

  test('should show net weight and fix weight with two decimal places', () => {
    const renderer = shallow(
      <PackingBoxWeight
        formName={'Foo'}
        scaleRef={jest.fn()}
        netWeight={1}
        product={productFactory.build({
          category: 'FIXED'
        })}
      />
    );

    jestExpect(renderer.find('[pid="net-weight-display"]').props()).toMatchSnapshot();
    jestExpect(renderer.find('[pid="fixed-weight-display"]').props()).toMatchSnapshot();
  });

  test('should show fixed weight from product if not retail', () => {
    const notARetailProduct = productFactory.build({
      category: 'FIXED'
    });

    jestExpect(getFixedWeight(notARetailProduct)).toEqual('2.00');
  });

  test('should show fixed weight from retail configuration when retail', () => {
    const retailProduct = productFactory.build({
      category: 'FIXED',
      retailSpecific: retailSpecificFactory.build()
    });

    jestExpect(getFixedWeight(retailProduct)).toEqual('5.00');
  });
});
