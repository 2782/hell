import React from 'react';
import { mount } from 'enzyme';
import { Provider } from 'react-redux';
import { createReduxStore } from '../../../store';
import PackOffOrderForm, {
  f2Behavior,
  PackOffOrderForm as PackOffOrderFormComponent
} from '../packOffOrderForm';
import CutOrderFactory from '../../../../test-factories/cutOrder';
import productFactory from '../../../../test-factories/productFactory';
import semanticUI from '../../../../test-helpers/semantic-ui';
import packOrdersResources from '../../../shared/api/packOrdersResources';
import boxResources from '../../../shared/api/boxResources';
import cutOrdersResources from '../../../shared/api/cutOrdersResources';
import CustomerOrderFactory from '../../../../test-factories/customerOrder';
import CustomerFactory from '../../../../test-factories/customerFactory';
import { showModal } from '../../../shared/actions/actions';
import { initializeOrderToPack } from '../../actions/orderToPackAction';
import { BANQUET, STANDARD } from '../../../../config/cutType';

const customer = CustomerFactory.build({ name: 'I am a customer' });

jest.mock('../../../shared/api/packOrdersResources');
jest.mock('../../../shared/api/boxResources');
jest.mock('../../../shared/api/tarePackagesResources');
jest.mock('../../../shared/api/cutOrdersResources');
jest.mock('../../../shared/actions/actions', () => ({
  showModal: jest.fn()
}));
jest.mock('../../../shared/scale/scale');

describe('PackOffOrderForm', () => {
  let order, form, onBack, store, onF2, quantityRemaining;
  const OVERRIDE_REASON_CODE =
    'Less than fixed weight - 1. Enter reason code and press enter to pack off.';

  beforeEach(() => {
    onBack = jest.fn();
    onF2 = jest.fn();
    quantityRemaining = jest.fn();
    store = createReduxStore({
      portionRoomsInfo: {
        currentPortionRoom: {
          code: 'A'
        }
      }
    });
  });

  afterEach(() => {
    boxResources.reprintLabelsForCurrentUser.mockReset();
    packOrdersResources.getPackOrders.mockReset();
    packOrdersResources.packOffStock.mockReset();
    packOrdersResources.packOffWIPBox.mockReset();
    packOrdersResources.getOrderToPack.mockReset();
    packOrdersResources.completeBanquetOrder.mockReset();
    packOrdersResources.packOrder.mockReset();
    packOrdersResources.checkPackOrderExistsForCutTicketAndRoom.mockReset();
    cutOrdersResources.dismissCancelledOrder.mockReset();
  });

  describe('CATCH product', () => {
    beforeEach(() => {
      order = CutOrderFactory.build({
        id: 8,
        unitOfMeasure: 'PIECE',
        qtyToProduce: 2,
        qtyInBoxes: 2,
        qtyPacked: 0,
        product: productFactory.build({
          code: '0071185',
          description: 'CAB SIRLOIN CULOTTE STEAK',
          productPortionSize: {
            portionSize: '12 OZ'
          },
          category: 'CATCH',
          minWeight: 1,
          maxWeight: 20,
          retailSpecific: null
        }),
        customerOrder: CustomerOrderFactory.build({ customer: customer })
      });

      store.dispatch(initializeOrderToPack(order));

      form = mount(
        <Provider store={store}>
          <PackOffOrderForm
            order={order}
            packedBoxes={[]}
            onBack={onBack}
            quantityRemaining={quantityRemaining}
            onF2={onF2}
          />
        </Provider>
      );
    });

    test('should fill out form and submit successfully', async () => {
      packOrdersResources.packOrder.mockImplementation(jest.fn(() => Promise.resolve()));
      packOrdersResources.getOrderToPack.mockResolvedValue({});

      semanticUI.changeInput(form, 'weight', '12.111111');
      semanticUI.changeInput(form, 'packagingTare', '2.4');

      form.find('form').simulate('submit');
      await waitForAsyncTasks();

      jestExpect(packOrdersResources.packOrder).toBeCalledWith(
        jestExpect.objectContaining({
          productionOrderId: order.id,
          qtyToProduce: order.qtyInBoxes,
          packagingTare: '2.40',
          productCode: order.product.code,
          roomCode: 'A',
          weighings: jestExpect.arrayContaining([
            jestExpect.objectContaining({
              overrideWeightRangeReasonCode: '',
              retailPieceTare: 0,
              weight: '12.11',
              type: 'BOX'
            })
          ])
        })
      );
    });

    test('should retained packagingTare value if changed', () => {
      packOrdersResources.packOrder.mockImplementation(() => Promise.resolve());

      semanticUI.changeInput(form, 'weight', '12.1');
      semanticUI.changeInput(form, 'packagingTare', '2.40');

      form.find('form').simulate('submit');

      jestExpect(packOrdersResources.packOrder).toBeCalled();
      jestExpect(semanticUI.getInputValue(form, 'packagingTare')).toEqual('2.40');
    });

    test('should not submit form if net weight has changed and reason code has not been entered again', () => {
      semanticUI.changeInput(form, 'weight', '44.1');
      semanticUI.changeInput(form, 'packagingTare', '2.4');

      form.find('form').simulate('submit');

      jestExpect(packOrdersResources.packOrder).not.toBeCalled();
      semanticUI.changeInput(form, 'overrideWeightRangeReasonCode', '555');
      semanticUI.changeInput(form, 'weight', '55.1');

      form.find('form').simulate('submit');
      jestExpect(packOrdersResources.packOrder).not.toBeCalled();
    });

    test('should not submit form if weight is invalid', () => {
      semanticUI.changeInput(form, 'weight', '-10.0');
      semanticUI.changeInput(form, 'packagingTare', '2.2');

      form.find('form').simulate('submit');

      jestExpect(packOrdersResources.packOrder).not.toBeCalled();
    });

    test('should not submit form if netWeight is not within min/max CATCH weight range', () => {
      const order = CutOrderFactory.build({
        id: 8,
        unitOfMeasure: 'PIECE',
        qtyToProduce: 2,
        qtyInBoxes: 2,
        qtyPacked: 0,
        utType: 'BANQUET',
        customerOrder: CustomerOrderFactory.build({ customer: customer }),
        product: productFactory.build({
          category: 'CATCH',
          minWeight: 1.0,
          maxWeight: 20.0
        })
      });

      form = mount(
        <Provider store={store}>
          <PackOffOrderForm
            order={order}
            packedBoxes={[]}
            onBack={onBack}
            quantityRemaining={quantityRemaining}
            onF2={onF2}
          />
        </Provider>
      );

      semanticUI.changeInput(form, 'weight', '3');
      semanticUI.changeInput(form, 'packagingTare', '2.2');

      form.find('form').simulate('submit');

      jestExpect(semanticUI.findErrorLabels(form).props().children).toEqual(
        'Outside of range - weight range is 1 - 20. Enter reason code and press enter to pack off.'
      );

      jestExpect(packOrdersResources.packOrder).not.toBeCalled();

      semanticUI.changeInput(form, 'weight', '31.7');
      semanticUI.changeInput(form, 'packagingTare', '4.1');

      form.find('form').simulate('submit');

      jestExpect(semanticUI.findErrorLabels(form).props().children).toEqual(
        'Outside of range - weight range is 1 - 20. Enter reason code and press enter to pack off.'
      );

      jestExpect(packOrdersResources.packOrder).not.toBeCalled();
    });

    test('netWeight precision should be 2', () => {
      semanticUI.changeInput(form, 'weight', '0.13');
      semanticUI.changeInput(form, 'packagingTare', '1.00');
      jestExpect(
        form
          .find('[pid="net-weight-display"]')
          .find('div')
          .at(1)
          .text()
      ).toEqual('-0.87');
    });
  });

  describe('FIXED', () => {
    beforeEach(() => {
      const order = CutOrderFactory.build({
        id: 8,
        unitOfMeasure: 'PIECE',
        qtyToProduce: 2,
        qtyInBoxes: 2,
        qtyPacked: 0,
        utType: 'BANQUET',
        customerOrder: CustomerOrderFactory.build({ customer: customer }),
        product: productFactory.build({
          category: 'FIXED',
          minWeight: 1.0,
          maxWeight: 20.0
        })
      });

      store.dispatch(initializeOrderToPack(order));

      form = mount(
        <Provider store={store}>
          <PackOffOrderForm
            order={order}
            packedBoxes={[]}
            onBack={onBack}
            quantityRemaining={quantityRemaining}
            onF2={onF2}
          />
        </Provider>
      );
    });

    test('should not submit form if netWeight is not within min/max FIXED weight range', () => {
      jestExpect(semanticUI.findLabelWithName(form, 'Fixed Weight').props().value).toEqual('1.00');

      semanticUI.changeInput(form, 'weight', '3');
      semanticUI.changeInput(form, 'packagingTare', '2.2');

      form.find('form').simulate('submit');

      jestExpect(semanticUI.findErrorLabels(form).props().children).toEqual(
        'Less than fixed weight - 1. Enter reason code and press enter to pack off.'
      );

      jestExpect(packOrdersResources.packOrder).not.toBeCalled();
    });

    test('should render fixed weight when product is FIXED and in by product page', () => {
      form.find('form').simulate('submit');

      jestExpect(semanticUI.findLabelWithName(form, 'Fixed Weight').props().value).toEqual('1.00');
    });

    test('should allow submit with valid override reason and remove reason code', () => {
      packOrdersResources.packOrder.mockImplementation(() => Promise.resolve());

      jestExpect(semanticUI.findLabelWithName(form, 'Fixed Weight').props().value).toEqual('1.00');

      semanticUI.changeInput(form, 'weight', '3');
      semanticUI.changeInput(form, 'packagingTare', '2.2');

      form.find('form').simulate('submit');

      jestExpect(semanticUI.findErrorLabels(form).props().children).toEqual(OVERRIDE_REASON_CODE);

      jestExpect(packOrdersResources.packOrder).not.toBeCalled();

      semanticUI.changeInput(form, 'overrideWeightRangeReasonCode', '555');
      form.find('form').simulate('submit');

      jestExpect(packOrdersResources.packOrder).toBeCalled();
    });

    test('should not allow letters for overrideWeightRangeReasonCode', () => {
      jestExpect(semanticUI.findLabelWithName(form, 'Fixed Weight').props().value).toEqual('1.00');

      semanticUI.changeInput(form, 'weight', '3');
      semanticUI.changeInput(form, 'packagingTare', '2.2');

      form.find('form').simulate('submit');

      jestExpect(semanticUI.findErrorLabels(form).props().children).toEqual(OVERRIDE_REASON_CODE);

      jestExpect(packOrdersResources.packOrder).not.toBeCalled();

      semanticUI.changeInput(form, 'overrideWeightRangeReasonCode', '4ff');
      jestExpect(
        semanticUI
          .findErrorLabels(form)
          .at(1)
          .props().children
      ).toEqual('Must be a number');
    });

    test('should not allow submit with empty override reason', () => {
      jestExpect(semanticUI.findLabelWithName(form, 'Fixed Weight').props().value).toEqual('1.00');

      semanticUI.changeInput(form, 'weight', '3');
      semanticUI.changeInput(form, 'packagingTare', '2.2');

      form.find('form').simulate('submit');

      jestExpect(semanticUI.findErrorLabels(form).props().children).toEqual(OVERRIDE_REASON_CODE);

      jestExpect(packOrdersResources.packOrder).not.toBeCalled();

      semanticUI.changeInput(form, 'overrideWeightRangeReasonCode', '');
      jestExpect(semanticUI.findErrorLabels(form).get(0).props.children).toEqual(
        OVERRIDE_REASON_CODE
      );
      form.find('form').simulate('submit');
      jestExpect(packOrdersResources.packOrder).not.toBeCalled();
    });
  });

  describe('cancelled CATCH product', () => {
    beforeEach(() => {
      order = CutOrderFactory.build({
        id: 8,
        unitOfMeasure: 'PIECE',
        qtyToProduce: 2,
        qtyInBoxes: 2,
        qtyPacked: 0,
        customerOrder: CustomerOrderFactory.build({ customer: customer }),
        cancelled: true
      });

      store.dispatch(initializeOrderToPack(order));

      form = mount(
        <Provider store={store}>
          <PackOffOrderForm
            order={order}
            packedBoxes={[]}
            onBack={onBack}
            quantityRemaining={quantityRemaining}
            onF2={onF2}
          />
        </Provider>
      );
    });

    test('should show cancellation warning when pack order resource call rejects', done => {
      const errorReponse = {
        error: {
          name: 'VALIDATION_ERROR',
          details: [
            {
              field: 'customerBoxRequest',
              value: order.id,
              issue: 'CUT_ORDER_IS_CANCELLED'
            }
          ],
          message: 'Production order is not active'
        }
      };
      packOrdersResources.packOrder.mockImplementation(() =>
        Promise.reject({ response: { data: errorReponse } })
      );
      showModal.mockImplementation(actual => {
        jestExpect(actual).toEqual({
          header: 'Sales Order Cancelled',
          content: 'This order has been cancelled and cannot be packed off.',
          cancelButton: 'Go Back',
          cancelAction: jestExpect.anything(),
          confirmButton: 'Pack as Stock',
          confirmAction: jestExpect.anything()
        });
        done();
        return { type: 'MOCK_SHOW_MODAL_ACTION' };
      });

      semanticUI.changeInput(form, 'weight', '12.1');
      semanticUI.changeInput(form, 'packagingTare', '2.4');

      form.find('form').simulate('submit');
    });

    test('should show deletion warning when pack order resource call rejects', done => {
      const errorReponse = {
        error: {
          name: 'VALIDATION_ERROR',
          details: [
            {
              field: 'customerBoxRequest',
              value: order.id,
              issue: 'CUT_ORDER_IS_DELETED'
            }
          ],
          message: 'Production order is not active'
        }
      };
      packOrdersResources.packOrder.mockImplementation(() =>
        Promise.reject({ response: { data: errorReponse } })
      );
      showModal.mockImplementation(actual => {
        jestExpect(actual).toEqual({
          header: 'Item Deleted From Sales Order',
          content: 'This item has been deleted from the order and cannot be packed off.',
          cancelButton: 'Go Back',
          cancelAction: jestExpect.anything(),
          confirmButton: 'Pack as Stock',
          confirmAction: jestExpect.anything()
        });
        done();
        return { type: 'MOCK_SHOW_MODAL_ACTION' };
      });

      semanticUI.changeInput(form, 'weight', '12.1');
      semanticUI.changeInput(form, 'packagingTare', '2.4');

      form.find('form').simulate('submit');
    });

    test('should show changed warning when pack order resource call rejects', done => {
      const errorReponse = {
        error: {
          name: 'VALIDATION_ERROR',
          details: [
            {
              field: 'customerBoxRequest',
              value: order.id,
              issue: 'CUT_ORDER_IS_UPDATED:0'
            }
          ],
          message: 'Production order is not active'
        }
      };
      packOrdersResources.packOrder.mockImplementation(() =>
        Promise.reject({ response: { data: errorReponse } })
      );

      showModal.mockImplementation(actual => {
        jestExpect(actual).toEqual({
          header: 'Sales Order Quantity Change',
          content:
            'This order quantity has been reduced to 0. ' +
            'Additional product cannot be packed off against the customer order.',
          cancelButton: 'Go Back',
          cancelAction: jestExpect.anything(),
          confirmButton: 'Pack as Stock',
          confirmAction: jestExpect.anything()
        });
        done();
        return { type: 'MOCK_SHOW_MODAL_ACTION' };
      });

      semanticUI.changeInput(form, 'weight', '12.1');
      semanticUI.changeInput(form, 'packagingTare', '2.4');

      form.find('form').simulate('submit');
    });

    test('should dismiss cut order and replace pack off screen with pack off stock screen', async () => {
      const packBoxForOrder = jest
        .fn()
        .mockImplementation(() => Promise.reject({ response: { data: errorReponse } }));
      const showModal = jest.fn().mockImplementation(options => options.confirmAction());
      const replacePath = jest.fn();

      cutOrdersResources.dismissCancelledOrder.mockImplementation((id, callback) => callback());

      const errorReponse = {
        error: {
          name: 'VALIDATION_ERROR',
          details: [
            {
              field: 'customerBoxRequest',
              value: order.id,
              issue: 'CUT_ORDER_IS_CANCELLED'
            }
          ],
          message: 'Production order is not active'
        }
      };
      const props = {
        id: 8,
        order: { product: { code: '0078889', minWeight: 0.5, maxWeight: 100, category: 'CATCH' } },
        packBoxForOrder,
        showModal,
        replacePath
      };
      const component = new PackOffOrderFormComponent(props);

      await component.submit({
        weight: '12.456',
        packagingTare: '1.000',
        overrideWeightRangeReasonCode: '312'
      });

      jestExpect(replacePath).toBeCalledWith('/pack/pack-off-stock/');
    });
  });

  describe('f2 Behavior', () => {
    test('should complete banquet order on F2 if cutType is BANQUET and qtyPacked > 0', () => {
      const props = {
        order: {
          cutType: BANQUET,
          id: 12,
          qtyPacked: 2
        },
        completeBanquetOrder: jest.fn()
      };

      f2Behavior(props);

      jestExpect(props.completeBanquetOrder).toHaveBeenCalled();
    });

    test('should not complete banquet order on F2 if cutType is not BANQUET', () => {
      const props = {
        order: {
          cutType: STANDARD,
          id: 12,
          qtyPacked: 2
        },
        completeBanquetOrder: jest.fn()
      };

      f2Behavior(props);

      jestExpect(props.completeBanquetOrder).not.toHaveBeenCalled();
    });

    test('should not complete banquet order on F2 if qtyPacked is 0', () => {
      const props = {
        order: {
          cutType: BANQUET,
          id: 12,
          qtyPacked: 0
        },
        completeBanquetOrder: jest.fn()
      };

      f2Behavior(props);

      jestExpect(props.completeBanquetOrder).not.toHaveBeenCalled();
    });
  });
});
