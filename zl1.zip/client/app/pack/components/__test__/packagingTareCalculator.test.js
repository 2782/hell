import _ from 'lodash';
import { calculatePackagingTare } from '../packagingTareCalculator';
import { PRODUCT_2 } from '../../../../test-factories/productFactory';

const product = PRODUCT_2;
const tarePackage = {
  id: 919990101003001,
  boxType: { boxDescription: 'BUCKHEAD 10# BLACK', boxTare: 0.789 },
  filmType: { filmDescription: '1X2', filmTare: 0.045 },
  defaulted: false
};

describe('calculatePackagingTare', () => {
  test('should calc packaging tare with product has been set up box type', () => {
    jestExpect(calculatePackagingTare(product)).toEqual('1.32');
  });

  test('should return 0.0 if product has not been set up box type and default is not null', () => {
    const productWithoutBoxType = _.omit(product, 'tarePackage');
    jestExpect(calculatePackagingTare(productWithoutBoxType, tarePackage)).toEqual('1.43');
  });

  test('should return empty when product has not been set up box and default is null', () => {
    const productWithoutBoxType = _.omit(product, 'tarePackage');
    jestExpect(calculatePackagingTare(productWithoutBoxType, null)).toEqual('');
  });

  test('should return empty when product has not been set up box and default is empty string', () => {
    const productWithoutBoxType = _.omit(product, 'tarePackage');
    jestExpect(calculatePackagingTare(productWithoutBoxType, '')).toEqual('');
  });

  test('should return empty when product is null or undefined', () => {
    jestExpect(calculatePackagingTare(null)).toEqual('');
  });

  test('should round to two decimal place rather than one or zero decimal', () => {
    const productWithoutBoxType = _.omit(product, 'tarePackage');
    const newTarePackage = {
      id: 919990101003001,
      boxType: { boxDescription: 'BUCKHEAD 10# BLACK', boxTare: 0.007 },
      filmType: { filmDescription: '1X2', filmTare: 0.293 },
      defaulted: false
    };

    jestExpect(calculatePackagingTare(productWithoutBoxType, newTarePackage)).toEqual('0.90');
  });
});
