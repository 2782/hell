import packBoxFormValidator from '../packBoxFormValidator';
import { PACK_OFF_WIP, PACK_OFF_STOCK } from '../packType';

const VALID_PRODUCT_CODE = '0078889';

const OVERRIDE_WEIGHT_RANGE_REASON_CODE = 555;

describe('PackedBoxFormValidator', () => {
  describe('validateSubmission', () => {
    let showOverrideWeightRangeRequest;

    beforeEach(() => {
      showOverrideWeightRangeRequest = jest.fn();
    });

    test('should throw error for fields required', () => {
      const values = {
        productCode: '',
        weight: null,
        packagingTare: '',
        overrideWeightRangeReasonCode: ''
      };

      const errors = packBoxFormValidator.validateSubmission(values, {
        showOverrideWeightRangeRequest
      });
      jestExpect(errors.productCode).toEqual('Required');
      jestExpect(errors.weight).toEqual('Required');
      jestExpect(errors.packagingTare).toEqual('Required');
    });

    test('should throw error for productCode non-wholeNumber', () => {
      const values = {
        productCode: 'abc123'
      };

      const errors = packBoxFormValidator.validateSubmission(values, {
        showOverrideWeightRangeRequest
      });
      jestExpect(errors.productCode).toEqual('Only whole number characters');
    });

    test('should throw error for productCode not length 7', () => {
      const values = {
        productCode: '012345678'
      };

      const errors = packBoxFormValidator.validateSubmission(values, {
        showOverrideWeightRangeRequest
      });
      jestExpect(errors.productCode).toEqual('Must be 7 characters');
    });

    test('should throw error for retail product on packoff stock screen', () => {
      const values = {
        productCode: VALID_PRODUCT_CODE,
        weight: '8.9',
        packagingTare: '1.2',
        overrideWeightRangeReasonCode: ''
      };

      const errors = packBoxFormValidator.validateSubmission(values, {
        packType: PACK_OFF_WIP,
        category: 'CATCH',
        minWeight: '2',
        maxWeight: '5',
        showOverrideWeightRangeRequest,
        retailSpecific: {
          price: 1.25,
          tare: 0.57,
          minWeight: 5.0
        }
      });

      jestExpect(errors.productCode).toBeUndefined();
    });

    test('should not throw error for retail product on packoff WIP screen', () => {
      const values = {
        productCode: VALID_PRODUCT_CODE,
        weight: '8.9',
        packagingTare: '1.2',
        overrideWeightRangeReasonCode: ''
      };

      const errors = packBoxFormValidator.validateSubmission(values, {
        packType: PACK_OFF_STOCK,
        category: 'CATCH',
        minWeight: '2',
        maxWeight: '5',
        showOverrideWeightRangeRequest,
        retailSpecific: {
          price: 1.25,
          tare: 0.57,
          minWeight: 5.0
        }
      });

      jestExpect(errors.productCode).toEqual('Retail items cannot be packed as stock.');
    });

    test('should throw error for weight and Packaging Tare when not a number', () => {
      const values = {
        weight: '.',
        packagingTare: 'abc'
      };

      const errors = packBoxFormValidator.validateSubmission(values, {
        showOverrideWeightRangeRequest
      });
      jestExpect(errors.weight).toEqual('Must be a number');
      jestExpect(errors.packagingTare).toEqual('Must be a number');
    });

    test('should throw error for weight when net weight is 0', () => {
      const values = {
        productCode: VALID_PRODUCT_CODE,
        weight: '7.0',
        packagingTare: '7.0',
        overrideWeightRangeReasonCode: ''
      };

      const errors = packBoxFormValidator.validateSubmission(values, {
        showOverrideWeightRangeRequest
      });
      jestExpect(errors.weight).toEqual('Weight should be greater than Packaging Tare');
    });

    test('should throw error for weight when net weight is negative', () => {
      const values = {
        productCode: VALID_PRODUCT_CODE,
        weight: '7.0',
        packagingTare: '9.0',
        overrideWeightRangeReasonCode: ''
      };

      const errors = packBoxFormValidator.validateSubmission(values, {
        showOverrideWeightRangeRequest
      });
      jestExpect(errors.weight).toEqual('Weight should be greater than Packaging Tare');
    });

    test(
      'should not throw error for byproduct weight when net weight is greater than max weight and ' +
        'overrideWeightRangeReasonCode is provided',
      () => {
        const values = {
          productCode: VALID_PRODUCT_CODE,
          weight: '8.3',
          packagingTare: '1.2',
          overrideWeightRangeReasonCode: '555'
        };

        const errors = packBoxFormValidator.validateSubmission(values, {
          packType: 'byproduct',
          category: 'FIXED',
          minWeight: '2',
          maxWeight: '5',
          showOverrideWeightRangeRequest
        });

        jestExpect(errors).toEqual({});
        jestExpect(showOverrideWeightRangeRequest).not.toBeCalled();
      }
    );

    test('should throw error for byproduct weight when net weight is greater than max weight', () => {
      const values = {
        productCode: VALID_PRODUCT_CODE,
        weight: '8.3',
        packagingTare: '1.2',
        overrideWeightRangeReasonCode: ''
      };

      const errors = packBoxFormValidator.validateSubmission(values, {
        packType: 'byproduct',
        category: 'CATCH',
        minWeight: '2',
        maxWeight: '5',
        showOverrideWeightRangeRequest
      });

      jestExpect(errors.weight).toEqual(
        'Outside of range - weight range is 2 - 5. Enter reason code and press enter to pack off.'
      );
      jestExpect(showOverrideWeightRangeRequest).toBeCalled();
    });

    test('should not throw error for pack wip weight when net weight is less than min weight', () => {
      const values = {
        productCode: VALID_PRODUCT_CODE,
        weight: '3.1',
        packagingTare: '1.2',
        overrideWeightRangeReasonCode: ''
      };

      const errors = packBoxFormValidator.validateSubmission(values, {
        packType: PACK_OFF_WIP,
        category: 'FIXED',
        minWeight: '2',
        maxWeight: '5',
        showOverrideWeightRangeRequest
      });

      jestExpect(errors).toEqual({});
    });

    test('should throw error for weight when net weight is less than fix weight and product is FIXED type', () => {
      const values = {
        productCode: VALID_PRODUCT_CODE,
        weight: '8.9',
        packagingTare: '1.2',
        overrideWeightRangeReasonCode: ''
      };

      const errors = packBoxFormValidator.validateSubmission(values, {
        packType: 'byproduct',
        category: 'FIXED',
        minWeight: '10',
        maxWeight: '10',
        showOverrideWeightRangeRequest
      });
      jestExpect(errors.weight).toEqual(
        'Less than fixed weight - 10. Enter reason code and press enter to pack off.'
      );

      jestExpect(showOverrideWeightRangeRequest).toBeCalled();
    });

    test('min and max weight is required for production products', () => {
      const values = {
        productCode: VALID_PRODUCT_CODE,
        weight: '8.9',
        packagingTare: '1.2',
        overrideWeightRangeReasonCode: ''
      };

      const errors = packBoxFormValidator.validateSubmission(values, {
        packType: 'byproduct',
        category: 'CATCH',
        showOverrideWeightRangeRequest,
        productOutput: 'FINISHED'
      });
      jestExpect(errors.productCode).toEqual('Product setup is incomplete');
    });

    test('min and max weight is not required to pack off a source product', () => {
      const values = {
        productCode: VALID_PRODUCT_CODE,
        weight: '8.9',
        packagingTare: '1.2',
        overrideWeightRangeReasonCode: ''
      };

      const errors = packBoxFormValidator.validateSubmission(values, {
        packType: 'byproduct',
        category: 'CATCH',
        showOverrideWeightRangeRequest,
        productOutput: 'SOURCE'
      });

      jestExpect(errors).toEqual({});
    });

    test(
      'should not throw error for byproduct weight when net weight is greater ' +
        'than max weight and override reason is provided',
      () => {
        const values = {
          productCode: VALID_PRODUCT_CODE,
          weight: '8.9',
          packagingTare: '1.2',
          overrideWeightRangeReasonCode: OVERRIDE_WEIGHT_RANGE_REASON_CODE
        };

        const errors = packBoxFormValidator.validateSubmission(values, {
          packType: 'byproduct',
          category: 'CATCH',
          minWeight: '2',
          maxWeight: '5',
          showOverrideWeightRangeRequest
        });

        jestExpect(errors).toEqual({});
        jestExpect(showOverrideWeightRangeRequest).not.toBeCalled();
      }
    );

    test('should not throw error for pack wip weight when net weight is greater than max weight', () => {
      const values = {
        productCode: VALID_PRODUCT_CODE,
        weight: '8.9',
        packagingTare: '1.2',
        overrideWeightRangeReasonCode: ''
      };

      const errors = packBoxFormValidator.validateSubmission(values, {
        packType: PACK_OFF_WIP,
        category: 'CATCH',
        minWeight: '2',
        maxWeight: '5',
        showOverrideWeightRangeRequest
      });

      jestExpect(errors).toEqual({});
    });
  });

  describe('processErrorResponse', () => {
    test('should throw submission error on productCode if issue PRODUCT_IS_NOT_PRODUCTION_ITEM is returned', () => {
      const errorResponse = {
        error: {
          details: [
            {
              field: 'FIELD',
              issue: 'PRODUCT_IS_NOT_PRODUCTION_ITEM',
              location: 'body',
              type: null
            }
          ]
        }
      };

      try {
        packBoxFormValidator.processErrorResponse(errorResponse);
        fail('Expected submission error to be thrown.');
      } catch ({ errors }) {
        jestExpect(errors.productCode).toEqual('Must be a production item.');
        jestExpect(errors._error).toEqual('Submission Failed!');
      }
    });

    test(
      'should throw submission error on productCode if issue ' +
        'USER_NOT_ASSIGNED_TO_PACKOFF_STATION_IN_CURRENT_ROOM is returned',
      () => {
        const errorResponse = {
          error: {
            details: [
              {
                field: 'stockBoxRequest',
                issue: 'USER_NOT_ASSIGNED_TO_PACKOFF_STATION_IN_CURRENT_ROOM',
                location: 'body',
                type: 'model',
                value: 'PackoffUser'
              }
            ]
          }
        };

        try {
          packBoxFormValidator.processErrorResponse(errorResponse);
          fail('Expected submission error to be thrown.');
        } catch ({ errors }) {
          jestExpect(errors.productCode).toEqual('User ID not assigned to portion room');
          jestExpect(errors._error).toEqual('Submission Failed!');
        }
      }
    );

    test(
      'should throw submission error on productCode if issue ' +
        'USER_NOT_ASSIGNED_TO_PACKOFF_STATION is returned',
      () => {
        const errorResponse = {
          error: {
            details: [
              {
                field: 'stockBoxRequest',
                issue: 'USER_NOT_ASSIGNED_TO_PACKOFF_STATION',
                location: 'body',
                type: 'model',
                value: 'PackoffUser'
              }
            ]
          }
        };

        try {
          packBoxFormValidator.processErrorResponse(errorResponse);
          fail('Expected submission error to be thrown.');
        } catch ({ errors }) {
          jestExpect(errors.productCode).toEqual('User ID not assigned to portion room');
          jestExpect(errors._error).toEqual('Submission Failed!');
        }
      }
    );

    test('should throw general submission error if issue is not tracked', () => {
      const errorResponse = {
        error: {
          details: [
            {
              field: 'FIELD',
              issue: 'OTHER',
              location: 'body',
              type: null
            }
          ]
        }
      };

      try {
        packBoxFormValidator.processErrorResponse(errorResponse);
        fail('Expected submission error to be thrown.');
      } catch ({ errors }) {
        jestExpect(errors.productCode).toBeUndefined();
        jestExpect(errors._error).toEqual('Submission Failed!');
      }
    });

    test('should throw general submission error if error response is empty', () => {
      const errorResponse1 = { error: {} };
      const errorResponse2 = { error: { details: [] } };

      try {
        packBoxFormValidator.processErrorResponse(errorResponse1);
        fail('Expected submission error to be thrown.');
      } catch ({ errors }) {
        jestExpect(errors._error).toEqual('Submission Failed!');
      }

      try {
        packBoxFormValidator.processErrorResponse(errorResponse2);
        fail('Expected submission error to be thrown.');
      } catch ({ errors }) {
        jestExpect(errors._error).toEqual('Submission Failed!');
      }
    });
  });
});
