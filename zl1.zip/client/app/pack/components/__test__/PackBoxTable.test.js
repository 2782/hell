import React from 'react';
import { shallow } from 'enzyme';
import { PackBoxTableComponent } from '../PackBoxTable';
import { Button, Table } from 'semantic-ui-react';
import { PACK_OFF_NORMAL, PACK_OFF_RETAIL, PACK_OFF_WIP } from '../packType';
import boxResources from '../../../shared/api/boxResources';

jest.mock('../../../shared/api/boxResources');
const packedBoxes = [
  {
    id: 1,
    packagingTare: 6.6,
    weighings: [
      {
        id: 1,
        weight: 879.6,
        retailPieceTare: 0.05,
        overrideWeightRangeReasonCode: 555,
        type: 'BOX'
      }
    ]
  },
  {
    id: 2,
    packagingTare: 2.0,
    weighings: [
      {
        id: 2,
        weight: 358,
        retailPieceTare: 0.05,
        type: 'BOX'
      }
    ]
  },
  {
    id: 3,
    packagingTare: 1.16,
    weighings: [
      {
        id: 3,
        weight: 123,
        retailPieceTare: 0.05,
        overrideWeightRangeReasonCode: 777,
        type: 'BOX'
      }
    ]
  }
];

describe('packOffBox', () => {
  afterEach(() => {
    boxResources.reprintLabelsForCurrentUser.mockReset();
  });

  describe('Normal pack off table', () => {
    test('should contain header with weight, packagingTare and net weight and reason', () => {
      const wrapper = shallow(
        <PackBoxTableComponent
          variant={PACK_OFF_NORMAL}
          packedBoxes={[]}
          reprintLabelsForCurrentUser={() => {}}
        />
      );

      const getHeaderCellAt = createHeaderSelector(wrapper);

      jestExpect(getHeaderCellAt(0)).toEqual(jestExpect.stringContaining('Box'));
      jestExpect(getHeaderCellAt(1)).toEqual(jestExpect.stringContaining('Weight'));
      jestExpect(getHeaderCellAt(2)).toEqual(jestExpect.stringContaining('Packaging Tare'));
      jestExpect(getHeaderCellAt(3)).toEqual(jestExpect.stringContaining('Net Weight'));
      jestExpect(getHeaderCellAt(4)).toEqual(jestExpect.stringContaining('Reason Code'));
    });

    test('should contain weight, packagingTare and net weight and no reason in each row', () => {
      const wrapper = shallow(
        <PackBoxTableComponent
          variant={PACK_OFF_NORMAL}
          packedBoxes={packedBoxes}
          reprintLabelsForCurrentUser={() => {}}
        />
      );
      const getRowAt = createCellSelector(wrapper);

      const firstRowAt = getRowAt(0);

      jestExpect(firstRowAt(0)).toEqual(jestExpect.stringContaining('3'));
      jestExpect(firstRowAt(1)).toEqual(jestExpect.stringContaining('123.00'));
      jestExpect(firstRowAt(2)).toEqual(jestExpect.stringContaining('1.16'));
      jestExpect(firstRowAt(3)).toEqual(jestExpect.stringContaining('121.84'));
      jestExpect(firstRowAt(4)).toEqual(jestExpect.stringContaining('777'));
      jestExpect(firstRowAt(5)).toEqual(jestExpect.stringContaining('REPRINT'));

      const secondRowAt = getRowAt(1);

      jestExpect(secondRowAt(0)).toEqual(jestExpect.stringContaining('2'));
      jestExpect(secondRowAt(1)).toEqual(jestExpect.stringContaining('358.00'));
      jestExpect(secondRowAt(2)).toEqual(jestExpect.stringContaining('2.0'));
      jestExpect(secondRowAt(3)).toEqual(jestExpect.stringContaining('356.00'));
      jestExpect(secondRowAt(4)).toEqual('<td class=""></td>');
      jestExpect(secondRowAt(5)).toEqual(jestExpect.stringContaining('REPRINT'));

      const thirdRowAt = getRowAt(2);

      jestExpect(thirdRowAt(0)).toEqual(jestExpect.stringContaining('1'));
      jestExpect(thirdRowAt(1)).toEqual(jestExpect.stringContaining('879.60'));
      jestExpect(thirdRowAt(2)).toEqual(jestExpect.stringContaining('6.60'));
      jestExpect(thirdRowAt(3)).toEqual(jestExpect.stringContaining('873.00'));
      jestExpect(thirdRowAt(4)).toEqual(jestExpect.stringContaining('555'));
      jestExpect(thirdRowAt(5)).toEqual(jestExpect.stringContaining('REPRINT'));
    });

    test('should render reprint button for each row', () => {
      boxResources.reprintLabelsForCurrentUser.mockResolvedValue({});
      const wrapper = shallow(
        <PackBoxTableComponent variant={PACK_OFF_NORMAL} packedBoxes={packedBoxes} />
      );

      jestExpect(wrapper.find(Button).length).toEqual(3);

      const firstButton = wrapper.find(Button).at(1);
      jestExpect(firstButton.childAt(0).text()).toBe('REPRINT');

      firstButton.simulate('click');
      jestExpect(boxResources.reprintLabelsForCurrentUser).toHaveBeenCalledTimes(1);
      jestExpect(boxResources.reprintLabelsForCurrentUser).toHaveBeenCalledWith(
        packedBoxes[1].id,
        'BOTH'
      );
    });
  });

  describe('WIP', () => {
    test('should contain header with weight, packagingTare and net weight and no reason', () => {
      const wrapper = shallow(
        <PackBoxTableComponent
          variant={PACK_OFF_WIP}
          packedBoxes={[]}
          reprintLabelsForCurrentUser={() => {}}
        />
      );

      const getHeaderCellAt = createHeaderSelector(wrapper);

      jestExpect(getHeaderCellAt(0)).toEqual(jestExpect.stringContaining('Product #'));
      jestExpect(getHeaderCellAt(1)).toEqual(jestExpect.stringContaining('Weight'));
      jestExpect(getHeaderCellAt(2)).toEqual(jestExpect.stringContaining('Packaging Tare'));
      jestExpect(getHeaderCellAt(3)).toEqual(jestExpect.stringContaining('Net Weight'));
      jestExpect(getHeaderCellAt(4)).toEqual(jestExpect.stringContaining(''));
    });

    test('should render reprint button for each row', () => {
      boxResources.reprintLabelsForCurrentUser.mockResolvedValue({});
      const wrapper = shallow(
        <PackBoxTableComponent variant={PACK_OFF_WIP} packedBoxes={packedBoxes} />
      );

      jestExpect(wrapper.find(Button).length).toEqual(3);

      const firstButton = wrapper.find(Button).at(1);
      jestExpect(firstButton.childAt(0).text()).toBe('REPRINT');

      firstButton.simulate('click');
      jestExpect(boxResources.reprintLabelsForCurrentUser).toHaveBeenCalledTimes(1);
      jestExpect(boxResources.reprintLabelsForCurrentUser).toHaveBeenCalledWith(
        packedBoxes[1].id,
        'BOX'
      );
    });
  });

  describe('RETAIL', () => {
    test('should show additional columns for Retail box label and retail tare', () => {
      const wrapper = shallow(
        <PackBoxTableComponent
          variant={PACK_OFF_RETAIL}
          packedBoxes={[]}
          reprintLabelsForCurrentUser={() => {}}
        />
      );

      const getHeaderCellAt = createHeaderSelector(wrapper);
      jestExpect(getHeaderCellAt(0)).toEqual(jestExpect.stringContaining('Box'));
      jestExpect(getHeaderCellAt(1)).toEqual(jestExpect.stringContaining('Tare'));
      jestExpect(getHeaderCellAt(2)).toEqual(jestExpect.stringContaining('Net Weight'));
      jestExpect(getHeaderCellAt(3)).toEqual(jestExpect.stringContaining('Retail Label'));
      jestExpect(getHeaderCellAt(4)).toEqual(jestExpect.stringContaining('Weight'));
      jestExpect(getHeaderCellAt(5)).toEqual(jestExpect.stringContaining('Retail Tare'));
      jestExpect(getHeaderCellAt(6)).toEqual(jestExpect.stringContaining('Net Weight'));
      jestExpect(getHeaderCellAt(7)).toEqual(jestExpect.stringContaining('Reason Code'));
    });

    test('should show the retail columns packaging tare', () => {
      const packedRetailBoxes = [
        {
          id: 1,
          packagingTare: 1.06,
          netWeight: 42.18,
          isFullBox: true,
          overrideWeightRangeReasonCode: 555,
          weighings: [
            {
              id: 1,
              weight: 11.0,
              retailPieceTare: 0.05,
              overrideWeightRangeReasonCode: null,
              type: 'RETAIL_PIECE'
            },
            {
              id: 2,
              weight: 12.0,
              retailPieceTare: 0.05,
              overrideWeightRangeReasonCode: null,
              type: 'RETAIL_PIECE'
            },
            {
              id: 3,
              weight: 11.96,
              retailPieceTare: 0.05,
              overrideWeightRangeReasonCode: null,
              type: 'RETAIL_PIECE'
            },
            {
              id: 4,
              weight: 12.52,
              retailPieceTare: 0.05,
              overrideWeightRangeReasonCode: 101,
              type: 'RETAIL_PIECE'
            }
          ]
        },
        {
          id: 2,
          netWeight: 10.89,
          packagingTare: 1.06,
          weighings: [
            {
              id: 5,
              weight: 11.95,
              retailPieceTare: 0.05,
              type: 'RETAIL_PIECE'
            }
          ]
        }
      ];
      const wrapper = shallow(
        <PackBoxTableComponent
          variant={PACK_OFF_RETAIL}
          packedBoxes={packedRetailBoxes}
          reprintLabelsForCurrentUser={() => {}}
          piecesPerCase={4}
        />
      );
      const rowSelector = createCellSelector(wrapper);
      const firstRowAt = rowSelector(0);

      jestExpect(firstRowAt(0)).toEqual(jestExpect.stringContaining('2'));
      jestExpect(firstRowAt(1)).toEqual('<td rowspan="1" class=""></td>'); // Don't show packaging tare
      jestExpect(firstRowAt(2)).toEqual('<td rowspan="1" class=""></td>');
      jestExpect(firstRowAt(3)).toEqual(jestExpect.stringContaining('1'));
      jestExpect(firstRowAt(4)).toEqual(jestExpect.stringContaining('11.95'));
      jestExpect(firstRowAt(5)).toEqual(jestExpect.stringContaining('0.05'));
      jestExpect(firstRowAt(6)).toEqual(jestExpect.stringContaining('11.90'));
      jestExpect(firstRowAt(7)).toEqual('<td class=""></td>');

      const secondRowAt = rowSelector(1);

      jestExpect(secondRowAt(0)).toEqual(jestExpect.stringContaining('1'));
      jestExpect(secondRowAt(1)).toEqual(jestExpect.stringContaining('1.06')); // show packaging tare!
      jestExpect(secondRowAt(2)).toEqual(jestExpect.stringContaining('42.18'));
      jestExpect(secondRowAt(3)).toEqual(jestExpect.stringContaining('4'));
      jestExpect(secondRowAt(4)).toEqual(jestExpect.stringContaining('12.52'));
      jestExpect(secondRowAt(5)).toEqual(jestExpect.stringContaining('0.05'));
      jestExpect(secondRowAt(6)).toEqual(jestExpect.stringContaining('12.47'));
      jestExpect(secondRowAt(7)).toEqual(jestExpect.stringContaining('101'));
      jestExpect(secondRowAt(8)).toEqual(jestExpect.stringContaining('REPRINT'));

      const thirdRowAt = rowSelector(2);

      // Third row starts at the first cell that is not spanning multiple rows
      jestExpect(thirdRowAt(0)).toEqual(jestExpect.stringContaining('3'));
      jestExpect(thirdRowAt(1)).toEqual(jestExpect.stringContaining('11.96'));
      jestExpect(thirdRowAt(2)).toEqual(jestExpect.stringContaining('0.05'));
      jestExpect(thirdRowAt(3)).toEqual(jestExpect.stringContaining('11.91'));
      jestExpect(thirdRowAt(4)).toEqual('<td class=""></td>');
      jestExpect(thirdRowAt(5)).toEqual(jestExpect.stringContaining('REPRINT'));

      const fourthRowAt = rowSelector(3);

      jestExpect(fourthRowAt(0)).toEqual(jestExpect.stringContaining('2'));
      jestExpect(fourthRowAt(1)).toEqual(jestExpect.stringContaining('12.00'));
      jestExpect(fourthRowAt(2)).toEqual(jestExpect.stringContaining('0.05'));
      jestExpect(fourthRowAt(3)).toEqual(jestExpect.stringContaining('11.95'));
      jestExpect(fourthRowAt(4)).toEqual('<td class=""></td>');
      jestExpect(fourthRowAt(5)).toEqual(jestExpect.stringContaining('REPRINT'));

      const fifthRowAt = rowSelector(4);

      jestExpect(fifthRowAt(0)).toEqual(jestExpect.stringContaining('1'));
      jestExpect(fifthRowAt(1)).toEqual(jestExpect.stringContaining('11.00'));
      jestExpect(fifthRowAt(2)).toEqual(jestExpect.stringContaining('0.05'));
      jestExpect(fifthRowAt(3)).toEqual(jestExpect.stringContaining('10.95'));
      jestExpect(fifthRowAt(4)).toEqual('<td class=""></td>');
      jestExpect(fifthRowAt(5)).toEqual(jestExpect.stringContaining('REPRINT'));
    });
  });
});

const createHeaderSelector = wrapper => col => {
  return wrapper
    .find(Table.Header)
    .find(Table.Row)
    .find(Table.HeaderCell)
    .at(col)
    .html();
};

const createCellSelector = wrapper => row => col => {
  return wrapper
    .find(Table.Body)
    .find(Table.Row)
    .at(row)
    .find(Table.Cell)
    .at(col)
    .html();
};
