import React from 'react';
import PropTypes from 'prop-types';
import ScaleInput from '../../shared/scale/components/ScaleInput';
import { Field } from 'redux-form';
import FormElement from '../../shared/FormElement';
import { Form } from 'semantic-ui-react';
import { normalizeToTwoDecimalPlaces } from '../../shared/components/product/normalizer';
import FormLabel from '../../shared/FormLabel';
import { formatNumberToTwoDecimalPlacesString } from '../../shared/util/dataUtil';
import _ from 'lodash';

export const getFixedWeight = product => {
  if (product.retailSpecific) {
    return formatNumberToTwoDecimalPlacesString(product.retailSpecific.minWeight);
  } else {
    return formatNumberToTwoDecimalPlacesString(product.minWeight);
  }
};

const PackingBoxWeight = ({ formName, scaleRef, netWeight, retailPieceTare, product }) => {
  const isFixedWeight = product && product.category === 'FIXED';
  const isRetailProduct = !_.isEmpty(_.get(product, 'retailSpecific', {}));
  return (
    <Form.Group>
      <ScaleInput formName={formName} fieldName='weight' label='Weight' ref={scaleRef} />
      <Form.Field width={1} />
      <Field
        name='packagingTare'
        component={FormElement}
        id='packaging-tare-input'
        as={Form.Input}
        type='text'
        label='Packaging Tare'
        width={4}
        normalize={normalizeToTwoDecimalPlaces}
      />
      {isRetailProduct && (
        <FormLabel
          pid='retail-piece-tare-display'
          label='Retail Piece Tare'
          value={formatNumberToTwoDecimalPlacesString(retailPieceTare)}
          width={4}
        />
      )}
      <FormLabel
        pid='net-weight-display'
        label='Net Weight'
        value={formatNumberToTwoDecimalPlacesString(netWeight)}
        width={4}
      />
      {isFixedWeight && (
        <FormLabel
          pid='fixed-weight-display'
          label='Fixed Weight'
          value={getFixedWeight(product)}
          width={4}
        />
      )}
    </Form.Group>
  );
};

PackingBoxWeight.propTypes = {
  formName: PropTypes.string.isRequired,
  scaleRef: PropTypes.func.isRequired,
  netWeight: PropTypes.oneOfType([PropTypes.string, PropTypes.number]).isRequired,
  product: PropTypes.object.isRequired,
  retailPieceTare: PropTypes.string
};

export default PackingBoxWeight;
