import _ from 'lodash';
import {
  isGreaterThanEqual,
  isLessThanEqual,
  number,
  positiveNumber,
  productWithWeight,
  required,
  validate
} from '../../shared/formValidations';

export const validateSubmission = (values, props) => {
  const { weight, packagingTare, overrideWeightRangeReasonCode } = values;
  const {
    order: {
      product: { minWeight, maxWeight, category, retailSpecific }
    },
    showOverrideWeightRangeRequest,
    netWeight
  } = props;
  let errors = {};

  errors = validate(errors, weight, 'weight', [
    required,
    number,
    positiveNumber,
    productWithWeight(maxWeight, minWeight)
  ]);
  errors = validate(errors, packagingTare, 'packagingTare', [required, number, positiveNumber]);

  if (!_.has(errors, 'weight') && !_.has(errors, 'packagingTare')) {
    errors = validate(
      errors,
      netWeight,
      'weight',
      [positiveNumber],
      'Weight should be greater than Packaging Tare'
    );
  }

  const header = 'Outside of range';
  if (
    !_.has(errors, 'weight') &&
    !_.has(errors, 'packagingTare') &&
    overrideWeightRangeReasonCode === ''
  ) {
    let minWeightToValidate = minWeight;
    let maxWeightToValidate = maxWeight;

    if (!_.isEmpty(retailSpecific)) {
      minWeightToValidate = retailSpecific.minWeight;
      maxWeightToValidate = retailSpecific.maxWeight;
    }

    if (category === 'CATCH') {
      const outOfRangeErrorMessage =
        `${header} - weight range is ${minWeightToValidate} - ${maxWeightToValidate}. ` +
        'Enter reason code and press enter to pack off.';

      errors = validate(errors, netWeight, 'weight', [
        isLessThanEqual(maxWeightToValidate, outOfRangeErrorMessage),
        isGreaterThanEqual(minWeightToValidate, outOfRangeErrorMessage)
      ]);
    }

    if (category === 'FIXED') {
      errors = validate(errors, netWeight, 'weight', [
        isGreaterThanEqual(
          minWeightToValidate,
          `Less than fixed weight - ${minWeightToValidate}. ` +
            'Enter reason code and press enter to pack off.'
        )
      ]);
    }

    if (_.has(errors, 'weight')) {
      showOverrideWeightRangeRequest();
    }
  }

  return errors;
};
