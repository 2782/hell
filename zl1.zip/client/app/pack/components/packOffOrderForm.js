import _ from 'lodash';
import React from 'react';
import PropTypes from 'prop-types';
import { change, Field, formValueSelector, reduxForm, SubmissionError } from 'redux-form';
import { Button, Divider, Form, Label } from 'semantic-ui-react';
import { connect } from 'react-redux';
import { validateSubmission } from './orderToPackValidator';
import { completeBanquetOrder, packBoxForOrder } from '../actions/orderToPackAction';
import PackBoxTable from './PackBoxTable';
import { BANQUET } from '../../../config/cutType';
import PackingBoxWeight from './PackingBoxWeight';
import FormElement from '../../shared/FormElement';
import { resetOverrideWeightRange, showOverrideWeightRangeRequest } from '../actions/packActions';
import { bindActionCreators } from 'redux';
import { number } from '../../shared/validation/formFieldValidations';
import { replacePath, showModal } from '../../shared/actions/actions';
import cutOrderResources from '../../shared/api/cutOrdersResources';
import { getDefaultTarePackage } from '../../settings/actions/tarePackagesActions';
import { PACK_OFF_NORMAL, PACK_OFF_RETAIL } from './packType';
import composeWeightValues from './composeWeightValues';
import { formatNumberToTwoDecimalPlacesString } from '../../shared/util/dataUtil';
import subscriber from '../../shared/functionKeys/subscriber';

const formName = 'packOffOrderForm';

const modalErrorMessage = {
  ['CUT_ORDER_IS_DELETED']: {
    header: 'Item Deleted From Sales Order',
    content: 'This item has been deleted from the order and cannot be packed off.'
  },
  ['CUT_ORDER_IS_CANCELLED']: {
    header: 'Sales Order Cancelled',
    content: 'This order has been cancelled and cannot be packed off.'
  }
};

export class PackOffOrderForm extends React.Component {
  constructor(props) {
    super(props);
  }

  componentDidMount() {
    const {
      order: { product },
      getDefaultTarePackage
    } = this.props;

    if (!product.tarePackage) {
      getDefaultTarePackage();
    }

    this.weightField.getWrappedInstance().refocus();
  }

  componentDidUpdate(prevProps) {
    const { netWeight, resetOverrideWeightRange, resetReasonCode } = this.props;

    if (prevProps.netWeight && (!netWeight || prevProps.netWeight !== netWeight)) {
      resetOverrideWeightRange();
      resetReasonCode();
    }
  }

  componentWillUnmount() {
    const { resetOverrideWeightRange } = this.props;
    resetOverrideWeightRange();
  }

  quantityRemaining() {
    const {
      order: { qtyInBoxes, qtyPacked }
    } = this.props;
    return qtyInBoxes - qtyPacked;
  }

  handleErrorResponse(errorResponse) {
    const {
      order: { id },
      showModal,
      replacePath
    } = this.props;
    const errorDetails = _.get(errorResponse, 'error.details', []);
    const errorDetailInfo = errorDetails.find(detail => !_.isEmpty(detail.field) === true);
    const errorType = _.get(errorDetailInfo, 'issue', '');

    if (errorType === 'CUT_ORDER_IS_DELETED' || errorType === 'CUT_ORDER_IS_CANCELLED') {
      showModal({
        ...modalErrorMessage[errorType],
        cancelButton: 'Go Back',
        cancelAction: () =>
          cutOrderResources.dismissCancelledOrder(id, () => replacePath('/pack/orders')),
        confirmButton: 'Pack as Stock',
        confirmAction: () =>
          cutOrderResources.dismissCancelledOrder(id, () => replacePath('/pack/pack-off-stock/'))
      });
    }

    const regex = /CUT_ORDER_IS_UPDATED:(\d+)/;
    const matchResult = errorType.match(regex);
    if (matchResult) {
      const quantityToPackRemaining = matchResult[1];
      showModal({
        header: 'Sales Order Quantity Change',
        content:
          `This order quantity has been reduced to ${quantityToPackRemaining}. ` +
          'Additional product cannot be packed off against the customer order.',
        cancelButton: 'Go Back',
        cancelAction: () => replacePath('/pack/orders'),
        confirmButton: 'Pack as Stock',
        confirmAction: () => replacePath('/pack/pack-off-stock/')
      });
    }
  }

  submit(values) {
    const {
      showOverrideWeightRange,
      resetOverrideWeightRange,
      order,
      packBoxForOrder
    } = this.props;

    const errors = validateSubmission(values, this.props);

    if (!_.isEmpty(errors)) {
      throw new SubmissionError(Object.assign({}, errors, { _error: 'Submission Failed!' }));
    }

    return packBoxForOrder({
      productionOrderId: order.id,
      qtyToProduce: order.qtyToProduce,
      weight: formatNumberToTwoDecimalPlacesString(values.weight),
      packagingTare: values.packagingTare,
      productCode: order.product.code,
      overrideWeightRangeReasonCode: values.overrideWeightRangeReasonCode
    })
      .then(() => {
        if (showOverrideWeightRange) {
          resetOverrideWeightRange();
        }
        this.weightField.getWrappedInstance().refocus();
      })
      .catch(errorResponse => {
        this.handleErrorResponse(_.get(errorResponse, 'response.data', {}));
      });
  }

  renderOverrideWeightRange() {
    const { showOverrideWeightRange } = this.props;

    return showOverrideWeightRange ? (
      <Form.Group>
        <Field
          component={FormElement}
          name='overrideWeightRangeReasonCode'
          pid='override-weight-range-reason-code'
          as={Form.Input}
          type='text'
          validate={number}
          label='Reason Code'
          autoFocus={true}
          width={3}
          maxLength={3}
        />
      </Form.Group>
    ) : (
      ''
    );
  }

  render() {
    const {
      handleSubmit,
      netWeight,
      order: { product, cutType, packedBoxes, piecesPerCase, qtyPacked },
      retailPieceTare,
      submitting,
      pristine,
      isRetail
    } = this.props;

    const disabledButton = this.quantityRemaining() <= 0;
    const variant = isRetail ? PACK_OFF_RETAIL : PACK_OFF_NORMAL;

    return (
      <div>
        <Form size={'large'} onSubmit={handleSubmit(this.submit.bind(this))}>
          <PackingBoxWeight
            formName={formName}
            scaleRef={node => (this.weightField = node)}
            netWeight={netWeight}
            retailPieceTare={retailPieceTare}
            product={product}
          />
          <div>
            {this.renderOverrideWeightRange()}
            <Button
              name='submit'
              primary
              size={'large'}
              className='submit'
              disabled={disabledButton || submitting || pristine}
            >
              LABEL
            </Button>
          </div>
          <Divider hidden />
          {this.quantityRemaining() <= 0 ? (
            <Label basic>All boxes have been packed: (F4) Back to pack order screen</Label>
          ) : null}
          {this.quantityRemaining() > 0 && qtyPacked > 0 && cutType === BANQUET ? (
            <Label basic>(F2) Finished with Custom pack</Label>
          ) : null}
        </Form>
        <PackBoxTable variant={variant} packedBoxes={packedBoxes} piecesPerCase={piecesPerCase} />
      </div>
    );
  }
}

PackOffOrderForm.propTypes = {
  order: PropTypes.shape({
    id: PropTypes.number.isRequired,
    packedBoxes: PropTypes.array.isRequired,
    customerOrder: PropTypes.object,
    unitOfMeasure: PropTypes.string.isRequired,
    qtyToProduce: PropTypes.number.isRequired,
    piecesPerCase: PropTypes.number,
    customerName: PropTypes.string,
    cutType: PropTypes.string.isRequired,
    product: PropTypes.shape({
      code: PropTypes.string.isRequired,
      description: PropTypes.string.isRequired,
      category: PropTypes.string.isRequired,
      minWeight: PropTypes.number,
      maxWeight: PropTypes.number,
      productPortionSize: PropTypes.shape({
        portionSize: PropTypes.string.isRequired
      })
    }),
    qtyPacked: PropTypes.number.isRequired,
    qtyInBoxes: PropTypes.number.isRequired
  }),
  completeBanquetOrder: PropTypes.func.isRequired,
  showOverrideWeightRange: PropTypes.bool,
  retailPieceTare: PropTypes.string,
  handleSubmit: PropTypes.func,
  resetOverrideWeightRange: PropTypes.func,
  getDefaultTarePackage: PropTypes.func,
  updateOverridePackagingTare: PropTypes.func,
  showOverrideWeightRangeRequest: PropTypes.func,
  netWeight: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  submitting: PropTypes.bool,
  pristine: PropTypes.bool,
  packBoxForOrder: PropTypes.func.isRequired,
  resetReasonCode: PropTypes.func,
  showModal: PropTypes.func,
  replacePath: PropTypes.func,
  isRetail: PropTypes.bool
};

const onSubmitSuccess = (result, dispatch, props) => {
  dispatch(change(props.form, 'weight', ''));
  dispatch(change(props.form, 'overrideWeightRangeReasonCode', ''));
  props.clearSubmitErrors(props.form);
};

const mapStateToProps = state => {
  const selector = formValueSelector(formName);
  const composedWeightValues = composeWeightValues(state, selector);

  return {
    initialValues: {
      packagingTare: composedWeightValues.initialPackagingTare,
      overrideWeightRangeReasonCode: ''
    },
    netWeight: composedWeightValues.netWeight,
    retailPieceTare: composedWeightValues.retailPieceTare,
    defaultPackagingTare: composedWeightValues.initialPackagingTare,
    isWeightFieldClean: _.isEmpty(composedWeightValues.weight),
    showOverrideWeightRange: state.orderToPackInfo.showOverrideWeightRangeRequest,
    isRetail: composedWeightValues.isRetailProduct
  };
};

const mapDispatchToProps = dispatch =>
  bindActionCreators(
    {
      packBoxForOrder,
      showOverrideWeightRangeRequest,
      resetOverrideWeightRange,
      getDefaultTarePackage,
      resetReasonCode: () => dispatch(change(formName, 'overrideWeightRangeReasonCode', '')),
      showModal,
      completeBanquetOrder,
      replacePath
    },
    dispatch
  );

export const f2Behavior = props => {
  const {
    order: { cutType, id, qtyPacked },
    completeBanquetOrder
  } = props;
  if (cutType === BANQUET && qtyPacked > 0) {
    completeBanquetOrder(id);
  }
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(
  reduxForm({
    form: formName,
    enableReinitialize: true,
    onSubmitSuccess
  })(
    subscriber(PackOffOrderForm, {
      f2Behavior,
      targetComponent: 'PackOffOrderForm',
      uris: {
        F2: ['#/pack/orders/*']
      }
    })
  )
);
