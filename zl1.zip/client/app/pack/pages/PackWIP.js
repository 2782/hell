import React from 'react';
import PropTypes from 'prop-types';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import { clearProductInfo, setHeaderAndFooter } from '../../shared/actions/actions';
import { clearWIPBoxes, packOffWIPBox } from '../actions/packActions';
import { clearState } from '../actions/orderToPackAction';
import PackBoxForm from '../components/PackBoxForm';
import PackBoxTable from '../components/PackBoxTable';
import { PACK_WIP } from '../../shared/components/pageTitles';
import { PACK_WIP_FOOTER } from '../../shared/components/pageFooters';
import { PACK_OFF_WIP } from '../components/packType';

const formName = 'packWIP';
export class PackWIPPage extends React.Component {
  constructor(props) {
    super(props);

    this.onReset = this.onReset.bind(this);
  }

  componentDidMount() {
    this.props.clearProductInfo();
    this.props.clearWIPBoxes();
    this.props.setHeaderAndFooter({
      header: PACK_WIP,
      footer: PACK_WIP_FOOTER
    });
  }

  componentWillUnmount() {
    this.props.clearState();
  }

  onReset() {
    this.props.clearProductInfo();
    this.props.clearWIPBoxes();
  }

  render() {
    const { wipBoxes, packOffWIPBox } = this.props;
    return (
      <div className='page-content' tabIndex={0}>
        <PackBoxForm
          form={formName}
          id='pack-box-form'
          packType={PACK_OFF_WIP}
          packedBoxes={wipBoxes}
          onSubmit={packOffWIPBox}
          onReset={this.onReset}
        />
        <PackBoxTable variant={PACK_OFF_WIP} packedBoxes={wipBoxes} />
      </div>
    );
  }
}

PackWIPPage.propTypes = {
  clearProductInfo: PropTypes.func.isRequired,
  packOffWIPBox: PropTypes.func.isRequired,
  clearWIPBoxes: PropTypes.func.isRequired,

  wipBoxes: PropTypes.array.isRequired,
  setHeaderAndFooter: PropTypes.func.isRequired,
  clearState: PropTypes.func.isRequired
};

const mapStateToProps = state => ({
  wipBoxes: state.packWIPReducer.wipBoxes
});

const mapDispatchToProps = dispatch =>
  bindActionCreators(
    {
      clearProductInfo,
      packOffWIPBox,
      clearWIPBoxes,
      setHeaderAndFooter,
      clearState
    },
    dispatch
  );

const PackWIP = connect(
  mapStateToProps,
  mapDispatchToProps
)(PackWIPPage);

export default PackWIP;
