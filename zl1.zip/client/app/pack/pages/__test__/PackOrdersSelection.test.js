import React from 'react';
import { mount } from 'enzyme';
import { Provider } from 'react-redux';
import { createReduxStore } from '../../../store';
import { Table } from 'semantic-ui-react';
import {
  cancelledCutOrder,
  cutOrder1WithNames,
  cutOrder2WithNames
} from '../../../shared/testData/cutOrdersForTesting';
import EmptyCutOrderTable from '../../../cut/components/EmptyCutOrderTable';
import PackOrdersSelection, {
  f5Behavior,
  PackOrdersSelectionComponent,
  sortGrindOrders
} from '../PackOrdersSelection';
import cutOrdersResources from '../../../shared/api/cutOrdersResources';
import semanticUI from '../../../../test-helpers/semantic-ui';
import {
  filterPackOrderByGrindTicketAndRoom,
  getPackOrdersInfo,
  loadPackOrderByCutTicketAndRoom
} from '../../actions/packActions';
import { changePath, showModal } from '../../../shared/actions/actions';
import grindingOrderFactory, {
  GRIND_ORDER_WITH_NATURAL_BLEND_1_2_GRIND,
  GRIND_ORDER_WITH_NATURAL_BLEND_1_2_GRIND_JIM_CUSTOMER_NAME,
  GRIND_ORDER_WITH_NATURAL_BLEND_1_2_GRIND_JIM_CUSTOMER_NAME_ITEM_NUMBER_34,
  GRIND_WITH_90_THREE_THIRTY_TWO_GRIND_SIZE_F19_TABLE,
  GRIND_WITH_KOBE_THREE_EIGHTS_GRIND_SIZE_F6_TABLE
} from '../../../../test-factories/grindingOrderFactory';
import { HOUSE_PAR_WITH_PRODUCT_3 } from '../../../../test-factories/housePar';

jest.mock('../../../shared/components/Header');
jest.mock('../../../shared/errors/ErrorNotification');
jest.mock('../../../shared/actions/actions', () => ({
  changePath: jest.fn(() => ({ type: 'MOCK_CHANGE_PATH' })),
  showModal: jest.fn(() => ({ type: 'MOCK_SHOW_MODAL' })),
  setHeaderAndFooter: jest.fn(() => ({ type: 'MOCK_SET_HEADER_AND_FOOTER' }))
}));

jest.mock('../../actions/packActions', () => ({
  loadPackOrderByCutTicketAndRoom: jest.fn(() => ({ type: 'MOCK_CHECK_PACK_ORDER' })),
  filterPackOrderByGrindTicketAndRoom: jest.fn(() => ({ type: 'MOCK_FILTER_GRIND_ORDER' })),
  getPackOrdersInfo: jest.fn(() => ({ type: 'MOCK_GET_PACK_ORDERS' }))
}));

jest.mock('../../../shared/api/cutOrdersResources');

describe('PackOrdersSelection', () => {
  let wrapper;
  let store;

  beforeEach(() => {
    jest.useFakeTimers();
    store = createReduxStore({
      portionRoomsInfo: {
        currentPortionRoom: {
          roomType: 'CUTTING'
        }
      },
      packOrdersInfo: {
        packOrders: [
          { orderId: cutOrder2WithNames.id, data: cutOrder2WithNames },
          { orderId: cutOrder1WithNames.id, data: cutOrder1WithNames },
          { orderId: cancelledCutOrder.id, data: cancelledCutOrder }
        ]
      }
    });

    wrapper = mount(
      <Provider store={store}>
        <PackOrdersSelection match={{ params: { tableId: '1' } }} />
      </Provider>
    );
  });

  describe('when there are no orders to pack', () => {
    test('should render empty cut order table', () => {
      store = createReduxStore({
        portionRoomsInfo: {
          currentPortionRoom: {
            roomType: 'CUTTING'
          }
        },
        packOrdersInfo: {
          packOrders: []
        }
      });

      wrapper = mount(
        <Provider store={store}>
          <PackOrdersSelection match={{ params: { tableId: '1' } }} />
        </Provider>
      );

      jestExpect(wrapper.find(EmptyCutOrderTable).exists()).toBeTruthy();
    });
  });

  describe('when there are orders to pack', () => {
    test('should focus to next row on down arrow', () => {
      const nextElementSibling = { focus: jest.fn() };

      wrapper
        .find(Table.Row)
        .at(1)
        .simulate('keydown', { key: 'ArrowDown', target: { nextElementSibling } });

      jestExpect(nextElementSibling.focus).toBeCalledTimes(1);
    });

    test('should focus to previous row on up arrow', () => {
      const previousElementSibling = { focus: jest.fn() };

      wrapper
        .find(Table.Row)
        .at(1)
        .simulate('keydown', { key: 'ArrowUp', target: { previousElementSibling } });

      jestExpect(previousElementSibling.focus).toBeCalledTimes(1);
    });

    describe('test actions', () => {
      let stopPropagation, preventDefault;

      beforeEach(() => {
        stopPropagation = jest.fn();
        preventDefault = jest.fn();
      });

      test('should navigate to pack order page on enter', () => {
        wrapper
          .find(Table.Row)
          .at(1)
          .simulate('keydown', { key: 'Enter', stopPropagation, preventDefault });

        jestExpect(stopPropagation).toHaveBeenCalled();
        jestExpect(preventDefault).toHaveBeenCalled();
        jestExpect(changePath).toHaveBeenCalledWith('/pack/orders/2');
      });

      test('should show confirm when trying to pack off cancelled order', () => {
        wrapper
          .find(Table.Row)
          .at(3)
          .simulate('keydown', { key: 'Enter', stopPropagation, preventDefault });

        jestExpect(stopPropagation).toHaveBeenCalled();
        jestExpect(preventDefault).toHaveBeenCalled();
        jestExpect(showModal).toHaveBeenCalledWith(
          jestExpect.objectContaining({
            header: 'Sales Order Cancelled',
            content: 'This order has been cancelled and cannot be packed off.',
            cancelButton: 'Dismiss',
            cancelAction: jestExpect.any(Function),
            confirmButton: 'Pack as Stock',
            confirmAction: jestExpect.any(Function)
          })
        );
      });

      test('should dismiss cut order and replace pack off screen with pack off stock screen when sales order is cancelled', () => {
        cutOrdersResources.dismissCancelledOrder.mockImplementation((arg, callback) => callback());

        const props = {
          packOrders: [{ orderId: 123, data: cancelledCutOrder }],
          showModal: jest.fn(options => options.confirmAction()),
          changePath: jest.fn()
        };
        const component = new PackOrdersSelectionComponent(props);

        component.onEnter(123);

        jestExpect(props.changePath).toBeCalledWith('/pack/pack-off-stock/');
      });

      test('should dismiss cut order and replace pack off screen with pack off stock screen when customer order is on hold', () => {
        cutOrdersResources.dismissCancelledOrder.mockImplementation((arg, callback) => callback());

        const props = {
          packOrders: [{ orderId: 123, data: { customerOrder: { onHold: true } } }],
          showModal: jest.fn(options => options.confirmAction()),
          changePath: jest.fn(),
          hideModal: jest.fn()
        };
        const component = new PackOrdersSelectionComponent(props);

        component.onEnter(123);

        jestExpect(props.changePath).toBeCalledWith('/pack/pack-off-stock/');
      });

      test('should hide model when customer order is on hold and click cancel', () => {
        cutOrdersResources.dismissCancelledOrder.mockImplementation((arg, callback) => callback());

        const hideModalAction = jest.fn();
        const props = {
          packOrders: [{ orderId: 123, data: { customerOrder: { onHold: true } } }],
          showModal: jest.fn(options => options.cancelAction()),
          changePath: jest.fn(),
          hideModal: hideModalAction
        };
        const component = new PackOrdersSelectionComponent(props);

        component.onEnter(123);

        jestExpect(hideModalAction).toHaveBeenCalled();
      });

      test('should get packBoxForOrder and table info on mount', () => {
        jestExpect(getPackOrdersInfo).toHaveBeenCalled();
      });
    });

    test('should have packOrdersInOrder in correct order', () => {
      const packOffOrders = [
        { data: grindingOrderFactory.build() },
        { data: GRIND_WITH_KOBE_THREE_EIGHTS_GRIND_SIZE_F6_TABLE },
        { data: GRIND_WITH_90_THREE_THIRTY_TWO_GRIND_SIZE_F19_TABLE },
        { data: GRIND_ORDER_WITH_NATURAL_BLEND_1_2_GRIND },
        { data: GRIND_ORDER_WITH_NATURAL_BLEND_1_2_GRIND_JIM_CUSTOMER_NAME },
        { data: HOUSE_PAR_WITH_PRODUCT_3 },
        { data: GRIND_ORDER_WITH_NATURAL_BLEND_1_2_GRIND_JIM_CUSTOMER_NAME_ITEM_NUMBER_34 }
      ];

      const jestExpectedOrders = [
        { data: GRIND_ORDER_WITH_NATURAL_BLEND_1_2_GRIND_JIM_CUSTOMER_NAME },
        { data: GRIND_ORDER_WITH_NATURAL_BLEND_1_2_GRIND_JIM_CUSTOMER_NAME_ITEM_NUMBER_34 },
        { data: GRIND_ORDER_WITH_NATURAL_BLEND_1_2_GRIND },
        { data: grindingOrderFactory.build() },
        { data: GRIND_WITH_KOBE_THREE_EIGHTS_GRIND_SIZE_F6_TABLE },
        { data: GRIND_WITH_90_THREE_THIRTY_TWO_GRIND_SIZE_F19_TABLE },
        { data: HOUSE_PAR_WITH_PRODUCT_3 }
      ];

      const results = sortGrindOrders(packOffOrders);

      jestExpect(results).toEqual(jestExpectedOrders);
    });
  });

  describe('cut ticket code input field', () => {
    test('should not show cut ticket code input field if current room is grinding', () => {
      store = createReduxStore({
        portionRoomsInfo: {
          currentPortionRoom: {
            roomType: 'GRINDING',
            code: 'TEST_GRINDING_ROOM_CODE'
          }
        }
      });
      wrapper = mount(
        <Provider store={store}>
          <PackOrdersSelection match={{ params: { tableId: '1' } }} />
        </Provider>
      );

      jestExpect(semanticUI.findLabelWithName(wrapper, 'Grind Ticket Barcode').exists()).toBeTruthy;
      jestExpect(semanticUI.findLabelWithName(wrapper, 'Cut Ticket Barcode').exists()).toBeFalsy();
    });

    test('should dispatch check for valid pack order when cut ticket code is submitted through input field', () => {
      const cuttingRoomCode = 'B';
      const cutTicketCode = 'C1207920123';

      store = createReduxStore({
        portionRoomsInfo: {
          currentPortionRoom: {
            roomType: 'CUTTING',
            code: cuttingRoomCode
          }
        }
      });

      wrapper = mount(
        <Provider store={store}>
          <PackOrdersSelection match={{ params: { tableId: '1' } }} />
        </Provider>
      );

      semanticUI.changeInput(wrapper, 'ticketCode', cutTicketCode);

      wrapper.find('form').simulate('submit');

      jestExpect(loadPackOrderByCutTicketAndRoom).toHaveBeenCalledWith(
        cutTicketCode,
        cuttingRoomCode
      );
    });
  });

  describe('grind ticket code input field', () => {
    test('should not show grind ticket code input field if current room is cutting', () => {
      store = createReduxStore({
        portionRoomsInfo: {
          currentPortionRoom: {
            roomType: 'CUTTING',
            code: 'TEST_CUTTING_ROOM_CODE'
          }
        }
      });

      wrapper = mount(
        <Provider store={store}>
          <PackOrdersSelection match={{ params: { tableId: '1' } }} />
        </Provider>
      );

      jestExpect(semanticUI.findLabelWithName(wrapper, 'Cut Ticket Barcode').exists()).toBeTruthy;
      jestExpect(
        semanticUI.findLabelWithName(wrapper, 'Grind Ticket Barcode').exists()
      ).toBeFalsy();
    });

    test('should dispatch check for valid pack order when grind ticket code is submitted through input field', () => {
      const grindRoomCode = 'D';
      const grindTicketCode = 'G1207191916172D';

      let grindingStore = createReduxStore({
        packOrdersInfo: {
          packOrders: [
            {
              orderId: GRIND_ORDER_WITH_NATURAL_BLEND_1_2_GRIND.id,
              data: GRIND_ORDER_WITH_NATURAL_BLEND_1_2_GRIND
            }
          ]
        },
        portionRoomsInfo: {
          currentPortionRoom: {
            roomType: 'GRINDING',
            code: grindRoomCode
          }
        }
      });

      wrapper = mount(
        <Provider store={grindingStore}>
          <PackOrdersSelection match={{ params: { tableId: '1' } }} />
        </Provider>
      );

      semanticUI.changeInput(wrapper, 'ticketCode', grindTicketCode);

      wrapper.find('form').simulate('submit');

      jestExpect(filterPackOrderByGrindTicketAndRoom).toHaveBeenCalledWith(
        [
          {
            orderId: GRIND_ORDER_WITH_NATURAL_BLEND_1_2_GRIND.id,
            data: GRIND_ORDER_WITH_NATURAL_BLEND_1_2_GRIND
          }
        ],
        grindTicketCode,
        grindRoomCode
      );
    });
  });

  describe('f5Behavior', () => {
    test('should reset the form when F5 is pressed', () => {
      const props = {
        reset: jest.fn(),
        getPackOrdersInfo: jest.fn()
      };

      f5Behavior(props);

      jestExpect(props.reset).toHaveBeenCalled();
      jestExpect(props.getPackOrdersInfo).toHaveBeenCalled();
    });
  });

  describe('auto-refresh data', () => {
    beforeEach(() => {
      jest.useFakeTimers();
    });

    afterEach(() => {
      jest.clearAllTimers();
    });

    describe('cutting room', () => {
      let packOrdersSelectionComponent;

      beforeEach(() => {
        packOrdersSelectionComponent = new PackOrdersSelectionComponent({
          setHeaderAndFooter: jest.fn(),
          getPackOrdersInfo: jest.fn(),
          isCuttingRoom: true
        });
      });
      test('should call setInterval when componentDidMount for cutting room', () => {
        packOrdersSelectionComponent.componentDidMount();
        jestExpect(setInterval).toHaveBeenCalledTimes(1);
      });

      test('should call clearInterval when componentWillUnmount for cutting room', () => {
        packOrdersSelectionComponent.componentWillUnmount();
        jestExpect(clearInterval).toHaveBeenCalledTimes(1);
      });
    });

    describe('grinding room', () => {
      let packOrdersSelectionComponent;

      beforeEach(() => {
        packOrdersSelectionComponent = new PackOrdersSelectionComponent({
          setHeaderAndFooter: jest.fn(),
          getPackOrdersInfo: jest.fn(),
          isCuttingRoom: false
        });
      });
      test('should call setInterval when componentDidMount for grinding room', () => {
        packOrdersSelectionComponent.componentDidMount();
        jestExpect(setInterval).toHaveBeenCalledTimes(0);
      });

      test('should call clearInterval when componentWillUnmount for grinding room', () => {
        packOrdersSelectionComponent.componentWillUnmount();
        jestExpect(clearInterval).toHaveBeenCalledTimes(0);
      });
    });
  });
});
