import React from 'react';
import PropTypes from 'prop-types';
import _ from 'lodash';
import { connect } from 'react-redux';
import { changePath, hideModal, setHeaderAndFooter, showModal } from '../../shared/actions/actions';
import { PACK_STATION } from '../../shared/components/pageTitles';
import { bindActionCreators } from 'redux';
import CutOrderTable from '../../cut/components/CutOrderTable';
import EmptyCutOrderTable from '../../cut/components/EmptyCutOrderTable';
import {
  filterPackOrderByGrindTicketAndRoom,
  getPackOrdersInfo,
  loadPackOrderByCutTicketAndRoom
} from '../actions/packActions';
import { PACK_STATION_FOOTER } from '../../shared/components/pageFooters';
import cutOrderResources from '../../shared/api/cutOrdersResources';
import { Field, reduxForm } from 'redux-form';
import FormElement from '../../shared/FormElement';
import { Divider, Form } from 'semantic-ui-react';
import GrindSizePriorityEnum from '../../grind/pages/GrindSizePriorityEnum';
import { POLLING_INTERVAL } from '../../shared/constants';
import subscriber from '../../shared/functionKeys/subscriber';

export class PackOrdersSelectionComponent extends React.Component {
  constructor(props) {
    super(props);

    this.onEnter = this.onEnter.bind(this);
    this.submit = this.submit.bind(this);
  }

  componentDidMount() {
    const { isCuttingRoom, getPackOrdersInfo, setHeaderAndFooter } = this.props;

    getPackOrdersInfo();
    setHeaderAndFooter({
      header: PACK_STATION,
      footer: PACK_STATION_FOOTER
    });

    if (isCuttingRoom) {
      this.intervalNumber = setInterval(() => {
        this.props.getPackOrdersInfo();
      }, POLLING_INTERVAL);
    }
  }

  componentWillUnmount() {
    const { isCuttingRoom } = this.props;

    if (isCuttingRoom) {
      clearInterval(this.intervalNumber);
    }
  }

  onEnter(orderId) {
    const { packOrders, changePath, showModal, hideModal, getPackOrdersInfo } = this.props;

    const packOrder = packOrders.find(item => item.orderId === orderId);
    if (packOrder.data.deleted) {
      showModal({
        header: 'Sales Order Cancelled',
        content: 'This order has been cancelled and cannot be packed off.',
        cancelButton: 'Dismiss',
        cancelAction: () => cutOrderResources.dismissCancelledOrder(orderId, getPackOrdersInfo),
        confirmButton: 'Pack as Stock',
        confirmAction: () =>
          cutOrderResources.dismissCancelledOrder(orderId, () =>
            changePath('/pack/pack-off-stock/')
          )
      });
    } else if (packOrder.data.customerOrder && packOrder.data.customerOrder.onHold) {
      showModal({
        header: 'Sales Order on Credit Hold',
        content:
          'This customer is on credit hold and this sales order cannot be packed off against.',
        cancelButton: 'Cancel',
        cancelAction: () => hideModal(),
        confirmButton: 'Pack as Stock',
        confirmAction: () =>
          cutOrderResources.dismissCancelledOrder(orderId, () =>
            changePath('/pack/pack-off-stock/')
          )
      });
    } else {
      changePath(`/pack/orders/${orderId}`);
    }
  }

  submit(values) {
    const { isCuttingRoom, packOrders } = this.props;
    const { ticketCode } = values;

    if (ticketCode) {
      const {
        loadPackOrderByCutTicketAndRoom,
        filterPackOrderByGrindTicketAndRoom,
        currentPortionRoom
      } = this.props;
      return isCuttingRoom
        ? loadPackOrderByCutTicketAndRoom(ticketCode, currentPortionRoom.code)
        : filterPackOrderByGrindTicketAndRoom(packOrders, ticketCode, currentPortionRoom.code);
    }
  }

  render() {
    const { packOrders, isCuttingRoom, handleSubmit } = this.props;

    const packOrdersInOrder = isCuttingRoom ? packOrders : sortGrindOrders(packOrders);

    return (
      <div className='page-content pack-orders-selection'>
        <Form pid='ticket-code-input-form' size={'large'} onSubmit={handleSubmit(this.submit)}>
          <Divider hidden className='pack-orders-selection-divider' />
          <Field
            autoFocus={true}
            as={Form.Input}
            component={FormElement}
            label={isCuttingRoom ? 'Cut Ticket Barcode' : 'Grind Ticket Barcode'}
            name='ticketCode'
            pid='ticket-code-input'
            placeholder='Scan Barcode'
            width={4}
          />
        </Form>

        {packOrders === null ? null : _.isEmpty(packOrders) ? (
          <EmptyCutOrderTable autoFocus={false} />
        ) : (
          <CutOrderTable
            autoFocus={false}
            cutOrdersInfo={packOrdersInOrder}
            handleSelect={this.onEnter}
            handleConfirm={this.onEnter}
          />
        )}
      </div>
    );
  }
}

export const sortGrindOrders = packOrders => {
  return _(packOrders)
    .sortBy([
      order => order.data.blend.priority,
      order => GrindSizePriorityEnum[order.data.product.grindSpecific.grindSize],
      order => order.data.product.code,
      order => _.get(order, 'data.customerOrder.customer.name', '')
    ])
    .value();
};

PackOrdersSelectionComponent.propTypes = {
  packOrders: PropTypes.array,
  getPackOrdersInfo: PropTypes.func.isRequired,
  changePath: PropTypes.func.isRequired,
  setHeaderAndFooter: PropTypes.func.isRequired,
  showModal: PropTypes.func.isRequired,
  hideModal: PropTypes.func,
  currentPortionRoom: PropTypes.object,
  isCuttingRoom: PropTypes.bool,
  loadPackOrderByCutTicketAndRoom: PropTypes.func.isRequired,
  filterPackOrderByGrindTicketAndRoom: PropTypes.func.isRequired,
  handleSubmit: PropTypes.func.isRequired
};

const mapStateToProps = state => {
  const currentPortionRoom = state.portionRoomsInfo.currentPortionRoom;
  const packOrders = state.packOrdersInfo.packOrders;
  const { roomType } = currentPortionRoom;
  const isCuttingRoom = 'cutting' === roomType.toLowerCase();

  return {
    packOrders,
    currentPortionRoom,
    isCuttingRoom
  };
};

const mapDispatchToProps = dispatch =>
  bindActionCreators(
    {
      changePath,
      getPackOrdersInfo,
      setHeaderAndFooter,
      showModal,
      hideModal,
      loadPackOrderByCutTicketAndRoom,
      filterPackOrderByGrindTicketAndRoom
    },
    dispatch
  );

export const f5Behavior = props => {
  const { getPackOrdersInfo } = props;

  props.reset();
  getPackOrdersInfo();
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(
  reduxForm({
    form: 'packOrdersSelection'
  })(
    subscriber(PackOrdersSelectionComponent, {
      f5Behavior,
      targetComponent: 'PackOrdersSelectionComponent',
      uris: {
        F5: ['#/pack/orders']
      }
    })
  )
);
