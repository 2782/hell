import { REGISTER_PRODUCT_CODE_FIELD, REGISTER_WEIGHT_FIELD } from '../actions/packActionTypes';

export const initialState = {
  productCodeField: {
    getRenderedComponent: () => ({
      focusInput: () => {}
    })
  },
  weightField: {
    getWrappedInstance: () => ({
      refocus: () => {}
    })
  }
};

export default (state = initialState, action) => {
  switch (action.type) {
    case REGISTER_PRODUCT_CODE_FIELD:
      return {
        ...state,
        productCodeField: action.payload
      };

    case REGISTER_WEIGHT_FIELD:
      return {
        ...state,
        weightField: action.payload
      };

    default:
      return state;
  }
};
