import packOrdersReducer from '../packOrdersReducer';
import { UPDATE_PACK_ORDERS_INFO } from '../../actions/packActionTypes';
import { LOCATION_CHANGE } from 'react-router-redux';

describe('packOrdersReducer', () => {
  let initState;
  beforeEach(() => {
    initState = {
      packOrders: null
    };
  });

  test('should return initState when handle unexpect action', () => {
    let unexpectAction = { type: 'unexpect' };
    jestExpect(packOrdersReducer(initState, unexpectAction)).toEqual(initState);
  });

  test('should return initState location change', () => {
    let locationChangeAction = { type: LOCATION_CHANGE };
    jestExpect(packOrdersReducer(initState, locationChangeAction)).toEqual(initState);
  });

  test('should update cutOrder state when handle UPDATE_PACK_ORDERS_INFO ', () => {
    let payload = [{ id: 1, deliveryDate: '2017-10-22' }, { id: 2, deliveryDate: '2017-10-23' }];

    jestExpect(
      packOrdersReducer(initState, {
        type: UPDATE_PACK_ORDERS_INFO,
        payload: payload
      })
    ).toEqual({ ...initState, packOrders: payload });
  });
});
