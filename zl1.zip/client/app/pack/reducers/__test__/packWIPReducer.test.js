import packWIPReducer from '../packWIPReducer';
import { RESET_WIP_BOXES, UPDATE_WIP_BOXES } from '../../actions/packActionTypes';

describe('packWIPReducer', () => {
  let initState;

  beforeEach(() => {
    initState = {
      wipBoxes: []
    };
  });

  test('should return default state when handle unexpectedAction', () => {
    jestExpect(packWIPReducer(initState, { type: 'unexpected' })).toEqual(initState);
  });

  test('should return default state when handle RESET_WIP_BOXES', () => {
    const state = {
      wipBoxes: [{ weight: '2.0', packagingTare: '1.00' }]
    };
    jestExpect(packWIPReducer(state, { type: RESET_WIP_BOXES })).toEqual(initState);
  });

  test('should return default state when handle UPDATE_WIP_BOXES', () => {
    const state = {
      wipBoxes: [{ weight: '2.0', packagingTare: '1.00' }]
    };
    jestExpect(
      packWIPReducer(initState, {
        type: UPDATE_WIP_BOXES,
        payload: { weight: '2.0', packagingTare: '1.00' }
      })
    ).toEqual(state);
  });
});
