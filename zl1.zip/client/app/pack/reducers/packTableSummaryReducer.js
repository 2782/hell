import { UPDATE_PACK_TABLE_SUMMARY } from '../actions/packActionTypes';

const initialState = {
  tables: null
};

export default (state = initialState, action) => {
  switch (action.type) {
    case UPDATE_PACK_TABLE_SUMMARY:
      return {
        ...state,
        tables: action.payload
      };

    default:
      return state;
  }
};
