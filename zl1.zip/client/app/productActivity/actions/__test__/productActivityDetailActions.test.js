import {
  CUSTOMER_PACKOFF,
  FINISHED_STOCK_WIP_PACKOFF,
  getProductActivityDetails,
  handleDetailsSort,
  productActivityDetailsChangePage,
  SOURCE_WIP_STOCK_PACKOFF
} from '../productActivityDetailActions';
import {
  PRODUCT_ACTIVITY_DETAILS_FETCHED,
  DETAILS_SORTED_BY_COLUMN
} from '../productActivityActionTypes';
import ReportingBoxAggregateEventFactory from '../../../../test-factories/reportingBoxAggregateEvent';
import { ReportingReturnBoxPackSequence } from '../../../../test-factories/productActivity';
import reportingResources from '../../../shared/api/reportingResources';

jest.mock('../../../shared/api/reportingResources', () => ({
  getCustomerBoxes: jest.fn(),
  getStockWipBoxesForFinished: jest.fn(),
  getWipBoxesForSource: jest.fn()
}));

describe('ProductActivityActions', () => {
  let dispatch;

  beforeEach(() => {
    dispatch = jest.fn();
  });

  afterEach(() => {
    reportingResources.getCustomerBoxes.mockReset();
    reportingResources.getStockWipBoxesForFinished.mockReset();
    reportingResources.getWipBoxesForSource.mockReset();
    dispatch.mockReset();
  });

  test('should request boxes for customer packoff', done => {
    const getState = () => ({
      productActivityDetail: {
        productActivityDetailsSortColumn: 'quantity',
        productActivityDetailsSortDirection: 'asc'
      }
    });
    const aggregateBox = ReportingBoxAggregateEventFactory.build();
    const box = ReportingReturnBoxPackSequence.build();

    reportingResources.getCustomerBoxes.mockResolvedValue({ data: box });
    return getProductActivityDetails({
      activityType: CUSTOMER_PACKOFF,
      productActivity: aggregateBox.data
    })(dispatch, getState).then(() => {
      jestExpect(dispatch).toHaveBeenCalledWith({
        type: PRODUCT_ACTIVITY_DETAILS_FETCHED,
        payload: box
      });
      done();
    });
  });

  test('should request boxes for finished stock/wip boxes', () => {
    const getState = () => ({
      productActivityDetail: {
        productActivityDetailsSortColumn: 'quantity',
        productActivityDetailsSortDirection: 'asc'
      }
    });
    const aggregateBox = ReportingBoxAggregateEventFactory.build();
    const box = ReportingReturnBoxPackSequence.build();
    const dispatch = jest.fn();

    reportingResources.getStockWipBoxesForFinished.mockResolvedValue({ data: box });

    return getProductActivityDetails({
      activityType: FINISHED_STOCK_WIP_PACKOFF,
      productActivity: aggregateBox.data
    })(dispatch, getState).then(() => {
      jestExpect(dispatch).toHaveBeenCalledWith({
        type: PRODUCT_ACTIVITY_DETAILS_FETCHED,
        payload: box
      });
    });
  });

  test('should request boxes for source wip boxes', done => {
    const getState = () => ({
      productActivityDetail: {
        productActivityDetailsSortColumn: 'quantity',
        productActivityDetailsSortDirection: 'asc'
      }
    });
    const productActivity = ReportingBoxAggregateEventFactory.build();
    const box = ReportingReturnBoxPackSequence.build();
    const dispatch = jest.fn();

    reportingResources.getWipBoxesForSource.mockResolvedValue({ data: box });
    return getProductActivityDetails({
      activityType: SOURCE_WIP_STOCK_PACKOFF,
      productActivity: productActivity.data
    })(dispatch, getState).then(() => {
      jestExpect(dispatch).toHaveBeenCalledWith({
        type: PRODUCT_ACTIVITY_DETAILS_FETCHED,
        payload: box
      });
      done();
    });
  });

  test('should change page by calling product detail', () => {
    reportingResources.getStockWipBoxesForFinished.mockResolvedValue({
      data: 'DATA'
    });

    const productActivitySearchCriteria = {
      productCode: '4102218',
      startDate: '2018-11-14',
      endDate: '2018-11-14'
    };

    const productActivityDetailCriteria = {
      customerCode: null,
      customerName: null,
      customerOrderNumber: null,
      incomplete: false,
      key: 'box-13',
      packoffStationName: 'JOHN',
      productCode: '2111148',
      quantity: 5,
      roomCode: 'A',
      shipDate: null,
      stationCode: 91,
      stationName: 'ALEX',
      status: 'ASSIGNED',
      tableCode: 91,
      tableName: 'STEAK',
      timestamp: '2018-12-24T11:16:41.245+08:00',
      type: 'Box',
      uom: 'CASE',
      weight: 161.45,
      workingDate: '2018-12-20'
    };
    const page = 0;
    const getState = () => ({
      productActivityDetail: {
        productActivityDetailsSortColumn: 'shipDate',
        productActivityDetailsSortDirection: 'desc',
        productActivityDetailCriteria: {
          activityType: FINISHED_STOCK_WIP_PACKOFF,
          ...productActivityDetailCriteria
        }
      },
      productActivity: {
        productActivitySearchCriteria
      }
    });

    return productActivityDetailsChangePage(0)(dispatch, getState).then(() => {
      jestExpect(reportingResources.getStockWipBoxesForFinished).toHaveBeenCalledWith({
        ...productActivityDetailCriteria,
        sortColumn: 'shipDate',
        sortDirection: 'desc',
        page
      });
    });
  });

  test('should handle sort when calling product activities', () => {
    reportingResources.getCustomerBoxes.mockResolvedValue({
      data: 'DATA'
    });

    const getState = () => ({
      productActivityDetail: {
        productActivityDetailCriteria: {
          productCode: '2111148',
          activityType: CUSTOMER_PACKOFF
        },
        productActivityDetailsSortColumn: 'EXISTING_SORT_COLUMN',
        productActivityDetailsSortDirection: 'asc'
      }
    });

    return handleDetailsSort('EXISTING_SORT_COLUMN')(dispatch, getState).then(() => {
      jestExpect(reportingResources.getCustomerBoxes).toHaveBeenCalledWith({
        page: 0,
        productCode: '2111148',
        sortColumn: 'EXISTING_SORT_COLUMN',
        sortDirection: 'desc'
      });
      jestExpect(dispatch).toHaveBeenCalledWith({
        type: DETAILS_SORTED_BY_COLUMN,
        payload: {
          productActivityDetailsSortColumn: 'EXISTING_SORT_COLUMN',
          productActivityDetailsSortDirection: 'desc'
        }
      });
    });
  });
});
