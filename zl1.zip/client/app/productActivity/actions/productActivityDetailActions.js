import reportingResources from '../../shared/api/reportingResources';
import {
  PRODUCT_ACTIVITY_DETAILS_FETCHED,
  PRODUCT_ACTIVITY_DETAIL_CRITERIA_SAVED,
  DETAILS_SORTED_BY_COLUMN
} from './productActivityActionTypes';
import { calculateSort } from '../../shared/util/sortUtil';

export const fetchProductActivityDetails = response => ({
  type: PRODUCT_ACTIVITY_DETAILS_FETCHED,
  payload: response.data
});

export const handleDetailsSort = columnToSort => (dispatch, getState) => {
  const {
    activityType,
    ...productActivity
  } = getState().productActivityDetail.productActivityDetailCriteria;
  return getProductActivityDetails({ activityType, productActivity, columnToSort })(
    dispatch,
    getState
  );
};

export const productActivityDetailsChangePage = changeToPage => (dispatch, getState) => {
  const {
    activityType,
    ...detailCriteria
  } = getState().productActivityDetail.productActivityDetailCriteria;
  return getProductActivityDetails({
    activityType,
    productActivity: detailCriteria,
    page: changeToPage
  })(dispatch, getState);
};

export const saveProductActivityDetailCriteria = (activityType, productActivity) => ({
  type: PRODUCT_ACTIVITY_DETAIL_CRITERIA_SAVED,
  payload: { activityType, ...productActivity }
});

export const CUSTOMER_PACKOFF = 'CUSTOMER_PACKOFF';
export const FINISHED_STOCK_WIP_PACKOFF = 'FINISHED_WIP_STOCK_PACKOFF';
export const SOURCE_WIP_STOCK_PACKOFF = 'SOURCE_WIP_STOCK_PACKOFF';

export const getProductActivityDetails = ({
  activityType,
  productActivity,
  page = 0,
  columnToSort = null
}) => (dispatch, getState) => {
  const {
    productActivityDetailsSortColumn,
    productActivityDetailsSortDirection
  } = getState().productActivityDetail;
  const { sortColumn, sortDirection } = calculateSort(
    columnToSort,
    productActivityDetailsSortColumn,
    productActivityDetailsSortDirection
  );

  const activityTypes = {
    [CUSTOMER_PACKOFF]: reportingResources.getCustomerBoxes,
    [FINISHED_STOCK_WIP_PACKOFF]: reportingResources.getStockWipBoxesForFinished,
    [SOURCE_WIP_STOCK_PACKOFF]: reportingResources.getWipBoxesForSource
  };

  return activityTypes[activityType]({ ...productActivity, page, sortColumn, sortDirection }).then(
    response => {
      dispatch({
        type: DETAILS_SORTED_BY_COLUMN,
        payload: {
          productActivityDetailsSortColumn: sortColumn,
          productActivityDetailsSortDirection: sortDirection
        }
      });
      dispatch(fetchProductActivityDetails(response));
    }
  );
};
