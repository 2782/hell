import React from 'react';
import PropTypes from 'prop-types';
import { Table } from 'semantic-ui-react';

const convertForSemantic = {
  asc: 'ascending',
  desc: 'descending'
};

const ReportingTableHeader = ({ sortColumn, sortDirection, handleSort }) => {
  return (
    <Table.Header>
      <Table.Row>
        <Table.HeaderCell
          width={4}
          sorted={sortColumn === 'timestamp' ? convertForSemantic[sortDirection] : null}
          onClick={() => handleSort('timestamp')}
        >
          DATE
        </Table.HeaderCell>
        <Table.HeaderCell
          width={3}
          sorted={sortColumn === 'type' ? convertForSemantic[sortDirection] : null}
          onClick={() => handleSort('type')}
        >
          TYPE
        </Table.HeaderCell>
        <Table.HeaderCell
          width={2}
          sorted={sortColumn === 'quantity,weight' ? convertForSemantic[sortDirection] : null}
          onClick={() => handleSort('quantity,weight')}
        >
          QTY
        </Table.HeaderCell>
        <Table.HeaderCell
          sorted={sortColumn === 'customerName' ? convertForSemantic[sortDirection] : null}
          onClick={() => handleSort('customerName')}
        >
          CUSTOMER
        </Table.HeaderCell>
        <Table.HeaderCell
          width={2}
          sorted={sortColumn === 'shipDate' ? convertForSemantic[sortDirection] : null}
          onClick={() => handleSort('shipDate')}
          textAlign={'right'}
        >
          SHIP DATE
        </Table.HeaderCell>
        <Table.HeaderCell
          width={1}
          sorted={sortColumn === 'stationCode,tableCode' ? convertForSemantic[sortDirection] : null}
          onClick={() => handleSort('stationCode,tableCode')}
        >
          LOCATION
        </Table.HeaderCell>
        <Table.HeaderCell width={1} />
      </Table.Row>
    </Table.Header>
  );
};

ReportingTableHeader.propTypes = {
  sortColumn: PropTypes.string,
  sortDirection: PropTypes.string,
  handleSort: PropTypes.func.isRequired
};

export default ReportingTableHeader;
