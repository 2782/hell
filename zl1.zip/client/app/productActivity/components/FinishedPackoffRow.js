import { Button, Table } from 'semantic-ui-react';
import PropTypes from 'prop-types';
import React from 'react';
import { formatType, reportingTableHelpers } from '../helpers';
import {
  CUSTOMER_PACKOFF,
  FINISHED_STOCK_WIP_PACKOFF
} from '../actions/productActivityDetailActions';

const isCustomerPackoff = productActivity => {
  const { customerCode, customerName } = productActivity;

  return customerCode && customerName;
};

export const DetailsButton = ({ productActivity, onClick }) => {
  const activityType = isCustomerPackoff(productActivity)
    ? CUSTOMER_PACKOFF
    : FINISHED_STOCK_WIP_PACKOFF;
  return (
    <Button primary size={'small'} onClick={() => onClick(activityType, productActivity)}>
      {'Details'}
    </Button>
  );
};

DetailsButton.propTypes = {
  productActivity: PropTypes.object.isRequired,
  onClick: PropTypes.func.isRequired
};

export const FinishedPackoffRow = ({ productActivity, onClick }) => {
  return (
    <Table.Row pid={`productActivity__row-${productActivity.key}`}>
      <Table.Cell pid={'productActivity__timestamp'}>
        {reportingTableHelpers.formatProduceDate(productActivity.timestamp)}
      </Table.Cell>
      <Table.Cell width={3} pid={'productActivity__type'}>
        {formatType(productActivity.type)}
      </Table.Cell>
      <Table.Cell pid={'productActivity__quantity'}>{productActivity.quantity} CS</Table.Cell>
      <Table.Cell width={3} pid={'productActivity__customerName'}>
        {isCustomerPackoff(productActivity)
          ? `${productActivity.customerName} ${productActivity.customerCode}`
          : reportingTableHelpers.formatCustomer(productActivity.incomplete)}
      </Table.Cell>
      <Table.Cell collapsing textAlign={'right'} pid={'productActivity__shipDate'}>
        {reportingTableHelpers.formatShipDate(productActivity.shipDate)}
      </Table.Cell>
      <Table.Cell width={1} pid={'productActivity__location'}>
        {productActivity.roomCode}
        <br />
        {productActivity.packoffStationName}
      </Table.Cell>
      <Table.Cell width={1}>
        <DetailsButton productActivity={productActivity} onClick={onClick} />
      </Table.Cell>
    </Table.Row>
  );
};

FinishedPackoffRow.propTypes = {
  productActivity: PropTypes.object.isRequired,
  onClick: PropTypes.func.isRequired
};
