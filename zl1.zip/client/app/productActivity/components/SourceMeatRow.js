import { Table } from 'semantic-ui-react';
import React from 'react';
import { formatType, reportingTableHelpers } from '../helpers';
import PropTypes from 'prop-types';
import { SOURCE_MEAT_WIP_REPORT_TYPE_NAME } from '../reportingTypes';

export const SourceMeatRow = ({ sourceMeat }) => (
  <Table.Row pid={`productActivity__row-${sourceMeat.key}`}>
    <Table.Cell pid={'productActivity__timestamp'}>
      {reportingTableHelpers.formatProduceDate(sourceMeat.timestamp)}
    </Table.Cell>
    <Table.Cell pid={'productActivity__type'}>{formatType(sourceMeat.type)}</Table.Cell>
    <Table.Cell pid={'productActivity__quantity'}>
      {sourceMeat.type == SOURCE_MEAT_WIP_REPORT_TYPE_NAME
        ? `${sourceMeat.weight} LB`
        : `${sourceMeat.quantity} ${reportingTableHelpers.formatUnitOfMeasure(sourceMeat.uom)}`}
    </Table.Cell>
    <Table.Cell width={3} pid={'productActivity__customerName'}>
      {sourceMeat.customerName ? `${sourceMeat.customerName}` : null}
    </Table.Cell>
    <Table.Cell pid={'productActivity__shipDate'} />
    <Table.Cell width={1} pid={'productActivity__location'}>
      <div>
        {sourceMeat.roomCode}
        <br />
        {sourceMeat.stationName}
      </div>
    </Table.Cell>
    <Table.Cell width={1} />
  </Table.Row>
);

SourceMeatRow.propTypes = {
  sourceMeat: PropTypes.object.isRequired
};
