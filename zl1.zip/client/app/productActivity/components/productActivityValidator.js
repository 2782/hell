import moment from 'moment';
import _ from 'lodash';
import { SubmissionError } from 'redux-form';
import { DEFAULT_DISPLAY_DATE_FORMAT } from '../../shared/util/dateUtil';
import { validate, validateDate } from '../../shared/formValidations';

export const validateSubmission = values => {
  let errors = {};
  const { startDate, endDate } = values;

  if (startDate) {
    errors = validate(errors, startDate, 'startDate', [validateDate(DEFAULT_DISPLAY_DATE_FORMAT)]);
  }
  if (endDate) {
    errors = validate(errors, endDate, 'endDate', [validateDate(DEFAULT_DISPLAY_DATE_FORMAT)]);
  }
  // Only check production date dependencies once we know both dates are valid dates
  if (Object.getOwnPropertyNames(errors).length === 0) {
    errors = { ...errors, ...validateProductionDates(values) };
  }
  errors = { ...errors, ...validateProductCode(values) };

  if (!_.isEmpty(errors)) {
    throw new SubmissionError({ ...errors, _error: 'Invalid search criteria' });
  }
};

export const validateProductCode = values => {
  const { productCode } = values;

  let errors = {};

  if (_.isEmpty(productCode)) {
    errors = { ...errors, productCode: 'Please enter a product code' };
  }

  return errors;
};

export const validateProductionDates = values => {
  const { startDate, endDate } = values;

  let errors = {};

  if (
    !!startDate &&
    moment(startDate, DEFAULT_DISPLAY_DATE_FORMAT).isAfter(
      moment(endDate, DEFAULT_DISPLAY_DATE_FORMAT),
      'day'
    )
  ) {
    errors = { ...errors, endDate: 'Must be after start date' };
  }
  return errors;
};
