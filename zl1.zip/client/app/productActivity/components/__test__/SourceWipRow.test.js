import React from 'react';
import { Button, Table } from 'semantic-ui-react';
import { shallow } from 'enzyme/build';
import { ProductActivitiesFactory } from '../../../../test-factories/productActivity';
import { DetailsButton, SourceWipRow } from '../SourceWipRow';

describe('SourceWipRow', () => {
  const sourceWipBox = ProductActivitiesFactory.build({
    customerCode: null,
    customerName: 'WIP',
    customerOrderNumber: null,
    incomplete: true,
    key: 'returnbox-30',
    packoffStationName: 'MARTHA',
    productCode: '1663364',
    quantity: 2,
    roomCode: 'A',
    shipDate: null,
    stationCode: null,
    stationName: null,
    status: 'AVAILABLE',
    tableCode: null,
    tableName: null,
    timestamp: '2018-10-02T09:41:46.863-05:00',
    type: 'ReturnBox',
    uom: 'CASE',
    weight: 11,
    workingDate: '2018-10-02'
  });

  test('should render row properly', () => {
    const wrapper = shallow(<SourceWipRow productActivity={sourceWipBox} onClick={() => {}} />);

    function getTableCellAt(index) {
      return wrapper
        .find(Table.Cell)
        .at(index)
        .dive()
        .text();
    }

    jestExpect(getTableCellAt(0)).toEqual('10-02-18 9:41 AM');
    jestExpect(getTableCellAt(1)).toEqual('Packoff');
    jestExpect(getTableCellAt(2)).toEqual('11 LB');
    jestExpect(getTableCellAt(3)).toEqual('WIP');
    jestExpect(getTableCellAt(5)).toEqual(
      jestExpect.stringContaining(sourceWipBox.roomCode + sourceWipBox.packoffStationName)
    );
  });

  describe('DetailsButton', () => {
    test('should invoke source WIP onClick behavior when button is pressed', () => {
      const onClick = jest.fn();

      const wrapper = shallow(<DetailsButton productActivity={sourceWipBox} onClick={onClick} />);

      wrapper.find(Button).simulate('click');

      jestExpect(onClick).toHaveBeenCalled();
    });
  });
});
