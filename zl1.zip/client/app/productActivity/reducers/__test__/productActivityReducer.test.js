import {
  PRODUCT_ACTIVITY_CLEARED,
  ACTIVITIES_SORTED_BY_COLUMN,
  PRODUCT_ACTIVITY_SEARCH_CRITERIA_SAVED
} from '../../actions/productActivityActionTypes';
import productActivityReducer from '../productActivityReducer';
import { ProductActivitiesFactory, PageFactory } from '../../../../test-factories/productActivity';
import { fetchProductActivities } from '../../actions/productActivityActions';

describe('ProductActivityReducer', () => {
  let initState;

  beforeEach(() => {
    initState = {
      productActivitiesPage: {},
      productActivities: [],
      productActivitySearchCriteria: {},
      productActivitiesSortColumn: 'timestamp',
      productActivitiesSortDirection: 'desc'
    };
  });

  describe('PRODUCT_ACTIVITY_CLEARED', () => {
    test('should clear current data in productActivity reducer', () => {
      const currentState = { ...initState, productActivities: [{ data: 'a lot of JSON' }] };

      jestExpect(
        productActivityReducer(currentState, {
          type: PRODUCT_ACTIVITY_CLEARED
        })
      ).toEqual(initState);
    });
  });

  describe('PRODUCT_ACTIVITY_SEARCH_CRITERIA_SAVED', () => {
    test('should soft save the product activity search criteria', () => {
      const currentState = { ...initState };
      const values = { key1: 'val1', key2: 'val2' };

      jestExpect(
        productActivityReducer(currentState, {
          type: PRODUCT_ACTIVITY_SEARCH_CRITERIA_SAVED,
          payload: values
        })
      ).toEqual({
        ...initState,
        productActivitySearchCriteria: values
      });
    });
  });

  describe('ACTIVITIES_SORTED_BY_COLUMN', () => {
    test('should change sort column and sort direction', () => {
      const expectedState = {
        ...initState,
        productActivitiesSortColumn: 'type',
        productActivitiesSortDirection: 'asc'
      };

      jestExpect(
        productActivityReducer(initState, {
          type: ACTIVITIES_SORTED_BY_COLUMN,
          payload: {
            productActivitiesSortColumn: 'type',
            productActivitiesSortDirection: 'asc'
          }
        })
      ).toEqual(expectedState);
    });
  });

  describe('PRODUCT_ACTIVITIES_FETCHED', () => {
    test('should unwrap page object data', () => {
      const returnBox = ProductActivitiesFactory.build();
      const page = PageFactory.build();

      const response = {
        data: {
          content: [returnBox],
          ...page
        }
      };
      const action = fetchProductActivities(response);

      jestExpect(productActivityReducer(initState, action)).toEqual({
        ...initState,
        productActivities: [returnBox],
        productActivitiesPage: page
      });
    });

    test('should not set page when content is empty', () => {
      const page = PageFactory.build();

      const response = {
        data: {
          content: [],
          ...page
        }
      };
      const action = fetchProductActivities(response);

      jestExpect(productActivityReducer(initState, action)).toEqual({
        ...initState,
        productActivities: [],
        productActivitiesPage: {}
      });
    });
  });
});
