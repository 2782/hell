import {
  PRODUCT_ACTIVITY_DETAILS_FETCHED,
  PRODUCT_ACTIVITY_DETAIL_CRITERIA_SAVED,
  DETAILS_SORTED_BY_COLUMN,
  PRODUCT_ACTIVITY_CLEARED
} from '../actions/productActivityActionTypes';
import _ from 'lodash';

const initState = {
  productActivityDetailsSortColumn: 'createdAt',
  productActivityDetailsSortDirection: 'desc',
  productActivityDetailsPage: {},
  productActivityDetails: [],
  productActivityDetailCriteria: {}
};

const productActivityDetailReducer = (state = initState, action) => {
  switch (action.type) {
    case PRODUCT_ACTIVITY_DETAILS_FETCHED: {
      return {
        ...state,
        productActivityDetails: action.payload.content,
        productActivityDetailsPage: _.isEmpty(action.payload.content)
          ? {}
          : _.omit(action.payload, ['content'])
      };
    }
    case PRODUCT_ACTIVITY_DETAIL_CRITERIA_SAVED: {
      return {
        ...state,
        productActivityDetailCriteria: action.payload
      };
    }
    case PRODUCT_ACTIVITY_CLEARED:
      return initState;
    case DETAILS_SORTED_BY_COLUMN:
      return {
        ...state,
        productActivityDetailsSortColumn: action.payload.productActivityDetailsSortColumn,
        productActivityDetailsSortDirection: action.payload.productActivityDetailsSortDirection
      };
    default:
      return state;
  }
};

export default productActivityDetailReducer;
