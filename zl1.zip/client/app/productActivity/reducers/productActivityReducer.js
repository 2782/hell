import {
  PRODUCT_ACTIVITIES_FETCHED,
  PRODUCT_ACTIVITY_SEARCH_CRITERIA_SAVED,
  PRODUCT_ACTIVITY_CLEARED,
  ACTIVITIES_SORTED_BY_COLUMN
} from '../actions/productActivityActionTypes';
import _ from 'lodash';

const initState = {
  productActivitiesSortColumn: 'timestamp',
  productActivitiesSortDirection: 'desc',
  productActivitiesPage: {},
  productActivities: [],
  productActivitySearchCriteria: {}
};

const productActivityReducer = (state = initState, action) => {
  switch (action.type) {
    case PRODUCT_ACTIVITIES_FETCHED: {
      return {
        ...state,
        productActivities: action.payload.content,
        productActivitiesPage: _.isEmpty(action.payload.content)
          ? {}
          : _.omit(action.payload, ['content'])
      };
    }
    case PRODUCT_ACTIVITY_SEARCH_CRITERIA_SAVED:
      return {
        ...state,
        productActivitySearchCriteria: action.payload
      };
    case PRODUCT_ACTIVITY_CLEARED:
      return initState;
    case ACTIVITIES_SORTED_BY_COLUMN:
      return {
        ...state,
        productActivitiesSortColumn: action.payload.productActivitiesSortColumn,
        productActivitiesSortDirection: action.payload.productActivitiesSortDirection
      };
    default:
      return state;
  }
};

export default productActivityReducer;
