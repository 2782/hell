import React from 'react';
import { Provider } from 'react-redux';
import { Field, reduxForm } from 'redux-form';
import { Button, Pagination } from 'semantic-ui-react';
import { mount, shallow } from 'enzyme';
import { createReduxStore } from '../../../store';
import ProductActivity, { ProductActivityComponent } from '../ProductActivity';
import { PRODUCT_ACTIVITY } from '../../../shared/components/pageTitles';
import { F4_F2 } from '../../../shared/components/pageFooters';
import ReportingTable from '../ReportingTable';
import FormLabel from '../../../shared/FormLabel';
import { NOT_A_PRODUCT_CODE } from '../../../../config/errorMessage';
import { CUSTOMER_PACKOFF } from '../../actions/productActivityDetailActions';
import { setHeaderAndFooter } from '../../../shared/actions/actions';
import { fetchProductActivities } from '../../actions/productActivityActions';
import { PageFactory } from '../../../../test-factories/productActivity';

jest.mock('../../components/productActivityValidator', () => ({
  validateSubmission: jest.fn(() => ({})),
  validateProductionDates: jest.fn(() => ({}))
}));

jest.mock('../../../shared/actions/actions', () => ({
  setHeaderAndFooter: jest.fn(() => ({ type: 'MOCK_SET_HEADER_AND_FOOTER' }))
}));

describe('ProductActivity', () => {
  let store, wrapper, DecoratedComponent;

  beforeEach(() => {
    store = createReduxStore({});
    DecoratedComponent = reduxForm({ form: 'testForm' })(ProductActivityComponent);
  });

  test('should call setHeaderAndFooter action upon mounting', () => {
    wrapper = mount(
      <Provider store={store}>
        <ProductActivity />
      </Provider>
    );

    jestExpect(setHeaderAndFooter).toHaveBeenCalledWith({
      header: PRODUCT_ACTIVITY,
      footer: F4_F2
    });
  });

  test('should show filter fields and search button', () => {
    wrapper = mount(
      <Provider store={store}>
        <ProductActivity />
      </Provider>
    );

    const productCodeInputField = wrapper.find(Field).at(0);
    const portionSizeField = wrapper.find(FormLabel).at(1);
    const productionStartDateInputField = wrapper.find(Field).at(1);
    const productionEndDateInputField = wrapper.find(Field).at(2);
    const searchButton = wrapper.find(Button);

    jestExpect(productCodeInputField.props().name).toEqual('productCode');
    jestExpect(portionSizeField.props().label).toEqual('PORTION SIZE');
    jestExpect(productionStartDateInputField.props().name).toEqual('startDate');
    jestExpect(productionEndDateInputField.props().name).toEqual('endDate');
    jestExpect(searchButton.text()).toContain('Search');
  });

  test('should send productActivitiesData to reportingTableComponent', () => {
    const pageable = { ...PageFactory.build(), content: [{ foo: 'bar' }] };

    store.dispatch(
      fetchProductActivities({
        data: pageable
      })
    );

    wrapper = mount(
      <Provider store={store}>
        <ProductActivity />
      </Provider>
    );
    const reportingTableComponent = wrapper.find(ReportingTable);

    jestExpect(reportingTableComponent.props().reportingData).toEqual([{ foo: 'bar' }]);
  });

  test('should call clearProductActivities on unmount', () => {
    const clearProductActivitiesMock = jest.fn();
    const setProductExistsToMock = jest.fn();

    wrapper = mount(
      <Provider store={store}>
        <DecoratedComponent
          clearProductActivities={clearProductActivitiesMock}
          finishedProductCode={'0011011'}
          getReportingData={() => {}}
          handleDetailsButtonClick={() => {}}
          handleActivitiesSort={() => {}}
          pathname={'/other/path'}
          productActivities={[]}
          productExists={false}
          productsDuplicate={{}}
          setHeaderAndFooter={() => {}}
          setProductExistTo={setProductExistsToMock}
        />
      </Provider>
    );

    wrapper.unmount();

    jestExpect(setProductExistsToMock).toBeCalledWith('0011011', true);
    jestExpect(clearProductActivitiesMock).toHaveBeenCalled();
  });

  test('should call getProduct Action on blur', () => {
    const getProductMock = jest.fn();
    const wrapper = mount(
      <Provider store={store}>
        <DecoratedComponent
          finishedProductCode={''}
          getProduct={getProductMock}
          getReportingData={() => {}}
          handleDetailsButtonClick={() => {}}
          handleActivitiesSort={() => {}}
          productActivities={[]}
          productsDuplicate={{}}
          setHeaderAndFooter={() => {}}
          setProductExistTo={() => {}}
        />
      </Provider>
    );

    let value = '0078889';
    const inputField = wrapper.find(Field).find('input[name="productCode"]');

    inputField.simulate('blur', { target: { value } });

    jestExpect(getProductMock).toHaveBeenCalledTimes(1);
  });

  test('should call setProductExistsTo Action on error callback', () => {
    const getProductStub = jest.fn();
    const setProductExistsToMock = jest.fn();
    const wrapper = mount(
      <Provider store={store}>
        <DecoratedComponent
          finishedProductCode={''}
          getProduct={getProductStub}
          getReportingData={() => {}}
          handleDetailsButtonClick={() => {}}
          handleActivitiesSort={() => {}}
          productActivities={[]}
          productsDuplicate={{}}
          setHeaderAndFooter={() => {}}
          setProductExistTo={setProductExistsToMock}
        />
      </Provider>
    );

    getProductStub.mockImplementation((arg, callback) => callback());
    let value = '0078889';
    const inputField = wrapper.find(Field).find('input[name="productCode"]');

    inputField.simulate('blur', { target: { value } });

    jestExpect(setProductExistsToMock).toHaveBeenCalledWith('0078889', false);
  });

  test('should call setProductExistsTo Action onChange', () => {
    const setProductExistsToMock = jest.fn();
    const clearProductActivitiesMock = jest.fn();
    const wrapper = mount(
      <Provider store={store}>
        <DecoratedComponent
          clearProductActivities={clearProductActivitiesMock}
          finishedProductCode={''}
          getReportingData={() => {}}
          handleDetailsButtonClick={() => {}}
          handleActivitiesSort={() => {}}
          productActivities={[]}
          productsDuplicate={{}}
          setHeaderAndFooter={() => {}}
          setProductExistTo={setProductExistsToMock}
        />
      </Provider>
    );

    let value = '0078889';
    const inputField = wrapper.find(Field).find('input[name="productCode"]');

    inputField.simulate('change', { target: { value } });

    jestExpect(setProductExistsToMock).toHaveBeenCalledWith('0078889', true);
    jestExpect(clearProductActivitiesMock).toHaveBeenCalledTimes(1);
  });

  test('should not call setProductExistsTo Action onChange when value is empty', () => {
    const setProductExistToMock = jest.fn();
    const wrapper = mount(
      <Provider store={store}>
        <DecoratedComponent
          finishedProductCode={''}
          getReportingData={() => {}}
          handleDetailsButtonClick={() => {}}
          handleActivitiesSort={() => {}}
          productActivities={[]}
          productsDuplicate={{}}
          setHeaderAndFooter={() => {}}
          setProductExistTo={setProductExistToMock}
        />
      </Provider>
    );

    let value = '';
    const inputField = wrapper.find(Field).find('input[name="productCode"]');

    inputField.simulate('change', { target: { value } });

    jestExpect(setProductExistToMock).not.toHaveBeenCalledWith(true);
  });

  test('should not call getProduct if finishedProductCode field is empty', () => {
    const getProductSpy = jest.fn();
    const wrapper = mount(
      <Provider store={store}>
        <DecoratedComponent
          finishedProductCode={''}
          getProduct={getProductSpy}
          getReportingData={() => {}}
          handleDetailsButtonClick={() => {}}
          handleActivitiesSort={() => {}}
          productActivities={[]}
          productsDuplicate={{}}
          setHeaderAndFooter={() => {}}
          setProductExistTo={() => {}}
        />
      </Provider>
    );

    let value = '';
    const inputField = wrapper.find(Field).find('input[name="productCode"]');

    inputField.simulate('blur', { target: { value } });

    jestExpect(getProductSpy).not.toHaveBeenCalled();
  });

  test('should render Pagination component when page object exists', () => {
    const changePage = jest.fn(() => Promise.resolve());

    const wrapper = shallow(
      <ProductActivityComponent
        productActivitiesChangePage={changePage}
        handleDetailsButtonClick={() => {}}
        handleActivitiesSort={() => {}}
        handleSubmit={() => {}}
        page={{ pageable: { pageNumber: 2 }, totalPages: 11 }}
        productsDuplicate={{}}
        setHeaderAndFooter={() => {}}
      />
    );

    jestExpect(
      wrapper
        .find(Pagination)
        .at(0)
        .exists()
    ).toEqual(true);
    jestExpect(
      wrapper
        .find(Pagination)
        .at(0)
        .props().activePage
    ).toEqual(3);
    jestExpect(
      wrapper
        .find(Pagination)
        .at(0)
        .props().totalPages
    ).toEqual(11);

    const onPageChange = wrapper
      .find(Pagination)
      .at(0)
      .props().onPageChange;

    onPageChange('EVENT', { activePage: 7 });

    jestExpect(changePage).toHaveBeenCalledWith(6);
  });

  test('should not render Pagination component when page object is empty', () => {
    const wrapper = shallow(
      <ProductActivityComponent
        handleDetailsButtonClick={() => {}}
        handleActivitiesSort={() => {}}
        handleSubmit={() => {}}
        page={{}}
        productsDuplicate={{}}
        setHeaderAndFooter={() => {}}
      />
    );
    jestExpect(wrapper.find(Pagination).exists()).toEqual(false);
  });

  test('should call getProductActivities action on button click', () => {
    const getProductActivities = jest.fn();
    store = createReduxStore({
      form: {
        productActivity: {
          values: {
            productCode: '1961172'
          }
        }
      }
    });
    const wrapper = mount(
      <Provider store={store}>
        <DecoratedComponent
          clearProductActivities={() => {}}
          finishedProductCode={'1961172'}
          getProductActivities={getProductActivities}
          handleDetailsButtonClick={() => {}}
          handleActivitiesSort={() => {}}
          productsDuplicate={{}}
          setHeaderAndFooter={() => {}}
          setProductExistTo={() => {}}
        />
      </Provider>
    );

    wrapper.find('form').simulate('submit');

    jestExpect(getProductActivities).toHaveBeenCalledTimes(1);
  });

  describe('handling on click for product activity details', () => {
    test('should not save details criteria or navigate to details on failure of fetching details', () => {
      const replacePath = jest.fn();
      const saveProductActivityDetailCriteria = jest.fn();
      const getProductActivityDetails = jest.fn(() => Promise.reject());

      const wrapper = shallow(
        <ProductActivityComponent
          getProductActivityDetails={getProductActivityDetails}
          saveProductActivityDetailCriteria={saveProductActivityDetailCriteria}
          replacePath={replacePath}
          productActivities={[]}
          handleSubmit={() => {}}
          productsDuplicate={{}}
          setHeaderAndFooter={() => {}}
          handleActivitiesSort={() => {}}
        />
      );

      const productActivity = {
        productCode: '1961172'
      };

      const instance = wrapper.instance();

      return instance
        .handleDetailsButtonClick(CUSTOMER_PACKOFF, productActivity)
        .then(() => {
          jest.fail('Should not resolve.');
        })
        .catch(() => {
          jestExpect(replacePath).not.toHaveBeenCalled();
          jestExpect(saveProductActivityDetailCriteria).not.toHaveBeenCalled();
        });
    });

    test('should save details criteria and navigate to details on success of fetching details', () => {
      const replacePath = jest.fn();
      const saveProductActivityDetailCriteria = jest.fn();
      const getProductActivityDetails = jest.fn(() => Promise.resolve());

      const wrapper = shallow(
        <ProductActivityComponent
          getProductActivityDetails={getProductActivityDetails}
          saveProductActivityDetailCriteria={saveProductActivityDetailCriteria}
          replacePath={replacePath}
          productActivities={[]}
          handleSubmit={() => {}}
          productsDuplicate={{}}
          setHeaderAndFooter={() => {}}
          handleActivitiesSort={() => {}}
        />
      );

      const productActivity = {
        productCode: '1961172'
      };

      const instance = wrapper.instance();

      return instance.handleDetailsButtonClick(CUSTOMER_PACKOFF, productActivity).then(() => {
        jestExpect(replacePath).toHaveBeenCalledWith('/product/product-activity/details');
        jestExpect(saveProductActivityDetailCriteria).toHaveBeenCalledWith(
          CUSTOMER_PACKOFF,
          productActivity
        );
      });
    });
  });

  describe('rendering message for Product Component', () => {
    test('should pass NOT_A_PRODUCT_CODE when product does not exist', () => {
      const productsExist = {
        '1234567': false
      };

      const wrapper = shallow(
        <ProductActivityComponent
          handleDetailsButtonClick={() => {}}
          finishedProductCode={'1234567'}
          handleActivitiesSort={() => {}}
          handleSubmit={() => {}}
          productActivities={[]}
          productsDuplicate={{}}
          productsExistList={productsExist}
          setHeaderAndFooter={() => {}}
        />
      );

      const productField = wrapper.find(Field).at(0);

      jestExpect(productField.props().message).toEqual(NOT_A_PRODUCT_CODE);

      const searchButton = wrapper.find(Button);
      jestExpect(searchButton).toBeDisabled();
    });

    test('should pass null when product does exist', () => {
      const productsExist = {
        '1234567': true
      };

      const wrapper = shallow(
        <ProductActivityComponent
          handleDetailsButtonClick={() => {}}
          handleActivitiesSort={() => {}}
          handleSubmit={() => {}}
          productActivities={[]}
          productsDuplicate={{}}
          productsExistList={productsExist}
          setHeaderAndFooter={() => {}}
        />
      );

      const productField = wrapper.find(Field).at(0);

      jestExpect(productField.props().message).toEqual(null);

      const searchButton = wrapper.find(Button);
      jestExpect(searchButton).not.toBeDisabled();
    });
  });
});
