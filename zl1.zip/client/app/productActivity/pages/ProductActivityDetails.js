import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { Grid, Pagination, Table } from 'semantic-ui-react';
import _ from 'lodash';
import { setHeaderAndFooter } from '../../shared/actions/actions';
import { PRODUCT_ACTIVITY } from '../../shared/components/pageTitles';
import { F4 } from '../../shared/components/pageFooters';
import subscriber from '../../shared/functionKeys/subscriber';
import { clearProductActivities, getProductActivities } from '../actions/productActivityActions';
import { reportingTableHelpers } from '../helpers';
import ProductActivityDetailsHeader from '../components/ProductActivityDetailsHeader';
import {
  handleDetailsSort,
  productActivityDetailsChangePage
} from '../actions/productActivityDetailActions';

const convertForSemantic = {
  asc: 'ascending',
  desc: 'descending'
};

export class ProductActivityDetailsComponent extends React.Component {
  constructor(props) {
    super(props);
    this.scrollToTop = this.scrollToTop.bind(this);
  }

  scrollToTop() {
    if (this.scrollToTopRef && this.scrollToTopRef.scrollIntoView) {
      this.scrollToTopRef.scrollIntoView({
        behavior: 'smooth',
        block: 'start',
        inline: 'nearest'
      });
    }
  }

  componentDidMount() {
    const { setHeaderAndFooter } = this.props;

    setHeaderAndFooter({
      header: PRODUCT_ACTIVITY,
      footer: F4
    });

    this.scrollToTop();
  }

  componentWillUnmount() {
    const { clearProductActivities } = this.props;
    clearProductActivities();
  }

  render() {
    const {
      productActivityDetailCriteria,
      productActivityDetailsChangePage,
      productActivityDetailsPage,
      productActivityDetails,
      handleDetailsSort,
      sortColumn,
      sortDirection
    } = this.props;
    if (productActivityDetails === null || _.isEmpty(productActivityDetails)) {
      return null;
    }

    return (
      <div className={'product-activity-details-page'} ref={node => (this.scrollToTopRef = node)}>
        <Grid>
          <Grid.Row>
            <Grid.Column width={4}>
              <b>PACKOFF</b>
            </Grid.Column>
            <Grid.Column width={2}>{productActivityDetailCriteria.productCode}</Grid.Column>
          </Grid.Row>
          <ProductActivityDetailsHeader detail={productActivityDetailCriteria} />
        </Grid>
        <Grid>
          <Grid.Row verticalAlign='bottom'>
            <Grid.Column width={8} />
            <Grid.Column textAlign='right' width={16}>
              {_.isEmpty(productActivityDetailsPage) ? null : (
                <Pagination
                  activePage={productActivityDetailsPage.pageable.pageNumber + 1}
                  onPageChange={(event, data) =>
                    productActivityDetailsChangePage(data.activePage - 1).then(this.scrollToTop())
                  }
                  totalPages={productActivityDetailsPage.totalPages}
                />
              )}
            </Grid.Column>
          </Grid.Row>
        </Grid>

        <Table sortable>
          <Table.Header>
            <Table.Row>
              <Table.HeaderCell />
              <Table.HeaderCell
                sorted={sortColumn === 'createdAt' ? convertForSemantic[sortDirection] : null}
                onClick={() => handleDetailsSort('createdAt')}
              >
                DATE
              </Table.HeaderCell>
              <Table.HeaderCell
                sorted={sortColumn === 'netWeight' ? convertForSemantic[sortDirection] : null}
                onClick={() => handleDetailsSort('netWeight')}
              >
                WEIGHT (LBS)
              </Table.HeaderCell>
            </Table.Row>
          </Table.Header>
          <Table.Body>
            {productActivityDetails.map(detail => {
              return (
                <Table.Row key={detail.id}>
                  <Table.Cell>{detail.packSequence}</Table.Cell>
                  <Table.Cell>
                    {reportingTableHelpers.formatProduceDate(detail.createdAt)}
                  </Table.Cell>
                  <Table.Cell>{detail.netWeight}</Table.Cell>
                </Table.Row>
              );
            })}
          </Table.Body>
        </Table>
        {_.isEmpty(productActivityDetailsPage) ? null : (
          <Grid>
            <Grid.Row>
              <Grid.Column textAlign='right' width={16}>
                <Pagination
                  activePage={productActivityDetailsPage.pageable.pageNumber + 1}
                  onPageChange={(event, data) =>
                    productActivityDetailsChangePage(data.activePage - 1).then(this.scrollToTop())
                  }
                  totalPages={productActivityDetailsPage.totalPages}
                />
              </Grid.Column>
            </Grid.Row>
          </Grid>
        )}
      </div>
    );
  }
}

ProductActivityDetailsComponent.propTypes = {
  clearProductActivities: PropTypes.func.isRequired,
  getProductActivities: PropTypes.func.isRequired,
  setHeaderAndFooter: PropTypes.func.isRequired,
  handleDetailsSort: PropTypes.func.isRequired,
  productActivityDetailsChangePage: PropTypes.func,
  productActivityDetails: PropTypes.array,
  productActivityDetailCriteria: PropTypes.object,
  productActivityDetailsPage: PropTypes.object,
  productActivitySearchCriteria: PropTypes.object,
  productActivitiesPage: PropTypes.object,
  sortColumn: PropTypes.string,
  sortDirection: PropTypes.string
};

const mapDispatchToProps = dispatch =>
  bindActionCreators(
    {
      setHeaderAndFooter,
      handleDetailsSort,
      getProductActivities,
      productActivityDetailsChangePage,
      clearProductActivities
    },
    dispatch
  );

const mapStateToProps = state => {
  const { productActivitySearchCriteria, productActivitiesPage } = state.productActivity;
  const {
    productActivityDetails,
    productActivityDetailCriteria,
    productActivityDetailsPage,
    productActivityDetailsSortColumn,
    productActivityDetailsSortDirection
  } = state.productActivityDetail;
  return {
    productActivityDetails,
    productActivityDetailCriteria,
    productActivityDetailsPage,
    productActivitySearchCriteria,
    productActivitiesPage,
    sortColumn: productActivityDetailsSortColumn,
    sortDirection: productActivityDetailsSortDirection
  };
};

export const f4Behavior = props => {
  props.getProductActivities({
    ...props.productActivitySearchCriteria,
    page: props.productActivitiesPage.pageable.pageNumber
  });
  props.replacePath('/product/product-activity');
};

const ProductActivityDetails = connect(
  mapStateToProps,
  mapDispatchToProps
)(
  subscriber(ProductActivityDetailsComponent, {
    f4Behavior,
    targetComponent: 'ProductActivityDetails',
    uris: {
      F4: ['#/product/product-activity/details']
    }
  })
);

export default ProductActivityDetails;
