import { reportingTableHelpers } from '../helpers';
import {
  BOX_REPORT_TYPE_NAME,
  CUT_ORDER_SELECTION_REPORT_TYPE_NAME,
  RETURN_BOX_REPORT_TYPE_NAME,
  SOURCE_MEAT_ORDER_REPORT_TYPE_NAME,
  SOURCE_MEAT_RECEIPT_REPORT_TYPE_NAME
} from '../reportingTypes';

describe('reportingTableHelpers', () => {
  describe('formatCustomer', () => {
    test('should return "Stock" when it is not a wip box', () => {
      const result = reportingTableHelpers.formatCustomer(false);

      jestExpect(result).toEqual('Stock');
    });
    test('should return "WIP" when it is a wip box', () => {
      const result = reportingTableHelpers.formatCustomer(true);

      jestExpect(result).toEqual('WIP');
    });
  });

  describe('formatProduceDate', () => {
    test('should return a timestamp in a "mm-dd HH:MM" format', () => {
      const result = reportingTableHelpers.formatProduceDate('2018-09-28T08:00:26.13-05:00');

      jestExpect(result).toEqual('09-28-18 8:00 AM');
    });

    test('should return a nothing when there is no produce date', () => {
      const result = reportingTableHelpers.formatProduceDate('');

      jestExpect(result).toEqual('');
    });
  });

  describe('formatShipDate', () => {
    test('should return a timestamp in a "mm-dd" format', () => {
      const result = reportingTableHelpers.formatShipDate('2018-09-28T08:00:26.13-05:00');

      jestExpect(result).toEqual('09-28');
    });

    test('should return a nothing when there is no produce date', () => {
      const result = reportingTableHelpers.formatShipDate('');

      jestExpect(result).toEqual('');
    });
  });

  describe('formatType', () => {
    test('should return "Packoff" when "Box" type', () => {
      const result = reportingTableHelpers.formatType(BOX_REPORT_TYPE_NAME);

      jestExpect(result).toEqual('Packoff');
    });

    test('should return "Cut Selection" when "CutOrder" type', () => {
      const result = reportingTableHelpers.formatType(CUT_ORDER_SELECTION_REPORT_TYPE_NAME);

      jestExpect(result).toEqual('Cut Selection');
    });

    test('should return "Request Meat" when "SourceMeatOrder" type', () => {
      const result = reportingTableHelpers.formatType(SOURCE_MEAT_ORDER_REPORT_TYPE_NAME);

      jestExpect(result).toEqual('Request Meat');
    });

    test('should return "Packoff" when "ReturnBox" type', () => {
      const result = reportingTableHelpers.formatType(RETURN_BOX_REPORT_TYPE_NAME);

      jestExpect(result).toEqual('Packoff');
    });

    test('should return "Receive Meat" when "SourceMeatReceipt" type', () => {
      const result = reportingTableHelpers.formatType(SOURCE_MEAT_RECEIPT_REPORT_TYPE_NAME);

      jestExpect(result).toEqual('Receive Meat');
    });
    test('should return empty when unknown type', () => {
      const result = reportingTableHelpers.formatType('FakeBox');

      jestExpect(result).toEqual('');
    });
  });

  describe('formatUnitOfMeasure', () => {
    test('should abbreviate cases as "CS"', () => {
      const result = reportingTableHelpers.formatUnitOfMeasure('cAsE');

      jestExpect(result).toEqual('CS');
    });

    test('should abbreviate pounds as "LB"', () => {
      const result = reportingTableHelpers.formatUnitOfMeasure('lBs');

      jestExpect(result).toEqual('LB');
    });

    test('should abbreviate pieces as "PC"', () => {
      const result = reportingTableHelpers.formatUnitOfMeasure('pIeCe');

      jestExpect(result).toEqual('PC');
    });

    test('should not change unit of measure other than CASE', () => {
      const result = reportingTableHelpers.formatUnitOfMeasure('bobs');

      jestExpect(result).toEqual('bobs');
    });
  });
});
