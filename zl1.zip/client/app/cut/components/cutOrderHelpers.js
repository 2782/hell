import _ from 'lodash';

export const productCodeConsolidator = cutOrdersInfo => {
  return _(cutOrdersInfo)
    .groupBy('data.product.code')
    .mapValues(orders => {
      return {
        orderIds: _.map(orders, order => order.orderId),
        selected: orders[0].selected,
        product: orders[0].data.product,
        totalQuantity: _.sumBy(orders, order => order.data.qtyInBoxes)
      };
    })
    .value();
};

export const handleKeyDown = (handleSelect, handleConfirm, orderIdOrIds, event, productCode) => {
  event.persist(); // persist the event so it can be accessed by async code https://reactjs.org/docs/events.html#event-pooling
  const {
    key,
    target: { nextElementSibling, previousElementSibling }
  } = event;

  switch (key) {
    case ' ':
      event.preventDefault();
      handleSelect(orderIdOrIds, event, productCode);
      break;
    case 'Enter':
      event.preventDefault();
      event.stopPropagation();
      handleConfirm(orderIdOrIds);
      break;
    case 'ArrowDown':
      nextElementSibling && nextElementSibling.focus();
      break;
    case 'ArrowUp':
      previousElementSibling && previousElementSibling.focus();
      break;
  }
};
