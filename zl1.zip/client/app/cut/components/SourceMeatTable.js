import React from 'react';
import * as _ from 'lodash';
import { Form, Table } from 'semantic-ui-react';
import PropTypes from 'prop-types';
import EmptyListMessage from '../../shared/components/EmptyListMessage';
import FormElement from '../../shared/FormElement';
import { Field } from 'redux-form';
import {
  maxLength3,
  nonNegativeNumber,
  required
} from '../../shared/validation/formFieldValidations';
import { reportingTableHelpers } from '../../productActivity/helpers';

const renderTable = sourceMeatOrders => {
  return (
    <Table fixed selectable>
      <Table.Header>
        <Table.Row>
          <Table.HeaderCell width={5}>PRODUCT</Table.HeaderCell>
          <Table.HeaderCell width={5}>SOURCE PRODUCT</Table.HeaderCell>
          <Table.HeaderCell width={4}>ORDER QUANTITY</Table.HeaderCell>
          <Table.HeaderCell width={2}>U/M</Table.HeaderCell>
        </Table.Row>
      </Table.Header>
      {renderBody(sourceMeatOrders)}
    </Table>
  );
};

const renderBody = sourceMeatOrders => {
  return (
    <Table.Body key={'source-meat-order-table-table-content'}>
      {_.map(sourceMeatOrders, (sourceMeatOrder, itemIndex) => {
        const {
          targetProductCode,
          targetProductDesc,
          productCode,
          productDesc,
          ingredients,
          unitOfMeasure
        } = sourceMeatOrder;

        return (
          <Table.Row pid={`source-meat-order-table__table-row-${itemIndex}`} key={itemIndex}>
            <Table.Cell width={5} verticalAlign='top'>
              <div pid='source-meat-order-table__table-cell-inner-product-code'>
                {targetProductCode}
              </div>
              <div pid='source-meat-order-table__table-cell-inner-product-desc'>
                {targetProductDesc}
              </div>
            </Table.Cell>
            <Table.Cell
              pid='source-meat-order-table__table-cell-table'
              width={5}
              verticalAlign='top'
            >
              <div
                pid='source-meat-order-table__table-cell-inner-source-product-code'
                className={'source-product'}
              >
                {productCode}
              </div>
              <div pid='source-meat-order-table__table-cell-inner-source-product-desc'>
                {productDesc}
              </div>
              {ingredients && (
                <div
                  pid='source-meat-order-table__table-cell-inner-ingredients'
                  className={'ingredients'}
                >
                  <span>Ingredients: </span>
                  {ingredients}
                </div>
              )}
            </Table.Cell>
            <Table.Cell width={4}>
              <Field
                className={'quantity'}
                width={10}
                validate={[required, nonNegativeNumber, maxLength3]}
                component={FormElement}
                name={`${targetProductCode}-quantity`}
                as={Form.Input}
              />
            </Table.Cell>
            <Table.Cell width={2} verticalAlign='top'>
              <div>{reportingTableHelpers.formatUnitOfMeasure(unitOfMeasure)}</div>
            </Table.Cell>
          </Table.Row>
        );
      })}
    </Table.Body>
  );
};

const SourceMeatTable = ({ sourceMeatOrders }) => {
  return (
    <div>
      {_.isEmpty(sourceMeatOrders) ? (
        <EmptyListMessage key={'source-meat-order-table-empty-message'} />
      ) : (
        renderTable(sourceMeatOrders)
      )}
    </div>
  );
};

SourceMeatTable.propTypes = {
  sourceMeatOrders: PropTypes.array
};

export default SourceMeatTable;
