import React from 'react';

class SideNavigation extends React.Component {
  render() {
    return <div>Fake SideNavigation Component</div>;
  }
}

export default SideNavigation;
