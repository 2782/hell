import React from 'react';
import PropTypes from 'prop-types';
import CutOrderTableHeader from './CutOrderTableHeader';
import ConsolidatedCutOrderTableBody from './ConsolidatedCutOrderTableBody';
import { Table } from 'semantic-ui-react';

const ConsolidatedCutOrderTable = ({
  cutOrdersInfo,
  handleSelect,
  handleConfirm,
  tabbable = true,
  autoFocus = true
}) => {
  return (
    <Table size='large' className='cut-orders-table' basic='very' pid='cut-orders-table'>
      <CutOrderTableHeader />
      <ConsolidatedCutOrderTableBody
        cutOrdersInfo={cutOrdersInfo}
        handleSelect={handleSelect}
        handleConfirm={handleConfirm}
        tabbable={tabbable}
        autoFocus={autoFocus}
      />
    </Table>
  );
};

ConsolidatedCutOrderTable.propTypes = {
  cutOrdersInfo: PropTypes.array.isRequired,
  handleSelect: PropTypes.func.isRequired,
  handleConfirm: PropTypes.func.isRequired,
  tabbable: PropTypes.bool,
  autoFocus: PropTypes.bool
};

export default ConsolidatedCutOrderTable;
