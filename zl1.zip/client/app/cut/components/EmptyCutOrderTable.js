import React from 'react';
import PropTypes from 'prop-types';
import { Ref, Table } from 'semantic-ui-react';
import CutOrderTableHeader from './CutOrderTableHeader';

export default class EmptyCutOrderTable extends React.Component {
  constructor(props) {
    super(props);

    this.contentRef = null;
  }

  componentDidMount() {
    const { autoFocus } = this.props;
    const shouldFocus = autoFocus !== undefined ? autoFocus : true;

    if (shouldFocus) {
      this.contentRef.focus();
    }
  }

  render() {
    return (
      <Ref innerRef={ref => (this.contentRef = ref)}>
        <div tabIndex={0} className={'empty-result-content'}>
          <Table key={0} tabIndex={0} size='large' className='cut-orders-table' basic='very'>
            <CutOrderTableHeader />
          </Table>
          <div className={'empty-table-message'}>This list is empty, press (F4) to go back.</div>
        </div>
      </Ref>
    );
  }
}
EmptyCutOrderTable.propTypes = {
  autoFocus: PropTypes.bool
};
