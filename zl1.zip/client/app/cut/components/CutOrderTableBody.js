import _ from 'lodash';
import React from 'react';
import PropTypes from 'prop-types';
import { Table, Ref, Grid } from 'semantic-ui-react';
import { prepareOrderItemQuantity } from '../../shared/util/dataUtil';
import DotDotDot from 'react-dotdotdot';
import { formatDate } from '../../shared/util/dateUtil';
import { handleKeyDown } from './cutOrderHelpers';

export const orderItemData = item => {
  const selected = item.selected;
  const cutOrder = item.data;
  const {
    product,
    id,
    producingInstruction,
    packInstruction,
    customerOrder,
    deliveryDate,
    cutType,
    deleted,
    productionType,
    updated
  } = cutOrder;
  const productCode = product.code;
  const productDescription = product.description;
  const portionSize = _.get(product, 'productPortionSize.portionSize', '');
  const customerName = _.get(customerOrder, 'customer.name', '');
  const customerNumber = _.get(customerOrder, 'customer.customerCode', '');
  const quantity = prepareOrderItemQuantity(cutOrder);
  const date = formatDate(deliveryDate);

  return {
    orderId: id,
    selected,
    productDescription,
    productCode,
    customerName,
    customerNumber,
    deliveryDate: date,
    producingInstruction,
    portionSize,
    cutType,
    packInstruction,
    quantity,
    isCancelled: deleted,
    productionType,
    isUpdated: updated
  };
};

export default function CutOrderTableBody({
  cutOrdersInfo,
  handleSelect,
  handleConfirm,
  tabbable = true,
  autoFocus = true
}) {
  return (
    <Table.Body>
      {cutOrdersInfo.map((item, index) => {
        const {
          selected,
          orderId,
          productDescription,
          productCode,
          customerName,
          customerNumber,
          producingInstruction,
          portionSize,
          cutType,
          packInstruction,
          deliveryDate,
          quantity,
          isCancelled,
          isUpdated
        } = orderItemData(item);

        let handleFocusFirstRow;
        if (autoFocus) {
          handleFocusFirstRow = node => index === 0 && node.focus();
        } else {
          handleFocusFirstRow = () => {};
        }

        return (
          <Ref key={`${orderId}`} innerRef={handleFocusFirstRow}>
            <Table.Row
              pid={`cut-orders-table__table-row-${index}`}
              tabIndex={tabbable ? 0 : null}
              active={tabbable && selected}
              onClick={event => handleSelect(orderId, event, productCode)}
              onKeyDown={event =>
                handleKeyDown(handleSelect, handleConfirm, orderId, event, productCode)
              }
              verticalAlign='top'
              className={isCancelled ? 'cancelled' : ''}
            >
              <Table.Cell width={6}>
                <Grid>
                  <Grid.Row>
                    <Grid.Column text-align='left'>
                      <span
                        className='cut-orders-table__uppercase'
                        pid={`cut-orders-table__product-code-${index}`}
                      >{`${productCode} / ${portionSize}`}</span>
                      <DotDotDot clamp={1} useNativeClamp={false}>
                        <span
                          className='cut-orders-table__uppercase'
                          pid={`cut-orders-table__product-description-${index}`}
                        >
                          {productDescription}
                        </span>
                      </DotDotDot>
                    </Grid.Column>
                  </Grid.Row>
                </Grid>
              </Table.Cell>
              <Table.Cell width={6}>
                <Grid>
                  <Grid.Row>
                    <Grid.Column text-align='left'>
                      <DotDotDot clamp={1} useNativeClamp={false}>
                        <span
                          className='cut-orders-table__uppercase'
                          pid={`cut-orders-table__customer-name-${index}`}
                        >
                          {customerName}
                        </span>
                      </DotDotDot>
                      <span
                        className='cut-orders-table__uppercase'
                        pid={`cut-orders-table__customer-number-${index}`}
                      >
                        {customerNumber}
                      </span>
                    </Grid.Column>
                  </Grid.Row>
                  <Grid.Row className='cut-orders-table__cut-instruction'>
                    <Grid.Column text-align='left' stretched>
                      <DotDotDot clamp={2} useNativeClamp={false}>
                        <span pid={`cut-orders-table__cut-instruction-${index}`}>
                          {producingInstruction}
                        </span>
                      </DotDotDot>
                    </Grid.Column>
                  </Grid.Row>
                </Grid>
              </Table.Cell>
              <Table.Cell width={4}>
                <Grid>
                  <Grid.Row columns={2}>
                    <Grid.Column text-align='left' width={8}>
                      <span
                        className='cut-orders-table__uppercase'
                        pid={`cut-orders-table__delivery-date-${index}`}
                      >
                        {deliveryDate}
                      </span>
                    </Grid.Column>
                    <Grid.Column text-align='left' width={8}>
                      <span
                        className={`cut-orders-table__uppercase ${isUpdated ? 'error' : ''}`}
                        pid={`cut-orders-table__today-quantity-${index}`}
                      >
                        {quantity}
                      </span>
                    </Grid.Column>
                  </Grid.Row>
                  <Grid.Row columns={1}>
                    <Grid.Column
                      text-align='left'
                      className='cut-orders-table__pack-instruction'
                      stretched
                    >
                      <DotDotDot clamp={2} useNativeClamp={false}>
                        <span pid={`cut-orders-table__pack-instruction-${index}`}>
                          {cutType === 'BANQUET' ? 'BANQUET: ' : ''}
                          {packInstruction}
                        </span>
                      </DotDotDot>
                    </Grid.Column>
                  </Grid.Row>
                </Grid>
              </Table.Cell>
            </Table.Row>
          </Ref>
        );
      })}
    </Table.Body>
  );
}

CutOrderTableBody.propTypes = {
  cutOrdersInfo: PropTypes.array.isRequired,
  handleSelect: PropTypes.func.isRequired,
  handleConfirm: PropTypes.func.isRequired,
  tabbable: PropTypes.bool,
  autoFocus: PropTypes.bool
};
