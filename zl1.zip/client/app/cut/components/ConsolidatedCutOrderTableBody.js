import React from 'react';
import PropTypes from 'prop-types';
import { Grid, Ref, Table } from 'semantic-ui-react';
import DotDotDot from 'react-dotdotdot';
import { handleKeyDown, productCodeConsolidator } from './cutOrderHelpers';

const ConsolidatedCutOrderTableBody = ({
  cutOrdersInfo,
  handleSelect,
  handleConfirm,
  tabbable = true,
  autoFocus = true
}) => {
  const consolidatedOrders = productCodeConsolidator(cutOrdersInfo);

  return (
    <Table.Body>
      {Object.keys(consolidatedOrders).map((key, index) => {
        const productPortionSize = consolidatedOrders[key].product.productPortionSize;
        const portionSize = productPortionSize.portionSize;
        const productCode = consolidatedOrders[key].product.code;
        const productDescription = consolidatedOrders[key].product.description;
        const selected = consolidatedOrders[key].selected;
        const totalQuantity = consolidatedOrders[key].totalQuantity;

        let handleFocusFirstRow;
        if (autoFocus) {
          handleFocusFirstRow = node => index === 0 && node.focus();
        } else {
          handleFocusFirstRow = () => {};
        }

        return (
          <Ref key={`ref-${key}`} innerRef={handleFocusFirstRow}>
            <Table.Row
              key={key}
              pid={`cut-orders-table__table-row-${index}`}
              tabIndex={tabbable ? 0 : null}
              active={tabbable && selected}
              onClick={event => handleSelect(consolidatedOrders[key].orderIds, event, productCode)}
              onKeyDown={event =>
                handleKeyDown(
                  handleSelect,
                  handleConfirm,
                  consolidatedOrders[key].orderIds,
                  event,
                  productCode
                )
              }
            >
              <Table.Cell width={6}>
                <Grid>
                  <Grid.Row>
                    <Grid.Column text-align='left'>
                      <span
                        className='cut-orders-table__uppercase'
                        pid={`cut-orders-table__product-code-${index}`}
                      >
                        {`${productCode} / ${portionSize}`}
                      </span>
                      <DotDotDot clamp={1} useNativeClamp={false}>
                        <span
                          className='cut-orders-table__uppercase'
                          pid={`cut-orders-table__product-description-${index}`}
                        >
                          {productDescription}
                        </span>
                      </DotDotDot>
                    </Grid.Column>
                  </Grid.Row>
                </Grid>
              </Table.Cell>
              <Table.Cell width={6} />
              <Table.Cell width={4}>
                <Grid>
                  <Grid.Row columns={2}>
                    <Grid.Column text-align='left' width={8}>
                      <span
                        className='cut-orders-table__uppercase'
                        pid={`cut-orders-table__delivery-date-${index}`}
                      />
                    </Grid.Column>
                    <Grid.Column text-align='left' width={8}>
                      <span pid={`cut-orders-table__today-quantity-${index}`}>{totalQuantity}</span>
                    </Grid.Column>
                  </Grid.Row>
                </Grid>
              </Table.Cell>
            </Table.Row>
          </Ref>
        );
      })}
    </Table.Body>
  );
};

ConsolidatedCutOrderTableBody.propTypes = {
  cutOrdersInfo: PropTypes.array.isRequired,
  handleSelect: PropTypes.func.isRequired,
  handleConfirm: PropTypes.func.isRequired,
  tabbable: PropTypes.bool,
  autoFocus: PropTypes.bool
};

export default ConsolidatedCutOrderTableBody;
