import React from 'react';
import PropTypes from 'prop-types';
import { Table } from 'semantic-ui-react';
import CutOrderTableBody from './CutOrderTableBody';
import CutOrderTableHeader from './CutOrderTableHeader';

export default function CutOrderTable({
  cutOrdersInfo,
  handleSelect,
  handleConfirm,
  tabbable = true,
  autoFocus = true
}) {
  return (
    <Table size='large' className='cut-orders-table' basic='very' pid='cut-orders-table'>
      <CutOrderTableHeader />
      <CutOrderTableBody
        autoFocus={autoFocus}
        tabbable={tabbable}
        cutOrdersInfo={cutOrdersInfo}
        handleSelect={handleSelect}
        handleConfirm={handleConfirm}
      />
    </Table>
  );
}

CutOrderTable.propTypes = {
  cutOrdersInfo: PropTypes.array.isRequired,
  handleSelect: PropTypes.func.isRequired,
  handleConfirm: PropTypes.func.isRequired,
  tabbable: PropTypes.bool,
  autoFocus: PropTypes.bool
};
