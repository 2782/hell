import React from 'react';
import * as _ from 'lodash';
import { Form, Table } from 'semantic-ui-react';
import PropTypes from 'prop-types';
import FormElement from '../../shared/FormElement';
import { Field } from 'redux-form';
import {
  nonNegativeNumber,
  required,
  number,
  wholeNumber
} from '../../shared/validation/formFieldValidations';
import { reportingTableHelpers } from '../../productActivity/helpers';

const renderTable = additives => {
  return (
    <Table fixed selectable>
      <Table.Header>
        <Table.Row>
          <Table.HeaderCell width={5}>ADDITIVES</Table.HeaderCell>
          <Table.HeaderCell width={5} />
          <Table.HeaderCell width={4}>ORDER QUANTITY</Table.HeaderCell>
          <Table.HeaderCell width={2}>U/M</Table.HeaderCell>
        </Table.Row>
      </Table.Header>
      {renderBody(additives)}
    </Table>
  );
};

const renderBody = additives => {
  return (
    <Table.Body key={'additives-table-table-content'}>
      {_.map(additives, (additive, additiveIndex) => {
        const { productCode, productDesc, unitOfMeasure } = additive;

        return (
          <Table.Row pid={`additives-table__table-row-${additiveIndex}`} key={additiveIndex}>
            <Table.Cell width={5} verticalAlign='top'>
              <div pid='additives-table__table-cell-product-code'>{productCode}</div>
            </Table.Cell>
            <Table.Cell width={5} verticalAlign='top'>
              <div pid='additives-table__table-cell-product-desc'>{productDesc}</div>
            </Table.Cell>
            <Table.Cell pid='additives-table__table-cell' width={4} verticalAlign='top'>
              <div pid='additives-table__table-cell-inner-product-code'>
                <Field
                  className={'quantity'}
                  width={10}
                  validate={[required, number, wholeNumber, nonNegativeNumber]}
                  component={FormElement}
                  name={`${productCode}-additives-quantity`}
                  as={Form.Input}
                />
              </div>
            </Table.Cell>
            <Table.Cell width={2}>
              <div>{reportingTableHelpers.formatUnitOfMeasure(unitOfMeasure)}</div>
            </Table.Cell>
          </Table.Row>
        );
      })}
    </Table.Body>
  );
};

const AdditivesTable = ({ additives }) => {
  return <div>{_.isEmpty(additives) ? null : renderTable(additives)}</div>;
};

AdditivesTable.propTypes = {
  additives: PropTypes.array
};

export default AdditivesTable;
