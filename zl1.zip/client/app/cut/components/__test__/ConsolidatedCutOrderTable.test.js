import React from 'react';
import { shallow } from 'enzyme';
import CutOrderFactory from '../../../../test-factories/cutOrder';
import CutOrderTableHeader from '../CutOrderTableHeader';
import ConsolidatedCutOrderTableBody from '../ConsolidatedCutOrderTableBody';
import ConsolidatedCutOrderTable from '../ConsolidatedCutOrderTable';

describe('ConsolidatedCutOrderTable', () => {
  let consolidatedCutOrderTable, handleSelect, handleConfirm;

  beforeEach(() => {
    handleSelect = jest.fn();
    handleConfirm = jest.fn();

    consolidatedCutOrderTable = shallow(
      <ConsolidatedCutOrderTable
        cutOrdersInfo={[
          {
            data: CutOrderFactory.build({ id: 12, productionType: 'CUTTING' }),
            index: 0,
            selected: false
          }
        ]}
        handleSelect={handleSelect}
        handleConfirm={handleConfirm}
      />
    );
  });

  test('should render a table header', () => {
    jestExpect(consolidatedCutOrderTable.find(CutOrderTableHeader)).toExist();
  });

  test('should render a table body', () => {
    jestExpect(consolidatedCutOrderTable.find(ConsolidatedCutOrderTableBody)).toExist();
    jestExpect(consolidatedCutOrderTable.find(ConsolidatedCutOrderTableBody)).toHaveProp({
      cutOrdersInfo: [
        {
          data: CutOrderFactory.build({ id: 12, productionType: 'CUTTING' }),
          index: 0,
          selected: false
        }
      ]
    });
    jestExpect(consolidatedCutOrderTable.find(ConsolidatedCutOrderTableBody)).toHaveProp({
      handleSelect
    });
    jestExpect(consolidatedCutOrderTable.find(ConsolidatedCutOrderTableBody)).toHaveProp({
      handleConfirm
    });
  });

  test('should make table body tabbable by default', () => {
    jestExpect(consolidatedCutOrderTable.find(ConsolidatedCutOrderTableBody)).toHaveProp({
      tabbable: true
    });
  });

  test('should make table body not tabbable', () => {
    consolidatedCutOrderTable.setProps({ tabbable: false });

    jestExpect(consolidatedCutOrderTable.find(ConsolidatedCutOrderTableBody)).toHaveProp({
      tabbable: false
    });
  });
});
