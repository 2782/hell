import { mount } from 'enzyme';
import React from 'react';
import SourceMeatTable from '../SourceMeatTable';
import semanticUI from '../../../../test-helpers/semantic-ui';
import EmptyListMessage from '../../../shared/components/EmptyListMessage';
import { sourceMeatOrder1, sourceMeatOrder2 } from '../../../../test-factories/sourceMeatOrder';
import { reduxForm } from 'redux-form';
import store from '../../../store';
import { Provider } from 'react-redux';

describe('sourceMeatTable', () => {
  let wrapper, Decorated;

  beforeEach(() => {
    Decorated = reduxForm({ form: 'testForm' })(SourceMeatTable);

    wrapper = mount(
      <Provider store={store}>
        <Decorated sourceMeatOrders={[sourceMeatOrder1, sourceMeatOrder2]} />
      </Provider>
    );
  });

  function getSourceMeatCell(row, col) {
    return semanticUI.findTableColumnWithRowIndex(wrapper.find('tbody').at(0), row, col, 'td');
  }

  test('should render correct table header', () => {
    const headerRow = semanticUI.findTable(wrapper, 0).find('th');

    jestExpect(headerRow.at(0).text()).toEqual('PRODUCT');
    jestExpect(headerRow.at(1).text()).toEqual('SOURCE PRODUCT');
    jestExpect(headerRow.at(2).text()).toEqual('ORDER QUANTITY');
  });

  test('should render correct table content when no ingredients', () => {
    jestExpect(getSourceMeatCell(0, 0).text()).toEqual(jestExpect.stringContaining('0078889'));
    jestExpect(getSourceMeatCell(0, 0).text()).toEqual(
      jestExpect.stringContaining('PRIME CC TRUE BARREL FILET STK')
    );
    jestExpect(getSourceMeatCell(0, 1).text()).toEqual(jestExpect.stringContaining('0079007'));
    jestExpect(getSourceMeatCell(0, 1).text()).toEqual(
      jestExpect.stringContaining('FLEMINGS CAB PRHOUSE STK')
    );
    jestExpect(getSourceMeatCell(0, 3).text()).toEqual(jestExpect.stringContaining('CS'));
  });

  test('should render correct table content when has ingredients', () => {
    jestExpect(getSourceMeatCell(1, 0).text()).toEqual(jestExpect.stringContaining('0078891'));
    jestExpect(getSourceMeatCell(1, 0).text()).toEqual(
      jestExpect.stringContaining('QB, PRIME T-BONE STEAK 205')
    );
    jestExpect(getSourceMeatCell(1, 1).text()).toEqual(jestExpect.stringContaining('0079888'));
    jestExpect(getSourceMeatCell(1, 1).text()).toEqual(
      jestExpect.stringContaining('QB, SOURCE PRIME T-BONE')
    );
    jestExpect(getSourceMeatCell(1, 1).text()).toEqual(
      jestExpect.stringContaining('Ingredients: ingredients')
    );
    jestExpect(getSourceMeatCell(1, 3).text()).toEqual(jestExpect.stringContaining('PC'));
  });

  test('should render empty list message when there are no source meat orders', () => {
    wrapper = mount(<SourceMeatTable sourceMeatOrders={[]} />);

    jestExpect(semanticUI.findTables(wrapper)).toHaveLength(0);
    jestExpect(wrapper.find(EmptyListMessage).exists()).toBeTruthy();
  });
});
