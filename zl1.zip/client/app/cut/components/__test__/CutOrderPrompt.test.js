import React from 'react';
import { shallow } from 'enzyme';
import CutOrderPrompt from '../CutOrderPrompt';
import { Button, Header } from 'semantic-ui-react';

describe('CutOrderPrompt', () => {
  let wrapper, handleYes, handleNo;
  const YES_BUTTON_TEXT = 'YES, CLICK ME!';
  const NO_BUTTON_TEXT = 'NO, CLICK ME INSTEAD!';
  const MESSAGE_TEXT = 'Which decision shall you mean?';

  beforeEach(() => {
    handleYes = jest.fn();
    handleNo = jest.fn();

    wrapper = shallow(
      <CutOrderPrompt
        handleYes={handleYes}
        handleNo={handleNo}
        yesButtonText={YES_BUTTON_TEXT}
        noButtonText={NO_BUTTON_TEXT}
        message={MESSAGE_TEXT}
        yesButtonDisbled={false}
      />
    );
  });

  test('should render disabled yes button when yesButtonDisabled is true', () => {
    wrapper = shallow(
      <CutOrderPrompt
        handleYes={handleYes}
        handleNo={handleNo}
        yesButtonText={YES_BUTTON_TEXT}
        noButtonText={NO_BUTTON_TEXT}
        message={MESSAGE_TEXT}
        yesButtonDisbled={true}
      />
    );

    jestExpect(wrapper.find(Button).at(0)).toBeDisabled();
  });

  test('should render message, yes button text, and no button text', () => {
    jestExpect(wrapper.find(Header)).toHaveProp({ children: MESSAGE_TEXT });
    jestExpect(wrapper.find(Button).at(0)).toHaveProp({ children: YES_BUTTON_TEXT });
    jestExpect(wrapper.find(Button).at(1)).toHaveProp({ children: NO_BUTTON_TEXT });
  });

  test('should perform on yes behavior on yes button click', () => {
    wrapper
      .find(Button)
      .at(0)
      .simulate('click');

    jestExpect(handleYes).toHaveBeenCalledTimes(1);
    jestExpect(handleNo).not.toHaveBeenCalled();
  });

  test('should perform on no behavior on no button click', () => {
    wrapper
      .find(Button)
      .at(1)
      .simulate('click');

    jestExpect(handleYes).not.toHaveBeenCalled();
    jestExpect(handleNo).toHaveBeenCalledTimes(1);
  });
});
