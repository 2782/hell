import React from 'react';
import { Table } from 'semantic-ui-react';
import CutOrderTableHeader from '../CutOrderTableHeader';

describe('CutOrderTableHeader', () => {
  let cutOrderTableHeader;

  beforeEach(() => {
    cutOrderTableHeader = mount(
      <Table>
        <CutOrderTableHeader />
      </Table>
    );
  });

  test('should render CutOrderTableHeader correctly', () => {
    jestExpect(cutOrderTableHeader.find(Table.HeaderCell).at(0)).toHaveText('PRODUCT');
    jestExpect(cutOrderTableHeader.find(Table.HeaderCell).at(1)).toHaveText('CUSTOMER');
    jestExpect(cutOrderTableHeader.find(Table.HeaderCell).at(2)).toHaveText('DATE');
    jestExpect(cutOrderTableHeader.find(Table.HeaderCell).at(3)).toHaveText('QTY');
  });
});
