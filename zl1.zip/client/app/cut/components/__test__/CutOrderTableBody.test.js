import React from 'react';
import { shallow } from 'enzyme';
import { Table } from 'semantic-ui-react';
import CutOrderFactory from '../../../../test-factories/cutOrder';
import { cutOrder3 } from '../../../shared/testData/cutOrdersForTesting';
import CutOrderTableBody, { orderItemData } from '../CutOrderTableBody';
import { handleKeyDown } from '../cutOrderHelpers';

jest.mock('../cutOrderHelpers', () => ({
  handleKeyDown: jest.fn()
}));

describe('CutOrderTableBody', () => {
  describe('component', () => {
    let cutOrderTableBody, handleSelect, handleConfirm;

    beforeEach(() => {
      handleSelect = jest.fn();
      handleConfirm = jest.fn();

      cutOrderTableBody = shallow(
        <CutOrderTableBody
          cutOrdersInfo={[
            {
              data: CutOrderFactory.build({ id: 12, productionType: 'CUTTING' }),
              orderId: 12,
              selected: false
            }
          ]}
          firstDay={'today'}
          confirm={false}
          handleSelect={handleSelect}
          handleConfirm={handleConfirm}
        />
      );
    });

    test('should call handleKeyDown on keydown event', () => {
      cutOrderTableBody.find(Table.Row).simulate('keydown', { key: ' ' });

      jestExpect(handleKeyDown).toHaveBeenCalledWith(
        handleSelect,
        handleConfirm,
        12,
        { key: ' ' },
        '0071185'
      );
    });

    test('should call handleSelect on click event', () => {
      cutOrderTableBody.find(Table.Row).simulate('click');

      jestExpect(handleSelect).toHaveBeenCalledWith(12, undefined, '0071185');
    });

    test('should render table rows for number of cut orders', () => {
      cutOrderTableBody.setProps({
        cutOrdersInfo: [
          {
            data: CutOrderFactory.build({ id: 12, productionType: 'CUTTING' }),
            orderId: 12,
            selected: false
          },
          {
            data: CutOrderFactory.build({ id: 14, productionType: 'CUTTING' }),
            orderId: 14,
            selected: false
          }
        ]
      });

      jestExpect(cutOrderTableBody.find(Table.Row)).toHaveLength(2);
    });

    test('should render table row as tabbable and selected by default', () => {
      cutOrderTableBody.setProps({
        cutOrdersInfo: [
          {
            data: CutOrderFactory.build({ id: 12, productionType: 'CUTTING' }),
            orderId: 12,
            selected: true
          }
        ]
      });

      jestExpect(cutOrderTableBody.find(Table.Row)).toHaveProp({ tabIndex: 0 });
      jestExpect(cutOrderTableBody.find(Table.Row)).toHaveProp({ active: true });
    });

    test('should render table row as not tabbable or selected', () => {
      cutOrderTableBody.setProps({
        cutOrdersInfo: [
          {
            data: CutOrderFactory.build({ id: 12, productionType: 'CUTTING' }),
            orderId: 12,
            selected: true
          }
        ],
        tabbable: false
      });

      jestExpect(cutOrderTableBody.find(Table.Row)).toHaveProp({ tabIndex: null });
      jestExpect(cutOrderTableBody.find(Table.Row)).toHaveProp({ active: false });
    });

    test('should not render that cut order is banquet pack when cut type is standard', () => {
      jestExpect(cutOrderTableBody.find('span').at(7)).toHaveText('Pack me off');
    });

    test('should render that cut order is banquet pack when cut type is pack', () => {
      cutOrderTableBody.setProps({
        cutOrdersInfo: [
          {
            data: CutOrderFactory.build({ id: 12, cutType: 'BANQUET', productionType: 'CUTTING' }),
            orderId: 12,
            selected: false
          }
        ]
      });

      jestExpect(cutOrderTableBody.find('span').at(7)).toHaveText('BANQUET: Pack me off');
    });
  });

  describe('orderItemData', () => {
    test('should transform cut order from API data to table data', () => {
      jestExpect(orderItemData({ data: cutOrder3, selected: false, orderId: 0 }, 'TODAY')).toEqual({
        selected: false,
        orderId: 3,
        productDescription: 'CAB SIRLOIN CULOTTE STEAK',
        productCode: '0071185',
        customerName: 'Test Customer Name',
        customerNumber: '99998',
        producingInstruction: 'Cut me off',
        portionSize: '12 OZ',
        cutType: 'STANDARD',
        packInstruction: 'Pack me off',
        deliveryDate: '05-17',
        quantity: 32,
        isCancelled: false,
        productionType: 'CUTTING',
        isUpdated: false
      });
    });
  });
});
