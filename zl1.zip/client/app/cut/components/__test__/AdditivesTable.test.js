import React from 'react';
import { mount } from 'enzyme';
import { Provider } from 'react-redux';
import store from '../../../store';
import { reduxForm } from 'redux-form';
import AdditivesTable from '../AdditivesTable';
import semanticUI from '../../../../test-helpers/semantic-ui';

describe('additivesTable', () => {
  let wrapper, Decorated;

  beforeEach(() => {
    Decorated = reduxForm({ form: 'testForm' })(AdditivesTable);
    const additive1 = {
      productCode: '0078889',
      productDesc: '0078889 desc',
      quantity: 10,
      unitOfMeasure: 'CASE'
    };
    const additive2 = {
      productCode: '0078891',
      productDesc: '0078891 desc',
      quantity: 20,
      unitOfMeasure: 'PIECE'
    };

    wrapper = mount(
      <Provider store={store}>
        <Decorated additives={[additive1, additive2]} />
      </Provider>
    );
  });

  function getAdditivesCell(row, col) {
    let additives = wrapper.find('tbody').at(0);
    return semanticUI.findTableColumnWithRowIndex(additives, row, col, 'td');
  }

  test('should render correct table header', () => {
    const header = semanticUI.findTable(wrapper, 0).find('th');

    jestExpect(header.at(0).text()).toEqual('ADDITIVES');
    jestExpect(header.at(2).text()).toEqual('ORDER QUANTITY');
    jestExpect(header.at(3).text()).toEqual('U/M');
  });

  test('should render correct table content', () => {
    jestExpect(getAdditivesCell(0, 0).text()).toEqual('0078889');
    jestExpect(getAdditivesCell(0, 1).text()).toEqual('0078889 desc');
    jestExpect(getAdditivesCell(0, 3).text()).toEqual('CS');
    jestExpect(getAdditivesCell(1, 0).text()).toEqual('0078891');
    jestExpect(getAdditivesCell(1, 1).text()).toEqual('0078891 desc');
    jestExpect(getAdditivesCell(1, 3).text()).toEqual('PC');
  });

  test('should render nothing when no additives', () => {
    wrapper = mount(<AdditivesTable additives={[]} />);

    jestExpect(semanticUI.findTables(wrapper)).toHaveLength(0);
  });
});
