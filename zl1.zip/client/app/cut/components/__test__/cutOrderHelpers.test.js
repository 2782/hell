import { handleKeyDown, productCodeConsolidator } from '../cutOrderHelpers';
import CutOrderFactory from '../../../../test-factories/cutOrder';

describe('productCodeConsolidator', () => {
  const initialCutOrdersInfo = [
    {
      data: CutOrderFactory.build({
        id: 12,
        productionType: 'CUTTING',
        product: {
          code: '2111203',
          description: 'BEEF STEAK T-BONE CH #1174',
          productPortionSize: {
            portionSize: {
              unitOfWeight: 'OZ',
              value: 12
            }
          },
          category: 'CATCH',
          minWeight: 1,
          maxWeight: 20
        }
      }),
      orderId: 12,
      selected: false
    },
    {
      data: CutOrderFactory.build({
        id: 13,
        productionType: 'CUTTING',
        product: {
          code: '2111203',
          description: 'BEEF STEAK T-BONE CH #1174',
          productPortionSize: {
            portionSize: {
              unitOfWeight: 'OZ',
              value: 12
            }
          },
          category: 'CATCH',
          minWeight: 1,
          maxWeight: 20
        },
        qtyInBoxes: 8
      }),
      orderId: 13,
      selected: false
    },
    {
      data: CutOrderFactory.build({
        id: 14,
        productionType: 'CUTTING',
        product: {
          code: '4102218',
          description: 'BEEF STEAK T-BONE CLS',
          productPortionSize: {
            portionSize: {
              unitOfWeight: 'OZ',
              value: 5
            }
          },
          category: 'CATCH',
          minWeight: 1,
          maxWeight: 20
        },
        qtyInBoxes: 10
      }),
      orderId: 14,
      selected: false
    }
  ];

  test('should consolidate cutOrders by product code', () => {
    const expectedConsolidatedCutOrdersInfo = {
      '2111203': {
        orderIds: [12, 13],
        product: {
          code: '2111203',
          description: 'BEEF STEAK T-BONE CH #1174',
          productPortionSize: {
            portionSize: {
              unitOfWeight: 'OZ',
              value: 12
            }
          },
          category: 'CATCH',
          minWeight: 1,
          maxWeight: 20
        },
        totalQuantity: 40,
        selected: false
      },
      '4102218': {
        orderIds: [14],
        product: {
          code: '4102218',
          description: 'BEEF STEAK T-BONE CLS',
          productPortionSize: {
            portionSize: {
              unitOfWeight: 'OZ',
              value: 5
            }
          },
          category: 'CATCH',
          minWeight: 1,
          maxWeight: 20
        },
        totalQuantity: 10,
        selected: false
      }
    };

    const finishedCutOrdersInfo = productCodeConsolidator(initialCutOrdersInfo);

    jestExpect(finishedCutOrdersInfo).toEqual(expectedConsolidatedCutOrdersInfo);
  });

  test('should see consolidated as selected if the first order is selected', () => {
    const consolidated = productCodeConsolidator([
      {
        data: CutOrderFactory.build({
          id: 12,
          productionType: 'CUTTING',
          product: {
            code: '2111203',
            description: 'BEEF STEAK T-BONE CH #1174',
            productPortionSize: {
              portionSize: {
                unitOfWeight: 'OZ',
                value: 12
              }
            },
            category: 'CATCH',
            minWeight: 1,
            maxWeight: 20
          }
        }),
        orderId: 12,
        selected: true
      }
    ]);

    jestExpect(consolidated['2111203'].selected).toEqual(true);
  });

  test('should select row on spacebar', () => {
    const handleSelect = jest.fn();
    const handleConfirm = jest.fn();
    const event = {
      preventDefault: jest.fn(),
      persist: jest.fn(),
      stopPropagation: jest.fn(),
      target: {
        nextElementSibling: { focus: jest.fn() },
        previousElementSibling: { focus: jest.fn() }
      }
    };

    handleKeyDown(handleSelect, handleConfirm, [1, 2, 3], { ...event, key: ' ' }, '1234567');

    jestExpect(event.persist).toHaveBeenCalledTimes(1);
    jestExpect(event.preventDefault).toHaveBeenCalledTimes(1);
    jestExpect(handleSelect).toHaveBeenCalledWith([1, 2, 3], { ...event, key: ' ' }, '1234567');
  });

  test('should confirm selection on enter', () => {
    const handleSelect = jest.fn();
    const handleConfirm = jest.fn();
    const event = {
      preventDefault: jest.fn(),
      persist: jest.fn(),
      stopPropagation: jest.fn(),
      target: {
        nextElementSibling: { focus: jest.fn() },
        previousElementSibling: { focus: jest.fn() }
      }
    };

    handleKeyDown(handleSelect, handleConfirm, [4, 5], { ...event, key: 'Enter' }, '7654321');

    jestExpect(event.persist).toHaveBeenCalledTimes(1);
    jestExpect(event.preventDefault).toHaveBeenCalledTimes(1);
    jestExpect(event.stopPropagation).toHaveBeenCalledTimes(1);
    jestExpect(handleConfirm).toHaveBeenCalledTimes(1);
  });

  test('should focus to next row on down arrow', () => {
    const handleSelect = jest.fn();
    const handleConfirm = jest.fn();
    const event = {
      preventDefault: jest.fn(),
      persist: jest.fn(),
      stopPropagation: jest.fn(),
      target: {
        nextElementSibling: { focus: jest.fn() },
        previousElementSibling: { focus: jest.fn() }
      }
    };

    handleKeyDown(handleSelect, handleConfirm, 6, { ...event, key: 'ArrowDown' }, '2221112');

    jestExpect(event.persist).toHaveBeenCalledTimes(1);
    jestExpect(event.target.nextElementSibling.focus).toHaveBeenCalledTimes(1);
  });

  test('should focus to previous row on up arrow', () => {
    const handleSelect = jest.fn();
    const handleConfirm = jest.fn();
    const event = {
      preventDefault: jest.fn(),
      persist: jest.fn(),
      stopPropagation: jest.fn(),
      target: {
        nextElementSibling: { focus: jest.fn() },
        previousElementSibling: { focus: jest.fn() }
      }
    };

    handleKeyDown(handleSelect, handleConfirm, 6, { ...event, key: 'ArrowUp' }, '1111112');

    jestExpect(event.persist).toHaveBeenCalledTimes(1);
    jestExpect(event.target.previousElementSibling.focus).toHaveBeenCalledTimes(1);
  });
});
