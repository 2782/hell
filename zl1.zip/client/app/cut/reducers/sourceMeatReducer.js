import { RESET_SOURCE_MEAT_INFO, UPDATE_SOURCE_MEAT_INFO } from '../actions/cutActionTypes';

const initialState = {
  sourceMeatOrders: null
};

export default (state = initialState, action) => {
  switch (action.type) {
    case UPDATE_SOURCE_MEAT_INFO:
      return {
        ...state,
        sourceMeatOrders: action.payload
      };

    case RESET_SOURCE_MEAT_INFO:
      return {
        ...state,
        sourceMeatOrders: null
      };

    default:
      return state;
  }
};
