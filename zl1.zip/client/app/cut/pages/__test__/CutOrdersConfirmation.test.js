import React from 'react';
import { mount, shallow } from 'enzyme';
import { Provider } from 'react-redux';
import { createReduxStore } from '../../../store';
import { Button, Table } from 'semantic-ui-react';
import {
  cutOrder1WithNames,
  cutOrder2WithNames
} from '../../../shared/testData/cutOrdersForTesting';

import CutOrdersConfirmation, {
  mapStateToProps,
  CutOrdersConfirmation as CutOrdersConfirmationComponent,
  f4Behavior
} from '../CutOrdersConfirmation';
import CutOrderTable from '../../components/CutOrderTable';
import CutOrderPrompt from '../../components/CutOrderPrompt';
import { CUT_STATION } from '../../../shared/components/pageTitles';
import { CUT_STATION_FOOTER } from '../../../shared/components/pageFooters';
import ConsolidatedCutOrderTable from '../../components/ConsolidatedCutOrderTable';
import HeaderNavigation from '../../../shared/components/HeaderNavigation';

jest.mock('../../../shared/components/Header');
jest.mock('../../../shared/errors/ErrorNotification');

describe('CutOrdersConfirmation', () => {
  let wrapper;
  let store;

  beforeEach(() => {
    store = createReduxStore({
      operatingDates: {
        today: '2017-01-07',
        firstDay: '2017-01-07',
        secondDay: '2017-01-08'
      },
      cutTablesInfo: {
        cutStation: {
          userId: 'user-1'
        }
      },
      cutOrdersInfo: {
        cutOrdersInfo: [
          { index: 0, data: cutOrder2WithNames, selected: true },
          { index: 1, data: cutOrder1WithNames, selected: false }
        ],
        confirmingInProgress: false
      },
      login: {
        userId: 'user-1'
      }
    });

    wrapper = mount(
      <Provider store={store}>
        <CutOrdersConfirmation match={{ params: { tableId: '1', stationId: '1' } }} />
      </Provider>
    );
  });

  test('should render a confirmation message and only selected cut orders in table when confirming', () => {
    jestExpect(wrapper.find(CutOrderTable)).toHaveProp({
      tabbable: false,
      cutOrdersInfo: [{ data: cutOrder2WithNames, index: 0, selected: true }]
    });
    jestExpect(wrapper.find(CutOrderPrompt)).toHaveProp({ message: 'Print Cut Tickets?' });
  });

  test('should submit cut orders to cut and navigate to cut orders source meat page on confirm button click', () => {
    const setHeaderAndFooter = jest.fn();
    const confirmCutOrders = jest.fn();

    wrapper = mount(
      <CutOrdersConfirmationComponent
        replacePath={jest.fn()}
        setHeaderAndFooter={setHeaderAndFooter}
        match={{ params: { stationId: 1, tableId: 1 } }}
        operatingDates={{
          today: '2017-01-07',
          firstDay: '2017-01-07',
          secondDay: '2017-01-08'
        }}
        cutOrdersInfo={[
          { index: 0, data: cutOrder2WithNames, selected: true },
          { index: 1, data: cutOrder1WithNames, selected: false }
        ]}
        cutStation={{ userId: 'user-1' }}
        userId={'user-1'}
        shouldGoBackToCutOrderSelection={false}
        portionRoomTableInfo={{}}
        toggleCutOrderSelection={() => {}}
        confirmCutOrders={confirmCutOrders}
        confirmingInProgress={false}
      />
    );

    wrapper
      .find(CutOrderPrompt)
      .props()
      .handleYes();

    jestExpect(confirmCutOrders).toHaveBeenCalled();
    jestExpect(setHeaderAndFooter).toHaveBeenCalledWith({
      header: CUT_STATION,
      footer: CUT_STATION_FOOTER
    });
  });

  test('should disable confirm button if user not assigned to station', () => {
    wrapper = mount(
      <CutOrdersConfirmationComponent
        replacePath={jest.fn()}
        match={{ params: { stationId: 1, tableId: 1 } }}
        operatingDates={{
          today: '2017-01-07',
          firstDay: '2017-01-07',
          secondDay: '2017-01-08'
        }}
        cutOrdersInfo={[
          { index: 0, data: cutOrder2WithNames, selected: true },
          { index: 1, data: cutOrder1WithNames, selected: false }
        ]}
        cutStation={{ userId: 'user-1' }}
        userId={'user-2'}
        shouldGoBackToCutOrderSelection={false}
        portionRoomTableInfo={{}}
        toggleCutOrderSelection={() => {}}
        confirmCutOrders={jest.fn()}
        setHeaderAndFooter={jest.fn()}
        confirmingInProgress={false}
      />
    );

    jestExpect(wrapper.find(Button).at(0)).toBeDisabled();
  });

  test('should disable confirm button if confirming cut order action is in process', () => {
    wrapper = mount(
      <CutOrdersConfirmationComponent
        replacePath={jest.fn()}
        match={{ params: { stationId: 1, tableId: 1 } }}
        operatingDates={{
          today: '2017-01-07',
          firstDay: '2017-01-07',
          secondDay: '2017-01-08'
        }}
        cutOrdersInfo={[
          { index: 0, data: cutOrder2WithNames, selected: true },
          { index: 1, data: cutOrder1WithNames, selected: false }
        ]}
        cutStation={{ userId: 'user-2' }}
        userId={'user-2'}
        shouldGoBackToCutOrderSelection={false}
        portionRoomTableInfo={{}}
        toggleCutOrderSelection={() => {}}
        confirmCutOrders={jest.fn()}
        setHeaderAndFooter={jest.fn()}
        confirmingInProgress={true}
      />
    );

    jestExpect(wrapper.find(Button).at(0)).toBeDisabled();
  });

  test('should navigate to cut order selection on change button click', () => {
    const replacePath = jest.fn();
    const setHeaderAndFooter = jest.fn();

    wrapper = mount(
      <CutOrdersConfirmationComponent
        replacePath={replacePath}
        match={{ params: { stationId: 1, tableId: 1 } }}
        operatingDates={{
          today: '2017-01-07',
          firstDay: '2017-01-07',
          secondDay: '2017-01-08'
        }}
        cutOrdersInfo={[
          { index: 0, data: cutOrder2WithNames, selected: true },
          { index: 1, data: cutOrder1WithNames, selected: false }
        ]}
        cutStation={{ userId: 'user-1' }}
        userId={'user-1'}
        shouldGoBackToCutOrderSelection={false}
        portionRoomTableInfo={{}}
        toggleCutOrderSelection={() => {}}
        confirmCutOrders={() => {}}
        setHeaderAndFooter={setHeaderAndFooter}
        confirmingInProgress={false}
      />
    );

    wrapper
      .find(CutOrderPrompt)
      .props()
      .handleNo();

    jestExpect(replacePath).toHaveBeenCalledWith('/cut/stations/1/tables/1/select');
  });

  test('should navigate to cut order selection on F4', () => {
    const props = { match: { params: { stationId: 123, tableId: 10 } }, replacePath: jest.fn() };

    f4Behavior(props);

    jestExpect(props.replacePath).toHaveBeenCalledWith('/cut/stations/123/tables/10/select');
  });

  test('should ignore row clicks', () => {
    jestExpect(wrapper.find(Table.Row).at(1)).toHaveProp({ active: false });

    wrapper
      .find(Table.Row)
      .at(1)
      .simulate('click');

    jestExpect(wrapper.find(Table.Row).at(1)).toHaveProp({ active: false });
  });

  test('should ignore space bar on rows', () => {
    jestExpect(wrapper.find(Table.Row).at(1)).toHaveProp({ active: false });

    wrapper
      .find(Table.Row)
      .at(1)
      .simulate('keydown', { key: ' ' });

    jestExpect(wrapper.find(Table.Row).at(1)).toHaveProp({ active: false });
  });

  describe('Translating state into props', () => {
    test('should copy over confirmingInProgress', () => {
      const state = {
        operatingDates: {
          today: '2017-01-07',
          firstDay: '2017-01-07',
          secondDay: '2017-01-08'
        },
        cutTablesInfo: {
          cutStation: {
            userId: 'user-1'
          }
        },
        cutOrdersInfo: {
          cutOrdersInfo: [
            { index: 0, data: cutOrder2WithNames, selected: true },
            { index: 1, data: cutOrder1WithNames, selected: false }
          ],
          confirmingInProgress: true
        },
        login: {
          userId: 'user-1'
        }
      };

      jestExpect(mapStateToProps(state).confirmingInProgress).toBe(true);
    });
  });

  describe('Header Navigation', () => {
    test('should pass in station, table, and consolidation toggle information to navigation header', () => {
      const toggleConsolidatedView = () => {};
      const portionRoomTableInfo = {
        stationCode: 45,
        name: 'JOHN',
        tableCode: 91,
        tableDescription: 'BEEF'
      };

      wrapper = shallow(
        <CutOrdersConfirmationComponent
          match={{ params: { stationId: 1, tableId: 1 } }}
          setHeaderAndFooter={() => {}}
          cutOrdersInfo={[{}]}
          cutStation={{ userId: 'user-1' }}
          userId={'user-1'}
          portionRoomTableInfo={portionRoomTableInfo}
          toggleConsolidatedView={toggleConsolidatedView}
          isConsolidated={true}
          confirmingInProgress={false}
        />
      );

      jestExpect(wrapper.find(HeaderNavigation)).toHaveProp({
        stationCode: portionRoomTableInfo.stationCode,
        stationName: portionRoomTableInfo.name,
        tableCode: portionRoomTableInfo.tableCode,
        tableDescription: portionRoomTableInfo.tableDescription,
        toggleText: 'Consolidate',
        toggleValue: true,
        renderToggle: true,
        toggleDisabled: true
      });
    });
  });

  test('should render consolidatedTable when consolidated toggle is on', () => {
    const wrapper = shallow(
      <CutOrdersConfirmationComponent
        setHeaderAndFooter={() => {}}
        cutOrdersInfo={[{}]}
        portionRoomTableInfo={{}}
        match={{ params: { stationId: 123 } }}
        cutStation={{ userId: 'user-1' }}
        userId={'user-1'}
        isConsolidated={true}
        confirmingInProgress={false}
      />
    );

    jestExpect(wrapper.find(ConsolidatedCutOrderTable)).toExist();
  });
});
