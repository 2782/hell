import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { replacePath, setHeaderAndFooter } from '../../shared/actions/actions';
import HeaderNavigation from '../../shared/components/HeaderNavigation';
import { CUT_STATION } from '../../shared/components/pageTitles';
import { confirmCutOrdersRequest } from '../actions/cutActions';
import { bindActionCreators } from 'redux';
import CutOrderTable from '../components/CutOrderTable';
import CutOrderPrompt from '../components/CutOrderPrompt';
import { CUT_STATION_FOOTER } from '../../shared/components/pageFooters';
import subscriber from '../../shared/functionKeys/subscriber';
import ConsolidatedCutOrderTable from '../components/ConsolidatedCutOrderTable';

export class CutOrdersConfirmation extends React.Component {
  constructor(props) {
    super(props);

    this.goBackToCutOrderSelection = this.goBackToCutOrderSelection.bind(this);
    this.confirmCutOrders = this.confirmCutOrders.bind(this);
  }

  componentDidMount() {
    this.props.setHeaderAndFooter({
      header: CUT_STATION,
      footer: CUT_STATION_FOOTER
    });
  }

  confirmCutOrders() {
    const {
      confirmCutOrders,
      match: {
        params: { stationId, tableId }
      }
    } = this.props;
    return confirmCutOrders(stationId, tableId);
  }

  goBackToCutOrderSelection() {
    const {
      replacePath,
      match: {
        params: { stationId, tableId }
      }
    } = this.props;
    replacePath(`/cut/stations/${stationId}/tables/${tableId}/select`);
  }

  render() {
    const { cutOrdersInfo, isConsolidated, cutStation, userId, confirmingInProgress } = this.props;
    const { stationCode, name, tableCode, tableDescription } = this.props.portionRoomTableInfo;

    const disableConfirm = (cutStation && cutStation.userId !== userId) || confirmingInProgress;

    return (
      <div className='page-content'>
        <HeaderNavigation
          stationCode={stationCode}
          stationName={name}
          tableCode={tableCode}
          tableDescription={tableDescription}
          renderToggle={true}
          toggleText='Consolidate'
          onToggle={() => {}}
          toggleValue={isConsolidated}
          toggleDisabled={true}
        />

        {isConsolidated ? (
          <ConsolidatedCutOrderTable
            tabbable={false}
            cutOrdersInfo={cutOrdersInfo.filter(item => item.selected)}
            handleSelect={() => {}}
            handleConfirm={() => {}}
          />
        ) : (
          <CutOrderTable
            key={0}
            tabbable={false}
            cutOrdersInfo={cutOrdersInfo.filter(item => item.selected)}
            handleSelect={() => {}}
            handleConfirm={() => {}}
          />
        )}

        <CutOrderPrompt
          handleYes={this.confirmCutOrders}
          handleNo={this.goBackToCutOrderSelection}
          yesButtonText='Yes'
          yesButtonDisbled={disableConfirm}
          noButtonText='Go Back'
          message='Print Cut Tickets?'
        />
      </div>
    );
  }
}

CutOrdersConfirmation.propTypes = {
  cutOrdersInfo: PropTypes.array,
  isConsolidated: PropTypes.bool,
  match: PropTypes.object,
  portionRoomTableInfo: PropTypes.object,
  operatingDates: PropTypes.object,
  userId: PropTypes.string,
  cutStation: PropTypes.object,
  confirmingInProgress: PropTypes.bool,

  replacePath: PropTypes.func,
  confirmCutOrders: PropTypes.func,
  setHeaderAndFooter: PropTypes.func
};

export const mapStateToProps = state => ({
  cutOrdersInfo: state.cutOrdersInfo.cutOrdersInfo,
  isConsolidated: state.cutOrdersInfo.isConsolidated,
  portionRoomTableInfo: state.portionRoomTableInfo,
  operatingDates: state.operatingDates,
  cutStation: state.cutTablesInfo.cutStation,
  userId: state.login.userId,
  confirmingInProgress: state.cutOrdersInfo.confirmingInProgress
});

const mapDispatchToProps = dispatch =>
  bindActionCreators(
    {
      replacePath,
      confirmCutOrders: confirmCutOrdersRequest,
      setHeaderAndFooter
    },
    dispatch
  );

export const f4Behavior = props => {
  const {
    replacePath,
    match: {
      params: { stationId, tableId }
    }
  } = props;
  replacePath(`/cut/stations/${stationId}/tables/${tableId}/select`);
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(
  subscriber(CutOrdersConfirmation, {
    f4Behavior,
    targetComponent: 'CutOrdersConfirmation',
    uris: {
      F4: ['#/cut/stations/*/tables/*/confirm']
    }
  })
);
