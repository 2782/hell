import cutTableSummaryResources from '../../../shared/api/cutTableSummaryResources';
import sourceMeatResources from '../../../shared/api/sourceMeatResources';
import cutOrdersResources from '../../../shared/api/cutOrdersResources';
import { cutOrder1, cutOrder2 } from '../../../shared/testData/cutOrdersForTesting';
import CutOrderFactory from '../../../../test-factories/cutOrder';
import {
  calcSourceMeat,
  confirmCutOrdersRequest,
  generateSourceMeatOrders,
  getCutOrdersInfo,
  getCutStation,
  getCutStationSummary,
  getCutTablesInfo,
  toggleConsolidatedCutOrderSelection,
  toggleConsolidatedView,
  toggleCutOrderSelection
} from '../cutActions';
import {
  CONFIRM_CUT_ORDERS_REQUESTED,
  CONFIRM_CUT_ORDERS_SUCCEEDED,
  CONSOLIDATED_CUT_ORDERS_TOGGLED,
  CONSOLIDATION_TOGGLED,
  CUT_ORDER_SELECTION_TOGGLED,
  CUT_TABLES_INFO_UPDATED,
  RESET_CUT_STATION_INFO,
  RESET_CUT_TABLES_INFO,
  RESET_SOURCE_MEAT_INFO,
  UPDATE_CUT_ORDERS_INFO,
  UPDATE_CUT_STATION_INFO,
  UPDATE_CUT_STATION_SUMMARY,
  UPDATE_SOURCE_MEAT_INFO
} from '../cutActionTypes';
import cutStationSummaryResources from '../../../shared/api/cutStationSummaryResources';
import cutStationResources from '../../../shared/api/stationResources';
import { getCostByProductCode_promise } from '../../../shared/api/costResources';
import { showNoCostWarningModal } from '../../../shared/actions/actions';

jest.mock('../../../shared/api/costResources');
jest.mock('../../../shared/api/cutOrdersResources');
jest.mock('../../../shared/api/cutTableSummaryResources');
jest.mock('../../../shared/api/sourceMeatResources');
jest.mock('../../../shared/api/cutStationSummaryResources');
jest.mock('../../../shared/api/stationResources');
jest.mock('../../../shared/actions/actions', () => ({
  showNoCostWarningModal: jest.fn(() => ({ type: 'MOCK_SHOW_MODAL' }))
}));

const cutOrdersResponse = {
  data: [cutOrder1, cutOrder2]
};

const getState = () => {
  return {
    portionRoomsInfo: {
      currentPortionRoom: {
        code: 'A'
      }
    },
    cutOrdersInfo: {
      cutOrdersInfo: [
        { index: 0, data: cutOrder2, selected: true },
        { index: 1, data: cutOrder1, selected: true },
        { index: 2, data: CutOrderFactory.build(), selected: false }
      ]
    }
  };
};

describe('cutActions', () => {
  let dispatch;

  beforeEach(() => {
    dispatch = jest.fn();
  });

  afterEach(() => {
    dispatch.mockReset();
  });

  describe('toggleConsolidatedView()', () => {
    test('should return action of type CONSOLIDATION_TOGGLED', () => {
      jestExpect(toggleConsolidatedView()).toEqual({
        type: CONSOLIDATION_TOGGLED
      });
    });
  });

  describe('getCutTablesInfo()', () => {
    const response = { data: [{ tableId: 1 }, { tableId: 2 }] };
    beforeEach(() => {
      cutTableSummaryResources.getCutTablesSummary.mockImplementation((roomCode, stationId, fn) => {
        return fn(response);
      });
    });

    test('should call getCutTablesSummary from cutTableSummaryResources and dispatch INIT_TABLES_TO_CUT', () => {
      getCutTablesInfo()(dispatch, getState);

      jestExpect(dispatch).toHaveBeenNthCalledWith(1, {
        type: RESET_CUT_TABLES_INFO
      });

      jestExpect(dispatch).toHaveBeenNthCalledWith(2, {
        type: CUT_TABLES_INFO_UPDATED,
        payload: response.data
      });
    });
  });

  describe('getCutOrdersInfo()', () => {
    test('should get cut order information with customer and user info', () => {
      cutOrdersResources.getOrdersByTableId.mockImplementation((room, tableCode, callback) => {
        return callback(cutOrdersResponse);
      });

      getCutOrdersInfo(1)(dispatch, getState);

      jestExpect(dispatch).toBeCalledWith({
        type: UPDATE_CUT_ORDERS_INFO,
        payload: cutOrdersResponse.data
      });
    });
  });

  describe('confirmCutOrdersRequest', () => {
    const tableId = '11';
    const stationId = '90';

    test('should successfully dispatch confirm actions during confirmCutOrdersRequest', async () => {
      cutOrdersResources.printCutTickets.mockResolvedValue({});
      cutOrdersResources.confirmCutOrders.mockResolvedValue({
        data: { cutOrderStatus: 'to-pack', id: cutOrder2.id }
      });

      await confirmCutOrdersRequest(stationId, tableId)(dispatch, getState);

      jestExpect(dispatch).toHaveBeenNthCalledWith(1, {
        type: CONFIRM_CUT_ORDERS_REQUESTED
      });
      jestExpect(dispatch).toHaveBeenNthCalledWith(2, {
        type: CONFIRM_CUT_ORDERS_SUCCEEDED
      });

      jestExpect(dispatch).toHaveBeenLastCalledWith({
        payload: {
          args: [`/cut/stations/${stationId}/tables/${tableId}/source-meat`],
          method: 'replace'
        },
        type: '@@router/CALL_HISTORY_METHOD'
      });
    });

    test('should call confirmCutOrdersRequest with cutOrdersIds and invoke callback', async () => {
      cutOrdersResources.printCutTickets.mockResolvedValue({});
      cutOrdersResources.confirmCutOrders.mockResolvedValue({
        data: { cutOrderStatus: 'to-pack', id: cutOrder2.id }
      });

      await confirmCutOrdersRequest(stationId, tableId)(dispatch, getState);
      jestExpect(cutOrdersResources.confirmCutOrders).toHaveBeenCalledWith('A', [
        cutOrder2.id,
        cutOrder1.id
      ]);
      jestExpect(cutOrdersResources.printCutTickets).toHaveBeenCalledWith([
        cutOrder2.id,
        cutOrder1.id
      ]);
    });
  });

  describe('calcSourceMeat', () => {
    test('should call calcSourceMeat and dispatch update sourceMeat info', () => {
      sourceMeatResources.calcSourceMeat.mockImplementation((cutOrderIds, callback) => {
        return callback(meatsResponse);
      });

      const meatsResponse = {
        data: [
          {
            id: 1,
            targetProductCode: '0078889',
            targetProductDesc: 'PRIME CC TRUE BARREL FILET STK',
            productCode: '12345',
            productDesc: 'PRIME CC TRUE BARREL FILET STK',
            orderQuantity: 4,
            orderUm: 'C'
          }
        ]
      };

      calcSourceMeat([1, 2, 3])(dispatch);

      jestExpect(dispatch).toHaveBeenCalledTimes(1);
      jestExpect(dispatch).toHaveBeenNthCalledWith(1, {
        type: UPDATE_SOURCE_MEAT_INFO,
        payload: meatsResponse.data
      });
    });
  });

  describe('generateSourceMeatOrders', () => {
    test('should call generateSourceMeatOrders and dispatch RESET_SOURCE_MEAT_INFO', () => {
      const getState = () => {
        return {
          portionRoomsInfo: {
            currentPortionRoom: {
              code: 'A'
            }
          }
        };
      };

      sourceMeatResources.generateSourceMeatOrders.mockImplementation(
        (sourceMeatOrders, roomCode, responseCallback) => {
          return responseCallback(null);
        }
      );

      const request = [
        {
          cutOrderId: 1,
          targetProductCode: '0078889',
          targetProductDesc: 'PRIME CC TRUE BARREL FILET STK',
          productCode: '12345',
          productDesc: 'PRIME CC TRUE BARREL FILET STK',
          quantity: 4,
          unitOfMeasure: 'C'
        },
        {
          cutOrderId: 2,
          targetProductCode: '0078887',
          targetProductDesc: 'PRIME CC TRUE BARREL FILET STK',
          productCode: '12345',
          productDesc: 'PRIME CC TRUE BARREL FILET STK',
          quantity: 0,
          unitOfMeasure: 'C'
        }
      ];

      generateSourceMeatOrders(request)(dispatch, getState);

      jestExpect(dispatch).toHaveBeenNthCalledWith(1, {
        type: RESET_SOURCE_MEAT_INFO
      });
    });
  });

  describe('select and deselect cut order', () => {
    let testEvent = { fakeEvent: 'fakeEvent' };
    let testProductCode = '0001111';

    test('should toggle cut order selection for given cut order index', async () => {
      getCostByProductCode_promise.mockResolvedValue({ data: { mockCost: 'cost returned' } });

      await toggleCutOrderSelection(12, testProductCode, testEvent)(dispatch);

      jestExpect(showNoCostWarningModal).not.toHaveBeenCalled();
      jestExpect(dispatch).toHaveBeenCalledWith({
        type: CUT_ORDER_SELECTION_TOGGLED,
        payload: 12
      });
    });

    test('should not toggle selection when no cost exists', async () => {
      getCostByProductCode_promise.mockResolvedValue({ data: null });

      await toggleCutOrderSelection(12, testProductCode, testEvent)(dispatch);

      jestExpect(showNoCostWarningModal).toHaveBeenCalledWith([testProductCode], testEvent);
      jestExpect(dispatch).toHaveBeenCalledWith(showNoCostWarningModal());
    });

    test('should not toggle selection when cost is zero', async () => {
      getCostByProductCode_promise.mockResolvedValue({ data: { cost: 0 } });

      await toggleCutOrderSelection(12, testProductCode, testEvent)(dispatch);

      jestExpect(showNoCostWarningModal).toHaveBeenCalledWith([testProductCode], testEvent);
      jestExpect(dispatch).toHaveBeenCalledWith(showNoCostWarningModal());
    });
  });

  describe('select and deselect consolidated cut orders', () => {
    test('should toggle consolidated cut order selection for given cut order ids', async () => {
      getCostByProductCode_promise.mockResolvedValue({ data: { mockCost: 'cost returned' } });

      await toggleConsolidatedCutOrderSelection([12, 13, 14])(dispatch);

      jestExpect(dispatch).toHaveBeenNthCalledWith(1, {
        type: CONSOLIDATED_CUT_ORDERS_TOGGLED,
        payload: [12, 13, 14]
      });
    });

    test('should not toggle consolidated selection when no cost exists', async () => {
      getCostByProductCode_promise.mockResolvedValue({ data: null });

      await toggleConsolidatedCutOrderSelection([11, 15])(dispatch);

      jestExpect(dispatch).toHaveBeenNthCalledWith(1, showNoCostWarningModal());
    });

    test('should not toggle consolidated selection when cost is zero', async () => {
      getCostByProductCode_promise.mockResolvedValue({ data: { cost: 0 } });

      await toggleConsolidatedCutOrderSelection([7, 8, 9])(dispatch);

      jestExpect(dispatch).toHaveBeenNthCalledWith(1, showNoCostWarningModal());
    });
  });

  describe('getCutStationSummary()', () => {
    test('should call getCutStationSummary from cutStationSummaryResources and dispatch UPDATE_CUT_STATION_SUMMARY', () => {
      const cutStation = {
        name: 'JOHN',
        stationId: 21421402141,
        room: 'A',
        stationCode: 90,
        boxesToCutForCustomerOrders: []
      };

      let response = { data: [cutStation] };

      cutStationSummaryResources.getCutStationSummary.mockImplementation((roomCode, callback) => {
        return callback(response);
      });

      getCutStationSummary()(dispatch, getState);

      jestExpect(dispatch).toHaveBeenCalledWith({
        type: UPDATE_CUT_STATION_SUMMARY,
        payload: response.data
      });
    });
  });

  describe('getStation()', () => {
    test('should call get cut station api and dispatch RESET_CUT_STATION_INFO, UPDATE_CUT_STATION_INFO', () => {
      const cutStation = {
        name: 'JOHN',
        stationId: 21421402141,
        room: 'A',
        stationCode: 90
      };

      let response = { data: cutStation };

      cutStationResources.getStation.mockImplementation((stationId, callback) => {
        return callback(response);
      });

      getCutStation(cutStation.id)(dispatch);

      jestExpect(dispatch).toHaveBeenNthCalledWith(1, {
        type: RESET_CUT_STATION_INFO
      });

      jestExpect(dispatch).toHaveBeenNthCalledWith(2, {
        type: UPDATE_CUT_STATION_INFO,
        payload: response.data
      });
    });
  });
});
