export const STATIONS_FOR_ROOM_RECEIVED = '/reprint/getStationsForCurrentRoom';
export const BOXES_FOR_REPRINT_RECEIVED = 'BOXES_FOR_REPRINT_RECEIVED';
export const BOXES_FOR_REPRINT_CLEARED = 'BOXES_FOR_REPRINT_CLEARED';
export const STATIONS_FOR_REPRINT_CLEARED = '/reprint/clearReprintStations';
export const CUT_ORDERS_FOR_REPRINT_RECEIVED = '/reprint/getCutOrdersToPack';
export const CUT_ORDERS_FOR_REPRINT_CLEARED = 'CUT_ORDERS_FOR_REPRINT_CLEARED';
