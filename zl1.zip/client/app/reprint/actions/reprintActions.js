import stationResources from '../../shared/api/stationResources';
import {
  BOXES_FOR_REPRINT_CLEARED,
  BOXES_FOR_REPRINT_RECEIVED,
  CUT_ORDERS_FOR_REPRINT_CLEARED,
  CUT_ORDERS_FOR_REPRINT_RECEIVED,
  STATIONS_FOR_REPRINT_CLEARED,
  STATIONS_FOR_ROOM_RECEIVED
} from './reprintTypes';
import boxResources from '../../shared/api/boxResources';
import * as _ from 'lodash';
import cutOrdersResources from '../../shared/api/cutOrdersResources';
import { displayDateToIsoDate } from '../../shared/util/dateUtil';

export const receiveCutOrders = cutOrders => ({
  type: CUT_ORDERS_FOR_REPRINT_RECEIVED,
  payload: cutOrders
});

export const receiveBoxes = boxes => ({
  type: BOXES_FOR_REPRINT_RECEIVED,
  payload: boxes
});

export const receiveStations = stations => ({
  type: STATIONS_FOR_ROOM_RECEIVED,
  payload: stations
});

export const clearReprintBoxes = () => ({
  type: BOXES_FOR_REPRINT_CLEARED
});

export const clearReprintCutOrders = () => ({
  type: CUT_ORDERS_FOR_REPRINT_CLEARED
});

export const clearReprintStations = () => ({
  type: STATIONS_FOR_REPRINT_CLEARED
});

export const getStationByType = (stationType, roomCode) => dispatch => {
  return stationResources.getStationsByRoom(roomCode).then(
    response => {
      const allStations = response.data;
      const stationByType = _.filter(allStations, station => stationType === station.type);

      dispatch(receiveStations(stationByType));
    },
    () => {}
  );
};

export const getCutOrders = (date, productCode, susOrderNo, customerNo) => dispatch => {
  const isoDate = displayDateToIsoDate(date);
  return cutOrdersResources
    .getCutOrdersToPack(isoDate, productCode, susOrderNo, customerNo)
    .then(({ data }) => dispatch(receiveCutOrders(data)));
};

export const getBoxes = (date, productCode, susOrderNo) => dispatch => {
  const isoDate = displayDateToIsoDate(date);
  return boxResources
    .getBoxes(isoDate, productCode, susOrderNo)
    .then(({ data }) => dispatch(receiveBoxes(data)));
};

export const reprintLabelsForCurrentUser = (weightingId, type) => {
  boxResources
    .reprintLabelsForCurrentUser(weightingId, type)
    // eslint-disable-next-line no-console
    .catch(error => console.error(error));
};

export const reprintLabelsForStation = (weightingId, type, stationCode) => {
  boxResources
    .reprintLabelsForStation(weightingId, type, stationCode)
    // eslint-disable-next-line no-console
    .catch(error => console.error(error));
};

export const relabelPackoffLabel = (boxId, stationCode) => {
  boxResources
    .relabelPackoffLabel(boxId, stationCode)
    // eslint-disable-next-line no-console
    .catch(error => console.log(error));
};

export const reprintCutTicket = (cutOrderId, stationCode) => {
  cutOrdersResources
    .reprintCutTicket(cutOrderId, stationCode)
    // eslint-disable-next-line no-console
    .catch(error => console.log(error));
};
