import React from 'react';
import * as _ from 'lodash';
import { formatNumberToTwoDecimalPlacesString } from '../../shared/util/dataUtil';
import { toPrecision } from '../../shared/util/floatUtil';
import { Button, Table } from 'semantic-ui-react';
import { formatTime } from '../../shared/util/dateUtil';
import PropTypes from 'prop-types';
import { reprintLabelsForStation } from '../actions/reprintActions';

export function filterProductionOrders(boxes) {
  return boxes.filter(box => box.forProductionOrder);
}

export const ReprintRetailTableContent = ({ boxes, stationCode }) => (
  <Table.Body>
    {_.orderBy(filterProductionOrders(boxes), ['packTime'], ['desc']).map(box => {
      return _.orderBy(box.weighings, ['id'], ['desc']).map(weighing => {
        const netWeight = formatNumberToTwoDecimalPlacesString(
          toPrecision(weighing.weight - weighing.retailPieceTare, 2)
        );

        return (
          <Table.Row key={`reprint-boxes-table-row-${box.id}-weighing-${weighing.id}`}>
            <Table.Cell colSpan={3} width={3}>
              {formatTime(box.packTime)}
            </Table.Cell>
            <Table.Cell colSpan={1} width={1} textAlign={'right'}>
              {toPrecision(weighing.weight)}
            </Table.Cell>
            <Table.Cell colSpan={3} width={3} textAlign={'right'}>
              {toPrecision(weighing.retailPieceTare)}
            </Table.Cell>
            <Table.Cell colSpan={2} width={2} textAlign={'right'}>
              {toPrecision(netWeight)}
            </Table.Cell>
            <Table.Cell colSpan={3} width={3} textAlign={'right'}>
              {weighing.overrideWeightRangeReasonCode}
            </Table.Cell>
            <Table.Cell colSpan={4} width={4}>
              <Button
                className='reprint-button'
                primary
                onClick={() => reprintLabelsForStation(weighing.id, 'RETAIL', stationCode)}
                pid={`reprint-retail-table__reprint-${weighing.id}`}
              >
                REPRINT
              </Button>
            </Table.Cell>
          </Table.Row>
        );
      });
    })}
  </Table.Body>
);

ReprintRetailTableContent.propTypes = {
  boxes: PropTypes.arrayOf(
    PropTypes.shape({
      isFullBox: PropTypes.bool.isRequired,
      weighings: PropTypes.array,
      packTime: PropTypes.string,
      weight: PropTypes.number,
      packagingTare: PropTypes.number,
      netWeight: PropTypes.number,
      overrideWeightRangeReasonCode: PropTypes.number
    })
  ),
  stationCode: PropTypes.number.isRequired
};
