import React from 'react';
import PropTypes from 'prop-types';
import * as _ from 'lodash';
import { toPrecision } from '../../shared/util/floatUtil';
import { Button, Table } from 'semantic-ui-react';
import { reprintCutTicket } from '../actions/reprintActions';
import moment from 'moment/moment';

export const formatDeliveryDate = dateString => {
  return moment.utc(dateString, '', 'en').format('MM/DD/YY');
};

export const ReprintCutTicketTableContent = ({ cutOrders, stationCode }) => (
  <Table.Body>
    {_.orderBy(cutOrders, ['cutSelectedAt'], ['desc']).map(cutOrder => {
      return (
        <Table.Row key={`reprint-cut-order-table-row-${cutOrder.id}`}>
          <Table.Cell colSpan={3} width={3}>
            {cutOrder.cutSelectedAt}
          </Table.Cell>
          <Table.Cell colSpan={1} width={1} textAlign={'right'}>
            {toPrecision(cutOrder.qtyToProduce)}
          </Table.Cell>
          <Table.Cell colSpan={2} width={2} textAlign={'right'}>
            {cutOrder.customerOrder ? toPrecision(cutOrder.customerOrder.orderNumber) : ''}
          </Table.Cell>
          <Table.Cell colSpan={5} width={5} textAlign={'left'}>
            {cutOrder.customerOrder ? cutOrder.customerOrder.customer.name : ''}
          </Table.Cell>
          <Table.Cell colSpan={2} width={2} textAlign={'left'}>
            {formatDeliveryDate(cutOrder.deliveryDate)}
          </Table.Cell>
          <Table.Cell colSpan={3} width={3} textAlign={'center'}>
            <Button
              className='reprint-button'
              primary
              onClick={() => reprintCutTicket(cutOrder.id, stationCode)}
              pid={`reprint-cut-order-table__reprint-${cutOrder.id}`}
            >
              REPRINT
            </Button>
          </Table.Cell>
        </Table.Row>
      );
    })}
  </Table.Body>
);

ReprintCutTicketTableContent.propTypes = {
  cutOrders: PropTypes.arrayOf(PropTypes.object),
  stationCode: PropTypes.number.isRequired
};
