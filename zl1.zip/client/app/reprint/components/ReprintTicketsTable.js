import React from 'react';
import PropTypes from 'prop-types';
import { Table } from 'semantic-ui-react';
import * as _ from 'lodash';
import EmptyTableMessage from '../../shared/components/EmptyTableMessage';
import { ReprintCutTicketTableHeader } from './ReprintCutTicketTableHeader';
import { ReprintCutTicketTableContent } from './ReprintCutTicketTableContent';

const ReprintTicketsTable = ({ cutOrders, stationCode }) => {
  if (_.isNull(cutOrders)) {
    return null;
  }

  if (_.isEmpty(cutOrders)) {
    return (
      <div>
        <EmptyTableMessage message='Combination does not exist.' />
      </div>
    );
  }

  return (
    <div className='reprint-cut-ticket-table'>
      <Table size='small' columns={16}>
        <ReprintCutTicketTableHeader />
        <ReprintCutTicketTableContent cutOrders={cutOrders} stationCode={stationCode} />
      </Table>
    </div>
  );
};

ReprintTicketsTable.propTypes = {
  cutOrders: PropTypes.arrayOf(PropTypes.object),
  stationCode: PropTypes.number
};

export default ReprintTicketsTable;
