import { Table } from 'semantic-ui-react';
import React from 'react';

export const ReprintCutTicketTableHeader = () => (
  <Table.Header>
    <Table.Row>
      <Table.HeaderCell colSpan={3} width={3}>
        Cut Select Date
      </Table.HeaderCell>
      <Table.HeaderCell colSpan={1} width={1} textAlign={'right'}>
        QTY
      </Table.HeaderCell>
      <Table.HeaderCell colSpan={2} width={2} textAlign={'right'}>
        Order&nbsp;#
      </Table.HeaderCell>
      <Table.HeaderCell colSpan={5} width={5} textAlign={'left'}>
        Customer
      </Table.HeaderCell>
      <Table.HeaderCell colSpan={2} width={2} textAlign={'left'}>
        Ship&nbsp;Date
      </Table.HeaderCell>
      <Table.HeaderCell colSpan={3} width={3} />
    </Table.Row>
  </Table.Header>
);
