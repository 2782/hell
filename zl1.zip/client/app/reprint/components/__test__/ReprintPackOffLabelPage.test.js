import React from 'react';
import { createReduxStore } from '../../../store';
import { mount } from 'enzyme';
import { Provider } from 'react-redux';
import ReprintPackOffLabelPage, {
  asyncValidate,
  generateStationOptions
} from '../ReprintPackOffLabelPage';
import semanticUI from '../../../../test-helpers/semantic-ui';
import boxResources from '../../../shared/api/boxResources';
import stationResources from '../../../shared/api/stationResources';
import EmptyTableMessage from '../../../shared/components/EmptyTableMessage';
import productResources from '../../../shared/api/productResources';
import productFactory from '../../../../test-factories/productFactory';
import retailSpecificFactory from '../../../../test-factories/retailSpecificFactory';
import weighingFactory from '../../../../test-factories/weighingFactory';
import boxFactory from '../../../../test-factories/boxFactory';

jest.mock('../../../shared/api/stationResources');
jest.mock('../../../shared/api/productResources');
jest.mock('../../../shared/api/boxResources');

describe('ReprintPackOffLabel', () => {
  beforeEach(() => {
    boxResources.reprintLabelsForCurrentUser.mockResolvedValue({});
    boxResources.reprintLabelsForStation.mockResolvedValue({});
    boxResources.relabelPackoffLabel.mockResolvedValue({});
  });

  afterEach(() => {
    boxResources.getBoxes.mockReset();
  });

  let form;

  test('should show additional dropdown when product is retail', async () => {
    const product = productFactory.build({
      code: '0078889',
      retailSpecific: retailSpecificFactory.build({})
    });
    stationResources.getStationsByRoom.mockResolvedValue({});
    productResources.getProductInfoPromise.mockResolvedValue({ data: product });

    form = mount(
      <Provider store={createReduxStore({})}>
        <ReprintPackOffLabelPage shouldAsyncValidate={() => true} />
      </Provider>
    );

    semanticUI.changeInput(form, 'date', '09-09-2018');
    semanticUI.changeInput(form, 'productCode', '0078889');

    await waitForAsyncTasks(form);

    jestExpect(semanticUI.getDropDownSelectionOptionsText(form, 'labelType')).toEqual([
      'Packoff',
      'Retail'
    ]);
  });

  test('should render mapping fields', () => {
    form = mount(
      <Provider store={createReduxStore({})}>
        <ReprintPackOffLabelPage shouldAsyncValidate={() => false} />
      </Provider>
    );

    jestExpect(semanticUI.getInputValue(form, 'date')).toEqual('');
    jestExpect(semanticUI.getInputValue(form, 'productCode')).toEqual('');
    jestExpect(semanticUI.getInputValue(form, 'susOrderNo')).toEqual('');
    jestExpect(semanticUI.getSelectValue(form, 'stationCode')).toEqual(undefined);
  });

  test('should show invalid product message if entered product is invalid', async () => {
    productResources.getProductInfoPromise.mockRejectedValueOnce();

    form = mount(
      <Provider store={createReduxStore({})}>
        <ReprintPackOffLabelPage shouldAsyncValidate={() => false} />
      </Provider>
    );

    await waitForAsyncTasks(form);

    semanticUI.changeInput(form, 'date', '09-09-2018');
    semanticUI.changeInput(form, 'productCode', '4102218');

    await waitForAsyncTasks(form);

    jestExpect(semanticUI.findErrorLabels(form)).toHaveLength(1);
    jestExpect(semanticUI.findErrorLabels(form)).toHaveText('Invalid Item Number');
  });

  test('should display printed boxes when all fields are valid', async () => {
    const stationsResponse = [{ id: 123, type: 'PACKOFF', stationCode: 1, name: 'station name' }];
    stationResources.getStationsByRoom.mockResolvedValue({ data: stationsResponse });
    const boxes = [
      boxFactory.build({
        id: 1,
        packTime: '2018-09-20T15:40:00.787',
        weight: 12.0,
        packagingTare: 1.2,
        netWeight: 10.8,
        overrideWeightRangeReasonCode: 1,
        isFullBox: true,
        weighings: [weighingFactory.build({ type: 'BOX', id: 3 })]
      }),
      boxFactory.build({
        id: 2,
        packTime: '2018-09-21T09:40:00.787',
        weight: 3.0,
        packagingTare: 1.1,
        netWeight: 1.9,
        overrideWeightRangeReasonCode: 2,
        isFullBox: true,
        weighings: [weighingFactory.build({ type: 'BOX', id: 4 })]
      })
    ];
    boxResources.getBoxes.mockResolvedValue({ data: boxes });

    form = mount(
      <Provider store={createReduxStore({})}>
        <ReprintPackOffLabelPage shouldAsyncValidate={() => false} />
      </Provider>
    );

    await waitForAsyncTasks(form);

    semanticUI.changeInput(form, 'date', '09-09-2018');
    semanticUI.changeInput(form, 'productCode', '0078889');
    semanticUI.selectOption(form, 'stationCode', 0);
    form.find('form').simulate('submit');

    await waitForAsyncTasks(form);

    jestExpect(
      semanticUI
        .findTable(form, 0)
        .find('th')
        .at(0)
    ).toHaveText('PACK DATE/TIME');
    jestExpect(
      semanticUI
        .findTable(form, 0)
        .find('th')
        .at(1)
    ).toHaveText('WEIGHT');
    jestExpect(
      semanticUI
        .findTable(form, 0)
        .find('th')
        .at(2)
    ).toHaveText('PACKAGING TARE');
    jestExpect(
      semanticUI
        .findTable(form, 0)
        .find('th')
        .at(3)
    ).toHaveText('NET WEIGHT');
    jestExpect(
      semanticUI
        .findTable(form, 0)
        .find('th')
        .at(4)
    ).toHaveText('REASON CODE');

    const boxesTableBody = form.find('tbody').at(0);
    jestExpect(semanticUI.findTableColumnWithRowIndex(boxesTableBody, 0, 0)).toHaveText(
      '09/21 09:40 AM'
    );
    jestExpect(semanticUI.findTableColumnWithRowIndex(boxesTableBody, 0, 1)).toHaveText('3');
    jestExpect(semanticUI.findTableColumnWithRowIndex(boxesTableBody, 0, 2)).toHaveText('1.1');
    jestExpect(semanticUI.findTableColumnWithRowIndex(boxesTableBody, 0, 3)).toHaveText('1.9');
    jestExpect(semanticUI.findTableColumnWithRowIndex(boxesTableBody, 0, 4)).toHaveText('2');

    jestExpect(semanticUI.findTableColumnWithRowIndex(boxesTableBody, 1, 0)).toHaveText(
      '09/20 03:40 PM'
    );
    jestExpect(semanticUI.findTableColumnWithRowIndex(boxesTableBody, 1, 1)).toHaveText('12');
    jestExpect(semanticUI.findTableColumnWithRowIndex(boxesTableBody, 1, 2)).toHaveText('1.2');
    jestExpect(semanticUI.findTableColumnWithRowIndex(boxesTableBody, 1, 3)).toHaveText('10.8');
    jestExpect(semanticUI.findTableColumnWithRowIndex(boxesTableBody, 1, 4)).toHaveText('1');

    form
      .find('.reprint-button')
      .at(1)
      .simulate('click');
    jestExpect(boxResources.reprintLabelsForStation).toHaveBeenCalledWith(4, 'BOX', 1);
    jestExpect(boxResources.reprintLabelsForStation).toHaveBeenCalledTimes(1);

    form
      .find('.reprint-button')
      .at(3)
      .simulate('click');
    jestExpect(boxResources.reprintLabelsForStation).toHaveBeenCalledWith(3, 'BOX', 1);
    jestExpect(boxResources.reprintLabelsForStation).toHaveBeenCalledTimes(2);
  });

  test('should render null when boxes is null', async () => {
    const stations = [{ id: 123, type: 'PACKOFF', stationCode: 1, name: 'station name' }];
    stationResources.getStationsByRoom.mockResolvedValue({ data: stations });
    boxResources.getBoxes.mockResolvedValue({ data: null });

    form = mount(
      <Provider store={createReduxStore({})}>
        <ReprintPackOffLabelPage shouldAsyncValidate={() => false} />
      </Provider>
    );
    await waitForAsyncTasks(form);

    semanticUI.changeInput(form, 'date', '09-09-2018');
    semanticUI.changeInput(form, 'productCode', '0078889');
    semanticUI.selectOption(form, 'stationCode', 0);
    form.find('form').simulate('submit');

    await waitForAsyncTasks(form);

    jestExpect(semanticUI.findTables(form).length).toEqual(0);
  });

  test('should render empty table message when result is empty', async () => {
    const stationsResponse = [{ id: 123, type: 'PACKOFF', stationCode: 1, name: 'station name' }];
    stationResources.getStationsByRoom.mockResolvedValue({ data: stationsResponse });
    boxResources.getBoxes.mockResolvedValue({ data: [] });

    form = mount(
      <Provider store={createReduxStore({})}>
        <ReprintPackOffLabelPage shouldAsyncValidate={() => false} />
      </Provider>
    );

    await waitForAsyncTasks(form);

    semanticUI.changeInput(form, 'date', '09-09-2018');
    semanticUI.changeInput(form, 'productCode', '0078889');
    semanticUI.selectOption(form, 'stationCode', 0);
    form.find('form').simulate('submit');

    await waitForAsyncTasks(form);

    jestExpect(semanticUI.findTables(form).length).toEqual(0);
    jestExpect(form.find(EmptyTableMessage)).toExist();
  });

  describe('generateStationOptions', () => {
    test('should generate station options', () => {
      const stations = [
        { id: 123, type: 'PACKOFF', stationCode: 1, name: 'name 1' },
        { id: 234, type: 'PACKOFF', stationCode: 2, name: 'name 2' }
      ];
      const result = generateStationOptions(stations);

      jestExpect(result[0]).toEqual({ key: 0, text: '1 - name 1', value: 1 });
      jestExpect(result[1]).toEqual({ key: 1, text: '2 - name 2', value: 2 });
    });

    test('should return empty when stations are null', () => {
      const result = generateStationOptions(null);

      jestExpect(result).toEqual([]);
    });
  });

  describe('async validate for fetching product information', () => {
    test('it returns an error message to redux form if promise rejects', () => {
      const props = { getProductPromise: jest.fn().mockRejectedValue({}) };
      const dispatch = jest.fn();
      const productCode = 'PRODUCT_CODE';

      return asyncValidate({ productCode }, dispatch, props).then(result => {
        jestExpect(result).toEqual({ productCode: 'Invalid Item Number' });
      });
    });

    test('it returns an resolved promise when resource call returns resolved promise', () => {
      const success = { data: 'success' };
      const props = { getProductPromise: jest.fn().mockResolvedValue(success) };
      const dispatch = jest.fn();
      const productCode = 'PRODUCT_CODE';

      return asyncValidate({ productCode }, dispatch, props).then(result => {
        jestExpect(result).toEqual(success);
      });
    });
  });
});
