import React from 'react';
import PropTypes from 'prop-types';
import * as _ from 'lodash';
import { toPrecision } from '../../shared/util/floatUtil';
import { Button, Table } from 'semantic-ui-react';
import { formatTime } from '../../shared/util/dateUtil';
import { relabelPackoffLabel, reprintLabelsForStation } from '../actions/reprintActions';

export function getLatestWeighingId(box) {
  return box.weighings.reduce((greatestId, { id }) => {
    if (id > greatestId) {
      return id;
    }
    return greatestId;
  }, 0);
}

export const ReprintBoxesTableContent = ({ boxes, stationCode, isRetailProduct }) => (
  <Table.Body>
    {_.orderBy(boxes, ['packTime'], ['desc']).map(box => {
      const latestWeighingId = getLatestWeighingId(box);
      return (
        <Table.Row key={`reprint-boxes-table-row-${box.id}`}>
          <Table.Cell colSpan={3} width={3}>
            {formatTime(box.packTime)}
          </Table.Cell>
          <Table.Cell colSpan={1} width={1} textAlign={'right'}>
            {toPrecision(box.weight)}
          </Table.Cell>
          <Table.Cell colSpan={3} width={3} textAlign={'right'}>
            {toPrecision(box.packagingTare)}
          </Table.Cell>
          <Table.Cell colSpan={2} width={2} textAlign={'right'}>
            {toPrecision(box.netWeight)}
          </Table.Cell>
          <Table.Cell colSpan={3} width={3} textAlign={'right'}>
            {box.overrideWeightRangeReasonCode}
          </Table.Cell>
          <Table.Cell colSpan={4} width={4}>
            <Button
              className='reprint-button'
              primary
              onClick={() => reprintLabelsForStation(latestWeighingId, 'BOX', stationCode)}
              pid={`reprint-box-table__reprint-${latestWeighingId}`}
            >
              REPRINT
            </Button>
            {box.forProductionOrder && !isRetailProduct && (
              <Button
                className='relabel-button'
                primary
                onClick={() => relabelPackoffLabel(box.id, stationCode)}
                pid={`reprint-box-table__relabel-${box.id}`}
              >
                RELABEL
              </Button>
            )}
          </Table.Cell>
        </Table.Row>
      );
    })}
  </Table.Body>
);

ReprintBoxesTableContent.propTypes = {
  boxes: PropTypes.arrayOf(
    PropTypes.shape({
      isFullBox: PropTypes.bool.isRequired,
      weighings: PropTypes.array,
      packTime: PropTypes.string,
      weight: PropTypes.number,
      packagingTare: PropTypes.number,
      netWeight: PropTypes.number,
      overrideWeightRangeReasonCode: PropTypes.number
    })
  ),
  stationCode: PropTypes.number.isRequired,
  isRetailProduct: PropTypes.bool.isRequired
};
