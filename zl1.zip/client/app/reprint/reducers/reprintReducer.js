import {
  BOXES_FOR_REPRINT_CLEARED,
  BOXES_FOR_REPRINT_RECEIVED,
  CUT_ORDERS_FOR_REPRINT_CLEARED,
  CUT_ORDERS_FOR_REPRINT_RECEIVED,
  STATIONS_FOR_REPRINT_CLEARED,
  STATIONS_FOR_ROOM_RECEIVED
} from '../actions/reprintTypes';

const initState = {
  stations: null,
  boxes: null,
  cutOrders: null
};

export default (state = initState, action) => {
  switch (action.type) {
    case STATIONS_FOR_ROOM_RECEIVED: {
      return {
        ...state,
        stations: action.payload
      };
    }

    case CUT_ORDERS_FOR_REPRINT_RECEIVED: {
      return {
        ...state,
        cutOrders: action.payload
      };
    }

    case BOXES_FOR_REPRINT_RECEIVED: {
      return {
        ...state,
        boxes: action.payload
      };
    }

    case BOXES_FOR_REPRINT_CLEARED: {
      return {
        ...state,
        boxes: initState.boxes
      };
    }

    case CUT_ORDERS_FOR_REPRINT_CLEARED: {
      return {
        ...state,
        cutOrders: initState.cutOrders
      };
    }

    case STATIONS_FOR_REPRINT_CLEARED: {
      return {
        ...state,
        stations: initState.stations
      };
    }

    default:
      return state;
  }
};
