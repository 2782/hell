module.exports = api => {
  api.assertVersion('^7.3.0');

  let presets;

  if (api.env('test')) {
    presets = ['@babel/preset-env', '@babel/preset-react'];
  } else {
    presets = [['@babel/preset-env', { modules: false }], '@babel/preset-react'];
  }

  const plugins = [
    ['@babel/plugin-proposal-decorators', { legacy: true }],
    ['@babel/plugin-proposal-class-properties', { loose: true }],
    ['@babel/plugin-transform-runtime']
  ];

  return { presets, plugins };
};
