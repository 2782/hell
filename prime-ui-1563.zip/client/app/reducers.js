import { combineReducers } from 'redux';
import { routerReducer } from 'react-router-redux';
import errorReducer from './shared/errors/errorReducer';
import packOffStockReducer from './pack/reducers/packOffStockReducer';
import cutOrdersReducer from './cut/reducers/cutOrdersReducer';
import cutStationSummaryReducer from './cut/reducers/cutStationSummaryReducer';
import cutTablesReducer from './cut/reducers/cutTablesReducer';
import packWIPReducer from './pack/reducers/packWIPReducer';
import meatRequestReducer from './requestMeat/reducers/meatRequestReducer';
import operatingDatesReducer from './shared/reducers/operatingDatesReducer';
import orderToPackReducer from './pack/reducers/orderToPackReducer';
import packOrdersReducer from './pack/reducers/packOrdersReducer';
import packBoxFormReducer from './pack/reducers/packBoxFormReducer';
import packTableSummaryReducer from './pack/reducers/packTableSummaryReducer';
import portionRoomReducer from './landingPage/reducers/portionRoomReducer';
import uploadFileReducer from './uploadFile/uploadFileReducer';
import portionRoomTableReducer from './shared/reducers/portionRoomTableReducer';
import productSetupReducer from './productSetup/reducers/productSetupReducer';
import incompleteProductSetupReducer from './incompleteProductSetup/reducers/incompleteProductSetupReducer';
// TODO: We are duplicating to eventually replace the namespaced product
import productReducer from './shared/components/product/reducer';
import productDuplicateReducer from './shared/components/product/reducerDuplicate';

import settingsReducer from './settings/reducers/settingsReducer';
import sourceMeatReducer from './cut/reducers/sourceMeatReducer';
import orderOverviewReducer from './overview/reducers/orderOverviewReducer';
import stationReducer from './shared/reducers/stationReducer';
import cuttingYieldModelReducer from './createYieldModel/reducers/cuttingYieldModelReducer';
import grindingYieldModelReducer from './createYieldModel/reducers/grindingYieldModelReducer';
import yieldModelReducer from './createYieldModel/reducers/yieldModelReducer';
import searchYieldModelReducer from './searchYieldModel/reducers/searchYieldModelReducer';
import batchReducer from './batch/reducers/batchReducer';
import { reducer as formReducer } from 'redux-form';
import functionKeyReducer from './shared/functionKeys/reducer';
import headerAndFooterReducer from './shared/reducers/headerAndFooterReducer';
import productGroupReducer from './yieldModelProductGroup/reducers/productGroupReducer';
import tarePackagesReducer from './settings/reducers/tarePackagesReducer';
import grindOrdersReducer from './grind/reducers/grindOrdersReducer';
import confirmationModalReducer from './shared/reducers/confirmationModalReducer';
import productSearchReducer from './productSearch/reducers/productSearchReducer';
import reportsReducer from './reports/reducers/reportsReducer';
import loginReducer from './shared/loginReducer';
import searchBatchesReducer from './batch/reducers/searchBatchesReducer';
import productActivityReducer from './productActivity/reducers/productActivityReducer';
import productActivityDetailReducer from './productActivity/reducers/productActivityDetailReducer';
import reprintReducer from './reprint/reducers/reprintReducer';
import yieldTestReducer from './yieldTest/reducers/yieldTestReducer';
import yieldModelChangelogReducer from './yieldModelChangelog/reducers/yieldModelChangelogReducer';
import yieldModelReportingEventReducer from './yieldModelChangelog/reducers/yieldModelReportingEventReducer';

export default combineReducers({
  router: routerReducer,
  form: formReducer,
  login: loginReducer,
  function: functionKeyReducer,
  errorReducer: errorReducer,
  cutTablesInfo: cutTablesReducer,
  cutOrdersInfo: cutOrdersReducer,
  grindOrdersInfo: grindOrdersReducer,
  packOrdersInfo: packOrdersReducer,
  orderToPackInfo: orderToPackReducer,
  packTableSummary: packTableSummaryReducer,
  portionRoomTableInfo: portionRoomTableReducer,
  cutStationSummary: cutStationSummaryReducer,
  portionRoomsInfo: portionRoomReducer,
  uploadFileReducer: uploadFileReducer,
  operatingDates: operatingDatesReducer,
  sourceMeatInfo: sourceMeatReducer,
  packedOffStockInfo: packOffStockReducer,
  packWIPReducer: packWIPReducer,
  packBoxForm: packBoxFormReducer,
  product: productReducer,
  productDuplicate: productDuplicateReducer,
  productActivity: productActivityReducer,
  productActivityDetail: productActivityDetailReducer,
  settingsInfo: settingsReducer,
  meatRequestInfo: meatRequestReducer,
  cutOrderOverview: orderOverviewReducer,
  stationInfo: stationReducer,
  yieldModelInfo: yieldModelReducer,
  cuttingYieldModelInfo: cuttingYieldModelReducer,
  grindingYieldModelInfo: grindingYieldModelReducer,
  yieldModelChangelog: yieldModelChangelogReducer,
  productGroup: productGroupReducer,
  batches: combineReducers({
    info: batchReducer,
    search: searchBatchesReducer
  }),
  searchYieldModels: searchYieldModelReducer,
  headerAndFooter: headerAndFooterReducer,
  tarePackages: tarePackagesReducer,
  incompleteProductSetup: incompleteProductSetupReducer,
  productsInfo: productSearchReducer,
  confirmationModal: confirmationModalReducer,
  productSetup: productSetupReducer,
  reportsInfo: reportsReducer,
  reprintInfo: reprintReducer,
  yieldTestInfo: yieldTestReducer,
  yieldModelReportingEvent: yieldModelReportingEventReducer
});
