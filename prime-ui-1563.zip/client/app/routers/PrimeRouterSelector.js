import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import CostingPrimeRouter from './CostingPrimeRouter';
import PrimeRouter from './PrimeRouter';
import { bindActionCreators } from 'redux';
import { getPrimeUserDetails } from '../shared/actions/actions';

export class PrimeRouterSelectorComponent extends React.Component {
  componentDidMount() {
    this.props.getPrimeUserDetails();
  }

  render() {
    const { role } = this.props;
    switch (role) {
      case 'ROLE_COSTING':
        return <CostingPrimeRouter />;
      case 'ROLE_ADMIN':
      case 'ROLE_PORTION_ROOM_MEMBER':
        return <PrimeRouter />;
      default:
        return null;
    }
  }
}

const mapDispatchToProps = dispatch =>
  bindActionCreators(
    {
      getPrimeUserDetails
    },
    dispatch
  );

const mapStateToProps = state => ({
  role: state.login.role
});

PrimeRouterSelectorComponent.propTypes = {
  role: PropTypes.string,
  getPrimeUserDetails: PropTypes.func
};

const PrimeRouterSelector = connect(
  mapStateToProps,
  mapDispatchToProps
)(PrimeRouterSelectorComponent);

export default PrimeRouterSelector;
