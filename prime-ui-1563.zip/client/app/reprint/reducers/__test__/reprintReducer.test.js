import reprintReducer from '../reprintReducer';

import StationFactory from '../../../../test-factories/station';
import {
  clearReprintBoxes,
  clearReprintCutOrders,
  clearReprintStations,
  receiveBoxes,
  receiveStations
} from '../../actions/reprintActions';

describe('reprintReducer', () => {
  let initState;

  const station1 = StationFactory.build({
    id: 2,
    portionRoomTables: [13],
    name: 'PEDRO',
    room: 'A'
  });

  const station2 = StationFactory.build({
    id: 1,
    portionRoomTables: [6, 7],
    name: 'ENRIQUE',
    room: 'A'
  });

  beforeEach(() => {
    initState = {
      stations: null,
      boxes: null,
      cutOrders: null
    };
  });

  test('should return initState when handle unexpect action', () => {
    let unexpectAction = { type: 'unexpect' };

    jestExpect(reprintReducer(undefined, unexpectAction)).toEqual(initState);
  });

  test('should return stations when getting stations for portion room', () => {
    const stations = [station1, station2];
    const result = { ...initState, stations: stations };

    jestExpect(reprintReducer(initState, receiveStations(stations))).toEqual(result);
  });

  test('should clear reprint boxes', () => {
    const state = {
      stations: [StationFactory],
      boxes: ['something']
    };

    const result = reprintReducer(state, clearReprintBoxes());

    jestExpect(result).toEqual({ ...state, boxes: null });
  });

  test('should clear reprint cutOrders', () => {
    const state = {
      stations: [StationFactory],
      cutOrders: ['something']
    };

    const result = reprintReducer(state, clearReprintCutOrders());

    jestExpect(result).toEqual({ ...state, cutOrders: null });
  });

  test('should return boxes when getting boxes', () => {
    const boxes = [
      {
        id: 1,
        packTime: '2018-09-09',
        weight: 12.0,
        packagingTare: 1.2,
        netWeight: 10.8,
        reasonCode: 1
      }
    ];
    const result = { ...initState, boxes: boxes };

    jestExpect(reprintReducer(initState, receiveBoxes(boxes))).toEqual(result);
  });

  test('should clear stations', () => {
    const state = { stations: ['1', '2', '3'], boxes: ['4', '5', '6'] };

    jestExpect(reprintReducer(state, clearReprintStations())).toEqual({
      ...state,
      stations: null
    });
  });
});
