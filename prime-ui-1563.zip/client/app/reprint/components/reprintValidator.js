import {
  maxLength,
  required,
  validate,
  validateDate,
  wholeNumber,
  positiveNumber
} from '../../shared/formValidations';
import { SubmissionError } from 'redux-form';
import _ from 'lodash';
import { DEFAULT_DISPLAY_DATE_FORMAT } from '../../shared/util/dateUtil';

export const validateSubmission = (values, isRetailProduct) => {
  const { date, susOrderNo, stationCode, productCode, labelType } = values;
  let errors = {};

  errors = validate(errors, date, 'date', [required, validateDate(DEFAULT_DISPLAY_DATE_FORMAT)]);
  errors = validate(errors, susOrderNo, 'susOrderNo', [maxLength(5), wholeNumber, positiveNumber]);
  errors = validate(errors, stationCode, 'stationCode', [required]);
  errors = validate(errors, productCode, 'productCode', [required]);

  if (isRetailProduct) {
    errors = validate(errors, labelType, 'labelType', [required]);
  }

  if (!_.isEmpty(errors)) {
    throw new SubmissionError({ _error: 'Submission Failed!', ...errors });
  }
};
