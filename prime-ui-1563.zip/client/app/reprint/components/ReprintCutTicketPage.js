import React from 'react';

import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import { bindActionCreators } from 'redux';
import { setHeaderAndFooter } from '../../shared/actions/actions';
import { Field, formValueSelector, reduxForm } from 'redux-form';
import { REPRINT_CUT_TICKET } from '../../shared/components/pageTitles';
import { ENTER_F4_F2 } from '../../shared/components/pageFooters';
import ProductDuplicate from '../../shared/components/product/ProductDuplicate';
import { normalizeProductCode } from '../../shared/components/product/normalizer';
import { Button, Divider, Form, Grid } from 'semantic-ui-react';
import FormElement from '../../shared/FormElement';
import FormDayPickerInput from '../../shared/FormDayPickerInput';
import {
  clearReprintCutOrders,
  clearReprintStations,
  getCutOrders,
  getStationByType
} from '../actions/reprintActions';
import * as _ from 'lodash';
import {
  getProductPromise,
  setProductExistTo
} from '../../shared/components/product/actionsDuplicate';
import { validateSubmission } from './reprintValidator';
import ReprintTicketsTable from './ReprintTicketsTable';
import { NOT_A_CUSTOMER_CODE, NOT_A_PRODUCT_CODE } from '../../../config/errorMessage';
import { getCustomer } from '../../settings/actions/settingsActions';
import { DEFAULT_DISPLAY_DATE_FORMAT } from '../../shared/util/dateUtil';

class ReprintCutTicket extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      stationCode: null
    };
    this.submit = this.submit.bind(this);
    this.handleChange = this.handleChange.bind(this);
  }

  componentDidMount() {
    const { setHeaderAndFooter, currentPortionRoomCode, getStationByType } = this.props;

    setHeaderAndFooter({
      header: REPRINT_CUT_TICKET,
      footer: ENTER_F4_F2
    });

    getStationByType('PRODUCTION', currentPortionRoomCode);
  }

  componentDidUpdate(prevProps) {
    const { currentProduct, reset } = this.props;
    const productCodeChanged =
      !_.isEmpty(prevProps.currentProduct) &&
      (!currentProduct || currentProduct.code !== prevProps.currentProduct.code);

    if (productCodeChanged) {
      reset();
    }
  }

  componentWillUnmount() {
    const { clearReprintCutOrders, clearReprintStations } = this.props;
    clearReprintCutOrders();
    clearReprintStations();
  }

  submit(values) {
    const { getCutOrders } = this.props;
    const { date, productCode, susOrderNo, customerNo } = values;

    validateSubmission(values, false);

    return getCutOrders(date, productCode, susOrderNo, customerNo);
  }

  selectStation(event, input) {
    this.setState({ ...this.state, stationCode: input });
  }

  handleOnBlur(event, productCode) {
    const { getProductPromise, setProductExistTo } = this.props;

    if (!_.isEmpty(productCode)) {
      getProductPromise(productCode, () => setProductExistTo(productCode, false));
    }
  }

  handleChange(event, productCode) {
    const { setProductExistTo } = this.props;
    if (!_.isEmpty(productCode)) {
      setProductExistTo(productCode, true);
    }
  }

  render() {
    const {
      currentProduct,
      stations,
      currentProductFormValue,
      productsExist,
      handleSubmit,
      cutOrders,
      pristine,
      submitting
    } = this.props;

    return (
      <div>
        <Form size={'large'} onSubmit={handleSubmit(this.submit)}>
          <Grid>
            <Grid.Row>
              <Grid.Column width={4}>
                <Field
                  component={FormDayPickerInput}
                  className='reprint-date-pick-up'
                  name='date'
                  autoFocus
                  as={Form.Input}
                  label='Cut Selection Date'
                  formatString={DEFAULT_DISPLAY_DATE_FORMAT}
                  placeholder={DEFAULT_DISPLAY_DATE_FORMAT}
                  dayPickerProps={{
                    showOutsideDays: true,
                    disabledDays: [{ after: new Date() }]
                  }}
                />
              </Grid.Column>
              <Grid.Column width={11}>
                <Field
                  component={ProductDuplicate}
                  product={currentProduct}
                  name='productCode'
                  maxLength={7}
                  label='Product #'
                  normalize={normalizeProductCode}
                  useDotDotDot={false}
                  descriptionFontSize={'18px'}
                  message={
                    _.get(productsExist, currentProductFormValue, true) ? null : NOT_A_PRODUCT_CODE
                  }
                  onBlur={(event, value) => this.handleOnBlur(event, value)}
                  onChange={this.handleChange}
                />
              </Grid.Column>
            </Grid.Row>
          </Grid>

          <Divider hidden />

          <Form.Group>
            <Field
              component={FormElement}
              name='susOrderNo'
              as={Form.Input}
              type='text'
              label='Sales Order #'
              width={4}
            />
            <Field
              component={FormElement}
              name='customerNo'
              as={Form.Input}
              type='text'
              label='Customer #'
              width={4}
            />
            <Field
              component={FormElement}
              name='stationCode'
              className='station-code-drop-down'
              as={Form.Select}
              options={generateStationOptions(stations)}
              type='text'
              label='Print Location'
              onChange={this.selectStation.bind(this)}
              width={4}
            />
          </Form.Group>

          <Divider hidden />

          <Button size={'large'} loading={submitting} disabled={submitting || pristine} primary>
            Search
          </Button>
        </Form>

        <Divider hidden />

        <ReprintTicketsTable cutOrders={cutOrders} stationCode={this.state.stationCode} />
      </div>
    );
  }
}

export const generateStationOptions = stations => {
  return (stations || []).map(({ stationCode, name }, index) => {
    return { key: index, text: `${stationCode} - ${name}`, value: stationCode };
  });
};

ReprintCutTicket.propTypes = {
  currentPortionRoomCode: PropTypes.string,
  stations: PropTypes.array,
  setHeaderAndFooter: PropTypes.func,
  getStationByType: PropTypes.func,
  handleSubmit: PropTypes.func,
  form: PropTypes.string,
  pristine: PropTypes.bool,
  submitting: PropTypes.bool,
  reset: PropTypes.func,
  currentProduct: PropTypes.object,
  getProductPromise: PropTypes.func,
  getCutOrders: PropTypes.func,
  cutOrders: PropTypes.array,
  clearReprintCutOrders: PropTypes.func,
  clearReprintStations: PropTypes.func,
  productsExist: PropTypes.object,
  setProductExistTo: PropTypes.func,
  currentProductFormValue: PropTypes.string,
  getCustomer: PropTypes.func.isRequired
};

const REPRINT_CUT_TICKET_FORM = 'ReprintCutTicketPage';
const selector = formValueSelector(REPRINT_CUT_TICKET_FORM);

const mapStateToProps = state => {
  const currentFormProductNumber = selector(state, 'productCode');
  const currentProduct = state.productDuplicate.products[currentFormProductNumber] || {};
  const productsExist = state.productDuplicate.productsExist || {};
  const currentProductFormValue = selector(state, 'productCode');

  return {
    currentPortionRoomCode: state.portionRoomsInfo.currentPortionRoom.code,
    stations: state.reprintInfo.stations,
    cutOrders: state.reprintInfo.cutOrders,
    currentProduct,
    productsExist,
    currentProductFormValue
  };
};

export const asyncValidate = ({ customerNo }, dispatch, props) => {
  if (!_.isEmpty(customerNo)) {
    return props.getCustomer(customerNo).catch(() => {
      return { customerNo: NOT_A_CUSTOMER_CODE };
    });
  }
  return Promise.resolve();
};

const mapDispatchToProps = dispatch =>
  bindActionCreators(
    {
      setHeaderAndFooter,
      getStationByType,
      getProductPromise,
      setProductExistTo,
      getCutOrders,
      clearReprintCutOrders,
      clearReprintStations,
      getCustomer
    },
    dispatch
  );

const ReprintCutTicketPage = connect(
  mapStateToProps,
  mapDispatchToProps
)(
  reduxForm({
    form: REPRINT_CUT_TICKET_FORM,
    asyncValidate,
    asyncBlurFields: ['customerNo']
  })(ReprintCutTicket)
);

export default ReprintCutTicketPage;
