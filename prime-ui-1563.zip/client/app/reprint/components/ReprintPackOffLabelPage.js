import React from 'react';

import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import { bindActionCreators } from 'redux';
import { setHeaderAndFooter } from '../../shared/actions/actions';
import { Field, formValueSelector, reduxForm } from 'redux-form';
import { REPRINT } from '../../shared/components/pageTitles';
import { ENTER_F4_F2 } from '../../shared/components/pageFooters';
import { Button, Divider, Form, Grid } from 'semantic-ui-react';
import FormDayPickerInput from '../../shared/FormDayPickerInput';
import { normalizeProductCode } from '../../shared/components/product/normalizer';
import FormElement from '../../shared/FormElement';
import {
  clearReprintBoxes,
  clearReprintStations,
  getBoxes,
  getStationByType
} from '../actions/reprintActions';
import * as _ from 'lodash';
import { validateSubmission } from './reprintValidator';
import ReprintBoxesTable, { VARIANT } from './ReprintBoxesTable';
import ProductDuplicate from '../../shared/components/product/ProductDuplicate';
import {
  getProductPromise,
  setProductExistTo
} from '../../shared/components/product/actionsDuplicate';
import { NOT_A_PRODUCT_CODE } from '../../../config/errorMessage';
import { DEFAULT_DISPLAY_DATE_FORMAT } from '../../shared/util/dateUtil';

class ReprintPackOffLabel extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      stationCode: null
    };
    this.handleChange = this.handleChange.bind(this);
    this.handleOnBlur = this.handleOnBlur.bind(this);
  }

  componentDidMount() {
    const { setHeaderAndFooter, currentPortionRoomCode, getStationByType } = this.props;

    setHeaderAndFooter({
      header: REPRINT,
      footer: ENTER_F4_F2
    });

    getStationByType('PACKOFF', currentPortionRoomCode);
  }

  componentDidUpdate(prevProps) {
    const { currentProduct, clearReprintBoxes, reset } = this.props;
    const productCodeChanged =
      !_.isEmpty(prevProps.currentProduct) &&
      (!currentProduct || currentProduct.code !== prevProps.currentProduct.code);

    if (productCodeChanged) {
      clearReprintBoxes();
      reset();
    }
  }

  componentWillUnmount() {
    const { clearReprintBoxes, clearReprintStations } = this.props;
    clearReprintBoxes();
    clearReprintStations();
  }

  submit(values) {
    const { getBoxes, isRetailProduct } = this.props;
    const { date, productCode, susOrderNo } = values;

    validateSubmission(values, isRetailProduct);

    return getBoxes(date, productCode, susOrderNo);
  }

  selectStation(event, input) {
    this.setState({ ...this.state, stationCode: input });
  }

  handleOnBlur(event, productCode) {
    const { getProductPromise, setProductExistTo } = this.props;

    if (!_.isEmpty(productCode)) {
      getProductPromise(productCode, () => setProductExistTo(productCode, false));
    }
  }

  handleChange(event, productCode) {
    const { setProductExistTo } = this.props;
    if (!_.isEmpty(productCode)) {
      setProductExistTo(productCode, true);
    }
  }

  render() {
    const {
      boxes,
      handleSubmit,
      currentProduct,
      currentProductFormValue,
      productsExist,
      stations,
      pristine,
      submitting,
      isRetailProduct
    } = this.props;

    return (
      <div>
        <Form size={'large'} onSubmit={handleSubmit(this.submit.bind(this))}>
          <Grid>
            <Grid.Row>
              <Grid.Column width={4}>
                <Field
                  component={FormDayPickerInput}
                  className='reprint-date-pick-up'
                  name='date'
                  autoFocus
                  as={Form.Input}
                  label='Date'
                  formatString={DEFAULT_DISPLAY_DATE_FORMAT}
                  placeholder={DEFAULT_DISPLAY_DATE_FORMAT}
                  dayPickerProps={{
                    showOutsideDays: true,
                    disabledDays: [{ after: new Date() }]
                  }}
                />
              </Grid.Column>
              <Grid.Column width={11}>
                <Field
                  component={ProductDuplicate}
                  product={currentProduct}
                  name='productCode'
                  label='Product #'
                  normalize={normalizeProductCode}
                  useDotDotDot={false}
                  descriptionFontSize={'18px'}
                  message={
                    _.get(productsExist, currentProductFormValue, true) ? null : NOT_A_PRODUCT_CODE
                  }
                  onBlur={(event, value) => this.handleOnBlur(event, value)}
                  onChange={this.handleChange}
                />
              </Grid.Column>
            </Grid.Row>
          </Grid>

          <Divider hidden />

          <Form.Group>
            <Field
              component={FormElement}
              name='susOrderNo'
              as={Form.Input}
              type='text'
              label='Sales Order #'
              width={4}
            />
            <Field
              component={FormElement}
              name='stationCode'
              className='station-code-drop-down'
              as={Form.Select}
              options={generateStationOptions(stations)}
              type='text'
              label='Print Location'
              onChange={this.selectStation.bind(this)}
              width={4}
            />
            <Form.Field width={1} />
            {isRetailProduct && (
              <Field
                component={FormElement}
                name='labelType'
                as={Form.Select}
                options={[
                  { key: 0, text: 'Packoff', value: VARIANT.PACKOFF },
                  { key: 1, text: 'Retail', value: VARIANT.RETAIL }
                ]}
                type='text'
                label='Label Type'
                width={4}
              />
            )}
          </Form.Group>

          <Divider hidden />

          <Button size={'large'} loading={submitting} disabled={submitting || pristine} primary>
            Search
          </Button>
        </Form>

        <Divider hidden />

        <ReprintBoxesTable
          boxes={boxes}
          stationCode={this.state.stationCode}
          variant={this.props.currentTableVariant}
          isRetailProduct={isRetailProduct}
        />
      </div>
    );
  }
}

export const generateStationOptions = stations => {
  return (stations || []).map(({ stationCode, name }, index) => {
    return { key: index, text: `${stationCode} - ${name}`, value: stationCode };
  });
};

ReprintPackOffLabel.propTypes = {
  currentPortionRoomCode: PropTypes.string,
  stations: PropTypes.array,
  boxes: PropTypes.array,
  getBoxes: PropTypes.func,
  clearReprint: PropTypes.func,
  setHeaderAndFooter: PropTypes.func,
  getStationByType: PropTypes.func,
  handleSubmit: PropTypes.func,
  form: PropTypes.string,
  pristine: PropTypes.bool,
  submitting: PropTypes.bool,
  currentProduct: PropTypes.object,
  isRetailProduct: PropTypes.bool,
  currentTableVariant: PropTypes.oneOf([VARIANT.PACKOFF, VARIANT.RETAIL]),
  clearReprintBoxes: PropTypes.func,
  reset: PropTypes.func,
  setProductExistTo: PropTypes.func,
  productsExist: PropTypes.object,
  getProductPromise: PropTypes.func,
  currentProductFormValue: PropTypes.string,
  clearReprintStations: PropTypes.func
};

ReprintPackOffLabel.defaultProps = {
  currentTableVariant: VARIANT.PACKOFF
};

const REPRINT_LABEL_FORM = 'ReprintForm';
const selector = formValueSelector(REPRINT_LABEL_FORM);

const mapStateToProps = state => {
  const currentFormProductNumber = selector(state, 'productCode');
  const currentProduct = state.productDuplicate.products[currentFormProductNumber] || {};
  const isRetailProduct = !_.isEmpty(_.get(currentProduct, 'retailSpecific', {}));
  const productsExist = state.productDuplicate.productsExist || {};
  const currentProductFormValue = selector(state, 'productCode');
  const currentTableVariant =
    isRetailProduct && selector(state, 'labelType') === VARIANT.RETAIL
      ? VARIANT.RETAIL
      : VARIANT.PACKOFF;

  return {
    currentPortionRoomCode: state.portionRoomsInfo.currentPortionRoom.code,
    stations: state.reprintInfo.stations,
    boxes: state.reprintInfo.boxes,
    currentProduct,
    isRetailProduct,
    productsExist,
    currentProductFormValue,
    currentTableVariant
  };
};

export const asyncValidate = ({ productCode }, dispatch, props) => {
  if (!_.isEmpty(productCode)) {
    return props.getProductPromise(productCode).catch(() => {
      return { productCode: 'Invalid Item Number' };
    });
  }
  return Promise.resolve();
};

const mapDispatchToProps = dispatch =>
  bindActionCreators(
    {
      setHeaderAndFooter,
      getStationByType,
      getBoxes,
      getProductPromise,
      setProductExistTo,
      clearReprintBoxes,
      clearReprintStations
    },
    dispatch
  );

const ReprintPackOffLabelPage = connect(
  mapStateToProps,
  mapDispatchToProps
)(
  reduxForm({
    form: REPRINT_LABEL_FORM,
    asyncValidate,
    asyncBlurFields: ['productCode']
  })(ReprintPackOffLabel)
);

export default ReprintPackOffLabelPage;
