import React from 'react';
import PropTypes from 'prop-types';
import { Table } from 'semantic-ui-react';
import * as _ from 'lodash';
import EmptyTableMessage from '../../shared/components/EmptyTableMessage';
import { ReprintBoxesTableHeader } from './ReprintBoxesTableHeader';
import { ReprintRetailTableContent } from './ReprintRetailTableContent';
import { ReprintBoxesTableContent } from './ReprintBoxesTableContent';

export const VARIANT = {
  RETAIL: 'RETAIL',
  PACKOFF: 'PACKOFF'
};

const ReprintBoxesTable = ({ boxes, stationCode, isRetailProduct, variant }) => {
  const isRetailView = variant === VARIANT.RETAIL;

  if (_.isNull(boxes)) {
    return null;
  }

  const boxesToRender = isRetailView
    ? boxes
    : !_.isEmpty(boxes) && boxes.filter(box => box.isFullBox);

  if (_.isEmpty(boxesToRender)) {
    return (
      <div>
        <EmptyTableMessage message='Combination does not exist.' />
      </div>
    );
  }

  return (
    <div className='reprint-boxes-table'>
      <Table size='small' columns={16}>
        <ReprintBoxesTableHeader />
        {isRetailView ? (
          <ReprintRetailTableContent boxes={boxesToRender} stationCode={stationCode} />
        ) : (
          <ReprintBoxesTableContent
            boxes={boxesToRender}
            stationCode={stationCode}
            isRetailProduct={isRetailProduct}
          />
        )}
      </Table>
    </div>
  );
};

ReprintBoxesTable.propTypes = {
  boxes: PropTypes.arrayOf(
    PropTypes.shape({
      isFullBox: PropTypes.bool.isRequired,
      weighings: PropTypes.array,
      packTime: PropTypes.string,
      weight: PropTypes.number,
      packagingTare: PropTypes.number,
      netWeight: PropTypes.number,
      overrideWeightRangeReasonCode: PropTypes.number
    })
  ),
  stationCode: PropTypes.number,
  variant: PropTypes.oneOf([VARIANT.PACKOFF, VARIANT.RETAIL]).isRequired,
  isRetailProduct: PropTypes.bool.isRequired
};

export default ReprintBoxesTable;
