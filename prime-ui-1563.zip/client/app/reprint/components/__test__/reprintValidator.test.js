import { validateSubmission } from '../reprintValidator';

describe('reprint validator', () => {
  test('should verify that date is required', () => {
    const values = {};

    try {
      validateSubmission(values, false);
    } catch ({ errors }) {
      jestExpect(errors.date).toEqual('Required');
      jestExpect(errors.stationCode).toEqual('Required');
      jestExpect(errors.productCode).toEqual('Required');
    }
  });

  test('should verify that date format is valid', () => {
    const values = {
      date: 'wrong format'
    };

    try {
      validateSubmission(values, false);
    } catch ({ errors }) {
      jestExpect(errors.date).toEqual('Invalid date format');
    }
  });

  test('should verify that susOrderNo length is less than 5 (more than 5 case)', () => {
    const values = {
      susOrderNo: '123456'
    };

    try {
      validateSubmission(values, false);
    } catch ({ errors }) {
      jestExpect(errors.susOrderNo).toEqual('Maximum 5 characters');
    }
  });

  test('should verify that susOrderNo is whole number', () => {
    const values = {
      susOrderNo: '12s34'
    };

    try {
      validateSubmission(values, false);
    } catch ({ errors }) {
      jestExpect(errors.susOrderNo).toEqual('Only whole number characters');
    }
  });

  test('valid case for non retail product', () => {
    const values = {
      date: '04-22-2019',
      susOrderNo: '12345',
      stationCode: 91,
      productCode: '4102218'
    };
    validateSubmission(values, false);
  });

  test('valid case for retail product', () => {
    const values = {
      date: '04-22-2019',
      susOrderNo: '12345',
      stationCode: 91,
      productCode: '4102218'
    };
    validateSubmission(values, false);
  });

  test('label type is required for retail product', () => {
    const values = {
      date: '04-22-2019',
      susOrderNo: '12345',
      stationCode: 91,
      productCode: '4102218'
    };

    try {
      validateSubmission(values, true);
      fail('should have failed');
    } catch ({ errors }) {
      jestExpect(errors.labelType).toEqual('Required');
    }
  });
});
