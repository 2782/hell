import React from 'react';
import { createReduxStore } from '../../../store';
import { mount } from 'enzyme';
import { Provider } from 'react-redux';
import semanticUI from '../../../../test-helpers/semantic-ui';
import stationResources from '../../../shared/api/stationResources';
import EmptyTableMessage from '../../../shared/components/EmptyTableMessage';
import productFactory from '../../../../test-factories/productFactory';
import retailSpecificFactory from '../../../../test-factories/retailSpecificFactory';
import cutOrdersResources from '../../../shared/api/cutOrdersResources';
import ReprintCutTicketPage, { asyncValidate } from '../ReprintCutTicketPage';
import CustomerOrderFactory from '../../../../test-factories/customerOrder';
import PortionSizeFactory from '../../../../test-factories/portionSize';
import customerFactory from '../../../../test-factories/customerFactory';
import cutOrderFactory from '../../../../test-factories/cutOrder';
import moment from 'moment/moment';
import productResources from '../../../shared/api/productResources';
import settingsResources from '../../../shared/api/settingsResources';

jest.mock('../../../shared/api/stationResources');
jest.mock('../../../shared/api/productResources');
jest.mock('../../../shared/api/cutOrdersResources');
jest.mock('../../../shared/api/settingsResources');

describe('ReprintCutTicket', () => {
  beforeEach(() => {
    const product = productFactory.build({
      code: '0078889'
    });

    cutOrdersResources.getCutOrdersToPack.mockResolvedValue({});
    stationResources.getStationsByRoom.mockResolvedValue({});
    cutOrdersResources.reprintCutTicket.mockResolvedValue({});
    productResources.getProductInfoPromise.mockResolvedValue({ data: product });
    settingsResources.getCustomer.mockResolvedValue({
      data: customerFactory.build({ name: 'Test Customer Name' })
    });
  });

  afterEach(() => {
    cutOrdersResources.getCutOrdersToPack.mockReset();
    stationResources.getStationsByRoom.mockReset();
  });

  let form;

  test('should returns error to redux form when customer does not exist', async () => {
    const getCustomer = jest.fn();
    getCustomer.mockRejectedValue({});

    const values = { customerNo: '123232' };
    const dispatch = jest.fn();

    const errors = await asyncValidate(values, dispatch, { getCustomer });

    jestExpect(errors).toEqual({
      customerNo: 'Invalid Customer Number'
    });
  });

  test('should render mapping fields', () => {
    form = mount(
      <Provider store={createReduxStore({})}>
        <ReprintCutTicketPage shouldAsyncValidate={() => false} />
      </Provider>
    );

    jestExpect(semanticUI.getInputValue(form, 'date')).toEqual('');
    jestExpect(semanticUI.getInputValue(form, 'productCode')).toEqual('');
    jestExpect(semanticUI.getInputValue(form, 'susOrderNo')).toEqual('');
    jestExpect(semanticUI.getInputValue(form, 'customerNo')).toEqual('');
    jestExpect(semanticUI.getSelectValue(form, 'stationCode')).toEqual(undefined);
  });

  test('should show invalid product message if entered product is invalid', async () => {
    productResources.getProductInfoPromise.mockRejectedValueOnce();

    form = mount(
      <Provider store={createReduxStore({})}>
        <ReprintCutTicketPage shouldAsyncValidate={() => false} />
      </Provider>
    );

    await waitForAsyncTasks(form);

    semanticUI.changeInput(form, 'date', '09-09-2018');
    semanticUI.changeInput(form, 'productCode', '4102218');

    await waitForAsyncTasks(form);

    jestExpect(semanticUI.findErrorLabels(form)).toHaveLength(1);
    jestExpect(semanticUI.findErrorLabels(form)).toHaveText('Invalid Item Number');
  });

  test('should display printed cutOrders when all fields are valid', async () => {
    const stationsResponse = [
      { id: 123, type: 'PRODUCTION', stationCode: 1, name: 'station name' }
    ];
    stationResources.getStationsByRoom.mockResolvedValue({ data: stationsResponse });
    const cutOrders = [
      cutOrderFactory.build({
        cutSelectedAt: '09/21 09:42 AM',
        piecesPerCase: 10,
        product: productFactory.build({
          code: '4102218',
          description: 'LL SKIRT STEAK',
          productPortionSize: PortionSizeFactory.build({}),
          retailSpecific: retailSpecificFactory.build({
            price: 1.25,
            tare: 0.57,
            minWeight: 5.0
          })
        }),
        customerOrder: CustomerOrderFactory.build({
          customer: customerFactory.build({
            name: 'SUNNYSIDE VALE GROCER'
          })
        })
      }),
      cutOrderFactory.build({
        cutSelectedAt: '09/21 09:40 AM',
        qtyToProduce: 1,
        piecesPerCase: 10,
        product: productFactory.build({
          code: '4102218',
          description: 'LL SKIRT STEAK',
          productPortionSize: PortionSizeFactory.build({}),
          retailSpecific: retailSpecificFactory.build({
            price: 1.25,
            tare: 0.57,
            minWeight: 5.0
          })
        }),
        customerOrder: null
      })
    ];
    cutOrdersResources.getCutOrdersToPack.mockResolvedValue({ data: cutOrders });

    form = mount(
      <Provider store={createReduxStore({})}>
        <ReprintCutTicketPage shouldAsyncValidate={() => false} />
      </Provider>
    );

    await waitForAsyncTasks(form);

    semanticUI.changeInput(form, 'date', '09-09-2018');
    semanticUI.changeInput(form, 'productCode', '4102218');
    semanticUI.selectOption(form, 'stationCode', 0);
    form.find('form').simulate('submit');

    await waitForAsyncTasks(form);

    const getHeaderCell = semanticUI.createHeaderCellSelector(form);

    jestExpect(getHeaderCell(0).text()).toEqual('Cut Select Date');
    jestExpect(getHeaderCell(1).text()).toEqual('QTY');
    jestExpect(getHeaderCell(2).html()).toEqual(jestExpect.stringContaining('Order&nbsp;#'));
    jestExpect(getHeaderCell(3).text()).toEqual('Customer');
    jestExpect(getHeaderCell(4).html()).toEqual(jestExpect.stringContaining('Ship&nbsp;Date'));

    const cutOrdersTableBody = form.find('tbody').at(0);
    const getTableCell = semanticUI.createCellSelector(cutOrdersTableBody);

    jestExpect(getTableCell(0, 0).text()).toEqual('09/21 09:42 AM');
    jestExpect(getTableCell(0, 1).text()).toEqual('32');
    jestExpect(getTableCell(0, 2).text()).toEqual('99998');
    jestExpect(getTableCell(0, 3).text()).toEqual('SUNNYSIDE VALE GROCER');
    jestExpect(getTableCell(0, 4).text()).toEqual(moment().format('MM/DD/YY'));

    jestExpect(getTableCell(1, 0).text()).toEqual('09/21 09:40 AM');
    jestExpect(getTableCell(1, 1).text()).toEqual('1');
    jestExpect(getTableCell(1, 2).text()).toEqual('');
    jestExpect(getTableCell(1, 3).text()).toEqual('');
    jestExpect(getTableCell(1, 4).text()).toEqual(moment().format('MM/DD/YY'));

    form
      .find('.reprint-button')
      .at(1)
      .simulate('click');
    jestExpect(cutOrdersResources.reprintCutTicket).toHaveBeenCalledWith(1, 1);
    jestExpect(cutOrdersResources.reprintCutTicket).toHaveBeenCalledTimes(1);
  });

  test('should render null when cut orders is null', async () => {
    const stations = [{ id: 123, type: 'PRODUCTION', stationCode: 1, name: 'station name' }];
    stationResources.getStationsByRoom.mockReset();
    stationResources.getStationsByRoom.mockResolvedValue({ data: stations });
    cutOrdersResources.getCutOrdersToPack.mockResolvedValue({ data: null });

    form = mount(
      <Provider store={createReduxStore({})}>
        <ReprintCutTicketPage shouldAsyncValidate={() => false} />
      </Provider>
    );
    await waitForAsyncTasks(form);

    semanticUI.changeInput(form, 'date', '09-09-2018');
    semanticUI.changeInput(form, 'productCode', '0078889');
    semanticUI.selectOption(form, 'stationCode', 0);
    form.find('form').simulate('submit');

    await waitForAsyncTasks(form);

    jestExpect(semanticUI.findTables(form).length).toEqual(0);
  });

  test('should render empty table message when result is empty', async () => {
    const stationsResponse = [
      { id: 123, type: 'PRODUCTION', stationCode: 1, name: 'station name' }
    ];
    stationResources.getStationsByRoom.mockResolvedValue({ data: stationsResponse });
    cutOrdersResources.getCutOrdersToPack.mockResolvedValue({ data: [] });

    form = mount(
      <Provider store={createReduxStore({})}>
        <ReprintCutTicketPage shouldAsyncValidate={() => false} />
      </Provider>
    );

    await waitForAsyncTasks(form);

    semanticUI.changeInput(form, 'date', '09-09-2018');
    semanticUI.changeInput(form, 'productCode', '0078889');
    semanticUI.selectOption(form, 'stationCode', 0);
    form.find('form').simulate('submit');

    await waitForAsyncTasks(form);

    jestExpect(semanticUI.findTables(form).length).toEqual(0);
    jestExpect(form.find(EmptyTableMessage)).toExist();
  });
});
