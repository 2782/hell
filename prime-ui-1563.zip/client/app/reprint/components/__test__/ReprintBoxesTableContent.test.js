import boxFactory from '../../../../test-factories/boxFactory';
import weighingFactory from '../../../../test-factories/weighingFactory';
import { getLatestWeighingId } from '../ReprintBoxesTableContent';

test('should get latest weighing', () => {
  const box = boxFactory.build({
    weighings: [
      weighingFactory.build({ id: 10 }),
      weighingFactory.build({ id: 11 }),
      weighingFactory.build({ id: 99 }),
      weighingFactory.build({ id: 13 }),
      weighingFactory.build({ id: 10 })
    ]
  });

  const result = getLatestWeighingId(box);

  jestExpect(result).toEqual(99);
});
