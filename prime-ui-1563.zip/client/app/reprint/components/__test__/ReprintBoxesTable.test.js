import React from 'react';
import { mount } from 'enzyme';
import ReprintBoxesTable, { VARIANT } from '../ReprintBoxesTable';
import semanticUI from '../../../../test-helpers/semantic-ui';
import { Button } from 'semantic-ui-react';
import boxResources from '../../../shared/api/boxResources';
import boxFactory from '../../../../test-factories/boxFactory';
import weighingFactory from '../../../../test-factories/weighingFactory';

jest.mock('../../../shared/api/boxResources');

const fullBox = boxFactory.build({
  weight: 20.5,
  packagingTare: 1.05,
  netWeight: 19.45,
  packTime: '2019-03-27T09:04:00.000',
  isFullBox: true,
  weighings: [
    weighingFactory.build({ id: 1, type: 'RETAIL_PIECE', weight: 10.3, retailPieceTare: 0.05 }),
    weighingFactory.build({ id: 2, type: 'RETAIL_PIECE', weight: 10.25, retailPieceTare: 0.05 })
  ]
});

const partialBox = boxFactory.build({
  weight: 2.6,
  packagingTare: 1.05,
  netWeight: 1.45,
  packTime: '2019-03-27T09:00:00.000',
  isFullBox: false,
  weighings: [
    weighingFactory.build({ id: 3, type: 'RETAIL_PIECE', weight: 1.3, retailPieceTare: 0.05 }),
    weighingFactory.build({ id: 4, type: 'RETAIL_PIECE', weight: 1.25, retailPieceTare: 0.05 })
  ]
});

const wipBox = boxFactory.build({
  weight: 20.5,
  packagingTare: 1.05,
  netWeight: 19.45,
  packTime: '2019-03-27T09:04:00.000',
  isFullBox: true,
  forProductionOrder: false,
  weighings: [weighingFactory.build({ id: 5, type: 'BOX', weight: 10.3, retailPieceTare: 0.05 })]
});

describe('Reprint Retail labels', () => {
  let wrapper;

  beforeEach(() => {
    boxResources.reprintLabelsForCurrentUser.mockResolvedValue({});
    boxResources.reprintLabelsForStation.mockResolvedValue({});
    boxResources.relabelPackoffLabel.mockResolvedValue({});

    const boxes = [fullBox, partialBox, wipBox];

    wrapper = mount(
      <ReprintBoxesTable
        boxes={boxes}
        stationCode={1}
        variant={VARIANT.RETAIL}
        isRetailProduct={true}
      />
    );
  });

  test('should render table content for full and partial retail boxes only and no wip boxes', () => {
    const boxesTableBody = wrapper.find('tbody').at(0);

    jestExpect(boxesTableBody.find('tr')).toHaveLength(4);

    jestExpect(semanticUI.findTableColumnWithRowIndex(boxesTableBody, 0, 0)).toHaveText(
      '03/27 09:04 AM'
    );
    jestExpect(semanticUI.findTableColumnWithRowIndex(boxesTableBody, 0, 1)).toHaveText('10.25');
    jestExpect(semanticUI.findTableColumnWithRowIndex(boxesTableBody, 0, 2)).toHaveText('0.05');
    jestExpect(semanticUI.findTableColumnWithRowIndex(boxesTableBody, 0, 3)).toHaveText('10.2');
    jestExpect(semanticUI.findTableColumnWithRowIndex(boxesTableBody, 0, 4)).toHaveText('121');
    jestExpect(
      semanticUI.findTableColumnWithRowIndex(boxesTableBody, 0, 5).find('button.reprint-button')
    ).toHaveText('REPRINT');

    jestExpect(semanticUI.findTableColumnWithRowIndex(boxesTableBody, 1, 0)).toHaveText(
      '03/27 09:04 AM'
    );
    jestExpect(semanticUI.findTableColumnWithRowIndex(boxesTableBody, 1, 1)).toHaveText('10.3');
    jestExpect(semanticUI.findTableColumnWithRowIndex(boxesTableBody, 1, 2)).toHaveText('0.05');
    jestExpect(semanticUI.findTableColumnWithRowIndex(boxesTableBody, 1, 3)).toHaveText('10.25');
    jestExpect(semanticUI.findTableColumnWithRowIndex(boxesTableBody, 1, 4)).toHaveText('121');
    jestExpect(
      semanticUI.findTableColumnWithRowIndex(boxesTableBody, 1, 5).find('button.reprint-button')
    ).toHaveText('REPRINT');

    jestExpect(semanticUI.findTableColumnWithRowIndex(boxesTableBody, 2, 0)).toHaveText(
      '03/27 09:00 AM'
    );
    jestExpect(semanticUI.findTableColumnWithRowIndex(boxesTableBody, 2, 1)).toHaveText('1.25');
    jestExpect(semanticUI.findTableColumnWithRowIndex(boxesTableBody, 2, 2)).toHaveText('0.05');
    jestExpect(semanticUI.findTableColumnWithRowIndex(boxesTableBody, 2, 3)).toHaveText('1.2');
    jestExpect(semanticUI.findTableColumnWithRowIndex(boxesTableBody, 2, 4)).toHaveText('121');
    jestExpect(
      semanticUI.findTableColumnWithRowIndex(boxesTableBody, 1, 5).find('button.reprint-button')
    ).toHaveText('REPRINT');

    jestExpect(semanticUI.findTableColumnWithRowIndex(boxesTableBody, 3, 0)).toHaveText(
      '03/27 09:00 AM'
    );
    jestExpect(semanticUI.findTableColumnWithRowIndex(boxesTableBody, 3, 1)).toHaveText('1.3');
    jestExpect(semanticUI.findTableColumnWithRowIndex(boxesTableBody, 3, 2)).toHaveText('0.05');
    jestExpect(semanticUI.findTableColumnWithRowIndex(boxesTableBody, 3, 3)).toHaveText('1.25');
    jestExpect(semanticUI.findTableColumnWithRowIndex(boxesTableBody, 3, 4)).toHaveText('121');
    jestExpect(
      semanticUI.findTableColumnWithRowIndex(boxesTableBody, 3, 5).find('button.reprint-button')
    ).toHaveText('REPRINT');
  });

  test('should send reprint request when clicking reprint button with weighingId for retail', () => {
    const boxesTableBody = wrapper.find('tbody').at(0);
    const reprintButtons = boxesTableBody.find('button.reprint-button');

    reprintButtons.at(0).simulate('click');
    reprintButtons.at(1).simulate('click');
    reprintButtons.at(2).simulate('click');
    reprintButtons.at(3).simulate('click');

    jestExpect(boxResources.reprintLabelsForStation).toHaveBeenNthCalledWith(1, 2, 'RETAIL', 1);
    jestExpect(boxResources.reprintLabelsForStation).toHaveBeenNthCalledWith(2, 1, 'RETAIL', 1);
    jestExpect(boxResources.reprintLabelsForStation).toHaveBeenNthCalledWith(3, 4, 'RETAIL', 1);
    jestExpect(boxResources.reprintLabelsForStation).toHaveBeenNthCalledWith(4, 3, 'RETAIL', 1);
  });
});

describe('ReprintBoxesTable', () => {
  let wrapper;

  beforeEach(() => {
    boxResources.reprintLabelsForCurrentUser.mockResolvedValue({});
    boxResources.reprintLabelsForStation.mockResolvedValue({});
    boxResources.relabelPackoffLabel.mockResolvedValue({});

    wrapper = mount(
      <ReprintBoxesTable
        boxes={[fullBox, partialBox]}
        stationCode={1}
        variant={VARIANT.PACKOFF}
        isRetailProduct={true}
      />
    );
  });

  afterEach(() => {
    boxResources.reprintLabelsForStation.mockReset();
  });

  test('should render table header', () => {
    const tableHeader = semanticUI.findTable(wrapper, 0).find('th');
    jestExpect(tableHeader.at(0)).toHaveText('PACK DATE/TIME');
    jestExpect(tableHeader.at(1)).toHaveText('WEIGHT');
    jestExpect(tableHeader.at(2)).toHaveText('PACKAGING TARE');
    jestExpect(tableHeader.at(3)).toHaveText('NET WEIGHT');
    jestExpect(tableHeader.at(4)).toHaveText('REASON CODE');
  });

  test('should render table content for full boxes only', () => {
    const boxesTableBody = wrapper.find('tbody').at(0);

    jestExpect(boxesTableBody.find('tr')).toHaveLength(1);

    jestExpect(semanticUI.findTableColumnWithRowIndex(boxesTableBody, 0, 0)).toHaveText(
      '03/27 09:04 AM'
    );
    jestExpect(semanticUI.findTableColumnWithRowIndex(boxesTableBody, 0, 1)).toHaveText('20.5');
    jestExpect(semanticUI.findTableColumnWithRowIndex(boxesTableBody, 0, 2)).toHaveText('1.05');
    jestExpect(semanticUI.findTableColumnWithRowIndex(boxesTableBody, 0, 3)).toHaveText('19.45');
    jestExpect(semanticUI.findTableColumnWithRowIndex(boxesTableBody, 0, 4)).toHaveText('999');
    jestExpect(
      semanticUI.findTableColumnWithRowIndex(boxesTableBody, 0, 5).find('button.reprint-button')
    ).toHaveText('REPRINT');
  });

  test('should send reprint request when clicking reprint button with weighingId', () => {
    const boxesTableBody = wrapper.find('tbody').at(0);

    boxesTableBody
      .find(Button)
      .at(0)
      .simulate('click');

    jestExpect(boxResources.reprintLabelsForStation).toHaveBeenNthCalledWith(1, 2, 'BOX', 1);
  });
});

describe('RELABEL', () => {
  describe('non retail product', () => {
    let wrapper;
    beforeEach(() => {
      const box = boxFactory.build({
        id: 123,
        packTime: '2018-09-20T15:40:00.787',
        weight: 10.2,
        packagingTare: 10,
        netWeight: 0.2,
        overrideWeightRangeReasonCode: 1,
        forProductionOrder: true,
        isFullBox: true,
        weighings: [weighingFactory.build({ type: 'BOX', id: 2 })]
      });
      wrapper = mount(
        <ReprintBoxesTable
          boxes={[box]}
          stationCode={1}
          variant={VARIANT.PACKOFF}
          isRetailProduct={false}
        />
      );
    });

    test('should have RELABEL button when box is forProductionOrder and is not a retail product', () => {
      const boxesTableBody = wrapper.find('tbody').at(0);
      jestExpect(
        semanticUI.findTableColumnWithRowIndex(boxesTableBody, 0, 5).find('button.relabel-button')
      ).toHaveText('RELABEL');
    });

    test('should show the relabel button', () => {
      const boxesTableBody = wrapper.find('tbody').at(0);
      jestExpect(
        semanticUI.findTableColumnWithRowIndex(boxesTableBody, 0, 5).find('button.relabel-button')
      ).toHaveText('RELABEL');
    });

    test('should send relabel request when clicking relabel button', () => {
      const boxesTableBody = wrapper.find('tbody').at(0);

      boxesTableBody
        .find('button.relabel-button')
        .at(0)
        .simulate('click');

      jestExpect(boxResources.relabelPackoffLabel).toHaveBeenCalledWith(123, 1);
    });
  });

  describe('retail product', () => {
    let wrapper;
    beforeEach(() => {
      const box = boxFactory.build();
      wrapper = mount(
        <ReprintBoxesTable
          boxes={[box]}
          stationCode={1}
          variant={VARIANT.PACKOFF}
          isRetailProduct={true}
        />
      );
    });

    test('should not show relabel buttons on packoff view if the product is retail', () => {
      const boxesTableBody = wrapper.find('tbody').at(0);
      jestExpect(
        semanticUI.findTableColumnWithRowIndex(boxesTableBody, 0, 5).find('button.relabel-button')
      ).not.toExist();
    });
  });
});
