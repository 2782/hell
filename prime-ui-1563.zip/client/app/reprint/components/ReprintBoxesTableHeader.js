import { Table } from 'semantic-ui-react';
import React from 'react';

export const ReprintBoxesTableHeader = () => (
  <Table.Header>
    <Table.Row>
      <Table.HeaderCell colSpan={3} width={3}>
        PACK DATE/TIME
      </Table.HeaderCell>
      <Table.HeaderCell colSpan={1} width={1} textAlign={'right'}>
        WEIGHT
      </Table.HeaderCell>
      <Table.HeaderCell colSpan={3} width={3} textAlign={'right'}>
        PACKAGING TARE
      </Table.HeaderCell>
      <Table.HeaderCell colSpan={2} width={2} textAlign={'right'}>
        NET WEIGHT
      </Table.HeaderCell>
      <Table.HeaderCell colSpan={3} width={3} textAlign={'right'}>
        REASON CODE
      </Table.HeaderCell>
      <Table.HeaderCell colSpan={4} width={4} />
    </Table.Row>
  </Table.Header>
);
