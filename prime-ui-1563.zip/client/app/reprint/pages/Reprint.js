import React from 'react';
import PropTypes from 'prop-types';
import SideNavigation from '../../shared/components/SideNavigation';
import { Route } from 'react-router-dom';
import ReprintPackOffLabelPage from '../components/ReprintPackOffLabelPage';
import { replacePath, setHeaderAndFooter } from '../../shared/actions/actions';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import * as _ from 'lodash';
import ReprintCutTickets from '../components/ReprintCutTicketPage';
import subscriber, { f2BehaviorForSideNavigation } from '../../shared/functionKeys/subscriber';

const PACK_OFF_LABEL_PAGE = '/pack-off-label';
const TICKETS_PAGE = '/cut-tickets';

class Reprint extends React.Component {
  constructor(props) {
    super(props);

    this.subRouteLinks = this.subRouteLinks.bind(this);
  }

  subRouteLinks() {
    const { match, role } = this.props;
    const subRoutes = [
      {
        path: PACK_OFF_LABEL_PAGE,
        name: 'By Product Info',
        allowedRoles: ['ROLE_PORTION_ROOM_MEMBER', 'ROLE_ADMIN'],
        toPath: () => this.props.replacePath(`${match.url}${PACK_OFF_LABEL_PAGE}`),
        category: 'Pack Off Label'
      },
      {
        path: TICKETS_PAGE,
        name: 'Cut',
        allowedRoles: ['ROLE_PORTION_ROOM_MEMBER', 'ROLE_ADMIN'],
        toPath: () => this.props.replacePath(`${match.url}${TICKETS_PAGE}`),
        category: 'Ticket'
      }
    ];

    return _.filter(subRoutes, subRoute => subRoute.allowedRoles.includes(role));
  }

  render() {
    const { match } = this.props;

    return (
      <div className='page-content side-navigation-page reprint-page left-right'>
        <SideNavigation
          links={this.subRouteLinks()}
          currentPath={this.props.location.pathname}
          ref={ref => (this.sideNavigation = ref)}
        />

        <div className='right'>
          <Route
            exact
            path={`${match.url}${PACK_OFF_LABEL_PAGE}`}
            component={ReprintPackOffLabelPage}
          />
          <Route exact path={`${match.url}${TICKETS_PAGE}`} component={ReprintCutTickets} />
        </div>
      </div>
    );
  }
}

Reprint.propTypes = {
  replacePath: PropTypes.func,
  match: PropTypes.object,
  role: PropTypes.string,
  location: PropTypes.object
};

const mapStateToProps = state => ({
  role: state.login.role
});

const mapDispatchToProps = dispatch =>
  bindActionCreators(
    {
      replacePath,
      setHeaderAndFooter
    },
    dispatch
  );

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(
  subscriber(Reprint, {
    f2Behavior: f2BehaviorForSideNavigation,
    targetComponent: 'ReprintTickets',
    uris: {
      F2: ['#/reprint/pack-off-label', '#/reprint/cut-tickets']
    }
  })
);
