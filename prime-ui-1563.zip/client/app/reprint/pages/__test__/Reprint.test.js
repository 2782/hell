import configureStore from 'redux-mock-store';
import thunk from 'redux-thunk';
import SidebarNavigation from '../../../shared/components/SideNavigation';
import { mount } from 'enzyme';
import React from 'react';
import Reprint from '../Reprint';
import { Menu } from 'semantic-ui-react';
import { Provider } from 'react-redux';
import { replace } from 'react-router-redux';

jest.mock('../../../shared/components/Header');
jest.mock('../../../reprint/components/ReprintPackOffLabelPage');

let middleware = [thunk];
const createStore = configureStore(middleware);

describe('Reprint', () => {
  let wrapper;
  let mockStore;

  beforeEach(() => {
    mockStore = createStore({
      login: {
        role: 'ROLE_ADMIN'
      },
      function: {}
    });

    wrapper = mount(
      <Provider store={mockStore}>
        <Reprint
          location={{ pathname: '/reprint/pack-off-label' }}
          match={{ url: '/reprint' }}
          store={mockStore}
        />
      </Provider>
    );
  });

  test('should be aware of all relevant sidebar nav links', () => {
    const sidebar = wrapper.find(SidebarNavigation);
    jestExpect(sidebar).toHaveProp({
      currentPath: '/reprint/pack-off-label',
      links: [
        {
          path: '/pack-off-label',
          toPath: jestExpect.any(Function),
          name: 'By Product Info',
          allowedRoles: ['ROLE_PORTION_ROOM_MEMBER', 'ROLE_ADMIN'],
          category: 'Pack Off Label'
        },
        {
          path: '/cut-tickets',
          toPath: jestExpect.any(Function),
          name: 'Cut',
          allowedRoles: ['ROLE_PORTION_ROOM_MEMBER', 'ROLE_ADMIN'],
          category: 'Ticket'
        }
      ]
    });
  });

  test('should changePath when click navigation links', () => {
    mockStore.clearActions();
    const sidebar = wrapper.find(SidebarNavigation);

    sidebar
      .find(Menu.Item)
      .at(0)
      .simulate('click');

    const actions = mockStore.getActions();
    jestExpect(actions[0]).toEqual(replace('/reprint/pack-off-label'));
  });

  test('should changePath to cut tickets click navigation links', () => {
    mockStore.clearActions();
    const sidebar = wrapper.find(SidebarNavigation);

    sidebar
      .find(Menu.Item)
      .at(1)
      .simulate('click');

    const actions = mockStore.getActions();
    jestExpect(actions[0]).toEqual(replace('/reprint/cut-tickets'));
  });
});
