import stationResources from '../../../shared/api/stationResources';
import {
  getBoxes,
  getCutOrders,
  getStationByType,
  relabelPackoffLabel,
  reprintLabelsForCurrentUser,
  reprintLabelsForStation
} from '../reprintActions';
import {
  BOXES_FOR_REPRINT_RECEIVED,
  CUT_ORDERS_FOR_REPRINT_RECEIVED,
  STATIONS_FOR_ROOM_RECEIVED
} from '../reprintTypes';
import boxResources from '../../../shared/api/boxResources';
import boxFactory from '../../../../test-factories/boxFactory';
import cutOrderFactory from '../../../../test-factories/cutOrder';
import cutOrdersResources from '../../../shared/api/cutOrdersResources';

jest.mock('../../../shared/api/boxResources');
jest.mock('../../../shared/api/stationResources');
jest.mock('../../../shared/api/cutOrdersResources');

describe('reprint actions', () => {
  let dispatch;

  beforeEach(() => {
    dispatch = jest.fn();
  });

  test('should dispatch STATIONS_FOR_ROOM_RECEIVED when getStations', async () => {
    const packoffStation = { stationId: 1, code: 'A', type: 'PACKOFF' };
    const productionStation = { stationId: 2, code: 'B', type: 'PRODUCTION' };
    stationResources.getStationsByRoom.mockResolvedValue({
      data: [productionStation, packoffStation]
    });

    await getStationByType('PACKOFF', 'A')(dispatch);

    jestExpect(dispatch).toHaveBeenCalledTimes(1);
    jestExpect(dispatch).toHaveBeenNthCalledWith(1, {
      type: STATIONS_FOR_ROOM_RECEIVED,
      payload: [packoffStation]
    });

    stationResources.getStationsByRoom.mockReset();
  });

  test('should dispatch BOXES_FOR_REPRINT_RECEIVED when getBoxes', async () => {
    const boxes = [boxFactory.build()];
    boxResources.getBoxes.mockResolvedValue({ data: boxes });

    await getBoxes('2018-09-09', '0078889', '123')(dispatch);

    jestExpect(dispatch).toHaveBeenCalledTimes(1);
    jestExpect(dispatch).toHaveBeenNthCalledWith(1, {
      type: BOXES_FOR_REPRINT_RECEIVED,
      payload: boxes
    });

    boxResources.getBoxes.mockReset();
  });

  test('should dispatch CUT_ORDERS_FOR_REPRINT_RECEIVED when getCutOrders', async () => {
    const cutOrders = [cutOrderFactory.build()];
    cutOrdersResources.getCutOrdersToPack.mockResolvedValue({ data: cutOrders });

    await getCutOrders('2018-09-09', '0078889', '123', '')(dispatch);

    jestExpect(dispatch).toHaveBeenCalledTimes(1);
    jestExpect(dispatch).toHaveBeenNthCalledWith(1, {
      type: CUT_ORDERS_FOR_REPRINT_RECEIVED,
      payload: cutOrders
    });

    cutOrdersResources.getCutOrdersToPack.mockReset();
  });

  test('should dispatch CUT_ORDERS_FOR_REPRINT_RECEIVED when receiveCutOrders', async () => {
    const cutOrders = [cutOrderFactory.build()];
    cutOrdersResources.getCutOrdersToPack.mockResolvedValue({ data: cutOrders });

    await getCutOrders('2018-09-09', '0078889', '123', '')(dispatch);

    jestExpect(dispatch).toHaveBeenCalledTimes(1);
    jestExpect(dispatch).toHaveBeenNthCalledWith(1, {
      type: CUT_ORDERS_FOR_REPRINT_RECEIVED,
      payload: cutOrders
    });

    cutOrdersResources.getCutOrdersToPack.mockReset();
  });

  describe('reprint actions', () => {
    beforeEach(() => {
      boxResources.reprintLabelsForCurrentUser.mockResolvedValue({});
      boxResources.reprintLabelsForStation.mockResolvedValue({});
      boxResources.relabelPackoffLabel.mockResolvedValue({});
    });

    test('should call reprint', () => {
      reprintLabelsForStation(12, 'BOTH', 1);

      jestExpect(boxResources.reprintLabelsForStation).toHaveBeenCalledWith(12, 'BOTH', 1);

      boxResources.reprintLabelsForStation.mockReset();
    });

    test('should call relabel', () => {
      relabelPackoffLabel(12, 1);

      jestExpect(boxResources.relabelPackoffLabel).toHaveBeenCalledWith(12, 1);

      boxResources.relabelPackoffLabel.mockReset();
    });

    test('should call reprintLabelsForCurrentUser in packOrdersResources', () => {
      reprintLabelsForCurrentUser(12, 'BOTH');

      jestExpect(boxResources.reprintLabelsForCurrentUser).toBeCalledWith(12, 'BOTH');
    });
  });
});
