import React from 'react';
import { mount, shallow } from 'enzyme';
import { Provider } from 'react-redux';
import PortionRooms, {
  SelectPortionRooms as PortionRoomsWithoutStore
} from '../SelectPortionRooms';
import { Table } from 'semantic-ui-react';
import { UPDATE_CURRENT_PORTION_ROOM as SELECT_ACTION } from '../../actions/landingPageActionTypes';
import portionRoomFactory from '../../../../test-factories/portionRoomFactory';
import { DOWN, TAB } from '../../../../config/keymap';
import { createReduxStore } from '../../../store';

jest.mock('../../../shared/api/portionRoomsResources', () => ({
  getPortionRooms: jest.fn(() => Promise.resolve({ data: [] }))
}));

jest.mock('../../../shared/errors/ErrorNotification');

describe('PortionRoom', () => {
  let wrapper;
  let store;
  let dispatchSpy;

  const portionRoomB = portionRoomFactory.build({
    id: 8888888,
    code: 'B',
    description: 'Steak',
    portionRoomStatus: 'open',
    roomType: 'CUTTING',
    openable: false
  });
  const portionRoomQ = portionRoomFactory.build({
    id: 9999999,
    code: 'Q',
    description: 'Goat',
    portionRoomStatus: 'closed',
    roomType: 'CUTTING',
    openable: true
  });

  beforeEach(() => {
    jest.useFakeTimers();

    store = createReduxStore({
      portionRoomsInfo: {
        portionRooms: [portionRoomQ, portionRoomB]
      },
      login: {
        userId: 'user-Id',
        role: 'ROLE_ADMIN'
      },
      function: {
        key: null,
        target: null,
        subscriptions: {}
      }
    });

    dispatchSpy = jest.spyOn(store, 'dispatch');

    const div = document.createElement('div');
    wrapper = mount(
      <Provider store={store}>
        <PortionRooms />
      </Provider>,
      { attachTo: div }
    );
  });

  test('should show a blank page if userid and role is not set', () => {
    const component = shallow(
      <PortionRoomsWithoutStore
        getPortionRooms={() => {}}
        changePath={() => {}}
        role={null}
        userId={null}
        portionRooms={[]}
        selectPortionRoom={() => {}}
        setHeaderAndFooter={() => {}}
      />
    );

    jestExpect(component.html()).toBeNull();
  });

  test('should get portions when mounting', () => {
    let getPortionRoomsSpy = jest.fn();
    shallow(
      <PortionRoomsWithoutStore
        getPortionRooms={getPortionRoomsSpy}
        changePath={() => {}}
        selectPortionRoom={() => {}}
        setHeaderAndFooter={() => {}}
        portionRooms={[]}
      />
    );

    jestExpect(getPortionRoomsSpy).toHaveBeenCalledTimes(1);
  });

  test('should not show header if userid and role is not set', async () => {
    let headerAndFooterSpy = jest.fn();
    const component = shallow(
      <PortionRoomsWithoutStore
        getPortionRooms={() => {}}
        changePath={() => {}}
        role={null}
        userId={null}
        portionRooms={[]}
        selectPortionRoom={() => {}}
        setHeaderAndFooter={headerAndFooterSpy}
      />
    );

    await component.setState({
      role: null,
      userId: null
    });

    jestExpect(headerAndFooterSpy).not.toHaveBeenCalled();
  });

  test('should show header if userid and role is not set', async () => {
    let headerAndFooterSpy = jest.fn();
    const component = shallow(
      <PortionRoomsWithoutStore
        getPortionRooms={() => {}}
        changePath={() => {}}
        portionRooms={[]}
        role={'ROLE_ADMIN'}
        userId={'user-Id'}
        selectPortionRoom={() => {}}
        setHeaderAndFooter={headerAndFooterSpy}
      />
    );

    await component.setState({
      role: 'ROLE_ADMIN',
      userId: 'user-Id'
    });

    jestExpect(headerAndFooterSpy).toHaveBeenCalled();
  });

  test('should render table header', () => {
    jestExpect(wrapper.find(Table.HeaderCell).text()).toEqual('PORTION ROOMS');
  });

  test('should have 3 rows including header row', () => {
    const rows = wrapper.find(Table.Row);

    jestExpect(rows.length).toEqual(3);
  });

  test('should have correct portion room in first row after sorting alphabetically', () => {
    const cells = wrapper.find(Table.Cell);

    jestExpect(cells.at(1).text()).toEqual('B - Steak');
  });

  test('should stay in portion room list as user tabs forwards', () => {
    const rows = wrapper.find(Table.Row);

    rows.at(1).simulate('keydown', { keyCode: TAB[0], shiftKey: false });
    rows.at(2).simulate('keydown', { keyCode: TAB[0], shiftKey: false });

    const focused = document.activeElement;

    jestExpect(focused).toEqual(rows.at(1).getDOMNode());
  });

  test('should stay in portion room list as user tabs backwards', () => {
    const rows = wrapper.find(Table.Row);

    rows.at(1).simulate('keydown', { keyCode: TAB[0], shiftKey: true });

    const focused = document.activeElement;

    jestExpect(focused).toEqual(rows.at(2).getDOMNode());
  });

  test('should stay on last portion room as user navigates with down arrow', () => {
    const rows = wrapper.find(Table.Row);

    rows.at(1).simulate('keydown', { keyCode: DOWN[0] });
    rows.at(2).simulate('keydown', { keyCode: DOWN[0] });

    const focused = document.activeElement;

    jestExpect(focused).toEqual(rows.at(2).getDOMNode());
  });

  test('should move to main navigation on click of a portion room', () => {
    let tableCells = wrapper.find(Table.Cell);

    tableCells.at(1).simulate('click');

    jestExpect(dispatchSpy).toHaveBeenCalledWith({
      type: 'FUNCTION_KEY_SUBSCRIPTION',
      payload: {
        targetComponent: 'SelectPortionRooms',
        uris: { F4: ['#/'] }
      }
    });

    jestExpect(dispatchSpy).toHaveBeenCalledWith({
      type: SELECT_ACTION,
      payload: portionRoomB
    });

    jestExpect(dispatchSpy).toHaveBeenCalledWith({
      type: '@@router/CALL_HISTORY_METHOD',
      payload: {
        method: 'push',
        args: ['/main-navigation']
      }
    });
  });

  test('should move to main navigation on hitting enter key for a portion room', () => {
    let rows = wrapper.find(Table.Row);

    rows.at(1).simulate('keydown', { keyCode: 13 });

    jestExpect(dispatchSpy).toHaveBeenCalledWith({
      type: 'FUNCTION_KEY_SUBSCRIPTION',
      payload: {
        targetComponent: 'SelectPortionRooms',
        uris: { F4: ['#/'] }
      }
    });
  });
});
