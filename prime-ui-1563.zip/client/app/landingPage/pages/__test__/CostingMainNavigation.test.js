import { CostingMainNavigationComponent } from '../CostingMainNavigation';

jest.mock('../../../shared/components/Header');
jest.mock('../../components/MainMenu');
jest.mock('../../../shared/errors/ErrorNotification');

describe('CostingMainNavigation', () => {
  beforeEach(() => {
    jest.useFakeTimers();
  });

  test('should get yield model status when mounting if role is costing', () => {
    let landingPage = new CostingMainNavigationComponent({
      setHeaderAndFooter: jest.fn(),
      getCostingRoom: jest.fn(),
      role: 'ROLE_COSTING'
    });

    landingPage.componentDidMount();

    jestExpect(landingPage.props.getCostingRoom).toBeCalled();
    jestExpect(landingPage.props.setHeaderAndFooter).toBeCalled();
  });

  test('should not yield model status when mounting if user not costing', () => {
    let landingPage = new CostingMainNavigationComponent({
      setHeaderAndFooter: jest.fn(),
      getCostingRoom: jest.fn(),
      role: 'ROLE_ADMIN'
    });

    landingPage.componentDidMount();

    jestExpect(landingPage.props.getCostingRoom).toBeCalled();
    jestExpect(landingPage.props.setHeaderAndFooter).toBeCalled();
  });

  test('should show yield models, run yield model, and reports for merchandiser role', () => {
    let landingPage = new CostingMainNavigationComponent({
      role: 'ROLE_COSTING'
    });

    const links = landingPage.createLinks();

    jestExpect(links.length).toEqual(2);

    jestExpect(links[0].length).toEqual(2);
    const importCost = links[0][0];
    const yieldModels = links[0][1];

    jestExpect(links[1].length).toEqual(2);
    const reports = links[1][0];
    const productBase = links[1][1];

    jestExpect(importCost.text).toEqual('Import Costs');
    jestExpect(yieldModels.text).toEqual('Yield Model');
    jestExpect(reports.text).toEqual('Reports');
    jestExpect(productBase.text).toEqual('Product');
  });

  test('should not any menu options when role is not costing', () => {
    let landingPage = new CostingMainNavigationComponent({
      role: 'ROLE_PORTION_ROOM_MEMBER'
    });

    const links = landingPage.createLinks();

    jestExpect(links.length).toEqual(0);
  });
});
