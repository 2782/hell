import React from 'react';
import { mount } from 'enzyme';
import { Provider } from 'react-redux';
import MainNavigation, {
  ClosePortionRoomWarning,
  MainNavigation as MainNavigationComponent
} from '../MainNavigation';
import store from '../../../store';
import portionRoomsResources from '../../../shared/api/portionRoomsResources';
import { PortionRoomState } from '../../reducers/portionRoomReducer';
import InstructionBoard from '../../../shared/components/InstructionBoard';
import portionRoomFactory from '../../../../test-factories/portionRoomFactory';
import FocusedModal from '../../components/FocusedModal';

jest.mock('../../../shared/components/Header');
jest.mock('../../components/MainMenu');
jest.mock('../../../shared/errors/ErrorNotification');
jest.mock('../../../shared/actions/actions', () => ({
  getOperatingDates: jest.fn(() => ({ type: 'MOCK_GET_OPERATING_DATES' })),
  setHeaderAndFooter: jest.fn(() => ({ type: 'MOCK_SET_HEADER_AND_FOOTER' }))
}));
jest.mock('../../../shared/api/portionRoomsResources');

describe('MainNavigation', () => {
  let wrapper;

  beforeEach(() => {
    portionRoomsResources.getPortionRooms.mockResolvedValue({ data: [portionRoomFactory.build()] });

    jest.useFakeTimers();

    wrapper = mount(
      <Provider store={store}>
        <MainNavigation />
      </Provider>
    );
  });

  test('should get portion room status when mounting if role is admin', () => {
    let landingPage = new MainNavigationComponent({
      getPortionRooms: jest.fn(),
      getOperatingDates: jest.fn(),
      setHeaderAndFooter: jest.fn(),
      role: 'ROLE_ADMIN'
    });

    landingPage.componentDidMount();

    jestExpect(landingPage.props.getPortionRooms).toHaveBeenCalled();
    jestExpect(landingPage.props.getOperatingDates).toHaveBeenCalled();
    jestExpect(landingPage.props.setHeaderAndFooter).toHaveBeenCalled();
  });

  test('should not portion room status when mounting if user not admin', () => {
    let landingPage = new MainNavigationComponent({
      getPortionRooms: jest.fn(),
      getOperatingDates: jest.fn(),
      setHeaderAndFooter: jest.fn(),
      role: 'ROLE_PORTION_ROOM_MEMBER'
    });

    landingPage.componentDidMount();

    jestExpect(landingPage.props.getPortionRooms).toHaveBeenCalled();
    jestExpect(landingPage.props.getOperatingDates).toHaveBeenCalled();
    jestExpect(landingPage.props.setHeaderAndFooter).toHaveBeenCalled();
  });

  test(
    'should enable open portion room, administration, yieldModel, ' +
      'productSetup, and overview options when room has not yet been opened',
    () => {
      let landingPage = new MainNavigationComponent({
        portionRoomState: PortionRoomState.CAN_OPEN,
        currentPortionRoomType: 'GRINDING',
        role: 'ROLE_ADMIN'
      });

      const links = landingPage.createLinks();
      const openPortionRoom = links[0][0];
      const importCosts = links[0][1];
      const ordersToCutToday = links[1][0];
      const requestMeat = links[1][1];
      const searchBatch = links[1][2];
      const ordersToPackToday = links[2][0];
      const packOffStock = links[2][1];
      const packWip = links[2][2];
      const scheduleGrindOrders = links[3][0];
      const administration = links[4][0];
      const yieldModels = links[4][1];
      const product = links[5][0];

      jestExpect(openPortionRoom.isDisabled).toEqual(false);
      jestExpect(openPortionRoom.text).toEqual('Open Portion Room');
      jestExpect(importCosts.text).toEqual('Import Costs');
      jestExpect(importCosts.isDisabled).toEqual(false);
      jestExpect(ordersToCutToday.isDisabled).toEqual(true);
      jestExpect(requestMeat.isDisabled).toEqual(false);
      jestExpect(searchBatch.isDisabled).toEqual(false);
      jestExpect(ordersToPackToday.isDisabled).toEqual(true);
      jestExpect(packOffStock.isDisabled).toEqual(true);
      jestExpect(packWip.isDisabled).toEqual(true);
      jestExpect(scheduleGrindOrders.isDisabled).toEqual(false);
      jestExpect(administration.isDisabled).toEqual(false);
      jestExpect(yieldModels.isDisabled).toEqual(false);
      jestExpect(product.isDisabled).toEqual(false);
    }
  );

  test(
    'should disable overview, orders to pack, pack off stock, Pack WIP' +
      'when GRINDING room is open but not yet approved',
    () => {
      let landingPage = new MainNavigationComponent({
        portionRoomState: PortionRoomState.CAN_APPROVE,
        currentPortionRoomType: 'GRINDING',
        role: 'ROLE_ADMIN'
      });

      const links = landingPage.createLinks();
      const openOrClosePortionRoom = links[0][0];
      const ordersToCutToday = links[1][0];
      const requestMeat = links[1][1];
      const ordersToPackToday = links[2][0];
      const packOffStock = links[2][1];
      const packWip = links[2][2];
      const scheduleGrindOrders = links[3][0];
      const administration = links[4][0];
      const yieldModels = links[4][1];
      const product = links[5][0];

      jestExpect(openOrClosePortionRoom.isDisabled).toEqual(false);
      jestExpect(openOrClosePortionRoom.text).toEqual('Close Portion Room');
      jestExpect(ordersToCutToday.isDisabled).toEqual(true);
      jestExpect(requestMeat.isDisabled).toEqual(false);
      jestExpect(ordersToPackToday.isDisabled).toEqual(true);
      jestExpect(packOffStock.isDisabled).toEqual(true);
      jestExpect(packWip.isDisabled).toEqual(true);
      jestExpect(scheduleGrindOrders.isDisabled).toEqual(false);
      jestExpect(administration.isDisabled).toEqual(false);
      jestExpect(yieldModels.isDisabled).toEqual(false);
      jestExpect(product.isDisabled).toEqual(false);
    }
  );

  test('should exist and be enabled Reprint', () => {
    let landingPage = new MainNavigationComponent({
      portionRoomState: PortionRoomState.CAN_OPEN,
      currentPortionRoomType: 'CUTTING',
      role: 'ROLE_ADMIN'
    });

    const links = landingPage.createLinks();
    const reprint = links[5][2];
    const reprintText = links[5][2].text;

    jestExpect(reprintText).toEqual('Reprint');
    jestExpect(reprint.isDisabled).toEqual(false);
    jestExpect(reprint.path).toEqual('/reprint');
  });

  test('should exist and be enabled scheduleFutureOrders when room is cutting, room is open', () => {
    let landingPage = new MainNavigationComponent({
      portionRoomState: PortionRoomState.CAN_CLOSE,
      currentPortionRoomType: 'CUTTING',
      role: 'ROLE_ADMIN'
    });

    const links = landingPage.createLinks();
    const scheduleFutureOrders = links[3][1];
    const scheduleFutureOrdersText = links[3][1].text;

    jestExpect(scheduleFutureOrdersText).toEqual('Schedule Future Orders');
    jestExpect(scheduleFutureOrders.isDisabled).toEqual(false);
    jestExpect(scheduleFutureOrders.path).toEqual('/future-orders/cutting/schedule');
  });

  test('should enable scheduling of grind orders for today, and not cut orders, when room is grinding', () => {
    let landingPage = new MainNavigationComponent({
      portionRoomState: PortionRoomState.CAN_OPEN,
      currentPortionRoomType: 'GRINDING',
      role: 'ROLE_ADMIN'
    });

    const links = landingPage.createLinks();
    const futureOrdersCell = links[3][0];
    const ordersToGrindToday = links[1][0];

    jestExpect(futureOrdersCell.text).toEqual('Schedule Grind Orders');
    jestExpect(ordersToGrindToday.text).toEqual('Orders to Grind Today');

    jestExpect(futureOrdersCell.isDisabled).toEqual(false);
    jestExpect(futureOrdersCell.path).toEqual('/grinding/future-orders/schedule');
  });

  test(
    'should disabled scheduling of grind orders for today, when room is grinding, room is opened' +
      ' and schedule is not approved',
    () => {
      let landingPage = new MainNavigationComponent({
        portionRoomState: PortionRoomState.CAN_APPROVE,
        currentPortionRoomType: 'GRINDING',
        role: 'ROLE_ADMIN'
      });

      const links = landingPage.createLinks();
      const ordersToGrindToday = links[1][0];

      jestExpect(ordersToGrindToday.text).toEqual('Orders to Grind Today');
      jestExpect(ordersToGrindToday.isDisabled).toEqual(true);
    }
  );

  test(
    'should enable scheduling of grind orders for today, when room is grinding, room is opened' +
      ' and schedule is approved',
    () => {
      let landingPage = new MainNavigationComponent({
        portionRoomState: PortionRoomState.CAN_CLOSE,
        currentPortionRoomType: 'GRINDING',
        role: 'ROLE_ADMIN'
      });

      const links = landingPage.createLinks();
      const ordersToGrindToday = links[1][0];

      jestExpect(ordersToGrindToday.text).toEqual('Orders to Grind Today');
      jestExpect(ordersToGrindToday.isDisabled).toEqual(false);
    }
  );

  test('should not show administration, yield model, reports, and open/close portion room for cutting', () => {
    let landingPage = new MainNavigationComponent({
      portionRoomState: PortionRoomState.CAN_CLOSE,
      currentPortionRoomType: 'CUTTING',
      role: 'ROLE_PORTION_ROOM_MEMBER'
    });

    const links = landingPage.createLinks();

    jestExpect(links.length).toEqual(4);

    jestExpect(links[2].length).toEqual(3);
    const ordersToCutToday = links[0][0];
    const requestMeat = links[0][1];
    const searchBatch = links[0][2];

    jestExpect(links[1].length).toEqual(3);
    const ordersToPackToday = links[1][0];
    const packOffStock = links[1][1];
    const packWip = links[1][2];

    jestExpect(links[2].length).toEqual(3);
    const cutOrdersOverview = links[2][0];
    const scheduleFutureOrders = links[2][1];
    const createBatch = links[2][2];

    jestExpect(links[3].length).toEqual(2);
    const product = links[3][0];
    const reprint = links[3][1];

    jestExpect(ordersToCutToday.text).toEqual('Orders to Cut Today');
    jestExpect(requestMeat.text).toEqual('Request Meat');
    jestExpect(searchBatch.text).toEqual('Search Batch');
    jestExpect(ordersToPackToday.text).toEqual('Orders to Pack Today');
    jestExpect(packOffStock.text).toEqual('Pack off Stock');
    jestExpect(packWip.text).toEqual('Pack WIP');
    jestExpect(cutOrdersOverview.text).toEqual('Cut Orders Overview');
    jestExpect(scheduleFutureOrders.text).toEqual('Schedule Future Orders');
    jestExpect(createBatch.text).toEqual('Create Batch');
    jestExpect(product.text).toEqual('Product');
    jestExpect(reprint.text).toEqual('Reprint');
  });

  test('should not show administration, yield model, reports, scheduling, and open/close portion room for grinding', () => {
    let landingPage = new MainNavigationComponent({
      portionRoomState: PortionRoomState.CAN_CLOSE,
      currentPortionRoomType: 'GRINDING',
      role: 'ROLE_PORTION_ROOM_MEMBER'
    });

    const links = landingPage.createLinks();

    jestExpect(links.length).toEqual(3);

    jestExpect(links[0].length).toEqual(3);
    const ordersToGrindToday = links[0][0];
    const requestMeat = links[0][1];
    const searchBatch = links[0][2];

    jestExpect(links[1].length).toEqual(3);
    const ordersToPackToday = links[1][0];
    const packOffStock = links[1][1];
    const packWip = links[1][2];

    jestExpect(links[2].length).toEqual(2);
    const product = links[2][0];
    const reprint = links[2][1];

    jestExpect(ordersToGrindToday.text).toEqual('Orders to Grind Today');
    jestExpect(requestMeat.text).toEqual('Request Meat');
    jestExpect(searchBatch.text).toEqual('Search Batch');
    jestExpect(ordersToPackToday.text).toEqual('Orders to Pack Today');
    jestExpect(packOffStock.text).toEqual('Pack off Stock');
    jestExpect(packWip.text).toEqual('Pack WIP');
    jestExpect(product.text).toEqual('Product');
    jestExpect(reprint.text).toEqual('Reprint');
  });

  test('should enable close portion room and all other options when room has been opened', () => {
    let landingPage = new MainNavigationComponent({
      portionRoomState: PortionRoomState.CAN_CLOSE,
      currentPortionRoomType: 'CUTTING',
      role: 'ROLE_ADMIN'
    });

    const links = landingPage.createLinks();
    const closePortionRoom = links[0][0];
    const ordersToCutToday = links[1][0];
    const requestMeat = links[1][1];
    const createBatch = links[1][2];
    const ordersToPackToday = links[2][0];
    const packOffStock = links[2][1];
    const packWip = links[2][2];
    const cutOrdersOverview = links[3][0];
    const scheduleFutureOrders = links[3][1];
    const administration = links[4][0];
    const yieldModels = links[4][1];

    jestExpect(closePortionRoom.isDisabled).toEqual(false);
    jestExpect(closePortionRoom.text).toEqual('Close Portion Room');
    jestExpect(ordersToCutToday.isDisabled).toEqual(false);
    jestExpect(requestMeat.isDisabled).toEqual(false);
    jestExpect(createBatch.isDisabled).toEqual(false);
    jestExpect(ordersToPackToday.isDisabled).toEqual(false);
    jestExpect(packOffStock.isDisabled).toEqual(false);
    jestExpect(packWip.isDisabled).toEqual(false);
    jestExpect(cutOrdersOverview.isDisabled).toEqual(false);
    jestExpect(scheduleFutureOrders.isDisabled).toEqual(false);
    jestExpect(administration.isDisabled).toEqual(false);
    jestExpect(yieldModels.isDisabled).toEqual(false);
  });

  test(
    'should disable open portion room and only enable order overview, yieldModel, searchYieldModel, productSetup, and' +
      ' administration when room is closed and not openable',
    () => {
      let landingPage = new MainNavigationComponent({
        portionRoomState: PortionRoomState.DISABLED,
        currentPortionRoomType: 'CUTTING',
        role: 'ROLE_ADMIN'
      });

      const links = landingPage.createLinks();
      const openPortionRoom = links[0][0];
      const ordersToCutToday = links[1][0];

      const requestMeat = links[1][1];
      const searchBatch = links[1][2];
      const ordersToPackToday = links[2][0];
      const packOffStock = links[2][1];
      const packWip = links[2][2];
      const cutOrdersOverview = links[3][0];
      const scheduleFutureOrders = links[3][1];
      const createBatch = links[3][2];
      const administration = links[4][0];
      const yieldModels = links[4][1];
      const product = links[5][0];

      jestExpect(openPortionRoom.isDisabled).toEqual(true);
      jestExpect(openPortionRoom.text).toEqual('Open Portion Room');
      jestExpect(createBatch.isDisabled).toEqual(true);
      jestExpect(ordersToCutToday.isDisabled).toEqual(true);
      jestExpect(requestMeat.isDisabled).toEqual(false);
      jestExpect(searchBatch.isDisabled).toEqual(false);
      jestExpect(ordersToPackToday.isDisabled).toEqual(true);
      jestExpect(packOffStock.isDisabled).toEqual(true);
      jestExpect(packWip.isDisabled).toEqual(true);
      jestExpect(cutOrdersOverview.isDisabled).toEqual(false);
      jestExpect(scheduleFutureOrders.isDisabled).toEqual(true);
      jestExpect(administration.isDisabled).toEqual(false);
      jestExpect(yieldModels.isDisabled).toEqual(false);
      jestExpect(product.isDisabled).toEqual(false);
    }
  );

  test(
    'should disable open portion room and only enable order overview and administration ' +
      'when room is closed and not openable',
    () => {
      let landingPage = new MainNavigationComponent({
        portionRoomState: PortionRoomState.DISABLED,
        currentPortionRoomType: 'CUTTING',
        role: 'ROLE_ADMIN'
      });

      const links = landingPage.createLinks();
      const openPortionRoom = links[0][0];
      const ordersToCutToday = links[1][0];
      const requestMeat = links[1][1];
      const searchBatch = links[1][2];
      const ordersToPackToday = links[2][0];
      const packOffStock = links[2][1];
      const packWip = links[2][2];
      const cutOrdersOverview = links[3][0];
      const scheduleFutureOrders = links[3][1];
      const createBatch = links[3][2];
      const administration = links[4][0];
      const yieldModels = links[4][1];

      jestExpect(openPortionRoom.isDisabled).toEqual(true);
      jestExpect(openPortionRoom.text).toEqual('Open Portion Room');
      jestExpect(createBatch.isDisabled).toEqual(true);
      jestExpect(ordersToCutToday.isDisabled).toEqual(true);
      jestExpect(requestMeat.isDisabled).toEqual(false);
      jestExpect(searchBatch.isDisabled).toEqual(false);
      jestExpect(ordersToPackToday.isDisabled).toEqual(true);
      jestExpect(packOffStock.isDisabled).toEqual(true);
      jestExpect(packWip.isDisabled).toEqual(true);
      jestExpect(cutOrdersOverview.isDisabled).toEqual(false);
      jestExpect(scheduleFutureOrders.isDisabled).toEqual(true);
      jestExpect(administration.isDisabled).toEqual(false);
      jestExpect(yieldModels.isDisabled).toEqual(false);
    }
  );

  test('should open portion room when pressing on enter if not yet opened and is openable', () => {
    let landingPage = new MainNavigationComponent({
      portionRoomState: PortionRoomState.CAN_OPEN,
      currentPortionRoomType: 'CUTTING',
      openPortionRoom: jest.fn(),
      closePortionRoom: jest.fn(),

      role: 'ROLE_ADMIN'
    });

    const openPortionRoom = landingPage.createLinks()[0][0];

    openPortionRoom.onEnter();

    jestExpect(landingPage.props.openPortionRoom).toHaveBeenCalled();
    jestExpect(landingPage.props.closePortionRoom).not.toHaveBeenCalled();
  });

  test('should request to close the portion room when pressing on enter if room is open', () => {
    let landingPage = new MainNavigationComponent({
      portionRoomState: PortionRoomState.CAN_CLOSE,
      currentPortionRoomType: 'CUTTING',
      openPortionRoom: jest.fn(),
      closePortionRoom: jest.fn(),
      role: 'ROLE_ADMIN'
    });

    const openPortionRoom = landingPage.createLinks()[0][0];

    openPortionRoom.onEnter();

    jestExpect(landingPage.props.openPortionRoom).not.toHaveBeenCalled();
    jestExpect(landingPage.props.closePortionRoom).toHaveBeenCalledWith(false, false);
  });

  test('should request to close the portion room when pressing on enter if room is open and can approve', () => {
    let landingPage = new MainNavigationComponent({
      portionRoomState: PortionRoomState.CAN_APPROVE,
      currentPortionRoomType: 'GRINDING',
      openPortionRoom: jest.fn(),
      closePortionRoom: jest.fn(),
      role: 'ROLE_ADMIN'
    });

    const openPortionRoom = landingPage.createLinks()[0][0];

    openPortionRoom.onEnter();

    jestExpect(landingPage.props.openPortionRoom).not.toHaveBeenCalled();
    jestExpect(landingPage.props.closePortionRoom).toBeCalledWith(false, false);
  });

  test('should do nothing when pressing on enter if room is not opened and is not openable now', () => {
    let landingPage = new MainNavigationComponent({
      portionRoomState: PortionRoomState.DISABLED,
      currentPortionRoomType: 'CUTTING',
      openPortionRoom: jest.fn(),
      closePortionRoom: jest.fn(),
      role: 'ROLE_ADMIN'
    });

    const openPortionRoom = landingPage.createLinks()[0][0];

    openPortionRoom.onEnter();

    jestExpect(landingPage.props.openPortionRoom).not.toHaveBeenCalled();
    jestExpect(landingPage.props.closePortionRoom).not.toHaveBeenCalled();
  });

  test('should show warning when cannot close', () => {
    let component = ClosePortionRoomWarning({ warn: true, show: true });
    jestExpect(component.type).toEqual(InstructionBoard);
    jestExpect(component.props.prompt).toEqual(
      'Orders are still in progress. Still close the room?'
    );
  });

  test('should offer yes/no options to warning', () => {
    let component = ClosePortionRoomWarning({ warn: true, show: true });
    jestExpect(component.props.options.length).toEqual(2);

    let yesOption = component.props.options[0];
    let noOption = component.props.options[1];

    jestExpect(yesOption.message).toEqual('Yes');
    jestExpect(noOption.message).toEqual('No');
  });

  test('should not show warning when can close', () => {
    jestExpect(ClosePortionRoomWarning({ warn: false })).toEqual(null);
  });

  test('should show unfinished orders warning when cannot close portion room', () => {
    let result = new MainNavigationComponent({
      cannotClosePortionRoom: true,
      currentPortionRoomType: 'CUTTING',
      cannotCloseReason: 'UNFINISHED_PRODUCTION_ORDERS',
      showUnreceivedPurchaseOrdersModel: true,
      showUnfinishedBatchModel: false,
      showSusPoServiceUnavailableModal: false,
      dismissPortionRoomWarning: () => {}
    }).render();

    let warning = mount(result).find(ClosePortionRoomWarning);
    jestExpect(warning.props().warn).toEqual(true);
  });

  test('should show unReceived purchase order model when there are UNRECEIVED_PURCHASE_ORDERS', () => {
    let result = new MainNavigationComponent({
      cannotClosePortionRoom: true,
      currentPortionRoomType: 'CUTTING',
      cannotCloseReason: 'UNRECEIVED_PURCHASE_ORDERS',
      showUnreceivedPurchaseOrdersModel: false,
      showUnfinishedBatchModel: false,
      showSusPoServiceUnavailableModal: false,
      dismissPortionRoomWarning: () => {}
    }).render();

    let modal = mount(result)
      .find(FocusedModal)
      .at(0);
    jestExpect(modal.props().content).toEqual(
      'Cannot close room until all purchase order responses are received from SUS. Please wait 5 minutes and attempt to close the room again.'
    );
  });

  test('should show unfinished batches model when there are UNFINISHED_BATCHES', () => {
    let result = new MainNavigationComponent({
      cannotClosePortionRoom: true,
      currentPortionRoomType: 'CUTTING',
      cannotCloseReason: 'UNFINISHED_BATCHES',
      unfinishableBatches: [{ id: 1, batchNumber: 1 }],
      showUnreceivedPurchaseOrdersModel: false,
      showUnfinishedBatchModel: true,
      showSusPoServiceUnavailableModal: false,
      dismissPortionRoomWarning: () => {}
    }).render();

    let modal = mount(result)
      .find(FocusedModal)
      .at(1);
    jestExpect(modal.props().content).toEqual(
      'Room cannot be closed with incomplete batch forms. Please review batch 1.'
    );
  });

  test('should show sus po service unavailable modal', () => {
    let result = new MainNavigationComponent({
      cannotClosePortionRoom: true,
      currentPortionRoomType: 'CUTTING',
      cannotCloseReason: 'UNPROCESSED_PURCHASE_ORDERS_OR_RECEIPTS',
      unfinishableBatches: [],
      showUnreceivedPurchaseOrdersModel: true,
      showUnfinishedBatchModel: true,
      showSusPoServiceUnavailableModal: true,
      dismissPortionRoomWarning: () => {}
    }).render();

    let modal = mount(result)
      .find(FocusedModal)
      .at(2);
    jestExpect(modal.props().content).toEqual(
      'PO service is unavailable, and POs in SUS need to be updated manually. Still close the room?'
    );
  });

  test('should forcibly close portion room on Yes from user, and dismiss warning', () => {
    let component = new MainNavigationComponent({
      cannotClosePortionRoom: true,
      currentPortionRoomType: 'CUTTING',
      portionRoomIds: [7],
      closePortionRoom: jest.fn(),
      dismissPortionRoomWarning: jest.fn(),
      showUnreceivedPurchaseOrdersModel: true,
      showUnfinishedBatchModel: false,
      showSusPoServiceUnavailableModal: false
    });

    wrapper = mount(component.render());

    let warning = wrapper.find(ClosePortionRoomWarning);
    warning.props().onYes();

    jestExpect(component.props.closePortionRoom).toBeCalledWith(true, false);
    jestExpect(component.props.dismissPortionRoomWarning).toHaveBeenCalled();
  });

  test('should do nothing special on No from user, and dismiss warning', () => {
    let component = new MainNavigationComponent({
      cannotClosePortionRoom: true,
      currentPortionRoomType: 'CUTTING',
      portionRoomIds: [7],
      closePortionRoom: jest.fn(),
      dismissPortionRoomWarning: jest.fn(),
      showUnreceivedPurchaseOrdersModel: true,
      showUnfinishedBatchModel: false,
      showSusPoServiceUnavailableModal: false
    });

    wrapper = mount(component.render());

    let warning = wrapper.find(ClosePortionRoomWarning);
    warning.props().onNo();

    jestExpect(component.props.closePortionRoom).not.toHaveBeenCalled();
    jestExpect(component.props.dismissPortionRoomWarning).toHaveBeenCalled();
  });

  test('should not show both Orders to Cut and Orders to Grind', () => {
    let landingPage = new MainNavigationComponent({
      portionRoomState: PortionRoomState.CAN_OPEN,
      currentPortionRoomType: 'CUTTING',
      role: 'ROLE_ADMIN'
    });

    const links = landingPage.createLinks();

    jestExpect(links[1].length).toEqual(3);
  });

  test('should show Orders to Cut for Today when in a cutting room, and not the other one', () => {
    let landingPage = new MainNavigationComponent({
      portionRoomState: PortionRoomState.CAN_OPEN,
      currentPortionRoomType: 'CUTTING',
      role: 'ROLE_ADMIN'
    });

    const links = landingPage.createLinks();

    const ordersForToday = links[1][0];

    jestExpect(ordersForToday.text).toEqual('Orders to Cut Today');
  });

  test('should show Orders to Grind for Today when in a grinding room, and not the other one', () => {
    let landingPage = new MainNavigationComponent({
      portionRoomState: PortionRoomState.CAN_OPEN,
      currentPortionRoomType: 'GRINDING',
      role: 'ROLE_ADMIN'
    });

    const links = landingPage.createLinks();

    const ordersForToday = links[1][0];

    jestExpect(ordersForToday.text).toEqual('Orders to Grind Today');
  });
});
