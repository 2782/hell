import _ from 'lodash';
import React from 'react';
import PropTypes from 'prop-types';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import MainMenu from '../components/MainMenu';
import { changePath, setHeaderAndFooter } from '../../shared/actions/actions';
import { getCostingRoom, runYieldModel } from '../actions/landingPageActions';
import { MAIN_MENU } from '../../shared/components/pageTitles';
import { MAIN_MENU_FOOTER } from '../../shared/components/pageFooters';
import { clearSearchBatches } from '../../batch/actions/batchActionCreators';

const filterForAuthorizedRows = (rows, role) => {
  const filterForAuthorizedColumns = row => _.filter(row, col => col.allowedRoles.includes(role));
  return _.filter(_.map(rows, filterForAuthorizedColumns), row => row.length > 0);
};

export class CostingMainNavigationComponent extends React.Component {
  constructor(props) {
    super(props);

    this.timer = null;
  }

  componentDidMount() {
    const { setHeaderAndFooter, getCostingRoom } = this.props;

    getCostingRoom({});
    setHeaderAndFooter({
      header: MAIN_MENU,
      footer: MAIN_MENU_FOOTER
    });
  }

  onRunYieldModelLinkEnter() {
    this.props.runYieldModel();
  }

  createLinks() {
    const { changePath, role } = this.props;

    const links = [
      [
        {
          path: '/import-costs',
          icon: 'icon-plus',
          text: 'Import Costs',
          id: 'import-costs',
          isDisabled: false,
          onEnter: () => changePath('import-costs'),
          allowedRoles: ['ROLE_COSTING']
        },
        {
          path: '/yield-model/search',
          icon: 'icon-yield-model',
          text: 'Yield Model',
          id: 'yield-model',
          isDisabled: false,
          onEnter: () => changePath('/yield-model/search'),
          allowedRoles: ['ROLE_COSTING']
        }
      ],
      [
        {
          path: '/reports',
          icon: 'icon-setting',
          text: 'Reports',
          id: 'reports',
          isDisabled: false,
          onEnter: () => changePath('/reports'),
          allowedRoles: ['ROLE_COSTING']
        },
        {
          path: '/product',
          icon: 'icon-setting',
          text: 'Product',
          id: 'product',
          isDisabled: false,
          onEnter: () => changePath('/product/product-search'),
          allowedRoles: ['ROLE_COSTING']
        }
      ]
    ];

    return filterForAuthorizedRows(links, role);
  }

  getRunYieldModelTile() {
    return {
      path: '/run-yield-model',
      icon: 'icon-run-yield-model',
      text: (
        <div>
          <div>Run Yield Model</div>
        </div>
      ),
      id: 'create-yield-model',
      onEnter: this.onRunYieldModelLinkEnter.bind(this),
      allowedRoles: ['ROLE_COSTING']
    };
  }

  render() {
    return (
      <div className='page-content main-navigation'>
        <MainMenu links={this.createLinks()} />
      </div>
    );
  }
}

CostingMainNavigationComponent.propTypes = {
  changePath: PropTypes.func,

  getCostingRoom: PropTypes.func.isRequired,
  setHeaderAndFooter: PropTypes.func.isRequired,
  role: PropTypes.string,

  runYieldModel: PropTypes.func.isRequired
};

const mapStateToProps = state => {
  return {
    role: state.login.role
  };
};

const mapDispatchToProps = dispatch =>
  bindActionCreators(
    {
      changePath,
      getCostingRoom,
      runYieldModel,
      setHeaderAndFooter,
      clearSearchBatches
    },
    dispatch
  );

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(CostingMainNavigationComponent);
