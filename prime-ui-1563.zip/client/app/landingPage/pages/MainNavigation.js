import _ from 'lodash';
import React from 'react';
import PropTypes from 'prop-types';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import { destroy as clearForm } from 'redux-form';
import MainMenu from '../components/MainMenu';
import { changePath, getOperatingDates, setHeaderAndFooter } from '../../shared/actions/actions';
import {
  closePortionRoom,
  dismissPortionRoomWarning,
  getPortionRooms,
  openPortionRoom,
  runYieldModel
} from '../actions/landingPageActions';
import { PortionRoomState } from '../reducers/portionRoomReducer';
import InstructionBoard from '../../shared/components/InstructionBoard';
import { MAIN_MENU } from '../../shared/components/pageTitles';
import { MAIN_MENU_FOOTER } from '../../shared/components/pageFooters';
import { clearSearchBatches } from '../../batch/actions/batchActionCreators';
import { FORM as SEARCH_BATCHES_FORM } from '../../batch/pages/SearchBatch';
import FocusedModal from '../components/FocusedModal';

import config from '../../../../config/env';

export function ClosePortionRoomWarning(props) {
  const { onYes, onNo, warn, show } = props;
  if (!show || !warn) {
    return null;
  }

  const warningForUnfinishedOrders = 'Orders are still in progress. Still close the room?';

  return (
    <InstructionBoard
      prompt={warningForUnfinishedOrders}
      options={[{ message: 'Yes', onEnter: onYes }, { message: 'No', onEnter: onNo }]}
    />
  );
}

ClosePortionRoomWarning.propTypes = {
  warn: PropTypes.bool.isRequired,
  show: PropTypes.bool,
  unfinishableBatches: PropTypes.array,
  onYes: PropTypes.func.isRequired,
  onNo: PropTypes.func.isRequired
};

const filterForAuthorizedRows = (rows, role) => {
  const filterForAuthorizedColumns = row =>
    _.filter(row, col => {
      if (config.importCostsToggle) {
        return col.allowedRoles.includes(role);
      } else {
        return col.id !== 'import-costs' && col.allowedRoles.includes(role);
      }
    });

  return _.filter(_.map(rows, filterForAuthorizedColumns), row => row.length > 0);
};

export class MainNavigation extends React.Component {
  constructor(props) {
    super(props);

    this.timer = null;
    this.getScheduledOrdersTile = this.getScheduledOrdersTile.bind(this);
    this.getCutOrdersOverview = this.getCutOrdersOverview.bind(this);
  }

  componentDidMount() {
    const { getPortionRooms, getOperatingDates, setHeaderAndFooter } = this.props;

    getPortionRooms();
    getOperatingDates();
    setHeaderAndFooter({
      header: MAIN_MENU,
      footer: MAIN_MENU_FOOTER
    });
  }

  componentWillUnmount() {
    this.props.dismissPortionRoomWarning();
  }

  onPortionRoomLinkEnter() {
    const { portionRoomState } = this.props;
    if (portionRoomState === PortionRoomState.CAN_OPEN) {
      this.props.openPortionRoom();
    } else if (
      portionRoomState === PortionRoomState.CAN_CLOSE ||
      portionRoomState === PortionRoomState.CAN_APPROVE
    ) {
      this.props.closePortionRoom(false, false);
    }
  }

  onRunYieldModelLinkEnter() {
    this.props.runYieldModel();
  }

  todaysOrdersCutOrGrind() {
    const { currentPortionRoomType, changePath, portionRoomState } = this.props;

    return 'GRINDING' === currentPortionRoomType
      ? {
          path: '/grinding-orders',
          icon: 'icon-knife',
          text: 'Orders to Grind Today',
          id: 'orders-to-grind-today',
          isDisabled: portionRoomState !== PortionRoomState.CAN_CLOSE,
          onEnter: () => changePath('/grinding-orders'),
          allowedRoles: ['ROLE_ADMIN', 'ROLE_PORTION_ROOM_MEMBER']
        }
      : {
          path: '/cut/stations',
          icon: 'icon-knife',
          text: 'Orders to Cut Today',
          id: 'orders-to-cut-today',
          isDisabled: portionRoomState !== PortionRoomState.CAN_CLOSE,
          onEnter: () => changePath('/cut/stations'),
          allowedRoles: ['ROLE_ADMIN', 'ROLE_PORTION_ROOM_MEMBER']
        };
  }

  createBatch() {
    const { currentPortionRoomType, changePath, portionRoomState } = this.props;

    return currentPortionRoomType != 'GRINDING'
      ? {
          path: '/batch/create',
          icon: 'icon-plus',
          text: 'Create Batch',
          id: 'crate-batch',
          isDisabled: portionRoomState !== PortionRoomState.CAN_CLOSE,
          onEnter: () => {
            changePath('/batch/create');
          },
          allowedRoles: ['ROLE_ADMIN', 'ROLE_PORTION_ROOM_MEMBER']
        }
      : null;
  }

  searchBatch() {
    const { changePath, clearSearchBatches, clearForm } = this.props;

    return {
      path: '/batch/search',
      icon: 'icon-setting',
      text: 'Search Batch',
      id: 'search-batch',
      isDisabled: false,
      onEnter: () => {
        clearSearchBatches();
        clearForm(SEARCH_BATCHES_FORM);
        changePath('/batch/search');
      },
      allowedRoles: ['ROLE_ADMIN', 'ROLE_PORTION_ROOM_MEMBER']
    };
  }

  createLinks() {
    const { portionRoomState, changePath, openingOrClosing, role } = this.props;

    const links = [
      [
        {
          path: '',
          icon: 'icon-play',
          text: [PortionRoomState.CAN_CLOSE, PortionRoomState.CAN_APPROVE].includes(
            portionRoomState
          )
            ? 'Close Portion Room'
            : 'Open Portion Room',
          id: 'open-portion-room',
          isDisabled: openingOrClosing || portionRoomState === PortionRoomState.DISABLED,
          onEnter: this.onPortionRoomLinkEnter.bind(this),
          allowedRoles: ['ROLE_ADMIN']
        },
        {
          path: 'import-costs',
          icon: 'icon-plus',
          text: 'Import Costs',
          id: 'import-costs',
          isDisabled: false,
          onEnter: () => changePath('import-costs'),
          allowedRoles: ['ROLE_ADMIN']
        }
      ],
      [
        this.todaysOrdersCutOrGrind(),
        {
          path: '/meat-request/available-wip',
          icon: 'icon-steak',
          text: 'Request Meat',
          id: 'request-meat',
          isDisabled: false,
          onEnter: () => changePath('/meat-request/available-wip'),
          allowedRoles: ['ROLE_ADMIN', 'ROLE_PORTION_ROOM_MEMBER']
        },
        this.searchBatch()
      ].filter(col => !!col),
      [
        {
          path: '/pack/orders',
          icon: 'icon-packed-box',
          text: 'Orders to Pack Today',
          id: 'orders-to-pack-today',
          isDisabled: portionRoomState !== PortionRoomState.CAN_CLOSE,
          onEnter: () => changePath('/pack/orders'),
          allowedRoles: ['ROLE_ADMIN', 'ROLE_PORTION_ROOM_MEMBER']
        },
        {
          path: '/pack/pack-off-stock',
          icon: 'icon-box',
          text: 'Pack off Stock',
          id: 'pack-off-stock',
          isDisabled: portionRoomState !== PortionRoomState.CAN_CLOSE,
          onEnter: () => changePath('/pack/pack-off-stock'),
          allowedRoles: ['ROLE_ADMIN', 'ROLE_PORTION_ROOM_MEMBER']
        },
        {
          path: '/pack/pack-wip',
          icon: 'icon-box',
          text: 'Pack WIP',
          id: 'pack-wip',
          isDisabled: portionRoomState !== PortionRoomState.CAN_CLOSE,
          onEnter: () => changePath('/pack/pack-wip'),
          allowedRoles: ['ROLE_ADMIN', 'ROLE_PORTION_ROOM_MEMBER']
        }
      ],
      [this.getCutOrdersOverview(), this.getScheduledOrdersTile(), this.createBatch()].filter(
        col => !!col
      ),
      [
        {
          path: '/settings/profile',
          icon: 'icon-setting',
          text: 'Administration',
          id: 'administration',
          isDisabled: false,
          onEnter: () => changePath('/settings/profile'),
          allowedRoles: ['ROLE_ADMIN']
        },
        {
          path: '/yield-model/search',
          icon: 'icon-yield-model',
          text: 'Yield Model',
          id: 'yield-model',
          isDisabled: false,
          onEnter: () => changePath('/yield-model/search'),
          allowedRoles: ['ROLE_ADMIN']
        }
      ],
      [
        {
          path: '/product',
          icon: 'icon-setting',
          text: 'Product',
          id: 'product',
          isDisabled: false,
          onEnter: () => changePath('/product/product-search'),
          allowedRoles: ['ROLE_ADMIN', 'ROLE_PORTION_ROOM_MEMBER']
        },
        {
          path: '/reports',
          icon: 'icon-setting',
          text: 'Reports',
          id: 'reports',
          isDisabled: false,
          onEnter: () => changePath('/reports'),
          allowedRoles: ['ROLE_ADMIN']
        },
        {
          path: '/reprint',
          icon: 'icon-setting',
          text: 'Reprint',
          id: 'reprint',
          isDisabled: false,
          onEnter: () => changePath('/reprint/pack-off-label'),
          allowedRoles: ['ROLE_ADMIN', 'ROLE_PORTION_ROOM_MEMBER']
        }
      ]
    ];

    return filterForAuthorizedRows(links, role);
  }

  getCutOrdersOverview() {
    const { currentPortionRoomType, changePath } = this.props;
    return currentPortionRoomType === 'GRINDING'
      ? null
      : {
          path: '/cut-orders',
          icon: 'icon-dashboard',
          text: 'Cut Orders Overview',
          id: 'cut-orders-overview',
          isDisabled: false,
          onEnter: () => changePath('/cut-orders'),
          allowedRoles: ['ROLE_ADMIN', 'ROLE_PORTION_ROOM_MEMBER']
        };
  }

  getRunYieldModelTile() {
    return {
      path: '/run-yield-model',
      icon: 'icon-run-yield-model',
      text: (
        <div>
          <div>Run Yield Model</div>
        </div>
      ),
      id: 'create-yield-model',
      onEnter: this.onRunYieldModelLinkEnter.bind(this),
      allowedRoles: ['ROLE_ADMIN']
    };
  }

  getScheduledOrdersTile() {
    const { currentPortionRoomType, changePath, portionRoomState } = this.props;

    return 'CUTTING' === currentPortionRoomType
      ? {
          path: '/future-orders/cutting/schedule',
          icon: 'icon-file',
          text: 'Schedule Future Orders',
          id: 'schedule-future-orders',
          isDisabled: portionRoomState !== PortionRoomState.CAN_CLOSE,
          onEnter: () => changePath('/future-orders/cutting/schedule'),
          allowedRoles: ['ROLE_ADMIN', 'ROLE_PORTION_ROOM_MEMBER']
        }
      : {
          path: '/grinding/future-orders/schedule',
          icon: 'icon-file',
          text: 'Schedule Grind Orders',
          id: 'schedule-future-orders',
          isDisabled: false,
          onEnter: () =>
            setTimeout(() => {
              changePath('/grinding/future-orders/schedule');
            }, 1),
          allowedRoles: ['ROLE_ADMIN']
        };
  }

  closePortionRoomEvenWithUnfinishedOrders(evenUnfinishedOrders, evenSusPoUnavailable) {
    this.props.closePortionRoom(evenUnfinishedOrders, evenSusPoUnavailable);
    this.props.dismissPortionRoomWarning();
  }

  doNotClosePortionRoomAfterAll() {
    this.props.dismissPortionRoomWarning();
  }

  render() {
    const {
      unfinishableBatches,
      cannotClosePortionRoom,
      cannotCloseReason,
      showUnreceivedPurchaseOrdersModel,
      dismissPortionRoomWarning,
      showUnfinishedBatchModel,
      showSusPoServiceUnavailableModal
    } = this.props;

    const batchNumbersString = _.join(_.map(unfinishableBatches, batch => batch.batchNumber), ',');
    const warningForUnfinishableBatches = `Room cannot be closed with incomplete batch forms. Please review batch ${batchNumbersString}.`;

    return (
      <div className='page-content main-navigation'>
        <MainMenu links={this.createLinks()} />
        <FocusedModal
          open={showUnreceivedPurchaseOrdersModel}
          header={'Cannot close room!'}
          content='Cannot close room until all purchase order responses are received from SUS. Please wait 5 minutes and attempt to close the room again.'
          actions={[{ action: dismissPortionRoomWarning, text: 'OK', active: true }]}
        />
        <FocusedModal
          open={showUnfinishedBatchModel}
          header={'Cannot close room!'}
          content={warningForUnfinishableBatches}
          actions={[{ action: dismissPortionRoomWarning, text: 'OK', active: true }]}
        />
        <FocusedModal
          open={showSusPoServiceUnavailableModal}
          header={'Cannot close room!'}
          content={
            'PO service is unavailable, and POs in SUS need to be updated manually. Still close the room?'
          }
          actions={[
            {
              action: () => {
                this.closePortionRoomEvenWithUnfinishedOrders(true, true);
              },
              text: 'YES',
              active: true
            },
            {
              action: () => {
                dismissPortionRoomWarning();
              },
              text: 'NO',
              active: false
            }
          ]}
        />
        <ClosePortionRoomWarning
          warn={cannotClosePortionRoom && cannotCloseReason === 'UNFINISHED_PRODUCTION_ORDERS'}
          show={!showUnfinishedBatchModel}
          onYes={this.closePortionRoomEvenWithUnfinishedOrders.bind(this, true, false)}
          onNo={this.doNotClosePortionRoomAfterAll.bind(this)}
        />
      </div>
    );
  }
}

MainNavigation.propTypes = {
  changePath: PropTypes.func,
  currentPortionRoomType: PropTypes.string,
  getPortionRooms: PropTypes.func.isRequired,
  openPortionRoom: PropTypes.func,
  closePortionRoom: PropTypes.func,
  getOperatingDates: PropTypes.func.isRequired,
  dismissPortionRoomWarning: PropTypes.func,
  showModal: PropTypes.func,
  hideModal: PropTypes.func,

  portionRoomState: PropTypes.number.isRequired,
  cannotClosePortionRoom: PropTypes.bool,
  showUnfinishedBatchModel: PropTypes.bool,
  setHeaderAndFooter: PropTypes.func.isRequired,
  role: PropTypes.string,

  runYieldModel: PropTypes.func.isRequired,
  cannotCloseReason: PropTypes.string,
  openingOrClosing: PropTypes.bool.isRequired,
  showUnreceivedPurchaseOrdersModel: PropTypes.bool,
  showSusPoServiceUnavailableModal: PropTypes.bool,
  unfinishableBatches: PropTypes.array,
  clearSearchBatches: PropTypes.func.isRequired,
  clearForm: PropTypes.func.isRequired
};

const mapStateToProps = state => {
  const currentPortionRoomState = _.get(
    state.portionRoomsInfo.currentPortionRoom,
    'portionRoomState',
    PortionRoomState.DISABLED
  );

  const cannotClosePortionRoom = state.portionRoomsInfo.cannotClosePortionRoom;
  const cannotCloseReason = state.portionRoomsInfo.cannotCloseReason;
  return {
    portionRoomState: currentPortionRoomState,
    cannotClosePortionRoom,
    unfinishableBatches: state.portionRoomsInfo.unfinishableBatches,
    currentPortionRoomType: state.portionRoomsInfo.currentPortionRoom.roomType,
    openingOrClosing: state.portionRoomsInfo.openingOrClosing,
    role: state.login.role,
    cannotCloseReason,
    showUnreceivedPurchaseOrdersModel:
      cannotClosePortionRoom && cannotCloseReason === 'UNRECEIVED_PURCHASE_ORDERS',
    showUnfinishedBatchModel: cannotClosePortionRoom && cannotCloseReason === 'UNFINISHED_BATCHES',
    showSusPoServiceUnavailableModal:
      cannotClosePortionRoom && cannotCloseReason === 'UNPROCESSED_PURCHASE_ORDERS_OR_RECEIPTS'
  };
};

const mapDispatchToProps = dispatch =>
  bindActionCreators(
    {
      changePath,
      getPortionRooms,
      getOperatingDates,
      openPortionRoom,
      closePortionRoom,
      runYieldModel,
      dismissPortionRoomWarning,
      setHeaderAndFooter,
      clearSearchBatches,
      clearForm
    },
    dispatch
  );

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(MainNavigation);
