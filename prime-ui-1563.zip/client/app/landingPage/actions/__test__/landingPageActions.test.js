import {
  getTestStateForGrindingRoom,
  getTestStateForRoomA
} from '../../../../test-factories/testState';
import portionRoomsResources from '../../../shared/api/portionRoomsResources';
import {
  closePortionRoom,
  dismissPortionRoomWarning,
  getCostingRoom,
  getPortionRooms,
  openPortionRoom,
  resetCurrentPortionRoom,
  selectPortionRoom
} from '../landingPageActions';
import portionRoomFactory, {
  COSTING_PORTION_ROOM
} from '../../../../test-factories/portionRoomFactory';

import {
  CANNOT_CLOSE_PORTION_ROOM,
  CLOSE_PORTION_ROOM,
  OPEN_OR_CLOSE_PORTION_ROOM_REQUESTED,
  OPEN_PORTION_ROOM,
  RESET_CURRENT_PORTION_ROOM,
  UPDATE_CURRENT_PORTION_ROOM,
  UPDATE_PORTION_ROOMS,
  USER_DISMISSED_CLOSE_WARNING
} from '../landingPageActionTypes';

jest.mock('../../../shared/api/portionRoomsResources');
jest.mock('../../../shared/api/yieldModelResources');

describe('landingPageActions', () => {
  let dispatch, portionRoom;

  beforeEach(() => {
    dispatch = jest.fn();
    portionRoom = portionRoomFactory.build();
  });

  describe('getPortionRooms()', () => {
    const response = {
      data: [portionRoom]
    };

    test('should call getPortionRooms from openPortionRoomResources and dispatch UPDATE_PORTION_ROOMS', async () => {
      portionRoomsResources.getPortionRooms.mockResolvedValue(response);

      await getPortionRooms()(dispatch);

      jestExpect(dispatch).toBeCalledWith({
        type: UPDATE_PORTION_ROOMS,
        payload: response.data
      });
    });
  });

  describe('closePortionRoom()', () => {
    test('should successfully close portion room', async () => {
      portionRoomsResources.closePortionRoom.mockResolvedValue({
        data: { closed: true, batches: [] }
      });

      await closePortionRoom(false, false)(dispatch, getTestStateForRoomA);
      jestExpect(dispatch).toBeCalledWith({
        type: OPEN_OR_CLOSE_PORTION_ROOM_REQUESTED
      });

      jestExpect(dispatch).toBeCalledWith({
        type: CLOSE_PORTION_ROOM
      });
    });

    test('should not close portion room when response return false', async () => {
      portionRoomsResources.closePortionRoom.mockResolvedValue({
        data: { closed: false, batches: [] }
      });

      await closePortionRoom(false, false)(dispatch, getTestStateForRoomA);
      jestExpect(dispatch).toBeCalledWith({
        type: OPEN_OR_CLOSE_PORTION_ROOM_REQUESTED
      });

      jestExpect(dispatch).toBeCalledWith({
        type: CANNOT_CLOSE_PORTION_ROOM,
        payload: { closed: false, batches: [] }
      });
    });
  });

  describe('openPortionRoom()', () => {
    test('should call openPortionRoom api, dispatch OPEN_PORTION_ROOM and UPDATE_PORTION_ROOMS, STOCK_ALLOCATION_ALERT When room is grinding', async () => {
      portionRoomsResources.openPortionRoom.mockResolvedValue({ data: [portionRoom] });
      portionRoomsResources.getStockAllocationAlert.mockResolvedValue({ data: true });

      await openPortionRoom()(dispatch, getTestStateForRoomA);

      jestExpect(dispatch).toBeCalledWith({
        type: OPEN_OR_CLOSE_PORTION_ROOM_REQUESTED
      });

      jestExpect(dispatch).toBeCalledWith({
        type: OPEN_PORTION_ROOM
      });

      jestExpect(dispatch).toBeCalledWith({
        type: UPDATE_PORTION_ROOMS,
        payload: [portionRoom]
      });

      jestExpect(dispatch).toBeCalledWith({
        type: 'ERROR',
        payload: 'STOCK_ALLOCATION_ALERT'
      });
    });

    test('should not call ERROR if stock alert response is false', async () => {
      portionRoomsResources.openPortionRoom.mockResolvedValue({ data: [portionRoom] });
      portionRoomsResources.getStockAllocationAlert.mockResolvedValue({ data: false });

      await openPortionRoom()(dispatch, getTestStateForRoomA);

      jestExpect(dispatch).toBeCalledWith({
        type: OPEN_OR_CLOSE_PORTION_ROOM_REQUESTED
      });

      jestExpect(dispatch).toBeCalledWith({
        type: OPEN_PORTION_ROOM
      });

      jestExpect(dispatch).toBeCalledWith({
        type: UPDATE_PORTION_ROOMS,
        payload: [portionRoom]
      });
    });

    test('should call openPortionRoom api, dispatch OPEN_PORTION_ROOM and UPDATE_PORTION_ROOMS When room is grinding', async () => {
      portionRoomsResources.openPortionRoom.mockResolvedValue({ data: [portionRoom] });

      await openPortionRoom()(dispatch, getTestStateForGrindingRoom);

      jestExpect(dispatch).toBeCalledWith({
        type: OPEN_OR_CLOSE_PORTION_ROOM_REQUESTED
      });

      jestExpect(dispatch).toBeCalledWith({
        type: OPEN_PORTION_ROOM
      });

      jestExpect(dispatch).toBeCalledWith({
        type: UPDATE_PORTION_ROOMS,
        payload: [portionRoom]
      });

      jestExpect(portionRoomsResources.getStockAllocationAlert).not.toBeCalledWith({
        type: 'ERROR',
        payload: 'STOCK_ALLOCATION_ALERT'
      });
    });
  });

  describe('dismiss the portion room warning', () => {
    test('should notify page to dismiss portion room warning', () => {
      dispatch(dismissPortionRoomWarning());

      jestExpect(dispatch).toBeCalledWith({
        type: USER_DISMISSED_CLOSE_WARNING
      });
    });
  });

  describe('selectPortionRoom()', () => {
    test('should update current portion room and dispatch UPDATE_CURRENT_PORTION_ROOM', () => {
      dispatch(selectPortionRoom(portionRoom));

      jestExpect(dispatch).toBeCalledWith({
        type: UPDATE_CURRENT_PORTION_ROOM,
        payload: portionRoom
      });
    });
  });

  describe('resetCurrentPortionRoom()', () => {
    test('should reset current portion room and dispatch RESET_CURRENT_PORTION_ROOM', () => {
      dispatch(resetCurrentPortionRoom());

      jestExpect(dispatch).toBeCalledWith({
        type: RESET_CURRENT_PORTION_ROOM
      });
    });
  });

  describe('getCostingRoom()', () => {
    test('should get costing room from resources and then update current portion room', async () => {
      const costingRoom = portionRoomFactory.build(COSTING_PORTION_ROOM);
      portionRoomsResources.getCostingRoom.mockResolvedValue({ data: costingRoom });

      await getCostingRoom()(dispatch);

      jestExpect(dispatch).toBeCalledWith({
        type: UPDATE_CURRENT_PORTION_ROOM,
        payload: costingRoom
      });
    });
  });
});
