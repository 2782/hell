import MenuOption from '../MenuOption';
import React from 'react';
import { mount } from 'enzyme';

describe('menuOption', () => {
  let icon;
  let text;
  let id;

  beforeEach(() => {
    id = '0-0';
    icon = 'icon-knife';
    text = 'Order to cut';
  });

  test('should have focused class when this menu option is focused', () => {
    let wrapper = mount(<MenuOption id={id} icon={icon} text={text} isFocused={true} />);

    let element = wrapper.find('.focused');
    jestExpect(element.length).toEqual(1);
  });

  test('should not have focused class when this menu option is not focused', () => {
    let wrapper = mount(<MenuOption id={id} icon={icon} text={text} isFocused={false} />);

    let element = wrapper.find('.focused');
    jestExpect(element.length).toEqual(0);
  });

  test('should have disabled class when this menu option is disabled', () => {
    let wrapper = mount(
      <MenuOption id={id} icon={icon} text={text} isFocused={true} isDisabled={true} />
    );

    let element = wrapper.find('.disabled');
    jestExpect(element.length).toEqual(1);
  });

  test('should not have disabled class when this menu option is not disabled', () => {
    let wrapper = mount(
      <MenuOption id={id} icon={icon} text={text} isFocused={false} isDisabled={false} />
    );

    let element = wrapper.find('.disabled');
    jestExpect(element.length).toEqual(0);
  });

  test('should call onClick method when click and is not disable', () => {
    const onClick = jest.fn();
    let wrapper = mount(
      <MenuOption
        id={id}
        icon={icon}
        onClick={onClick}
        text={text}
        isFocused={false}
        isDisabled={false}
      />
    );

    wrapper.find('.menu-option').simulate('click');
    jestExpect(onClick).toHaveBeenCalled();
  });

  test('should not call onClick method when click and is disable', () => {
    const onClick = jest.fn();
    let wrapper = mount(
      <MenuOption
        id={id}
        icon={icon}
        onClick={onClick}
        text={text}
        isFocused={false}
        isDisabled={true}
      />
    );

    wrapper.find('.menu-option').simulate('click');
    jestExpect(onClick).not.toHaveBeenCalled();
  });
});
