import React from 'react';
import PropTypes from 'prop-types';

const MenuOption = props => {
  const { id, icon, text, isFocused, isDisabled, onClick } = props;

  return (
    <div
      id={id}
      onClick={isDisabled ? () => {} : onClick}
      className={`menu-option ${isFocused ? 'focused' : ''} ${isDisabled ? 'disabled' : ''} `}
    >
      <span className='icon-wrapper'>
        <i className={`icon ${icon}`} />
      </span>
      <span className='text'>{text}</span>
    </div>
  );
};

MenuOption.propTypes = {
  icon: PropTypes.string.isRequired,
  text: PropTypes.oneOfType([PropTypes.string, PropTypes.object]),
  isFocused: PropTypes.bool,
  isDisabled: PropTypes.bool,
  onClick: PropTypes.func,
  id: PropTypes.string.isRequired
};

export default MenuOption;
