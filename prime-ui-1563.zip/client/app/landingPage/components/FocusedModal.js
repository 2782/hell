import React from 'react';
import PropTypes from 'prop-types';
import { Header, Modal } from 'semantic-ui-react';
import FocusedModalButton from './FocusedModalButton';
import * as _ from 'lodash';

export default class FocusedModal extends React.Component {
  constructor(props) {
    super(props);
  }

  render() {
    const { open, content, actions, header } = this.props;

    const buttonActions = _.map(actions, buttonAction => {
      return (
        <FocusedModalButton
          key={buttonAction.text}
          action={buttonAction.action}
          buttonText={buttonAction.text}
          active={buttonAction.active}
        />
      );
    });

    return (
      <Modal open={open}>
        <Header>{header}</Header>
        <Modal.Content>{content}</Modal.Content>
        <Modal.Actions>{buttonActions}</Modal.Actions>
      </Modal>
    );
  }
}

FocusedModal.propTypes = {
  open: PropTypes.bool.isRequired,
  header: PropTypes.string.isRequired,
  content: PropTypes.string.isRequired,
  actions: PropTypes.array.isRequired
};
