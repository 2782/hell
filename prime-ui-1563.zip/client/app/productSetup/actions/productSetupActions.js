import piecesPackagesResources from '../../shared/api/piecesPackagesResources';
import productResources from '../../shared/api/productResources';
import {
  PRODUCT_SETUP_GET_ALL_PIECES_PACKAGES,
  PRODUCT_SETUP_ALLERGENS_RETRIEVED
} from './productSetupActionTypes';

export const getAllergens = () => dispatch => {
  return productResources.getAllergens().then(response => {
    dispatch({
      type: PRODUCT_SETUP_ALLERGENS_RETRIEVED,
      payload: response.data
    });
  });
};

export const getAllPiecesPackages = () => dispatch => {
  return piecesPackagesResources.getAllPiecesPackages(response => {
    dispatch({
      type: PRODUCT_SETUP_GET_ALL_PIECES_PACKAGES,
      payload: response.data
    });
  });
};
