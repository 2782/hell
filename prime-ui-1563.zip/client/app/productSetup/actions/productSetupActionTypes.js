export const PRODUCT_SETUP_GET_ALL_PIECES_PACKAGES = 'product-setup/getAllPiecesPackage';
export const PRODUCT_SETUP_ALLERGENS_RETRIEVED = 'product-setup/getAllergens';
