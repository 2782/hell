import FormElement from '../../shared/FormElement';
import { Divider, Form } from 'semantic-ui-react';
import { Field } from 'redux-form';
import React from 'react';

export const GrindSpecificFields = () => {
  const packInstructionsAOptions = [
    {
      key: 0,
      text: 'Fresh',
      value: 'Fresh'
    },
    {
      key: 1,
      text: 'Frozen',
      value: 'Frozen'
    }
  ];

  const packInstructionsBOptions = [
    {
      key: 0,
      text: 'Gas',
      value: 'Gas'
    },
    {
      key: 1,
      text: 'No Gas',
      value: 'No Gas'
    }
  ];

  const tenderformOptions = [
    {
      key: 0,
      text: 'Yes',
      value: true
    },
    {
      key: 1,
      text: 'No',
      value: false
    }
  ];

  const grindSizeOptions = [
    {
      key: 0,
      text: '3/32',
      value: '3/32'
    },
    {
      key: 1,
      text: '3/16',
      value: '3/16'
    },
    {
      key: 2,
      text: '3/8',
      value: '3/8'
    },
    {
      key: 3,
      text: '1/2',
      value: '1/2'
    }
  ];

  return (
    <div>
      <Form.Group>
        <Field
          component={FormElement}
          name='packInstructionA'
          className='packInstructionA'
          as={Form.Select}
          options={packInstructionsAOptions}
          type='text'
          label='Pack Instructions'
          width={4}
        />
        <Field
          component={FormElement}
          name='packInstructionB'
          className='packInstructionB'
          as={Form.Select}
          options={packInstructionsBOptions}
          type='text'
          label='&nbsp;'
          width={4}
        />

        <Field
          component={FormElement}
          name='tenderform'
          as={Form.Select}
          options={tenderformOptions}
          type='text'
          label='Tenderform'
          width={8}
        />
      </Form.Group>

      <Divider hidden />

      <Form.Group>
        <Field
          component={FormElement}
          name='grindSize'
          as={Form.Select}
          options={grindSizeOptions}
          type='text'
          label='Grind Size'
          width={8}
        />

        <Field
          component={FormElement}
          name='diameter'
          as={Form.Input}
          type='text'
          label='Diameter'
          width={8}
        />
      </Form.Group>

      <Divider hidden />

      <Form.Group>
        <Field
          component={FormElement}
          name='thickness'
          as={Form.Input}
          type='text'
          label='Thickness'
          width={8}
        />

        <Field
          component={FormElement}
          name='plateUsed'
          as={Form.Input}
          type='text'
          label='Plate Used'
          width={8}
        />
      </Form.Group>

      <Form.Group>
        <Field
          component={FormElement}
          name='casesPerTray'
          as={Form.Input}
          type='text'
          label='Cases Per Tray'
          width={8}
        />
      </Form.Group>
    </div>
  );
};
