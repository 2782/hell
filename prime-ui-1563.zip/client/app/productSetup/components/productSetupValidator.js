import _ from 'lodash';
import { SubmissionError } from 'redux-form';
import {
  alphanumericOrCommaOrDot,
  alphanumericOrCommaOrDotOrSpaceOrHyphen,
  exactLength,
  isGreaterThan,
  maxLength,
  nonNegativeNumber,
  positiveNumber,
  productExists,
  required,
  validate,
  wholeNumber
} from '../../shared/formValidations';

const validateSubmission = (values, props) => {
  const {
    productCode,
    tableCode,
    piecesPackageId,
    grindSpecific: { grindSize, diameter, thickness, plateUsed, casesPerTray },
    ingredientsStatement,
    byproductOnly,
    byproductOnlyCost,
    fixWeight,
    minWeight,
    maxWeight
  } = values;

  const { productCodeExists, selectedRoomType, product } = props;
  let errors = {};

  errors = validate(errors, productCode, 'productCode', [
    required,
    wholeNumber,
    exactLength(7),
    productExists(productCodeExists)
  ]);
  errors = validate(errors, tableCode, 'tableCode', [required, positiveNumber]);

  const piecesPackageValidations = [positiveNumber];
  !byproductOnly && piecesPackageValidations.push(required);

  errors = validate(errors, piecesPackageId, 'piecesPackageId', piecesPackageValidations);

  errors = validate(errors, ingredientsStatement, 'ingredientsStatement', [maxLength(700)]);

  if (byproductOnly) {
    errors = validate(errors, byproductOnlyCost, 'byproductOnlyCost', [
      required,
      nonNegativeNumber
    ]);
  }

  if (selectedRoomType === 'GRINDING') {
    let grindingErrors = {};
    grindingErrors = validate(grindingErrors, grindSize, 'grindSize', [required]);
    grindingErrors = validate(grindingErrors, diameter, 'diameter', [
      alphanumericOrCommaOrDot,
      maxLength(50)
    ]);
    grindingErrors = validate(grindingErrors, thickness, 'thickness', [
      alphanumericOrCommaOrDot,
      maxLength(50)
    ]);
    grindingErrors = validate(grindingErrors, plateUsed, 'plateUsed', [
      alphanumericOrCommaOrDotOrSpaceOrHyphen,
      maxLength(50)
    ]);
    grindingErrors = validate(grindingErrors, casesPerTray, 'casesPerTray', [
      required,
      positiveNumber,
      wholeNumber
    ]);
    errors = { ...errors, grindSpecific: { ...grindingErrors } };
  }

  if (product.category === 'FIXED') {
    errors = validate(errors, fixWeight, 'fixWeight', [required, positiveNumber]);
  }

  if (product.category === 'CATCH') {
    errors = validate(errors, maxWeight, 'maxWeight', [required, positiveNumber]);
    errors = validate(errors, minWeight, 'minWeight', [required, positiveNumber]);

    if (!errors.maxWeight && !errors.minWeight) {
      errors = validate(errors, maxWeight, 'maxWeight', [
        isGreaterThan(minWeight, 'Max should be greater than min')
      ]);
    }
  }
  const { grindSpecific, ...remainingErrors } = errors;

  if (!_.isEmpty(remainingErrors) || !_.isEmpty(grindSpecific)) {
    throw new SubmissionError(Object.assign({}, errors, { _error: 'Submission Failed!' }));
  }
};

const processFieldError = (errorDetails, errors) => {
  let fieldErrors = {};
  errorDetails
    .filter(errorDetail => 'field' === errorDetail.type)
    .forEach(errorDetail => {
      fieldErrors = _.set(fieldErrors, errorDetail.field, errorDetail.issue);
    });
  return { ...errors, ...fieldErrors };
};

const processModelErrors = (errorDetails, errors) => {
  let modelErrors = {};
  errorDetails
    .filter(errorDetail => 'model' === errorDetail.type)
    .forEach(errorDetail => {
      const type = errorDetail.value;

      if (type === 'HasGrindSize') {
        modelErrors = { ...modelErrors, grindSize: errorDetail.issue };
      }
    });
  return { ...errors, ...modelErrors };
};

export const processErrorResponse = errorResponse => {
  let errors = {};
  const errorDetails = _.get(errorResponse, 'error.details', []);

  errors = processFieldError(errorDetails, errors);
  errors = processModelErrors(errorDetails, errors);

  if (!_.isEmpty(errors)) {
    throw new SubmissionError({ ...errors, _error: 'Submission Failed!' });
  }
};

export const validateMinMaxRetailWeight = values => {
  let errors = {};

  if (!values.isRetail || !values.retailSpecific) {
    return errors;
  }

  const {
    retailSpecific: { minWeight, maxWeight }
  } = values;

  if (Boolean(maxWeight) && parseFloat(minWeight) >= parseFloat(maxWeight)) {
    errors = { ...errors, retailSpecific: { minWeight: 'Invalid weight.' } };
  }

  return errors;
};

export default {
  validateSubmission
};
