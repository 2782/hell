import Validator, {
  processErrorResponse,
  validateMinMaxRetailWeight
} from '../productSetupValidator';
import productFactory from '../../../../test-factories/productFactory';
import { randomString } from '../../../../test-factories/utils';

const catchProduct = productFactory.build();
const fixProduct = productFactory.build({ category: 'FIXED' });

describe('productSetupValidator', () => {
  describe('should verify required fields', () => {
    test('valid form values should not throw submission error', () => {
      const values = {
        minWeight: 10,
        maxWeight: 12,
        piecesPackageId: 1,
        tableCode: 100,
        productCode: '4102218',
        grindSpecific: {
          diameter: 'df',
          thickness: 'adsf',
          plateUsed: 'asdf',
          casesPerTray: 10,
          grindSize: 'asdf'
        },
        byproductOnly: false,
        byproductOnlyCost: ''
      };

      Validator.validateSubmission(values, {
        productCodeExists: true,
        selectedRoomType: 'GRINDING',
        product: catchProduct
      });
    });

    test('should not require pieces package for byproduct only products', () => {
      const values = {
        minWeight: 10,
        maxWeight: 12,
        tableCode: 100,
        productCode: '4102218',
        // no pieces package
        grindSpecific: {
          diameter: 'df',
          thickness: 'adsf',
          plateUsed: 'asdf',
          casesPerTray: 10,
          grindSize: 'asdf'
        },
        byproductOnly: true,
        byproductOnlyCost: 20
      };

      Validator.validateSubmission(values, {
        productCodeExists: true,
        selectedRoomType: 'GRINDING',
        product: catchProduct
      });
    });

    test('should validate fields for a catch weight product', () => {
      const values = { grindSpecific: {} };

      try {
        Validator.validateSubmission(values, {
          productCodeExists: true,
          product: catchProduct,
          byProductOnly: false
        });
      } catch ({ errors }) {
        jestExpect(errors).toEqual(
          jestExpect.objectContaining({
            productCode: 'Required',
            tableCode: 'Required',
            maxWeight: 'Required',
            piecesPackageId: 'Required',
            _error: 'Submission Failed!'
          })
        );
      }
    });

    test('should verify required fields for fix weight product', () => {
      const values = { grindSpecific: {} };

      try {
        Validator.validateSubmission(values, {
          productCodeExists: true,
          product: fixProduct,
          byProductOnly: false
        });
      } catch ({ errors }) {
        jestExpect(errors).toEqual(
          jestExpect.objectContaining({
            productCode: 'Required',
            tableCode: 'Required',
            fixWeight: 'Required',
            piecesPackageId: 'Required',
            _error: 'Submission Failed!'
          })
        );
      }
    });

    test('should not require pieces package id if product is byproduct only', () => {
      const values = { productCode: '123', grindSpecific: {} };

      try {
        Validator.validateSubmission(values, {
          productCodeExists: true,
          product: fixProduct,
          byproductOnly: false
        });
      } catch ({ errors }) {
        jestExpect(errors).toMatchObject({
          piecesPackageId: 'Required',
          _error: 'Submission Failed!'
        });
      }
    });
  });

  test('should validate that byproduct cost is required if byproduct only flag is true', () => {
    const values = {
      byproductOnly: true,
      byproductOnlyCost: '',
      grindSpecific: {}
    };

    try {
      Validator.validateSubmission(values, { product: {} });
      jest.fail('Expected SubmissionError to be thrown.');
    } catch (e) {
      jestExpect(e.errors.byproductOnlyCost).toEqual('Required');
      jestExpect(e.errors._error).toEqual('Submission Failed!');
    }
  });

  test('should validate that byproduct cost is non-negative', () => {
    const values = {
      byproductOnly: true,
      byproductOnlyCost: '-1.256',
      grindSpecific: {}
    };

    try {
      Validator.validateSubmission(values, { product: {} });
      jest.fail('Expected SubmissionError to be thrown.');
    } catch (e) {
      jestExpect(e.errors.byproductOnlyCost).toEqual('Must be a positive number');
      jestExpect(e.errors._error).toEqual('Submission Failed!');
    }
  });

  test('should not validate byproductCost of 0', () => {
    const values = {
      byproductOnly: true,
      byproductOnlyCost: '0',
      grindSpecific: {}
    };

    try {
      Validator.validateSubmission(values, { product: {} });
      jest.fail('Expected SubmissionError to be thrown.');
    } catch (e) {
      jestExpect(e.errors.byproductOnlyCost).toBeUndefined();
    }
  });

  test('should not validate positive decimal byproductCost', () => {
    const values = {
      byproductOnly: true,
      byproductOnlyCost: '5.463',
      grindSpecific: {}
    };

    try {
      Validator.validateSubmission(values, { product: {} });
      jest.fail('Expected SubmissionError to be thrown.');
    } catch (e) {
      jestExpect(e.errors.byproductOnlyCost).toBeUndefined();
    }
  });

  test('should validate that catchProduct code are exactly 7 characters', () => {
    const values = {
      productCode: '0123123123',
      tableCode: '99',
      piecesPackageId: '1234567890',
      casesPerTray: '3',
      grindSpecific: {}
    };

    try {
      Validator.validateSubmission(values, {
        productCodeExists: true,
        product: catchProduct
      });
      jest.fail('Expected SubmissionError to be thrown.');
    } catch (e) {
      jestExpect(e.errors.productCode).toEqual('Must be 7 characters');
      jestExpect(e.errors._error).toEqual('Submission Failed!');
    }
  });

  test('should validate that tableCode and piecesPackageId is not negative', () => {
    const values = {
      productCode: '0078889',
      tableCode: '-99',
      piecesPackageId: '-89',
      casesPerTray: '3',
      grindSpecific: {}
    };

    try {
      Validator.validateSubmission(values, {
        productCodeExists: true,
        product: catchProduct
      });
      jest.fail('Expected SubmissionError to be thrown.');
    } catch ({ errors }) {
      jestExpect(errors).toEqual(
        jestExpect.objectContaining({
          tableCode: 'Must be a positive number',
          piecesPackageId: 'Must be a positive number',
          _error: 'Submission Failed!'
        })
      );
    }
  });

  test('should validate grind specific fields when selected room type is GRINDING', () => {
    const values = {
      productCode: '0078889',
      tableCode: '99',
      piecesPackageId: '89',
      grindSpecific: {
        diameter: '89./2^&',
        thickness: randomString(51),
        plateUsed: '3,4AB 123.23 - 01',
        casesPerTray: '-3'
      }
    };

    try {
      Validator.validateSubmission(values, {
        productCodeExists: true,
        selectedRoomType: 'GRINDING',
        product: catchProduct
      });
      jest.fail('Expected SubmissionError to be thrown.');
    } catch ({ errors }) {
      jestExpect(errors).toEqual(
        jestExpect.objectContaining({
          grindSpecific: jestExpect.objectContaining({
            grindSize: 'Required',
            diameter: 'Only numbers, letters, comma or period',
            thickness: 'Maximum 50 characters',
            casesPerTray: 'Must be a positive number'
          }),
          _error: 'Submission Failed!'
        })
      );
    }
  });

  test('should validate cases Per tray as whole number', () => {
    const values = {
      productCode: '0078889',
      tableCode: '99',
      piecesPackageId: '89',
      grindSpecific: {
        diameter: '2.5',
        thickness: randomString(2),
        plateUsed: 'Regular',
        casesPerTray: '4.3'
      }
    };

    try {
      Validator.validateSubmission(values, {
        productCodeExists: true,
        selectedRoomType: 'GRINDING',
        product: catchProduct
      });
      jest.fail('Expected SubmissionError to be thrown.');
    } catch ({ errors }) {
      jestExpect(errors.grindSpecific.casesPerTray).toEqual('Only whole number characters');
      jestExpect(errors._error).toEqual('Submission Failed!');
    }
  });

  test('should validate that catchProduct max/min weight should be a positive number', () => {
    const values = {
      productCode: '0078889',
      tableCode: '99',
      maxWeight: -1,
      minWeight: -2,
      piecesPackageId: '1234567890',
      grindSpecific: {}
    };

    try {
      Validator.validateSubmission(values, {
        productCodeExists: true,
        product: catchProduct
      });
      jest.fail('Expected SubmissionError to be thrown.');
    } catch ({ errors }) {
      jestExpect(errors.maxWeight).toEqual('Must be a positive number');
      jestExpect(errors.minWeight).toEqual('Must be a positive number');
    }
  });

  test('should validate that catchProduct max weight should be greater than min weight', () => {
    const values = {
      productCode: '0078889',
      tableCode: '99',
      maxWeight: 11,
      minWeight: 13,
      piecesPackageId: '1234567890',
      grindSpecific: {}
    };

    try {
      Validator.validateSubmission(values, {
        productCodeExists: true,
        product: catchProduct
      });
      jest.fail('Expected SubmissionError to be thrown.');
    } catch ({ errors }) {
      jestExpect(errors.maxWeight).toEqual('Max should be greater than min');
    }
  });

  test('should validate that catchProduct max weight should not equal min weight', () => {
    const values = {
      productCode: '0078889',
      tableCode: '99',
      maxWeight: 13,
      minWeight: 13,
      piecesPackageId: '1234567890',
      grindSpecific: {}
    };

    try {
      Validator.validateSubmission(values, {
        productCodeExists: true,
        product: catchProduct
      });
      jest.fail('Expected SubmissionError to be thrown.');
    } catch ({ errors }) {
      jestExpect(errors.maxWeight).toEqual('Max should be greater than min');
    }
  });

  test('should validate that catchProduct does not exist', () => {
    const values = {
      productCode: '0078889',
      tableCode: '99',
      piecesPackageId: '1234567890',
      grindSpecific: {}
    };

    try {
      Validator.validateSubmission(values, {
        productCodeExists: false,
        product: catchProduct
      });
      jest.fail('Expected SubmissionError to be thrown.');
    } catch ({ errors }) {
      jestExpect(errors.productCode).toEqual('Invalid Item Number');
      jestExpect(errors._error).toEqual('Submission Failed!');
    }
  });

  describe('#processErrorResponse', () => {
    test('should throw exception when having errors', () => {
      const errorResponse = {
        error: {
          details: [
            {
              field: 'piecesPackageId',
              value: 'null',
              issue: 'may not be null',
              type: 'field'
            },
            {
              field: 'productSetupRequest',
              value: 'HasGrindSize',
              issue: 'GrindSize is Required',
              type: 'model'
            }
          ]
        }
      };

      try {
        processErrorResponse(errorResponse);
      } catch ({ errors }) {
        jestExpect(errors.piecesPackageId).toEqual('may not be null');
        jestExpect(errors.grindSize).toEqual('GrindSize is Required');
        jestExpect(errors._error).toEqual('Submission Failed!');
      }
    });

    test('should throw exception when invalid cases per tray', () => {
      const errorResponse = {
        error: {
          details: [
            {
              field: 'grindSpecific.casesPerTray',
              value: '13',
              issue: 'must be less than or equal to 9',
              location: 'body',
              type: 'field'
            },
            {
              field: 'grindSpecific.grindSize',
              value: '-13',
              issue: 'other error',
              location: 'body',
              type: 'field'
            }
          ]
        }
      };

      try {
        processErrorResponse(errorResponse);
      } catch ({ errors }) {
        jestExpect(errors.grindSpecific.casesPerTray).toEqual('must be less than or equal to 9');
        jestExpect(errors.grindSpecific.grindSize).toEqual('other error');
        jestExpect(errors._error).toEqual('Submission Failed!');
      }
    });

    test('should throw submission error when text is over 700 characters', () => {
      const text = 'a'.repeat(701);

      const values = {
        productCode: '0078889',
        tableCode: '99',
        piecesPackageId: '1234567890',
        ingredientsStatement: text,
        grindSpecific: {}
      };

      try {
        Validator.validateSubmission(values, {
          productCodeExists: true,
          product: catchProduct
        });
        jest.fail('Expected SubmissionError to be thrown.');
      } catch ({ errors }) {
        jestExpect(errors.ingredientsStatement).toEqual('Maximum 700 characters');
        jestExpect(errors._error).toEqual('Submission Failed!');
      }
    });
  });

  describe('retailSpecificFields', () => {
    test('should validate min weight less than max weight when retail fields are showing', () => {
      const values = {
        other: 'abc',
        isRetail: true,
        retailSpecific: {
          price: 1,
          tare: 919990101003002,
          minWeight: 5,
          maxWeight: 1
        }
      };

      const result = validateMinMaxRetailWeight(values);

      jestExpect(result).toEqual(
        jestExpect.objectContaining({
          retailSpecific: {
            minWeight: 'Invalid weight.'
          }
        })
      );
    });

    test('should validate min weight equal to max weight when retail fields are showing', () => {
      const values = {
        other: 'abc',
        isRetail: true,
        retailSpecific: {
          price: 1,
          tare: 919990101003002,
          minWeight: 7,
          maxWeight: 7
        }
      };

      const result = validateMinMaxRetailWeight(values);

      jestExpect(result).toEqual(
        jestExpect.objectContaining({
          retailSpecific: {
            minWeight: 'Invalid weight.'
          }
        })
      );
    });

    test('should not validate when isRetail is false', () => {
      const values = {
        other: 'abc',
        isRetail: false,
        retailSpecific: {
          price: 1,
          tare: 919990101003002,
          minWeight: 5,
          maxWeight: 1
        }
      };

      const result = validateMinMaxRetailWeight(values);

      jestExpect(result).toEqual({});
    });

    test('should not validate when max Weight is not present', () => {
      const values = {
        other: 'abc',
        isRetail: true,
        retailSpecific: {
          price: 1,
          tare: 919990101003002,
          minWeight: 5
        }
      };

      const result = validateMinMaxRetailWeight(values);

      jestExpect(result).toEqual({});
    });

    test('should be type agnostic', () => {
      const values = {
        other: 'abc',
        isRetail: true,
        retailSpecific: {
          price: 1,
          tare: 919990101003002,
          minWeight: '10.23',
          maxWeight: '1.23'
        }
      };

      const result = validateMinMaxRetailWeight(values);

      jestExpect(result).toEqual(
        jestExpect.objectContaining({
          retailSpecific: {
            minWeight: 'Invalid weight.'
          }
        })
      );
    });

    test('should handle absent retail specific fields', () => {
      const values = {
        other: 'abc',
        isRetail: true
      };

      const result = validateMinMaxRetailWeight(values);

      jestExpect(result).toEqual(jestExpect.objectContaining({}));
    });
  });
});
