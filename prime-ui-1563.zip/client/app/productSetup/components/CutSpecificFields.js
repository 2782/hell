import FormElement from '../../shared/FormElement';
import { Form } from 'semantic-ui-react';
import { Field } from 'redux-form';
import React from 'react';

export const CutSpecificFields = () => {
  const tenderizedOptions = [
    {
      key: 0,
      text: 'None',
      value: 'None'
    },
    {
      key: 1,
      text: 'Blade',
      value: 'Blade'
    },
    {
      key: 2,
      text: 'Needle',
      value: 'Needle'
    },
    {
      key: 3,
      text: 'Papain and Bromelain',
      value: 'Papain and Bromelain'
    },
    {
      key: 4,
      text: 'Papain',
      value: 'Papain'
    }
  ];

  return (
    <div>
      <Form.Group>
        <Field
          component={FormElement}
          name='tenderized'
          className='tenderized'
          as={Form.Select}
          options={tenderizedOptions}
          type='text'
          label='Tenderized'
          width={4}
        />
      </Form.Group>
    </div>
  );
};
