import React from 'react';

class ProductSetupMock extends React.Component {
  render() {
    return <div>Fake product setup page</div>;
  }
}

export default ProductSetupMock;
