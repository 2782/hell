import {
  PRODUCT_SETUP_ALLERGENS_RETRIEVED,
  PRODUCT_SETUP_GET_ALL_PIECES_PACKAGES
} from '../actions/productSetupActionTypes';

const initState = {
  piecesPackages: [],
  allergens: []
};

const productSetupReducer = (state = initState, action) => {
  switch (action.type) {
    case PRODUCT_SETUP_GET_ALL_PIECES_PACKAGES:
      return {
        ...state,
        piecesPackages: action.payload
      };
    case PRODUCT_SETUP_ALLERGENS_RETRIEVED:
      return {
        ...state,
        allergens: action.payload
      };
    default:
      return state;
  }
};

export default productSetupReducer;
