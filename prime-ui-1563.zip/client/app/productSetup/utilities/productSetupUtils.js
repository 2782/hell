export const generatePortionRoomTableOptions = (portionRoomTables, selectedRoomValue) => {
  return portionRoomTables
    .filter(table => table.room === selectedRoomValue)
    .map(({ tableCode, tableDescription }, index) => {
      return { key: index, text: `${tableCode} - ${tableDescription}`, value: tableCode };
    });
};
