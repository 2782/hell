import {
  GET_INCOMPLETE_PRODUCTS,
  INCOMPLETE_PRODUCT_REQUESTED,
  INCOMPLETE_PRODUCT_RECEIVED,
  INCOMPLETE_PRODUCTS_FAILED
} from '../actions/incompleteProductSetupActionTypes';

const initialState = {
  incompleteProducts: [],
  loading: true
};

export default (state = initialState, action) => {
  switch (action.type) {
    case GET_INCOMPLETE_PRODUCTS:
      return {
        ...state,
        incompleteProducts: action.payload
      };
    case INCOMPLETE_PRODUCT_REQUESTED:
      return {
        ...state,
        loading: true
      };
    case INCOMPLETE_PRODUCT_RECEIVED:
      return {
        ...state,
        loading: false
      };
    case INCOMPLETE_PRODUCTS_FAILED:
      return {
        ...state,
        loading: false
      };
    default:
      return state;
  }
};
