import React from 'react';
import { createReduxStore } from '../../../store';
import { mount } from 'enzyme';
import { Provider } from 'react-redux';
import IncompleteProductSetup, { IncompleteProductSetupPage } from '../IncompleteProductSetup';
import incompleteProductResources from '../../../shared/api/incompleteProductResources';
import IncompleteProductSetupTable from '../../components/IncompleteProductSetupTable';
import { Table, Loader } from 'semantic-ui-react';
import EmptyListMessage from '../../../shared/components/EmptyListMessage';
import { PRODUCT_SETUP_FORM } from '../../../productSetup/pages/ProductSetup';

jest.mock('../../../shared/components/Header');
jest.mock('../../../shared/api/incompleteProductResources');

describe('Incomplete Product Setup', () => {
  describe('Incomplete Product Setup Table', () => {
    let wrapper;
    let mockStore;

    let incompleteProducts = [
      {
        code: '0079007',
        description: 'FLEMINGS CAB PRHOUSE STK',
        portionSize: '2 OZ',
        tableAssigned: false,
        priceModelAssigned: false,
        createdAt: '07-16'
      },
      {
        code: '0202013',
        description: 'SLICED PORK BELLY 9MM',
        portionSize: '32 OZ',
        tableAssigned: true,
        priceModelAssigned: false,
        createdAt: '07-16'
      }
    ];

    test('should get all incomplete products and pass them to IncompleteProductSetupTable', async () => {
      mockStore = createReduxStore({});
      incompleteProductResources.getIncompleteProducts.mockResolvedValue({
        data: incompleteProducts
      });

      wrapper = mount(
        <Provider store={mockStore}>
          <IncompleteProductSetup />
        </Provider>
      );

      await waitForAsyncTasks();

      wrapper.update();

      const incompleteProductSetupTable = wrapper.find(IncompleteProductSetupTable);
      jestExpect(incompleteProductSetupTable.length).toEqual(1);
      jestExpect(incompleteProductSetupTable.props().incompleteProducts).toEqual(
        incompleteProducts
      );
      jestExpect(wrapper.find(EmptyListMessage).exists()).toEqual(false);
    });

    test('should render empty table message when no incomplete products', () => {
      mockStore = createReduxStore({});
      incompleteProductResources.getIncompleteProducts.mockResolvedValue({ data: [] });

      wrapper = mount(
        <Provider store={mockStore}>
          <IncompleteProductSetup />
        </Provider>
      );

      jestExpect(wrapper.find(EmptyListMessage).exists()).toEqual(false);
      jestExpect(wrapper.find(Loader).exists()).toEqual(true);
    });

    test('should call setupTable when user click setup table icon', () => {
      const getProduct = jest.fn();
      const changePath = jest.fn();
      const replacePath = jest.fn();
      const initialize = jest.fn();

      wrapper = mount(
        <IncompleteProductSetupPage
          getProduct={getProduct}
          changePath={changePath}
          replacePath={replacePath}
          incompleteProducts={incompleteProducts}
          setHeaderAndFooter={() => {}}
          getIncompleteProducts={() => {}}
          initialize={initialize}
        />
      );

      const wrapperBody = wrapper.find(Table.Body);
      const wrapperItemRow = wrapperBody.find(Table.Row).at(0);
      const productCode = incompleteProducts[0].code;

      wrapperItemRow
        .find('[pid="incomplete-product-setup__table-cell-table"]')
        .find('a')
        .simulate('click');

      jestExpect(getProduct).toHaveBeenCalledWith(productCode);
      jestExpect(initialize).toHaveBeenCalledWith(PRODUCT_SETUP_FORM, { productCode });
      jestExpect(replacePath).toHaveBeenCalledWith('/product/product-setup');
    });

    test('should call setup price model when user click setup price model icon', () => {
      const initFinishedProductCode = jest.fn();
      const changePath = jest.fn();

      wrapper = mount(
        <IncompleteProductSetupPage
          changePath={changePath}
          initFinishedProductCode={initFinishedProductCode}
          incompleteProducts={incompleteProducts}
          setHeaderAndFooter={() => {}}
          getIncompleteProducts={() => {}}
        />
      );

      const wrapperBody = wrapper.find(Table.Body);
      const wrapperItemRow = wrapperBody.find(Table.Row).at(0);
      const calledWithParam = incompleteProducts[0].code;

      wrapperItemRow
        .find('[pid="incomplete-product-setup__table-cell-price-model"]')
        .find('a')
        .simulate('click');

      jestExpect(initFinishedProductCode).toHaveBeenCalledWith(calledWithParam);
      jestExpect(changePath).toHaveBeenCalledWith('/yield-model/create');
    });
  });
});
