import React from 'react';
import { shallow } from 'enzyme';
import IncompleteProductSetupTable from '../IncompleteProductSetupTable';
import { Table } from 'semantic-ui-react';
import EmptyListMessage from '../../../shared/components/EmptyListMessage';
import semanticUI from '../../../../test-helpers/semantic-ui';

describe('IncompleteProductSetupTable', () => {
  let wrapper;

  const setupTable = productCode => {
    return productCode;
  };
  const setupPriceModel = productCode => {
    return productCode;
  };

  let incompleteProducts = [
    {
      code: '0079007',
      description: 'FLEMINGS CAB PRHOUSE STK',
      portionSizeValue: 2,
      portionSizeUnit: 'OZ',
      tableAssigned: true,
      minWeightAssigned: true,
      maxWeightAssigned: true,
      priceModelAssigned: false,
      createdAt: '07-16'
    },
    {
      code: '0202013',
      description: 'SLICED PORK BELLY 9MM',
      portionSizeValue: 32,
      portionSizeUnit: 'OZ',
      minWeightAssigned: false,
      maxWeightAssigned: false,
      tableAssigned: false,
      priceModelAssigned: true,
      createdAt: '07-16'
    }
  ];

  beforeEach(() => {
    wrapper = shallow(
      <IncompleteProductSetupTable
        incompleteProducts={incompleteProducts}
        setupTable={setupTable}
        setupPriceModel={setupPriceModel}
      />
    );
  });

  test('should render Empty Table with no incomplete products', () => {
    const wrapper = shallow(
      <IncompleteProductSetupTable
        incompleteProducts={[]}
        setupTable={setupTable}
        setupPriceModel={setupPriceModel}
      />
    );

    jestExpect(wrapper.find(EmptyListMessage).exists()).toBeTruthy();
  });

  test('should render incomplete product setup table header row', () => {
    const wrapperHeader = wrapper.find(Table.Header).html();

    jestExpect(wrapperHeader).toEqual(jestExpect.stringContaining('PRODUCT'));
    jestExpect(wrapperHeader).toEqual(jestExpect.stringContaining('PRODUCT SETUP'));
    jestExpect(wrapperHeader).toEqual(jestExpect.stringContaining('PRICING MODEL'));
    jestExpect(wrapperHeader).toEqual(jestExpect.stringContaining('CREATED ON'));
  });

  test('should render the product info, table, price model and created on, with evaluating function if column contains value', () => {
    const wrapperBody = wrapper.find(Table.Body);
    const wrapperItemRow = wrapperBody.find(Table.Row).at(0);

    const firstIncompleteProduct = incompleteProducts[0];

    jestExpect(
      wrapperItemRow.find('[pid="incomplete-product-setup__table-cell-inner-product-info"]').text()
    ).toEqual(jestExpect.stringContaining(firstIncompleteProduct.code));
    const find = wrapperItemRow.find(
      '[pid="incomplete-product-setup__table-cell-inner-product-description"]'
    );

    jestExpect(find.children().text()).toEqual(
      jestExpect.stringContaining(firstIncompleteProduct.description)
    );
    jestExpect(
      wrapperItemRow.find('[pid="incomplete-product-setup__table-cell-table"]').find('.icon-add')
        .length
    ).toEqual(0);
    jestExpect(
      wrapperItemRow
        .find('[pid="incomplete-product-setup__table-cell-price-model"]')
        .find('.icon-add').length
    ).toEqual(1);
    jestExpect(
      wrapperItemRow
        .find('[pid="incomplete-product-setup__table-cell-created-on"]')
        .children()
        .text()
    ).toEqual(jestExpect.stringContaining(firstIncompleteProduct.createdAt));
  });

  test('should call setupTable callback when user click setup table icon', () => {
    const mockSetupTable = jest.fn();

    const wrapper = mount(
      <IncompleteProductSetupTable
        incompleteProducts={incompleteProducts}
        setupTable={mockSetupTable}
        setupPriceModel={setupPriceModel}
      />
    );
    const wrapperBody = wrapper.find(Table.Body);
    const wrapperItemRow = wrapperBody.find(Table.Row).at(1);

    const calledWithParam = incompleteProducts[1].code;

    wrapperItemRow
      .find('[pid="incomplete-product-setup__table-cell-table"]')
      .find('.icon-add')
      .simulate('click');

    jestExpect(mockSetupTable).toHaveBeenCalledTimes(1);
    jestExpect(mockSetupTable).toHaveBeenCalledWith(calledWithParam);
  });

  test('should render click setup table icon if min or max weight are not assigned', () => {
    const mockSetupTable = jest.fn();

    const wrapper = mount(
      <IncompleteProductSetupTable
        incompleteProducts={incompleteProducts}
        setupTable={mockSetupTable}
        setupPriceModel={setupPriceModel}
      />
    );
    const wrapperBody = wrapper.find(Table.Body);

    jestExpect(
      semanticUI
        .findTableColumnWithRowIndex(wrapperBody, 1, 1)
        .find('.icon-add')
        .exists()
    ).toBeTruthy();
  });

  test('should call setupPriceModel callback when user click setup price model icon', () => {
    const mockSetupPriceModel = jest.fn();

    const wrapper = mount(
      <IncompleteProductSetupTable
        incompleteProducts={incompleteProducts}
        setupTable={setupTable}
        setupPriceModel={mockSetupPriceModel}
      />
    );
    const wrapperBody = wrapper.find(Table.Body);
    const wrapperItemRow = wrapperBody.find(Table.Row).at(0);

    const calledWithParam = incompleteProducts[0].code;

    wrapperItemRow
      .find('[pid="incomplete-product-setup__table-cell-price-model"]')
      .find('.icon-add')
      .simulate('click');

    jestExpect(mockSetupPriceModel).toBeCalledTimes(1);
    jestExpect(mockSetupPriceModel).toBeCalledWith(calledWithParam);
  });
});
