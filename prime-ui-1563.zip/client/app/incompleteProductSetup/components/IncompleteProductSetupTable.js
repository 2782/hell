import React from 'react';
import * as _ from 'lodash';
import { Loader, Table } from 'semantic-ui-react';
import PropTypes from 'prop-types';
import DotDotDot from 'react-dotdotdot';
import EmptyListMessage from '../../shared/components/EmptyListMessage';

const renderTable = content => {
  return (
    <Table size='small' columns={10} fixed>
      <Table.Header>
        <Table.Row>
          <Table.HeaderCell colSpan={4} width={4}>
            PRODUCT
          </Table.HeaderCell>
          <Table.HeaderCell textAlign='center' colSpan={2} width={2}>
            PRODUCT SETUP
          </Table.HeaderCell>
          <Table.HeaderCell textAlign='center' colSpan={2} width={2}>
            PRICING MODEL
          </Table.HeaderCell>
          <Table.HeaderCell textAlign='right' colSpan={2} width={2}>
            CREATED ON
          </Table.HeaderCell>
        </Table.Row>
      </Table.Header>
      {content}
    </Table>
  );
};

const renderBody = (incompleteProducts, setupTable, setupPriceModel) => {
  if (!_.isNull(incompleteProducts)) {
    return (
      <Table.Body key={'incomplete-product-setup-table-content'}>
        {_.map(incompleteProducts, (incompleteProduct, itemIndex) => {
          const productInfo = `${incompleteProduct.code} / ${incompleteProduct.portionSize}`;
          const needSetUp =
            !incompleteProduct.tableAssigned ||
            !incompleteProduct.minWeightAssigned ||
            !incompleteProduct.maxWeightAssigned;
          return (
            <Table.Row
              pid={`incomplete-product-setup__table-row-${itemIndex}`}
              key={`incomplete-product-setup__table-row-${itemIndex}`}
            >
              <Table.Cell textAlign='left' colSpan={4} width={4}>
                <div pid='incomplete-product-setup__table-cell-inner-product-info'>
                  {productInfo}
                </div>
                <DotDotDot
                  clamp={1}
                  title={incompleteProduct.description}
                  pid='incomplete-product-setup__table-cell-inner-product-description'
                >
                  {incompleteProduct.description}
                </DotDotDot>
              </Table.Cell>
              <Table.Cell
                textAlign='center'
                pid='incomplete-product-setup__table-cell-table'
                colSpan={2}
                width={2}
              >
                {needSetUp && (
                  <a onClick={() => setupTable(incompleteProduct.code)}>
                    <i className='icon-add' />
                  </a>
                )}
              </Table.Cell>
              <Table.Cell
                textAlign='center'
                pid='incomplete-product-setup__table-cell-price-model'
                colSpan={2}
                width={2}
              >
                {!incompleteProduct.priceModelAssigned && (
                  <a onClick={() => setupPriceModel(incompleteProduct.code)}>
                    <i className='icon-add' />
                  </a>
                )}
              </Table.Cell>
              <Table.Cell
                textAlign='right'
                pid='incomplete-product-setup__table-cell-created-on'
                colSpan={2}
                width={2}
              >
                {incompleteProduct.createdAt}
              </Table.Cell>
            </Table.Row>
          );
        })}
      </Table.Body>
    );
  }
};

const IncompleteProductSetupTable = ({
  incompleteProducts,
  setupTable,
  setupPriceModel,
  loading
}) => {
  const content = renderBody(incompleteProducts, setupTable, setupPriceModel);
  const inCompleteProductSetupTable = renderTable(content);
  let loadingContent = <EmptyListMessage key={'incomplete-product-setup-table-empty-message'} />;
  if (loading) {
    loadingContent = <Loader size='large' className='loader-image' active />;
  }

  return <div>{_.isEmpty(incompleteProducts) ? loadingContent : inCompleteProductSetupTable}</div>;
};

IncompleteProductSetupTable.propTypes = {
  incompleteProducts: PropTypes.array,
  setupTable: PropTypes.func.isRequired,
  setupPriceModel: PropTypes.func.isRequired,
  loading: PropTypes.bool
};

export default IncompleteProductSetupTable;
