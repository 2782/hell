import incompleteProductResources from '../../shared/api/incompleteProductResources';
import {
  GET_INCOMPLETE_PRODUCTS,
  INCOMPLETE_PRODUCT_REQUESTED,
  INCOMPLETE_PRODUCT_RECEIVED,
  INCOMPLETE_PRODUCTS_FAILED
} from './incompleteProductSetupActionTypes';

export const getIncompleteProducts = () => {
  return dispatch => {
    dispatch({
      type: INCOMPLETE_PRODUCT_REQUESTED
    });
    return incompleteProductResources.getIncompleteProducts().then(
      response => {
        dispatch({
          type: GET_INCOMPLETE_PRODUCTS,
          payload: response.data
        });
        dispatch({
          type: INCOMPLETE_PRODUCT_RECEIVED
        });
      },
      () => {
        dispatch({
          type: INCOMPLETE_PRODUCTS_FAILED
        });
      }
    );
  };
};
