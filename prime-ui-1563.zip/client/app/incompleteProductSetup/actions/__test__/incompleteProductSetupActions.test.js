import incompleteProductResources from '../../../shared/api/incompleteProductResources';
import { getIncompleteProducts } from '../incompleteProductSetupActions';
import {
  GET_INCOMPLETE_PRODUCTS,
  INCOMPLETE_PRODUCT_REQUESTED,
  INCOMPLETE_PRODUCT_RECEIVED
} from '../incompleteProductSetupActionTypes';

jest.mock('../../../shared/api/incompleteProductResources');

describe('incompleteProductSetupActions', () => {
  let dispatch;

  beforeEach(() => {
    dispatch = jest.fn();
  });

  afterEach(() => {
    incompleteProductResources.getIncompleteProducts.mockReset();
  });

  test('should call getIncompleteProducts and dispatch GET_INCOMPLETE_PRODUCTS on success', async () => {
    const incompleteProductsResponse = {
      data: [
        {
          code: '0079007',
          description: 'FLEMINGS CAB PRHOUSE STK',
          portionSizeValue: 2,
          portionSizeUnit: 'OZ',
          tableAssigned: true,
          priceModelAssigned: false,
          createdAt: '07-16'
        },
        {
          code: '0202013',
          description: 'SLICED PORK BELLY 9MM',
          portionSizeValue: 32,
          portionSizeUnit: 'OZ',
          tableAssigned: true,
          priceModelAssigned: false,
          createdAt: '07-16'
        }
      ]
    };
    incompleteProductResources.getIncompleteProducts.mockResolvedValue(incompleteProductsResponse);

    await getIncompleteProducts()(dispatch);

    jestExpect(dispatch).toHaveBeenNthCalledWith(3, {
      type: INCOMPLETE_PRODUCT_RECEIVED
    });
    jestExpect(dispatch).toHaveBeenNthCalledWith(2, {
      type: GET_INCOMPLETE_PRODUCTS,
      payload: incompleteProductsResponse.data
    });
    jestExpect(dispatch).toHaveBeenNthCalledWith(1, {
      type: INCOMPLETE_PRODUCT_REQUESTED
    });
  });

  test('should call getIncompleteProducts and not dispatch GET_INCOMPLETE_PRODUCTS in fail', async () => {
    incompleteProductResources.getIncompleteProducts.mockRejectedValue({});

    await getIncompleteProducts()(dispatch);

    jestExpect(dispatch).toHaveBeenNthCalledWith(1, {
      type: INCOMPLETE_PRODUCT_REQUESTED
    });
  });
});
