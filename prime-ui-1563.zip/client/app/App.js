import React from 'react';

import functionKeyProducer from './shared/functionKeys/producer';
import subscriber from './shared/functionKeys/subscriber';

import './shared/interceptor';
import Header from './shared/components/Header';
import Footer from './shared/components/Footer';
import ConfirmationModal from './shared/components/ConfirmationModal';
import PrimeRouterSelector from './routers/PrimeRouterSelector';

const FunctionKeySubscribedPrimeRouter = subscriber(PrimeRouterSelector);

class App extends React.Component {
  render() {
    return (
      <div className='app-wrapper'>
        <div className='sticky-header'>
          <Header />
        </div>
        <div className='page-wrapper'>
          <div className='page'>
            <FunctionKeySubscribedPrimeRouter />
          </div>
          <ConfirmationModal />
        </div>
        <Footer />
      </div>
    );
  }
}

export default functionKeyProducer(App);
