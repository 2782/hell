import { Route, Switch } from 'react-router-dom';

jest.mock('../../../shared/components/Header');
jest.mock('../../../productSearch/pages/ProductSearch');
jest.mock('../../../productSetup/pages/ProductSetup');
jest.mock('../../../incompleteProductSetup/pages/IncompleteProductSetup');

import configureStore from 'redux-mock-store';
import thunk from 'redux-thunk';
import SidebarNavigation from '../../../shared/components/SideNavigation';
import { mount } from 'enzyme';
import React from 'react';
import ProductBase from '../ProductBase';
import { Menu } from 'semantic-ui-react';
import { Provider } from 'react-redux';
import { replace } from 'react-router-redux';
import ProductSearch from '../../../productSearch/pages/ProductSearch';
import IncompleteProductSetup from '../../../incompleteProductSetup/pages/IncompleteProductSetup';
import ProductSetup from '../../../productSetup/pages/ProductSetup';
import ProductActivity from '../../../productActivity/pages/ProductActivity';
import ProductActivityDetails from '../../../productActivity/pages/ProductActivityDetails';

let middleware = [thunk];
const createStore = configureStore(middleware);

describe('ProductBase', () => {
  let wrapper;
  let mockStore;

  describe('ROLE_ADMIN', () => {
    beforeEach(() => {
      mockStore = createStore({
        incompleteProductSetup: {
          incompleteProducts: []
        },
        login: {
          role: 'ROLE_ADMIN'
        },
        function: {}
      });
      wrapper = mount(
        <Provider store={mockStore}>
          <ProductBase
            location={{ pathname: '/product/product-search' }}
            match={{ url: '/product' }}
            store={mockStore}
          />
        </Provider>
      );
    });

    test('should be aware of all relevant sidebar nav links', () => {
      const sidebar = wrapper.find(SidebarNavigation);
      jestExpect(sidebar.props().links.length).toEqual(4);
      jestExpect(sidebar.props().links[0].path).toEqual('/product-search');
      jestExpect(sidebar.props().links[1].path).toEqual('/product-activity');
      jestExpect(sidebar.props().links[2].path).toEqual('/product-setup');
      jestExpect(sidebar.props().links[3].path).toEqual('/incomplete-products');
    });

    test('should have routes in Switch tag', () => {
      const allLinks = wrapper.find(Switch);

      jestExpect(allLinks.find(Route).length).toEqual(5);

      function getRouteProps(index) {
        return allLinks
          .find(Route)
          .at(index)
          .props();
      }

      jestExpect(getRouteProps(0).component).toEqual(ProductSearch);
      jestExpect(getRouteProps(0).path).toEqual('/product/product-search');
      jestExpect(getRouteProps(1).component).toEqual(ProductActivity);
      jestExpect(getRouteProps(1).path).toEqual('/product/product-activity');
      jestExpect(getRouteProps(2).component).toEqual(ProductActivityDetails);
      jestExpect(getRouteProps(2).path).toEqual('/product/product-activity/details');
      jestExpect(getRouteProps(3).component).toEqual(ProductSetup);
      jestExpect(getRouteProps(3).path).toEqual('/product/product-setup');
      jestExpect(getRouteProps(4).component).toEqual(IncompleteProductSetup);
      jestExpect(getRouteProps(4).path).toEqual('/product/incomplete-products');
    });

    test('should changePath when click navigation links', () => {
      mockStore.clearActions();
      const sidebar = wrapper.find(SidebarNavigation);

      sidebar
        .find(Menu.Item)
        .at(0)
        .simulate('click');
      sidebar
        .find(Menu.Item)
        .at(2)
        .simulate('click');
      sidebar
        .find(Menu.Item)
        .at(3)
        .simulate('click');

      const actions = mockStore.getActions();
      jestExpect(actions[0]).toEqual(replace('/product/product-search'));
      jestExpect(actions[1]).toEqual(replace('/product/product-setup'));
      jestExpect(actions[2]).toEqual(replace('/product/incomplete-products'));
    });
  });

  test('should be aware of only links allowed when role is portion room member', () => {
    mockStore = createStore({
      incompleteProductSetup: {
        incompleteProducts: []
      },
      login: {
        role: 'ROLE_PORTION_ROOM_MEMBER'
      },
      function: {}
    });
    wrapper = mount(
      <Provider store={mockStore}>
        <ProductBase
          location={{ pathname: '/product/product-search' }}
          match={{ url: '/product' }}
          store={mockStore}
        />
      </Provider>
    );

    const sidebar = wrapper.find(SidebarNavigation);
    jestExpect(sidebar.props().links.length).toEqual(2);
    jestExpect(sidebar.props().links[0].path).toEqual('/product-search');
    jestExpect(sidebar.props().links[1].path).toEqual('/product-activity');
  });
});
