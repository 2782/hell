import _ from 'lodash';

export const generateStationOptions = stations => {
  return stations
    ? _.filter(stations, station => station.type === 'PRODUCTION').map(
        ({ stationCode, name }, index) => {
          return { key: index, text: `${stationCode} - ${name}`, value: stationCode };
        }
      )
    : [];
};

export const generateAdditivesInitialValues = sourceMeatOrderPreview => {
  return sourceMeatOrderPreview ? sourceMeatOrderPreview.additives : [];
};
