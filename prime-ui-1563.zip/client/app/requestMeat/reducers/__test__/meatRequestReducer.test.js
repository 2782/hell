import meatRequestReducer, { initialState } from '../meatRequestReducer';
import {
  CLEAR_MEAT_REQUEST_BY_BLEND_PRICING_MODEL,
  BLEND_SOURCE_MEAT_TABLE_DISPLAYED,
  GET_BLENDS,
  GET_BLEND_PRICING_MODEL,
  GRABBED_WIP_BOXES,
  RESET_CUT_STATIONS_INFO,
  RESET_SOURCE_MEAT_ORDER_PREVIEW,
  UPDATE_CUT_STATIONS_INFO,
  UPDATE_SOURCE_MEAT_ORDER_PREVIEW,
  UPDATE_SOURCE_PRODUCT_INFO,
  UPDATED_WIP_SORTING,
  PRODUCT_SOURCE_MEAT_TABLE_DISPLAYED,
  CLEAR_MEAT_REQUEST_BY_FINISHED_PRODUCT,
  REGISTER_BARCODE_FIELD,
  RESET_MEAT_REQUEST,
  MEAT_REQUESTED,
  SET_SELECTED_BLEND
} from '../../actions/meatRequestActionTypes';
import GrindingPricingModelFactory from '../../../../test-factories/grindingPricingModel';

const sourceMeatOrderPreview = {
  id: 20,
  code: '0000507',
  description: 'QB, PRIME T-BONE STEAK 205',
  table: {
    id: 21421402152,
    station: {
      name: 'QB CUTTER 2',
      room: 'QB',
      stationCode: 99,
      id: 21421402152
    },
    tableCode: 2,
    tableDescription: 'Table 2 at QB Portion',
    stationId: 21421402152
  },
  productOutput: 'FINISHED'
};

const stationOne = {
  id: 1,
  name: 'Cutter One'
};

const stationTwo = {
  id: 2,
  name: 'Cutter Two'
};

describe('meatRequestReducer', () => {
  let initState;

  beforeEach(() => {
    initState = {
      barcodeField: {
        getRenderedComponent: () => ({
          focusInput: () => {}
        })
      },
      stations: [],
      sourceMeatOrderPreview: {},
      blends: [],
      selectedBlend: null,
      blendPricingModel: {},
      sourceProductInfo: {},
      showBlendSourceMeatTable: false,
      showProductSourceMeatTable: false,
      requesting: false,
      wipBoxes: null
    };
  });

  test('should return init state when handling unexpected action', () => {
    jestExpect(
      meatRequestReducer(undefined, {
        type: 'UNEXPECTED'
      })
    ).toEqual(initialState);
  });

  test('should return new state with cut stations', () => {
    const result = meatRequestReducer(initState, {
      type: UPDATE_CUT_STATIONS_INFO,
      payload: [stationOne, stationTwo]
    });
    jestExpect(result.stations).toEqual([stationOne, stationTwo]);
  });

  test('should reset cut station info', () => {
    initState = {
      stations: [stationOne, stationTwo]
    };

    const result = meatRequestReducer(initState, {
      type: RESET_CUT_STATIONS_INFO
    });
    jestExpect(result.stations).toEqual([]);
  });

  test('should return new state with preview of source meat order', () => {
    const result = meatRequestReducer(initState, {
      type: UPDATE_SOURCE_MEAT_ORDER_PREVIEW,
      payload: sourceMeatOrderPreview
    });
    jestExpect(result.sourceMeatOrderPreview).toEqual(sourceMeatOrderPreview);
  });

  test('should reset source meat order preview', () => {
    const result = meatRequestReducer(initState, {
      type: RESET_SOURCE_MEAT_ORDER_PREVIEW
    });
    jestExpect(result.sourceMeatOrderPreview).toEqual({});
  });

  test('should return new state with blends', () => {
    const result = meatRequestReducer(initState, {
      type: GET_BLENDS,
      payload: [
        {
          name: 'NATURAL',
          displayName: 'Natural'
        }
      ]
    });
    jestExpect(result.blends).toEqual([
      {
        name: 'NATURAL',
        displayName: 'Natural'
      }
    ]);
  });

  test('should return new state with blendPricingModel', () => {
    const pricingModel = GrindingPricingModelFactory.build();
    const result = meatRequestReducer(initState, {
      type: GET_BLEND_PRICING_MODEL,
      payload: pricingModel
    });
    jestExpect(result.blendPricingModel).toEqual(pricingModel);
  });

  test('should reset blend pricingModel', () => {
    initState = {
      ...initState,
      selectedBlend: 'BLEND05'
    };
    const result = meatRequestReducer(initState, {
      type: CLEAR_MEAT_REQUEST_BY_BLEND_PRICING_MODEL
    });
    jestExpect(result.blendPricingModel).toEqual({});
    jestExpect(result.sourceProductInfo).toEqual({});
    jestExpect(result.selectedBlend).toEqual(null);
  });

  test('should reset finished product meat request', () => {
    const result = meatRequestReducer(initState, {
      type: CLEAR_MEAT_REQUEST_BY_FINISHED_PRODUCT
    });
    jestExpect(result.sourceMeatOrderPreview).toEqual({});
    jestExpect(result.showProductSourceMeatTable).toEqual(false);
  });

  test('should return new state with sourceProductInfo', () => {
    const sourceProductInfo = { '0204001': 'Description' };
    const result = meatRequestReducer(initState, {
      type: UPDATE_SOURCE_PRODUCT_INFO,
      payload: sourceProductInfo
    });
    jestExpect(result.sourceProductInfo).toEqual(sourceProductInfo);
  });

  test('should return new state with showBlendSourceMeatTable', () => {
    const result = meatRequestReducer(initState, {
      type: BLEND_SOURCE_MEAT_TABLE_DISPLAYED
    });
    jestExpect(result.showBlendSourceMeatTable).toEqual(true);
  });

  test('should return new state with showProductSourceMeatTable', () => {
    const result = meatRequestReducer(initState, {
      type: PRODUCT_SOURCE_MEAT_TABLE_DISPLAYED
    });
    jestExpect(result.showProductSourceMeatTable).toEqual(true);
  });

  test('should return new state with showProductSourceMeatTable', () => {
    const result = meatRequestReducer(initState, {
      type: PRODUCT_SOURCE_MEAT_TABLE_DISPLAYED
    });
    jestExpect(result.showProductSourceMeatTable).toEqual(true);
  });

  test('should return new state with wipBoxes', () => {
    const wipBoxes = [
      {
        netWeight: 10,
        productCode: '4102218',
        productDesc: 'Product Desc for 4102218',
        productPortionSize: {
          portionSize: {
            unitOfWeight: 'OZ',
            value: 7.8
          }
        },
        productionProduct: true
      }
    ];
    const result = meatRequestReducer(initState, {
      type: GRABBED_WIP_BOXES,
      payload: wipBoxes
    });

    jestExpect(result.wipBoxes).toEqual(wipBoxes);
  });

  describe('UPDATED_WIP_SORTING', () => {
    test('should change sort column and sort direction', () => {
      const expectedState = {
        ...initState,
        sortColumn: 'Drew Direction',
        sortDirection: 'ascending'
      };

      jestExpect(
        meatRequestReducer(initState, {
          type: UPDATED_WIP_SORTING,
          payload: {
            sortColumn: 'Drew Direction',
            sortDirection: 'ascending'
          }
        })
      ).toEqual(expectedState);
    });
  });

  test('should register barcodeField', () => {
    jestExpect(
      meatRequestReducer(undefined, { type: REGISTER_BARCODE_FIELD, payload: 'BARCODE_FIELD' })
    ).toEqual({
      ...initState,
      barcodeField: 'BARCODE_FIELD'
    });
  });

  test('should reset requesting', () => {
    const result = meatRequestReducer(initState, {
      type: RESET_MEAT_REQUEST
    });
    jestExpect(result.requesting).toEqual(false);
  });

  test('should set requesting to true', () => {
    const result = meatRequestReducer(initState, {
      type: MEAT_REQUESTED
    });
    jestExpect(result.requesting).toEqual(true);
  });

  test('should set selected blend', () => {
    const result = meatRequestReducer(initState, {
      type: SET_SELECTED_BLEND,
      payload: 'BLEND05'
    });
    jestExpect(result.selectedBlend).toEqual('BLEND05');
  });
});
