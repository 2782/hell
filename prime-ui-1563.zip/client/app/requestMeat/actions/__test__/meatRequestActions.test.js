import cutStationResources from '../../../shared/api/stationResources';
import {
  bringWipToPortionRoom,
  clearMeatRequestByBlendInfo,
  clearMeatRequestByFinishedProduct,
  deleteWipBox,
  focusBarcodeField,
  generateMeatRequest,
  getBlends,
  getPricingModelByBlend,
  getSourceMeatOrderPreview,
  getStations,
  getWipBoxes,
  handleSort,
  registerBarcodeField
} from '../meatRequestActions';
import {
  CLEAR_MEAT_REQUEST_BY_BLEND_PRICING_MODEL,
  CLEAR_MEAT_REQUEST_BY_FINISHED_PRODUCT,
  GET_BLEND_PRICING_MODEL,
  GET_BLENDS,
  GRABBED_WIP_BOXES,
  PRODUCT_SOURCE_MEAT_TABLE_DISPLAYED,
  REGISTER_BARCODE_FIELD,
  RESET_CUT_STATIONS_INFO,
  RESET_SOURCE_MEAT_ORDER_PREVIEW,
  UPDATE_CUT_STATIONS_INFO,
  UPDATE_SOURCE_MEAT_ORDER_PREVIEW,
  UPDATE_SOURCE_PRODUCT_INFO,
  UPDATED_WIP_SORTING,
  RESET_MEAT_REQUEST,
  MEAT_REQUESTED,
  SET_SELECTED_BLEND
} from '../meatRequestActionTypes';
import sourceMeatResources from '../../../shared/api/sourceMeatResources';
import { getTestStateForRoomA } from '../../../../test-factories/testState';
import SourceMeatOrderFactory from '../../../../test-factories/sourceMeatOrder';
import yieldModelResources from '../../../shared/api/yieldModelResources';
import GrindingPricingModelFactory from '../../../../test-factories/grindingPricingModel';
import productResources from '../../../shared/api/productResources';
import boxResources from '../../../shared/api/boxResources';
import { AVAILABLE_WIP_BOX } from '../../../../test-factories/wipBoxFactory';
import { SubmissionError } from 'redux-form';

const sourceMeatOrder = SourceMeatOrderFactory.build();

jest.mock('../../../shared/api/sourceMeatResources');
jest.mock('../../../shared/api/stationResources');
jest.mock('../../../shared/api/yieldModelResources');
jest.mock('../../../shared/api/boxResources');
jest.mock('../../../shared/api/productResources');

describe('meatRequestActions', () => {
  let dispatch;

  beforeEach(() => {
    dispatch = jest.fn();
  });

  describe('CLEAR_MEAT_REQUEST_BY_FINISHED_PRODUCT', () => {
    test('should call clearMeatRequestByFinishedProduct and dispatch RESET_SOURCE_MEAT_ORDER_PREVIEW', () => {
      jestExpect(clearMeatRequestByFinishedProduct()).toEqual({
        type: CLEAR_MEAT_REQUEST_BY_FINISHED_PRODUCT
      });
    });
  });

  describe('getSourceMeatOrderPreview', () => {
    test('should get preview of source meat order', () => {
      const aResponse = {
        data: 'responseData'
      };

      sourceMeatResources.getSourceMeatOrderPreviewByProduct.mockImplementation((arg, success) =>
        success(aResponse)
      );
      getSourceMeatOrderPreview('A')(dispatch);

      jestExpect(dispatch).toHaveBeenNthCalledWith(1, {
        type: RESET_SOURCE_MEAT_ORDER_PREVIEW
      });

      jestExpect(dispatch).toHaveBeenNthCalledWith(2, {
        payload: aResponse.data,
        type: UPDATE_SOURCE_MEAT_ORDER_PREVIEW
      });

      jestExpect(dispatch).toHaveBeenNthCalledWith(3, {
        type: PRODUCT_SOURCE_MEAT_TABLE_DISPLAYED
      });
    });
  });

  test('should return clear meat request by finished product action type', () => {
    const action = clearMeatRequestByFinishedProduct();
    jestExpect(action).toEqual({ type: CLEAR_MEAT_REQUEST_BY_FINISHED_PRODUCT });
  });

  describe('getStations', () => {
    test('should call getStations and dispatch UPDATE_CUT_STATIONS_INFO', async () => {
      cutStationResources.getStationsByRoom.mockResolvedValue({
        data: 'responseData'
      });
      await getStations()(dispatch, getTestStateForRoomA);

      jestExpect(dispatch).toHaveBeenNthCalledWith(1, {
        payload: 'responseData',
        type: UPDATE_CUT_STATIONS_INFO
      });
    });

    test('should dispatch RESET_CUT_STATIONS_INFO when request fails', async () => {
      cutStationResources.getStationsByRoom.mockRejectedValue({});

      await getStations()(dispatch, getTestStateForRoomA);

      jestExpect(dispatch).toHaveBeenNthCalledWith(1, {
        type: RESET_CUT_STATIONS_INFO
      });
    });
  });

  describe('generateMeatRequest', () => {
    test('should call generateMeatRequest and dispatch MEAT_REQUESTED & RESET_SOURCE_MEAT_ORDER_PREVIEW & RESET_MEAT_REQUEST', () => {
      const getState = () => {
        return {
          portionRoomsInfo: {
            currentPortionRoom: {
              code: 'A'
            }
          }
        };
      };

      sourceMeatResources.generateSourceMeatOrders.mockImplementation(
        (sourceMeatOrder, roomCode, successfulCallback) => successfulCallback()
      );

      generateMeatRequest(sourceMeatOrder)(dispatch, getState);

      jestExpect(dispatch).toHaveBeenNthCalledWith(1, {
        type: MEAT_REQUESTED
      });

      jestExpect(dispatch).toHaveBeenNthCalledWith(2, {
        type: RESET_SOURCE_MEAT_ORDER_PREVIEW
      });

      jestExpect(dispatch).toHaveBeenNthCalledWith(3, {
        type: RESET_MEAT_REQUEST
      });
    });

    test('should call generateMeatRequest and dispatch MEAT_REQUESTED & RESET_MEAT_REQUEST', () => {
      const successfulCallback = jest.fn();
      const errorHandler = jest.fn();
      const error = {};

      const getState = () => {
        return {
          portionRoomsInfo: {
            currentPortionRoom: {
              code: 'A'
            }
          }
        };
      };

      sourceMeatResources.generateSourceMeatOrders.mockImplementation(
        (sourceMeatOrder, roomCode, successfulCallback, errorHandler) => errorHandler(error)
      );

      generateMeatRequest(sourceMeatOrder, successfulCallback, errorHandler)(dispatch, getState);

      jestExpect(errorHandler).toHaveBeenCalledWith(error);

      jestExpect(dispatch).toHaveBeenNthCalledWith(1, {
        type: MEAT_REQUESTED
      });

      jestExpect(dispatch).toHaveBeenNthCalledWith(2, {
        type: RESET_MEAT_REQUEST
      });
    });
  });

  describe('Blend', () => {
    beforeEach(() => {
      dispatch = jest.fn();
    });

    test('should call getBlends and dispatch GET_BLEND_NAMES', async () => {
      yieldModelResources.getBlends.mockResolvedValue({ data: ['NATURAL', 'KOBE'] });

      await getBlends()(dispatch);

      jestExpect(dispatch).toHaveBeenNthCalledWith(1, {
        type: GET_BLENDS,
        payload: ['NATURAL', 'KOBE']
      });
    });

    test(
      'should call getPricingModelByBlend and dispatch @@redux-form/STOP_SUBMIT and ' +
        '@@redux-form/SET_SUBMIT_FAILED when no pricing model response',
      () => {
        yieldModelResources.getPricingModelByBlend.mockImplementation((arg, success) =>
          success({})
        );
        getPricingModelByBlend('NATURAL')(dispatch);

        jestExpect(dispatch).toHaveBeenNthCalledWith(1, {
          type: SET_SELECTED_BLEND,
          payload: 'NATURAL'
        });

        jestExpect(dispatch).toHaveBeenNthCalledWith(2, {
          type: '@@redux-form/STOP_SUBMIT',
          payload: { blend: 'Blend has no pricing model' },
          meta: { form: 'meatRequestByBlendForm' },
          error: true
        });

        jestExpect(dispatch).toHaveBeenNthCalledWith(3, {
          type: '@@redux-form/SET_SUBMIT_FAILED',
          meta: { fields: [], form: 'meatRequestByBlendForm' },
          error: true
        });
      }
    );

    test(
      'should call getPricingModelByBlend and dispatch GET_BLEND_PRICING_MODEL and ' +
        'UPDATE_SOURCE_PRODUCT_INFO when has pricing model response',
      () => {
        const grindPricingModel = GrindingPricingModelFactory.build();

        yieldModelResources.getPricingModelByBlend.mockImplementation((arg, success) =>
          success({ data: grindPricingModel })
        );
        productResources.getProductInfoByProductCodes.mockImplementation((arg, callback) =>
          callback({
            data: [
              {
                code: '0204001',
                description: 'test  data'
              }
            ]
          })
        );

        getPricingModelByBlend('NATURAL')(dispatch);

        jestExpect(dispatch).toHaveBeenNthCalledWith(1, {
          type: SET_SELECTED_BLEND,
          payload: 'NATURAL'
        });

        jestExpect(dispatch).toHaveBeenNthCalledWith(2, {
          type: GET_BLEND_PRICING_MODEL,
          payload: grindPricingModel
        });

        jestExpect(dispatch).toHaveBeenNthCalledWith(3, {
          type: UPDATE_SOURCE_PRODUCT_INFO,
          payload: { '0204001': { code: '0204001', description: 'test  data' } }
        });
      }
    );

    test(
      'should call getPricingModelByBlend and only dispatch GET_BLEND_PRICING_MODEL ' +
        'when has pricing model response and no product info response ',
      () => {
        const grindPricingModel = GrindingPricingModelFactory.build();

        yieldModelResources.getPricingModelByBlend.mockImplementation((arg, success) =>
          success({ data: grindPricingModel })
        );
        productResources.getProductInfoByProductCodes.mockImplementation((arg, success, error) => {
          error({});
        });

        getPricingModelByBlend('NATURAL')(dispatch);

        jestExpect(dispatch).toHaveBeenCalledWith({
          type: GET_BLEND_PRICING_MODEL,
          payload: grindPricingModel
        });
      }
    );

    test('should call clearMeatRequestByBlendInfo and dispatch CLEAR_MEAT_REQUEST_BY_BLEND_PRICING_MODEL', () => {
      clearMeatRequestByBlendInfo()(dispatch);

      jestExpect(dispatch).toHaveBeenNthCalledWith(1, {
        type: CLEAR_MEAT_REQUEST_BY_BLEND_PRICING_MODEL
      });
    });
  });

  test('should get wip boxes', () => {
    const wipBoxResponse = {
      data: [
        {
          netWeight: 10,
          productCode: '4102218',
          productDesc: 'Product Desc for 4102218',
          productPortionSize: {
            portionSize: {
              unitOfWeight: 'OZ',
              value: 7.8
            }
          }
        }
      ]
    };
    boxResources.getWipBoxes.mockImplementation(success => success(wipBoxResponse));

    getWipBoxes()(dispatch);

    jestExpect(dispatch).toHaveBeenNthCalledWith(1, {
      type: GRABBED_WIP_BOXES,
      payload: wipBoxResponse.data
    });
  });

  test('should delete wip box', () => {
    boxResources.deleteWipBox.mockImplementation((arg, success) => success({}));
    const wipBoxResponse = {
      data: [
        {
          netWeight: 10,
          productCode: '4102218',
          productDesc: 'Product Desc for 4102218',
          productPortionSize: {
            portionSize: {
              unitOfWeight: 'OZ',
              value: 7.8
            }
          }
        }
      ]
    };

    boxResources.getWipBoxes.mockImplementation(success => success(wipBoxResponse));

    deleteWipBox(1)(dispatch);

    jestExpect(dispatch).toHaveBeenNthCalledWith(1, {
      type: GRABBED_WIP_BOXES,
      payload: wipBoxResponse.data
    });
  });

  test('should flip wip sorting', () => {
    handleSort('Bob the Column')(dispatch, () => ({
      meatRequestInfo: {
        sortColumn: 'Bob the Column',
        sortDirection: 'ascending'
      }
    }));

    jestExpect(dispatch).toHaveBeenCalledWith({
      type: UPDATED_WIP_SORTING,
      payload: {
        sortColumn: 'Bob the Column',
        sortDirection: 'descending'
      }
    });
  });

  test('should switch wip sorting', () => {
    handleSort('Sally Sorter')(dispatch, () => ({
      meatRequestInfo: {
        sortColumn: 'Bob the Column',
        sortDirection: 'descending'
      }
    }));

    jestExpect(dispatch).toHaveBeenCalledWith({
      type: UPDATED_WIP_SORTING,
      payload: {
        sortColumn: 'Sally Sorter',
        sortDirection: 'ascending'
      }
    });
  });

  describe('bringWipIntoPortionRoomWhenEnteringBarcode', () => {
    beforeEach(() => {
      dispatch = jest.fn();
    });

    test('should bring wip into portion room successfully', async () => {
      const dispatch = jest.fn();
      const resetBarcode = jest.fn();
      const wipBoxResponse = AVAILABLE_WIP_BOX;

      boxResources.getWipBoxes.mockImplementation(success => success(wipBoxResponse));
      boxResources.updateWipStatusToInPortionRoom.mockResolvedValue({});

      await bringWipToPortionRoom('barcode', 'Test room code', resetBarcode)(dispatch);

      jestExpect(dispatch).toBeCalledWith({
        type: GRABBED_WIP_BOXES,
        payload: wipBoxResponse.data
      });
    });

    test('should throw when bring wip into portion room fails', async () => {
      const dispatch = jest.fn();

      boxResources.updateWipStatusToInPortionRoom.mockRejectedValue({});

      await jestExpect(
        bringWipToPortionRoom('barcode', 'TEST_ROOM_CODE')(dispatch)
      ).rejects.toThrow(SubmissionError);
    });
  });

  test('should return action for REGISTER_BARCODE_FIELD', () => {
    jestExpect(registerBarcodeField('FIELD')).toEqual({
      type: REGISTER_BARCODE_FIELD,
      payload: 'FIELD'
    });
  });

  test('should focus barcodeField from existing state', () => {
    const focusInput = jest.fn();
    const getState = jest.fn(() => ({
      meatRequestInfo: {
        barcodeField: {
          getRenderedComponent: jest.fn(() => ({
            focusInput
          }))
        }
      }
    }));

    focusBarcodeField()(null, getState);

    jestExpect(focusInput).toBeCalled();
  });
});
