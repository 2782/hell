import cutStationResources from '../../shared/api/stationResources';
import sourceMeatResources from '../../shared/api/sourceMeatResources';
import {
  BLEND_SOURCE_MEAT_TABLE_DISPLAYED,
  CLEAR_MEAT_REQUEST_BY_BLEND_PRICING_MODEL,
  CLEAR_MEAT_REQUEST_BY_FINISHED_PRODUCT,
  GET_BLENDS,
  GET_BLEND_PRICING_MODEL,
  GRABBED_WIP_BOXES,
  PRODUCT_SOURCE_MEAT_TABLE_DISPLAYED,
  RESET_CUT_STATIONS_INFO,
  RESET_SOURCE_MEAT_ORDER_PREVIEW,
  UPDATE_CUT_STATIONS_INFO,
  UPDATE_SOURCE_MEAT_ORDER_PREVIEW,
  UPDATE_SOURCE_PRODUCT_INFO,
  UPDATED_WIP_SORTING,
  REGISTER_BARCODE_FIELD,
  RESET_MEAT_REQUEST,
  MEAT_REQUESTED,
  SET_SELECTED_BLEND
} from './meatRequestActionTypes';
import yieldModelResources from '../../shared/api/yieldModelResources';
import productResources from '../../shared/api/productResources';
import * as _ from 'lodash';

import { setSubmitFailed, stopSubmit } from 'redux-form';
import boxResources from '../../shared/api/boxResources';
import Validator from '../components/availableWipFormValidator';

export const getSourceMeatOrderPreview = productInfo => dispatch => {
  return sourceMeatResources.getSourceMeatOrderPreviewByProduct(productInfo, response => {
    dispatch({
      type: RESET_SOURCE_MEAT_ORDER_PREVIEW
    });
    dispatch({
      type: UPDATE_SOURCE_MEAT_ORDER_PREVIEW,
      payload: response.data
    });
    dispatch({
      type: PRODUCT_SOURCE_MEAT_TABLE_DISPLAYED
    });
  });
};

export const generateMeatRequest = (
  sourceMeatOrders,
  successfulCallback = () => {},
  errorHandler
) => {
  return (dispatch, getState) => {
    dispatch({
      type: MEAT_REQUESTED
    });

    const roomCode = getState().portionRoomsInfo.currentPortionRoom.code;
    return sourceMeatResources.generateSourceMeatOrders(
      sourceMeatOrders,
      roomCode,
      usedWipBoxes => {
        dispatch({
          type: RESET_SOURCE_MEAT_ORDER_PREVIEW
        });
        dispatch({
          type: RESET_MEAT_REQUEST
        });
        successfulCallback(usedWipBoxes);
      },
      error => {
        dispatch({
          type: RESET_MEAT_REQUEST
        });
        errorHandler(error);
      }
    );
  };
};

export const getStations = () => (dispatch, getState) => {
  const roomCode = getState().portionRoomsInfo.currentPortionRoom.code;
  return cutStationResources.getStationsByRoom(roomCode).then(
    response => {
      dispatch({
        type: UPDATE_CUT_STATIONS_INFO,
        payload: response.data
      });
    },
    () => {
      dispatch({
        type: RESET_CUT_STATIONS_INFO
      });
    }
  );
};

export const getBlends = () => dispatch => {
  return yieldModelResources.getBlends().then(response => {
    dispatch({
      type: GET_BLENDS,
      payload: response.data
    });
  });
};

export const getPricingModelByBlend = (blend, errorHandler) => dispatch => {
  return yieldModelResources.getPricingModelByBlend(
    blend,
    response => {
      dispatch({
        type: SET_SELECTED_BLEND,
        payload: blend
      });
      const pricingModel = response.data;
      if (_.isEmpty(pricingModel)) {
        dispatch(stopSubmit('meatRequestByBlendForm', { blend: 'Blend has no pricing model' }));
        dispatch(setSubmitFailed('meatRequestByBlendForm'));
      } else {
        dispatch({
          type: GET_BLEND_PRICING_MODEL,
          payload: pricingModel
        });

        const sourceProductCodes = pricingModel.sourceProducts.map(({ code }) => code);

        productResources.getProductInfoByProductCodes(
          sourceProductCodes.join(','),
          productInfoResponse => {
            let formattedProductInfo = {};

            _.forEach(productInfoResponse.data, productInfo => {
              formattedProductInfo[productInfo.code] = productInfo;
            });

            dispatch({
              type: UPDATE_SOURCE_PRODUCT_INFO,
              payload: formattedProductInfo
            });
          },
          () => {}
        );
      }
    },
    errorHandler
  );
};

export const clearMeatRequestByBlendInfo = () => dispatch => {
  dispatch({
    type: CLEAR_MEAT_REQUEST_BY_BLEND_PRICING_MODEL
  });
};

export const clearMeatRequestByFinishedProduct = () => ({
  type: CLEAR_MEAT_REQUEST_BY_FINISHED_PRODUCT
});

export const displayBlendSourceMeatTable = () => dispatch => {
  dispatch({
    type: BLEND_SOURCE_MEAT_TABLE_DISPLAYED
  });
};

export const getWipBoxes = () => dispatch => {
  return boxResources.getWipBoxes(response => {
    dispatch({
      type: GRABBED_WIP_BOXES,
      payload: response.data
    });
  });
};

export const bringWipToPortionRoom = (barcode, roomCode, resetBarcode) => dispatch => {
  return boxResources
    .updateWipStatusToInPortionRoom(barcode, roomCode)
    .then(() => {
      resetBarcode();
      getWipBoxes()(dispatch);
    })
    .catch(errorResponse => {
      Validator.processErrorResponse(_.get(errorResponse, 'response.data', {}));
    });
};

export const deleteWipBox = boxId => dispatch => {
  return boxResources.deleteWipBox(boxId, () => {
    getWipBoxes()(dispatch);
  });
};

export const handleSort = newSortColumn => (dispatch, getState) => {
  const { sortColumn, sortDirection } = getState().meatRequestInfo;

  if (newSortColumn === sortColumn) {
    dispatch({
      type: UPDATED_WIP_SORTING,
      payload: {
        sortColumn,
        sortDirection: sortDirection === 'ascending' ? 'descending' : 'ascending'
      }
    });
  } else {
    dispatch({
      type: UPDATED_WIP_SORTING,
      payload: {
        sortColumn: newSortColumn,
        sortDirection: 'ascending'
      }
    });
  }
};

export const registerBarcodeField = barcodeField => {
  return {
    type: REGISTER_BARCODE_FIELD,
    payload: barcodeField
  };
};

export const focusBarcodeField = () => (dispatch, getState) => {
  const { barcodeField } = getState().meatRequestInfo;
  barcodeField.getRenderedComponent().focusInput();
};
