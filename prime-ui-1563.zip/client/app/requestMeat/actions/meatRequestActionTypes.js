export const UPDATE_CUT_STATIONS_INFO = 'updateCutStationsInfo';
export const RESET_CUT_STATIONS_INFO = 'resetCutStationsInfo';
export const RESET_SOURCE_MEAT_ORDER_PREVIEW = 'resetSourceMeatOrderPreview';
export const UPDATE_SOURCE_MEAT_ORDER_PREVIEW = 'updateSourceMeatOrderPreview';
export const GET_BLENDS = 'getBlends';
export const GET_BLEND_PRICING_MODEL = 'requestMeat/getBlendPricingModel';
export const CLEAR_MEAT_REQUEST_BY_BLEND_PRICING_MODEL =
  'requestMeat/clearMeatRequestByBlendPricingModel';
export const UPDATE_SOURCE_PRODUCT_INFO = 'requestMeat/updateSourceProductInfo';
export const BLEND_SOURCE_MEAT_TABLE_DISPLAYED = 'requestMeat/blendSourceMeatTableDisplayed';
export const PRODUCT_SOURCE_MEAT_TABLE_DISPLAYED = 'requestMeat/productSourceMeatTableDisplayed';
export const GRABBED_WIP_BOXES = '@@prime/GRABBED_WIP_BOXES';
export const UPDATED_WIP_SORTING = '@@prime/UPDATED_WIP_SORTING';
export const CLEAR_MEAT_REQUEST_BY_FINISHED_PRODUCT =
  '@@prime/CLEAR_MEAT_REQUEST_BY_FINISHED_PRODUCT';
export const REGISTER_BARCODE_FIELD = '@@prime/AVAILABLE_WIP/REGISTER_BARCODE_FIELD';
export const RESET_MEAT_REQUEST = 'requestMeat/resetMeatRequest';
export const MEAT_REQUESTED = 'requestMeat/meatRequested';
export const SET_SELECTED_BLEND = 'requestMeat/setSelectedBlend';
