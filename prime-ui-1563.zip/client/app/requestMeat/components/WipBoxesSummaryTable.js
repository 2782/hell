import _ from 'lodash';
import React from 'react';
import PropTypes from 'prop-types';
import { Table } from 'semantic-ui-react';
import { formatNumberToTwoDecimalPlacesString } from '../../shared/util/dataUtil';

export const WipBoxesSummaryRow = ({ wipBoxes }) => {
  return (
    <Table.Row>
      <Table.Cell pid={'wip-box-table__summary-row-title'} colSpan={4} width={4} textAlign='left'>
        <strong>TOTAL WIP VALUE</strong>
      </Table.Cell>
      <Table.Cell colSpan={2} width={2}>
        &nbsp;
      </Table.Cell>
      <Table.Cell pid={'wip-box-table__summary-row-value'} colSpan={2} width={2} textAlign='right'>
        <strong>
          {'$' +
            formatNumberToTwoDecimalPlacesString(
              _.sum(_.map(wipBoxes, box => box.cost * box.netWeight))
            )}
        </strong>
      </Table.Cell>
      <Table.Cell colSpan={2} width={2}>
        &nbsp;
      </Table.Cell>
      <Table.Cell colSpan={1} width={1}>
        &nbsp;
      </Table.Cell>
      <Table.Cell colSpan={2} width={2}>
        &nbsp;
      </Table.Cell>
      <Table.Cell colSpan={2} width={2}>
        &nbsp;
      </Table.Cell>
      <Table.Cell colSpan={1} width={1}>
        &nbsp;
      </Table.Cell>
    </Table.Row>
  );
};

WipBoxesSummaryRow.propTypes = {
  wipBoxes: PropTypes.array
};

export const WipBoxesSummaryTable = ({ wipBoxes }) => {
  return (
    <Table columns={16} attached>
      <Table.Body>
        <WipBoxesSummaryRow wipBoxes={wipBoxes} />
      </Table.Body>
    </Table>
  );
};

WipBoxesSummaryTable.propTypes = {
  wipBoxes: PropTypes.array
};
