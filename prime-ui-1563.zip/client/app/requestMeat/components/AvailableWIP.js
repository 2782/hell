import _ from 'lodash';
import React from 'react';
import PropTypes from 'prop-types';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import moment from 'moment/moment';
import {
  bringWipToPortionRoom,
  deleteWipBox,
  getWipBoxes,
  handleSort,
  registerBarcodeField,
  focusBarcodeField
} from '../actions/meatRequestActions';
import { showModal } from '../../shared/actions/actions';
import { wipBoxAge, WipBoxTable, wipBoxValue } from './wipBoxTable';
import FormElement from '../../shared/FormElement';
import { Divider, Form } from 'semantic-ui-react';
import { change, Field, reduxForm } from 'redux-form';
import subscriber from '../../shared/functionKeys/subscriber';

const AVAILABLE_WIP_FORM = 'availableWIP';

export class AvailableWIPPage extends React.Component {
  constructor(props) {
    super(props);

    this.submit = this.submit.bind(this);
  }

  componentDidMount() {
    this.props.getWipBoxes();
  }

  deleteWip(wipId) {
    const { showModal, deleteWipBox, focusBarcodeField } = this.props;
    showModal({
      header: 'Delete WIP',
      content: 'Are you sure you want to delete?',
      cancelButton: 'No',
      confirmButton: 'Yes',
      confirmAction: () => {
        deleteWipBox(wipId);
        focusBarcodeField();
      },
      cancelAction: () => {
        focusBarcodeField();
      }
    });
  }

  submit(values) {
    const { currentPortionRoom, bringWipToPortionRoom, resetBarcode } = this.props;
    const barcode = values['barcode'];

    if (_.isEmpty(barcode)) {
      return;
    }
    return bringWipToPortionRoom(barcode, currentPortionRoom.code, resetBarcode);
  }

  render() {
    const {
      wipBoxes,
      handleSort,
      sortColumn,
      sortDirection,
      handleSubmit,
      registerBarcodeField,
      role
    } = this.props;

    return (
      <div className='available-wip'>
        <Form pid='barcode-input-form' size={'large'} onSubmit={handleSubmit(this.submit)}>
          <Field
            autoFocus
            withRef
            ref={node => registerBarcodeField(node)}
            as={Form.Input}
            component={FormElement}
            name='barcode'
            pid='barcode-input'
            placeholder='Barcode'
            width={9}
          />
        </Form>
        <WipBoxTable
          wipBoxes={wipBoxes}
          handleSort={handleSort}
          sortColumn={sortColumn}
          sortDirection={sortDirection}
          role={role}
          deleteWip={this.deleteWip.bind(this)}
        />
        <Divider hidden className='divider-medium' />
      </div>
    );
  }
}

AvailableWIPPage.propTypes = {
  wipBoxes: PropTypes.array,
  sortColumn: PropTypes.string,
  sortDirection: PropTypes.oneOf(['ascending', 'descending']),
  currentPortionRoom: PropTypes.object,
  getWipBoxes: PropTypes.func.isRequired,
  handleSort: PropTypes.func,
  showModal: PropTypes.func,
  deleteWipBox: PropTypes.func,
  bringWipToPortionRoom: PropTypes.func,
  handleSubmit: PropTypes.func.isRequired,
  registerBarcodeField: PropTypes.func,
  focusBarcodeField: PropTypes.func,
  resetBarcode: PropTypes.func,
  role: PropTypes.string
};

export const mapStateToProps = state => {
  const { wipBoxes, sortColumn, sortDirection } = state.meatRequestInfo;

  let orderBy;
  if (!sortColumn) {
    orderBy = 'productCode'; // Page load default
  } else if ('_value' === sortColumn) {
    orderBy = wipBoxValue; // Computed column
  } else if ('_age' === sortColumn) {
    const now = moment();
    orderBy = wipBox => wipBoxAge(wipBox, now); // Computed column
  } else {
    orderBy = sortColumn;
  }

  const sortedWipBoxes = _.orderBy(
    wipBoxes,
    [orderBy],
    ['ascending' === sortDirection ? 'asc' : 'descending' === sortDirection ? 'desc' : 'asc']
  );

  return {
    wipBoxes: sortedWipBoxes,
    sortColumn: sortColumn ? sortColumn : 'productCode',
    sortDirection: sortDirection ? sortDirection : 'ascending',
    currentPortionRoom: state.portionRoomsInfo.currentPortionRoom,
    role: state.login.role
  };
};

export const f5Behavior = props => {
  const { resetBarcode, focusBarcodeField } = props;
  resetBarcode();
  focusBarcodeField();
};

const mapDispatchToProps = dispatch =>
  bindActionCreators(
    {
      getWipBoxes,
      handleSort,
      showModal,
      deleteWipBox,
      bringWipToPortionRoom,
      registerBarcodeField,
      focusBarcodeField,
      resetBarcode: () => dispatch(change(AVAILABLE_WIP_FORM, 'barcode', ''))
    },
    dispatch
  );

const AvailableWIP = connect(
  mapStateToProps,
  mapDispatchToProps
)(
  reduxForm({
    form: AVAILABLE_WIP_FORM
  })(
    subscriber(AvailableWIPPage, {
      f5Behavior,
      targetComponent: 'AvailableWIPPage',
      uris: {
        F5: ['#/meat-request/available-wip']
      }
    })
  )
);

export default AvailableWIP;
