import {
  inRange,
  isBlank,
  isNumeric,
  isPositiveInt,
  isWholeNumber
} from '../../shared/util/validation';
import _ from 'lodash';
import { SubmissionError } from 'redux-form';

const maxQuantity = 100000; // "99,999" is the max amount; the check is for < this value

export const validateMeatRequest = values => {
  const { sourceMeatQuantity, additives } = values;

  const totalQty = sourceMeatQuantity + _.sumBy(additives, additive => additive.quantity);
  if (totalQty <= 0) {
    throw new SubmissionError({
      _error: 'Total quantity requested for source meat and additives must be greater than 0.'
    });
  }
};

export const isInRange = (minValue, maxValue, inclusivity = '()') => value => {
  if (!inRange(value, minValue, maxValue, inclusivity)) {
    return 'quantity is invalid';
  } else {
    return undefined;
  }
};

const quantityValid = (minValue, maxValue) => value => {
  return (
    !isBlank(value) &&
    isNumeric(value) &&
    isWholeNumber(value) &&
    isPositiveInt(value) &&
    inRange(value, minValue, maxValue)
  );
};

export const isQuantityInRangeBottomInclusive = isInRange(0, maxQuantity, '[)');

export const isQuantityInRange = isInRange(0, maxQuantity);

export const isQuantityInRangeForBlend = isInRange(0, maxQuantity, '[)');

export const isQuantityValid = quantityValid(0, maxQuantity);

export const isQuantityValidForBlend = quantityValid(0, maxQuantity);
