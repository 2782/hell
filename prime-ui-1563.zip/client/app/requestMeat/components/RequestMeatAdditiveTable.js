import React from 'react';
import PropTypes from 'prop-types';
import { Form, Table } from 'semantic-ui-react';
import { Field, FieldArray } from 'redux-form';
import FormElement from '../../shared/FormElement';
import {
  nonNegativeNumber,
  number,
  required,
  wholeNumber
} from '../../shared/validation/formFieldValidations';
import { isQuantityInRangeBottomInclusive } from './meatRequestValidator';
import { reportingTableHelpers } from '../../productActivity/helpers';

const RequestMeatAdditiveTable = ({ additives }) => {
  return (
    <Table columns={3} fixed size='small'>
      <Table.Header>
        <Table.Row>
          <Table.HeaderCell width={5} textAlign='left'>
            Additives
          </Table.HeaderCell>
          <Table.HeaderCell width={8}>&nbsp;</Table.HeaderCell>
          <Table.HeaderCell width={3} textAlign='left'>
            Quantity
          </Table.HeaderCell>
          <Table.HeaderCell width={3}>U/M</Table.HeaderCell>
        </Table.Row>
      </Table.Header>
      <Table.Body>
        <FieldArray name='additives' component={additiveRow} additives={additives} />
      </Table.Body>
    </Table>
  );
};

export const additiveRow = ({ fields, additives }) => {
  {
    return fields.map((member, index) => {
      return (
        <Table.Row key={index}>
          <Table.Cell width={5}>{additives[index].productCode}</Table.Cell>
          <Table.Cell width={8}>{additives[index].productDesc}</Table.Cell>
          <Table.Cell width={3} align='left'>
            <Field
              component={FormElement}
              name={`${member}.quantity`}
              fluid
              pid={`additive-quantity-${additives[index].productCode}`}
              as={Form.Input}
              validate={[
                required,
                number,
                wholeNumber,
                nonNegativeNumber,
                isQuantityInRangeBottomInclusive
              ]}
              type='text'
            />
          </Table.Cell>
          <Table.Cell width={3}>
            {reportingTableHelpers.formatUnitOfMeasure(additives[index].unitOfMeasure)}
          </Table.Cell>
        </Table.Row>
      );
    });
  }
};

RequestMeatAdditiveTable.propTypes = {
  additives: PropTypes.array
};

export default RequestMeatAdditiveTable;
