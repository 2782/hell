import moment from 'moment/moment';
import _ from 'lodash';
import { wipBoxAge, wipBoxValue } from './wipBoxTable';
import React from 'react';
import PropTypes from 'prop-types';
import { Table } from 'semantic-ui-react';
import { formatNumberToTwoDecimalPlacesString } from '../../shared/util/dataUtil';

export const WipBoxTableBody = ({ wipBoxes, deleteWip, role }) => {
  const now = moment();

  return (
    <Table.Body>
      {_.map(wipBoxes, (wipBox, index) => {
        const portionSize = wipBox.productPortionSize.portionSize;
        const productInfo = `${wipBox.productCode} / ${portionSize}`;

        return (
          <Table.Row pid={`wip-box-table__table-row-${index}`} key={wipBox.id}>
            <Table.Cell colSpan={4} width={4} textAlign='left'>
              <div pid='wip-box-table__product-info'>{productInfo}</div>
              <span pid='wip-box-table__product-description' className='product-description'>
                {wipBox.productDesc}
              </span>
            </Table.Cell>
            <Table.Cell colSpan={2} width={2} textAlign='right'>
              {formatNumberToTwoDecimalPlacesString(wipBox.netWeight)}
            </Table.Cell>
            <Table.Cell colSpan={2} width={2} textAlign='right'>
              {'$' + formatNumberToTwoDecimalPlacesString(wipBoxValue(wipBox))}
            </Table.Cell>
            <Table.Cell colSpan={2} width={2} textAlign='left'>
              {wipBox.productionProduct ? 'FINISHED' : 'SOURCE'}
            </Table.Cell>
            <Table.Cell colSpan={1} width={1} textAlign='right'>
              {wipBoxAge(wipBox, now)}
            </Table.Cell>
            <Table.Cell colSpan={2} width={2} textAlign='left'>
              {wipBox.status}
            </Table.Cell>
            <Table.Cell colSpan={2} width={2} textAlign='right'>
              {wipBox.portionRoomDesc ? wipBox.portionRoomDesc : ''}
            </Table.Cell>
            {role === 'ROLE_ADMIN' ? (
              <Table.Cell
                colSpan={1}
                width={1}
                className={'action'}
                onClick={() => {
                  deleteWip(wipBox.id);
                }}
              >
                <i className='icon-delete' />
              </Table.Cell>
            ) : (
              <Table.Cell colSpan={1} width={1} className={'action'} />
            )}
          </Table.Row>
        );
      })}
    </Table.Body>
  );
};

WipBoxTableBody.propTypes = {
  wipBoxes: PropTypes.array,
  deleteWip: PropTypes.func,
  role: PropTypes.string
};
