import _ from 'lodash';
import React, { Fragment } from 'react';
import moment from 'moment/moment';
import PropTypes from 'prop-types';
import EmptyTableMessage from '../../shared/components/EmptyTableMessage';
import { Table } from 'semantic-ui-react';
import { WipBoxTableHeader } from './wipBoxTableHeader';
import { WipBoxTableBody } from './wipBoxTableBody';
import { WipBoxesSummaryTable } from './WipBoxesSummaryTable';
import { ISO_DATE_FORMAT } from '../../shared/util/dateUtil';

export const WipBoxTable = ({
  wipBoxes,
  handleSort,
  sortColumn,
  sortDirection,
  deleteWip,
  role
}) => {
  return (
    <Fragment>
      <Table size='small' columns={16} fixed attached='top' sortable>
        <WipBoxTableHeader
          handleSort={handleSort}
          sortColumn={sortColumn}
          sortDirection={sortDirection}
        />
        <WipBoxTableBody wipBoxes={wipBoxes} deleteWip={deleteWip} role={role} />
      </Table>
      <WipBoxesSummaryTable wipBoxes={wipBoxes} />
      {wipBoxes === null ? null : _.isEmpty(wipBoxes) ? (
        <EmptyTableMessage className='prime-list-empty-message' />
      ) : null}
    </Fragment>
  );
};

WipBoxTable.propTypes = {
  wipBoxes: PropTypes.array,
  handleSort: PropTypes.func,
  deleteWip: PropTypes.func,
  sortColumn: PropTypes.string,
  sortDirection: PropTypes.string,
  role: PropTypes.string
};

export const wipBoxValue = wipBox => {
  return wipBox.cost * wipBox.netWeight;
};

export const wipBoxAge = (wipBox, now) => {
  const packedDate = moment(wipBox.packDate).format(ISO_DATE_FORMAT);
  return now.diff(packedDate, 'days');
};
