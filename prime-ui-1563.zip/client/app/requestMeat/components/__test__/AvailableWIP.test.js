import _ from 'lodash';
import React from 'react';
import { AvailableWIPPage, mapStateToProps, f5Behavior } from '../AvailableWIP';
import { AVAILABLE_WIP_BOX, RESERVED_WIP_BOX } from '../../../../test-factories/wipBoxFactory';
import semanticUI from '../../../../test-helpers/semantic-ui';
import { createReduxStore } from '../../../store';
import { reduxForm } from 'redux-form';
import { Provider } from 'react-redux';
import { mount } from 'enzyme/build/index';
import { updateWipStatusToInPortionRoom } from '../../../shared/api/boxResources';

jest.mock('../../../shared/api/boxResources', () => ({
  updateWipStatusToInPortionRoom: jest.fn()
}));

const wipBoxes = [AVAILABLE_WIP_BOX, RESERVED_WIP_BOX];

const portionRoomsInfo = {
  portionRoomsInfo: {
    currentPortionRoom: {
      roomType: 'CUTTING',
      code: 'TEST_CUTTING_ROOM_CODE'
    }
  }
};

describe('AvailableWIP', () => {
  describe('WIP barcode search', () => {
    let wrapper, DecoratedComponent, registerBarcodeField;

    beforeEach(() => {
      registerBarcodeField = jest.fn();
      DecoratedComponent = reduxForm({ form: 'testForm' })(AvailableWIPPage);
    });

    test('should render mapping fields', () => {
      wrapper = mount(
        <Provider store={createReduxStore({})}>
          <DecoratedComponent getWipBoxes={() => {}} registerBarcodeField={registerBarcodeField} />
        </Provider>
      );
      jestExpect(semanticUI.getInputValue(wrapper, 'barcode')).toEqual('');
    });

    test('should dispatch bring to portion room action', () => {
      updateWipStatusToInPortionRoom.mockImplementation(() => Promise.resolve({}));
      const bringWipToPortionRoomSpy = jest.fn();
      const resetBarcode = jest.fn();

      const currentPortionRoom = {
        roomType: 'CUTTING',
        code: 'TEST_CUTTING_ROOM_CODE'
      };

      wrapper = mount(
        <Provider store={createReduxStore({})}>
          <DecoratedComponent
            getWipBoxes={() => {}}
            bringWipToPortionRoom={bringWipToPortionRoomSpy}
            currentPortionRoom={currentPortionRoom}
            registerBarcodeField={registerBarcodeField}
            resetBarcode={resetBarcode}
          />
        </Provider>
      );

      semanticUI.changeInput(wrapper, 'barcode', 'XXX');

      wrapper.find('form').simulate('submit');

      jestExpect(bringWipToPortionRoomSpy).toHaveBeenCalledWith(
        'XXX',
        'TEST_CUTTING_ROOM_CODE',
        resetBarcode
      );
    });
  });

  describe('AvailableWIP Component', () => {
    test('should call getWipBoxes when componentDidMount', () => {
      const getWipBoxes = jest.fn();
      const availableWIP = new AvailableWIPPage({
        wipBoxes: [],
        getWipBoxes
      });

      availableWIP.componentDidMount();

      jestExpect(getWipBoxes).toHaveBeenCalled();
    });

    test('should call showModal when call deleteWip', () => {
      const showModal = jest.fn();
      const getWipBoxes = jest.fn();

      const availableWIP = new AvailableWIPPage({
        wipBoxes: [],
        getWipBoxes,
        showModal
      });

      availableWIP.deleteWip(1);

      jestExpect(showModal).toHaveBeenCalledWith({
        header: 'Delete WIP',
        content: 'Are you sure you want to delete?',
        cancelButton: 'No',
        confirmButton: 'Yes',
        confirmAction: jestExpect.any(Function),
        cancelAction: jestExpect.any(Function)
      });
    });
  });

  describe('mapStateToProps', () => {
    test('should initially sort by product code ascending', () => {
      const state = {
        meatRequestInfo: {
          wipBoxes
        },
        portionRoomsInfo,
        login: {
          role: 'ROLE_ADMIN'
        }
      };
      jestExpect(_.map(mapStateToProps(state).wipBoxes, 'productCode')).toEqual([
        '3102218',
        '4102218'
      ]);
    });

    test('should sort for value', () => {
      const state = {
        meatRequestInfo: {
          wipBoxes,
          sortColumn: '_value',
          sortDirection: 'ascending'
        },
        portionRoomsInfo,
        login: {
          role: 'ROLE_ADMIN'
        }
      };
      jestExpect(_.map(mapStateToProps(state).wipBoxes, 'productCode')).toEqual([
        '4102218',
        '3102218'
      ]);
    });

    test('should sort for age', () => {
      const state = {
        meatRequestInfo: {
          wipBoxes,
          sortColumn: '_age',
          sortDirection: 'descending'
        },
        portionRoomsInfo,
        login: {
          role: 'ROLE_ADMIN'
        }
      };
      jestExpect(_.map(mapStateToProps(state).wipBoxes, 'productCode')).toEqual([
        '4102218',
        '3102218'
      ]);
    });
  });

  describe('f5 Behavior', () => {
    test('should clear fields on f5 pressing', () => {
      const props = {
        resetBarcode: jest.fn(),
        focusBarcodeField: jest.fn()
      };

      f5Behavior(props);

      jestExpect(props.resetBarcode).toHaveBeenCalled();
      jestExpect(props.focusBarcodeField).toHaveBeenCalled();
    });
  });
});
