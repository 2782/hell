import { validateSubmission } from '../meatRequestByProductFormValidator';

describe('meatRequestByProductFormValidator', () => {
  const VALID_FINISHED_PRODUCT_CODE = '0078889';
  const VALID_STATION_CODE = '2';
  const VALID_QUANTITY = 1;

  describe('submission validation', () => {
    test('should call submit with given values', () => {
      const values = {
        finishedProductCode: VALID_FINISHED_PRODUCT_CODE,
        quantity: VALID_QUANTITY,
        stationCode: VALID_STATION_CODE
      };

      validateSubmission(values);
    });

    test('should check that all fields are required', () => {
      try {
        validateSubmission({});
        jest.fail('Expected SubmissionError to be thrown.');
      } catch ({ errors }) {
        jestExpect(errors.finishedProductCode).toEqual('Required');
      }
    });
  });
});
