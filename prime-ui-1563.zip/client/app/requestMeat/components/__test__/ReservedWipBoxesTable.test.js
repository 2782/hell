import React from 'react';
import { mount, shallow } from 'enzyme';
import ReservedWipBoxesTable from '../ReservedWipBoxesTable';
import { Table } from 'semantic-ui-react';
import wipBoxFactory from '../../../../test-factories/wipBoxFactory';

describe('ReservedWipBoxesTable', () => {
  const reservedBoxes = [
    wipBoxFactory.build(),
    wipBoxFactory.build({ id: 123, productCode: '4102218', netWeight: 44 })
  ];

  test('should render statement before table', () => {
    const wrapper = shallow(<ReservedWipBoxesTable reservedWipBoxes={[]} />);

    jestExpect(wrapper.find('span').text()).toEqual(
      'You need to retrieve the following source meats from WIP. ' +
        'All other requested items will be brought from inventory.'
    );
  });

  test('should render header with proper columns', () => {
    const wrapper = mount(<ReservedWipBoxesTable reservedWipBoxes={[]} />);

    const headerRow = wrapper.find(Table.Header).find(Table.Row);

    function getHeaderText(index) {
      return headerRow
        .find(Table.HeaderCell)
        .at(index)
        .text();
    }

    jestExpect(getHeaderText(0)).toEqual('PRODUCT');
    jestExpect(getHeaderText(2)).toEqual('AGE (DAYS)');
    jestExpect(getHeaderText(3)).toEqual('QTY (LBS)');
  });

  test('should render rows properly', () => {
    const wrapper = mount(<ReservedWipBoxesTable reservedWipBoxes={reservedBoxes} />);
    const tableRows = wrapper.find(Table.Body).find(Table.Row);
    jestExpect(tableRows.length).toEqual(2);

    function getCell(row, column) {
      return tableRows
        .at(row)
        .find(Table.Cell)
        .at(column)
        .text();
    }

    jestExpect(getCell(0, 0)).toEqual('3102218');
    jestExpect(getCell(1, 0)).toEqual('4102218');
    jestExpect(getCell(0, 1)).toEqual('Product Desc for 3102218');
    jestExpect(getCell(1, 1)).toEqual('Product Desc for 3102218');
    jestExpect(getCell(0, 2)).toEqual('1');
    jestExpect(getCell(1, 2)).toEqual('1');
    jestExpect(getCell(0, 3)).toEqual('15');
    jestExpect(getCell(1, 3)).toEqual('44');
  });
});
