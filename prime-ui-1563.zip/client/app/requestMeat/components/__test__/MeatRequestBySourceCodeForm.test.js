import React from 'react';
import { mount } from 'enzyme';
import MeatRequestBySourceCodeForm, {
  f4Behavior,
  generateStationOptions
} from '../MeatRequestBySourceCodeForm';
import cutStationResources from '../../../shared/api/stationResources';
import { createReduxStore } from '../../../store';
import semanticUI from '../../../../test-helpers/semantic-ui';
import productResources from '../../../shared/api/productResources';
import productFactory from '../../../../test-factories/productFactory';
import StationFactory from '../../../../test-factories/station';
import { Provider } from 'react-redux';
import { CREATE_SOURCE_MEAT_REQUEST_MESSAGE } from '../../../../config/errorMessage';
import { showModal } from '../../../shared/actions/actions';
import ReservedWipBoxesTable from '../ReservedWipBoxesTable';
import { RESERVED_WIP_BOX } from '../../../../test-factories/wipBoxFactory';
import sourceMeatResources from '../../../shared/api/sourceMeatResources';

jest.mock('../../../shared/actions/actions', () => ({
  showModal: jest.fn()
}));

jest.mock('../../../shared/api/productResources');
jest.mock('../../../shared/api/sourceMeatResources');
jest.mock('../../../shared/api/stationResources');

describe('meatRequestBySourceCodeForm', () => {
  let form;

  beforeEach(async () => {
    productResources.getProductInfo.mockImplementation((arg, success) =>
      success(productFactory.build())
    );
    cutStationResources.getStationsByRoom.mockResolvedValue({
      data: [
        StationFactory.build({ id: 1, stationCode: 12, name: 'cutter' }),
        StationFactory.build({ id: 2, stationCode: 13, name: 'cutter Steak' })
      ]
    });

    let store = createReduxStore({
      portionRoomsInfo: {
        currentPortionRoom: {
          code: 'A'
        }
      }
    });
    form = mount(
      <Provider store={store}>
        <MeatRequestBySourceCodeForm />
      </Provider>
    );

    await waitForAsyncTasks(form);
  });

  afterEach(() => {
    sourceMeatResources.generateSourceMeatOrders.mockReset();
    productResources.getProductInfo.mockReset();
    cutStationResources.getStationsByRoom.mockReset();
  });

  describe('should render input component', () => {
    test('should render input component', () => {
      jestExpect(semanticUI.getInputValue(form, 'sourceProductCode')).toEqual('');
      jestExpect(semanticUI.getInputValue(form, 'quantity')).toEqual('');
      jestExpect(semanticUI.getSelectValue(form, 'stationCode')).toEqual(undefined);
      jestExpect(semanticUI.getSelectValue(form, 'unitOfMeasure')).toEqual('CASE');
    });

    test('should render selection for stationCode with correct props', () => {
      semanticUI.selectOption(form, 'stationCode', 1);
      jestExpect(semanticUI.getSelectValue(form, 'stationCode')).toEqual(13);
    });
  });

  test('should submit values to API and not call modal when no WIP is received', () => {
    showModal.mockImplementation(() => ({ type: 'MOCK_SHOW_MODAL_ACTION' }));
    const maxQuantity = '99999';
    productResources.getProductInfo.mockImplementation((arg, success) =>
      success({ data: productFactory.build({ code: '0078889' }) })
    );
    semanticUI.selectOption(form, 'stationCode', 1);
    semanticUI.changeInput(form, 'sourceProductCode', '78889');
    semanticUI.changeInput(form, 'quantity', maxQuantity);
    form.update();
    jestExpect(semanticUI.getSelectValue(form, 'stationCode')).toEqual(13);

    form.find('form').simulate('submit');

    jestExpect(showModal).not.toHaveBeenCalledWith({
      header: 'Retrieve from WIP',
      content:
        'You need to retrieve the following source meats from WIP. ' +
        'All other requested items will be brought from inventory.',
      confirmButton: 'ok',
      confirmAction: jestExpect.anything()
    });
  });

  test('should show modal on successful call', () => {
    showModal.mockImplementation(() => ({ type: 'MOCK_SHOW_MODAL_ACTION' }));
    sourceMeatResources.generateSourceMeatOrders.mockImplementation((arg1, arg2, success) =>
      success({ data: [RESERVED_WIP_BOX] })
    );
    const maxQuantity = '99999';

    productResources.getProductInfo.mockImplementation((arg, success) =>
      success({ data: productFactory.build({ code: '0078889' }) })
    );
    semanticUI.selectOption(form, 'stationCode', 1);
    semanticUI.changeInput(form, 'sourceProductCode', '78889');
    semanticUI.changeInput(form, 'quantity', maxQuantity);
    form.update();
    jestExpect(semanticUI.getSelectValue(form, 'stationCode')).toEqual(13);

    form.find('form').simulate('submit');
    jestExpect(sourceMeatResources.generateSourceMeatOrders.mock.calls[0]).toEqual(
      jestExpect.arrayContaining([
        [
          {
            productCode: '0078889',
            productDesc: 'QB, PRIME T-BONE STEAK 205',
            quantity: maxQuantity,
            roomCode: 'A',
            stationId: 2,
            unitOfMeasure: 'CASE'
          }
        ],
        'A'
      ])
    );

    jestExpect(showModal).toHaveBeenCalledWith({
      header: 'Retrieve from WIP',
      content: ReservedWipBoxesTable({ reservedWipBoxes: [RESERVED_WIP_BOX] }),
      confirmButton: 'ok',
      confirmAction: jestExpect.anything()
    });
  });

  test('should not submit form when exceeding max Quantity', () => {
    const excedingMaxQuantity = '100000';
    productResources.getProductInfo.mockImplementation((arg, success) =>
      success({ data: productFactory.build({ code: '0078889' }) })
    );
    semanticUI.selectOption(form, 'stationCode', 1);
    semanticUI.changeInput(form, 'sourceProductCode', '78889');
    semanticUI.changeInput(form, 'quantity', excedingMaxQuantity);
    form.update();
    jestExpect(semanticUI.getSelectValue(form, 'stationCode')).toEqual(13);

    form.find('form').simulate('submit');

    jestExpect(sourceMeatResources.generateSourceMeatOrders).not.toHaveBeenCalled();
  });

  test('should not submit form if source product code is invalid', () => {
    semanticUI.selectOption(form, 'stationCode', 1);
    semanticUI.changeInput(form, 'sourceProductCode', '78881');
    semanticUI.changeInput(form, 'quantity', '10');
    form.update();
    jestExpect(semanticUI.getSelectValue(form, 'stationCode')).toEqual(13);

    form.find('form').simulate('submit');

    jestExpect(sourceMeatResources.generateSourceMeatOrders).not.toHaveBeenCalled();
  });

  test('should not submit successfully when sourceProductCode does not exist in API', () => {
    productResources.getProductInfo.mockImplementation((arg, success, fail) => fail());

    semanticUI.selectOption(form, 'stationCode', 1);
    semanticUI.changeInput(form, 'sourceProductCode', '72821');
    semanticUI.changeInput(form, 'quantity', '5');

    form.find('form').simulate('submit');

    jestExpect(sourceMeatResources.generateSourceMeatOrders).not.toHaveBeenCalled();
  });

  test('should show error when generateMeatRequest failed', () => {
    sourceMeatResources.generateSourceMeatOrders.mockImplementation((arg1, arg2, arg3, callback) =>
      callback({ message: 'generate source meat order failed' })
    );

    productResources.getProductInfo.mockImplementation((arg, success) =>
      success({ data: productFactory.build({ code: '0078889' }) })
    );
    semanticUI.selectOption(form, 'stationCode', 1);
    semanticUI.changeInput(form, 'sourceProductCode', '0078889');
    semanticUI.changeInput(form, 'quantity', '5');

    form.find('form').simulate('submit');

    jestExpect(form.find('span.meat-request-error').text()).toEqual(
      'generate source meat order failed'
    );
  });

  test('when an error happens during submitting meat request, should show error', () => {
    sourceMeatResources.generateSourceMeatOrders.mockImplementation((arg1, arg2, arg3, callback) =>
      callback({ message: CREATE_SOURCE_MEAT_REQUEST_MESSAGE })
    );

    productResources.getProductInfo.mockImplementation((arg, success) =>
      success({ data: productFactory.build({ code: '0078889' }) })
    );
    semanticUI.selectOption(form, 'stationCode', 1);
    semanticUI.changeInput(form, 'sourceProductCode', '0078889');
    semanticUI.changeInput(form, 'quantity', '5');

    form.find('form').simulate('submit');

    jestExpect(form.find('span.meat-request-error').text()).toEqual(
      CREATE_SOURCE_MEAT_REQUEST_MESSAGE
    );
  });

  test('should clear source code model from store after successful submit', () => {
    let product = productFactory.PRODUCT_1;
    let store = createReduxStore({
      product: {
        'meatRequestBySourceForm-sourceProductCode': {
          product
        }
      }
    });

    form = mount(
      <Provider store={store}>
        <MeatRequestBySourceCodeForm />
      </Provider>
    );

    form.unmount();

    jestExpect(store.getState().product['meatRequestBySourceCodeForm-sourceProductCode']).toEqual(
      undefined
    );
  });
});

describe('f4 Behavior', () => {
  test('should hide modal on f4 when modal is showing', () => {
    const props = {
      isModalShowing: true,
      hideModal: jest.fn(),
      replacePath: jest.fn()
    };

    f4Behavior(props);

    jestExpect(props.hideModal).toHaveBeenCalledTimes(1);
  });

  test('should return to table selection on f4 when no orders are selected', () => {
    const props = {
      isModalShowing: false,
      hideModal: jest.fn(),
      replacePath: jest.fn()
    };

    f4Behavior(props);

    jestExpect(props.replacePath).toHaveBeenCalledWith('/main-navigation');
  });
});

describe('generate station options', () => {
  const stations = [
    { stationCode: 'A', name: 'Room A', type: 'PRODUCTION' },
    { stationCode: 'B', name: 'Room B', type: 'PACKOFF' },
    { stationCode: 'C', name: 'Room C', type: 'PRODUCTION' }
  ];

  test('should design array to expected results', () => {
    const expectedArray = [
      { key: 0, text: 'A - Room A', value: 'A' },
      { key: 1, text: 'C - Room C', value: 'C' }
    ];

    const result = generateStationOptions(stations);

    jestExpect(result).toEqual(expectedArray);
  });

  test('should return empty array if stations is empty', () => {
    const result = generateStationOptions([]);

    jestExpect(result).toEqual([]);
  });

  test('should return empty array if stations is null', () => {
    const result = generateStationOptions(null);

    jestExpect(result).toEqual([]);
  });
});
