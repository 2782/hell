import React from 'react';
import { Table } from 'semantic-ui-react';
import { mount } from 'enzyme/build/index';
import EmptyTableMessage from '../../../shared/components/EmptyTableMessage';
import { AVAILABLE_WIP_BOX, RESERVED_WIP_BOX } from '../../../../test-factories/wipBoxFactory';
import { WipBoxTable } from '../wipBoxTable';
import semanticUI from '../../../../test-helpers/semantic-ui';

const wipBoxes = [AVAILABLE_WIP_BOX, RESERVED_WIP_BOX];

describe('WipBoxTable', () => {
  describe('WipBoxTable Component', () => {
    let wrapper;
    let deleteWip = jest.fn();

    beforeEach(() => {
      wrapper = mount(
        <WipBoxTable
          wipBoxes={wipBoxes}
          handleSort={() => {}}
          sortColumn={undefined}
          sortDirection={undefined}
          role='ROLE_ADMIN'
          deleteWip={deleteWip}
        />
      );
    });

    test('should render Wip table header', () => {
      const header = semanticUI.findTable(wrapper, 0).find('th');

      jestExpect(header.at(0)).toHaveText('PRODUCT');
      jestExpect(header.at(1)).toHaveText('QTY (LBS)');
      jestExpect(header.at(2)).toHaveText('VALUE');
      jestExpect(header.at(3)).toHaveText('TYPE');
      jestExpect(header.at(4)).toHaveText('AGE');
      jestExpect(header.at(5)).toHaveText('STATUS');
      jestExpect(header.at(6)).toHaveText('LOCATION');
      jestExpect(header.at(7)).toHaveText('');
    });

    test('should render wip table body correctly', () => {
      const tableBody = wrapper.find('tbody').at(0);
      const findCell = createCellSelector(tableBody);

      jestExpect(
        tableBody
          .find('tr')
          .at(0)
          .parent()
          .key()
      ).toEqual('456');
      jestExpect(findCell(0, 0).find('div[pid="wip-box-table__product-info"]')).toHaveText(
        '3102218 / 17.8#AVG'
      );
      jestExpect(findCell(0, 0).find('span[pid="wip-box-table__product-description"]')).toHaveText(
        'Product Desc for 3102218'
      );
      jestExpect(findCell(0, 1)).toHaveText('15.00');
      jestExpect(findCell(0, 2)).toHaveText('$68.40');
      jestExpect(findCell(0, 3)).toHaveText('SOURCE');
      jestExpect(findCell(0, 4)).toHaveText('1');
      jestExpect(findCell(0, 5)).toHaveText('AVAILABLE');
      jestExpect(findCell(0, 6)).toHaveText('');
      jestExpect(findCell(0, 7).find('i')).toExist();

      jestExpect(
        tableBody
          .find('tr')
          .at(1)
          .parent()
          .key()
      ).toEqual('123');
      jestExpect(findCell(1, 0).find('div[pid="wip-box-table__product-info"]')).toHaveText(
        '4102218 / 7.8 OZ'
      );
      jestExpect(findCell(1, 0).find('span[pid="wip-box-table__product-description"]')).toHaveText(
        'Product Desc for 4102218'
      );

      jestExpect(findCell(1, 1)).toHaveText('10.00');
      jestExpect(findCell(1, 2)).toHaveText('$12.30');
      jestExpect(findCell(1, 3)).toHaveText('FINISHED');
      jestExpect(findCell(1, 4)).toHaveText('2');
      jestExpect(findCell(1, 5)).toHaveText('RESERVED');
      jestExpect(findCell(1, 6)).toHaveText('Room C');
      jestExpect(findCell(1, 7).find('i')).toExist();

      const summaryTable = wrapper.find('tbody').at(1);
      const findSummaryCell = createCellSelector(summaryTable);

      jestExpect(findSummaryCell(0, 0)).toHaveText('TOTAL WIP VALUE');
      jestExpect(findSummaryCell(0, 2)).toHaveText('$80.70');

      function createCellSelector(tableBody) {
        return function(row, column) {
          return semanticUI.findTableColumnWithRowIndex(tableBody, row, column);
        };
      }
    });

    test('should render wip table body without delete button', () => {
      wrapper = mount(
        <WipBoxTable
          wipBoxes={wipBoxes}
          handleSort={() => {}}
          sortColumn={undefined}
          sortDirection={undefined}
          role='ROLE_PORTION_ROOM_MEMBER'
          deleteWip={deleteWip}
        />
      );

      const tableBody = wrapper.find('tbody').at(0);
      const findCell = createCellSelector(tableBody);

      jestExpect(findCell(0, 7).find('i')).not.toExist();
      jestExpect(findCell(1, 7).find('i')).not.toExist();

      function createCellSelector(tableBody) {
        return function(row, column) {
          return semanticUI.findTableColumnWithRowIndex(tableBody, row, column);
        };
      }
    });

    test('should call deleteWip when click delete icon', () => {
      const tableRows = wrapper.find(Table.Body).find(Table.Row);
      tableRows
        .at(1)
        .find(Table.Cell)
        .at(7)
        .find('i')
        .simulate('click');
      jestExpect(deleteWip).toHaveBeenCalledWith(123);
    });

    test('should show EmptyTableMessage when wipBoxes is not empty', () => {
      jestExpect(wrapper.find(EmptyTableMessage)).not.toExist();
    });

    test('should show EmptyTableMessage when wipBoxes is empty', () => {
      wrapper = mount(
        <WipBoxTable
          wipBoxes={[]}
          handleSort={() => {}}
          sortColumn={undefined}
          sortDirection={undefined}
        />
      );
      jestExpect(wrapper.find(EmptyTableMessage)).toExist();
    });
  });
});
