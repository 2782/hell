import React from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { change, Field, FieldArray, reduxForm, SubmissionError } from 'redux-form';
import FormElement from '../../shared/FormElement';
import { Button, Divider, Form } from 'semantic-ui-react';
import PropTypes from 'prop-types';
import {
  clearMeatRequestByBlendInfo,
  displayBlendSourceMeatTable,
  getBlends,
  getPricingModelByBlend
} from '../actions/meatRequestActions';
import MeatRequestSourceProductsTable from './MeatRequestSourceProductsTable';
import _ from 'lodash';
import sourceMeatResources from '../../shared/api/sourceMeatResources';
import {
  number,
  positiveNumber,
  required,
  wholeNumber
} from '../../shared/validation/formFieldValidations';
import { isQuantityInRangeForBlend, isQuantityValidForBlend } from './meatRequestValidator';
import subscriber from '../../shared/functionKeys/subscriber';
import ReservedWipBoxesTable from './ReservedWipBoxesTable';
import { hideModal, replacePath, showModal } from '../../shared/actions/actions';

const unitOfMeasureOptions = [
  {
    key: 0,
    text: 'LBS',
    value: 'LBS'
  }
];

export const calcSourceProductQty = (targetProductQty, blendPricingModel, sourceProduct) => {
  if (!isQuantityValidForBlend(targetProductQty)) {
    return '';
  }

  const wastePercentage = blendPricingModel.wastePercentage / 100;
  const sourceProductBlendPercentage = sourceProduct.blendPercentage / 100;
  const sourceQty = (targetProductQty / (1 - wastePercentage)) * sourceProductBlendPercentage;

  return Math.ceil(sourceQty);
};

export class MeatRequestByBlendFormComponent extends React.Component {
  constructor(props) {
    super(props);

    this.handleBlendChange = this.handleBlendChange.bind(this);
    this.submit = this.submit.bind(this);
    this.updateSourceProductQuantity = this.updateSourceProductQuantity.bind(this);
    this.displayBlendSourceMeatTable = this.displayBlendSourceMeatTable.bind(this);
  }

  componentDidMount() {
    this.props.getBlends();
  }

  componentWillUnmount() {
    this.props.clearMeatRequestByBlendInfo();
  }

  submit(values) {
    const { currentRoomCode, showModal } = this.props;

    if (_.isEmpty(values.sourceProducts)) {
      throw new SubmissionError({ sourceProducts: 'Required' });
    }

    const request = values.sourceProducts
      .filter(sourceProduct => sourceProduct.quantity > 0)
      .map(({ code, description, quantity }) => {
        return {
          productCode: code,
          productDesc: description,
          quantity: quantity,
          unitOfMeasure: 'LBS',
          roomCode: currentRoomCode
        };
      });

    return sourceMeatResources.generateSourceMeatOrders(
      request,
      currentRoomCode,
      usedWipBoxes => {
        if (!_.isEmpty(usedWipBoxes.data)) {
          showModal({
            header: 'Retrieve from WIP',
            content: ReservedWipBoxesTable({ reservedWipBoxes: usedWipBoxes.data }),
            confirmButton: 'ok',
            confirmAction: () => {}
          });
        }
      },
      error => {
        throw new SubmissionError({
          _error: error.message
        });
      }
    );
  }

  showFormError() {
    if (this.props.error) {
      return <span className={'ui red message meat-request-error'}>{this.props.error}</span>;
    }
  }

  updateSourceProductQuantity(event, value) {
    const { blendPricingModel, change, showBlendSourceMeatTable } = this.props;

    if (!showBlendSourceMeatTable) {
      return;
    }

    if (!_.isEmpty(blendPricingModel) && !_.isEmpty(blendPricingModel.sourceProducts)) {
      blendPricingModel.sourceProducts.forEach((sourceProduct, index) => {
        change(
          `sourceProducts[${index}].quantity`,
          calcSourceProductQty(value, blendPricingModel, sourceProduct)
        );
      });
    }
  }

  displayBlendSourceMeatTable({ target: { value } }) {
    const {
      blendPricingModel,
      change,
      displayBlendSourceMeatTable,
      sourceProductInfo
    } = this.props;

    if (isQuantityValidForBlend(value) && !_.isEmpty(blendPricingModel)) {
      displayBlendSourceMeatTable();

      change('sourceProducts', generateSourceProducts(blendPricingModel, sourceProductInfo, value));
    }
  }

  handleBlendChange(newValue) {
    const { clearMeatRequestByBlendInfo, getPricingModelByBlend, change } = this.props;
    change('quantity', '');
    clearMeatRequestByBlendInfo();
    getPricingModelByBlend(newValue);
  }

  render() {
    const {
      handleSubmit,
      submitting,
      pristine,
      blendOptions,
      showBlendSourceMeatTable,
      blendPricingModelNotExists,
      invalid
    } = this.props;
    return (
      <div className='meat-request-form-wrapper'>
        <Form pid='meat-request-form' size={'large'} onSubmit={handleSubmit(this.submit)}>
          <Form.Group>
            <Field
              component={FormElement}
              name='blend'
              pid='request-meat-blend'
              as={Form.Select}
              onChange={(event, newValue) => {
                this.handleBlendChange(newValue);
              }}
              options={blendOptions}
              type='text'
              label='Blend'
              message={blendPricingModelNotExists ? 'Blend has no pricing model' : null}
            />
          </Form.Group>

          <Divider hidden />

          <Form.Group>
            <Field
              component={FormElement}
              width={3}
              name='quantity'
              pid='request-meat-quantity'
              as={Form.Input}
              type='text'
              onChange={this.updateSourceProductQuantity}
              onBlur={this.displayBlendSourceMeatTable}
              validate={[required, number, wholeNumber, positiveNumber, isQuantityInRangeForBlend]}
              label='quantity'
            />
            <Field
              component={FormElement}
              name='unitOfMeasure'
              className={'request-meat-unit-of-measure'}
              width={4}
              pid='request-meat-unitOfMeasure'
              as={Form.Select}
              options={unitOfMeasureOptions}
              type='text'
              label='Unit of Measure'
            />
          </Form.Group>

          <Divider hidden />

          {showBlendSourceMeatTable && (
            <div pid='request-meat-source-product-table'>
              <Form.Group>
                <FieldArray name={'sourceProducts'} component={MeatRequestSourceProductsTable} />
              </Form.Group>

              <Button
                primary
                size={'large'}
                loading={submitting}
                disabled={submitting || pristine || invalid}
                className='submit'
              >
                Submit
              </Button>
            </div>
          )}

          <Divider hidden />

          {this.showFormError()}
        </Form>
      </div>
    );
  }
}

MeatRequestByBlendFormComponent.propTypes = {
  handleSubmit: PropTypes.func.isRequired,
  getBlends: PropTypes.func.isRequired,
  getPricingModelByBlend: PropTypes.func.isRequired,
  clearMeatRequestByBlendInfo: PropTypes.func.isRequired,
  displayBlendSourceMeatTable: PropTypes.func.isRequired,
  change: PropTypes.func.isRequired,
  blendOptions: PropTypes.array.isRequired,
  sourceProductInfo: PropTypes.object.isRequired,
  blendPricingModel: PropTypes.object.isRequired,
  blendPricingModelNotExists: PropTypes.bool.isRequired,
  submitting: PropTypes.bool.isRequired,
  invalid: PropTypes.bool.isRequired,
  pristine: PropTypes.bool.isRequired,
  showBlendSourceMeatTable: PropTypes.bool,
  error: PropTypes.string,
  currentRoomCode: PropTypes.string,
  showModal: PropTypes.func,
  hideModal: PropTypes.func,
  isModalShowing: PropTypes.bool
};

const generateBlendOptions = blends => {
  return blends.map((blend, index) => {
    return { key: index, text: blend.displayName, value: blend.name };
  });
};

export const generateSourceProducts = (blendPricingModel, sourceProductInfo, targetProductQty) => {
  if (_.isEmpty(blendPricingModel) || _.isEmpty(blendPricingModel.sourceProducts)) {
    return [];
  }
  return blendPricingModel.sourceProducts.map(sourceProduct => {
    const productInfo = _.get(sourceProductInfo, sourceProduct.code, {});
    return {
      code: sourceProduct.code,
      quantity: calcSourceProductQty(targetProductQty, blendPricingModel, sourceProduct),
      description: productInfo.description
    };
  });
};

const mapStateToProps = state => {
  const {
    blendPricingModel,
    sourceProductInfo,
    blends,
    showBlendSourceMeatTable,
    selectedBlend
  } = state.meatRequestInfo;
  const blendPricingModelNotExists = !_.isEmpty(selectedBlend) && _.isEmpty(blendPricingModel);
  return {
    initialValues: {
      blend: '',
      quantity: '',
      unitOfMeasure: 'LBS',
      sourceProducts: []
    },
    blendOptions: generateBlendOptions(blends),
    blendPricingModel,
    blendPricingModelNotExists,
    sourceProductInfo,
    currentRoomCode: state.portionRoomsInfo.currentPortionRoom.code,
    isModalShowing: state.confirmationModal.showing,
    showBlendSourceMeatTable
  };
};

const mapDispatchToProps = dispatch =>
  bindActionCreators(
    {
      getBlends,
      getPricingModelByBlend,
      clearMeatRequestByBlendInfo,
      displayBlendSourceMeatTable,
      showModal,
      hideModal,
      replacePath,
      change
    },
    dispatch
  );

const onSubmitSuccess = (sourceProductCode, dispatch, props) => {
  const { clearMeatRequestByBlendInfo, reset } = props;
  clearMeatRequestByBlendInfo();
  reset();
};

export const f4Behavior = props => {
  if (props.isModalShowing) {
    props.hideModal();
  } else {
    props.replacePath('/main-navigation');
  }
};

const MeatRequestByBlendForm = connect(
  mapStateToProps,
  mapDispatchToProps
)(
  reduxForm({
    form: 'MeatRequestByBlendForm',
    enableReinitialize: true,
    onSubmitSuccess
  })(
    subscriber(MeatRequestByBlendFormComponent, {
      f4Behavior,
      targetComponent: 'MeatRequestByBlendForm',
      uris: {
        F4: ['#/meat-request/by-blend']
      }
    })
  )
);

export default MeatRequestByBlendForm;
