import React from 'react';

class MeatRequestBySourceCodeForm extends React.Component {
  render() {
    return <div>Fake MeatRequestBySourceCodeForm Component</div>;
  }
}

export default MeatRequestBySourceCodeForm;
