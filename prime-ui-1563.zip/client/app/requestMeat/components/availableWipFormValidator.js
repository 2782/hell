import { SubmissionError } from 'redux-form';
import _ from 'lodash';
import { BRING_WIP_IN_PORTION_ROOM_MESSAGE } from '../../../config/errorMessage';

const processErrorResponse = errorResponse => {
  const errorDetails = _.get(errorResponse, 'error.details', []);

  const errorDetailInfo = errorDetails.find(detail => !_.isEmpty(detail.field) === true);
  const errorDetailStatusText = !_.isEmpty(errorResponse.statusText) === true;
  const issue = errorDetailInfo
    ? errorDetailInfo.issue
    : errorDetailStatusText
    ? errorResponse.statusText
    : '';

  let errors = {};

  switch (issue) {
    case 'CANNOT_CHANGE':
      errors = {
        barcode: 'This box of WIP is reserved for another room. Cannot bring it into the room.',
        ...errors
      };
      break;
    case 'Not Found':
      errors = { barcode: 'Invalid Barcode', ...errors };
      break;
    case 'NOT_EXIST':
      errors = { barcode: 'Invalid Barcode', ...errors };
      break;
    default:
      errors = { barcode: BRING_WIP_IN_PORTION_ROOM_MESSAGE, ...errors };
      break;
  }

  if (!_.isEmpty(errors)) {
    throw new SubmissionError({ ...errors });
  }
};

export default {
  processErrorResponse
};
