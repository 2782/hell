import React from 'react';
import PropTypes from 'prop-types';
import { Table } from 'semantic-ui-react';

export const WipBoxTableHeader = ({ handleSort, sortColumn, sortDirection }) => {
  return (
    <Table.Header>
      <Table.Row>
        <Table.HeaderCell
          colSpan={4}
          width={4}
          textAlign='left'
          sorted={'productCode' === sortColumn ? sortDirection : null}
          onClick={() => handleSort('productCode')}
        >
          PRODUCT
        </Table.HeaderCell>
        <Table.HeaderCell
          colSpan={2}
          width={2}
          textAlign='right'
          sorted={'netWeight' === sortColumn ? sortDirection : null}
          onClick={() => handleSort('netWeight')}
        >
          QTY (LBS)
        </Table.HeaderCell>
        <Table.HeaderCell
          colSpan={2}
          width={2}
          textAlign='right'
          sorted={'_value' === sortColumn ? sortDirection : null}
          onClick={() => handleSort('_value')}
        >
          VALUE
        </Table.HeaderCell>
        <Table.HeaderCell
          colSpan={2}
          width={2}
          textAlign='left'
          sorted={'productionProduct' === sortColumn ? sortDirection : null}
          onClick={() => handleSort('productionProduct')}
        >
          TYPE
        </Table.HeaderCell>
        <Table.HeaderCell
          colSpan={1}
          width={1}
          textAlign='right'
          sorted={'_age' === sortColumn ? sortDirection : null}
          onClick={() => handleSort('_age')}
        >
          AGE
        </Table.HeaderCell>
        <Table.HeaderCell
          colSpan={2}
          width={2}
          textAlign='left'
          sorted={'status' === sortColumn ? sortDirection : null}
          onClick={() => handleSort('status')}
        >
          STATUS
        </Table.HeaderCell>
        <Table.HeaderCell
          colSpan={2}
          width={2}
          textAlign='right'
          sorted={'portionRoomDesc' === sortColumn ? sortDirection : null}
          onClick={() => handleSort('portionRoomDesc')}
        >
          LOCATION
        </Table.HeaderCell>
        <Table.HeaderCell colSpan={1} width={1} />
      </Table.Row>
    </Table.Header>
  );
};

WipBoxTableHeader.propTypes = {
  handleSort: PropTypes.func,
  sortColumn: PropTypes.string,
  sortDirection: PropTypes.string
};
