import packOrdersResources from '../../shared/api/packOrdersResources';
import _ from 'lodash';
import {
  CLEAR_ORDER_TO_PACK_STATE,
  INIT_ORDER_TO_PACK,
  UPDATE_OVERRIDE_PACKAGING_TARE
} from './packActionTypes';
import {
  calculatePackagingTare,
  calculateRetailPieceTare
} from '../components/packagingTareCalculator';

export const initializeOrderToPack = orderData => ({
  type: INIT_ORDER_TO_PACK,
  payload: orderData
});

export const getOrderToPack = orderId => dispatch => {
  return packOrdersResources.getOrderToPack(orderId).then(packOrderResponse => {
    dispatch(initializeOrderToPack(packOrderResponse.data));
  });
};

export const completeBanquetOrder = orderId => dispatch => {
  return packOrdersResources.completeBanquetOrder(orderId).then(() => {
    return getOrderToPack(orderId)(dispatch);
  });
};

export const packBoxForOrder = formData => (dispatch, getState) => {
  const roomCode = getRoom(getState());

  const isRetailOrder = isRetail(getState());

  let boxRequestBody = {};

  if (isRetailOrder) {
    const latestRetailBox = getLatestRetailBoxIfNotFull(getState());

    if (_.isEmpty(latestRetailBox)) {
      boxRequestBody = initializeBoxWithFirstWeighing(
        roomCode,
        formData,
        'RETAIL_PIECE',
        getState()
      );
    } else {
      boxRequestBody = {
        id: latestRetailBox.id,
        productCode: formData.productCode,
        productionOrderId: formData.productionOrderId,
        qtyToProduce: formData.qtyToProduce,
        packagingTare: formData.packagingTare,
        weighings: [
          {
            weight: formData.weight,
            retailPieceTare: getRetailPieceTare(getState()),
            overrideWeightRangeReasonCode: formData.overrideWeightRangeReasonCode,
            type: 'RETAIL_PIECE'
          },
          ...latestRetailBox.weighings
        ],
        roomCode
      };
    }
  } else {
    boxRequestBody = initializeBoxWithFirstWeighing(roomCode, formData, 'BOX', getState());
  }

  return packOrdersResources
    .packOrder(boxRequestBody)
    .then(() => getOrderToPack(formData.productionOrderId)(dispatch));
};

export const clearState = () => ({
  type: CLEAR_ORDER_TO_PACK_STATE
});

export const updateOverridePackagingTare = overridePackagingTare => ({
  type: UPDATE_OVERRIDE_PACKAGING_TARE,
  payload: overridePackagingTare
});

function getRoom(state) {
  return state.portionRoomsInfo.currentPortionRoom.code;
}

export function isRetail(state) {
  const maybeRetail = _.get(state, 'orderToPackInfo.order.product.retailSpecific', {});

  return !_.isEmpty(maybeRetail);
}

function getPackedBoxes(state) {
  return state.orderToPackInfo.order.packedBoxes;
}

export function getPackagingTare(state) {
  const defaultTarePackage = _.get(state, 'tarePackages.defaultTarePackage', {});
  const product = _.get(state, 'orderToPackInfo.order.product', {});

  return calculatePackagingTare(product, defaultTarePackage);
}

export function getRetailPieceTare(state) {
  const defaultTarePackage = _.get(state, 'tarePackages.defaultTarePackage', {});
  const retailSpecificTare = _.get(state, 'orderToPackInfo.order.product.retailSpecific.tare', {});

  return calculateRetailPieceTare(retailSpecificTare, defaultTarePackage);
}

function getLatestRetailBoxIfNotFull(state) {
  const packedRetailBoxes = getPackedBoxes(state);

  if (_.isEmpty(packedRetailBoxes)) {
    return {};
  }

  const latestRetailBox = packedRetailBoxes[0];
  if (latestRetailBox.isFullBox) {
    return {};
  }

  return latestRetailBox;
}

function initializeBoxWithFirstWeighing(roomCode, formData, weighingType, state) {
  return {
    productCode: formData.productCode,
    productionOrderId: formData.productionOrderId,
    qtyToProduce: formData.qtyToProduce,
    packagingTare: formData.packagingTare,
    weighings: [
      {
        weight: formData.weight,
        retailPieceTare: weighingType === 'BOX' ? 0 : getRetailPieceTare(state),
        overrideWeightRangeReasonCode: formData.overrideWeightRangeReasonCode,
        type: weighingType
      }
    ],
    roomCode
  };
}
