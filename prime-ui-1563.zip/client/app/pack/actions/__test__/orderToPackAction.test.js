import packOrdersResources from '../../../shared/api/packOrdersResources';
import {
  CLEAR_ORDER_TO_PACK_STATE,
  INIT_ORDER_TO_PACK,
  UPDATE_OVERRIDE_PACKAGING_TARE
} from '../packActionTypes';
import {
  clearState,
  completeBanquetOrder,
  getOrderToPack,
  packBoxForOrder,
  updateOverridePackagingTare
} from '../orderToPackAction';
import { cutOrder1 } from '../../../shared/testData/cutOrdersForTesting';
import boxFactory from '../../../../test-factories/boxFactory';
import CutOrderFactory from '../../../../test-factories/cutOrder';
import productFactory from '../../../../test-factories/productFactory';
import retailSpecificFactory from '../../../../test-factories/retailSpecificFactory';
import PortionSizeFactory from '../../../../test-factories/portionSize';
import weighingFactory from '../../../../test-factories/weighingFactory';
import tarePackageFactory, {
  DEFAULT_PACKAGE_TARE_VALUE
} from '../../../../test-factories/tarePackageFactory';
import { toPrecision } from '../../../shared/util/floatUtil';

const WEIGHT = '14.2';
const PACKAGING_TARE = '2.1';
const RETAIL_PIECE_TARE_VALUE = '0.71';
const DEFAULT_RETAIL_PIECE_TARE_VALUE = toPrecision(DEFAULT_PACKAGE_TARE_VALUE).toFixed(2);
const RETAIL_PIECE_TARE = tarePackageFactory.build({
  boxType: {
    boxDescription: 'this is a box',
    boxTare: 0.4
  },
  filmType: {
    filmDescription: 'this is a film',
    filmTare: 0.31
  }
});
const OVERRIDE_WEIGHT_RANGE_REASON_CODE = '555';
const BOX_WEIGHING_TYPE = 'BOX';
const RETAIL_WEIGHING_TYPE = 'RETAIL_PIECE';

const packOrderResponse = { data: cutOrder1 };

jest.mock('../../../shared/api/packOrdersResources');

describe('orderToPackAction', () => {
  let dispatch;

  beforeEach(() => {
    dispatch = jest.fn();
  });

  describe('getOrderToPack()', () => {
    beforeEach(() => {
      packOrdersResources.getOrderToPack.mockResolvedValue(packOrderResponse);
    });

    afterEach(() => {
      packOrdersResources.getOrderToPack.mockReset();
    });

    test(
      'should call getOrderToPack from packOrdersResource with orderId, call getCustomerById with customer Id' +
        'and getProductInfo with productCode, then dispatch',
      async () => {
        await getOrderToPack(cutOrder1.id)(dispatch);

        jestExpect(packOrdersResources.getOrderToPack).toBeCalledWith(cutOrder1.id);
        jestExpect(dispatch).toBeCalledWith({
          type: INIT_ORDER_TO_PACK,
          payload: packOrderResponse.data
        });
      }
    );
  });

  describe('completeBanquetOrder()', () => {
    beforeEach(() => {
      packOrdersResources.getOrderToPack.mockResolvedValue(packOrderResponse);
      packOrdersResources.completeBanquetOrder.mockResolvedValue();
    });

    afterEach(() => {
      packOrdersResources.getOrderToPack.mockReset();
      packOrdersResources.completeBanquetOrder.mockReset();
    });

    test('should complete banquet order and then re-fetch updated order', async () => {
      await completeBanquetOrder(cutOrder1.id)(dispatch);

      jestExpect(packOrdersResources.completeBanquetOrder).toBeCalledWith(cutOrder1.id);
      jestExpect(packOrdersResources.getOrderToPack).toBeCalledWith(cutOrder1.id);
      jestExpect(dispatch).toBeCalledWith({
        type: INIT_ORDER_TO_PACK,
        payload: cutOrder1
      });
    });
  });

  describe('clearState()', () => {
    test('should dispatch CLEAR_ORDER_TO_PACK_STATE', () => {
      const result = clearState();

      jestExpect(result).toEqual({
        type: CLEAR_ORDER_TO_PACK_STATE
      });
    });
  });

  describe('updateOverridePackagingTare()', () => {
    test('should dispatch UPDATE_OVERRIDE_PACKAGING_TARE', () => {
      const result = updateOverridePackagingTare(1.21);

      jestExpect(result).toEqual({
        type: UPDATE_OVERRIDE_PACKAGING_TARE,
        payload: 1.21
      });
    });
  });

  describe('packBoxForOrder()', () => {
    let box, getState, defaultState;

    beforeEach(() => {
      defaultState = {
        tarePackages: {
          defaultTarePackage: tarePackageFactory.build({})
        },
        portionRoomsInfo: {
          currentPortionRoom: {
            code: 'A'
          }
        },
        orderToPackInfo: {
          order: CutOrderFactory.build({
            product: productFactory.build({})
          })
        }
      };
      getState = () => {
        return defaultState;
      };

      box = boxFactory.build({});
      packOrdersResources.packOrder.mockResolvedValue({ data: box });
      packOrdersResources.getOrderToPack.mockResolvedValue({ data: cutOrder1 });
    });

    afterEach(() => {
      packOrdersResources.packOrder.mockReset();
      packOrdersResources.getOrderToPack.mockReset();
    });

    test('should pack a full standard box with a single weighing', async () => {
      let formData = {
        productCode: cutOrder1.product.code,
        productionOrderId: cutOrder1.id,
        qtyToProduce: cutOrder1.qtyToProduce,
        weight: WEIGHT,
        packagingTare: PACKAGING_TARE,
        overrideWeightRangeReasonCode: OVERRIDE_WEIGHT_RANGE_REASON_CODE
      };

      await packBoxForOrder(formData)(dispatch, getState);

      jestExpect(packOrdersResources.packOrder).toBeCalledWith({
        productCode: cutOrder1.product.code,
        productionOrderId: cutOrder1.id,
        qtyToProduce: cutOrder1.qtyToProduce,
        packagingTare: PACKAGING_TARE,
        weighings: [
          {
            weight: WEIGHT,
            retailPieceTare: 0,
            overrideWeightRangeReasonCode: OVERRIDE_WEIGHT_RANGE_REASON_CODE,
            type: BOX_WEIGHING_TYPE
          }
        ],
        roomCode: 'A'
      });

      jestExpect(packOrdersResources.getOrderToPack).toBeCalledWith(cutOrder1.id);
    });

    test('should pack a single retail weighing for a brand new retail box', async () => {
      let formData = {
        productCode: cutOrder1.product.code,
        productionOrderId: cutOrder1.id,
        qtyToProduce: cutOrder1.qtyToProduce,
        weight: WEIGHT,
        packagingTare: PACKAGING_TARE,
        overrideWeightRangeReasonCode: OVERRIDE_WEIGHT_RANGE_REASON_CODE
      };

      let state = {
        ...defaultState,
        orderToPackInfo: {
          order: CutOrderFactory.build({
            product: productFactory.build({
              retailSpecific: retailSpecificFactory.build({
                tare: RETAIL_PIECE_TARE
              })
            })
          })
        }
      };

      getState = () => state;

      await packBoxForOrder(formData)(dispatch, getState);
      jestExpect(packOrdersResources.packOrder).toBeCalledWith({
        productCode: cutOrder1.product.code,
        productionOrderId: cutOrder1.id,
        qtyToProduce: cutOrder1.qtyToProduce,
        packagingTare: PACKAGING_TARE,
        weighings: [
          {
            weight: WEIGHT,
            retailPieceTare: RETAIL_PIECE_TARE_VALUE,
            overrideWeightRangeReasonCode: OVERRIDE_WEIGHT_RANGE_REASON_CODE,
            type: RETAIL_WEIGHING_TYPE
          }
        ],
        roomCode: 'A'
      });

      jestExpect(packOrdersResources.getOrderToPack).toBeCalledWith(cutOrder1.id);
    });

    test('should pack a second retail weighing for an existing retail box', async () => {
      let formData = {
        productCode: cutOrder1.product.code,
        productionOrderId: cutOrder1.id,
        qtyToProduce: cutOrder1.qtyToProduce,
        weight: WEIGHT,
        packagingTare: PACKAGING_TARE,
        overrideWeightRangeReasonCode: OVERRIDE_WEIGHT_RANGE_REASON_CODE
      };

      const existingRetailWeighing = weighingFactory.build({
        weight: 1.25,
        retailPieceTare: 2.51,
        overrideWeightRangeReasonCode: 121,
        type: RETAIL_WEIGHING_TYPE
      });

      const existingBox = boxFactory.build({
        isFullBox: false,
        weighings: [existingRetailWeighing]
      });

      let state = {
        ...defaultState,
        orderToPackInfo: {
          order: CutOrderFactory.build({
            packedBoxes: [existingBox],
            product: productFactory.build({
              retailSpecific: retailSpecificFactory.build({
                tare: {}
              })
            })
          })
        }
      };

      getState = () => state;

      await packBoxForOrder(formData)(dispatch, getState);
      jestExpect(packOrdersResources.packOrder).toBeCalledWith(
        jestExpect.objectContaining({
          id: existingBox.id,
          productCode: cutOrder1.product.code,
          productionOrderId: cutOrder1.id,
          qtyToProduce: cutOrder1.qtyToProduce,
          packagingTare: PACKAGING_TARE,
          weighings: [
            {
              weight: WEIGHT,
              retailPieceTare: DEFAULT_RETAIL_PIECE_TARE_VALUE,
              overrideWeightRangeReasonCode: OVERRIDE_WEIGHT_RANGE_REASON_CODE,
              type: RETAIL_WEIGHING_TYPE
            },
            existingRetailWeighing
          ],
          roomCode: 'A'
        })
      );

      jestExpect(packOrdersResources.getOrderToPack).toBeCalledWith(cutOrder1.id);
    });

    test('add new box when packedBoxes contains existing complete retail box', async () => {
      let formData = {
        productCode: cutOrder1.product.code,
        productionOrderId: cutOrder1.id,
        qtyToProduce: cutOrder1.qtyToProduce,
        weight: WEIGHT,
        packagingTare: PACKAGING_TARE,
        overrideWeightRangeReasonCode: OVERRIDE_WEIGHT_RANGE_REASON_CODE
      };

      const existingRetailWeighing = weighingFactory.build({
        weight: 1.25,
        retailPieceTare: 2.51,
        overrideWeightRangeReasonCode: 121,
        type: RETAIL_WEIGHING_TYPE
      });

      const existingFullBox = boxFactory.build({
        isFullBox: true,
        weighings: [existingRetailWeighing, existingRetailWeighing]
      });

      let state = {
        ...defaultState,
        orderToPackInfo: {
          order: CutOrderFactory.build({
            packedBoxes: [existingFullBox],
            product: productFactory.build({
              retailSpecific: retailSpecificFactory.build({}),
              productPortionSize: PortionSizeFactory.build({
                piecesPerCase: 2
              })
            })
          })
        }
      };

      getState = () => state;

      await packBoxForOrder(formData)(dispatch, getState);

      jestExpect(packOrdersResources.packOrder).toBeCalledWith({
        productCode: cutOrder1.product.code,
        productionOrderId: cutOrder1.id,
        qtyToProduce: cutOrder1.qtyToProduce,
        packagingTare: PACKAGING_TARE,
        weighings: [
          {
            weight: WEIGHT,
            retailPieceTare: DEFAULT_RETAIL_PIECE_TARE_VALUE,
            overrideWeightRangeReasonCode: OVERRIDE_WEIGHT_RANGE_REASON_CODE,
            type: RETAIL_WEIGHING_TYPE
          }
        ],
        roomCode: 'A'
      });

      jestExpect(packOrdersResources.getOrderToPack).toBeCalledWith(cutOrder1.id);
    });
  });
});
