import { getTestStateForRoomA } from '../../../../test-factories/testState';
import packOrderResources from '../../../shared/api/packOrdersResources';
import { cutOrder1, cutOrder2 } from '../../../shared/testData/cutOrdersForTesting';
import {
  REGISTER_PRODUCT_CODE_FIELD,
  REGISTER_WEIGHT_FIELD,
  RESET_OVERRIDE_WEIGHT_RANGE_REQUEST,
  RESET_PACK_OFF_STOCK,
  RESET_PACK_ORDERS_INFO,
  SHOW_OVERRIDE_WEIGHT_RANGE_REQUEST,
  UPDATE_PACK_OFF_STOCK,
  UPDATE_PACK_ORDERS_INFO,
  UPDATE_WIP_BOXES
} from '../packActionTypes';
import {
  clearPackedOffStock,
  filterPackOrderByGrindTicketAndRoom,
  focusProductCodeField,
  focusWeightField,
  getPackOrdersInfo,
  loadPackOrderByCutTicketAndRoom,
  packOffStock,
  packOffWIPBox,
  registerProductCodeField,
  registerWeightField,
  resetOverrideWeightRange,
  showOverrideWeightRangeRequest
} from '../packActions';
import { changePath } from '../../../shared/actions/actions';
import { SubmissionError } from 'redux-form';
import {
  GRIND_ORDER_WITH_NATURAL_BLEND_1_2_GRIND,
  GRIND_WITH_NATURAL_BLEND_3_16_GRIND_F19_TABLE
} from '../../../../test-factories/grindingOrderFactory';

jest.mock('../../../shared/actions/actions', () => ({
  changePath: jest.fn(path => ({ type: 'MOCK_CHANGE_PATH', payload: path }))
}));
jest.mock('../../../shared/api/packOrdersResources');

const getState = () => {
  return {
    portionRoomsInfo: {
      currentPortionRoom: {
        code: 'A'
      }
    }
  };
};

describe('packActions', () => {
  let dispatch;

  beforeEach(() => {
    dispatch = jest.fn();
  });

  test('should create an action RESET_PACK_OFF_STOCK', () => {
    jestExpect(clearPackedOffStock()).toEqual({
      type: RESET_PACK_OFF_STOCK
    });
  });

  test('should return action for REGISTER_PRODUCT_CODE_FIELD', () => {
    jestExpect(registerProductCodeField('FIELD')).toEqual({
      type: REGISTER_PRODUCT_CODE_FIELD,
      payload: 'FIELD'
    });
  });

  test('should return action for REGISTER_WEIGHT', () => {
    jestExpect(registerWeightField('FIELD')).toEqual({
      type: REGISTER_WEIGHT_FIELD,
      payload: 'FIELD'
    });
  });

  test('should focus productCodeField from existing state', () => {
    const focusInput = jest.fn();
    const getState = jest.fn(() => ({
      packBoxForm: {
        productCodeField: {
          getRenderedComponent: jest.fn(() => ({
            focusInput
          }))
        }
      }
    }));

    focusProductCodeField()(null, getState);

    jestExpect(focusInput).toBeCalled();
  });

  test('should focus weightField from existing state', () => {
    const refocus = jest.fn();
    const getState = jest.fn(() => ({
      packBoxForm: {
        weightField: {
          getWrappedInstance: jest.fn(() => ({
            refocus
          }))
        }
      }
    }));

    focusWeightField()(null, getState);

    jestExpect(refocus).toBeCalled();
  });

  describe('resetOverrideWeightRequest', () => {
    test('should create an action RESET_OVERRIDE_WEIGHT_RANGE_REQUEST', () => {
      resetOverrideWeightRange()(dispatch);

      jestExpect(dispatch).toHaveBeenNthCalledWith(1, {
        type: RESET_OVERRIDE_WEIGHT_RANGE_REQUEST
      });
    });
  });

  describe('showOverrideWeightRequest', () => {
    test('should create an action SHOW_OVERRIDE_WEIGHT_RANGE_REQUEST', () => {
      showOverrideWeightRangeRequest()(dispatch);

      jestExpect(dispatch).toHaveBeenNthCalledWith(1, {
        type: SHOW_OVERRIDE_WEIGHT_RANGE_REQUEST
      });
    });
  });

  test('should call packOffStock with formatted weight and dispatch UPDATE_PACK_OFF_STOCK', async () => {
    const formValues = {
      productCode: '0000507',
      weight: '2.118888',
      packagingTare: '1.00',
      netWeight: '1'
    };
    packOrderResources.packOffStock.mockResolvedValue({ data: { id: 15, netWeight: 10.0 } });

    await packOffStock(formValues)(dispatch, getState);

    jestExpect(packOrderResources.packOffStock).toBeCalledWith({
      productCode: formValues.productCode,
      qtyToProduce: formValues.qtyToProduce,
      packagingTare: '1.00',
      weighings: [
        {
          weight: '2.12',
          retailPieceTare: 0,
          overrideWeightRangeReasonCode: undefined,
          type: 'BOX'
        }
      ],
      roomCode: 'A'
    });

    jestExpect(dispatch).toHaveBeenNthCalledWith(1, {
      type: UPDATE_PACK_OFF_STOCK,
      payload: { id: 15, netWeight: 10.0 }
    });
  });

  test('should get pack order information with customer and user info', () => {
    const cutOrderForToday = {
      ...cutOrder1,
      id: 1,
      deliveryDate: '2018-10-10',
      productDescription: 'abc'
    };
    const cutOrderForTodayWithOtherDesc = {
      ...cutOrder1,
      id: 2,
      deliveryDate: '2018-10-10',
      productDescription: 'bcd'
    };
    const cutOrderForTomorrow = {
      ...cutOrder2,
      id: 3,
      deliveryDate: '2018-10-11',
      productDescription: 'abc'
    };

    const packOrdersResponse = {
      data: [cutOrderForTomorrow, cutOrderForToday, cutOrderForTodayWithOtherDesc]
    };
    packOrderResources.getPackOrders.mockImplementation((room, fn) => fn(packOrdersResponse));

    getPackOrdersInfo()(dispatch, getTestStateForRoomA);

    jestExpect(dispatch).toHaveBeenNthCalledWith(1, {
      type: RESET_PACK_ORDERS_INFO
    });

    jestExpect(dispatch).toHaveBeenNthCalledWith(2, {
      type: UPDATE_PACK_ORDERS_INFO,
      payload: [
        { data: cutOrderForToday, orderId: 1 },
        { data: cutOrderForTodayWithOtherDesc, orderId: 2 },
        { data: cutOrderForTomorrow, orderId: 3 }
      ]
    });
  });

  describe('getPackOrderWhenEnteringTicketCode', () => {
    test('should change path to pack page when fetching entered cut ticket code successfully', async () => {
      const orderId = 12;
      const cutTicketCode = 'C1207920123';
      const roomCode = 'A';

      packOrderResources.checkPackOrderExistsForCutTicketAndRoom.mockResolvedValue({
        data: orderId
      });

      await loadPackOrderByCutTicketAndRoom(cutTicketCode, roomCode)(dispatch);

      jestExpect(dispatch).toHaveBeenCalledWith(changePath(`/pack/orders/${orderId}`));
    });

    test('should throw when check pack order exists for room fails', async () => {
      const cutTicketCode = 'C1207920123';
      const roomCode = 'A';

      packOrderResources.checkPackOrderExistsForCutTicketAndRoom.mockRejectedValue({});

      await jestExpect(
        loadPackOrderByCutTicketAndRoom(cutTicketCode, roomCode)(dispatch)
      ).rejects.toThrow(SubmissionError);
    });
  });

  describe('getPackOrderWhenEnteringGrindTicketCode', () => {
    test('should filter packOrders when checking entered grind ticket code successfully', async () => {
      const productCode = '4100159';
      const grindTicketCode = 'G1111194100159A';
      const roomCode = 'A';

      const grindOrders = [
        {
          orderId: GRIND_ORDER_WITH_NATURAL_BLEND_1_2_GRIND.id,
          data: GRIND_ORDER_WITH_NATURAL_BLEND_1_2_GRIND
        },
        {
          orderId: GRIND_WITH_NATURAL_BLEND_3_16_GRIND_F19_TABLE.id,
          data: GRIND_WITH_NATURAL_BLEND_3_16_GRIND_F19_TABLE
        }
      ];

      packOrderResources.checkPackOrderExistsForGrindTicketAndRoom.mockResolvedValue({
        data: productCode
      });

      await filterPackOrderByGrindTicketAndRoom(grindOrders, grindTicketCode, roomCode)(dispatch);

      jestExpect(dispatch).toHaveBeenNthCalledWith(1, {
        type: UPDATE_PACK_ORDERS_INFO,
        payload: [
          {
            orderId: GRIND_ORDER_WITH_NATURAL_BLEND_1_2_GRIND.id,
            data: GRIND_ORDER_WITH_NATURAL_BLEND_1_2_GRIND
          }
        ]
      });
    });

    test('should throw when check pack order exists for room fails', async () => {
      const grindTicketCode = 'G1111191916172A';
      const roomCode = 'A';
      const grindOrders = [GRIND_ORDER_WITH_NATURAL_BLEND_1_2_GRIND];

      packOrderResources.checkPackOrderExistsForGrindTicketAndRoom.mockRejectedValue({});

      await jestExpect(
        filterPackOrderByGrindTicketAndRoom(grindOrders, grindTicketCode, roomCode)(dispatch)
      ).rejects.toThrow(SubmissionError);
    });
  });

  test('should call packOffWIPBox from and dispatch packing complete', async () => {
    packOrderResources.packOffWIPBox.mockResolvedValue({ data: { id: 15, netWeight: 2.0 } });

    const wipPackInfo = {
      qtyToProduce: 10,
      productCode: '0078889',
      packagingTare: '1.1',
      weight: '13.4'
    };

    await packOffWIPBox(wipPackInfo)(dispatch, getState);

    jestExpect(packOrderResources.packOffWIPBox).toBeCalledWith({
      productCode: wipPackInfo.productCode,
      qtyToProduce: wipPackInfo.qtyToProduce,
      packagingTare: '1.1',
      weighings: [
        {
          weight: '13.40',
          retailPieceTare: 0,
          overrideWeightRangeReasonCode: undefined,
          type: 'BOX'
        }
      ],
      roomCode: 'A'
    });

    jestExpect(dispatch).toHaveBeenNthCalledWith(1, {
      type: UPDATE_WIP_BOXES,
      payload: { id: 15, netWeight: 2.0 }
    });
  });
});
