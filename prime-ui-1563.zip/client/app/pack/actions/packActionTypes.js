export const UPDATE_PACK_TABLE_SUMMARY = 'updatePackTableSummary';
export const UPDATE_PACK_ORDERS_INFO = 'updatePackOrdersInfo';
export const RESET_PACK_ORDERS_INFO = 'resetPackOrdersInfo';
export const SHOW_OVERRIDE_WEIGHT_RANGE_REQUEST = 'showOverrideWeightRequest';
export const RESET_OVERRIDE_WEIGHT_RANGE_REQUEST = 'resetOverrideWeightRequest';

export const INIT_ORDER_TO_PACK = 'cutOrders/toPack/initOrderToPack';
export const CLEAR_ORDER_TO_PACK_STATE = 'cutOrders/toPack/clearState';

export const UPDATE_PACK_OFF_STOCK = 'cutOrders/toPack/updatePackOffStock';
export const RESET_PACK_OFF_STOCK = 'cutOrders/toPack/resetPackOffStock';
export const UPDATE_WIP_BOXES = 'cutOrders/toPack/updateWIPBoxes';
export const RESET_WIP_BOXES = 'cutOrders/toPack/resetWIPBoxes';

export const REGISTER_PRODUCT_CODE_FIELD = 'cutOrders/toPack/registerProductCodeField';
export const REGISTER_WEIGHT_FIELD = 'cutOrders/toPack/registerWeightField';

export const UPDATE_OVERRIDE_PACKAGING_TARE = 'packoff/updateOverridePackagingTare';
