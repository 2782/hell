import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { clearPackedOffStock, packOffStock } from '../actions/packActions';
import { clearState } from '../actions/orderToPackAction';
import PackBoxForm from '../components/PackBoxForm';
import PackBoxTable from '../components/PackBoxTable';
import { PACK_OFF_STOCK_TITLE } from '../../shared/components/pageTitles';
import { setHeaderAndFooter } from '../../shared/actions/actions';
import { bindActionCreators } from 'redux';
import { PACK_OFF_STOCK_FOOTER } from '../../shared/components/pageFooters';
import { PACK_OFF_STOCK } from '../components/packType';

export class PackOffStockPage extends React.Component {
  constructor(props) {
    super(props);

    this.onReset = this.onReset.bind(this);
  }

  componentDidMount() {
    this.props.clearPackedOffStock();
    this.props.setHeaderAndFooter({
      header: PACK_OFF_STOCK_TITLE,
      footer: PACK_OFF_STOCK_FOOTER
    });
  }

  componentWillUnmount() {
    this.props.clearState();
  }

  onReset() {
    this.props.clearPackedOffStock();
  }

  render() {
    const { packedOffStocks, packOffStock } = this.props;

    return (
      <div className='page-content' tabIndex={0}>
        <PackBoxForm
          form='packOffStock'
          id='pack-box-form'
          packType={PACK_OFF_STOCK}
          packedBoxes={packedOffStocks}
          onSubmit={packOffStock}
          onReset={this.onReset}
        />
        <PackBoxTable variant={PACK_OFF_STOCK} packedBoxes={packedOffStocks} />
      </div>
    );
  }
}

PackOffStockPage.propTypes = {
  packOffStock: PropTypes.func.isRequired,
  clearPackedOffStock: PropTypes.func.isRequired,
  packedOffStocks: PropTypes.array.isRequired,
  setHeaderAndFooter: PropTypes.func.isRequired,
  clearState: PropTypes.func.isRequired
};

const mapStateToProps = state => ({
  packedOffStocks: state.packedOffStockInfo.packedOffStocks
});

const mapDispatchToProps = dispatch =>
  bindActionCreators(
    {
      clearPackedOffStock,
      packOffStock,
      clearState,
      setHeaderAndFooter
    },
    dispatch
  );

const PackOffStock = connect(
  mapStateToProps,
  mapDispatchToProps
)(PackOffStockPage);

export default PackOffStock;
