import React from 'react';
import PropTypes from 'prop-types';
import _ from 'lodash';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import { clearState, getOrderToPack } from '../actions/orderToPackAction';
import { ORDER_TO_PACK } from '../../shared/components/pageTitles';
import { setHeaderAndFooter } from '../../shared/actions/actions';
import { ORDER_TO_PACK_FOOTER } from '../../shared/components/pageFooters';
import { BANQUET, STANDARD } from '../../../config/cutType';
import PackOffOrderForm from '../components/packOffOrderForm';
import FormLabel from '../../shared/FormLabel';
import { Form } from 'semantic-ui-react';
import CasesAndPiecesOrderHeader from '../components/CasesAndPiecesOrderHeader';

export class OrderToPack extends React.Component {
  constructor(props) {
    super(props);

    this.quantityRemaining = this.quantityRemaining.bind(this);
  }

  componentDidMount() {
    const { orderId } = this.props.match.params;
    this.props.getOrderToPack(orderId);
    this.props.setHeaderAndFooter({
      header: ORDER_TO_PACK,
      footer: ORDER_TO_PACK_FOOTER()
    });
  }

  componentDidUpdate() {
    const { order } = this.props;
    if (!_.isEmpty(order)) {
      this.props.setHeaderAndFooter({
        header: ORDER_TO_PACK,
        footer: ORDER_TO_PACK_FOOTER(order)
      });
    }
  }

  componentWillUnmount() {
    this.props.clearState();
  }

  quantityRemaining() {
    const {
      order: { qtyInBoxes, packedBoxes }
    } = this.props;
    return qtyInBoxes - packedBoxes.length;
  }

  render() {
    const { order } = this.props;
    if (_.isEmpty(order)) {
      return <div className='page-content' tabIndex={0} />;
    }

    const { product, customerOrder, packedBoxes } = order;

    const productCode = product.code;
    const productDescription = product.description;
    const portionSize = product.productPortionSize.portionSize;
    const isRetail = !_.isEmpty(product.retailSpecific);
    const customerName = _.get(customerOrder, 'customer.name', '');

    return (
      <div className='page-content' tabIndex={0}>
        <div>
          <Form size={'large'} className='order-to-pack-form'>
            <Form.Group>
              <FormLabel
                label='Product'
                value={`${productCode} - ${productDescription}`}
                width={12}
              />
            </Form.Group>
            <Form.Group>
              <FormLabel label='Size: ' value={portionSize} width={12} />
            </Form.Group>
            <Form.Group>
              <FormLabel label='Customer' value={customerName} width={12} />
            </Form.Group>
            <CasesAndPiecesOrderHeader {...order} isRetail={isRetail} packedBoxes={packedBoxes} />
          </Form>
          <PackOffOrderForm {...this.props} quantityRemaining={this.quantityRemaining} />
        </div>
      </div>
    );
  }
}

OrderToPack.propTypes = {
  getOrderToPack: PropTypes.func.isRequired,
  clearState: PropTypes.func.isRequired,
  match: PropTypes.object.isRequired,
  order: PropTypes.shape({
    id: PropTypes.number,
    packedBoxes: PropTypes.array,
    customerOrder: PropTypes.object,
    unitOfMeasure: PropTypes.string,
    qtyToProduce: PropTypes.number,
    piecesPerCase: PropTypes.number,
    customerName: PropTypes.string,
    cutType: PropTypes.oneOf([STANDARD, BANQUET]),
    product: PropTypes.shape({
      code: PropTypes.string,
      description: PropTypes.string,
      category: PropTypes.string,
      minWeight: PropTypes.number,
      maxWeight: PropTypes.number,
      productPortionSize: PropTypes.shape({
        portionSize: PropTypes.string
      })
    }),
    qtyPacked: PropTypes.number,
    qtyInBoxes: PropTypes.number
  }),
  setHeaderAndFooter: PropTypes.func.isRequired
};

const mapStateToProps = state => ({
  order: state.orderToPackInfo.order
});

const mapDispatchToProps = dispatch =>
  bindActionCreators(
    {
      getOrderToPack,
      clearState,
      setHeaderAndFooter
    },
    dispatch
  );

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(OrderToPack);
