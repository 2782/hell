import { initializeOrderToPack } from '../../actions/orderToPackAction';
import PackWIP, { PackWIPPage } from '../PackWIP';
import { mount } from 'enzyme';
import React from 'react';
import { createReduxStore } from '../../../store';
import { Provider } from 'react-redux';
import PackBoxForm from '../../components/PackBoxForm';
import PackBoxTable from '../../components/PackBoxTable';
import CustomerOrderFactory from '../../../../test-factories/customerOrder';
import productFactory from '../../../../test-factories/productFactory';

jest.mock('../../../shared/scale/scale');
jest.mock('../../../shared/errors/ErrorNotification');

describe('PackWIP', () => {
  let wrapper;

  beforeEach(() => {
    const store = createReduxStore();

    store.dispatch(
      initializeOrderToPack(
        CustomerOrderFactory.build({
          product: productFactory.build({
            retailSpecific: null
          })
        })
      )
    );

    wrapper = mount(
      <Provider store={store}>
        <PackWIP />
      </Provider>
    );
  });

  test('should find render form component and packed boxes table', () => {
    jestExpect(wrapper.find(PackBoxForm).exists()).toBeTruthy();
    jestExpect(wrapper.find(PackBoxTable).exists()).toBeTruthy();
  });

  test('check product and wip boxes in cleared in store', () => {
    const clearWIPBoxes = jest.fn();
    const clearProductInfo = jest.fn();
    const setHeaderAndFooter = jest.fn();
    const clearState = jest.fn();

    const component = new PackWIPPage({
      clearProductInfo,
      clearWIPBoxes,
      setHeaderAndFooter,
      clearState
    });

    component.componentDidMount();

    jestExpect(clearProductInfo).toBeCalledTimes(1);
    jestExpect(clearWIPBoxes).toBeCalledTimes(1);
    jestExpect(setHeaderAndFooter).toBeCalledTimes(1);

    component.componentWillUnmount();
    jestExpect(clearState).toBeCalledTimes(1);
  });
});
