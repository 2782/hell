import { initializeOrderToPack } from '../../actions/orderToPackAction';
import PackOffStock, { PackOffStockPage } from '../PackOffStock';
import { mount, shallow } from 'enzyme';
import React from 'react';
import { createReduxStore } from '../../../store';
import { Provider } from 'react-redux';
import PackBoxForm from '../../components/PackBoxForm';
import PackBoxTable from '../../components/PackBoxTable';

import CustomerOrderFactory from '../../../../test-factories/customerOrder';
import productFactory from '../../../../test-factories/productFactory';

jest.mock('../../../shared/scale/scale');
jest.mock('../../../shared/errors/ErrorNotification');

describe('PackOffStock', () => {
  let wrapper;

  describe('mounting', () => {
    beforeEach(() => {
      const store = createReduxStore();

      store.dispatch(
        initializeOrderToPack(
          CustomerOrderFactory.build({
            product: productFactory.build({
              retailSpecific: null
            })
          })
        )
      );
      wrapper = mount(
        <Provider store={store}>
          <PackOffStock />
        </Provider>
      );
    });

    test('should find render form component and packed boxes table', () => {
      jestExpect(wrapper.find(PackBoxForm).exists()).toEqual(true);
      jestExpect(wrapper.find(PackBoxTable).exists()).toEqual(true);
    });
  });

  describe('shallow rendering', () => {
    let clearPackedOffStockFn;
    let packOffStockFn;
    let dispatchSpy;
    let setHeaderAndFooter;
    let clearStateSpy;

    beforeEach(() => {
      dispatchSpy = jest.fn();
      clearPackedOffStockFn = jest.fn();
      packOffStockFn = jest.fn();
      setHeaderAndFooter = jest.fn();
      clearStateSpy = jest.fn();

      wrapper = shallow(
        <PackOffStockPage
          packOffStock={packOffStockFn}
          setHeaderAndFooter={setHeaderAndFooter}
          clearPackedOffStock={clearPackedOffStockFn}
          packedOffStocks={[]}
          dispatch={dispatchSpy}
          clearState={clearStateSpy}
        />
      );
    });

    test('should call clearPackedOffStock action on mount', () => {
      jestExpect(clearPackedOffStockFn).toBeCalledTimes(1);
    });

    test('should call packOffStock action on submit', () => {
      wrapper.find('#pack-box-form').simulate('submit', { preventDefault() {} });
      jestExpect(packOffStockFn).toBeCalledTimes(1);
    });

    test('check clearState when componentWillUnmount', () => {
      const clearState = jest.fn();

      const component = new PackOffStockPage({
        clearState: clearState
      });

      component.componentWillUnmount();
      jestExpect(clearState).toBeCalledTimes(1);
    });

    test('check clearPackedOffStock in called when Reset is called', () => {
      const clearPackedOffStock = jest.fn();

      const component = new PackOffStockPage({
        clearPackedOffStock: clearPackedOffStock
      });

      component.onReset();

      jestExpect(clearPackedOffStock).toBeCalledTimes(1);
    });
  });
});
