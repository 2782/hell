import OrderToPack from '../OrderToPack';
import React from 'react';
import { mount } from 'enzyme';
import { Provider } from 'react-redux';
import { createReduxStore } from '../../../store';
import cutOrderFactory from '../../../../test-factories/cutOrder';
import semanticUI from '../../../../test-helpers/semantic-ui';
import CustomerOrderFactory from '../../../../test-factories/customerOrder';
import CustomerFactory from '../../../../test-factories/customerFactory';
import productFactory from '../../../../test-factories/productFactory';
import PortionSizeFactory from '../../../../test-factories/portionSize';
import packOrderResources from '../../../shared/api/packOrdersResources';
import retailSpecificFactory from '../../../../test-factories/retailSpecificFactory';

const customer = CustomerFactory.build({ name: 'I am a customer' });

jest.mock('../../../shared/api/packOrdersResources');
jest.mock('../../../shared/api/tarePackagesResources');

describe('OrderToPack', () => {
  let store;

  beforeEach(() => {
    store = createReduxStore({});
  });

  test('should render standard order successfully', async () => {
    const order = cutOrderFactory.build({
      id: 8,
      unitOfMeasure: 'PIECE',
      qtyToProduce: 2,
      qtyInBoxes: 2,
      qtyPacked: 0,
      piecesPerCase: 10,
      customerOrder: CustomerOrderFactory.build({ customer: customer })
    });

    packOrderResources.getOrderToPack.mockResolvedValue({ data: order });

    let wrapper = mount(
      <Provider store={store}>
        <OrderToPack match={{ params: { orderId: 12 } }} />
      </Provider>
    );

    await waitForAsyncTasks(wrapper);

    jestExpect(semanticUI.getTextForLabelWithName(wrapper, 'Product')).toEqual(
      '0071185 - CAB SIRLOIN CULOTTE STEAK'
    );
    jestExpect(semanticUI.getTextForLabelWithName(wrapper, 'Size: ')).toEqual('12 OZ');
    jestExpect(semanticUI.getTextForLabelWithName(wrapper, 'Customer')).toEqual('I am a customer');
    jestExpect(semanticUI.getTextForLabelWithName(wrapper, 'Pieces Ordered')).toEqual('2');
    jestExpect(semanticUI.getTextForLabelWithName(wrapper, 'Pieces Per Box')).toEqual('10');
    jestExpect(semanticUI.getInputValue(wrapper, 'weight')).toEqual('');
    jestExpect(semanticUI.getInputValue(wrapper, 'packagingTare')).toEqual('');
    jestExpect(wrapper.find('#pack-box-table').exists()).toBeTruthy();
  });

  test('should render banquet order successfully', async () => {
    const order = cutOrderFactory.build({
      id: 8,
      cutType: 'BANQUET',
      unitOfMeasure: 'PIECE',
      qtyToProduce: 2,
      qtyInBoxes: 2,
      qtyPacked: 0,
      customerOrder: CustomerOrderFactory.build({ customer: customer })
    });

    packOrderResources.getOrderToPack.mockResolvedValue({ data: order });

    let wrapper = mount(
      <Provider store={store}>
        <OrderToPack match={{ params: { orderId: 12 } }} />
      </Provider>
    );

    await waitForAsyncTasks(wrapper);

    jestExpect(semanticUI.getTextForLabelWithName(wrapper, 'Product')).toEqual(
      '0071185 - CAB SIRLOIN CULOTTE STEAK'
    );
    jestExpect(semanticUI.getTextForLabelWithName(wrapper, 'Size: ')).toEqual('12 OZ');
    jestExpect(semanticUI.getTextForLabelWithName(wrapper, 'Customer')).toEqual('I am a customer');
    jestExpect(semanticUI.getTextForLabelWithName(wrapper, 'Cases Remaining')).toEqual('2');
    jestExpect(semanticUI.getTextForLabelWithName(wrapper, 'Pieces Ordered')).toEqual('2');
    jestExpect(semanticUI.getInputValue(wrapper, 'weight')).toEqual('');
    jestExpect(semanticUI.getInputValue(wrapper, 'packagingTare')).toEqual('');

    jestExpect(wrapper.find('#pack-box-table').exists()).toBeTruthy();
  });

  test('should render the retail cut order information for cases/pieces remaining, pieces per case', async () => {
    const order = cutOrderFactory.build({
      piecesPerCase: 10,
      product: productFactory.build({
        code: '4102218',
        description: 'LL SKIRT STEAK',
        productPortionSize: PortionSizeFactory.build({}),
        retailSpecific: retailSpecificFactory.build({
          price: 1.25,
          tare: 0.57,
          minWeight: 5.0
        })
      }),
      customerOrder: CustomerOrderFactory.build({
        customer: CustomerFactory.build({
          name: 'SUNNYSIDE VALE GROCER'
        })
      })
    });

    packOrderResources.getOrderToPack.mockResolvedValue({ data: order });

    let wrapper = mount(
      <Provider store={store}>
        <OrderToPack match={{ params: { orderId: 12 } }} />
      </Provider>
    );

    function getFieldText(index) {
      return wrapper
        .find('.field')
        .at(index)
        .text();
    }

    await waitForAsyncTasks(wrapper);

    jestExpect(semanticUI.findLabelWithName(wrapper, '')).toIncludeText('RETAIL');
    jestExpect(semanticUI.findLabelWithName(wrapper, 'Pieces Per Case')).toIncludeText('10');
    jestExpect(semanticUI.findLabelWithName(wrapper, 'Pieces Remaining')).toIncludeText('320');

    jestExpect(getFieldText(0)).toEqual(jestExpect.stringContaining('4102218 - LL SKIRT STEAK'));
    jestExpect(getFieldText(1)).toEqual(jestExpect.stringContaining('6.0 OZ'));
    jestExpect(getFieldText(2)).toEqual(jestExpect.stringContaining('SUNNYSIDE VALE GROCER'));
    jestExpect(getFieldText(3)).toEqual(jestExpect.stringContaining('32'));
  });
});
