import {
  CLEAR_ORDER_TO_PACK_STATE,
  INIT_ORDER_TO_PACK,
  RESET_OVERRIDE_WEIGHT_RANGE_REQUEST,
  SHOW_OVERRIDE_WEIGHT_RANGE_REQUEST,
  UPDATE_OVERRIDE_PACKAGING_TARE
} from '../actions/packActionTypes';

const initialState = {
  order: {},
  showOverrideWeightRangeRequest: false,
  overridePackagingTare: ''
};

export default (state = initialState, action) => {
  switch (action.type) {
    case INIT_ORDER_TO_PACK:
      return {
        ...initialState,
        order: action.payload
      };

    case SHOW_OVERRIDE_WEIGHT_RANGE_REQUEST:
      return {
        ...state,
        showOverrideWeightRangeRequest: true
      };

    case RESET_OVERRIDE_WEIGHT_RANGE_REQUEST:
      return {
        ...state,
        showOverrideWeightRangeRequest: false
      };

    case CLEAR_ORDER_TO_PACK_STATE:
      return initialState;

    case UPDATE_OVERRIDE_PACKAGING_TARE:
      return {
        ...state,
        overridePackagingTare: action.payload
      };

    default:
      return state;
  }
};
