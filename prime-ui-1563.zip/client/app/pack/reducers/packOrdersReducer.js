import { UPDATE_PACK_ORDERS_INFO } from '../actions/packActionTypes';
import { LOCATION_CHANGE } from 'react-router-redux';

const initialState = {
  packOrders: null
};

export default (state = initialState, action) => {
  switch (action.type) {
    case LOCATION_CHANGE: {
      return {
        ...initialState
      };
    }
    case UPDATE_PACK_ORDERS_INFO: {
      return {
        ...initialState,
        packOrders: action.payload
      };
    }

    default:
      return state;
  }
};
