import { RESET_WIP_BOXES, UPDATE_WIP_BOXES } from '../actions/packActionTypes';

const initialState = {
  wipBoxes: []
};

export default (state = initialState, action) => {
  switch (action.type) {
    case UPDATE_WIP_BOXES:
      return {
        ...state,
        wipBoxes: [action.payload, ...state.wipBoxes]
      };

    case RESET_WIP_BOXES:
      return {
        ...state,
        wipBoxes: []
      };

    default:
      return state;
  }
};
