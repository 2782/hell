import {
  RESET_PACK_OFF_STOCK,
  SHOW_OVERRIDE_WEIGHT_RANGE_REQUEST,
  UPDATE_PACK_OFF_STOCK,
  RESET_OVERRIDE_WEIGHT_RANGE_REQUEST
} from '../actions/packActionTypes';

const initialState = {
  packedOffStocks: [],
  showOverrideWeightRangeRequest: false
};

export default (state = initialState, action) => {
  switch (action.type) {
    case UPDATE_PACK_OFF_STOCK:
      return {
        ...state,
        packedOffStocks: [action.payload, ...state.packedOffStocks]
      };

    case SHOW_OVERRIDE_WEIGHT_RANGE_REQUEST:
      return {
        ...state,
        showOverrideWeightRangeRequest: true
      };

    case RESET_OVERRIDE_WEIGHT_RANGE_REQUEST:
      return {
        ...state,
        showOverrideWeightRangeRequest: false
      };

    case RESET_PACK_OFF_STOCK:
      return {
        ...state,
        packedOffStocks: []
      };

    default:
      return state;
  }
};
