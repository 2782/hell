import packOffStockReducer from '../packOffStockReducer';

import {
  RESET_OVERRIDE_WEIGHT_RANGE_REQUEST,
  RESET_PACK_OFF_STOCK,
  SHOW_OVERRIDE_WEIGHT_RANGE_REQUEST,
  UPDATE_PACK_OFF_STOCK
} from '../../actions/packActionTypes';

describe('packOffStockReducer', () => {
  let initState;

  beforeEach(() => {
    initState = {
      packedOffStocks: [],
      showOverrideWeightRangeRequest: false
    };
  });

  test('should return default state when handle unjestExpectedAction', () => {
    jestExpect(packOffStockReducer(initState, { type: 'unjestExpected' })).toEqual(initState);
  });

  test('should show OverideWeightRangeRequest when receiving action SHOW_OVERRIDE_WEIGHT_RANGE_REQUEST', () => {
    const result = packOffStockReducer(initState, {
      type: SHOW_OVERRIDE_WEIGHT_RANGE_REQUEST
    });

    jestExpect(result).toEqual({
      packedOffStocks: [],
      showOverrideWeightRangeRequest: true
    });
  });

  test('should reset resetOverideWeightRangeRequest when receiving action RESET_OVERRIDE_WEIGHT_RANGE_REQUEST', () => {
    const state = {
      packedOffStocks: [],
      showOverrideWeightRangeRequest: true
    };

    const result = packOffStockReducer(state, {
      type: RESET_OVERRIDE_WEIGHT_RANGE_REQUEST
    });

    jestExpect(result).toEqual({
      packedOffStocks: [],
      showOverrideWeightRangeRequest: false
    });
  });

  test('should reset packedOffInfo when receiving action RESET_PACK_OFF_STOCK', () => {
    const state = {
      packedOffStocks: [{ weight: '2.0', packagingTare: '1.00' }]
    };

    const result = packOffStockReducer(state, {
      type: RESET_PACK_OFF_STOCK
    });

    jestExpect(result).toEqual({
      packedOffStocks: []
    });
  });

  test('should add new packedOffStock to packed stocks when receiving action UPDATE_PACK_OFF_STOCK', () => {
    const state = {
      packedOffStocks: [{ weight: '2.0', packagingTare: '1.00' }]
    };

    const newPackedOffStock = { weight: '3.0', packagingTare: '1.00' };

    const result = packOffStockReducer(state, {
      type: UPDATE_PACK_OFF_STOCK,
      payload: newPackedOffStock
    });
    jestExpect(result).toEqual({
      packedOffStocks: [
        { weight: '3.0', packagingTare: '1.00' },
        { weight: '2.0', packagingTare: '1.00' }
      ]
    });
  });
});
