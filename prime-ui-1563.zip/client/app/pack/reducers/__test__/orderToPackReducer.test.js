import orderToPackReducer from '../orderToPackReducer';
import {
  CLEAR_ORDER_TO_PACK_STATE,
  INIT_ORDER_TO_PACK,
  UPDATE_OVERRIDE_PACKAGING_TARE
} from '../../actions/packActionTypes';
import CutOrderFactory from '../../../../test-factories/cutOrder';

const order = CutOrderFactory.build({
  product: {
    category: 'FIXED',
    minWeight: '3.4',
    maxWeight: '3.4'
  }
});

describe('orderToPackReducer', () => {
  let initOrderToPackReducer;

  beforeEach(() => {
    initOrderToPackReducer = {
      order: {},
      showOverrideWeightRangeRequest: false,
      overridePackagingTare: ''
    };
  });

  test('should return default state when handle unexpectedAction', () => {
    jestExpect(orderToPackReducer(initOrderToPackReducer, { type: 'unexpected' })).toEqual(
      initOrderToPackReducer
    );
  });

  test('should initialize order to pack when receiving event INIT_ORDER_TO_PACK', () => {
    const result = orderToPackReducer(initOrderToPackReducer, {
      type: INIT_ORDER_TO_PACK,
      payload: order
    });
    jestExpect(result.order).toEqual(order);
  });

  test('should clear order to initial state when receiving event CLEAR_ORDER_TO_PACK_STATE', () => {
    const result = orderToPackReducer(initOrderToPackReducer, {
      type: CLEAR_ORDER_TO_PACK_STATE
    });
    jestExpect(result).toEqual(initOrderToPackReducer);
  });

  test('should clear order to initial state when receiving event CLEAR_ORDER_TO_PACK_STATE', () => {
    const result = orderToPackReducer(initOrderToPackReducer, {
      type: CLEAR_ORDER_TO_PACK_STATE
    });
    jestExpect(result).toEqual(initOrderToPackReducer);
  });

  test('should udpate override packagint tare when receiving event UPDATE_OVERRIDE_PACKAGING_TARE', () => {
    const expectResult = {
      ...initOrderToPackReducer,
      overridePackagingTare: 1.21
    };
    const result = orderToPackReducer(initOrderToPackReducer, {
      type: UPDATE_OVERRIDE_PACKAGING_TARE,
      payload: 1.21
    });
    jestExpect(result).toEqual(expectResult);
  });
});
