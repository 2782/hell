import packBoxFormReducer, { initialState } from '../packBoxFormReducer';
import { REGISTER_WEIGHT_FIELD, REGISTER_PRODUCT_CODE_FIELD } from '../../actions/packActionTypes';

describe('packBoxFormReducer', () => {
  test('should return default state when handle unexpectedAction', () => {
    jestExpect(packBoxFormReducer(undefined, { type: 'unexpected' })).toEqual(initialState);
  });

  test('should register weightField', () => {
    jestExpect(
      packBoxFormReducer(undefined, { type: REGISTER_WEIGHT_FIELD, payload: 'WEIGHT_FIELD' })
    ).toEqual({
      ...initialState,
      weightField: 'WEIGHT_FIELD'
    });
  });

  test('should register productCodeField', () => {
    jestExpect(
      packBoxFormReducer(undefined, {
        type: REGISTER_PRODUCT_CODE_FIELD,
        payload: 'PRODUCT_CODE_FIELD'
      })
    ).toEqual({
      ...initialState,
      productCodeField: 'PRODUCT_CODE_FIELD'
    });
  });
});
