import packTableSummaryReducer from '../packTableSummaryReducer';
import { UPDATE_PACK_TABLE_SUMMARY } from '../../actions/packActionTypes';
import { TABLE_SUMMARY_1, TABLE_SUMMARY_2 } from '../../../../test-factories/cutOrder';

describe('packTableSummaryReducer', () => {
  let initState;

  beforeEach(() => {
    initState = {
      tables: [],
      today: '10-13',
      tomorrow: '10-14'
    };
  });

  test('should retuen init state when handle unexpected action', () => {
    let unexpectAction = { type: 'UNEXPECTED' };
    jestExpect(packTableSummaryReducer(initState, unexpectAction)).toEqual(initState);
  });

  test('should get add index to order items when processing event UPDATE_PACK_TABLE_SUMMARY', () => {
    const packTableSummaryData = [TABLE_SUMMARY_1, TABLE_SUMMARY_2];
    const result = packTableSummaryReducer(initState, {
      type: UPDATE_PACK_TABLE_SUMMARY,
      payload: packTableSummaryData
    });
    jestExpect(result.tables).toEqual(packTableSummaryData);
  });
});
