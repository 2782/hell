import { getPackagingTare, getRetailPieceTare, isRetail } from '../actions/orderToPackAction';
import { toPrecision } from '../../shared/util/floatUtil';

function composeWeightValues(state, selector) {
  const calculation = {};

  calculation.isRetailProduct = isRetail(state);
  calculation.weight = selector(state, 'weight');
  calculation.initialPackagingTare = getPackagingTare(state);
  calculation.packagingTare = selector(state, 'packagingTare') || calculation.initialPackagingTare;
  calculation.retailPieceTare = getRetailPieceTare(state);

  calculation.netWeight =
    toPrecision(
      calculation.weight -
        (calculation.isRetailProduct ? calculation.retailPieceTare : calculation.packagingTare),
      2
    ) || '';

  return calculation;
}

export default composeWeightValues;
