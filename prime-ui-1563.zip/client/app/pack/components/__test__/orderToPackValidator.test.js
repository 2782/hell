import { validateSubmission } from '../orderToPackValidator';
import productFactory from '../../../../test-factories/productFactory';
import retailSpecificFactory from '../../../../test-factories/retailSpecificFactory';

describe('OrderToPackValidator', () => {
  const OVERRIDE_WEIGHT_RANGE_REASON_CODE = 555;

  test('should validate successfully and call submit when category is catch', () => {
    const values = {
      weight: '5.0',
      packagingTare: '1.00'
    };

    validateSubmission(values, {
      order: {
        product: productFactory.build({ category: 'CATCH', minWeight: 2.0, maxWeight: 20.0 })
      }
    });
  });

  test('should validate successfully and call submit when category is fixed', () => {
    const values = {
      weight: '4.0',
      packagingTare: '1.00',
      overrideWeightRangeReasonCode: ''
    };

    validateSubmission(values, {
      order: {
        product: productFactory.build({ category: 'FIXED', minWeight: 2.5, maxWeight: 5.2 })
      }
    });
  });

  test('should validate and throw error when weight is less than fixed', () => {
    const values = {
      weight: '30.0',
      packagingTare: '1.00',
      overrideWeightRangeReasonCode: ''
    };

    const errors = validateSubmission(values, {
      order: {
        product: productFactory.build({ category: 'FIXED', minWeight: 2.0, maxWeight: 20.0 })
      },
      showOverrideWeightRangeRequest: () => {}
    });
    jestExpect(errors).toEqual({});
  });

  test('should validate and throw error when weight is less than retail min for fixed weight retail product', () => {
    const values = {
      weight: '5.0',
      packagingTare: '1.00',
      overrideWeightRangeReasonCode: ''
    };

    const errors = validateSubmission(values, {
      netWeight: 1.0,
      order: {
        product: productFactory.build({
          category: 'FIXED',
          minWeight: 3.0,
          maxWeight: 20.0,
          retailSpecific: retailSpecificFactory.build({
            minWeight: 5.0,
            maxWeight: 7.0
          })
        })
      },
      showOverrideWeightRangeRequest: () => {}
    });
    jestExpect(errors.weight).toEqual(jestExpect.stringContaining('Less than fixed weight - 5. '));
  });

  test('should validate and throw error when weight is less than retail min for catch weight retail product', () => {
    const values = {
      weight: '5.0',
      packagingTare: '1.00',
      overrideWeightRangeReasonCode: ''
    };

    const errors = validateSubmission(values, {
      netWeight: 1.0,
      order: {
        product: productFactory.build({
          category: 'CATCH',
          minWeight: 3.0,
          maxWeight: 20.0,
          retailSpecific: retailSpecificFactory.build({
            minWeight: 5.0,
            maxWeight: 7.0
          })
        })
      },
      showOverrideWeightRangeRequest: () => {}
    });
    jestExpect(errors.weight).toEqual(
      jestExpect.stringContaining('Outside of range - weight range is 5 - 7. ')
    );
  });

  test('should validate and throw error when weight is greater than retail max for catch weight retail product', () => {
    const values = {
      weight: '15.0',
      packagingTare: '1.00',
      overrideWeightRangeReasonCode: ''
    };

    const errors = validateSubmission(values, {
      netWeight: 8.0,
      order: {
        product: productFactory.build({
          category: 'CATCH',
          minWeight: 3.0,
          maxWeight: 20.0,
          retailSpecific: retailSpecificFactory.build({
            minWeight: 5.0,
            maxWeight: 7.0
          })
        })
      },
      showOverrideWeightRangeRequest: () => {}
    });
    jestExpect(errors.weight).toEqual(
      jestExpect.stringContaining('Outside of range - weight range is 5 - 7. ')
    );
  });

  test('should validate and return no error when fixed weight retail product and not less than retail min', () => {
    const values = {
      weight: '5.0',
      packagingTare: '1.00',
      overrideWeightRangeReasonCode: ''
    };

    const errors = validateSubmission(values, {
      order: {
        product: productFactory.build({
          category: 'FIXED',
          minWeight: 6.0,
          maxWeight: 20.0,
          retailSpecific: retailSpecificFactory.build({
            minWeight: 3.0,
            maxWeight: 3.5
          })
        })
      },
      showOverrideWeightRangeRequest: () => {}
    });
    jestExpect(errors).toEqual({});
  });

  test('should validate and return no error when catch weight retail product and within min / max retail range', () => {
    const values = {
      weight: '5.0',
      packagingTare: '1.50',
      overrideWeightRangeReasonCode: ''
    };

    const errors = validateSubmission(values, {
      order: {
        product: productFactory.build({
          category: 'FIXED',
          minWeight: 6.0,
          maxWeight: 20.0,
          retailSpecific: retailSpecificFactory.build({
            minWeight: 3.0,
            maxWeight: 4.0
          })
        })
      },
      showOverrideWeightRangeRequest: () => {}
    });
    jestExpect(errors).toEqual({});
  });

  const weightErrorScenarios = [
    { scenario: 'empty', weight: '', netWeight: '', packagingTare: '1.00', error: 'Required' },
    {
      scenario: 'alphanumeric',
      weight: 'abc',
      netWeight: '',
      packagingTare: '1.00',
      error: 'Must be a number'
    },
    {
      scenario: 'negative',
      weight: '-3',
      netWeight: '-3.25',
      packagingTare: '1.00',
      error: 'Must be a positive number'
    },
    {
      scenario: 'less than minWeight',
      weight: '2.00',
      netWeight: '1.00',
      packagingTare: '1.00',
      error: 'Less than fixed weight - 3. Enter reason code and press enter to pack off.'
    },
    {
      scenario: 'equal packagingTare',
      weight: '4.0',
      netWeight: '0.00',
      packagingTare: '4.0',
      error: 'Weight should be greater than Packaging Tare'
    },
    {
      scenario: 'less than packagingTare',
      weight: '3.0',
      netWeight: '-1.00',
      packagingTare: '4.0',
      error: 'Weight should be greater than Packaging Tare'
    }
  ];

  weightErrorScenarios.forEach(
    ({ scenario, weight, category = 'FIXED', packagingTare, error, netWeight }) => {
      test(`should throw error when weight is ${scenario}`, () => {
        const values = {
          weight: weight,
          packagingTare: packagingTare,
          overrideWeightRangeReasonCode: ''
        };

        const errors = validateSubmission(values, {
          netWeight,
          order: { product: productFactory.build({ category, minWeight: 3.0, maxWeight: 20.0 }) },
          showOverrideWeightRangeRequest: () => {}
        });
        jestExpect(errors.weight).toEqual(error);
      });
    }
  );

  const packagingTareErrorScenarios = [
    { scenario: 'empty', packagingTare: '', error: 'Required' },
    { scenario: 'alphanumeric', packagingTare: 'abc', error: 'Must be a number' },
    { scenario: 'negative', packagingTare: '-3', error: 'Must be a positive number' }
  ];

  packagingTareErrorScenarios.forEach(({ scenario, packagingTare, error }) => {
    test(`should throw error when weight is ${scenario}`, () => {
      const values = {
        weight: '3.0',
        packagingTare: packagingTare,
        overrideWeightRangeReasonCode: ''
      };

      const errors = validateSubmission(
        values,
        {
          order: { product: productFactory.build({ minWeight: 2.0, maxWeight: 20.0 }) }
        },
        () => {}
      );
      jestExpect(errors.packagingTare).toEqual(error);
    });
  });

  test(
    'should not throw error when net weight is greater than max weight and ' +
      'override reason is provided',
    () => {
      const values = {
        weight: '35.0',
        packagingTare: '1.2',
        overrideWeightRangeReasonCode: OVERRIDE_WEIGHT_RANGE_REASON_CODE
      };
      const showOverrideWeightRangeRequest = jest.fn();

      validateSubmission(values, {
        order: { product: productFactory.build({ minWeight: 2.0, maxWeight: 20.0 }) },
        showOverrideWeightRangeRequest
      });

      jestExpect(showOverrideWeightRangeRequest).not.toHaveBeenCalled();
    }
  );

  test('should throw error when min/max for product is not setup', () => {
    const values = {
      weight: '35.0',
      packagingTare: '1.2'
    };

    const errors = validateSubmission(values, {
      order: { product: productFactory.build({ minWeight: null, maxWeight: null }) }
    });
    jestExpect(errors.weight).toEqual('Product setup is incomplete');
  });
});
