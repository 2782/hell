import composeWeightValues from '../composeWeightValues';
import productFactory from '../../../../test-factories/productFactory';
import retailSpecificFactory from '../../../../test-factories/retailSpecificFactory';
import tarePackageFactory, {
  DEFAULT_PACKAGE_TARE_VALUE
} from '../../../../test-factories/tarePackageFactory';
import { formatNumberToTwoDecimalPlacesString } from '../../../shared/util/dataUtil';

const mockSelector = (state, fieldName) => {
  return state.form[fieldName];
};

test('maps form state and order state to calculate net weight with default packaging tare', () => {
  const state = {
    tarePackages: {
      defaultTarePackage: tarePackageFactory.build({})
    },
    orderToPackInfo: {
      order: {
        product: productFactory.build({
          category: 'FIXED',
          minWeight: 3.0,
          maxWeight: 20.0
        })
      }
    },
    form: {
      weight: '10.00',
      packagingTare: '',
      overrideWeightRangeReasonCode: ''
    }
  };

  const result = composeWeightValues(state, mockSelector);

  // uses default package tare if not retail
  const expectedRetailPieceTare = formatNumberToTwoDecimalPlacesString(DEFAULT_PACKAGE_TARE_VALUE);

  jestExpect(result).toMatchObject({
    netWeight: -0.8,
    retailPieceTare: expectedRetailPieceTare
  });
});

test('maps form state and order state to calculate net weight with input packaging tare', () => {
  const state = {
    tarePackages: {
      defaultTarePackage: tarePackageFactory.build({})
    },
    orderToPackInfo: {
      order: {
        product: productFactory.build({
          category: 'FIXED',
          minWeight: 3.0,
          maxWeight: 20.0
        })
      }
    },
    form: {
      weight: '10.00',
      packagingTare: '5.00',
      overrideWeightRangeReasonCode: ''
    }
  };

  const result = composeWeightValues(state, mockSelector);

  // uses default package tare if not retail
  const expectedRetailPieceTare = formatNumberToTwoDecimalPlacesString(DEFAULT_PACKAGE_TARE_VALUE);

  jestExpect(result).toMatchObject({
    netWeight: 5,
    retailPieceTare: expectedRetailPieceTare
  });
});

test('maps form state and order state to calculate net weight with retail packaging tare', () => {
  const state = {
    tarePackages: {
      defaultTarePackage: tarePackageFactory.build({})
    },
    orderToPackInfo: {
      order: {
        product: productFactory.build({
          category: 'FIXED',
          minWeight: 3.0,
          maxWeight: 20.0,
          retailSpecific: retailSpecificFactory.build({
            minWeight: 5.0,
            maxWeight: 7.0,
            tare: tarePackageFactory.build({
              boxType: {
                boxTare: 4.3
              },
              filmType: {
                filmTare: 3.7
              }
            })
          })
        })
      }
    },
    form: {
      weight: '10.00',
      packagingTare: '5.00',
      overrideWeightRangeReasonCode: ''
    }
  };

  const result = composeWeightValues(state, mockSelector);

  jestExpect(result).toMatchObject({
    netWeight: 2,
    retailPieceTare: '8.00'
  });
});
