import { mount, shallow } from 'enzyme';
import React from 'react';
import PackBoxForm, {
  PackBoxForm as PackBoxFormComponent,
  f4Behavior,
  f5Behavior
} from '../PackBoxForm';
import semanticUI from '../../../../test-helpers/semantic-ui';
import productResources from '../../../shared/api/productResources';
import productFactory, { PRODUCT_2 } from '../../../../test-factories/productFactory';
import retailSpecificFactory from '../../../../test-factories/retailSpecificFactory';
import { Provider } from 'react-redux';
import { createReduxStore } from '../../../store';
import { PACK_OFF_WIP } from '../packType';
import { Field } from 'redux-form';
import { NOT_A_PRODUCT_CODE, NOT_PACK_RETAIL_ITEM } from '../../../../config/errorMessage';
import { updateOverridePackagingTare } from '../../actions/orderToPackAction';

jest.mock('../../../shared/scale/scale');
jest.mock('../../../shared/api/productResources');

const FORM_NAME = 'testform';

describe('PackBoxForm', () => {
  let onReset, onSubmit, registerWeightField, registerProductCodeField;

  beforeEach(() => {
    onReset = jest.fn();
    onSubmit = jest.fn();
    registerWeightField = jest.fn();
    registerProductCodeField = jest.fn();
  });

  test('should use default packaging tare value 1.00 on pack wip page', () => {
    const store = createReduxStore({
      packedOffStockInfo: {
        showOverrideWeightRangeRequest: false
      }
    });

    const wrapper = mount(
      <Provider store={store}>
        <PackBoxForm
          form={FORM_NAME}
          packedBoxes={[]}
          onReset={onReset}
          onSubmit={onSubmit}
          packType={PACK_OFF_WIP}
          updateOverridePackagingTare={() => {}}
        />
      </Provider>
    );

    jestExpect(semanticUI.getInputValue(wrapper, 'packagingTare')).toEqual('1.00');
  });

  test('should initialize form with tare override if it exists', () => {
    const store = createReduxStore({
      packedOffStockInfo: {
        showOverrideWeightRangeRequest: false
      }
    });

    const overridePackagingTare = '2.75';

    store.dispatch(updateOverridePackagingTare(overridePackagingTare));

    const wrapper = mount(
      <Provider store={store}>
        <PackBoxForm
          form={FORM_NAME}
          packedBoxes={[]}
          onReset={onReset}
          onSubmit={onSubmit}
          packType={PACK_OFF_WIP}
          updateOverridePackagingTare={() => {}}
        />
      </Provider>
    );

    jestExpect(semanticUI.getInputValue(wrapper, 'packagingTare')).toEqual(overridePackagingTare);
  });

  test('should not show reason field when showOverrideWeightRange is false', () => {
    const store = createReduxStore({
      productDuplicate: {
        products: {
          [PRODUCT_2.code]: PRODUCT_2
        },
        productsExist: {
          [PRODUCT_2.code]: true
        }
      },
      packedOffStockInfo: {
        packedOffStocks: [],
        showOverrideWeightRangeRequest: false
      }
    });

    const form = mount(
      <Provider store={store}>
        <PackBoxForm
          shouldAsyncValidate={() => false}
          form={FORM_NAME}
          packedBoxes={[]}
          onReset={() => {}}
          onSubmit={() => {}}
          updateOverridePackagingTare={() => {}}
        />
      </Provider>
    );

    jestExpect(form.find('div[pid="override-weight-range-reason-code"]').exists()).toBeFalsy();
  });

  test('should show reason field when showOverweightRange is true', () => {
    const store = createReduxStore({
      productDuplicate: {
        products: {
          [PRODUCT_2.code]: PRODUCT_2
        },
        productsExist: {
          [PRODUCT_2.code]: true
        }
      },
      packedOffStockInfo: {
        packedOffStocks: [],
        showOverrideWeightRangeRequest: true
      }
    });

    const form = mount(
      <Provider store={store}>
        <PackBoxForm
          shouldAsyncValidate={() => false}
          form={FORM_NAME}
          packedBoxes={[]}
          onReset={() => {}}
          onSubmit={() => {}}
          updateOverridePackagingTare={() => {}}
        />
      </Provider>
    );

    jestExpect(form.find('div[pid="override-weight-range-reason-code"]').exists()).toBeTruthy();
  });

  test('should not submit wrapper if product is invalid', () => {
    productResources.getProductInfo.mockImplementation((value, suc, err) => err());

    const store = createReduxStore({
      productDuplicate: {
        products: {
          [PRODUCT_2.code]: PRODUCT_2
        },
        productsExist: {
          [PRODUCT_2.code]: true
        }
      },
      packedOffStockInfo: {
        packedOffStocks: [],
        showOverrideWeightRangeRequest: true
      }
    });

    const wrapper = mount(
      <Provider store={store}>
        <PackBoxForm
          shouldAsyncValidate={() => false}
          form={FORM_NAME}
          packedBoxes={[]}
          onReset={onReset}
          onSubmit={onSubmit}
          updateOverridePackagingTare={() => {}}
        />
      </Provider>
    );

    semanticUI.changeInput(wrapper, 'productCode', '12345');
    semanticUI.changeInput(wrapper, 'weight', '12.6');
    semanticUI.changeInput(wrapper, 'packagingTare', '2.2');

    wrapper.find('form').simulate('submit');

    jestExpect(onSubmit).not.toBeCalled();
  });

  test('should not submit wrapper if productCode is null', () => {
    productResources.getProductInfo.mockImplementation((value, suc, err) => err());

    const store = createReduxStore({
      packedOffStockInfo: {
        packedOffStocks: [],
        showOverrideWeightRangeRequest: true
      }
    });

    const wrapper = mount(
      <Provider store={store}>
        <PackBoxForm
          shouldAsyncValidate={() => true}
          form={FORM_NAME}
          packedBoxes={[]}
          onReset={onReset}
          onSubmit={onSubmit}
          updateOverridePackagingTare={() => {}}
        />
      </Provider>
    );

    semanticUI.changeInput(wrapper, 'weight', '12.6');

    wrapper.find('form').simulate('submit');

    jestExpect(onSubmit).not.toBeCalled();
  });

  test('should not submit wrapper if product is invalid and shouldAsyncValidate true', () => {
    productResources.getProductInfo.mockImplementation((value, suc, err) => err());

    const store = createReduxStore({
      productDuplicate: {
        products: {
          [PRODUCT_2.code]: PRODUCT_2
        },
        productsExist: {
          [PRODUCT_2.code]: true
        }
      },
      packedOffStockInfo: {
        packedOffStocks: [],
        showOverrideWeightRangeRequest: true
      }
    });

    const wrapper = mount(
      <Provider store={store}>
        <PackBoxForm
          shouldAsyncValidate={() => true}
          form={FORM_NAME}
          packedBoxes={[]}
          onReset={onReset}
          onSubmit={onSubmit}
          updateOverridePackagingTare={() => {}}
        />
      </Provider>
    );

    semanticUI.changeInput(wrapper, 'productCode', '12345');
    semanticUI.changeInput(wrapper, 'weight', '12.6');
    semanticUI.changeInput(wrapper, 'packagingTare', '2.2');

    wrapper.find('form').simulate('submit');

    jestExpect(onSubmit).not.toBeCalled();
  });

  describe('rendering message for Product Component', () => {
    test('should pass NOT_A_PRODUCT_CODE when product does not exist', () => {
      const productsExist = {
        productCode: false
      };
      const productsDuplicate = {};
      const portionSize = {
        unitOfWeight: 'OZ',
        value: 7.8
      };

      const setProductExistToSpy = jest.fn();
      let wrapper = shallow(
        <PackBoxFormComponent
          packedBoxes={[]}
          form={FORM_NAME}
          onReset={onReset}
          onSubmit={onSubmit}
          reset={jest.fn()}
          handleSubmit={jest.fn()}
          portionSize={portionSize}
          resetOverrideWeightRange={() => {}}
          finishedProductCode={''}
          productsDuplicate={productsDuplicate}
          getDefaultTarePackage={() => {}}
          currentProduct={productFactory.build()}
          productsExist={productsExist}
          shouldResetForm={false}
          showOverrideWeightRangeRequest={jest.fn()}
          updateOverridePackagingTare={() => {}}
          setProductExistTo={setProductExistToSpy}
          netWeight=''
        />
      );

      const productField = wrapper.find(Field).at(0);

      jestExpect(productField.props().message).toEqual(NOT_A_PRODUCT_CODE);
    });

    test('should pass null when product does exist', () => {
      const productsExist = {
        productCode: true
      };
      const productsDuplicate = {};
      const portionSize = {
        unitOfWeight: 'OZ',
        value: 7.8
      };

      const setProductExistToSpy = jest.fn();
      let wrapper = shallow(
        <PackBoxFormComponent
          packedBoxes={[]}
          form={FORM_NAME}
          onReset={onReset}
          onSubmit={onSubmit}
          reset={jest.fn()}
          handleSubmit={jest.fn()}
          portionSize={portionSize}
          resetOverrideWeightRange={() => {}}
          finishedProductCode={''}
          productsDuplicate={productsDuplicate}
          getDefaultTarePackage={() => {}}
          currentProduct={productFactory.build()}
          productsExist={productsExist}
          shouldResetForm={false}
          showOverrideWeightRangeRequest={jest.fn()}
          updateOverridePackagingTare={() => {}}
          setProductExistTo={setProductExistToSpy}
          netWeight=''
        />
      );

      const productField = wrapper.find(Field).at(0);

      jestExpect(productField.props().message).toEqual(null);
    });

    test('should show NOT_PACK_RETAIL_ITEM when product is a retail product on packoff stock screen', () => {
      const productsExist = {
        productCode: true
      };
      const productsDuplicate = {};
      const portionSize = {
        unitOfWeight: 'OZ',
        value: 7.8
      };

      let currentProduct = productFactory.build({
        retailSpecific: retailSpecificFactory.build({
          price: 1.25,
          tare: 0.57,
          minWeight: 5.0
        })
      });

      const setProductExistToSpy = jest.fn();
      let wrapper = shallow(
        <PackBoxFormComponent
          packedBoxes={[]}
          form={FORM_NAME}
          onReset={onReset}
          onSubmit={onSubmit}
          reset={jest.fn()}
          handleSubmit={jest.fn()}
          portionSize={portionSize}
          resetOverrideWeightRange={() => {}}
          finishedProductCode={''}
          productsDuplicate={productsDuplicate}
          getDefaultTarePackage={() => {}}
          currentProduct={currentProduct}
          productsExist={productsExist}
          shouldResetForm={false}
          showOverrideWeightRangeRequest={jest.fn()}
          updateOverridePackagingTare={() => {}}
          setProductExistTo={setProductExistToSpy}
          isForPackWip={false}
          netWeight=''
        />
      );

      const productField = wrapper.find(Field).at(0);

      jestExpect(productField.props().message).toEqual(NOT_PACK_RETAIL_ITEM);
    });

    test('should not show NOT_PACK_RETAIL_ITEM when product is a retail product on packoff WIP screen', () => {
      const productsExist = {
        productCode: true
      };
      const productsDuplicate = {};
      const portionSize = {
        unitOfWeight: 'OZ',
        value: 7.8
      };

      let currentProduct = productFactory.build({
        retailSpecific: retailSpecificFactory.build({
          price: 1.25,
          tare: 0.57,
          minWeight: 5.0
        })
      });

      const setProductExistToSpy = jest.fn();
      let wrapper = shallow(
        <PackBoxFormComponent
          packedBoxes={[]}
          form={FORM_NAME}
          onReset={onReset}
          onSubmit={onSubmit}
          reset={jest.fn()}
          handleSubmit={jest.fn()}
          portionSize={portionSize}
          resetOverrideWeightRange={() => {}}
          finishedProductCode={''}
          productsDuplicate={productsDuplicate}
          getDefaultTarePackage={() => {}}
          currentProduct={currentProduct}
          productsExist={productsExist}
          shouldResetForm={false}
          showOverrideWeightRangeRequest={jest.fn()}
          updateOverridePackagingTare={() => {}}
          setProductExistTo={setProductExistToSpy}
          isForPackWip={true}
          netWeight=''
        />
      );

      const productField = wrapper.find(Field).at(0);

      jestExpect(productField.props().message).toEqual(null);
    });
  });

  describe('componentWillUnMount', () => {
    test('call resetOverrideWeightRange since there is no finishedProductCode', () => {
      const resetOverrideWeightRange = jest.fn();
      const setProductExistToSpy = jest.fn();
      const getDefaultTarePackage = jest.fn();
      const productsDuplicate = {};
      const portionSize = {
        unitOfWeight: 'OZ',
        value: 7.8
      };

      let wrapper = shallow(
        <PackBoxFormComponent
          packedBoxes={[]}
          form={FORM_NAME}
          onReset={onReset}
          onSubmit={onSubmit}
          reset={jest.fn()}
          handleSubmit={jest.fn()}
          portionSize={portionSize}
          resetOverrideWeightRange={resetOverrideWeightRange}
          finishedProductCode={''}
          productsDuplicate={productsDuplicate}
          getDefaultTarePackage={getDefaultTarePackage}
          currentProduct={productFactory.build()}
          productCodeExists={true}
          shouldResetForm={false}
          showOverrideWeightRangeRequest={jest.fn()}
          updateOverridePackagingTare={() => {}}
          setProductExistTo={setProductExistToSpy}
          netWeight=''
        />
      );

      wrapper.unmount();

      jestExpect(resetOverrideWeightRange).toHaveBeenCalledTimes(1);
      jestExpect(setProductExistToSpy).not.toHaveBeenCalled();
    });

    test('call resetOverrideWeightRange and setProductExistTo when componentWillUnMount', () => {
      const resetOverrideWeightRange = jest.fn();
      const setProductExistToSpy = jest.fn();
      const getDefaultTarePackage = jest.fn();
      const finishedProductCode = '0078889';
      const productsDuplicate = {
        '0078889': productFactory.build({
          productPortionSize: {
            id: 6851,
            productCode: '0078889',
            portionSize: {
              unitOfWeight: 'OZ',
              value: 7.8
            },
            piecesPerCase: 32
          }
        })
      };
      const portionSize = {
        unitOfWeight: 'OZ',
        value: 7.8
      };

      let wrapper = shallow(
        <PackBoxFormComponent
          form={FORM_NAME}
          onReset={onReset}
          onSubmit={onSubmit}
          reset={jest.fn()}
          handleSubmit={jest.fn()}
          portionSize={portionSize}
          resetOverrideWeightRange={resetOverrideWeightRange}
          finishedProductCode={finishedProductCode}
          productsDuplicate={productsDuplicate}
          getDefaultTarePackage={getDefaultTarePackage}
          currentProduct={productFactory.build()}
          productCodeExists={true}
          shouldResetForm={false}
          showOverrideWeightRangeRequest={jest.fn()}
          updateOverridePackagingTare={() => {}}
          setProductExistTo={setProductExistToSpy}
          netWeight=''
        />
      );

      wrapper.unmount();

      jestExpect(resetOverrideWeightRange).toHaveBeenCalledTimes(1);
      jestExpect(setProductExistToSpy).toHaveBeenCalledWith('productCode', true);
    });
  });

  describe('componentDidUpdate', () => {
    test('should call "getDefaultTarePackage" action when current product has no TarePackage', () => {
      const finishedProductCode = '0078889';
      const productsDuplicate = {
        '0078889': {}
      };
      const portionSize = {
        size: '7.80 OZ',
        piecesPerCase: 32
      };
      const getTarePackageSpy = jest.fn();
      const wrapper = shallow(
        <PackBoxFormComponent
          reset={() => {}}
          packedBoxes={[]}
          onReset={onReset}
          onSubmit={onSubmit}
          handleSubmit={() => {}}
          form={FORM_NAME}
          finishedProductCode={finishedProductCode}
          productsDuplicate={productsDuplicate}
          portionSize={portionSize}
          getDefaultTarePackage={getTarePackageSpy}
          updateOverridePackagingTare={() => {}}
          netWeight=''
        />
      );
      wrapper.setProps({
        currentProduct: {
          tarePackage: null
        }
      });

      jestExpect(getTarePackageSpy).toBeCalledTimes(2);
    });

    test('should call submit when all values are valid', () => {
      productResources.getProductInfo.mockImplementation((thing, fn) =>
        fn({
          data: productFactory.build({ code: '0078889' })
        })
      );

      onSubmit.mockResolvedValue({});

      const store = createReduxStore({
        productDuplicate: {
          products: {
            [PRODUCT_2.code]: PRODUCT_2
          },
          productsExist: {
            [PRODUCT_2.code]: true
          }
        },
        packedOffStockInfo: {
          packedOffStocks: [],
          showOverrideWeightRangeRequest: true
        },
        portionRoomsInfo: {
          currentPortionRoom: {
            code: 'B'
          }
        }
      });

      const wrapper = mount(
        <Provider store={store}>
          <PackBoxForm
            shouldAsyncValidate={() => false}
            form={FORM_NAME}
            packedBoxes={[]}
            packType={PACK_OFF_WIP}
            onReset={onReset}
            onSubmit={onSubmit}
            registerProductCodeField={registerProductCodeField}
            registerWeightField={registerWeightField}
            updateOverridePackagingTare={() => {}}
          />
        </Provider>
      );

      semanticUI.changeInput(wrapper, 'productCode', '78889');
      semanticUI.changeInput(wrapper, 'weight', '12.6');

      wrapper.find('form').simulate('submit');

      jestExpect(onSubmit).toBeCalledWith({
        overrideWeightRangeReasonCode: '',
        packagingTare: '1.00',
        productCode: '0078889',
        weight: '12.60'
      });
    });

    test('should call actions when props are updated', () => {
      const finishedProductCode = '0078889';
      const productsDuplicate = {
        '0078889': {}
      };
      const portionSize = {
        size: '7.80 OZ',
        piecesPerCase: 32
      };
      const onResetMock = jest.fn();
      const resetOverrideMock = jest.fn();
      const resetReasonMock = jest.fn();
      const resetMock = jest.fn();
      const wrapper = shallow(
        <PackBoxFormComponent
          form={FORM_NAME}
          packedBoxes={[]}
          onReset={onResetMock}
          onSubmit={onSubmit}
          currentProduct={productFactory.build({})}
          handleSubmit={() => {}}
          finishedProductCode={finishedProductCode}
          productsDuplicate={productsDuplicate}
          portionSize={portionSize}
          getDefaultTarePackage={() => {}}
          resetOverrideWeightRange={resetOverrideMock}
          resetReasonCode={resetReasonMock}
          reset={resetMock}
          updateOverridePackagingTare={() => {}}
          netWeight=''
          clearState={() => {}}
        />
      );

      wrapper.setProps({
        currentProduct: {
          code: '4102218',
          tarePackage: null
        }
      });

      jestExpect(resetOverrideMock).toBeCalledTimes(1);
      jestExpect(resetReasonMock).toBeCalledTimes(1);
      jestExpect(resetMock).toBeCalledTimes(1);
    });

    test('should call actions when change in netWeight', () => {
      const finishedProductCode = '0078889';
      const productsDuplicate = {
        '0078889': {}
      };
      const portionSize = {
        size: '7.80 OZ',
        piecesPerCase: 32
      };
      const resetOverrideMock = jest.fn();
      const resetReasonMock = jest.fn();
      const wrapper = shallow(
        <PackBoxFormComponent
          reset={() => {}}
          form={FORM_NAME}
          packedBoxes={[]}
          onReset={onReset}
          onSubmit={onSubmit}
          currentProduct={productFactory.build({})}
          handleSubmit={() => {}}
          finishedProductCode={finishedProductCode}
          productsDuplicate={productsDuplicate}
          portionSize={portionSize}
          getDefaultTarePackage={() => {}}
          resetOverrideWeightRange={resetOverrideMock}
          resetReasonCode={resetReasonMock}
          netWeight={'1.5'}
          updateOverridePackagingTare={() => {}}
        />
      );

      wrapper.setProps({
        netWeight: '5.3'
      });

      jestExpect(resetOverrideMock).toBeCalledTimes(1);
      jestExpect(resetReasonMock).toBeCalledTimes(1);
    });
  });

  describe('f5 Behavior', () => {
    test('should clear fields on f5 pressing', () => {
      const props = {
        resetReasonCode: jest.fn(),
        resetOverrideWeightRange: jest.fn(),
        reset: jest.fn(),
        onReset: jest.fn(),
        resetProductCode: jest.fn(),
        focusProductCodeField: jest.fn()
      };

      f5Behavior(props);

      jestExpect(props.resetReasonCode).toHaveBeenCalled();
      jestExpect(props.resetOverrideWeightRange).toHaveBeenCalled();
      jestExpect(props.reset).toHaveBeenCalled();
      jestExpect(props.onReset).toHaveBeenCalled();
      jestExpect(props.resetProductCode).toHaveBeenCalled();
      jestExpect(props.focusProductCodeField).toHaveBeenCalled();
    });
  });

  describe('f4 Behavior', () => {
    test('should hide modal on f4 when modal is showing', () => {
      const props = {
        isModalShowing: true,
        hideModal: jest.fn(),
        replacePath: jest.fn()
      };

      f4Behavior(props);

      jestExpect(props.hideModal).toHaveBeenCalled();
      jestExpect(props.replacePath).not.toHaveBeenCalled();
    });

    test('should change path when exiting this page', () => {
      const props = {
        isModalShowing: false,
        hideModal: jest.fn(),
        replacePath: jest.fn()
      };

      f4Behavior(props);

      jestExpect(props.hideModal).not.toHaveBeenCalled();
      jestExpect(props.replacePath).toHaveBeenCalledWith('/main-navigation');
    });
  });
});
