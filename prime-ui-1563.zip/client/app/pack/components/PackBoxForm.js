import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import _ from 'lodash';
import { hideModal, replacePath } from '../../shared/actions/actions';
import {
  change,
  clearSubmitErrors,
  Field,
  formValueSelector,
  reduxForm,
  SubmissionError
} from 'redux-form';
import { Button, Divider, Form } from 'semantic-ui-react';
import FormLabel from '../../shared/FormLabel';
import { normalizeProductCode } from '../../shared/components/product/normalizer';
import PackBoxFormValidator from './packBoxFormValidator';
import PackingBoxWeight from './PackingBoxWeight';
import { formatNumberToTwoDecimalPlacesString } from '../../shared/util/dataUtil';
import {
  focusProductCodeField,
  focusWeightField,
  registerProductCodeField,
  registerWeightField,
  resetOverrideWeightRange,
  showOverrideWeightRangeRequest
} from '../actions/packActions';
import { getDefaultTarePackage } from '../../settings/actions/tarePackagesActions';
import FormElement from '../../shared/FormElement';
import { bindActionCreators } from 'redux';
import { number } from '../../shared/validation/formFieldValidations';
import { PACK_OFF_WIP } from './packType';
import { clearState, updateOverridePackagingTare } from '../actions/orderToPackAction';
import { checkProductHasCost } from '../../shared/actions/checkProductHasCost';
import ProductDuplicate from '../../shared/components/product/ProductDuplicate';
import { getProduct, setProductExistTo } from '../../shared/components/product/actionsDuplicate';
import { calculatePackagingTare } from './packagingTareCalculator';
import { NOT_A_PRODUCT_CODE, NOT_PACK_RETAIL_ITEM } from '../../../config/errorMessage';
import subscriber from '../../shared/functionKeys/subscriber';

export class PackBoxForm extends React.Component {
  constructor(props) {
    super(props);

    this.submit = this.submit.bind(this);
    this.handleFinishedProductCodeBlur = this.handleFinishedProductCodeBlur.bind(this);
    this.handleFinishedProductCodeChange = this.handleFinishedProductCodeChange.bind(this);
    this.clearAllDataAndRefocusToProductCodeInput = this.clearAllDataAndRefocusToProductCodeInput.bind(
      this
    );
  }

  componentDidMount() {
    this.props.getDefaultTarePackage();
  }

  componentWillUnmount() {
    const { resetOverrideWeightRange, finishedProductCode, setProductExistTo } = this.props;
    if (!_.isEmpty(finishedProductCode)) {
      setProductExistTo('productCode', true);
    }
    resetOverrideWeightRange();
  }

  componentDidUpdate(prevProps) {
    const {
      shouldResetForm,
      currentProduct,
      netWeight,
      resetOverrideWeightRange,
      resetReasonCode,
      getDefaultTarePackage
    } = this.props;
    const productCodeChanged =
      prevProps.currentProduct &&
      (!currentProduct || currentProduct.code !== prevProps.currentProduct.code);
    const netWeightChanged =
      prevProps.netWeight && (!netWeight || prevProps.netWeight !== netWeight);
    if (shouldResetForm) {
      this.clearAllDataAndRefocusToProductCodeInput();
    }
    if (!currentProduct.tarePackage) {
      getDefaultTarePackage();
    }
    if (productCodeChanged) {
      this.props.clearState();
      this.clearAllDataAndRefocusToProductCodeInput();
    }
    if (netWeightChanged) {
      resetOverrideWeightRange();
      resetReasonCode();
    }
  }

  clearAllDataAndRefocusToProductCodeInput() {
    const { resetReasonCode, resetOverrideWeightRange, reset } = this.props;
    resetOverrideWeightRange();
    resetReasonCode();
    reset();
  }

  submit(values) {
    const {
      onSubmit,
      currentProduct,
      form,
      showOverrideWeightRangeRequest,
      showOverrideWeightRange,
      resetOverrideWeightRange,
      clearSubmitErrors,
      error
    } = this.props;

    if (showOverrideWeightRange) {
      resetOverrideWeightRange();
    }

    if (_.isEmpty(currentProduct)) {
      return;
    }

    const errors = PackBoxFormValidator.validateSubmission(values, {
      ...currentProduct,
      packType: form,
      showOverrideWeightRangeRequest
    });

    if (!_.isEmpty(errors)) {
      throw new SubmissionError(Object.assign({}, errors, { _error: 'Submission Failed!' }));
    }

    return onSubmit(values)
      .then(() => {
        this.props.updateOverridePackagingTare(values.packagingTare);

        if (error) {
          clearSubmitErrors(form);
        }

        this.clearAllDataAndRefocusToProductCodeInput();
      })
      .catch(errorResponse => {
        PackBoxFormValidator.processErrorResponse(_.get(errorResponse, 'response.data', {}));
      });
  }

  handleFinishedProductCodeBlur(event, normalizedValue, prevValue, fieldName) {
    const { getProduct, setProductExistTo } = this.props;
    if (!_.isEmpty(normalizedValue)) {
      getProduct(normalizedValue, () => setProductExistTo(fieldName, false));
    }
  }

  handleFinishedProductCodeChange(event, productCode, prevValue, fieldName) {
    const { setProductExistTo } = this.props;
    if (!_.isEmpty(productCode)) {
      setProductExistTo(fieldName, true);
    }
  }

  renderOverrideWeightRange() {
    const { showOverrideWeightRange } = this.props;

    return showOverrideWeightRange ? (
      <Form.Group>
        <Field
          component={FormElement}
          name='overrideWeightRangeReasonCode'
          pid='override-weight-range-reason-code'
          as={Form.Input}
          type='text'
          validate={number}
          label='Reason Code'
          autoFocus={true}
          width={3}
          maxLength={3}
        />
      </Form.Group>
    ) : (
      ''
    );
  }

  render() {
    const {
      portionSize,
      netWeight,
      pristine,
      submitting,
      handleSubmit,
      form,
      registerWeightField,
      registerProductCodeField,
      productsDuplicate,
      productsExist,
      currentProduct,
      finishedProductCode,
      isForPackWip
    } = this.props;

    const isRetailProduct = !_.isEmpty(_.get(currentProduct, 'retailSpecific', {}));
    const product = productsDuplicate[finishedProductCode] || {};

    return (
      <div className='pack-box-form'>
        <Form size={'large'} onSubmit={handleSubmit(this.submit)}>
          <Divider hidden className='pack-box-form-divider' />
          <Field
            component={ProductDuplicate}
            name='productCode'
            label='Product #'
            autoFocus
            withRef
            ref={node => registerProductCodeField(node)}
            normalize={normalizeProductCode}
            message={
              _.get(productsExist, 'productCode', true)
                ? isRetailProduct && !isForPackWip
                  ? NOT_PACK_RETAIL_ITEM
                  : null
                : NOT_A_PRODUCT_CODE
            }
            product={product}
            onBlur={this.handleFinishedProductCodeBlur}
            onChange={this.handleFinishedProductCodeChange}
          />

          <Divider hidden className='pack-box-form-divider' />

          <Form.Group>
            <FormLabel label='Size' value={portionSize.size} width={3} />
            <FormLabel label='Pieces/Case' value={portionSize.piecesPerCase} width={3} />
          </Form.Group>

          <PackingBoxWeight
            formName={form}
            scaleRef={node => registerWeightField(node)}
            netWeight={netWeight}
            product={product}
          />

          <Divider hidden className='pack-box-form-divider' />
          {this.renderOverrideWeightRange()}
          <Button
            primary
            size={'large'}
            type='submit'
            loading={submitting}
            disabled={submitting || pristine || (isRetailProduct && !isForPackWip)}
            id='submit-box-to-pack'
          >
            Label
          </Button>

          <Divider hidden className='pack-box-form-divider' />
        </Form>
      </div>
    );
  }
}

PackBoxForm.propTypes = {
  netWeight: PropTypes.string,
  overrideWeightRangeReasonCode: PropTypes.string,
  finishedProductCodeExists: PropTypes.bool,
  portionSize: PropTypes.object,
  showOverrideWeightRange: PropTypes.bool,
  onReset: PropTypes.func.isRequired,
  resetReasonCode: PropTypes.func,
  onSubmit: PropTypes.func.isRequired,
  showOverrideWeightRangeRequest: PropTypes.func,
  resetOverrideWeightRange: PropTypes.func,
  reset: PropTypes.func.isRequired,
  handleSubmit: PropTypes.func.isRequired,
  clearSubmitErrors: PropTypes.func,
  submitting: PropTypes.bool,
  pristine: PropTypes.bool,
  invalid: PropTypes.bool,
  form: PropTypes.string.isRequired,
  error: PropTypes.string,
  isForPackWip: PropTypes.bool,
  packedBoxes: PropTypes.array,
  packType: PropTypes.string,
  getDefaultTarePackage: PropTypes.func.isRequired,
  updateOverridePackagingTare: PropTypes.func.isRequired,
  productsDuplicate: PropTypes.object.isRequired,
  finishedProductCode: PropTypes.string,
  focusProductCodeField: PropTypes.func,
  registerProductCodeField: PropTypes.func,
  focusWeightField: PropTypes.func,
  registerWeightField: PropTypes.func,
  getProduct: PropTypes.func,
  currentProduct: PropTypes.object,
  shouldResetForm: PropTypes.bool,
  setProductExistTo: PropTypes.func,
  productsExist: PropTypes.object,
  isModalShowing: PropTypes.bool,
  hideModal: PropTypes.func,
  replacePath: PropTypes.func,
  clearState: PropTypes.func
};

function getPackagingTare(tareOverride, isForPackWip, currentProduct, defaultTarePackage) {
  if (tareOverride !== '') {
    return tareOverride;
  }

  return isForPackWip ? '1.00' : calculatePackagingTare(currentProduct, defaultTarePackage);
}

const mapStateToProps = (state, ownProps) => {
  const selector = formValueSelector(ownProps.form);

  const weight = selector(state, 'weight');
  const formPackagingTare = selector(state, 'packagingTare');
  const finishedProductCode = selector(state, 'productCode');
  const netWeight = formatNumberToTwoDecimalPlacesString(
    Number.parseFloat(weight) - Number.parseFloat(formPackagingTare)
  );
  const productsDuplicate = state.productDuplicate.products;
  const productsExist = state.productDuplicate.productsExist || {};
  const currentProduct = productsDuplicate[finishedProductCode] || {};

  const packType = ownProps.packType;
  const isForPackWip = PACK_OFF_WIP === packType;
  const defaultTarePackage = state.tarePackages.defaultTarePackage;
  const tareOverride = state.orderToPackInfo.overridePackagingTare;
  const packagingTare = getPackagingTare(
    tareOverride,
    isForPackWip,
    currentProduct,
    defaultTarePackage
  );

  const isModalShowing = state.confirmationModal.showing;

  return {
    isForPackWip: isForPackWip,
    initialValues: {
      productCode: currentProduct.code || '',
      packagingTare,
      overrideWeightRangeReasonCode: ''
    },
    portionSize: {
      size: _.get(currentProduct, 'productPortionSize.portionSize', ''),
      piecesPerCase: _.get(currentProduct, 'productPortionSize.piecesPerCase', '')
    },

    isWeightFieldClean: _.isEmpty(weight),
    netWeight: isNaN(netWeight) ? '' : String(netWeight),
    productsDuplicate,
    productsExist,
    finishedProductCode,
    currentProduct,
    overrideWeightRangeReasonCode: selector(state, 'overrideWeightRangeReasonCode'),
    showOverrideWeightRange: state.packedOffStockInfo.showOverrideWeightRangeRequest,
    isModalShowing
  };
};

const mapDispatchToProps = (dispatch, ownProps) =>
  bindActionCreators(
    {
      getProduct,
      setProductExistTo,
      focusProductCodeField,
      focusWeightField,
      registerProductCodeField,
      registerWeightField,
      showOverrideWeightRangeRequest,
      resetOverrideWeightRange,
      getDefaultTarePackage,
      updateOverridePackagingTare,
      clearSubmitErrors,
      resetReasonCode: () => dispatch(change(ownProps.form, 'overrideWeightRangeReasonCode', '')),
      resetProductCode: () => dispatch(change(ownProps.form, 'productCode', '')),
      hideModal,
      replacePath,
      clearState
    },
    dispatch
  );

const onSubmitSuccess = (result, dispatch, props) => {
  dispatch(change(props.form, 'weight', ''));
  dispatch(change(props.form, 'overrideWeightRangeReasonCode', ''));
  if (props.isForPackWip) {
    dispatch(change(props.form, 'productCode', ''));
    props.focusProductCodeField();
  } else {
    props.focusWeightField();
  }
  props.clearSubmitErrors(props.form);
};

const asyncValidate = (values, dispatch) => {
  const { productCode, weight } = values;

  if (!_.isEmpty(weight) && _.isEmpty(productCode)) {
    return Promise.resolve({ productCode: 'Required' });
  }
  if (!_.isEmpty(productCode)) {
    return dispatch(checkProductHasCost(values.productCode));
  }

  return Promise.resolve();
};

export const f4Behavior = props => {
  const { isModalShowing, hideModal, replacePath } = props;
  if (isModalShowing) {
    hideModal();
  } else {
    replacePath('/main-navigation');
  }
};

export const f5Behavior = props => {
  const {
    resetReasonCode,
    resetOverrideWeightRange,
    reset,
    onReset,
    resetProductCode,
    focusProductCodeField
  } = props;

  resetOverrideWeightRange();
  resetReasonCode();
  reset();
  onReset();
  resetProductCode();
  focusProductCodeField();
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(
  reduxForm({
    // Expect 'form' prop to be passed in
    asyncValidate,
    asyncBlurFields: ['productCode'],
    enableReinitialize: true,
    onSubmitSuccess
  })(
    subscriber(PackBoxForm, {
      f4Behavior,
      f5Behavior,
      targetComponent: 'PackBoxForm',
      uris: {
        F4: ['#/pack/pack-wip', '#/pack/pack-off-stock'],
        F5: ['#/pack/pack-wip', '#/pack/pack-off-stock']
      }
    })
  )
);
