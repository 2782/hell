export const PACK_OFF_WIP = 'packWIP';
export const PACK_OFF_STOCK = 'packOffStock';
export const PACK_OFF_RETAIL = 'packOffRetail';
export const PACK_OFF_NORMAL = 'normal';
