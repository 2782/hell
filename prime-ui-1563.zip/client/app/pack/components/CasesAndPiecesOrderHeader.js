import React from 'react';
import PropTypes from 'prop-types';
import { Form } from 'semantic-ui-react';
import FormLabel from '../../shared/FormLabel';
import { BANQUET, STANDARD } from '../../../config/cutType';

class CasesAndPiecesOrderHeader extends React.Component {
  renderCasesRemaining() {
    const { qtyInBoxes, qtyPacked } = this.props;
    const quantityRemaining = qtyInBoxes - qtyPacked;

    return <FormLabel label='Cases Remaining' value={quantityRemaining} width={3} />;
  }

  renderFirstPiecesColumn() {
    const { isRetail, unitOfMeasure, piecesPerCase, qtyToProduce } = this.props;

    if (isRetail) {
      return <FormLabel label='Pieces Per Case' value={piecesPerCase} width={3} />;
    }

    if (unitOfMeasure === 'PIECE') {
      return <FormLabel label='Pieces Ordered' value={qtyToProduce} width={3} />;
    }

    return null;
  }

  renderSecondPiecesColumn() {
    const { isRetail, qtyInPieces, unitOfMeasure, piecesPerCase, packedBoxes } = this.props;

    const totalPiecesPackedOff = packedBoxes.reduce((acc, box) => {
      acc += box.weighings.length;
      return acc;
    }, 0);

    if (isRetail) {
      return (
        <FormLabel label='Pieces Remaining' value={qtyInPieces - totalPiecesPackedOff} width={3} />
      );
    }

    if (unitOfMeasure === 'PIECE') {
      return (
        <FormLabel label='Pieces Per Box' value={piecesPerCase ? piecesPerCase : ''} width={3} />
      );
    }

    return null;
  }

  renderOrderType() {
    const { cutType, isRetail } = this.props;

    if (isRetail) {
      return <FormLabel label='' value='RETAIL' width={3} />;
    }

    if (cutType === BANQUET) {
      return <FormLabel label='' value='BANQUET' width={3} />;
    }

    return null;
  }

  render() {
    return (
      <Form.Group>
        {this.renderCasesRemaining()}
        {this.renderFirstPiecesColumn()}
        {this.renderSecondPiecesColumn()}
        {this.renderOrderType()}
      </Form.Group>
    );
  }
}

CasesAndPiecesOrderHeader.propTypes = {
  isRetail: PropTypes.bool.isRequired,
  packedBoxes: PropTypes.array.isRequired,
  unitOfMeasure: PropTypes.oneOf(['CASE', 'PIECE']).isRequired,
  qtyToProduce: PropTypes.number.isRequired,
  qtyInBoxes: PropTypes.number.isRequired,
  qtyInPieces: PropTypes.number.isRequired,
  piecesPerCase: PropTypes.number.isRequired,
  cutType: PropTypes.oneOf([BANQUET, STANDARD]).isRequired,
  qtyPacked: PropTypes.number.isRequired
};

export default CasesAndPiecesOrderHeader;
