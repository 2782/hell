import _ from 'lodash';
import { SubmissionError } from 'redux-form';
import {
  exactLength,
  isGreaterThanEqual,
  isLessThanEqual,
  number,
  positiveNumber,
  productWithWeight,
  required,
  validate,
  wholeNumber
} from '../../shared/formValidations';
import { toPrecision } from '../../shared/util/floatUtil';
import { PACK_OFF_WIP } from './packType';

const hasNoErrorForWeightAndPackagingTare = errors => {
  return !_.has(errors, 'weight') && !_.has(errors, 'packagingTare');
};

const validateSubmission = (
  values,
  {
    packType,
    minWeight,
    maxWeight,
    category,
    showOverrideWeightRangeRequest,
    retailSpecific,
    productOutput
  }
) => {
  const { productCode, weight, packagingTare, overrideWeightRangeReasonCode } = values;
  let errors = {};

  const validations = [
    required,
    wholeNumber,
    exactLength(7),
    validateRetailProduct(retailSpecific, packType)
  ];

  productOutput === 'FINISHED' && validations.push(productWithWeight(maxWeight, minWeight));

  errors = validate(errors, productCode, 'productCode', validations);
  errors = validate(errors, weight, 'weight', [required, number]);
  errors = validate(errors, packagingTare, 'packagingTare', [required, number]);
  const netWeight = toPrecision(
    Number.parseFloat(weight) - Number.parseFloat(packagingTare),
    2
  ).toString();

  if (hasNoErrorForWeightAndPackagingTare(errors)) {
    errors = validate(
      errors,
      netWeight,
      'weight',
      [positiveNumber],
      'Weight should be greater than Packaging Tare'
    );
  }

  if (packType !== PACK_OFF_WIP && hasNoErrorForWeightAndPackagingTare(errors)) {
    if (overrideWeightRangeReasonCode === '') {
      if (category === 'CATCH') {
        errors = validate(errors, netWeight, 'weight', [
          isLessThanEqual(
            maxWeight,
            `Outside of range - weight range is ${minWeight} - ${maxWeight}. ` +
              'Enter reason code and press enter to pack off.'
          ),
          isGreaterThanEqual(
            minWeight,
            `Outside of range - weight range is ${minWeight} - ${maxWeight}. ` +
              'Enter reason code and press enter to pack off.'
          )
        ]);
      }

      if (category === 'FIXED') {
        errors = validate(errors, netWeight, 'weight', [
          isGreaterThanEqual(
            minWeight,
            `Less than fixed weight - ${minWeight}. ` +
              'Enter reason code and press enter to pack off.'
          )
        ]);
      }

      if (_.has(errors, 'weight')) {
        showOverrideWeightRangeRequest();
      }
    }
  }

  return errors;
};

const processErrorResponse = errorResponse => {
  const errorDetails = _.get(errorResponse, 'error.details', []);

  const errorDetailInfo = errorDetails.find(detail => !_.isEmpty(detail.field) === true);
  const issue = errorDetailInfo ? errorDetailInfo.issue : '';

  let errors = {};

  switch (issue) {
    case 'PRODUCT_IS_NOT_PRODUCTION_ITEM':
      errors = { productCode: 'Must be a production item.', ...errors };
      break;
    case 'USER_NOT_ASSIGNED_TO_PACKOFF_STATION_IN_CURRENT_ROOM':
      errors = { productCode: 'User ID not assigned to portion room' };
      break;
    case 'USER_NOT_ASSIGNED_TO_PACKOFF_STATION':
      errors = { productCode: 'User ID not assigned to portion room' };
      break;
    default:
      errors = { _error: 'Submission Failed!', ...errors };
      break;
  }

  if (!_.isEmpty(errors)) {
    throw new SubmissionError({ ...errors, _error: 'Submission Failed!' });
  }
};

const validateRetailProduct = (retailSpecific, packType) => (value, fieldName) => {
  if (!_.isEmpty(retailSpecific) && packType !== PACK_OFF_WIP) {
    return {
      [fieldName]: 'Retail items cannot be packed as stock.'
    };
  }
};

export default {
  validateSubmission,
  processErrorResponse
};
