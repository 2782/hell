import React, { Component, Fragment } from 'react';
import PropTypes from 'prop-types';
import { Button, Table } from 'semantic-ui-react';
import { toPrecision } from '../../shared/util/floatUtil';
import { PACK_OFF_NORMAL, PACK_OFF_RETAIL, PACK_OFF_STOCK, PACK_OFF_WIP } from './packType';
import { formatNumberToTwoDecimalPlacesString } from '../../shared/util/dataUtil';
import _ from 'lodash';
import { reprintLabelsForCurrentUser } from '../../reprint/actions/reprintActions';

export class PackBoxTableComponent extends Component {
  render() {
    const { packedBoxes, variant } = this.props;
    const isForPackWip = variant === PACK_OFF_WIP;
    const isRetail = variant === PACK_OFF_RETAIL;
    const totalBoxesPacked = packedBoxes.length;

    return (
      <Table id='pack-box-table' celled structured columns={4} fixed>
        <Table.Header>
          <Table.Row>
            <Table.HeaderCell>{isForPackWip ? 'Product #' : 'Box'}</Table.HeaderCell>
            {isRetail && <Table.HeaderCell>Tare</Table.HeaderCell>}
            {isRetail && <Table.HeaderCell>Net Weight</Table.HeaderCell>}
            {isRetail && <Table.HeaderCell>Retail Label</Table.HeaderCell>}
            <Table.HeaderCell>Weight</Table.HeaderCell>
            <Table.HeaderCell>{isRetail ? 'Retail' : 'Packaging'} Tare</Table.HeaderCell>
            <Table.HeaderCell>Net Weight</Table.HeaderCell>
            {isForPackWip ? null : <Table.HeaderCell>Reason Code</Table.HeaderCell>}
            <Table.HeaderCell />
          </Table.Row>
        </Table.Header>
        <Table.Body>
          {_.orderBy(packedBoxes, ['id'], ['desc']).map((box, boxIndex) => {
            const currentBoxNumber = totalBoxesPacked - boxIndex;
            const totalWeighings = box.weighings.length;

            const productCode = box.productCode ? box.productCode : 'No Product Code';

            return _.orderBy(box.weighings, ['id'], ['desc']).map((weighing, weighingIndex) => {
              const rawNetWeight = isRetail
                ? weighing.weight - weighing.retailPieceTare
                : weighing.weight - box.packagingTare;

              const netWeight = formatNumberToTwoDecimalPlacesString(toPrecision(rawNetWeight, 2));
              const currentWeighingNumber = totalWeighings - weighingIndex;

              return (
                <Table.Row key={`${box.id}-${weighing.id}`}>
                  {weighingIndex === 0 ? (
                    <Fragment>
                      <Table.Cell rowSpan={totalWeighings}>
                        {isForPackWip ? productCode : currentBoxNumber}
                      </Table.Cell>
                      {isRetail ? (
                        <Fragment>
                          <Table.Cell rowSpan={totalWeighings}>
                            {box.isFullBox && box.packagingTare}
                          </Table.Cell>
                          <Table.Cell rowSpan={totalWeighings}>
                            {box.isFullBox && box.netWeight}
                          </Table.Cell>
                        </Fragment>
                      ) : null}
                    </Fragment>
                  ) : null}
                  {isRetail && <Table.Cell>{currentWeighingNumber}</Table.Cell>}
                  <Table.Cell>{formatNumberToTwoDecimalPlacesString(weighing.weight)}</Table.Cell>
                  <Table.Cell>
                    {isRetail
                      ? formatNumberToTwoDecimalPlacesString(weighing.retailPieceTare)
                      : formatNumberToTwoDecimalPlacesString(box.packagingTare)}
                  </Table.Cell>
                  <Table.Cell>{netWeight}</Table.Cell>
                  {isForPackWip ? null : (
                    <Table.Cell>{weighing.overrideWeightRangeReasonCode}</Table.Cell>
                  )}
                  <Table.Cell className='center aligned'>
                    <Button
                      size='tiny'
                      primary
                      onClick={() =>
                        reprintLabelsForCurrentUser(weighing.id, isForPackWip ? 'BOX' : 'BOTH')
                      }
                      pid={`pack-box-table__reprint-${weighing.id}`}
                    >
                      REPRINT
                    </Button>
                  </Table.Cell>
                </Table.Row>
              );
            });
          })}
        </Table.Body>
      </Table>
    );
  }
}

PackBoxTableComponent.propTypes = {
  packedBoxes: PropTypes.arrayOf(
    PropTypes.shape({
      id: PropTypes.number.isRequired,
      weight: PropTypes.number,
      packagingTare: PropTypes.number,
      isFullBox: PropTypes.bool,
      weighings: PropTypes.arrayOf(
        PropTypes.shape({
          id: PropTypes.number,
          weight: PropTypes.number,
          retailPieceTare: PropTypes.number,
          overrideWeightRangeReasonCode: PropTypes.number,
          type: PropTypes.oneOf(['BOX', 'RETAIL_PIECE'])
        })
      )
    })
  ),
  variant: PropTypes.oneOf([PACK_OFF_WIP, PACK_OFF_STOCK, PACK_OFF_RETAIL, PACK_OFF_NORMAL])
    .isRequired,
  piecesPerCase: PropTypes.number
};

const PackBoxTable = PackBoxTableComponent;

export default PackBoxTable;
