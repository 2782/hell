import React from 'react';
import PropTypes from 'prop-types';
import { Table } from 'semantic-ui-react';
import EmptyListMessage from '../../shared/components/EmptyListMessage';
import FutureGrindOrdersTableContent from './FutureGrindOrdersTableContent';
import { isActionable } from '../pages/ScheduleFutureCutOrders';

const ScheduleFutureGrindOrdersTable = ({
  futureOrders,
  grindHousePars,
  inputFocus,
  stockAllocationAlert,
  updateTotalPounds = () => {}
}) => {
  return !isActionable(futureOrders) ? (
    <EmptyListMessage />
  ) : (
    <div pid='future-grind-order-table'>
      <Table columns={16} size={'small'} fixed selectable>
        <Table.Header>
          <Table.Row>
            <Table.HeaderCell colSpan={4} width={4}>
              Product
            </Table.HeaderCell>
            <Table.HeaderCell colSpan={4} width={4}>
              Customer
            </Table.HeaderCell>
            <Table.HeaderCell colSpan={2} width={2} textAlign={'right'}>
              Ship Date
            </Table.HeaderCell>
            <Table.HeaderCell colSpan={2} width={2} textAlign={'right'}>
              Quantity Remaining
            </Table.HeaderCell>
            <Table.HeaderCell colSpan={2} width={2} className={'schedule-today'}>
              Grind Today
            </Table.HeaderCell>
          </Table.Row>
        </Table.Header>
        <FutureGrindOrdersTableContent
          stockAllocationAlert={stockAllocationAlert}
          futureOrders={futureOrders}
          grindHousePars={grindHousePars}
          inputFocus={inputFocus}
          updateTotalPounds={updateTotalPounds}
        />
      </Table>
    </div>
  );
};

ScheduleFutureGrindOrdersTable.propTypes = {
  futureOrders: PropTypes.array,
  grindHousePars: PropTypes.array,
  inputFocus: PropTypes.func,
  updateTotalPounds: PropTypes.func,
  stockAllocationAlert: PropTypes.bool
};

export default ScheduleFutureGrindOrdersTable;
