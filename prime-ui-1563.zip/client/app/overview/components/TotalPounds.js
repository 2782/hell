import React from 'react';
import PropTypes from 'prop-types';
import _ from 'lodash';
import { HOUSE_PAR, LINE_ITEM } from '../../../config/orderSource';

export const TotalPounds = ({
  futureOrders,
  grindOrders,
  grindHousePars,
  userProjectedQuantitiesRemaining
}) => {
  const formattedTotalPounds = calculateTotalPounds(
    futureOrders,
    grindOrders,
    grindHousePars,
    userProjectedQuantitiesRemaining
  ).toLocaleString('en');

  return (
    <div className='total-planned-pounds-wrapper' pid='scheduledFutureOrders__totalPounds'>
      <div className='total-planned-pounds'>
        <strong>Total Planned Pounds: {formattedTotalPounds}</strong>
      </div>
    </div>
  );
};
TotalPounds.propTypes = {
  isApprovedForDay: PropTypes.bool,
  futureOrders: PropTypes.array,
  grindHousePars: PropTypes.array,
  userProjectedQuantitiesRemaining: PropTypes.array,
  grindOrders: PropTypes.array
};

export const calculateTotalPounds = (
  futureOrders,
  grindOrders,
  grindHousePars,
  userProjectedQuantitiesRemaining
) => {
  if (_.isEmpty(futureOrders) && _.isEmpty(grindOrders) && _.isEmpty(grindHousePars)) {
    return 0;
  }
  let totalWeight = 0;
  totalWeight += calculateTotalPoundsForUserInput(
    futureOrders,
    grindHousePars,
    userProjectedQuantitiesRemaining
  );
  totalWeight += calculateTotalPoundsForScheduledOrders(grindOrders);

  return Math.ceil(totalWeight);
};

const calculateTotalPoundsForUserInput = (
  futureOrders,
  grindHousePars,
  userProjectedQuantitiesRemaining
) => {
  let totalWeight = 0;
  futureOrders.forEach(order => {
    let weightPerBox = order.product.weightPerBox;
    let userInput = getUserInput(order.itemId, userProjectedQuantitiesRemaining, LINE_ITEM);

    totalWeight += userInput * weightPerBox;
  });

  grindHousePars.forEach(par => {
    let weightPerBox = par.product.weightPerBox;
    let userInput = getUserInput(par.id, userProjectedQuantitiesRemaining, HOUSE_PAR);

    totalWeight += userInput * weightPerBox;
  });
  return totalWeight;
};

const getUserInput = (itemId, userProjectedQuantitiesRemaining, type) => {
  const match = userProjectedQuantitiesRemaining.find(
    userEntry => userEntry.itemId === itemId && userEntry.type === type
  );
  return match ? parseInt(match.orderQuantityRemaining) : 0;
};

export const calculateTotalPoundsForScheduledOrders = allGrindOrders => {
  if (_.isEmpty(allGrindOrders)) {
    return 0;
  }

  return allGrindOrders.reduce((acc, grindOrder) => {
    if (grindOrder.status === 'TO_APPROVE') {
      return acc + grindOrder.qtyInBoxes * grindOrder.product.weightPerBox;
    }
    return acc;
  }, 0);
};
