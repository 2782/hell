import React from 'react';
import PropTypes from 'prop-types';
import { Table } from 'semantic-ui-react';
import _ from 'lodash';
import EmptyListMessage from '../../shared/components/EmptyListMessage';
import FutureCutOrdersContent from './FutureCutOrdersTableContent';
import { isActionable } from '../pages/ScheduleFutureCutOrders';

const sortColumnField = {
  product: 'product.code',
  customer: 'customerOrder.customer.name',
  station: 'product.table.station.stationCode',
  table: 'product.table.tableCode',
  shipDate: 'customerOrder.shipDate',
  quantityRemaining: 'quantityRemaining'
};

const defaultSortConfig = [
  { columnKey: 'product.table.tableCode', direction: 'asc' },
  { columnKey: 'customerOrder.shipDate', direction: 'asc' },
  { columnKey: 'quantityRemaining', direction: 'desc' }
];

const convertForSemantic = {
  asc: 'ascending',
  desc: 'descending'
};

export const sort = (futureOrders, sortColumn, sortDirection) => {
  const sortConfig = sortColumn
    ? [{ columnKey: sortColumnField[sortColumn], direction: sortDirection }].concat(
        defaultSortConfig
      )
    : defaultSortConfig;

  return _(futureOrders)
    .filter(order => order.quantityRemaining > 0)
    .orderBy(
      _.map(sortConfig, config => config.columnKey),
      _.map(sortConfig, config => config.direction)
    )
    .value();
};

const ScheduleFutureCutOrdersTable = ({
  futureOrders,
  inputFocus = () => {},
  sortColumn,
  sortDirection,
  handleSort
}) => {
  const sortedFutureOrders = sort(futureOrders, sortColumn, sortDirection);

  return !isActionable(futureOrders) ? (
    <EmptyListMessage />
  ) : (
    <div pid='future-cut-order-table'>
      <Table stackable sortable selectable columns={16}>
        <Table.Header>
          <Table.Row>
            <Table.HeaderCell
              collapsing
              sorted={sortColumn === 'product' ? convertForSemantic[sortDirection] : null}
              onClick={() => handleSort('product')}
            >
              Product
            </Table.HeaderCell>
            <Table.HeaderCell
              collapsing
              sorted={sortColumn === 'customer' ? convertForSemantic[sortDirection] : null}
              onClick={() => handleSort('customer')}
            >
              Customer
            </Table.HeaderCell>
            <Table.HeaderCell
              collapsing
              sorted={sortColumn === 'station' ? convertForSemantic[sortDirection] : null}
              onClick={() => handleSort('station')}
              textAlign={'right'}
            >
              Station
            </Table.HeaderCell>
            <Table.HeaderCell
              collapsing
              sorted={sortColumn === 'table' ? convertForSemantic[sortDirection] : null}
              onClick={() => handleSort('table')}
              textAlign={'right'}
            >
              Table
            </Table.HeaderCell>
            <Table.HeaderCell
              collapsing
              sorted={sortColumn === 'shipDate' ? convertForSemantic[sortDirection] : null}
              onClick={() => handleSort('shipDate')}
              textAlign={'right'}
            >
              Ship Date
            </Table.HeaderCell>
            <Table.HeaderCell
              collapsing
              sorted={sortColumn === 'quantityRemaining' ? convertForSemantic[sortDirection] : null}
              onClick={() => handleSort('quantityRemaining')}
              textAlign={'right'}
            >
              Quantity Remaining
            </Table.HeaderCell>
            <Table.HeaderCell collapsing className={'schedule-today'}>
              To Cut Today
            </Table.HeaderCell>
          </Table.Row>
        </Table.Header>
        <FutureCutOrdersContent futureOrders={sortedFutureOrders} inputFocus={inputFocus} />
      </Table>
    </div>
  );
};

ScheduleFutureCutOrdersTable.propTypes = {
  futureOrders: PropTypes.array, // 'null' when first loaded, so cannot be "isRequired"
  inputFocus: PropTypes.func.isRequired,
  sortColumn: PropTypes.string,
  sortDirection: PropTypes.string,
  handleSort: PropTypes.func.isRequired
};

export default ScheduleFutureCutOrdersTable;
