import { mount } from 'enzyme';
import React from 'react';
import ScheduleFutureGrindOrdersTable from '../ScheduleFutureGrindOrdersTable';
import semanticUI from '../../../../test-helpers/semantic-ui';
import { futureLineItems } from '../../../../test-factories/lineItemFactory';
import { Field, reduxForm } from 'redux-form';
import store from '../../../store';
import { Provider } from 'react-redux';
import GrindingHouseParFactory from '../../../../test-factories/grindingHousePar';

const grindHousePars = [GrindingHouseParFactory.build()];

describe('scheduleFutureGrindOrdersTable', () => {
  let wrapper, Decorated;
  let updateTotalPounds = jest.fn();

  beforeEach(() => {
    Decorated = reduxForm({ form: 'testForm' })(ScheduleFutureGrindOrdersTable);

    wrapper = mount(
      <Provider store={store}>
        <Decorated
          grindHousePars={grindHousePars}
          futureOrders={futureLineItems}
          stockAllocationAlert={false}
          updateTotalPounds={updateTotalPounds}
        />
      </Provider>
    );
  });

  afterEach(() => {
    updateTotalPounds.mockReset();
  });

  test('should call updateTotalPounds when on blur for a field is called', () => {
    const firstField = wrapper.find(Field).at(0);

    firstField.simulate('blur');

    jestExpect(updateTotalPounds).toHaveBeenCalled();
  });

  test('should render correct table header for grinding future orders', () => {
    jestExpect(semanticUI.findTable(wrapper, 0).find('th')).toHaveLength(5);
  });

  test('should render correct row descendents for one grinding future orders', () => {
    const futureGrindItemTableRow = wrapper
      .find('tbody')
      .find('tr')
      .at(1);

    jestExpect(futureGrindItemTableRow.find('td')).toHaveLength(5);
  });
});
