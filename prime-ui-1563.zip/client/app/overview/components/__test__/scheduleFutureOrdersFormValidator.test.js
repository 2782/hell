import { validateSubmission } from '../scheduleFutureOrdersFormValidator';

describe('ScheduleFutureOrdersFormValidator', () => {
  test('should validate successfully and call submit on grinding validation', () => {
    const values = {
      '123-LINE_ITEM-toGrindToday': '4'
    };

    const futureOrders = [{ itemId: 123, quantity: 100 }];
    validateSubmission(values, {
      futureOrders
    });
  });

  [
    { scenario: 'alphanumeric', qty: 'abc' },
    { scenario: 'decimal', qty: '1.1' },
    { scenario: 'negative', qty: '-3' },
    { scenario: 'greateThanQuantity', qty: '100' }
  ].forEach(({ scenario, qty }) => {
    test(`should throw error when toGrindToday is ${scenario}`, () => {
      const values = {
        '123-LINE_ITEM-toGrindToday': qty
      };
      const futureOrders = [{ itemId: 123, quantity: 100, quantityRemaining: 10 }];
      try {
        validateSubmission(values, {
          futureOrders
        });
      } catch ({ errors }) {
        jestExpect(errors['123-LINE_ITEM-toGrindToday']).toEqual('Invalid Quantity');
        jestExpect(errors._error).toEqual('Submission Failed!');
      }
    });
  });

  test('should validate successfully and call submit on cutting validation', () => {
    const values = {
      '123-LINE_ITEM-toCutToday': '4'
    };

    const futureOrders = [{ itemId: 123, quantity: 100 }];
    validateSubmission(values, {
      futureOrders
    });
  });

  [
    { scenario: 'alphanumeric', qty: 'abc' },
    { scenario: 'decimal', qty: '1.1' },
    { scenario: 'negative', qty: '-3' },
    { scenario: 'greateThanQuantity', qty: '100' }
  ].forEach(({ scenario, qty }) => {
    test(`should throw error when toCutToday is ${scenario}`, () => {
      const values = {
        '123-LINE_ITEM-toCutToday': qty
      };
      const futureOrders = [{ itemId: 123, quantity: 100, quantityRemaining: 10 }];
      try {
        validateSubmission(values, {
          futureOrders
        });
      } catch ({ errors }) {
        jestExpect(errors['123-LINE_ITEM-toCutToday']).toEqual('Invalid Quantity');
        jestExpect(errors._error).toEqual('Submission Failed!');
      }
    });
  });

  test('should validate grind house par successfully', () => {
    const values = {
      '123-HOUSE_PAR-toCutToday': '4'
    };

    const grindHousePar = [{ itemId: 123, quantity: 100 }];
    validateSubmission(values, {
      grindHousePar
    });
  });

  [
    { scenario: 'alphanumeric', qty: 'abc' },
    { scenario: 'decimal', qty: '1.1' },
    { scenario: 'negative', qty: '-3' },
    { scenario: 'greateThanQuantity', qty: '100' }
  ].forEach(({ scenario, qty }) => {
    test(`should throw error when toGrindToday is ${scenario}`, () => {
      const values = {
        '123-HOUSE_PAR-toCutToday': qty
      };
      const futureOrders = [{ itemId: 123, quantity: 10 }];
      try {
        validateSubmission(values, {
          futureOrders
        });
      } catch ({ errors }) {
        jestExpect(errors['123-HOUSE_PAR-toCutToday']).toEqual('Invalid Quantity');
        jestExpect(errors._error).toEqual('Submission Failed!');
      }
    });
  });
});
