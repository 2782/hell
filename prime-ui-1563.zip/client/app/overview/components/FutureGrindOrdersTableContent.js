import React from 'react';
import { Form } from 'semantic-ui-react';
import { Table } from 'semantic-ui-react';
import _ from 'lodash';
import DotDotDot from 'react-dotdotdot';
import { Field } from 'redux-form';
import FormElement from '../../shared/FormElement';
import { formatDate } from '../../shared/util/dateUtil';
import { HOUSE_PAR, LINE_ITEM } from '../../../config/orderSource';

const groupByTableCode = items => {
  return _.groupBy(items, item => item.tableCode);
};

const onlyOrdersInProgress = items => {
  return _.filter(items, item => item.quantityRemaining > 0);
};

const mapFutureOrdersToGrindingItems = futureOrders => {
  return _.map(futureOrders, order => {
    return {
      itemId: order.itemId,
      tableCode: _.get(order, 'product.table.tableCode', ''),
      quantityRemaining: order.quantityRemaining,
      tableDescription: _.get(order, 'product.table.tableDescription', ''),
      shipDate: formatDate(_.get(order, 'customerOrder.shipDate', '')),
      productCode: _.get(order, 'product.code', ''),
      productDescription: _.get(order, 'product.description', ''),
      quantity: order.quantity,
      portionSize: _.get(order, 'product.productPortionSize.portionSize'),
      customerName: _.get(order, 'customerOrder.customer.name', ''),
      customerCode: _.get(order, 'customerCode', ''),
      cost: _.get(order, 'product.cost', ''),
      type: LINE_ITEM
    };
  });
};

const mapGrindingHouseParToGrindingItems = grindHousePars => {
  return _.map(grindHousePars, par => {
    return {
      itemId: par.id,
      tableCode: _.get(par, 'product.table.tableCode', ''),
      quantityRemaining: par.quantity,
      cost: _.get(par, 'product.cost', ''),
      tableDescription: _.get(par, 'product.table.tableDescription', ''),
      shipDate: formatDate(_.get(par, 'deliveryDate', '')),
      productCode: _.get(par, 'product.code', ''),
      productDescription: _.get(par, 'product.description', ''),
      quantity: par.quantity,
      portionSize: _.get(par, 'product.productPortionSize.portionSize'),
      customerName: _.get(par, 'customerOrder.customer.name', ''),
      customerCode: _.get(par, 'customerOrder.customer.customerCode', ''),
      type: HOUSE_PAR
    };
  });
};

const FutureGrindOrdersTableContent = ({
  futureOrders,
  grindHousePars,
  inputFocus,
  updateTotalPounds,
  stockAllocationAlert
}) => {
  const grindingFutureItems = _.concat(
    mapFutureOrdersToGrindingItems(futureOrders),
    mapGrindingHouseParToGrindingItems(grindHousePars)
  );

  const ordersByTableCode = _.orderBy(onlyOrdersInProgress(grindingFutureItems), [
    'product.table.tableCode'
  ]);

  return _.map(groupByTableCode(ordersByTableCode), (value, key) => (
    <Table.Body key={`future-orders-content-${key}`}>
      <Table.Row pid={`future-grind-order-table__table-section-${key}`}>
        <Table.Cell colSpan={1} active>
          {key}
        </Table.Cell>
        <Table.Cell colSpan={13}>{value[0].tableDescription}</Table.Cell>
      </Table.Row>
      {_.map(
        _.orderBy(value, ['shipDate', 'productCode', 'quantity'], ['asc', 'desc', 'desc']),
        (item, index) => {
          const portionSize = item.portionSize;
          const productInfo = `${item.productCode} / ${portionSize}`;
          const customerName = item.customerName;
          const customerCode = item.customerCode;

          const isFirstTableSection = _.get(ordersByTableCode[0], 'tableCode').toString() === key;
          const isFirstToProduceTodayField = isFirstTableSection && index === 0;

          return (
            <Table.Row
              pid={`future-grind-order-table__table-section-row-${index}`}
              key={`future-orders-content-${key}-${index}`}
            >
              <Table.Cell colSpan={4}>
                <div>{productInfo}</div>
                <span>{item.productDescription}</span>
              </Table.Cell>
              <Table.Cell colSpan={4} title={customerName}>
                <DotDotDot clamp={1} title={customerName}>
                  {customerName}
                </DotDotDot>
                <div>{customerCode}</div>
              </Table.Cell>
              <Table.Cell colSpan={2} textAlign={'right'}>
                {item.shipDate}
              </Table.Cell>
              <Table.Cell colSpan={2} textAlign={'right'}>
                {item.quantityRemaining}
              </Table.Cell>
              <Table.Cell colSpan={2} className={'schedule-today'}>
                <Field
                  width={10}
                  component={FormElement}
                  onBlur={updateTotalPounds(item)}
                  autoFocus={!stockAllocationAlert && isFirstToProduceTodayField}
                  withRef
                  ref={isFirstToProduceTodayField ? inputFocus : null}
                  name={`${item.itemId}-${item.type}-toGrindToday`}
                  as={Form.Input}
                  error={!item.cost}
                  disabled={!item.cost}
                />
              </Table.Cell>
            </Table.Row>
          );
        }
      )}
    </Table.Body>
  ));
};

export default FutureGrindOrdersTableContent;
