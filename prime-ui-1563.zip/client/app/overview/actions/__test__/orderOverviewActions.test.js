import {
  getTestStateForGrindingRoom,
  getTestStateForRoomA
} from '../../../../test-factories/testState';
import {
  FUTURE_ORDERS_REVIEW,
  HOUSE_PAR_AND_LINE_ITEMS_DELETED,
  ON_HOLD_ORDERS_CLEAR,
  ON_HOLD_ORDERS_DISPLAY,
  ORDERS_REVIEW,
  RESET_STATE,
  SORT_BY_COLUMN,
  STATIONS
} from '../orderOverviewActionTypes';
import {
  clear,
  clearOnHoldOrdersQuantity,
  clearUserProjectedQuantitiesRemaining,
  generateGrindingOrdersFromHousePar,
  getFutureLineItems,
  getOverviewOfOrders,
  getStations,
  handleSort,
  remainHoldOrdersQuantity,
  scheduleFutureOrdersToProduceToday,
  scheduleGrindOrdersToProduceToday
} from '../orderOverviewActions';
import cutStationResources from '../../../shared/api/stationResources';
import cutOrdersResources from '../../../shared/api/cutOrdersResources';
import { customerInfos, cutOrder1, cutOrder2 } from '../../../shared/testData/cutOrdersForTesting';
import lineItemsResources from '../../../shared/api/lineItemsResources';
import grindOrdersResources from '../../../shared/api/grindOrdersResources';
import LineItemFactory from '../../../../test-factories/lineItemFactory';
import CustomerOrderFactory from '../../../../test-factories/customerOrder';
import GrindingHouseParFactory from '../../../../test-factories/grindingHousePar';

jest.mock('../../../shared/api/cutOrdersResources');
jest.mock('../../../shared/api/lineItemsResources');
jest.mock('../../../shared/api/stationResources');
jest.mock('../../../shared/api/lineItemsResources');
jest.mock('../../../shared/api/grindOrdersResources');

const cutOrdersResponse = {
  data: [cutOrder1, cutOrder2]
};

const lineItemResponse = {
  data: [
    LineItemFactory.build({
      customerOrder: CustomerOrderFactory.build({ customerCode: customerInfos[0].customerCode })
    }),
    LineItemFactory.build({
      customerOrder: CustomerOrderFactory.build({ customerCode: customerInfos[1].customerCode })
    })
  ]
};
const STATION_ID = 123;

describe('orderOverviewActions', () => {
  let dispatch;
  let successCallback;

  beforeEach(() => {
    dispatch = jest.fn();
    successCallback = jest.fn();
  });

  test('get overview of cut dispatches orders to review', () => {
    cutOrdersResources.getOverviewOfOrders.mockImplementation((arg1, arg2, arg3, callback) =>
      callback(cutOrdersResponse)
    );
    getOverviewOfOrders('Completed', STATION_ID)(dispatch, getTestStateForRoomA);

    jestExpect(dispatch).toHaveBeenCalledWith({
      type: ORDERS_REVIEW,
      payload: cutOrdersResponse.data
    });
  });

  test('dispatches stations', async () => {
    const stations = [
      { id: 123, name: 'SALLY', room: 'roomA', portionRoomTables: [], stationCode: 12 }
    ];
    cutStationResources.getStationsByRoom.mockResolvedValue({ data: stations });

    await getStations()(dispatch, getTestStateForRoomA);
    jestExpect(dispatch).toHaveBeenNthCalledWith(1, {
      type: STATIONS,
      payload: stations
    });
  });

  test('sort columns when column is not yet selected', () => {
    handleSort('COLUMN_A')(dispatch, () => ({
      cutOrderOverview: { sortColumn: null, sortDirection: null }
    }));

    jestExpect(dispatch).toHaveBeenNthCalledWith(1, {
      type: SORT_BY_COLUMN,
      payload: {
        sortColumn: 'COLUMN_A',
        sortDirection: 'asc'
      }
    });
  });

  test('when column is already selected and same column is selected from ascending to descending', () => {
    handleSort('COLUMN_B')(dispatch, () => ({
      cutOrderOverview: { sortColumn: 'COLUMN_B', sortDirection: 'asc' }
    }));

    jestExpect(dispatch).toHaveBeenNthCalledWith(1, {
      type: SORT_BY_COLUMN,
      payload: {
        sortColumn: 'COLUMN_B',
        sortDirection: 'desc'
      }
    });
  });

  test('when column is already selected and same column is selected from descending to ascending', () => {
    handleSort('COLUMN_B')(dispatch, () => ({
      cutOrderOverview: { sortColumn: 'COLUMN_B', sortDirection: 'desc' }
    }));

    jestExpect(dispatch).toHaveBeenNthCalledWith(1, {
      type: SORT_BY_COLUMN,
      payload: {
        sortColumn: 'COLUMN_B',
        sortDirection: 'asc'
      }
    });
  });

  test('when column is already selected and new column is selected', () => {
    handleSort('COLUMN_C')(dispatch, () => ({
      cutOrderOverview: { sortColumn: 'COLUMN_D', sortDirection: 'desc' }
    }));

    jestExpect(dispatch).toHaveBeenNthCalledWith(1, {
      type: SORT_BY_COLUMN,
      payload: {
        sortColumn: 'COLUMN_C',
        sortDirection: 'asc'
      }
    });
  });

  test('clear info', () => {
    clear()(dispatch);
    jestExpect(dispatch).toHaveBeenNthCalledWith(1, { type: RESET_STATE });
  });

  test('get future line items for cutting and grinding room', () => {
    lineItemsResources.getFutureLineItems.mockImplementation((arg, callback) =>
      callback(lineItemResponse)
    );

    getFutureLineItems(successCallback)(dispatch, getTestStateForRoomA);

    jestExpect(dispatch).toHaveBeenNthCalledWith(1, {
      type: FUTURE_ORDERS_REVIEW,
      payload: lineItemResponse.data
    });

    jestExpect(dispatch).toHaveBeenCalledTimes(1);
    jestExpect(successCallback).toHaveBeenCalledWith(lineItemResponse.data);
  });

  test('clear user projected quantities remaining', () => {
    clearUserProjectedQuantitiesRemaining()(dispatch);
    jestExpect(dispatch).toHaveBeenNthCalledWith(1, {
      type: HOUSE_PAR_AND_LINE_ITEMS_DELETED
    });
  });

  test('schedule future orders to cut today', () => {
    lineItemsResources.scheduleFutureOrdersToProduceToday.mockImplementation((arg, callback) =>
      callback({})
    );

    scheduleFutureOrdersToProduceToday([{ itemId: 100, toCutToday: '2' }], successCallback)();

    jestExpect(lineItemsResources.scheduleFutureOrdersToProduceToday).toHaveBeenCalledWith(
      [
        {
          itemId: 100,
          toCutToday: '2'
        }
      ],
      successCallback
    );
  });

  test('schedule grind order to produce today', () => {
    const scheduledMap = { 1: 23, 4: 56 };
    scheduleGrindOrdersToProduceToday(scheduledMap, successCallback)(dispatch);

    jestExpect(grindOrdersResources.scheduleGrindOrdersToProduceToday).toHaveBeenCalledWith(
      scheduledMap,
      successCallback
    );
  });

  test('generate grinding orders form house par', () => {
    grindOrdersResources.generateGrindingOrdersFromHousePar.mockImplementation(
      (arg1, arg2, callback) => callback({})
    );

    const housePars = [GrindingHouseParFactory.build()];
    generateGrindingOrdersFromHousePar(housePars, successCallback)(
      dispatch,
      getTestStateForGrindingRoom
    );

    jestExpect(grindOrdersResources.generateGrindingOrdersFromHousePar).toHaveBeenCalledWith(
      housePars,
      'D',
      successCallback
    );
  });

  test('remain onhold orders', () => {
    const onHoldOrders = { '101': '1', '102': '2' };
    remainHoldOrdersQuantity(onHoldOrders)(dispatch);

    jestExpect(dispatch).toHaveBeenNthCalledWith(1, {
      type: ON_HOLD_ORDERS_DISPLAY,
      payload: onHoldOrders
    });
  });

  test('clear remaining onhold orders', () => {
    clearOnHoldOrdersQuantity()(dispatch);

    jestExpect(dispatch).toHaveBeenNthCalledWith(1, { type: ON_HOLD_ORDERS_CLEAR });
  });
});
