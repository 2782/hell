import cutOrdersResources from '../../shared/api/cutOrdersResources';
import {
  FUTURE_ORDERS_DISPLAY,
  FUTURE_ORDERS_REVIEW,
  HOUSE_PAR_AND_LINE_ITEMS_DELETED,
  ON_HOLD_ORDERS_CLEAR,
  ON_HOLD_ORDERS_DISPLAY,
  ORDERS_REVIEW,
  RESET_STATE,
  SORT_BY_COLUMN,
  STATIONS
} from './orderOverviewActionTypes';
import cutStationResources from '../../shared/api/stationResources';
import grindOrdersResources from '../../shared/api/grindOrdersResources';
import lineItemsResources from '../../shared/api/lineItemsResources';

export const getOverviewOfOrders = (orderStatus, stationId) => {
  return (dispatch, getState) => {
    const roomCode = getState().portionRoomsInfo.currentPortionRoom.code;
    return cutOrdersResources.getOverviewOfOrders(roomCode, orderStatus, stationId, response => {
      dispatch({
        type: ORDERS_REVIEW,
        payload: response.data
      });
    });
  };
};

export const getStations = () => (dispatch, getState) => {
  const roomCode = getState().portionRoomsInfo.currentPortionRoom.code;
  return cutStationResources.getStationsByRoom(roomCode).then(
    response => {
      dispatch({
        type: STATIONS,
        payload: response.data
      });
    },
    () => {}
  );
};

export const clear = () => {
  return dispatch => {
    return dispatch({
      type: RESET_STATE
    });
  };
};

export const handleSort = clickedColumn => (dispatch, getState) => {
  const { sortDirection, sortColumn } = getState().cutOrderOverview;

  if (clickedColumn !== sortColumn) {
    dispatch({
      type: SORT_BY_COLUMN,
      payload: {
        sortColumn: clickedColumn,
        sortDirection: 'asc'
      }
    });
  } else {
    dispatch({
      type: SORT_BY_COLUMN,
      payload: {
        sortColumn,
        sortDirection: sortDirection === 'asc' ? 'desc' : 'asc'
      }
    });
  }
};

export const getFutureLineItems = (successCallback = () => {}) => {
  return (dispatch, getState) => {
    const roomCode = getState().portionRoomsInfo.currentPortionRoom.code;
    return lineItemsResources.getFutureLineItems(roomCode, futureLineItemsResponse => {
      dispatch({
        type: FUTURE_ORDERS_REVIEW,
        payload: futureLineItemsResponse.data
      });
      successCallback(futureLineItemsResponse.data);
    });
  };
};

export const setUserProjectedQuantitiesRemaining = userProjectedQuantitiesRemaining => {
  return dispatch => {
    return dispatch({
      type: FUTURE_ORDERS_DISPLAY,
      payload: userProjectedQuantitiesRemaining
    });
  };
};

export const clearUserProjectedQuantitiesRemaining = () => dispatch => {
  return dispatch({
    type: HOUSE_PAR_AND_LINE_ITEMS_DELETED
  });
};

export const scheduleGrindOrdersToProduceToday = (values, successCallback) => () => {
  return grindOrdersResources.scheduleGrindOrdersToProduceToday(values, successCallback);
};

export const scheduleFutureOrdersToProduceToday = (values, successCallBack) => {
  return () => {
    return lineItemsResources.scheduleFutureOrdersToProduceToday(values, successCallBack);
  };
};

export const generateGrindingOrdersFromHousePar = (values, successCallBack) => {
  return (dispatch, getState) => {
    const roomCode = getState().portionRoomsInfo.currentPortionRoom.code;
    return grindOrdersResources.generateGrindingOrdersFromHousePar(
      values,
      roomCode,
      successCallBack
    );
  };
};

export const remainHoldOrdersQuantity = onHoldOrders => {
  return dispatch => {
    return dispatch({
      type: ON_HOLD_ORDERS_DISPLAY,
      payload: onHoldOrders
    });
  };
};

export const clearOnHoldOrdersQuantity = () => {
  return dispatch => {
    return dispatch({
      type: ON_HOLD_ORDERS_CLEAR
    });
  };
};
