import orderOverviewReducer, { initialState } from '../orderOverviewReducer';
import {
  FUTURE_ORDERS_DISPLAY,
  FUTURE_ORDERS_REVIEW,
  HOUSE_PAR_AND_LINE_ITEMS_DELETED,
  ON_HOLD_ORDERS_CLEAR,
  ON_HOLD_ORDERS_DISPLAY,
  ORDERS_REVIEW,
  RESET_STATE,
  SORT_BY_COLUMN,
  STATIONS
} from '../../actions/orderOverviewActionTypes';
import { cutOrder1, cutOrder2 } from '../../../shared/testData/cutOrdersForTesting';

const cutOrders = [cutOrder1, cutOrder2];
const stations = [
  { id: 124, name: 'CYWCTER', room: 'roomB', portionRoomTables: [], stationCode: 14 }
];

describe('orderOverviewReducer', () => {
  test('should initialize with the correct initial state', () => {
    jestExpect(orderOverviewReducer(undefined, { type: 'UNEXPECTED' })).toEqual(initialState);
  });

  test('given I receive some cut orders, the state should be updated', () => {
    jestExpect(
      orderOverviewReducer(initialState, {
        type: ORDERS_REVIEW,
        payload: cutOrders
      })
    ).toEqual({ ...initialState, cutOrders: cutOrders });
  });

  test('given I receive a new column sort, the state should be updated', () => {
    jestExpect(
      orderOverviewReducer(initialState, {
        type: SORT_BY_COLUMN,
        payload: {
          sortColumn: 'COLUMN_E',
          sortDirection: 'SORT_DIRECTION_FOR_COLUMN_E'
        }
      })
    ).toEqual({
      ...initialState,
      sortColumn: 'COLUMN_E',
      sortDirection: 'SORT_DIRECTION_FOR_COLUMN_E'
    });
  });

  test('given I receive some stations, the state should be updated', () => {
    jestExpect(
      orderOverviewReducer(initialState, {
        type: STATIONS,
        payload: stations
      })
    ).toEqual({ ...initialState, stations: stations });
  });

  test('given I reset the filter, the state should be updated', () => {
    jestExpect(
      orderOverviewReducer(initialState, {
        type: RESET_STATE
      })
    ).toEqual({ ...initialState });
  });

  test('given I receive some future cut orders, the state should be updated', () => {
    jestExpect(
      orderOverviewReducer(initialState, {
        type: FUTURE_ORDERS_REVIEW,
        payload: cutOrders
      })
    ).toEqual({ ...initialState, futureOrders: cutOrders });
  });

  test('given I receive onHold orders, the state should be updated', () => {
    const onHoldOrders = { '101': '1', '100': '2' };
    jestExpect(
      orderOverviewReducer(initialState, {
        type: ON_HOLD_ORDERS_DISPLAY,
        payload: onHoldOrders
      })
    ).toEqual({ ...initialState, onHoldOrders });
  });

  test('given I receive clear onhold orders, the state should be updated', () => {
    jestExpect(
      orderOverviewReducer(
        { ...initialState, onHoldOrders: { '101': '1', '100': '2' } },
        {
          type: ON_HOLD_ORDERS_CLEAR
        }
      )
    ).toEqual({ ...initialState, onHoldOrders: {} });
  });
});

describe('User projected quantities remaining', () => {
  test('should pass through incomplete projections', () => {
    const projection = {
      itemId: 123,
      orderQuantityRemaining: 1,
      quantityRemaining: 0
    };

    jestExpect(
      orderOverviewReducer(initialState, {
        type: FUTURE_ORDERS_DISPLAY,
        payload: [projection]
      })
    ).toEqual({ ...initialState, userProjectedQuantitiesRemaining: [projection] });
  });

  test('should drop completed projections', () => {
    const projection = {
      itemId: 123,
      orderQuantityRemaining: 0,
      quantityRemaining: 0
    };

    jestExpect(
      orderOverviewReducer(initialState, {
        type: FUTURE_ORDERS_DISPLAY,
        payload: [projection]
      })
    ).toEqual({ ...initialState, userProjectedQuantitiesRemaining: [] });
  });

  test('should clear user project quantities remaining', () => {
    const projection = {
      itemId: 123,
      orderQuantityRemaining: 0,
      quantityRemaining: 0
    };

    jestExpect(
      orderOverviewReducer(
        {
          ...initialState,
          userProjectedQuantitiesRemaining: [projection]
        },
        {
          type: HOUSE_PAR_AND_LINE_ITEMS_DELETED
        }
      )
    ).toEqual({ ...initialState, userProjectedQuantitiesRemaining: [] });
  });
});
