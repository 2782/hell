import {
  FUTURE_ORDERS_DISPLAY,
  FUTURE_ORDERS_REVIEW,
  HOUSE_PAR_AND_LINE_ITEMS_DELETED,
  ON_HOLD_ORDERS_CLEAR,
  ON_HOLD_ORDERS_DISPLAY,
  ORDERS_REVIEW,
  RESET_STATE,
  SORT_BY_COLUMN,
  STATIONS
} from '../actions/orderOverviewActionTypes';
import _ from 'lodash';

export const initialState = {
  cutOrders: null,
  stations: [],
  futureOrders: null,
  sortColumn: null,
  sortDirection: null,
  userProjectedQuantitiesRemaining: [],
  onHoldOrders: {}
};

export default (state = initialState, action) => {
  switch (action.type) {
    case ORDERS_REVIEW:
      return {
        ...state,
        cutOrders: action.payload
      };

    case RESET_STATE:
      return initialState;

    case SORT_BY_COLUMN:
      return {
        ...state,
        sortColumn: action.payload.sortColumn,
        sortDirection: action.payload.sortDirection
      };

    case STATIONS:
      return {
        ...state,
        stations: action.payload
      };

    case FUTURE_ORDERS_REVIEW:
      return {
        ...state,
        futureOrders: action.payload
      };

    case FUTURE_ORDERS_DISPLAY:
      return {
        ...state,
        userProjectedQuantitiesRemaining: _.filter(action.payload, item => {
          return item.orderQuantityRemaining > 0;
        })
      };
    case HOUSE_PAR_AND_LINE_ITEMS_DELETED:
      return {
        ...state,
        userProjectedQuantitiesRemaining: []
      };
    case ON_HOLD_ORDERS_DISPLAY:
      return {
        ...state,
        onHoldOrders: action.payload
      };
    case ON_HOLD_ORDERS_CLEAR:
      return {
        ...state,
        onHoldOrders: {}
      };
    default:
      return state;
  }
};
