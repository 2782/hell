import { Provider } from 'react-redux';
import React from 'react';
import { mount } from 'enzyme';
import OrdersOverview, { OrderReview as OrderReviewComponent } from '../OrderOverview';
import { createReduxStore } from '../../../store';
import { STATION_1, STATION_2 } from '../../../../test-factories/station';
import CutOrderFactory from '../../../../test-factories/cutOrder';
import semanticUI from '../../../../test-helpers/semantic-ui';
import cutOrdersResources from '../../../shared/api/cutOrdersResources';
import cutStationResources from '../../../shared/api/stationResources';
import CustomerFactory from '../../../../test-factories/customerFactory';
import CustomerOrderFactory from '../../../../test-factories/customerOrder';

jest.mock('../../../shared/components/Header');
jest.mock('../../../shared/errors/ErrorNotification');
jest.mock('../../../shared/api/cutOrdersResources');
jest.mock('../../../shared/api/stationResources');

describe('Orders Overview', () => {
  const customer1 = CustomerFactory.build({ name: 'CUSTOMER_1' });

  beforeEach(() => {
    jest.useFakeTimers();
  });

  describe('Subcutaneous Testing', () => {
    let store, form;

    beforeEach(async () => {
      cutOrdersResources.getOverviewOfOrders.mockImplementation((ar1, arg2, arg3, callback) =>
        callback({
          data: [
            CutOrderFactory.build({
              id: 12,
              customerOrder: CustomerOrderFactory.build({ customer: customer1 })
            }),
            CutOrderFactory.build({
              id: 25,
              customerOrder: CustomerOrderFactory.build({ customer: customer1 })
            })
          ]
        })
      );

      afterEach(() => {
        cutOrdersResources.getOverviewOfOrders.mockReset();
      });

      cutStationResources.getStationsByRoom.mockResolvedValue({
        data: [STATION_1, STATION_2]
      });

      store = createReduxStore({ portionRoomsInfo: { currentPortionRoom: { code: 'A' } } });

      form = mount(
        <Provider store={store}>
          <OrdersOverview />
        </Provider>
      );

      await waitForAsyncTasks(form);
    });

    test('should clear all station and cut order store data on unmount', () => {
      form.unmount();
      form.update();

      jestExpect(store.getState().cutOrderOverview.stations).toEqual([]);
      jestExpect(store.getState().cutOrderOverview.cutOrders).toEqual(null);
    });

    test('should show all stations and statuses as default filters for cut order overview', () => {
      jestExpect(cutStationResources.getStationsByRoom.mock.calls[0][0]).toEqual('A');
      jestExpect(cutOrdersResources.getOverviewOfOrders).toHaveBeenNthCalledWith(
        1,
        'A',
        'All',
        null,
        jestExpect.any(Function)
      );

      jestExpect(semanticUI.getSelectText(form, 'station')).toEqual('All');
      jestExpect(semanticUI.getSelectText(form, 'status')).toEqual('All');
    });

    test('should select station and status filters and make API calls to retrieve filtered orders', () => {
      jestExpect(cutOrdersResources.getOverviewOfOrders).toHaveBeenNthCalledWith(
        1,
        'A',
        'All',
        null,
        jestExpect.any(Function)
      );

      semanticUI.selectOption(form, 'station', 1);
      jestExpect(semanticUI.getSelectText(form, 'station')).toEqual('12 - ENRIQUE');
      jestExpect(cutOrdersResources.getOverviewOfOrders).toHaveBeenNthCalledWith(
        2,
        'A',
        'All',
        1,
        jestExpect.any(Function)
      );

      semanticUI.selectOption(form, 'status', 1);
      jestExpect(semanticUI.getSelectText(form, 'status')).toEqual('New');
      jestExpect(cutOrdersResources.getOverviewOfOrders).toHaveBeenNthCalledWith(
        3,
        'A',
        'New',
        1,
        jestExpect.any(Function)
      );

      semanticUI.selectOption(form, 'status', 3);
      jestExpect(semanticUI.getSelectText(form, 'status')).toEqual('Completed');
      jestExpect(cutOrdersResources.getOverviewOfOrders).toHaveBeenNthCalledWith(
        4,
        'A',
        'Completed',
        1,
        jestExpect.any(Function)
      );

      semanticUI.selectOption(form, 'station', 2);
      jestExpect(semanticUI.getSelectText(form, 'station')).toEqual('43 - PEDRO');
      jestExpect(cutOrdersResources.getOverviewOfOrders).toHaveBeenNthCalledWith(
        5,
        'A',
        'Completed',
        2,
        jestExpect.any(Function)
      );

      semanticUI.selectOption(form, 'status', 2);
      jestExpect(semanticUI.getSelectText(form, 'status')).toEqual('Selected to Cut');
      jestExpect(cutOrdersResources.getOverviewOfOrders).toHaveBeenNthCalledWith(
        6,
        'A',
        'SelectedToCut',
        2,
        jestExpect.any(Function)
      );

      semanticUI.selectOption(form, 'station', 0);
      jestExpect(semanticUI.getSelectText(form, 'station')).toEqual('All');
      jestExpect(cutOrdersResources.getOverviewOfOrders).toHaveBeenNthCalledWith(
        7,
        'A',
        'SelectedToCut',
        null,
        jestExpect.any(Function)
      );

      semanticUI.selectOption(form, 'status', 0);
      jestExpect(semanticUI.getSelectText(form, 'status')).toEqual('All');
      jestExpect(cutOrdersResources.getOverviewOfOrders).toHaveBeenNthCalledWith(
        8,
        'A',
        'All',
        null,
        jestExpect.any(Function)
      );
    });
  });

  describe('auto-refresh data', () => {
    let orderReviewComponent;
    let getOverviewOfOrders;

    beforeEach(() => {
      getOverviewOfOrders = jest.fn();

      orderReviewComponent = new OrderReviewComponent({
        setHeaderAndFooter: jest.fn(),
        getStations: jest.fn(),
        clear: jest.fn(),
        getOverviewOfOrders
      });
      orderReviewComponent.ref = { focus: jest.fn() };
    });

    afterEach(() => {
      jest.clearAllTimers();
    });

    test('should call setInterval when componentDidMount', () => {
      orderReviewComponent.componentDidMount();

      jestExpect(setInterval).toHaveBeenCalledTimes(1);
      jestExpect(getOverviewOfOrders).toHaveBeenCalledTimes(1);
    });

    test('should call clearInterval when componentWillUnmount', () => {
      orderReviewComponent.componentWillUnmount();

      jestExpect(clearInterval).toHaveBeenCalledTimes(1);
    });
  });
});
