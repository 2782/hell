import React from 'react';
import { mount, shallow } from 'enzyme';
import { Provider } from 'react-redux';
import { createReduxStore } from '../../../store';
import ScheduleFutureCutOrders, {
  ScheduleFutureCutOrdersComponent,
  SubmitButton
} from '../ScheduleFutureCutOrders';
import ScheduleFutureCutOrdersTable from '../../components/ScheduleFutureCutOrdersTable';
import lineItemsResources from '../../../shared/api/lineItemsResources';
import CustomerOrderFactory from '../../../../test-factories/customerOrder';
import CustomerFactory from '../../../../test-factories/customerFactory';
import LineItemFactory from '../../../../test-factories/lineItemFactory';
import semanticUI from '../../../../test-helpers/semantic-ui';
import { Button } from 'semantic-ui-react';
import EmptyTableMessage from '../../../shared/components/EmptyTableMessage';
import { showModal } from '../../../shared/actions/actions';

jest.mock('../../../shared/actions/actions', () => ({
  setHeaderAndFooter: jest.fn(() => ({ type: 'MOCK_SET_HEADER_AND_FOOTER' })),
  showModal: jest.fn(() => ({ type: 'MOCK_SHOW_MODAL' }))
}));

jest.mock('../../../shared/api/lineItemsResources');

const customer = CustomerFactory.build({ name: 'GRILLED CHEESE FACTORY' });

const lineItemResponse = {
  data: [
    LineItemFactory.build({
      itemId: 100,
      customerOrder: CustomerOrderFactory.build({ customer: customer, onHold: false }),
      quantityRemaining: 2
    }),
    LineItemFactory.build({
      itemId: 101,
      customerOrder: CustomerOrderFactory.build({ customer: customer, onHold: true }),
      quantityRemaining: 1
    })
  ]
};

describe('scheduleFutureCutOrders', () => {
  beforeEach(() => {
    jest.useFakeTimers();
  });

  describe('when there are future orders', () => {
    let wrapper, store;

    beforeEach(() => {
      store = createReduxStore({
        portionRoomsInfo: {
          currentPortionRoom: {
            roomType: 'CUTTING'
          }
        }
      });
      lineItemsResources.getFutureLineItems.mockImplementation((arg, callback) =>
        callback(lineItemResponse)
      );
      lineItemsResources.scheduleFutureOrdersToProduceToday.mockImplementation((arg, callback) =>
        callback({})
      );

      wrapper = mount(
        <Provider store={store}>
          <ScheduleFutureCutOrders />
        </Provider>
      );
    });

    afterEach(() => {
      lineItemsResources.getFutureLineItems.mockReset();
      lineItemsResources.scheduleFutureOrdersToProduceToday.mockReset();
    });

    test('should render schedule future orders for cutting room', () => {
      let futureOrderOverviewTable = wrapper.find(ScheduleFutureCutOrdersTable);
      jestExpect(futureOrderOverviewTable.exists()).toEqual(true);
    });

    test('should fill out form, submit values to API, reset form when submit successfully', () => {
      semanticUI.changeInput(wrapper, '100-toCutToday', '2');
      wrapper.find('form').simulate('submit');

      jestExpect(lineItemsResources.scheduleFutureOrdersToProduceToday).toHaveBeenCalledWith(
        {
          '100': '2'
        },
        jestExpect.any(Function)
      );
      jestExpect(lineItemsResources.getFutureLineItems).toHaveBeenCalledTimes(2);
    });

    test('should fill out form, submit when having onHold customer', () => {
      semanticUI.changeInput(wrapper, '100-toCutToday', '2');
      semanticUI.changeInput(wrapper, '101-toCutToday', '1');
      wrapper.find('form').simulate('submit');

      jestExpect(showModal).toHaveBeenCalledWith(
        jestExpect.objectContaining({
          header: 'Customer on Credit Hold',
          content:
            'Customer 99998 is on credit hold. Are you sure you want to produce orders for this customer?',
          cancelButton: 'No',
          cancelAction: jestExpect.any(Function),
          confirmButton: 'Yes',
          confirmAction: jestExpect.any(Function)
        })
      );
    });

    test('should fill out form, submit successfully when only having onHold customer', () => {
      semanticUI.changeInput(wrapper, '101-toCutToday', '1');
      wrapper.find('form').simulate('submit');

      jestExpect(showModal).toHaveBeenCalledWith(
        jestExpect.objectContaining({
          header: 'Customer on Credit Hold',
          content:
            'Customer 99998 is on credit hold. Are you sure you want to produce orders for this customer?',
          cancelButton: 'No',
          cancelAction: jestExpect.any(Function),
          confirmButton: 'Yes',
          confirmAction: jestExpect.any(Function)
        })
      );
    });

    test('should not submit values to API when submit validation failed', () => {
      semanticUI.changeInput(wrapper, '100-toCutToday', 'abc');
      wrapper.find('form').simulate('submit');

      jestExpect(lineItemsResources.scheduleFutureOrdersToProduceToday).not.toHaveBeenCalled();
    });
  });

  describe('when there are no future orders', () => {
    test('should not show Future orders table nor empty table message when futureOrders is null', () => {
      const store = createReduxStore({
        portionRoomsInfo: {
          currentPortionRoom: {
            roomType: 'CUTTING'
          }
        },
        cutOrderOverview: {
          futureOrders: null
        }
      });

      const wrapper = mount(
        <Provider store={store}>
          <ScheduleFutureCutOrders />
        </Provider>
      );

      jestExpect(wrapper.contains(EmptyTableMessage)).toBe(false);
      jestExpect(wrapper.contains(ScheduleFutureCutOrdersTable)).toBe(false);
    });
  });

  describe('when there are initial values', () => {
    test('should show initial values', () => {
      const store = createReduxStore({
        portionRoomsInfo: {
          currentPortionRoom: {
            roomType: 'CUTTING'
          }
        },
        cutOrderOverview: {
          futureOrders: lineItemResponse.data,
          onHoldOrders: {
            '101': '1'
          }
        }
      });

      const wrapper = mount(
        <Provider store={store}>
          <ScheduleFutureCutOrders />
        </Provider>
      );

      const futureOrderOverviewTable = wrapper.find(ScheduleFutureCutOrdersTable);

      jestExpect(
        futureOrderOverviewTable
          .find('input')
          .at(0)
          .props().value
      ).toBe('');
      jestExpect(
        futureOrderOverviewTable
          .find('input')
          .at(1)
          .props().value
      ).toBe('1');
    });
  });

  describe('auto-refresh data', () => {
    let scheduleFutureCutOrdersComponent;

    let getFutureLineItems = jest.fn();

    beforeEach(() => {
      scheduleFutureCutOrdersComponent = new ScheduleFutureCutOrdersComponent({
        setHeaderAndFooter: jest.fn(),
        clear: jest.fn(),
        getFutureLineItems
      });
      scheduleFutureCutOrdersComponent.ref = { focus: jest.fn() };
    });

    afterEach(() => {
      jest.clearAllTimers();
    });

    test('should call setInterval when componentDidMount', () => {
      scheduleFutureCutOrdersComponent.componentDidMount();

      jestExpect(setInterval).toHaveBeenCalledTimes(1);
      jestExpect(getFutureLineItems).toHaveBeenCalledTimes(1);
    });

    test('should call clearInterval when componentWillUnmount', () => {
      scheduleFutureCutOrdersComponent.componentWillUnmount();
      jestExpect(clearInterval).toHaveBeenCalledTimes(1);
    });
  });
});

describe('Submit button', () => {
  test('should disable submit when pristine', () => {
    const submitButton = shallow(
      <SubmitButton
        futureOrders={lineItemResponse.data}
        userProjectedQuantitiesRemaining={[]}
        submitting={false}
        pristine={true}
        isApprovedForDay={false}
        roomIsDisabled={false}
      />
    );

    jestExpect(submitButton.find(Button)).toBeDisabled();
  });

  test('should not display when there are no orders to act on', () => {
    const submitButton = shallow(
      <SubmitButton
        futureOrders={[]}
        userProjectedQuantitiesRemaining={[]}
        submitting={false}
        pristine={true}
        isApprovedForDay={false}
        roomIsDisabled={false}
      />
    );

    jestExpect(submitButton.type()).toBe(null);
  });
});
