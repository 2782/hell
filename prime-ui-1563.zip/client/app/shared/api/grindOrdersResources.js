import config from '../../../../config/env';
import axios from 'axios';

const getGrindOrders = (roomCode, callback) => {
  const request = axios({
    method: 'get',
    url: `${config.api.target}/api/orders/grind`,
    headers: {
      'Content-type': 'application/json'
    },
    params: {
      'room-code': roomCode,
      cancelled: false
    }
  });

  return request.then(response => {
    callback(response);
  });
};

const scheduleGrindOrdersToProduceToday = (values, successCallback) => {
  const request = axios({
    method: 'post',
    url: `${config.api.target}/api/orders/grind/schedule`,
    headers: {
      'Content-type': 'application/json'
    },
    data: values
  });

  return request.then(response => {
    successCallback(response);
  });
};

const approveGrindOrders = roomCode => {
  return axios({
    method: 'post',
    url: `${config.api.target}/api/orders/grind/approve`,
    params: { 'room-code': roomCode },
    headers: { 'Content-type': 'application/json' }
  });
};

const updateGrindOrder = (grindOrder, successCallback) => {
  const request = axios({
    method: 'post',
    url: `${config.api.target}/api/orders/grind/update/${grindOrder.id}/qtyInBoxes/${
      grindOrder.qtyInBoxes
    }`,
    headers: {
      'Content-type': 'application/json'
    }
  });

  return request.then(response => {
    successCallback(response);
  });
};

const generateGrindingOrdersFromHousePar = (value, roomCode, callback) => {
  const request = axios({
    method: 'post',
    url: `${config.api.target}/api/orders/grind/house-pars/schedule`,
    params: {
      'room-code': roomCode
    },
    headers: {
      'Content-type': 'application/json'
    },
    data: value
  });

  return request.then(response => {
    callback(response);
  });
};

export default {
  scheduleGrindOrdersToProduceToday,
  getGrindOrders,
  approveGrindOrders,
  generateGrindingOrdersFromHousePar,
  updateGrindOrder
};
