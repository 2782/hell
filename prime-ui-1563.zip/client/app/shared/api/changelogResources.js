import config from '../../../../config/env';
import axios from 'axios';

const getAllUniqueUserIdNamesForCutting = ({
  startDate,
  endDate,
  finishedProductCode,
  sourceProductCode,
  fieldNames
}) => {
  return axios({
    method: 'get',
    url: `${config.api.target}/api/cutting-yield-model-change-log/user-ids`,
    params: {
      'finished-product-code': finishedProductCode,
      'source-product-code': sourceProductCode,
      'field-names': fieldNames,
      startDate,
      endDate
    }
  });
};

const getAllUniqueUserIdNamesForGrinding = ({
  startDate,
  endDate,
  blend,
  fieldNames,
  sourceProductCodes
}) => {
  return axios({
    method: 'get',
    url: `${config.api.target}/api/grinding-yield-model-change-log/user-ids`,
    params: {
      blend,
      'source-product-codes': sourceProductCodes,
      'field-names': fieldNames,
      startDate,
      endDate
    }
  });
};

const getAllUniqueUserIdNamesForAllCuttingPricing = ({
  startDate,
  endDate,
  fieldNames,
  finishedProductCode
}) => {
  return axios({
    method: 'get',
    url: `${config.api.target}/api/all-cutting-yield-model-change-log/user-ids`,
    params: {
      'field-names': fieldNames,
      'finished-product-code': finishedProductCode,
      startDate,
      endDate
    }
  });
};

const getAllUniqueFieldNamesForAllCuttingPricing = ({
  startDate,
  endDate,
  userId,
  finishedProductCode
}) => {
  return axios({
    method: 'get',
    url: `${config.api.target}/api/all-cutting-yield-model-change-log/field-names`,
    params: {
      'user-id': userId,
      'finished-product-code': finishedProductCode,
      startDate,
      endDate
    }
  });
};

const getAllUniqueFieldNamesForCutting = ({
  startDate,
  endDate,
  finishedProductCode,
  sourceProductCode,
  userId
}) => {
  return axios({
    method: 'get',
    url: `${config.api.target}/api/cutting-yield-model-change-log/field-names`,
    params: {
      'finished-product-code': finishedProductCode,
      'source-product-code': sourceProductCode,
      'user-id': userId,
      startDate,
      endDate
    }
  });
};

const getAllUniqueFieldNamesForGrinding = ({
  startDate,
  endDate,
  blend,
  userId,
  sourceProductCodes
}) => {
  return axios({
    method: 'get',
    url: `${config.api.target}/api/grinding-yield-model-change-log/field-names`,
    params: {
      blend,
      'source-product-codes': sourceProductCodes,
      'user-id': userId,
      startDate,
      endDate
    }
  });
};

const getCuttingYieldModelChangelog = ({
  finishedProductCode,
  sourceProductCode,
  startDate,
  endDate,
  userId = '',
  fieldNames = '',
  page = 0,
  sortColumn = 'timestamp',
  sortDirection = 'desc'
}) => {
  return axios({
    method: 'get',
    url: `${config.api.target}/api/cutting-yield-model-change-log`,
    params: {
      'finished-product-code': finishedProductCode,
      'source-product-code': sourceProductCode,
      startDate,
      endDate,
      userId,
      'field-names': fieldNames,
      size: 20,
      page,
      sort: `${sortColumn},${sortDirection}`
    }
  });
};

const getAllCuttingPricingYieldModelChangelog = ({
  startDate,
  endDate,
  userId = '',
  fieldNames = '',
  finishedProductCode = '',
  page = 0,
  sortColumn = 'timestamp',
  sortDirection = 'desc'
}) => {
  return axios({
    method: 'get',
    url: `${config.api.target}/api/all-cutting-yield-model-change-log`,
    params: {
      startDate,
      endDate,
      userId,
      'field-names': fieldNames,
      'finished-product-code': finishedProductCode,

      size: 20,
      page,
      sort: `${sortColumn},${sortDirection}`
    }
  });
};

const getGrindingYieldModelChangelog = ({
  blend,
  sourceProductCodes,
  startDate,
  endDate,
  userId = '',
  fieldNames = '',
  page = 0,
  sortColumn = 'timestamp',
  sortDirection = 'desc'
}) => {
  return axios({
    method: 'get',
    url: `${config.api.target}/api/grinding-yield-model-change-log`,
    params: {
      blend,
      'source-product-codes': sourceProductCodes,
      startDate,
      endDate,
      userId,
      'field-names': fieldNames,
      size: 20,
      page,
      sort: `${sortColumn},${sortDirection}`
    }
  });
};

const getCuttingYieldModelChangelogDates = ({ finishedProductCode, sourceProductCode }) => {
  return axios({
    method: 'get',
    url: `${config.api.target}/api/cutting-yield-model-change-log/dates`,
    params: {
      'finished-product-code': finishedProductCode,
      'source-product-code': sourceProductCode
    }
  });
};

const getAllCuttingPricingYieldModelChangelogDates = () => {
  return axios({
    method: 'get',
    url: `${config.api.target}/api/all-cutting-yield-model-change-log/dates`
  });
};

const getGrindingYieldModelChangelogDates = ({ blend, sourceProductCodes }) => {
  return axios({
    method: 'get',
    url: `${config.api.target}/api/grinding-yield-model-change-log/dates`,
    params: {
      blend: blend,
      'source-product-codes': sourceProductCodes
    }
  });
};

export default {
  getAllUniqueUserIdNamesForCutting,
  getAllUniqueUserIdNamesForGrinding,
  getAllUniqueUserIdNamesForAllCuttingPricing,
  getAllUniqueFieldNamesForCutting,
  getAllUniqueFieldNamesForGrinding,
  getAllUniqueFieldNamesForAllCuttingPricing,
  getCuttingYieldModelChangelog,
  getCuttingYieldModelChangelogDates,
  getGrindingYieldModelChangelogDates,
  getGrindingYieldModelChangelog,
  getAllCuttingPricingYieldModelChangelogDates,
  getAllCuttingPricingYieldModelChangelog
};
