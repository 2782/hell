import axios from 'axios';
import config from '../../../../config/env';
import { CREATE_PROFILE_ERROR_MESSAGE } from '../../../config/errorMessage';
import _ from 'lodash';

import { convertWeekendsConfigStringToBoolean } from '../util/dataUtil';

const getHolidays = callback => {
  const request = axios({
    method: 'get',
    url: `${config.api.target}/api/holidays`,
    headers: {
      'Content-Type': 'application/json'
    }
  });

  request.then(response => callback(response));
};

const getStations = callback => {
  const request = axios({
    method: 'get',
    url: `${config.api.target}/api/stations`,
    headers: {
      'Content-Type': 'application/json'
    }
  });

  request.then(response => callback(response));
};

const getTables = callback => {
  const request = axios({
    method: 'get',
    url: `${config.api.target}/api/portion-room-tables`,
    headers: {
      'Content-type': 'application/json'
    }
  });

  request.then(response => callback(response));
};

const getTable = (tableId, callback) => {
  const request = axios({
    method: 'get',
    url: `${config.api.target}/api/portion-room-tables/${tableId}`,
    headers: {
      'Content-type': 'application/json'
    }
  });

  request.then(response => callback(response));
};

const getStation = (stationId, callback) => {
  const request = axios({
    method: 'get',
    url: `${config.api.target}/api/stations/${stationId}`,
    headers: {
      'Content-type': 'application/json'
    }
  });

  request.then(response => callback(response));
};

const createHoliday = (holiday, successCallback, errorCallback) => {
  const request = axios({
    method: 'post',
    url: `${config.api.target}/api/holiday`,
    headers: {
      'Content-type': 'application/json'
    },
    data: holiday
  });

  request
    .then(response => successCallback(response))
    .catch(() => errorCallback({ showing: true, message: 'Please provide a valid date' }));
};

const editHoliday = (holiday, existingId) => {
  const request = axios({
    method: 'post',
    url: `${config.api.target}/api/holiday/edit/${existingId}`,
    headers: {
      'Content-type': 'application/json'
    },
    data: holiday
  });

  return request
    .then(response => response)
    .catch(() => ({ message: 'Please provide a valid date' }));
};

const deleteHoliday = (id, callback) => {
  const request = axios({
    method: 'delete',
    url: `${config.api.target}/api/holiday/${id}`
  });

  request.then(() => {
    callback();
  });
};

const getWeekends = callback => {
  const request = axios({
    method: 'get',
    url: `${config.api.target}/api/system-configs`,
    headers: {
      'Content-Type': 'application/json'
    },
    params: {
      'config-group': 'GROUP_WEEKEND_OPEN_PORTION_ROOM'
    }
  });

  request.then(response => callback(convertWeekendsConfigStringToBoolean(response.data)));
};

const updateSystemConfig = (data, callback) => {
  const request = axios({
    method: 'put',
    url: `${config.api.target}/api/system-configs/${data.id}`,
    headers: {
      'Content-type': 'application/json'
    },
    data: data
  });

  return request.then(response => callback(convertWeekendsConfigStringToBoolean(response.data)));
};

const createStation = (station, successCallback, errorCallback) => {
  const request = axios({
    method: 'post',
    url: `${config.api.target}/api/stations`,
    headers: {
      'Content-type': 'application/json'
    },
    data: station
  });

  return request.then(
    response => successCallback(response),
    error => errorCallback(_.get(error, 'response.data', {}))
  );
};

const getRooms = () => {
  return axios({
    method: 'get',
    url: `${config.api.target}/api/rooms`,
    headers: {
      'Content-type': 'application/json'
    }
  });
};

const createRoom = (data, successCallback, errorCallback) => {
  const request = axios({
    method: 'post',
    url: `${config.api.target}/api/rooms`,
    headers: {
      'Content-Type': 'application/json'
    },
    data: data
  });

  return request.then(
    response => successCallback(response),
    error => errorCallback(_.get(error, 'response.data', {}))
  );
};

const createHousePar = (data, successCallback, errorCallback) => {
  const request = axios({
    method: 'post',
    url: `${config.api.target}/api/house-pars`,
    headers: {
      'Content-Type': 'application/json'
    },
    data: data
  });

  return request.then(
    response => successCallback(response),
    error =>
      errorCallback({
        ..._.get(error, 'response.data', {}),
        update: false
      })
  );
};

const updateHousePar = (data, successCallback, errorCallback) => {
  const request = axios({
    method: 'put',
    url: `${config.api.target}/api/house-pars/${data.id}`,
    headers: {
      'Content-Type': 'application/json'
    },
    data: data
  });

  return request.then(
    response => successCallback(response),
    error =>
      errorCallback({
        ..._.get(error, 'response.data', {}),
        update: true
      })
  );
};

const createTable = table => {
  return axios({
    method: 'post',
    url: `${config.api.target}/api/portion-room-tables`,
    headers: {
      'Content-Type': 'application/json'
    },
    data: table
  });
};

const updateStation = (station, successCallback, errorCallback) => {
  const request = axios({
    method: 'put',
    url: `${config.api.target}/api/stations/${station.id}`,
    headers: {
      'Content-Type': 'application/json'
    },
    data: station
  });

  return request.then(
    response => successCallback(response),
    error => errorCallback(_.get(error, 'response.data', {}))
  );
};

const updateTable = (tableId, table) => {
  return axios({
    method: 'put',
    url: `${config.api.target}/api/portion-room-tables/${tableId}`,
    headers: {
      'Content-Type': 'application/json'
    },
    data: table
  });
};

const createOrUpdateProfile = (data, successCallback, errorCallback) => {
  const request = axios({
    method: 'post',
    url: `${config.api.target}/api/profile`,
    headers: {
      'Content-Type': 'application/json'
    },
    data: data
  });

  return request.then(
    response => {
      successCallback(response);
    },
    () => {
      errorCallback({ showing: true, message: CREATE_PROFILE_ERROR_MESSAGE });
    }
  );
};

const getProfile = callback => {
  const request = axios({
    method: 'get',
    url: `${config.api.target}/api/profile`,
    headers: {
      'Content-Type': 'application/json'
    }
  });

  request.then(response => callback(response));
};

const getHousePars = callback => {
  const request = axios({
    method: 'get',
    url: `${config.api.target}/api/house-pars`,
    headers: {
      'Content-Type': 'application/json'
    }
  });

  return request.then(response => callback(response));
};

const deleteHousePar = (productCode, callback) => {
  const request = axios({
    method: 'delete',
    url: `${config.api.target}/api/house-par/${productCode}`,
    headers: {
      'Content-Type': 'application/json'
    }
  });

  return request.then(response => callback(response));
};

const getHousePar = (productCode, callback) => {
  const request = axios({
    method: 'get',
    url: `${config.api.target}/api/house-par/${productCode}`,
    headers: {
      'Content-Type': 'application/json'
    }
  });

  return request.then(response => callback(response));
};

const getAvailableGrindingHousePar = (roomCode, callback) => {
  const request = axios({
    method: 'get',
    url: `${config.api.target}/api/house-pars/grinding`,
    params: {
      'room-code': roomCode
    },
    headers: {
      'Content-Type': 'application/json'
    }
  });

  return request.then(response => callback(response));
};

const getCustomers = () => {
  return axios({
    method: 'get',
    url: `${config.api.target}/api/customers`,
    headers: {
      'Content-Type': 'application/json'
    }
  });
};

const getCustomer = customerCode => {
  return axios({
    method: 'get',
    url: `${config.api.target}/api/customers/${customerCode}`,
    headers: {
      'Content-Type': 'application/json'
    }
  });
};

const setupCustomer = (data, logoFile) => {
  const formData = new FormData();
  formData.append(
    'data',
    new Blob([JSON.stringify(data)], {
      type: 'application/json'
    })
  );
  if (logoFile !== null) {
    formData.append('file', logoFile);
  }

  return axios({
    method: 'post',
    url: `${config.api.target}/api/customers/setup`,
    data: formData,
    headers: {
      'Content-Type': 'undefined'
    }
  });
};

const getSubPrimal = (subPrimalCode, successCallback, rejectCallback) => {
  const request = axios({
    method: 'get',
    url: `${config.api.target}/api/products/sub-primal`,
    params: { 'sub-primal-code': subPrimalCode },
    headers: {
      'Content-Type': 'application/json'
    }
  });

  return request.then(
    response => successCallback(response),
    error => rejectCallback(_.get(error, 'response.data', {}))
  );
};

export default {
  getRooms,
  getHolidays,
  getWeekends,
  createHoliday,
  editHoliday,
  updateSystemConfig,
  deleteHoliday,
  getStations,
  getStation,
  getTables,
  getTable,
  createStation,
  updateStation,
  createTable,
  updateTable,
  getProfile,
  createRoom,
  createOrUpdateProfile,
  createHousePar,
  updateHousePar,
  deleteHousePar,
  getHousePar,
  getHousePars,
  getAvailableGrindingHousePar,
  getCustomers,
  getCustomer,
  setupCustomer,
  getSubPrimal
};
