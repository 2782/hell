import config from '../../../../config/env';
import axios from 'axios';

const getPortionRoomTable = (tableId, callback) => {
  const request = axios({
    method: 'get',
    url: `${config.api.target}/api/portion-room-tables/${tableId}`,
    headers: {
      'Content-Type': 'application/json'
    }
  });

  return request.then(response => {
    callback(response);
  });
};

export default {
  getPortionRoomTable
};
