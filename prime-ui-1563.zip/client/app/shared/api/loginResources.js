import axios from 'axios';
import config from '../../../../config/env';

const getPrimeUserDetails = () => {
  return axios({
    method: 'get',
    url: `${config.api.target}/api/prime-user-details`,
    headers: {
      'Content-Type': 'application/json'
    }
  });
};

export default {
  getPrimeUserDetails
};
