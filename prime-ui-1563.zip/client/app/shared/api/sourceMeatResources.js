import config from '../../../../config/env';
import axios from 'axios';
import { CREATE_SOURCE_MEAT_REQUEST_MESSAGE } from '../../../config/errorMessage';

const calcSourceMeat = (cutOrderIds, callback) => {
  const request = axios({
    method: 'get',
    url: `${config.api.target}/api/source-meat?cutOrderIds=${cutOrderIds.join(',')}`,
    headers: {
      'Content-Type': 'application/json'
    }
  });

  return request.then(response => {
    callback(response);
  });
};

const generateSourceMeatOrders = (sourceMeatOrders, roomCode, responseCallback, errorCallback) => {
  let url = `${config.api.target}/api/source-meat`;
  if (sourceMeatOrders[0].unitOfMeasure === 'LBS') {
    url = `${config.api.target}/api/source-meat/by-lbs`;
  }
  const request = axios({
    method: 'post',
    url: url,
    headers: {
      'Content-Type': 'application/json'
    },
    data: sourceMeatOrders,
    params: { roomCode }
  });

  return request
    .then(response => {
      responseCallback(response);
    })
    .catch(() => errorCallback({ message: CREATE_SOURCE_MEAT_REQUEST_MESSAGE }));
};

const getSourceMeatOrderPreviewByProduct = (productInfo, callback) => {
  const request = axios({
    method: 'get',
    url: `${config.api.target}/api/source-meat/preview`,
    headers: {
      'Content-Type': 'application/json'
    },
    params: productInfo
  });

  return request.then(response => {
    callback(response);
  });
};

export default {
  calcSourceMeat,
  generateSourceMeatOrders,
  getSourceMeatOrderPreviewByProduct
};
