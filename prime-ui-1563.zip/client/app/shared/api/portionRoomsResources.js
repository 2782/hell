import config from '../../../../config/env';
import axios from 'axios';

const getPortionRooms = () => {
  return axios({
    method: 'get',
    url: `${config.api.target}/api/rooms`,
    headers: {
      'Content-type': 'application/json'
    }
  });
};

const openPortionRoom = id => {
  return axios({
    method: 'post',
    url: `${config.api.target}/api/rooms/${id}/open`,
    headers: {
      'Content-Type': 'application/json'
    }
  });
};

const closePortionRoom = (id, evenUnfinishedOrders, evenSusPoUnavailable) => {
  return axios({
    method: 'post',
    url: `${config.api.target}/api/rooms/${id}/close`,
    headers: {
      'Content-Type': 'application/json'
    },
    params: {
      unfinishedOrders: evenUnfinishedOrders,
      susPoUnavailable: evenSusPoUnavailable
    }
  });
};

const getStockAllocationAlert = roomCode => {
  return axios({
    method: 'get',
    url: `${config.api.target}/api/rooms/${roomCode}/stock-allocation-alert`,
    headers: {
      'Content-type': 'application/json'
    }
  });
};

const getCostingRoom = () => {
  return axios({
    method: 'get',
    url: `${config.api.target}/api/rooms/costing`,
    headers: {
      'Content-type': 'application/json'
    }
  });
};

export default {
  getPortionRooms,
  openPortionRoom,
  closePortionRoom,
  getStockAllocationAlert,
  getCostingRoom
};
