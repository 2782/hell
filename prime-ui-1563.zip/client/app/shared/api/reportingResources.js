import config from '../../../../config/env';
import axios from 'axios';

const transformToObject = arrayBuffer => {
  return JSON.parse(String.fromCharCode.apply(null, new Uint8Array(arrayBuffer)));
};

const downloadProfitabilityReport = ({ reportDate, roomCode }) => {
  const request = axios({
    method: 'get',
    url: `${config.api.target}/metrics/${roomCode}/profitability/${reportDate}`,
    responseType: 'arraybuffer'
  });

  return request
    .then(response => response.data)
    .catch(error => Promise.reject(transformToObject(error.response.data)));
};

const downloadWeeklyRecapReport = ({ reportDate }) => {
  const request = axios({
    method: 'get',
    url: `${config.api.target}/metrics/weekly-recap/${reportDate}`,
    responseType: 'arraybuffer'
  });

  return request.then(response => response.data, error => transformToObject(error.response.data));
};

const downloadCuttingStationProductivityReport = ({ reportDate, roomCode }) => {
  const request = axios({
    method: 'get',
    url: `${config.api.target}/metrics/${roomCode}/cutting-station-productivity/${reportDate}`,
    responseType: 'arraybuffer'
  });

  return request.then(
    response => response.data,
    error => Promise.reject(transformToObject(error.response.data))
  );
};

const downloadProductInAndOutReport = ({ roomCode, reportYearMonth }) => {
  const request = axios({
    method: 'get',
    url: `${config.api.target}/metrics/${roomCode}/product-in-out/${reportYearMonth}`,
    responseType: 'arraybuffer'
  });

  return request.then(response => response.data);
};

const downloadYieldCostSummaryReport = ({ reportDate }) => {
  const request = axios({
    method: 'get',
    url: `${config.api.target}/metrics/yield-cost-summary/${reportDate}`,
    responseType: 'arraybuffer'
  });

  return request.then(response => response.data, error => transformToObject(error.response.data));
};

const downloadHouseParReport = ({ reportDate }) => {
  const request = axios({
    method: 'get',
    url: `${config.api.target}/metrics/house-par/${reportDate}`,
    responseType: 'arraybuffer'
  });

  return request.then(response => response.data, error => transformToObject(error.response.data));
};

const downloadScaleSummary = ({ endDate, reportDate }) => {
  const request = axios({
    method: 'get',
    url: `${config.api.target}/metrics/scale-summary`,
    params: {
      startDate: reportDate,
      endDate
    },
    responseType: 'arraybuffer'
  });

  return request.then(response => response.data, error => transformToObject(error.response.data));
};

const downloadWipSpoil = ({ endDate, reportDate }) => {
  const request = axios({
    method: 'get',
    url: `${config.api.target}/metrics/wip-spoil`,
    params: {
      startDate: reportDate,
      endDate
    },
    responseType: 'arraybuffer'
  });

  return request.then(response => response.data, error => transformToObject(error.response.data));
};

const getCustomerBoxes = ({
  productCode,
  packoffStationName,
  tableCode,
  customerOrderNumber,
  workingDate,
  page = 0,
  sortColumn = 'createdAt',
  sortDirection = 'desc'
}) => {
  return axios({
    method: 'get',
    url: `${config.api.target}/api/product-activities/search/packoff/boxes`,
    params: {
      productCode,
      packoffStationName,
      tableCode,
      customerOrderNumber,
      workingDate,
      size: 20,
      page,
      sort: `${sortColumn},${sortDirection}`
    }
  });
};

const getStockWipBoxesForFinished = ({
  roomCode,
  productCode,
  packoffStationName,
  workingDate,
  incomplete,
  page = 0,
  sortColumn = 'createdAt',
  sortDirection = 'desc'
}) => {
  return axios({
    method: 'get',
    url: `${config.api.target}/api/product-activities/search/stock-wip/finished/boxes`,
    params: {
      roomCode,
      productCode,
      packoffStationName,
      workingDate,
      incomplete,
      size: 20,
      page,
      sort: `${sortColumn},${sortDirection}`
    }
  });
};

const getWipBoxesForSource = ({
  roomCode,
  productCode,
  packoffStationName,
  workingDate,
  page = 0,
  sortColumn = 'createdAt',
  sortDirection = 'desc'
}) => {
  return axios({
    method: 'get',
    url: `${config.api.target}/api/product-activities/search/wip/source/boxes`,
    params: {
      roomCode,
      productCode,
      packoffStationName,
      workingDate,
      size: 20,
      page,
      sort: `${sortColumn},${sortDirection}`
    }
  });
};

const getProductActivities = ({
  productCode,
  startDate,
  endDate,
  page = 0,
  sortColumn = 'timestamp',
  sortDirection = 'desc'
}) => {
  return axios({
    method: 'get',
    url: `${config.api.target}/api/product-activities/${productCode}`,
    params: {
      startDate,
      endDate,
      size: 20,
      page,
      sort: `${sortColumn},${sortDirection}`
    }
  });
};

const downloadFinishedGoodMarketCostReport = () => {
  const request = axios({
    method: 'get',
    url: `${config.api.target}/metrics/finished-good-market-cost`,
    responseType: 'arraybuffer'
  });

  return request.then(response => response.data, error => transformToObject(error.response.data));
};

const getCuttingReportingEvent = id => {
  return axios({
    method: 'get',
    url: `${config.api.target}/api/cutting-yield-model-reporting-event/${id}`
  });
};

const getGrindingReportingEvent = id => {
  return axios({
    method: 'get',
    url: `${config.api.target}/api/grinding-yield-model-reporting-event/${id}`
  });
};

export default {
  downloadCuttingStationProductivityReport,
  downloadHouseParReport,
  downloadProductInAndOutReport,
  downloadProfitabilityReport,
  downloadWeeklyRecapReport,
  downloadYieldCostSummaryReport,
  getCustomerBoxes,
  getProductActivities,
  getStockWipBoxesForFinished,
  getWipBoxesForSource,
  downloadScaleSummary,
  downloadWipSpoil,
  downloadFinishedGoodMarketCostReport,
  getCuttingReportingEvent,
  getGrindingReportingEvent
};
