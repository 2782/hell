import _ from 'lodash';
import axios from 'axios';
import config from '../../../../config/env';

const WEIGHT_PATTERN = /([-]?[\d]*[.]{0,1}[\d]+)lb$/g;

function extract(weight) {
  if (weight.match(WEIGHT_PATTERN)) {
    let executed = WEIGHT_PATTERN.exec(weight);
    return executed[1];
  }
}

function validate(weight) {
  if (_.isEmpty(weight)) {
    return new Error("Please set scale's unit of measure to pounds.");
  }
  if (parseFloat(weight) < 0) {
    return new Error('Weight cannot be negative.');
  }
}

const readWeightFromAPI = (successCallback, errorCallback) => {
  const request = axios({
    method: 'get',
    url: `${config.api.target}/api/boxes/read-houston-scale`
  });

  return request
    .then(response => {
      const value = extract(response.data);
      const validationError = validate(value);

      if (validationError) {
        errorCallback(validationError);
      } else {
        successCallback(value);
      }
    })
    .catch(error => errorCallback(error));
};

export default {
  readWeight: readWeightFromAPI
};
