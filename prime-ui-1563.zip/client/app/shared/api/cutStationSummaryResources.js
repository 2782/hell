import config from '../../../../config/env';
import axios from 'axios';

const getCutStationSummary = (roomCode, callback) => {
  const request = axios({
    method: 'get',
    url: `${config.api.target}/api/cut-orders/summary/stations`,
    headers: {
      'Content-type': 'application/json'
    },
    params: {
      'room-code': roomCode
    }
  });

  return request.then(response => {
    callback(response);
  });
};

export default {
  getCutStationSummary
};
