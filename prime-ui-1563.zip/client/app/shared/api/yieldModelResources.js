import axios from 'axios';
import config from '../../../../config/env';
import _ from 'lodash';

const getYieldModel = (finishedProductCode, sourceProductCode) => {
  return axios({
    method: 'get',
    url: `${config.api.target}/api/yield-model`,
    params: {
      'finished-product-code': finishedProductCode,
      'source-product-code': sourceProductCode
    },
    headers: {
      'Content-Type': 'application/json'
    }
  });
};

const calculateCuttingYieldModelFinishedCost = yieldModel => {
  return axios({
    method: 'post',
    url: `${config.api.target}/api/yield-model/cutting/cost`,
    data: yieldModel,
    headers: {
      'Content-type': 'application/json'
    }
  });
};

const createOrUpdateCuttingYieldModel = yieldModel => {
  return axios({
    method: 'put',
    url: `${config.api.target}/api/yield-model`,
    data: yieldModel,
    headers: {
      'Content-type': 'application/json'
    }
  });
};

const calculateGrindingYieldModelFinishedCost = yieldModel => {
  return axios({
    method: 'post',
    url: `${config.api.target}/api/yield-model/grinding/cost`,
    data: yieldModel,
    headers: {
      'Content-type': 'application/json'
    }
  });
};

const createGrindingYieldModel = (yieldModel, successCallback, errorCallback) => {
  const request = axios({
    method: 'post',
    url: `${config.api.target}/api/yield-model/grinding`,
    data: yieldModel,
    headers: {
      'Content-type': 'application/json'
    }
  });

  return request.then(
    response => successCallback(response.data),
    error => errorCallback(_.get(error, 'response.data', {}))
  );
};

const runYieldModel = () => {
  return axios({
    method: 'post',
    url: `${config.api.target}/api/yield-models/run`,
    headers: {
      'Content-type': 'application/json'
    }
  });
};

const searchYieldModelsByFinishedProductCode = productCode => {
  return axios({
    method: 'get',
    url: `${
      config.api.target
    }/api/yield-models/search-by-finished-product-code?finished-product-code=${productCode}`,
    headers: {
      'Content-type': 'application/json'
    }
  });
};

const searchYieldModelsByBlend = blend => {
  return axios({
    method: 'get',
    url: `${config.api.target}/api/yield-models/search-by-blend?blend=${encodeURI(blend)}`,
    headers: {
      'Content-type': 'application/json'
    }
  });
};

const getPricingModelByBlend = (blend, successCallback, rejectCallback) => {
  const request = axios({
    method: 'get',
    url: `${config.api.target}/api/yield-models/pricing-models/by-blend?blend=${blend}`,
    headers: {
      'Content-type': 'application/json'
    }
  });

  return request.then(response => successCallback(response), error => rejectCallback(error));
};

const checkGrindingYieldModelExists = yieldModel => {
  const request = axios({
    method: 'post',
    data: yieldModel,
    url: `${config.api.target}/api/yield-models/by-blend`,
    header: {
      'Content-type': 'application/json'
    }
  });

  return request.then(response => response.data);
};

const getBlends = () => {
  return axios({
    method: 'get',
    url: `${config.api.target}/api/blends`,
    headers: {
      'Content-type': 'application/json'
    }
  });
};

const createYieldTest = yieldTest => {
  return axios({
    method: 'post',
    url: `${config.api.target}/api/yield-tests`,
    data: yieldTest,
    headers: {
      'Content-type': 'application/json'
    }
  });
};

const getActualYieldTests = (yieldModelId, successCallback, rejectCallback) => {
  const request = axios({
    method: 'get',
    url: `${config.api.target}/api/yield-tests/${yieldModelId}`,
    headers: {
      'Content-Type': 'application/json'
    }
  });

  return request.then(response => successCallback(response), () => rejectCallback());
};

export default {
  calculateCuttingYieldModelFinishedCost,
  calculateGrindingYieldModelFinishedCost,
  checkGrindingYieldModelExists,
  createGrindingYieldModel,
  createOrUpdateCuttingYieldModel,
  getYieldModel,
  runYieldModel,
  searchYieldModelsByFinishedProductCode,
  searchYieldModelsByBlend,
  getPricingModelByBlend,
  getBlends,
  createYieldTest,
  getActualYieldTests
};
