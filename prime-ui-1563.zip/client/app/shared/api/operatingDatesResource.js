import config from '../../../../config/env';
import axios from 'axios';

const getOperatingDates = (roomCode, callback) => {
  const request = axios({
    method: 'get',
    url: `${config.api.target}/api/operating-dates/${roomCode}`,
    headers: {
      'Content-type': 'application/json'
    }
  });

  return request.then(response => {
    callback(response);
  });
};

export default {
  getOperatingDates
};
