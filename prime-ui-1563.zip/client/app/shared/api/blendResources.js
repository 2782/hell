import config from '../../../../config/env';
import axios from 'axios';

const getBlendPromise = blendName => {
  return axios({
    method: 'get',
    url: `${config.api.target}/api/blendName?blendName=${encodeURI(blendName)}`,
    headers: {
      'Content-type': 'application/json'
    }
  });
};

export default {
  getBlendPromise
};
