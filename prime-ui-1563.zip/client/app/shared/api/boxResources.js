import axios from 'axios';
import config from '../../../../config/env';

const getBoxes = (date, productCode, susOrderNo) => {
  return axios({
    method: 'get',
    url: `${config.api.target}/api/boxes`,
    params: buildQueryParams(date, productCode, susOrderNo),
    headers: {
      'Content-Type': 'application/json'
    }
  });
};

const getWipBoxes = successCallback => {
  const request = axios({
    method: 'get',
    url: `${config.api.target}/api/boxes/wip`,
    headers: {
      'Content-Type': 'application/json'
    }
  });

  request.then(response => {
    successCallback(response);
  });
};

const reprintLabelsForStation = (weightingId, type, stationCode) => {
  return axios({
    method: 'post',
    url: `${config.api.target}/api/boxes/labels/reprint-for-station`,
    data: {
      reprintWeightingId: weightingId,
      type,
      stationCode
    },
    headers: {
      'Content-type': 'application/json'
    }
  });
};

const reprintLabelsForCurrentUser = (weightingId, type) => {
  return axios({
    method: 'post',
    url: `${config.api.target}/api/boxes/labels/reprint`,
    data: {
      reprintWeightingId: weightingId,
      type
    },
    headers: {
      'Content-Type': 'application/json'
    }
  });
};

const relabelPackoffLabel = (boxId, stationCode) => {
  return axios({
    method: 'post',
    url: `${config.api.target}/api/boxes/labels/relabel`,
    data: {
      reprintBoxId: boxId,
      stationCode
    },
    headers: {
      'Content-type': 'application/json'
    }
  });
};

const deleteWipBox = (boxId, successCallback) => {
  const request = axios({
    method: 'delete',
    url: `${config.api.target}/api/boxes/wip/${boxId}`,
    headers: {
      'Content-type': 'application/json'
    }
  });

  return request.then(response => successCallback(response.data));
};

const updateWipStatusToInPortionRoom = (barcode, roomCode) => {
  return axios({
    method: 'put',
    url: `${config.api.target}/api/boxes/wip/${barcode}/room/${roomCode}`,
    headers: {
      'Content-Type': 'application/json'
    }
  });
};

export default {
  reprintLabelsForCurrentUser,
  getBoxes,
  reprintLabelsForStation,
  relabelPackoffLabel,
  getWipBoxes,
  deleteWipBox,
  updateWipStatusToInPortionRoom
};

const buildQueryParams = (date, productCode, susOrderNo) => {
  let params = {};

  if (date) {
    params['date'] = date;
  }

  if (productCode) {
    params['product-code'] = productCode;
  }

  if (susOrderNo) {
    params['sus-order-no'] = susOrderNo;
  }

  return params;
};
