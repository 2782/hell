import config from '../../../../config/env';
import axios from 'axios';

const buildQueryParams = (roomCode, orderStatus, stationId) => {
  const statusMap = {
    Completed: 'packed',
    All: 'to-cut,to-pack,packed,dismissed',
    SelectedToCut: 'to-pack',
    New: 'to-cut',
    Cancelled: 'to-cut,to-pack,packed,dismissed'
  };
  let params = {};

  if (roomCode) {
    params['room-code'] = roomCode;
  }

  if (orderStatus) {
    if (orderStatus === 'Cancelled') params['cancelled'] = true;
    params['status'] = statusMap[orderStatus];
  }

  if (stationId) {
    params['station-ids'] = stationId;
  }
  return params;
};

const getOverviewOfOrders = (roomCode, orderStatus, stationId, callback) => {
  const request = axios({
    method: 'get',
    url: `${config.api.target}/api/cut-orders`,
    headers: {
      'Content-type': 'application/json'
    },
    params: buildQueryParams(roomCode, orderStatus, stationId)
  });

  return request.then(response => {
    callback(response);
  });
};

const getOrdersByTableId = (roomCode, tableId, callback) => {
  const request = axios({
    method: 'get',
    url: `${
      config.api.target
    }/api/cut-orders?status=to-cut&table-id=${tableId}&room-code=${roomCode}&cancelled=false`,
    headers: {
      'Content-type': 'application/json'
    }
  });

  return request.then(response => {
    callback(response);
  });
};

const buildQueryParamsForCutOrderToPack = (date, productCode, susOrderNo, customerNo) => {
  let params = {};

  if (date) {
    params['date'] = date;
  }

  if (productCode) {
    params['product-code'] = productCode;
  }

  if (susOrderNo) {
    params['sus-order-no'] = susOrderNo;
  }

  if (customerNo) {
    params['customer-no'] = customerNo;
  }
  return params;
};

const getCutOrdersToPack = (date, productCode, susOrderNo, customerNo) => {
  return axios({
    method: 'get',
    url: `${config.api.target}/api/cut-orders/to-pack`,
    headers: {
      'Content-type': 'application/json'
    },
    params: buildQueryParamsForCutOrderToPack(date, productCode, susOrderNo, customerNo)
  });
};

const confirmCutOrders = (roomCode, cutOrderIds) => {
  return axios({
    method: 'patch',
    url: `${config.api.target}/api/cut-orders?room-code=${roomCode}`,
    headers: {
      'Content-type': 'application/json'
    },
    data: cutOrderIds.map(id => {
      return {
        cutOrderStatus: 'to-pack',
        id
      };
    })
  });
};

const dismissCancelledOrder = (id, callback) => {
  const request = axios({
    method: 'patch',
    url: `${config.api.target}/api/cut-orders`,
    headers: {
      'Content-type': 'application/json'
    },
    data: [
      {
        cutOrderStatus: 'dismissed',
        id
      }
    ]
  });

  return request.then(() => callback());
};

const printCutTickets = cutOrderIds => {
  return axios({
    method: 'post',
    url: `${config.api.target}/api/cut-tickets`,
    headers: {
      'Content-type': 'application/json',
      'Keep-Alive': 'timeout=120'
    },
    data: cutOrderIds
  });
};

const reprintCutTicket = (cutOrderId, stationCode) => {
  return axios({
    method: 'post',
    url: `${config.api.target}/api/cut-tickets/${cutOrderId}/reprint`,
    params: {
      stationCode: stationCode
    },
    headers: {
      'Content-type': 'application/json'
    }
  });
};

export default {
  dismissCancelledOrder,
  getOverviewOfOrders,
  getOrdersByTableId,
  getCutOrdersToPack,
  confirmCutOrders,
  printCutTickets,
  reprintCutTicket
};
