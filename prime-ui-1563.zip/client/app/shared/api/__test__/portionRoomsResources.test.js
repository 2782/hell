import moxios from 'moxios';
import portionRoomsResources from '../portionRoomsResources';

describe('portionRoomsResources', () => {
  beforeEach(() => {
    moxios.install();
  });

  afterEach(() => {
    moxios.uninstall();
  });

  test('should get portion room statuses', () => {
    moxios.wait(() => {
      const request = moxios.requests.mostRecent();
      request.respondWith({
        status: 200,
        response: 'data'
      });
    });

    return portionRoomsResources
      .getPortionRooms()
      .catch(() => {
        fail('Expected resolve promise to return.');
      })
      .then(() => {
        const request = moxios.requests.mostRecent();
        jestExpect(request.config.method).toEqual('get');
        jestExpect(request.config.url).toEqual('/api/rooms');
        jestExpect(request.config.headers).toEqual(
          jestExpect.objectContaining({ 'Content-Type': 'application/json' })
        );
      });
  });

  test('should open portion room for given ids', () => {
    moxios.wait(() => {
      const request = moxios.requests.mostRecent();
      request.respondWith({
        status: 200,
        response: 'data'
      });
    });

    return portionRoomsResources
      .openPortionRoom(3)
      .catch(() => {
        fail('Expected resolve promise to return.');
      })
      .then(() => {
        const request = moxios.requests.mostRecent();
        jestExpect(request.config.method).toEqual('post');
        jestExpect(request.config.url).toEqual('/api/rooms/3/open');
        jestExpect(request.config.headers).toEqual(
          jestExpect.objectContaining({ 'Content-Type': 'application/json' })
        );
      });
  });

  test('should close portion room for given ids', () => {
    moxios.wait(() => {
      const request = moxios.requests.mostRecent();
      request.respondWith({
        status: 200,
        response: 'data'
      });
    });

    return portionRoomsResources
      .closePortionRoom(3, true, false)
      .catch(() => {
        fail('Expected resolve promise to return.');
      })
      .then(() => {
        const request = moxios.requests.mostRecent();
        jestExpect(request.config.method).toEqual('post');
        jestExpect(request.config.url).toEqual('/api/rooms/3/close');
        jestExpect(request.config.params).toEqual({
          unfinishedOrders: true,
          susPoUnavailable: false
        });
        jestExpect(request.config.headers).toEqual(
          jestExpect.objectContaining({ 'Content-Type': 'application/json' })
        );
      });
  });

  test('should get stock allocation alert for given portion room code', () => {
    moxios.wait(() => {
      const request = moxios.requests.mostRecent();
      request.respondWith({
        status: 200,
        response: 'data'
      });
    });

    return portionRoomsResources
      .getStockAllocationAlert('A')
      .catch(() => {
        fail('Expected resolve promise to return.');
      })
      .then(() => {
        const request = moxios.requests.mostRecent();
        jestExpect(request.config.method).toEqual('get');
        jestExpect(request.config.url).toEqual('/api/rooms/A/stock-allocation-alert');
        jestExpect(request.config.headers).toEqual(
          jestExpect.objectContaining({ 'Content-Type': 'application/json' })
        );
      });
  });

  test('should get costing room', () => {
    moxios.wait(() => {
      const request = moxios.requests.mostRecent();
      request.respondWith({
        status: 200,
        response: 'data'
      });
    });

    return portionRoomsResources
      .getCostingRoom()
      .catch(() => {
        fail('Expected resolve promise to return.');
      })
      .then(() => {
        const request = moxios.requests.mostRecent();
        jestExpect(request.config.method).toEqual('get');
        jestExpect(request.config.url).toEqual('/api/rooms/costing');
        jestExpect(request.config.headers).toEqual(
          jestExpect.objectContaining({ 'Content-Type': 'application/json' })
        );
      });
  });
});
