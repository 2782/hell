import moxios from 'moxios';
import costResources from '../costResources';

describe('costResources', () => {
  let successCallback;

  beforeEach(() => {
    successCallback = jest.fn();
    moxios.install();
  });

  afterEach(() => {
    moxios.uninstall();
  });

  test('should get cost by product code', done => {
    costResources.getCostByProductCode('0078889', successCallback);

    moxios.wait(() => {
      let request = moxios.requests.mostRecent();
      request
        .respondWith({
          status: 200,
          response: { cost: 1.2, labor: 3.4 }
        })
        .then(response => {
          jestExpect(successCallback).toHaveBeenCalledWith(response.data);
          jestExpect(request.config).toMatchObject({
            method: 'get',
            url: '/api/cost/0078889',
            headers: { 'Content-Type': 'application/json' }
          });
          done();
        });
    });
  });

  test('should upload cost data', done => {
    const jsonArray = [
      {
        'Source Item': '7203473',
        Cost: '2.35'
      }
    ];

    costResources.uploadCosts(jsonArray);

    moxios.wait(() => {
      let request = moxios.requests.mostRecent();
      request
        .respondWith({
          status: 201,
          response: jsonArray
        })
        .then(() => {
          jestExpect(request.config).toMatchObject({
            method: 'post',
            url: '/api/costs',
            headers: { 'Content-Type': 'application/json' }
          });
          done();
        });
    });
  });
});
