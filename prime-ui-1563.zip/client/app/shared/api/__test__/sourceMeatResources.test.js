import moxios from 'moxios';
import sourceMeatResources from '../sourceMeatResources';

describe('sourceMeatResources', () => {
  let successCallback;

  beforeEach(() => {
    successCallback = jest.fn();
    moxios.install();
  });

  afterEach(() => {
    moxios.uninstall();
  });

  test('should calculate source meat for given cut order ids', done => {
    sourceMeatResources.calcSourceMeat([3, 5, 7], successCallback);

    moxios.wait(() => {
      let request = moxios.requests.mostRecent();
      request.respondWith({ status: 200, response: 'data' }).then(response => {
        jestExpect(successCallback).toHaveBeenCalledWith(response);
        jestExpect(request.config).toMatchObject({
          method: 'get',
          url: '/api/source-meat?cutOrderIds=3,5,7',
          headers: { 'Content-Type': 'application/json' }
        });
        done();
      });
    });
  });

  test('should generate source meat orders', done => {
    sourceMeatResources.generateSourceMeatOrders(
      [
        {
          cutOrderId: 1,
          id: 1,
          unitOfMeasure: 'CASE',
          targetProductCode: 'targetProductCode one',
          targetProductDesc: 'targetProductDesc one',
          productCode: 'productCode one',
          productDesc: 'productDesc one',
          quantity: 12
        },
        {
          cutOrderId: 2,
          id: 2,
          unitOfMeasure: 'CASE',
          targetProductCode: 'targetProductCode two',
          targetProductDesc: 'targetProductDesc two',
          productCode: 'productCode two',
          productDesc: 'productDesc two',
          quantity: 13
        }
      ],
      'A',
      successCallback
    );

    moxios.wait(() => {
      let request = moxios.requests.mostRecent();
      request.respondWith({ status: 200, response: 'data' }).then(() => {
        jestExpect(request.config).toMatchObject({
          method: 'post',
          url: '/api/source-meat',
          params: { roomCode: 'A' },
          headers: { 'Content-Type': 'application/json' },
          data: JSON.stringify([
            {
              cutOrderId: 1,
              id: 1,
              unitOfMeasure: 'CASE',
              targetProductCode: 'targetProductCode one',
              targetProductDesc: 'targetProductDesc one',
              productCode: 'productCode one',
              productDesc: 'productDesc one',
              quantity: 12
            },
            {
              cutOrderId: 2,
              id: 2,
              unitOfMeasure: 'CASE',
              targetProductCode: 'targetProductCode two',
              targetProductDesc: 'targetProductDesc two',
              productCode: 'productCode two',
              productDesc: 'productDesc two',
              quantity: 13
            }
          ])
        });
        done();
      });
    });
  });

  test('should request source meat orders by lbs', done => {
    sourceMeatResources.generateSourceMeatOrders(
      [
        {
          unitOfMeasure: 'LBS',
          productCode: '1234567',
          quantity: 12
        },
        {
          unitOfMeasure: 'LBS',
          productCode: '1234568',
          quantity: 13
        }
      ],
      'A',
      successCallback
    );

    moxios.wait(() => {
      let request = moxios.requests.mostRecent();
      request.respondWith({ status: 200, response: 'data' }).then(() => {
        jestExpect(request.config).toMatchObject({
          method: 'post',
          url: '/api/source-meat/by-lbs',
          params: { roomCode: 'A' },
          headers: { 'Content-Type': 'application/json' },
          data: JSON.stringify([
            {
              unitOfMeasure: 'LBS',
              productCode: '1234567',
              quantity: 12
            },
            {
              unitOfMeasure: 'LBS',
              productCode: '1234568',
              quantity: 13
            }
          ])
        });
        done();
      });
    });
  });

  test('should get source meat order preview for given product info', done => {
    sourceMeatResources.getSourceMeatOrderPreviewByProduct(
      {
        productCode: '0078889',
        portionSize: '12 OZ',
        quantity: 4,
        unitOfMeasure: 'C'
      },
      successCallback
    );

    moxios.wait(() => {
      let request = moxios.requests.mostRecent();
      request.respondWith({ status: 200, response: 'data' }).then(response => {
        jestExpect(successCallback).toHaveBeenCalledWith(response);
        jestExpect(request.config).toMatchObject({
          method: 'get',
          url: '/api/source-meat/preview',
          params: {
            productCode: '0078889',
            portionSize: '12 OZ',
            quantity: 4,
            unitOfMeasure: 'C'
          },
          headers: { 'Content-Type': 'application/json' }
        });
        done();
      });
    });
  });
});
