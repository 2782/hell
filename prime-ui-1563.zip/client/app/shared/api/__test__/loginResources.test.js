import moxios from 'moxios';
import loginResources from '../loginResources';

describe('loginResources', () => {
  beforeEach(() => {
    moxios.install();
  });

  afterEach(() => {
    moxios.uninstall();
  });

  test('should get costing room', () => {
    moxios.wait(() => {
      const request = moxios.requests.mostRecent();
      request.respondWith({
        status: 200,
        response: 'data'
      });
    });

    return loginResources
      .getPrimeUserDetails()
      .catch(() => {
        fail('Expected resolve promise to return.');
      })
      .then(() => {
        const request = moxios.requests.mostRecent();
        jestExpect(request.config.method).toEqual('get');
        jestExpect(request.config.url).toEqual('/api/prime-user-details');
        jestExpect(request.config.headers).toEqual(
          jestExpect.objectContaining({ 'Content-Type': 'application/json' })
        );
      });
  });
});
