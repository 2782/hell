import moxios from 'moxios';
import reportingResources from '../reportingResources';
import {
  CUTTING_STATION_PRODUCTIVITY_REPORT,
  PROFITABILITY_REPORT,
  WEEKLY_RECAP_REPORT
} from '../../../reports/components/reportType';
import { ProductActivitiesFactory } from '../../../../test-factories/productActivity';

describe('reportingResources', () => {
  beforeEach(() => {
    moxios.install();
  });

  afterEach(() => {
    moxios.uninstall();
  });

  describe('reporting event', () => {
    test('should get cutting yield model reporting event', done => {
      reportingResources.getCuttingReportingEvent('6043');

      moxios.wait(() => {
        let request = moxios.requests.mostRecent();
        request
          .respondWith({
            status: 200,
            response: 'data'
          })
          .then(() => {
            jestExpect(request.config).toMatchObject({
              method: 'get',
              url: '/api/cutting-yield-model-reporting-event/6043'
            });
            done();
          });
      });
    });

    test('should get grinding yield model reporting event', done => {
      reportingResources.getGrindingReportingEvent('6043');

      moxios.wait(() => {
        let request = moxios.requests.mostRecent();
        request
          .respondWith({
            status: 200,
            response: 'data'
          })
          .then(() => {
            jestExpect(request.config).toMatchObject({
              method: 'get',
              url: '/api/grinding-yield-model-reporting-event/6043'
            });
            done();
          });
      });
    });
  });

  describe('reports', () => {
    test('should get profitability report for June 22nd, 2018', done => {
      reportingResources.downloadProfitabilityReport({
        reportType: PROFITABILITY_REPORT,
        reportDate: '2018-06-22',
        roomCode: 'B'
      });

      moxios.wait(() => {
        let request = moxios.requests.mostRecent();
        request
          .respondWith({
            status: 200,
            response: 'data'
          })
          .then(() => {
            jestExpect(request.config).toMatchObject({
              responseType: 'arraybuffer',
              method: 'get',
              url: '/metrics/B/profitability/2018-06-22'
            });
            done();
          });
      });
    });

    const stringToArrayBuffer = str => {
      let array = new Int8Array(str.length);
      for (let i = 0; i < str.length; i++) {
        array[i] = str.charCodeAt(i);
      }
      return array.buffer;
    };

    test('should handle error when get profitability report for June 22nd, 2018', done => {
      moxios.wait(() => {
        let request = moxios.requests.mostRecent();
        const data =
          '{"timestamp":1548147930965,"method":"GET","path":"/metrics/B/profitability/2018-06-22","status":422}';
        request
          .respondWith({ status: 422, response: stringToArrayBuffer(data) })
          .then(() => done());
      });

      reportingResources
        .downloadProfitabilityReport({
          reportType: PROFITABILITY_REPORT,
          reportDate: '2018-06-22',
          roomCode: 'B'
        })
        .catch(error => {
          const expected = {
            method: 'GET',
            path: '/metrics/B/profitability/2018-06-22',
            status: 422,
            timestamp: 1548147930965
          };
          jestExpect(error).toEqual(expected);
        });
    });

    test('should get weekly recap report for 2018-08-04', done => {
      reportingResources.downloadWeeklyRecapReport({
        reportType: WEEKLY_RECAP_REPORT,
        reportDate: '2018-08-04'
      });

      moxios.wait(() => {
        let request = moxios.requests.mostRecent();
        request
          .respondWith({
            status: 200,
            response: 'data'
          })
          .then(() => {
            jestExpect(request.config).toMatchObject({
              responseType: 'arraybuffer',
              method: 'get',
              url: '/metrics/weekly-recap/2018-08-04'
            });
            done();
          });
      });
    });

    test('should handle error when  get weekly recap report for 2018-08-04', done => {
      reportingResources.downloadWeeklyRecapReport({
        reportType: WEEKLY_RECAP_REPORT,
        reportDate: '2018-08-04'
      });

      moxios.wait(() => {
        let request = moxios.requests.mostRecent();
        const data =
          '{"timestamp":1548147930965,"method":"GET","path":"/metrics/weekly-recap/2018-08-04","status":422}';
        request.respondWith({ status: 422, response: stringToArrayBuffer(data) }).then(() => {
          jestExpect(request.config).toMatchObject({
            responseType: 'arraybuffer',
            method: 'get',
            url: '/metrics/weekly-recap/2018-08-04'
          });
          done();
        });
      });
    });

    test('should get cutting station productivity report for 2018-09-01', done => {
      reportingResources.downloadCuttingStationProductivityReport({
        reportType: CUTTING_STATION_PRODUCTIVITY_REPORT,
        reportDate: '2018-09-01',
        roomCode: 'B'
      });

      moxios.wait(() => {
        let request = moxios.requests.mostRecent();
        request
          .respondWith({
            status: 200,
            response: 'data'
          })
          .then(() => {
            jestExpect(request.config).toMatchObject({
              responseType: 'arraybuffer',
              method: 'get',
              url: '/metrics/B/cutting-station-productivity/2018-09-01'
            });
            done();
          });
      });
    });

    test('should handle error when get cutting station productivity report for 2018-09-01', done => {
      moxios.wait(() => {
        let request = moxios.requests.mostRecent();
        const data =
          '{"timestamp":1548147930965,"method":"GET","path":"/metrics/B/cutting-station-productivity/2018-09-01","status":422}';
        request
          .respondWith({ status: 422, response: stringToArrayBuffer(data) })
          .then(() => done());
      });

      reportingResources
        .downloadCuttingStationProductivityReport({
          reportType: CUTTING_STATION_PRODUCTIVITY_REPORT,
          reportDate: '2018-09-01',
          roomCode: 'B'
        })
        .catch(error => {
          const expected = {
            method: 'GET',
            path: '/metrics/B/cutting-station-productivity/2018-09-01',
            status: 422,
            timestamp: 1548147930965
          };
          jestExpect(error).toEqual(expected);
        });
    });

    test('should get product in-and-out report for 2018-09', done => {
      reportingResources.downloadProductInAndOutReport({
        reportYearMonth: '2018-09',
        roomCode: 'B'
      });

      moxios.wait(() => {
        let request = moxios.requests.mostRecent();
        request
          .respondWith({
            status: 200,
            response: 'data'
          })
          .then(() => {
            jestExpect(request.config).toMatchObject({
              responseType: 'arraybuffer',
              method: 'get',
              url: '/metrics/B/product-in-out/2018-09'
            });
            done();
          });
      });
    });

    test('should get yield cost summary report for 2018-09-16', done => {
      reportingResources.downloadYieldCostSummaryReport({
        reportDate: '2018-09-16'
      });

      moxios.wait(() => {
        let request = moxios.requests.mostRecent();
        request
          .respondWith({
            status: 200,
            response: 'data'
          })
          .then(() => {
            jestExpect(request.config).toMatchObject({
              responseType: 'arraybuffer',
              method: 'get',
              url: '/metrics/yield-cost-summary/2018-09-16'
            });
            done();
          });
      });
    });

    test('should handle error when get yield cost summary report for 2018-09-16', done => {
      reportingResources.downloadYieldCostSummaryReport({
        reportDate: '2018-09-16'
      });

      moxios.wait(() => {
        let request = moxios.requests.mostRecent();
        const data =
          '{"timestamp":1548147930965,"method":"GET","path":"/metrics/yield-cost-summary/2018-09-16","status":422}';
        request.respondWith({ status: 422, response: stringToArrayBuffer(data) }).then(() => {
          jestExpect(request.config).toMatchObject({
            responseType: 'arraybuffer',
            method: 'get',
            url: '/metrics/yield-cost-summary/2018-09-16'
          });
          done();
        });
      });
    });

    test('should get house par report for 2018-12-04', done => {
      reportingResources.downloadHouseParReport({
        reportDate: '2018-12-04'
      });

      moxios.wait(() => {
        let request = moxios.requests.mostRecent();
        request
          .respondWith({
            status: 200,
            response: 'data'
          })
          .then(() => {
            jestExpect(request.config).toMatchObject({
              responseType: 'arraybuffer',
              method: 'get',
              url: '/metrics/house-par/2018-12-04'
            });
            done();
          });
      });
    });

    test('should handle error when  get house par report for 2018-12-04', done => {
      reportingResources.downloadHouseParReport({
        reportDate: '2018-12-04'
      });

      moxios.wait(() => {
        let request = moxios.requests.mostRecent();
        const data =
          '{"timestamp":1548147930965,"method":"GET","path":"/metrics/house-par/2018-12-04","status":422}';
        request.respondWith({ status: 422, response: stringToArrayBuffer(data) }).then(() => {
          jestExpect(request.config).toMatchObject({
            responseType: 'arraybuffer',
            method: 'get',
            url: '/metrics/house-par/2018-12-04'
          });
          done();
        });
      });
    });

    test('should get scale summary report from 2018-12-04 to 2018-12-06', done => {
      reportingResources.downloadScaleSummary({
        reportDate: '2018-12-04',
        endDate: '2018-12-06'
      });

      moxios.wait(() => {
        let request = moxios.requests.mostRecent();
        request
          .respondWith({
            status: 200,
            response: 'data'
          })
          .then(() => {
            jestExpect(request.config).toMatchObject({
              responseType: 'arraybuffer',
              method: 'get',
              url: '/metrics/scale-summary',
              params: {
                endDate: '2018-12-06',
                startDate: '2018-12-04'
              }
            });
            done();
          });
      });
    });

    test('should handle error when get scale summary report from 2018-12-04 to 2018-12-06', done => {
      reportingResources.downloadScaleSummary({
        reportDate: '2018-12-06',
        startDate: '2018-12-04'
      });

      moxios.wait(() => {
        let request = moxios.requests.mostRecent();
        const data =
          '{"timestamp":1548147930965,"method":"GET","path":"/metrics/scale-summary","status":422}';
        request.respondWith({ status: 422, response: stringToArrayBuffer(data) }).then(() => {
          jestExpect(request.config).toMatchObject({
            responseType: 'arraybuffer',
            method: 'get',
            url: '/metrics/scale-summary'
          });
          done();
        });
      });
    });

    test('should get wip spoil report from 2018-12-04 to 2018-12-06', done => {
      reportingResources.downloadWipSpoil({
        reportDate: '2018-12-04',
        endDate: '2018-12-06'
      });

      moxios.wait(() => {
        let request = moxios.requests.mostRecent();
        request
          .respondWith({
            status: 200,
            response: 'data'
          })
          .then(() => {
            jestExpect(request.config).toMatchObject({
              responseType: 'arraybuffer',
              method: 'get',
              url: '/metrics/wip-spoil',
              params: {
                endDate: '2018-12-06',
                startDate: '2018-12-04'
              }
            });
            done();
          });
      });
    });

    test('should handle error when get wip spoil report from 2018-12-04 to 2018-12-06', done => {
      reportingResources.downloadWipSpoil({
        reportDate: '2018-12-06',
        startDate: '2018-12-04'
      });

      moxios.wait(() => {
        let request = moxios.requests.mostRecent();
        const data =
          '{"timestamp":1548147930965,"method":"GET","path":"/metrics/wip-spoil","status":422}';
        request.respondWith({ status: 422, response: stringToArrayBuffer(data) }).then(() => {
          jestExpect(request.config).toMatchObject({
            responseType: 'arraybuffer',
            method: 'get',
            url: '/metrics/wip-spoil'
          });
          done();
        });
      });
    });
  });

  describe('Product Activity Resources', () => {
    test('should build out query for individual customer boxes with sort applied', done => {
      const productActivity = ProductActivitiesFactory.build({
        productCode: '2857102',
        customerOrderNumber: '012',
        tableCode: 91,
        packoffStationName: 'BRAINS',
        workingDate: '2018-09-28'
      });

      reportingResources.getCustomerBoxes({
        sortColumn: 'COLUMN_TO_SORT',
        sortDirection: 'COLUMN_SORT_DIRECTION',
        page: 7,
        ...productActivity
      });

      moxios.wait(() => {
        let request = moxios.requests.mostRecent();
        request
          .respondWith({
            status: 200,
            response: 'data'
          })
          .then(() => {
            jestExpect(request.config).toMatchObject({
              params: {
                productCode: productActivity.productCode,
                packoffStationName: productActivity.packoffStationName,
                tableCode: productActivity.tableCode,
                customerOrderNumber: productActivity.customerOrderNumber,
                workingDate: productActivity.workingDate,
                sort: 'COLUMN_TO_SORT,COLUMN_SORT_DIRECTION',
                size: 20,
                page: 7
              },
              method: 'get',
              url: '/api/product-activities/search/packoff/boxes'
            });
            done();
          });
      });
    });

    test('should build out query for individual customer boxes', done => {
      const productActivity = ProductActivitiesFactory.build({
        productCode: '2857102',
        customerOrderNumber: '012',
        tableCode: 91,
        packoffStationName: 'BRAINS',
        workingDate: '2018-09-28'
      });

      reportingResources.getCustomerBoxes({ ...productActivity });

      moxios.wait(() => {
        let request = moxios.requests.mostRecent();
        request
          .respondWith({
            status: 200,
            response: 'data'
          })
          .then(() => {
            jestExpect(request.config).toMatchObject({
              params: {
                productCode: productActivity.productCode,
                packoffStationName: productActivity.packoffStationName,
                tableCode: productActivity.tableCode,
                customerOrderNumber: productActivity.customerOrderNumber,
                workingDate: productActivity.workingDate,
                sort: 'createdAt,desc',
                size: 20,
                page: 0
              },
              method: 'get',
              url: '/api/product-activities/search/packoff/boxes'
            });
            done();
          });
      });
    });

    test('should build out query for individual finished stock boxes with sort applied', done => {
      const productActivity = ProductActivitiesFactory.build({
        incomplete: false,
        productCode: '2857102',
        roomCode: 'A',
        packoffStationName: 'ALEX',
        workingDate: '2018-09-28',
        page: 0
      });

      reportingResources.getStockWipBoxesForFinished({
        sortColumn: 'COLUMN_TO_SORT',
        sortDirection: 'COLUMN_SORT_DIRECTION',
        ...productActivity
      });

      moxios.wait(() => {
        let request = moxios.requests.mostRecent();
        request
          .respondWith({
            status: 200,
            response: 'data'
          })
          .then(() => {
            jestExpect(request.config).toMatchObject({
              params: {
                roomCode: productActivity.roomCode,
                productCode: productActivity.productCode,
                packoffStationName: productActivity.packoffStationName,
                workingDate: productActivity.workingDate,
                incomplete: productActivity.incomplete,
                sort: 'COLUMN_TO_SORT,COLUMN_SORT_DIRECTION',
                size: 20,
                page: 0
              },
              method: 'get',
              url: '/api/product-activities/search/stock-wip/finished/boxes'
            });
            done();
          });
      });
    });

    test('should build out query for individual finished stock boxes', done => {
      const productActivity = ProductActivitiesFactory.build({
        incomplete: false,
        productCode: '2857102',
        roomCode: 'A',
        packoffStationName: 'JOHN',
        workingDate: '2018-09-28'
      });

      reportingResources.getStockWipBoxesForFinished({ ...productActivity });

      moxios.wait(() => {
        let request = moxios.requests.mostRecent();
        request
          .respondWith({
            status: 200,
            response: 'data'
          })
          .then(() => {
            jestExpect(request.config).toMatchObject({
              params: {
                roomCode: productActivity.roomCode,
                productCode: productActivity.productCode,
                workingDate: productActivity.workingDate,
                packoffStationName: productActivity.packoffStationName,
                incomplete: productActivity.incomplete,
                size: 20,
                page: 0,
                sort: 'createdAt,desc'
              },
              method: 'get',
              url: '/api/product-activities/search/stock-wip/finished/boxes'
            });
            done();
          });
      });
    });

    test('should query for individual source WIP boxes with sort applied', done => {
      const productActivity = {
        roomCode: 'A',
        productCode: '2111148',
        packoffStationName: 'JOHN',
        workingDate: '2018-09-28'
      };
      reportingResources.getWipBoxesForSource({
        page: 12,
        sortColumn: 'COLUMN_TO_SORT',
        sortDirection: 'COLUMN_SORT_DIRECTION',
        ...productActivity
      });

      moxios.wait(() => {
        let request = moxios.requests.mostRecent();
        request
          .respondWith({
            status: 200,
            response: 'data'
          })
          .then(() => {
            jestExpect(request.config).toMatchObject({
              params: {
                roomCode: productActivity.roomCode,
                productCode: productActivity.productCode,
                workingDate: productActivity.workingDate,
                packoffStationName: productActivity.packoffStationName,
                page: 12,
                size: 20,
                sort: 'COLUMN_TO_SORT,COLUMN_SORT_DIRECTION'
              },
              method: 'get',
              url: '/api/product-activities/search/wip/source/boxes'
            });
            done();
          });
      });
    });

    test('should query for individual source WIP boxes', done => {
      const productActivity = {
        roomCode: 'A',
        productCode: '2111148',
        packoffStationName: 'JOHN',
        workingDate: '2018-09-28'
      };
      reportingResources.getWipBoxesForSource({ ...productActivity });

      moxios.wait(() => {
        let request = moxios.requests.mostRecent();
        request
          .respondWith({
            status: 200,
            response: 'data'
          })
          .then(() => {
            jestExpect(request.config).toMatchObject({
              params: {
                roomCode: productActivity.roomCode,
                productCode: productActivity.productCode,
                workingDate: productActivity.workingDate,
                packoffStationName: productActivity.packoffStationName,
                size: 20,
                page: 0,
                sort: 'createdAt,desc'
              },
              method: 'get',
              url: '/api/product-activities/search/wip/source/boxes'
            });
            done();
          });
      });
    });

    test('should query for individual source WIP boxes with sort applied', done => {
      const productActivity = {
        roomCode: 'A',
        productCode: '2111148',
        workingDate: '2018-09-28',
        packoffStationName: 'ALEX'
      };
      reportingResources.getWipBoxesForSource({
        page: 12,
        sortColumn: 'COLUMN_TO_SORT',
        sortDirection: 'COLUMN_SORT_DIRECTION',
        ...productActivity
      });

      moxios.wait(() => {
        let request = moxios.requests.mostRecent();
        request
          .respondWith({
            status: 200,
            response: 'data'
          })
          .then(() => {
            jestExpect(request.config).toMatchObject({
              params: {
                roomCode: productActivity.roomCode,
                productCode: productActivity.productCode,
                packoffStationName: productActivity.packoffStationName,
                workingDate: productActivity.workingDate,
                page: 12,
                size: 20,
                sort: 'COLUMN_TO_SORT,COLUMN_SORT_DIRECTION'
              },
              method: 'get',
              url: '/api/product-activities/search/wip/source/boxes'
            });
            done();
          });
      });
    });

    test('should search all product activity with sort applied', done => {
      reportingResources.getProductActivities({
        productCode: '1234567',
        startDate: '2018-12-05',
        endDate: '2018-12-05',
        page: 12,
        sortColumn: 'COLUMN_TO_SORT',
        sortDirection: 'COLUMN_SORT_DIRECTION'
      });

      moxios.wait(() => {
        let request = moxios.requests.mostRecent();
        request
          .respondWith({
            status: 200,
            response: 'data'
          })
          .then(() => {
            jestExpect(request.config).toMatchObject({
              method: 'get',
              url: '/api/product-activities/1234567',
              params: {
                startDate: '2018-12-05',
                endDate: '2018-12-05',
                page: 12,
                size: 20,
                sort: 'COLUMN_TO_SORT,COLUMN_SORT_DIRECTION'
              }
            });
            done();
          });
      });
    });
  });
});
