import settingsResources from '../settingsResources';
import moxios from 'moxios';

describe('settingsResources', () => {
  let successCallback, errorCallback;

  beforeEach(() => {
    successCallback = jest.fn();
    errorCallback = jest.fn();
    moxios.install();
  });

  afterEach(() => {
    moxios.uninstall();
  });

  test('should get rooms for room maintenance page', done => {
    settingsResources.getRooms();

    moxios.wait(() => {
      let request = moxios.requests.mostRecent();
      request
        .respondWith({
          status: 200,
          response: 'data'
        })
        .then(() => {
          jestExpect(request.config).toMatchObject({
            method: 'get',
            url: '/api/rooms',
            headers: { 'Content-Type': 'application/json' }
          });
          done();
        });
    });
  });

  test('should get holidays for weekend/holiday settings page', done => {
    settingsResources.getHolidays(successCallback);

    moxios.wait(() => {
      let request = moxios.requests.mostRecent();
      request.respondWith({ status: 200, response: 'data' }).then(response => {
        jestExpect(successCallback).toHaveBeenCalledWith(response);
        jestExpect(request.config).toMatchObject({
          method: 'get',
          url: '/api/holidays',
          headers: { 'Content-Type': 'application/json' }
        });
        done();
      });
    });
  });

  test('should create holidays for weekend/holiday settings page', done => {
    settingsResources.createHoliday(
      { date: '2018-01-01', description: 'New Year Day' },
      successCallback,
      errorCallback
    );

    moxios.wait(() => {
      let request = moxios.requests.mostRecent();
      request.respondWith({ status: 200, response: 'data' }).then(response => {
        jestExpect(successCallback).toHaveBeenCalledWith(response);
        jestExpect(errorCallback).not.toHaveBeenCalled();
        jestExpect(request.config).toMatchObject({
          method: 'post',
          url: '/api/holiday',
          headers: { 'Content-Type': 'application/json' }
        });
        done();
      });
    });
  });

  test('should handle error when create holidays fails', done => {
    settingsResources.createHoliday(
      { date: '2018-01-01', description: 'New Year Day' },
      successCallback,
      errorCallback
    );

    moxios.wait(() => {
      let request = moxios.requests.mostRecent();
      request.respondWith({ status: 422 }).then(() => {
        jestExpect(successCallback).not.toHaveBeenCalled();
        jestExpect(errorCallback).toHaveBeenCalledWith({
          showing: true,
          message: 'Please provide a valid date'
        });
        done();
      });
    });
  });

  test('should delete holiday for weekend/holiday settings page', done => {
    settingsResources.deleteHoliday(1, successCallback);

    moxios.wait(() => {
      let request = moxios.requests.mostRecent();
      request.respondWith({ status: 200, response: 'data' }).then(() => {
        jestExpect(successCallback).toHaveBeenCalled();
        jestExpect(request.config).toMatchObject({ method: 'delete', url: '/api/holiday/1' });
        done();
      });
    });
  });

  test('should get weekends for weekend/holiday settings page', done => {
    settingsResources.getWeekends(successCallback);

    moxios.wait(() => {
      let request = moxios.requests.mostRecent();
      request
        .respondWith({
          status: 200,
          response: [
            {
              id: 2,
              configGroup: 'GROUP_WEEKEND_OPEN_PORTION_ROOM',
              key: 'sunday',
              value: 'true',
              description: 'allow sunday to open portion room'
            },
            {
              id: 1,
              configGroup: 'GROUP_WEEKEND_OPEN_PORTION_ROOM',
              key: 'saturday',
              value: 'true',
              description: 'allow saturday to open portion room'
            }
          ]
        })
        .then(() => {
          jestExpect(successCallback).toHaveBeenCalledWith([
            {
              id: 1,
              configGroup: 'GROUP_WEEKEND_OPEN_PORTION_ROOM',
              key: 'saturday',
              value: true,
              description: 'allow saturday to open portion room'
            },
            {
              id: 2,
              configGroup: 'GROUP_WEEKEND_OPEN_PORTION_ROOM',
              key: 'sunday',
              value: true,
              description: 'allow sunday to open portion room'
            }
          ]);
          jestExpect(request.config).toMatchObject({
            method: 'get',
            url: '/api/system-configs',
            headers: { 'Content-Type': 'application/json' },
            params: {
              'config-group': 'GROUP_WEEKEND_OPEN_PORTION_ROOM'
            }
          });
          done();
        });
    });
  });

  test('should update weekends for weekend/holiday settings page', done => {
    settingsResources.updateSystemConfig(
      {
        id: 2,
        configGroup: 'GROUP_WEEKEND_OPEN_PORTION_ROOM',
        key: 'sunday',
        value: false,
        description: 'allow sunday to open portion room'
      },
      successCallback
    );

    moxios.wait(() => {
      let request = moxios.requests.mostRecent();
      request
        .respondWith({
          status: 200,
          response: [
            {
              id: 1,
              configGroup: 'GROUP_WEEKEND_OPEN_PORTION_ROOM',
              key: 'saturday',
              value: 'true',
              description: 'allow saturday to open portion room'
            },
            {
              id: 2,
              configGroup: 'GROUP_WEEKEND_OPEN_PORTION_ROOM',
              key: 'sunday',
              value: 'false',
              description: 'allow sunday to open portion room'
            }
          ]
        })
        .then(() => {
          jestExpect(successCallback).toHaveBeenCalledWith([
            {
              id: 1,
              configGroup: 'GROUP_WEEKEND_OPEN_PORTION_ROOM',
              key: 'saturday',
              value: true,
              description: 'allow saturday to open portion room'
            },
            {
              id: 2,
              configGroup: 'GROUP_WEEKEND_OPEN_PORTION_ROOM',
              key: 'sunday',
              value: false,
              description: 'allow sunday to open portion room'
            }
          ]);
          jestExpect(request.config).toMatchObject({
            method: 'put',
            url: '/api/system-configs/2',
            headers: { 'Content-Type': 'application/json' }
          });
          done();
        });
    });
  });

  test('should get stations for station maintenance page', done => {
    settingsResources.getStations(successCallback);

    moxios.wait(() => {
      let request = moxios.requests.mostRecent();
      request.respondWith({ status: 200, response: 'data' }).then(response => {
        jestExpect(successCallback).toHaveBeenCalledWith(response);
        jestExpect(request.config).toMatchObject({
          method: 'get',
          url: '/api/stations',
          headers: { 'Content-Type': 'application/json' }
        });
        done();
      });
    });
  });

  test('should get tables for table maintenance page', done => {
    settingsResources.getTables(successCallback);

    moxios.wait(() => {
      let request = moxios.requests.mostRecent();
      request.respondWith({ status: 200, response: 'data' }).then(response => {
        jestExpect(successCallback).toHaveBeenCalledWith(response);
        jestExpect(request.config).toMatchObject({
          method: 'get',
          url: '/api/portion-room-tables',
          headers: { 'Content-Type': 'application/json' }
        });
        done();
      });
    });
  });

  test('should get one table for table edit page', done => {
    settingsResources.getTable(1, successCallback);

    moxios.wait(() => {
      let request = moxios.requests.mostRecent();
      request.respondWith({ status: 200, response: 'data' }).then(response => {
        jestExpect(successCallback).toHaveBeenCalledWith(response);
        jestExpect(request.config).toMatchObject({
          method: 'get',
          url: '/api/portion-room-tables/1',
          headers: { 'Content-Type': 'application/json' }
        });
        done();
      });
    });
  });

  test('should get profile for change profile page', done => {
    settingsResources.getProfile(successCallback);

    moxios.wait(() => {
      let request = moxios.requests.mostRecent();
      request.respondWith({ status: 200, response: 'data' }).then(response => {
        jestExpect(successCallback).toHaveBeenCalledWith(response);
        jestExpect(request.config).toMatchObject({
          method: 'get',
          url: '/api/profile',
          headers: { 'Content-Type': 'application/json' }
        });
        done();
      });
    });
  });

  test('should get one station for station edit page', done => {
    settingsResources.getStation(1, successCallback);

    moxios.wait(() => {
      let request = moxios.requests.mostRecent();
      request.respondWith({ status: 200, response: 'data' }).then(response => {
        jestExpect(successCallback).toHaveBeenCalledWith(response);
        jestExpect(request.config).toMatchObject({
          method: 'get',
          url: '/api/stations/1',
          headers: { 'Content-Type': 'application/json' }
        });
        done();
      });
    });
  });

  test('should create room with given code and description', done => {
    settingsResources.createRoom(
      { code: 'A', description: 'Portion Room A' },
      successCallback,
      errorCallback
    );

    moxios.wait(() => {
      let request = moxios.requests.mostRecent();
      request.respondWith({ status: 204 }).then(response => {
        jestExpect(successCallback).toHaveBeenCalledWith(response);
        jestExpect(errorCallback).not.toHaveBeenCalled();
        jestExpect(request.config).toMatchObject({
          method: 'post',
          url: '/api/rooms',
          headers: { 'Content-Type': 'application/json' },
          data: JSON.stringify({ code: 'A', description: 'Portion Room A' })
        });
        done();
      });
    });
  });

  test('should handle error when creating room fails', done => {
    settingsResources.createRoom(
      { code: 'ABC', description: 'Portion Room A' },
      successCallback,
      errorCallback
    );

    moxios.wait(() => {
      let request = moxios.requests.mostRecent();
      request.respondWith({ status: 422 }).then(() => {
        jestExpect(successCallback).not.toHaveBeenCalled();
        jestExpect(errorCallback).toHaveBeenCalled();
        done();
      });
    });
  });

  test('should create house par with given productCode and config values', done => {
    settingsResources.createHousePar(
      { productCode: '0079007', monday: 1 },
      successCallback,
      errorCallback
    );

    moxios.wait(() => {
      let request = moxios.requests.mostRecent();
      request.respondWith({ status: 201 }).then(response => {
        jestExpect(successCallback).toHaveBeenCalledWith(response);
        jestExpect(errorCallback).not.toHaveBeenCalled();
        jestExpect(request.config).toMatchObject({
          method: 'post',
          url: '/api/house-pars',
          headers: { 'Content-Type': 'application/json' },
          data: JSON.stringify({
            productCode: '0079007',
            monday: 1
          })
        });
        done();
      });
    });
  });

  test('should update house par with given productCode and config values', done => {
    settingsResources.updateHousePar(
      { productCode: '0079007', monday: 1, id: 1 },
      successCallback,
      errorCallback
    );

    moxios.wait(() => {
      let request = moxios.requests.mostRecent();
      request.respondWith({ status: 201 }).then(response => {
        jestExpect(successCallback).toHaveBeenCalledWith(response);
        jestExpect(errorCallback).not.toHaveBeenCalled();
        jestExpect(request.config).toMatchObject({
          method: 'put',
          url: '/api/house-pars/1',
          headers: { 'Content-Type': 'application/json' },
          data: JSON.stringify({ productCode: '0079007', monday: 1, id: 1 })
        });
        done();
      });
    });
  });

  test('should handle error when creating house par fails', done => {
    settingsResources.createHousePar(
      { productCode: '0079007', monday: 1 },
      successCallback,
      errorCallback
    );

    moxios.wait(() => {
      let request = moxios.requests.mostRecent();
      request.respondWith({ status: 422 }).then(() => {
        jestExpect(successCallback).not.toHaveBeenCalled();
        jestExpect(errorCallback).toHaveBeenCalled();
        done();
      });
    });
  });

  test('should create table with given code and description', done => {
    let tableData = {
      tableCode: 11,
      tableDescription: 'Portion Room Table AB',
      station: { id: 123 }
    };
    settingsResources.createTable(tableData);

    moxios.wait(() => {
      let request = moxios.requests.mostRecent();
      request
        .respondWith({
          status: 204,
          response: {
            data: JSON.stringify(tableData)
          }
        })
        .then(() => {
          jestExpect(request.config).toMatchObject({
            method: 'post',
            url: '/api/portion-room-tables',
            headers: { 'Content-Type': 'application/json' }
          });
          done();
        });
    });
  });

  test('should update table with given code and description', done => {
    let existingTableData = {
      tableCode: 11,
      tableDescription: 'Portion Room Table AB',
      station: { id: 123 }
    };
    settingsResources.updateTable(111, existingTableData);

    moxios.wait(() => {
      let request = moxios.requests.mostRecent();
      request.respondWith({ status: 200 }).then(() => {
        jestExpect(request.config).toMatchObject({
          method: 'put',
          url: '/api/portion-room-tables/111',
          headers: { 'Content-Type': 'application/json' }
        });
        done();
      });
    });
  });

  test('should update company profile with given profile info', done => {
    settingsResources.createOrUpdateProfile(
      {
        plantNumber: '123',
        name: 'Sysco & newport',
        address: "dont't know",
        city: 'Culver',
        state: 'AL',
        zipCode: '90230',
        establishmentNumber: '4195'
      },
      successCallback,
      errorCallback
    );

    moxios.wait(() => {
      let request = moxios.requests.mostRecent();
      request.respondWith({ status: 201 }).then(response => {
        jestExpect(successCallback).toHaveBeenCalledWith(response);
        jestExpect(errorCallback).not.toHaveBeenCalled();
        jestExpect(request.config).toMatchObject({
          method: 'post',
          url: '/api/profile',
          headers: { 'Content-Type': 'application/json' },
          data: JSON.stringify({
            plantNumber: '123',
            name: 'Sysco & newport',
            address: "dont't know",
            city: 'Culver',
            state: 'AL',
            zipCode: '90230',
            establishmentNumber: '4195'
          })
        });
        done();
      });
    });
  });

  test('should create station with given code, name, and room', done => {
    settingsResources.createStation(
      { stationCode: '11', name: 'PORK', room: 'A' },
      successCallback,
      errorCallback
    );

    moxios.wait(() => {
      let request = moxios.requests.mostRecent();
      request.respondWith({ status: 204 }).then(response => {
        jestExpect(successCallback).toHaveBeenCalledWith(response);
        jestExpect(errorCallback).not.toHaveBeenCalled();
        jestExpect(request.config).toMatchObject({
          method: 'post',
          url: '/api/stations',
          headers: { 'Content-Type': 'application/json' },
          data: JSON.stringify({
            stationCode: '11',
            name: 'PORK',
            room: 'A'
          })
        });
        done();
      });
    });
  });

  test('should handle error when creating station fails', done => {
    settingsResources.createStation(
      {
        stationNumber: '11',
        name: 'PORK',
        room: 'A'
      },
      successCallback,
      errorCallback
    );

    moxios.wait(() => {
      let request = moxios.requests.mostRecent();
      request
        .respondWith({
          status: 422
        })
        .then(() => {
          jestExpect(successCallback).not.toHaveBeenCalled();
          jestExpect(errorCallback).toHaveBeenCalled();
          done();
        });
    });
  });

  test('should update station with given code, name, and room for station with stationId', done => {
    settingsResources.updateStation(
      { id: 12, stationCode: '11', name: 'PORK', room: 'A' },
      successCallback,
      errorCallback
    );

    moxios.wait(() => {
      let request = moxios.requests.mostRecent();
      request.respondWith({ status: 204 }).then(response => {
        jestExpect(successCallback).toHaveBeenCalledWith(response);
        jestExpect(errorCallback).not.toHaveBeenCalled();
        jestExpect(request.config).toMatchObject({
          method: 'put',
          url: '/api/stations/12',
          headers: { 'Content-Type': 'application/json' },
          data: JSON.stringify({
            id: 12,
            stationCode: '11',
            name: 'PORK',
            room: 'A'
          })
        });
        done();
      });
    });
  });

  test('should handle error when creating station fails', done => {
    settingsResources.updateStation(
      { id: 13, stationNumber: '11', name: 'PORK', room: 'A' },
      successCallback,
      errorCallback
    );

    moxios.wait(() => {
      let request = moxios.requests.mostRecent();
      request.respondWith({ status: 422 }).then(() => {
        jestExpect(successCallback).not.toHaveBeenCalled();
        jestExpect(errorCallback).toHaveBeenCalled();
        done();
      });
    });
  });

  test('should get house pars', done => {
    settingsResources.getHousePars(successCallback);

    moxios.wait(() => {
      let request = moxios.requests.mostRecent();
      request.respondWith({ status: 200, response: 'data' }).then(response => {
        jestExpect(successCallback).toHaveBeenCalledWith(response);
        jestExpect(request.config).toMatchObject({
          method: 'get',
          url: '/api/house-pars',
          headers: { 'Content-Type': 'application/json' }
        });
        done();
      });
    });
  });

  test('should get house par', done => {
    settingsResources.getHousePar('0079007', successCallback);

    moxios.wait(() => {
      let request = moxios.requests.mostRecent();
      request.respondWith({ status: 200, response: 'data' }).then(response => {
        jestExpect(successCallback).toHaveBeenCalledWith(response);
        jestExpect(request.config).toMatchObject({
          method: 'get',
          url: '/api/house-par/0079007',
          headers: { 'Content-Type': 'application/json' }
        });
        done();
      });
    });
  });

  test('should delete house par', done => {
    settingsResources.deleteHousePar('0078889', successCallback);

    moxios.wait(() => {
      let request = moxios.requests.mostRecent();
      request.respondWith({ status: 200, response: 'data' }).then(response => {
        jestExpect(successCallback).toHaveBeenCalledWith(response);
        jestExpect(request.config).toMatchObject({
          method: 'delete',
          url: '/api/house-par/0078889',
          headers: { 'Content-Type': 'application/json' }
        });
        done();
      });
    });
  });

  test('should get grinding house pars', done => {
    settingsResources.getAvailableGrindingHousePar('D', successCallback);

    moxios.wait(() => {
      let request = moxios.requests.mostRecent();
      request.respondWith({ status: 200, response: 'data' }).then(response => {
        jestExpect(successCallback).toHaveBeenCalledWith(response);
        jestExpect(request.config).toMatchObject({
          method: 'get',
          url: '/api/house-pars/grinding',
          params: { 'room-code': 'D' },
          headers: { 'Content-Type': 'application/json' }
        });
        done();
      });
    });
  });

  test('should get all customers', done => {
    settingsResources.getCustomers();

    moxios.wait(() => {
      let request = moxios.requests.mostRecent();
      request.respondWith({ status: 200, response: 'data' }).then(() => {
        jestExpect(request.config).toMatchObject({
          method: 'get',
          url: '/api/customers',
          headers: { 'Content-Type': 'application/json' }
        });
        done();
      });
    });
  });

  test('should get customer by customer code', done => {
    settingsResources.getCustomer('000170');

    moxios.wait(() => {
      let request = moxios.requests.mostRecent();
      request.respondWith({ status: 200, response: 'data' }).then(() => {
        jestExpect(request.config).toMatchObject({
          method: 'get',
          url: '/api/customers/000170',
          headers: { 'Content-Type': 'application/json' }
        });
        done();
      });
    });
  });

  global.FormData = function() {
    this.append = jest.fn();
  };

  global.Blob = function(content, options) {
    return { content, options };
  };

  test('should setup customer', done => {
    const customer = { customerCode: '123456', bestBy: 10 };
    const logoFile = 'data';

    settingsResources.setupCustomer(customer, logoFile);

    var formData = new FormData();
    formData.append(
      'data',
      new Blob([JSON.stringify(customer)], {
        type: 'application/json'
      })
    );
    formData.append('file', logoFile);

    moxios.wait(() => {
      let request = moxios.requests.mostRecent();
      request.respondWith({ status: 200, response: 'data' }).then(() => {
        jestExpect(request.config.headers).toMatchObject({
          Accept: 'application/json, ' + 'text/plain, */*',
          'Content-Type': 'undefined'
        });
        done();
      });
    });
  });

  test('should get subPrimal by subPrimalCode', done => {
    settingsResources.getSubPrimal('123', successCallback, errorCallback);

    moxios.wait(() => {
      let request = moxios.requests.mostRecent();
      request.respondWith({ status: 200, response: 'data' }).then(response => {
        jestExpect(successCallback).toHaveBeenCalledWith(response);

        jestExpect(request.config).toMatchObject({
          method: 'get',
          url: '/api/products/sub-primal',
          params: { 'sub-primal-code': '123' },
          headers: { 'Content-Type': 'application/json' }
        });
        done();
      });
    });
  });
});
