import moxios from 'moxios';
import batchResources from '../batchResources';
import BatchFactory from '../../../../test-factories/batch';

const batch = BatchFactory.build();

describe('batchResources', () => {
  let successCallback, errorCallback;

  beforeEach(() => {
    successCallback = jest.fn();
    errorCallback = jest.fn();
    moxios.install();
  });

  afterEach(() => {
    moxios.uninstall();
  });

  test('should create batch successfully', done => {
    batchResources.create(batch, successCallback, errorCallback);

    moxios.wait(() => {
      let request = moxios.requests.mostRecent();
      request.respondWith({ status: 201 }).then(() => {
        jestExpect(request.config).toMatchObject({
          method: 'post',
          url: '/api/batches'
        });

        jestExpect(successCallback).toHaveBeenCalledTimes(1);
        jestExpect(errorCallback).not.toHaveBeenCalled();
        done();
      });
    });
  });

  test('should handle error when create batch failed', done => {
    batchResources.create(batch, successCallback, errorCallback);

    moxios.wait(() => {
      let request = moxios.requests.mostRecent();
      request.respondWith({ status: 422, response: {} }).then(() => {
        jestExpect(request.config).toMatchObject({
          method: 'post',
          url: '/api/batches'
        });

        jestExpect(successCallback).not.toHaveBeenCalled();
        jestExpect(errorCallback).toHaveBeenCalledWith({ message: 'Create Batch Failed.' });
        done();
      });
    });
  });

  test('should update batch successfully', done => {
    batchResources.update(batch, successCallback, errorCallback);

    moxios.wait(() => {
      let request = moxios.requests.mostRecent();
      request.respondWith({ status: 201 }).then(() => {
        jestExpect(request.config).toMatchObject({
          method: 'put',
          url: `/api/batches/${batch.id}`
        });

        jestExpect(successCallback).toHaveBeenCalledTimes(1);
        jestExpect(errorCallback).not.toHaveBeenCalled();
        done();
      });
    });
  });

  test('should handle error when update batch failed', done => {
    batchResources.update(batch, successCallback, errorCallback);

    moxios.wait(() => {
      let request = moxios.requests.mostRecent();
      request.respondWith({ status: 422, response: {} }).then(() => {
        jestExpect(request.config).toMatchObject({
          method: 'put',
          url: `/api/batches/${batch.id}`
        });
        jestExpect(successCallback).not.toHaveBeenCalled();
        jestExpect(errorCallback).toHaveBeenCalledWith({ message: 'Create Batch Failed.' });
        done();
      });
    });
  });

  test('should finish grind batch successfully', done => {
    batchResources.finishGrind(batch, successCallback, errorCallback);

    moxios.wait(() => {
      let request = moxios.requests.mostRecent();
      request.respondWith({ status: 201 }).then(() => {
        jestExpect(request.config).toMatchObject({
          method: 'post',
          url: '/api/batches/grind/finish'
        });
        jestExpect(successCallback).toHaveBeenCalledTimes(1);
        jestExpect(errorCallback).not.toHaveBeenCalled();
        done();
      });
    });
  });

  test('should handle error when finish grind batch failed', done => {
    batchResources.finishGrind(batch, successCallback, errorCallback);

    moxios.wait(() => {
      let request = moxios.requests.mostRecent();
      request.respondWith({ status: 422, response: {} }).then(() => {
        jestExpect(request.config).toMatchObject({
          method: 'post',
          url: '/api/batches/grind/finish'
        });
        jestExpect(successCallback).not.toHaveBeenCalled();
        jestExpect(errorCallback).toHaveBeenCalledWith({ message: 'Finish Batch Failed.' });
        done();
      });
    });
  });

  test('should finish marination batch successfully', done => {
    batchResources.finishMarination(batch, successCallback, errorCallback);

    moxios.wait(() => {
      let request = moxios.requests.mostRecent();
      request.respondWith({ status: 201 }).then(() => {
        jestExpect(request.config).toMatchObject({
          method: 'post',
          url: '/api/batches/marination/finish'
        });
        jestExpect(successCallback).toHaveBeenCalledTimes(1);
        jestExpect(errorCallback).not.toHaveBeenCalled();
        done();
      });
    });
  });

  test('should handle error when finish marination batch failed', done => {
    batchResources.finishMarination(batch, successCallback, errorCallback);

    moxios.wait(() => {
      let request = moxios.requests.mostRecent();
      request.respondWith({ status: 422, response: {} }).then(() => {
        jestExpect(request.config).toMatchObject({
          method: 'post',
          url: '/api/batches/marination/finish'
        });
        jestExpect(successCallback).not.toHaveBeenCalled();
        jestExpect(errorCallback).toHaveBeenCalledWith({ message: 'Finish Batch Failed.' });
        done();
      });
    });
  });

  test('should get batches by blend names', done => {
    batchResources.getBatchesByBlendNames(['A', '90%'], '2018-07-05', successCallback);

    const batches = [batch];

    moxios.wait(() => {
      let request = moxios.requests.mostRecent();
      request.respondWith({ status: 200, response: { data: batches } }).then(response => {
        jestExpect(request.config).toMatchObject({
          method: 'get',
          url: '/api/batches?blend-names=A,90%25&produce-date=2018-07-05'
        });

        jestExpect(successCallback).toHaveBeenCalledWith(response);
        done();
      });
    });
  });

  test('should search batches by blend name', done => {
    const values = {
      finishedOrBlend: 'kobe',
      productionDateEnd: '2018-09-17',
      productionDateStart: '2018-09-17',
      sourceNumber: '20',
      sourcePurchaseOrderNumber: '20'
    };

    batchResources.search(values);

    const batches = [batch];

    moxios.wait(() => {
      let request = moxios.requests.mostRecent();
      request.respondWith({ status: 200, response: { data: batches } }).then(() => {
        jestExpect(request.config).toMatchObject({
          method: 'get',
          url: '/api/batches/criteria',
          params: {
            'finished-or-blend': 'kobe',
            'end-production-date': '2018-09-17',
            'start-production-date': '2018-09-17',
            'source-number': '20',
            'source-po-number': '20'
          }
        });
        done();
      });
    });
  });
});
