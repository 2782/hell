import moxios from 'moxios';
import boxResources from '../boxResources';

describe('boxResources', () => {
  let successCallback;

  beforeEach(() => {
    successCallback = jest.fn();
    moxios.install();
  });

  afterEach(() => {
    moxios.uninstall();
  });

  test('should get boxes', done => {
    boxResources.getBoxes('2018-09-09', '0078889', '123');

    moxios.wait(() => {
      let request = moxios.requests.mostRecent();
      request
        .respondWith({
          status: 200,
          response: { data: 'data' }
        })
        .then(() => {
          jestExpect(request.config).toMatchObject({
            method: 'get',
            url: '/api/boxes',
            params: { date: '2018-09-09', 'product-code': '0078889', 'sus-order-no': '123' },
            headers: { 'Content-Type': 'application/json' }
          });
          done();
        });
    });
  });

  test('should get boxes when all params are empty', done => {
    boxResources.getBoxes('', '', '', successCallback);

    moxios.wait(() => {
      let request = moxios.requests.mostRecent();
      request
        .respondWith({
          status: 200,
          response: { data: 'data' }
        })
        .then(() => {
          jestExpect(request.config).toMatchObject({
            method: 'get',
            url: '/api/boxes',
            params: {},
            headers: { 'Content-Type': 'application/json' }
          });
          done();
        });
    });
  });

  test('should get wip boxes', done => {
    boxResources.getWipBoxes(successCallback);

    moxios.wait(() => {
      let request = moxios.requests.mostRecent();
      request
        .respondWith({
          status: 200,
          response: { data: 'data' }
        })
        .then(response => {
          jestExpect(successCallback).toHaveBeenCalledWith(response);
          jestExpect(request.config.method).toEqual('get');
          jestExpect(request.config.url).toEqual('/api/boxes/wip');
          jestExpect(request.config.headers).toEqual(
            jestExpect.objectContaining({ 'Content-Type': 'application/json' })
          );
          done();
        });
    });
  });

  test('should print pack off label with packOffBoxid', done => {
    boxResources.reprintLabelsForCurrentUser(15, 'BOTH');

    moxios.wait(() => {
      let request = moxios.requests.mostRecent();
      request
        .respondWith({
          status: 200,
          response: 'data'
        })
        .then(() => {
          jestExpect(request.config.method).toEqual('post');
          jestExpect(request.config.url).toEqual('/api/boxes/labels/reprint');
          jestExpect(request.config.headers).toEqual(
            jestExpect.objectContaining({ 'Content-Type': 'application/json' })
          );
          done();
        });
    });
  });

  test('should reprint pack off label', done => {
    boxResources.reprintLabelsForStation(15, 'BOTH', 12);

    moxios.wait(() => {
      let request = moxios.requests.mostRecent();
      request
        .respondWith({
          status: 200
        })
        .then(() => {
          jestExpect(request.config.method).toEqual('post');
          jestExpect(request.config.url).toEqual('/api/boxes/labels/reprint-for-station');
          jestExpect(request.config.headers).toEqual(
            jestExpect.objectContaining({ 'Content-Type': 'application/json' })
          );
          done();
        });
    });
  });

  test('should label pack off label', done => {
    boxResources.relabelPackoffLabel(15, 12);

    moxios.wait(() => {
      let request = moxios.requests.mostRecent();
      request
        .respondWith({
          status: 200
        })
        .then(() => {
          jestExpect(request.config.method).toEqual('post');
          jestExpect(request.config.url).toEqual('/api/boxes/labels/relabel');
          jestExpect(request.config.headers).toEqual(
            jestExpect.objectContaining({ 'Content-Type': 'application/json' })
          );
          done();
        });
    });
  });

  test('should delete wip box', done => {
    boxResources.deleteWipBox(1, successCallback);

    moxios.wait(() => {
      let request = moxios.requests.mostRecent();
      request
        .respondWith({
          status: 200
        })
        .then(() => {
          jestExpect(successCallback).toHaveBeenCalled();
          jestExpect(request.config.method).toEqual('delete');
          jestExpect(request.config.url).toEqual('/api/boxes/wip/1');
          jestExpect(request.config.headers).toEqual(
            jestExpect.objectContaining({ 'Content-Type': 'application/json' })
          );
          done();
        });
    });
  });

  test('should should bring in portion room', done => {
    boxResources.updateWipStatusToInPortionRoom('barcodeString', 'A');

    moxios.wait(() => {
      let request = moxios.requests.mostRecent();
      request
        .respondWith({
          status: 200
        })
        .then(() => {
          jestExpect(request.config.method).toEqual('put');
          jestExpect(request.config.url).toEqual('/api/boxes/wip/barcodeString/room/A');
          jestExpect(request.config.headers).toEqual(
            jestExpect.objectContaining({ 'Content-Type': 'application/json' })
          );
          done();
        });
    });
  });
});
