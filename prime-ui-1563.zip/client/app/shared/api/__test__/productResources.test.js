import moxios from 'moxios';
import productResources from '../productResources';
import productFactory from '../../../../test-factories/productFactory';

const products = [productFactory.build(), productFactory.build()];
describe('productResources', () => {
  let successCallback, rejectCallback;

  beforeEach(() => {
    successCallback = jest.fn();
    rejectCallback = jest.fn();
    moxios.install();
  });

  afterEach(() => {
    moxios.uninstall();
  });

  test('should lookup product group', async () => {
    moxios.wait(() => {
      const request = moxios.requests.mostRecent();
      request.respondWith({
        status: 200,
        response: 'data'
      });
    });

    const productGroupName = '54456';

    await productResources.lookupProductGroup(productGroupName);

    const request = moxios.requests.mostRecent();
    jestExpect(request.config).toMatchObject({
      method: 'get',
      url: '/api/products/group/lookup',
      params: {
        name: productGroupName
      },
      headers: { 'Content-Type': 'application/json' }
    });
  });

  test('should get product info for product code on success', done => {
    productResources.getProductInfo('0078889', successCallback, rejectCallback);

    moxios.wait(() => {
      let request = moxios.requests.mostRecent();
      request
        .respondWith({
          status: 200,
          response: 'data'
        })
        .then(response => {
          jestExpect(successCallback).toHaveBeenCalledWith(response);
          jestExpect(request.config).toMatchObject({
            method: 'get',
            url: '/api/products/by-code?productCode=0078889',
            headers: { 'Content-Type': 'application/json' }
          });
          done();
        });
    });
  });

  test('should handle error when failing to get product info', done => {
    productResources.getProductInfo('0078889', successCallback, rejectCallback);

    moxios.wait(() => {
      let request = moxios.requests.mostRecent();
      request.respondWith({ status: 422 }).then(() => {
        jestExpect(successCallback).not.toHaveBeenCalled();
        jestExpect(rejectCallback).toHaveBeenCalledTimes(1);
        done();
      });
    });
  });

  test('should get product info for yield models on success', done => {
    productResources.getProductInfoByProductCodes(
      '0078889,0078891',
      successCallback,
      rejectCallback
    );

    moxios.wait(() => {
      let request = moxios.requests.mostRecent();
      request
        .respondWith({
          status: 200,
          response: 'data'
        })
        .then(response => {
          jestExpect(successCallback).toHaveBeenCalledWith(response);
          jestExpect(request.config).toMatchObject({
            method: 'get',
            url: '/api/products?product-codes=0078889,0078891',
            headers: { 'Content-Type': 'application/json' }
          });
          done();
        });
    });
  });

  test('should call success callback when success create cutting product group', done => {
    productResources.createCuttingProductGroup({}, successCallback, rejectCallback);

    moxios.wait(() => {
      let request = moxios.requests.mostRecent();
      request
        .respondWith({
          status: 201,
          response: 'data'
        })
        .then(response => {
          jestExpect(successCallback).toHaveBeenCalledWith(response.data);
          jestExpect(request.config).toMatchObject({
            method: 'post',
            url: '/api/products/group/cutting',
            headers: { 'Content-Type': 'application/json' }
          });
          done();
        });
    });
  });

  test('should handle error when failing to create cutting product group', done => {
    productResources.createCuttingProductGroup({}, successCallback, rejectCallback);

    moxios.wait(() => {
      let request = moxios.requests.mostRecent();
      request.respondWith({ status: 422, response: { data: 'error message' } }).then(response => {
        jestExpect(successCallback).not.toHaveBeenCalled();
        jestExpect(rejectCallback).toHaveBeenCalledWith(response.data);
        done();
      });
    });
  });

  test('should call success callback when success create grinding product group', done => {
    productResources.createGrindProductGroup({}, successCallback, rejectCallback);

    moxios.wait(() => {
      let request = moxios.requests.mostRecent();
      request
        .respondWith({
          status: 201,
          response: 'data'
        })
        .then(response => {
          jestExpect(successCallback).toHaveBeenCalledWith(response.data);

          jestExpect(request.config).toMatchObject({
            method: 'post',
            url: '/api/products/group/grinding',
            headers: { 'Content-Type': 'application/json' }
          });
          done();
        });
    });
  });

  test('should handle error when failing to create grinding product group', done => {
    productResources.createGrindProductGroup({}, successCallback, rejectCallback);

    moxios.wait(() => {
      let request = moxios.requests.mostRecent();
      request.respondWith({ status: 422, response: { data: 'error message' } }).then(response => {
        jestExpect(successCallback).not.toHaveBeenCalled();
        jestExpect(rejectCallback).toHaveBeenCalledWith(response.data);
        done();
      });
    });
  });

  test('should get allergens', async () => {
    moxios.wait(() => {
      const request = moxios.requests.mostRecent();
      request.respondWith({
        status: 200,
        response: 'data'
      });
    });

    await productResources.getAllergens();
    const request = moxios.requests.mostRecent();

    jestExpect(request.config).toMatchObject({
      method: 'get',
      url: '/api/products/allergens',
      headers: { 'Content-Type': 'application/json' }
    });
  });

  test('should call success callback when successfully setup product', async () => {
    const productCode = '78889';
    const tableCode = 98;
    const tarePackageId = 123456789;
    const requestData = { productCode, tableCode, tarePackageId };

    moxios.wait(() => {
      const request = moxios.requests.mostRecent();
      request.respondWith({
        status: 200,
        response: 'data'
      });
    });

    await productResources.setupProduct(requestData, successCallback, rejectCallback);
    const request = moxios.requests.mostRecent();

    jestExpect(request.config).toMatchObject({
      method: 'post',
      url: '/api/products/setup',
      data: JSON.stringify(requestData),
      headers: { 'Content-Type': 'application/json' }
    });
  });

  test('should call success callback when successfully get the products by descriptions', done => {
    const descriptions = 'AB,CD';
    productResources.getProductsByDescriptions(descriptions, successCallback, rejectCallback);

    moxios.wait(() => {
      let request = moxios.requests.mostRecent();
      request
        .respondWith({
          status: 200,
          response: { data: products }
        })
        .then(response => {
          jestExpect(successCallback).toHaveBeenCalledWith(response.data);

          jestExpect(request.config).toMatchObject({
            method: 'get',
            url: '/api/products/by-descriptions',
            params: { descriptions },
            headers: { 'Content-Type': 'application/json' }
          });
          done();
        });
    });
  });

  test('should configure load products groups resource', done => {
    const productGroups = [
      {
        productGroupName: 'NATURAL',
        finishedProductCodes: ['1234567']
      }
    ];
    productResources.loadProductGroups(productGroups);

    moxios.wait(() => {
      let request = moxios.requests.mostRecent();
      request
        .respondWith({
          status: 200,
          response: { data: products }
        })
        .then(() => {
          jestExpect(request.config).toMatchObject({
            method: 'post',
            url: '/api/products/groups/load',
            data: JSON.stringify(productGroups),
            headers: { 'Content-Type': 'application/json' }
          });
          done();
        });
    });
  });
});
