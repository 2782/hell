import moxios from 'moxios';
import fiscalCalendarResources from '../fiscalCalendarResources';

describe('fiscalCalendarResources', () => {
  let successCallback;

  beforeEach(() => {
    successCallback = jest.fn();
    moxios.install();
  });

  afterEach(() => {
    moxios.uninstall();
  });

  test('should get active fiscal calendar', done => {
    fiscalCalendarResources.getActiveFiscalCalendar(successCallback);

    moxios.wait(() => {
      let request = moxios.requests.mostRecent();
      request.respondWith({ status: 200, response: 'data' }).then(response => {
        jestExpect(successCallback).toHaveBeenCalledWith(response);
        jestExpect(request.config).toMatchObject({
          method: 'get',
          url: '/api/fiscal-calendar/active',
          headers: { 'Content-Type': 'application/json' }
        });
        done();
      });
    });
  });

  test('should get all fiscal calendar', done => {
    fiscalCalendarResources.getAllFiscalCalendars(successCallback);

    moxios.wait(() => {
      let request = moxios.requests.mostRecent();
      request.respondWith({ status: 200, response: 'data' }).then(response => {
        jestExpect(successCallback).toHaveBeenCalledWith(response);
        jestExpect(request.config).toMatchObject({
          method: 'get',
          url: '/api/fiscal-calendar',
          headers: { 'Content-Type': 'application/json' }
        });
        done();
      });
    });
  });

  test('should update active fiscal calendar', done => {
    const data = {
      id: 1,
      nextStartDate: '2017-07-02'
    };
    const rejectCallback = jest.fn();
    fiscalCalendarResources.updateActiveFiscalCalendar(data, successCallback, rejectCallback);

    moxios.wait(() => {
      let request = moxios.requests.mostRecent();
      request.respondWith({ status: 200, response: 'data' }).then(response => {
        jestExpect(successCallback).toHaveBeenCalledWith(response);
        jestExpect(rejectCallback).not.toHaveBeenCalled();
        jestExpect(request.config).toMatchObject({
          method: 'put',
          url: `/api/fiscal-calendar/${data.id}`,
          headers: { 'Content-Type': 'application/json' }
        });
        done();
      });
    });
  });

  test('should not update active fiscal calendar', done => {
    const data = {
      id: 1,
      nextStartDate: '2017-07-02'
    };
    const rejectCallback = jest.fn();
    fiscalCalendarResources.updateActiveFiscalCalendar(data, successCallback, rejectCallback);

    moxios.wait(() => {
      let request = moxios.requests.mostRecent();
      request
        .respondWith({
          status: 422,
          response: {}
        })
        .then(() => {
          jestExpect(successCallback).not.toHaveBeenCalled();
          jestExpect(rejectCallback).toHaveBeenCalledTimes(1);
          jestExpect(request.config).toMatchObject({
            method: 'put',
            url: `/api/fiscal-calendar/${data.id}`,
            headers: { 'Content-Type': 'application/json' }
          });
          done();
        });
    });
  });
});
