import { getCostByProductCode_promise } from '../api/costResources';
import { showNoCostWarningModal } from './actions';

export const checkProductHasCost = productCode => dispatch => {
  return getCostByProductCode_promise(productCode).then(({ data }) => {
    if (!data || data.cost === 0) {
      dispatch(showNoCostWarningModal([productCode]));
      return { productCode: 'Product must have a cost' };
    }
  });
};
