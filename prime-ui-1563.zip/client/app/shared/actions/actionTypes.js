export const UPDATE_PORTION_ROOM_TABLE = 'updatePortionRoomTable';
export const RESET_PORTION_ROOM_TABLE = 'resetPortionRoomTable';
export const UPDATE_OPERATING_DATES = 'updateOperatingDates';
export const UPDATE_PRODUCT_INFO = 'updateProductInfo';
export const RESET_PRODUCT_INFO = 'resetProductInfo';
export const SET_HEADER_AND_FOOTER = 'setHeaderAndFooter';
export const HIDE_CONFIRMATION_MODAL = 'HIDE_CONFIRMATION_MODAL';
export const SHOW_CONFIRMATION_MODAL = 'SHOW_CONFIRMATION_MODAL';
