import reportsReducer from '../reportsReducer';
import { CHANGE_REPORT_TYPE, GET_ALL_FISCAL_CALENDARS } from '../../actions/reportingActionTypes';

describe('reportsReducer', () => {
  let initState;

  beforeEach(() => {
    initState = {
      reportType: null,
      fiscalCalendars: []
    };
  });

  test('should return init state when handling unexpected action', () => {
    jestExpect(reportsReducer(initState, { type: 'UNEXPECTED' })).toEqual(initState);
  });

  test('should return change with reportType when handling CHANGE_REPORT_TYPE action', () => {
    jestExpect(reportsReducer(initState, { type: CHANGE_REPORT_TYPE, payload: 'CUT' })).toEqual({
      ...initState,
      reportType: 'CUT'
    });
  });

  test('should return change with all fiscal calendar when handling GET_ALL_FISCAL_CALENDARS action', () => {
    const fiscalCalendars = [
      {
        startDate: '2018-08-01',
        nextStartDate: null
      }
    ];

    jestExpect(
      reportsReducer(initState, { type: GET_ALL_FISCAL_CALENDARS, payload: fiscalCalendars })
    ).toEqual({
      ...initState,
      fiscalCalendars: fiscalCalendars
    });
  });
});
