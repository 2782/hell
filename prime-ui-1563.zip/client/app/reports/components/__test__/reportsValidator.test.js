import { validateScaleDates, validateSubmission } from '../reportsValidator';
import moment from 'moment';
import { PROFITABILITY_REPORT, SCALE_SUMMARY_REPORT, WIP_SPOIL_REPORT } from '../reportType';
import { DEFAULT_DISPLAY_DATE_FORMAT } from '../../../shared/util/dateUtil';

describe('reportsValidator', () => {
  describe('submission validation', () => {
    test('should call submit with given values', () => {
      validateSubmission(
        {
          reportDate: moment().format(DEFAULT_DISPLAY_DATE_FORMAT),
          reportType: PROFITABILITY_REPORT
        },
        { isPortionRoomSelected: true },
        false
      );
    });

    test('should check that fields are required', () => {
      try {
        validateSubmission({}, { isPortionRoomSelected: true }, false);
        jest.fail('Expected SubmissionError to be thrown.');
      } catch ({ errors }) {
        jestExpect(errors.reportDate).toEqual('Required');
        jestExpect(errors.reportType).toEqual('Required');
        jestExpect(errors._error).toEqual('Submission Failed!');
      }
    });

    test('should check that fields are required and date must be in correct format', () => {
      try {
        validateSubmission({ reportDate: '2019-08-01' }, { isPortionRoomSelected: true }, false);
        jest.fail('Expected SubmissionError to be thrown.');
      } catch ({ errors }) {
        jestExpect(errors.reportDate).toEqual('Invalid date format');
        jestExpect(errors.reportType).toEqual('Required');
        jestExpect(errors._error).toEqual('Submission Failed!');
      }
    });

    test('should check that room fields are required when portion room is not selected', () => {
      try {
        validateSubmission({}, { isPortionRoomSelected: false }, true);
        jest.fail('Expected SubmissionError to be thrown.');
      } catch ({ errors }) {
        jestExpect(errors.reportDate).toEqual('Required');
        jestExpect(errors.reportType).toEqual('Required');
        jestExpect(errors.room).toEqual('Required');
        jestExpect(errors._error).toEqual('Submission Failed!');
      }
    });
  });

  describe('validateScaleDates validation', () => {
    test('should validateScaleDates with given values', () => {
      const errors = validateScaleDates(
        {
          reportDate: moment().format(DEFAULT_DISPLAY_DATE_FORMAT),
          endDate: moment().format(DEFAULT_DISPLAY_DATE_FORMAT),
          reportType: PROFITABILITY_REPORT
        },
        { isPortionRoomSelected: true }
      );

      jestExpect(errors).toEqual({});
    });

    test('should validateScaleDates with given values for SCALE_SUMMARY_REPORT report', () => {
      const errors = validateScaleDates(
        {
          reportDate: moment()
            .add(3, 'days')
            .format(DEFAULT_DISPLAY_DATE_FORMAT),
          endDate: moment().format(DEFAULT_DISPLAY_DATE_FORMAT),
          reportType: SCALE_SUMMARY_REPORT
        },
        { isPortionRoomSelected: true }
      );

      jestExpect(errors).toEqual({ endDate: 'Must be after start date' });
    });

    test('should validateScaleDates with given values for WIP_SPOIL_REPORT report', () => {
      const errors = validateScaleDates(
        {
          reportDate: moment()
            .add(3, 'days')
            .format(DEFAULT_DISPLAY_DATE_FORMAT),
          endDate: moment().format(DEFAULT_DISPLAY_DATE_FORMAT),
          reportType: WIP_SPOIL_REPORT
        },
        { isPortionRoomSelected: true }
      );

      jestExpect(errors).toEqual({ endDate: 'Must be after start date' });
    });
  });
});
