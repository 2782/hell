import moment from 'moment';
import { required, validate, validateDate } from '../../shared/formValidations';
import { SubmissionError } from 'redux-form';
import {
  FINISHED_GOOD_MARKET_COST_REPORT,
  SCALE_SUMMARY_REPORT,
  WIP_SPOIL_REPORT
} from './reportType';
import _ from 'lodash';
import { DEFAULT_DISPLAY_DATE_FORMAT } from '../../shared/util/dateUtil';

export const validateSubmission = (values, props, checkRoom) => {
  let errors = {};
  const { isPortionRoomSelected } = props;
  const { reportDate, reportType, endDate, room } = values;

  if (reportType === FINISHED_GOOD_MARKET_COST_REPORT) {
    return;
  }

  errors = validate(errors, reportDate, 'reportDate', [
    required,
    validateDate(DEFAULT_DISPLAY_DATE_FORMAT)
  ]);
  errors = validate(errors, reportType, 'reportType', [required]);

  if (!isPortionRoomSelected && checkRoom) {
    errors = validate(errors, room, 'room', [required]);
  }

  if (reportType === SCALE_SUMMARY_REPORT || reportType === WIP_SPOIL_REPORT) {
    errors = validate(errors, endDate, 'endDate', [
      required,
      validateDate(DEFAULT_DISPLAY_DATE_FORMAT)
    ]);
  }
  if (!_.isEmpty(errors)) {
    throw new SubmissionError({ _error: 'Submission Failed!', ...errors });
  }
};

export const validateScaleDates = values => {
  const { reportDate, endDate, reportType } = values;
  let errors = {};

  if (
    (reportType === SCALE_SUMMARY_REPORT || reportType === WIP_SPOIL_REPORT) &&
    (!!endDate &&
      moment(reportDate, DEFAULT_DISPLAY_DATE_FORMAT).isAfter(
        moment(endDate, DEFAULT_DISPLAY_DATE_FORMAT),
        'day'
      ))
  ) {
    errors = { ...errors, endDate: 'Must be after start date' };
  }
  return errors;
};
