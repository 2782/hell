import { downloadReport, getAllFiscalCalendars } from '../reportingActions';
import reportingResources from '../../../shared/api/reportingResources';
import fileDownload from 'js-file-download';
import {
  CUTTING_STATION_PRODUCTIVITY_REPORT,
  HOUSE_PAR_REPORT,
  PRODUCT_IN_AND_OUT_REPORT,
  PROFITABILITY_REPORT,
  SCALE_SUMMARY_REPORT,
  WEEKLY_RECAP_REPORT,
  YIELD_MODEL_GROUP_COST_SUMMARY_REPORT,
  WIP_SPOIL_REPORT
} from '../../components/reportType';
import fiscalCalendarResources from '../../../shared/api/fiscalCalendarResources';
import { GET_ALL_FISCAL_CALENDARS } from '../reportingActionTypes';

jest.mock('js-file-download');
jest.mock('../../../shared/api/reportingResources', () => ({
  downloadProfitabilityReport: jest.fn(),
  downloadWeeklyRecapReport: jest.fn(),
  downloadCuttingStationProductivityReport: jest.fn(),
  downloadProductInAndOutReport: jest.fn(),
  downloadYieldCostSummaryReport: jest.fn(),
  downloadHouseParReport: jest.fn(),
  downloadScaleSummary: jest.fn(),
  downloadWipSpoil: jest.fn()
}));
jest.mock('../../../shared/api/fiscalCalendarResources');

const errorPayload = {
  status: 422,
  error: {
    name: 'VALIDATION_ERROR',
    details: [
      {
        field: 'reportDate',
        value: '2018-06-06',
        issue: 'DATE_IS_NOT_PORTION_ROOM_WORKING_DAY'
      }
    ],
    message: 'This portion room was not opened on the requested working day.'
  }
};

describe('downloading report', () => {
  const dispatch = jest.fn();
  const getState = () => ({ portionRoomsInfo: { currentPortionRoom: { code: 'A' } } });

  test('should call getAllFiscalCalendars and dispatch GET_ALL_FISCAL_CALENDARS', () => {
    const fiscalCalendars = [
      {
        startDate: '2018-08-01',
        nextStartDate: '2019-07-01'
      }
    ];

    fiscalCalendarResources.getAllFiscalCalendars.mockImplementation(fn =>
      fn({ data: fiscalCalendars })
    );

    getAllFiscalCalendars()(dispatch);

    jestExpect(dispatch).toBeCalledWith({
      type: GET_ALL_FISCAL_CALENDARS,
      payload: fiscalCalendars
    });
  });

  describe('download profitability report', () => {
    afterEach(() => {
      reportingResources.downloadProfitabilityReport.mockReset();
    });

    test('should download data to file when successfully retrieving data from resource', () => {
      reportingResources.downloadProfitabilityReport.mockResolvedValue('SOME_TEST_DATA');

      return downloadReport({ reportType: PROFITABILITY_REPORT, reportDate: '06-22-2018' })(
        dispatch,
        getState
      ).then(() => {
        jestExpect(fileDownload).toBeCalledWith(
          'SOME_TEST_DATA',
          'profitabilityReport-06-22-2018-Room-A.xlsx'
        );
      });
    });

    test('should download data to file when successfully using roomcode from values', () => {
      const getStateWithoutCurrentPortionRoom = () => ({
        portionRoomsInfo: { currentPortionRoom: {} }
      });

      reportingResources.downloadProfitabilityReport.mockImplementation(() =>
        Promise.resolve('SOME_TEST_DATA')
      );

      return downloadReport({
        reportType: PROFITABILITY_REPORT,
        reportDate: '06-22-2018',
        room: 'A'
      })(dispatch, getStateWithoutCurrentPortionRoom).then(() => {
        jestExpect(fileDownload).toBeCalledWith(
          'SOME_TEST_DATA',
          'profitabilityReport-06-22-2018-Room-A.xlsx'
        );
      });
    });

    test('should not use costing room and instead use roomcode from values', () => {
      const getStateWithoutCurrentPortionRoom = () => ({
        portionRoomsInfo: { currentPortionRoom: { code: 'A', roomType: 'COSTING' } }
      });

      reportingResources.downloadProfitabilityReport.mockImplementation(() =>
        Promise.resolve('SOME_TEST_DATA')
      );

      return downloadReport({
        reportType: PROFITABILITY_REPORT,
        reportDate: '06-22-2018',
        room: 'B'
      })(dispatch, getStateWithoutCurrentPortionRoom).then(() => {
        jestExpect(fileDownload).toBeCalledWith(
          'SOME_TEST_DATA',
          'profitabilityReport-06-22-2018-Room-B.xlsx'
        );
      });
    });

    test('should throw SubmissionError when date is not an opening date', () => {
      reportingResources.downloadProfitabilityReport.mockImplementation(() =>
        Promise.reject(errorPayload)
      );

      return downloadReport({ reportType: PROFITABILITY_REPORT, reportDate: '06-22-2018' })(
        dispatch,
        getState
      ).catch(error => {
        jestExpect(error.errors.reportDate).toEqual(
          'This portion room was not opened on the requested working day.'
        );
      });
    });
  });

  describe('download weekly recap report', () => {
    test('should download data to file when successfully retrieving data from resource', () => {
      reportingResources.downloadWeeklyRecapReport.mockImplementation(() =>
        Promise.resolve('SOME_TEST_DATA')
      );

      return downloadReport({ reportType: WEEKLY_RECAP_REPORT, reportDate: '08-04-2018' })().then(
        () => {
          jestExpect(fileDownload).toBeCalledWith(
            'SOME_TEST_DATA',
            'portionRoomWeeklyReport-08-04-2018.xlsx'
          );
        }
      );
    });

    test('should throw SubmissionError when date is not an opening date', () => {
      reportingResources.downloadCuttingStationProductivityReport.mockImplementation(() =>
        Promise.reject({ response: { data: errorPayload } })
      );

      return downloadReport({ reportType: WEEKLY_RECAP_REPORT, reportDate: '08-04-2018' })().catch(
        error => {
          jestExpect(error._error).toEqual('Submission Failed!');
        }
      );
    });
  });

  describe('download cutting station productivity report', () => {
    test('should download data to file when successfully retrieving data from resource', () => {
      reportingResources.downloadCuttingStationProductivityReport.mockImplementation(() =>
        Promise.resolve('SOME_TEST_DATA')
      );

      return downloadReport({
        reportType: CUTTING_STATION_PRODUCTIVITY_REPORT,
        roomCode: 'A',
        reportDate: '09-01-2018'
      })(dispatch, getState).then(() => {
        jestExpect(fileDownload).toBeCalledWith(
          'SOME_TEST_DATA',
          'Cutting-Station-Productivity-Report-09-01-2018-Room-A.xlsx'
        );
      });
    });

    test('should download data by using roomCode from values rather than state', () => {
      const getStateWithoutCurrentPortionRoom = () => ({
        portionRoomsInfo: { currentPortionRoom: {} }
      });

      reportingResources.downloadCuttingStationProductivityReport.mockImplementation(() =>
        Promise.resolve('SOME_TEST_DATA')
      );

      return downloadReport({
        reportType: CUTTING_STATION_PRODUCTIVITY_REPORT,
        roomCode: 'A',
        reportDate: '09-01-2018',
        room: 'B'
      })(dispatch, getStateWithoutCurrentPortionRoom).then(() => {
        jestExpect(fileDownload).toBeCalledWith(
          'SOME_TEST_DATA',
          'Cutting-Station-Productivity-Report-09-01-2018-Room-B.xlsx'
        );
      });
    });

    test('should throw SubmissionError when date is not an opening date', () => {
      reportingResources.downloadCuttingStationProductivityReport.mockImplementation(() =>
        Promise.reject(errorPayload)
      );

      return downloadReport({
        reportType: CUTTING_STATION_PRODUCTIVITY_REPORT,
        roomCode: 'A',
        reportDate: '09-01-2018'
      })(dispatch, getState).catch(error => {
        jestExpect(error.errors.reportDate).toEqual(
          'This portion room was not opened on the requested working day.'
        );
      });
    });
  });

  describe('download product in-and-out report', () => {
    test('should download data to file when successfully retrieving data from resource', () => {
      reportingResources.downloadProductInAndOutReport.mockImplementation(() =>
        Promise.resolve('SOME_TEST_DATA')
      );

      return downloadReport({
        reportType: PRODUCT_IN_AND_OUT_REPORT,
        reportDate: '09-02-2018'
      })(dispatch, getState).then(() => {
        jestExpect(fileDownload).toBeCalledWith(
          'SOME_TEST_DATA',
          'Product-In-And-Out-Report-09-2018-Room-A.xlsx'
        );
      });
    });

    test('should download data to file by using roomcode from selection instead', () => {
      const getStateWithoutCurrentPortionRoom = () => ({
        portionRoomsInfo: { currentPortionRoom: {} }
      });

      reportingResources.downloadProductInAndOutReport.mockImplementation(() =>
        Promise.resolve('SOME_TEST_DATA')
      );

      return downloadReport({
        room: 'B',
        reportType: PRODUCT_IN_AND_OUT_REPORT,
        reportDate: '09-02-2018'
      })(dispatch, getStateWithoutCurrentPortionRoom).then(() => {
        jestExpect(fileDownload).toBeCalledWith(
          'SOME_TEST_DATA',
          'Product-In-And-Out-Report-09-2018-Room-B.xlsx'
        );
      });
    });
  });

  describe('download yield cost summary report', () => {
    test('should download data to file when successfully retrieving data from resource', () => {
      reportingResources.downloadYieldCostSummaryReport.mockImplementation(() =>
        Promise.resolve('SOME_TEST_DATA')
      );

      downloadReport({
        reportType: YIELD_MODEL_GROUP_COST_SUMMARY_REPORT,
        reportDate: '09-16-2018'
      })(dispatch, getState).then(() => {
        jestExpect(fileDownload).toBeCalledWith(
          'SOME_TEST_DATA',
          'Yield-Cost-Summary-Report-09-16-2018.xlsx'
        );
      });
    });
  });

  describe('download house par report', () => {
    test('should download data to file when successfully retrieving data from resource', () => {
      reportingResources.downloadHouseParReport.mockImplementation(() =>
        Promise.resolve('SOME_TEST_DATA')
      );

      downloadReport({
        reportType: HOUSE_PAR_REPORT,
        reportDate: '12-04-2018'
      })(dispatch, getState).then(() => {
        jestExpect(fileDownload).toBeCalledWith(
          'SOME_TEST_DATA',
          'House-Par-Report-12-04-2018.xlsx'
        );
      });
    });
  });

  describe('download scale report', () => {
    test('should download data to file when successfully retrieving data from resource', () => {
      reportingResources.downloadScaleSummary.mockImplementation(() =>
        Promise.resolve('SOME_TEST_DATA')
      );

      downloadReport({
        reportType: SCALE_SUMMARY_REPORT,
        reportDate: '08-05-2018',
        endDate: '08-06-2018'
      })().then(() => {
        jestExpect(fileDownload).toBeCalledWith(
          'SOME_TEST_DATA',
          'Scale-Summary-Report-08-06-2018.csv'
        );
      });
    });

    test('should throw SubmissionError when startDate after endDate', () => {
      reportingResources.downloadScaleSummary.mockImplementation(() =>
        Promise.reject({ response: { data: errorPayload } })
      );

      downloadReport({
        reportType: SCALE_SUMMARY_REPORT,
        reportDate: '08-06-2018',
        startDate: '08-05-2018'
      })().catch(error => {
        jestExpect(error.errors.reportDate).toEqual(
          'This portion room was not opened on the requested working day.'
        );
      });
    });
  });

  describe('download wip spoil report', () => {
    test('should download data to file when successfully retrieving data from resource', () => {
      reportingResources.downloadWipSpoil.mockImplementation(() =>
        Promise.resolve('SOME_TEST_DATA')
      );

      downloadReport({
        reportType: WIP_SPOIL_REPORT,
        reportDate: '08-05-2018',
        endDate: '08-06-2018'
      })().then(() => {
        jestExpect(fileDownload).toBeCalledWith(
          'SOME_TEST_DATA',
          'WIP-Spoil-Report-08-06-2018.csv'
        );
      });
    });

    test('should throw SubmissionError when startDate after endDate', () => {
      reportingResources.downloadWipSpoil.mockImplementation(() =>
        Promise.reject({ response: { data: errorPayload } })
      );

      downloadReport({
        reportType: WIP_SPOIL_REPORT,
        reportDate: '08-06-2018',
        startDate: '08-05-2018'
      })().catch(error => {
        jestExpect(error.errors._error).toEqual('Submission Failed!');
      });
    });
  });
});
