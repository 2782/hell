import searchYieldModelReducer from '../searchYieldModelReducer';
import {
  CLEAR_SEARCH_YIELD_MODELS_PAGE,
  SEARCH_YIELD_MODEL_RESULTS,
  UPDATE_FINISHED_PRODUCT_INFO,
  UPDATE_YIELD_MODEL_PRODUCT_INFO
} from '../../actions/searchYieldModelActionTypes';
import { productInfo1 } from '../../../shared/testData/product';
import CuttingYieldModelFactory from '../../../../test-factories/cuttingYieldModel';

describe('searchYieldModelReducer', () => {
  let initState, yieldModel, yieldModels;

  beforeEach(() => {
    initState = {
      finishedProduct: null,
      yieldModels: null,
      productInfoForYieldModels: null,
      pricingModelOfProductGroup: null,
      yieldModelType: null,
      loading: false
    };

    yieldModel = CuttingYieldModelFactory.build({});
    yieldModels = [
      CuttingYieldModelFactory.build({ code: '4545454' }),
      CuttingYieldModelFactory.build({ code: '5454545' })
    ];
  });

  test('should return initial reducer state when first initialized', () => {
    jestExpect(searchYieldModelReducer(undefined, { type: 'unexpect' })).toEqual(initState);
  });

  test('should clear finishedProduct when dispatch CLEAR_SEARCH_YIELD_MODELS_PAGE', () => {
    jestExpect(
      searchYieldModelReducer(
        { firstProductInfo: productInfo1, searchedProductCode: '0078889' },
        {
          type: CLEAR_SEARCH_YIELD_MODELS_PAGE
        }
      )
    ).toEqual(initState);
  });

  test('should get yield model result when dispatch SEARCH_YIELD_MODEL_RESULTS', () => {
    jestExpect(
      searchYieldModelReducer(initState, {
        type: SEARCH_YIELD_MODEL_RESULTS,
        pricingModelPayload: yieldModel,
        yieldModelPayload: yieldModels,
        yieldModelTypePayload: 'cutting'
      })
    ).toEqual({
      ...initState,
      pricingModelOfProductGroup: yieldModel,
      yieldModels: yieldModels,
      yieldModelType: 'cutting'
    });
  });

  test('should update finished product info when dispatch UPDATE_FINISHED_PRODUCT_INFO', () => {
    jestExpect(
      searchYieldModelReducer(initState, {
        type: UPDATE_FINISHED_PRODUCT_INFO,
        finishedProductPayload: productInfo1
      })
    ).toEqual({
      ...initState,
      finishedProduct: productInfo1
    });
  });

  test('should update product info when dispatch UPDATE_YIELD_MODEL_PRODUCT_INFO', () => {
    jestExpect(
      searchYieldModelReducer(initState, {
        type: UPDATE_YIELD_MODEL_PRODUCT_INFO,
        productInfoPayload: { '0078889': 'description 1', '0078891': 'description 2' }
      })
    ).toEqual({
      ...initState,
      productInfoForYieldModels: { '0078889': 'description 1', '0078891': 'description 2' }
    });
  });
});
