import React from 'react';
import PropTypes from 'prop-types';
import { Table } from 'semantic-ui-react';

const GrindPricingModelTable = ({ pricingModel, onSelectYieldModel }) => {
  return pricingModel && pricingModel.grindYieldModelSourceProductDescriptions ? (
    <div>
      <div className='yield-model-table-title'>Yield Model Group Results</div>
      <Table size='small' selectable>
        <Table.Header>
          <Table.Row>
            <Table.HeaderCell width={3} textAlign={'center'}>
              PRICING MODEL
            </Table.HeaderCell>
            <Table.HeaderCell width={6}>BLEND</Table.HeaderCell>
            <Table.HeaderCell width={7}>SOURCE PRODUCT</Table.HeaderCell>
          </Table.Row>
        </Table.Header>
        <Table.Body>
          <Table.Row onClick={() => onSelectYieldModel(pricingModel, 'grinding')}>
            <Table.Cell
              width={3}
              textAlign={'center'}
              pid={'yield-model-table-group-results__pricing'}
            >
              {<i className='icon-checked' />}
            </Table.Cell>
            <Table.Cell width={6} pid={'yield-model-table-group-results__blend'}>
              {pricingModel.blend && pricingModel.blend.displayName}
            </Table.Cell>
            <Table.Cell width={7} pid={'yield-model-table-group-results__sourceProducts'}>
              {pricingModel.grindYieldModelSourceProductDescriptions.map((description, key) => (
                <div key={key}>{description}</div>
              ))}
            </Table.Cell>
          </Table.Row>
        </Table.Body>
      </Table>
    </div>
  ) : null;
};

GrindPricingModelTable.propTypes = {
  pricingModel: PropTypes.shape({
    blend: PropTypes.shape({
      name: PropTypes.string,
      displayName: PropTypes.string,
      priority: PropTypes.number
    }),
    grindYieldModelSourceProductDescriptions: PropTypes.arrayOf(PropTypes.string)
  }),
  onSelectYieldModel: PropTypes.func
};

export default GrindPricingModelTable;
