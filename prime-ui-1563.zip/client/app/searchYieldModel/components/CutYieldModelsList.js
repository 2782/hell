import React from 'react';
import PropTypes from 'prop-types';
import _ from 'lodash';
import { toPrecision } from '../../shared/util/floatUtil';
import { Table } from 'semantic-ui-react';

const CutYieldModelsList = ({ yieldModelResult, onSelectYieldModel, newYieldTest }) => {
  return yieldModelResult && yieldModelResult.length > 0 ? (
    <div>
      <div className='yield-model-table-title'>Finished Product Results</div>
      <Table size='small' selectable>
        <Table.Header>
          <Table.Row>
            <Table.HeaderCell width={3} textAlign={'center'}>
              PRICING MODEL
            </Table.HeaderCell>
            <Table.HeaderCell width={9}>SOURCE PRODUCT</Table.HeaderCell>
            <Table.HeaderCell width={2} textAlign={'right'}>
              YIELD %
            </Table.HeaderCell>
            <Table.HeaderCell width={2} textAlign={'center'}>
              YIELD TEST
            </Table.HeaderCell>
          </Table.Row>
        </Table.Header>
        <Table.Body>
          {_.map(yieldModelResult, (data, index) => {
            return (
              <Table.Row key={index} onClick={() => onSelectYieldModel(data, 'cutting')}>
                <Table.Cell
                  width={3}
                  textAlign={'center'}
                  pid={`yield-model-table-finished-results__pricing-${index}`}
                >
                  {data.pricingModel ? <i className='icon-checked'>{data.pricingModel}</i> : ''}
                </Table.Cell>
                <Table.Cell
                  width={9}
                  pid={`yield-model-table-finished-results__sourceProduct-${index}`}
                >
                  {`${data.sourceProductCode} ${data.sourceProductDescription}`}
                </Table.Cell>
                <Table.Cell
                  width={2}
                  textAlign={'right'}
                  pid={`yield-model-table-finished-results__estimatedYield-${index}`}
                >
                  {toPrecision(data.estimatedYield, 2)}
                </Table.Cell>
                <Table.Cell
                  width={2}
                  textAlign={'center'}
                  className={'new-yield-test'}
                  onClick={e => {
                    e.stopPropagation();
                    newYieldTest(data);
                  }}
                >
                  <i className='icon-add' />
                </Table.Cell>
              </Table.Row>
            );
          })}
        </Table.Body>
      </Table>
    </div>
  ) : null;
};

CutYieldModelsList.propTypes = {
  yieldModelResult: PropTypes.array,
  onSelectYieldModel: PropTypes.func.isRequired,
  newYieldTest: PropTypes.func.isRequired,
  yieldModelType: PropTypes.string
};

export default CutYieldModelsList;
