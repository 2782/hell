import React from 'react';
import { shallow } from 'enzyme';
import CutPricingModelTable from '../CutPricingModelTable';
import { Table } from 'semantic-ui-react';

jest.mock('../../../shared/errors/ErrorNotification');

describe('cutPricingModelTable', () => {
  let wrapper;
  const onSelectYieldModel = jest.fn();

  test('should not render anything when pricing model table is null', () => {
    wrapper = shallow(
      <CutPricingModelTable pricingModel={null} onSelectYieldModel={onSelectYieldModel} />
    );

    jestExpect(wrapper.find(Table).exists()).toEqual(false);
  });

  describe('render correct component for cutting pricing model', () => {
    const pricingModel = {
      id: 13,
      pricingModel: true,
      finishedProductCode: '0068209',
      finishedProductDescription: 'finished product description',
      sourceProductCode: '0078891',
      sourceProductDescription: 'desc for 0078891',
      estimatedYield: '13'
    };

    beforeEach(() => {
      wrapper = shallow(
        <CutPricingModelTable pricingModel={pricingModel} onSelectYieldModel={onSelectYieldModel} />
      );
    });

    test('should render title', () => {
      const tableTitle = wrapper.find('.yield-model-table-title').html();

      jestExpect(tableTitle).toContain('Yield Model Group Results');
    });

    test('should render header', () => {
      const wrapperHeader = wrapper.find(Table.Header).html();

      jestExpect(wrapperHeader).toContain('PRICING MODEL');
      jestExpect(wrapperHeader).toContain('PRIMARY PRODUCT');
      jestExpect(wrapperHeader).toContain('SOURCE PRODUCT');
      jestExpect(wrapperHeader).toContain('YIELD %');
      jestExpect(wrapperHeader).toContain('YIELD TEST');
    });

    test('should render correct component content', () => {
      const pricingModelRow = wrapper.find(Table.Body).find(Table.Row);

      jestExpect(pricingModelRow.length).toEqual(1);

      function getCol(index) {
        return pricingModelRow
          .at(0)
          .find(Table.Cell)
          .at(index);
      }

      jestExpect(
        getCol(0)
          .find('.icon-checked')
          .exists()
      ).toEqual(true);
      jestExpect(
        getCol(1)
          .find('Dotdotdot')
          .props().children
      ).toEqual('0068209 finished product description');
      jestExpect(
        getCol(2)
          .find('Dotdotdot')
          .props().children
      ).toEqual('0078891 desc for 0078891');
      jestExpect(getCol(3).props().children).toEqual(13);
      jestExpect(
        getCol(4)
          .find('i.icon-add')
          .exists()
      ).toEqual(true);
    });

    test('should call click method when click on table row', () => {
      wrapper
        .find(Table.Body)
        .find(Table.Row)
        .at(0)
        .simulate('click');

      jestExpect(onSelectYieldModel).toHaveBeenCalledTimes(1);
    });
  });
});
