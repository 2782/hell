import React from 'react';
import { shallow } from 'enzyme';
import GrindPricingModelTable from '../GrindPricingModelTable';
import { Table } from 'semantic-ui-react';
import { grindYieldModel } from '../../../shared/testData/yieldModel';
import semanticUI from '../../../../test-helpers/semantic-ui';

jest.mock('../../../shared/errors/ErrorNotification');

describe('grindPricingModelTable', () => {
  let wrapper;
  const onSelectYieldModel = jest.fn();

  test('should not render anything when pricing model table is null', () => {
    wrapper = shallow(
      <GrindPricingModelTable pricingModel={null} onSelectYieldModel={onSelectYieldModel} />
    );

    jestExpect(wrapper.find(Table)).not.toExist();
  });

  describe('render correct component for cutting pricing model', () => {
    const pricingModel = grindYieldModel;
    pricingModel.grindYieldModelSourceProductDescriptions = ['0078891 desc for 0078891'];

    beforeEach(() => {
      wrapper = mount(
        <GrindPricingModelTable
          pricingModel={pricingModel}
          onSelectYieldModel={onSelectYieldModel}
        />
      );
    });

    test('should render title', () => {
      const tableTitle = wrapper.find('.yield-model-table-title');

      jestExpect(tableTitle).toHaveText('Yield Model Group Results');
    });

    test('should render header', () => {
      const wrapperHeader = semanticUI.findTable(wrapper, 0).find('th');

      jestExpect(wrapperHeader.at(1)).toHaveText('BLEND');
      jestExpect(wrapperHeader.at(2)).toHaveText('SOURCE PRODUCT');
    });

    test('should render correct component content', () => {
      const pricingModelRow = wrapper.find(Table.Body).find(Table.Row);

      jestExpect(pricingModelRow.length).toEqual(1);
      jestExpect(
        pricingModelRow
          .at(0)
          .find(Table.Cell)
          .at(0)
          .find('.icon-checked')
      ).toExist();
      jestExpect(
        pricingModelRow
          .at(0)
          .find(Table.Cell)
          .at(1)
      ).toHaveText(pricingModel.blend.displayName);
      jestExpect(
        pricingModelRow
          .at(0)
          .find(Table.Cell)
          .at(2)
          .find('div')
      ).toHaveText('0078891 desc for 0078891');
    });

    test('should call click method when click on table row', () => {
      wrapper
        .find(Table.Body)
        .find(Table.Row)
        .at(0)
        .simulate('click');

      jestExpect(onSelectYieldModel).toHaveBeenCalledTimes(1);
    });
  });
});
