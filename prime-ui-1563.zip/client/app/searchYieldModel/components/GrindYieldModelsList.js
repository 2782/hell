import React from 'react';
import PropTypes from 'prop-types';
import _ from 'lodash';
import { Table } from 'semantic-ui-react';

const GrindYieldModelsList = ({ yieldModelResult, onSelectYieldModel }) => {
  return yieldModelResult && yieldModelResult.length > 0 ? (
    <div>
      <div className='yield-model-table-title'>Blend Results</div>
      <Table size='small' selectable>
        <Table.Header>
          <Table.Row>
            <Table.HeaderCell width={3} textAlign={'center'}>
              PRICING MODEL
            </Table.HeaderCell>
            <Table.HeaderCell width={6}>BLEND</Table.HeaderCell>
            <Table.HeaderCell width={7}>SOURCE PRODUCT</Table.HeaderCell>
          </Table.Row>
        </Table.Header>
        <Table.Body>
          {_.map(yieldModelResult, (data, index) => {
            return (
              <Table.Row key={index} onClick={() => onSelectYieldModel(data, 'grinding')}>
                <Table.Cell
                  width={3}
                  textAlign={'center'}
                  pid={`yield-model-table-blend-results__pricing-${index}`}
                >
                  {data.pricingModel ? <i className='icon-checked'>{data.pricingModel}</i> : ''}
                </Table.Cell>
                <Table.Cell width={6} pid={`yield-model-table-blend-results__blend-${index}`}>
                  {data.blend.displayName}
                </Table.Cell>
                <Table.Cell
                  width={7}
                  pid={`yield-model-table-blend-results__sourceProducts-${index}`}
                >
                  {data.grindYieldModelSourceProductDescriptions.map((description, key) => (
                    <div key={key}>{description}</div>
                  ))}
                </Table.Cell>
              </Table.Row>
            );
          })}
        </Table.Body>
      </Table>
    </div>
  ) : null;
};

GrindYieldModelsList.propTypes = {
  yieldModelResult: PropTypes.arrayOf(
    PropTypes.shape({
      pricingMode: PropTypes.bool,
      blend: PropTypes.shape({
        displayName: PropTypes.string
      }),
      grindYieldModelSourceProductDescriptions: PropTypes.arrayOf(PropTypes.string)
    })
  ),
  onSelectYieldModel: PropTypes.func.isRequired,
  yieldModelType: PropTypes.string
};

export default GrindYieldModelsList;
