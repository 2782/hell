import {
  CLEAR_SEARCH_YIELD_MODELS_PAGE,
  SEARCH_YIELD_MODEL_RESULTS,
  UPDATE_FINISHED_PRODUCT_INFO,
  UPDATE_YIELD_MODEL_PRODUCT_INFO,
  YIELD_MODEL_RECEIVED,
  YIELD_MODEL_REQUESTED
} from './searchYieldModelActionTypes';
import blendPromise from '../../shared/api/blendResources';
import yieldModelResources from '../../shared/api/yieldModelResources';
import productResources from '../../shared/api/productResources';
import * as _ from 'lodash';
import { transformCuttingYieldModelNumerics } from '../../createYieldModel/actions/cuttingYieldModelActions';

export const clearSearchYieldModelsPage = () => {
  return dispatch => {
    dispatch({
      type: CLEAR_SEARCH_YIELD_MODELS_PAGE
    });
  };
};

export const requestYieldModels = () => ({
  type: YIELD_MODEL_REQUESTED
});

export const receiveYieldModels = () => ({
  type: YIELD_MODEL_RECEIVED
});

export const searchYieldModelsByFinishedProductCode = (productCode, rejectCallback) => dispatch => {
  return productResources.getProductInfoPromise(productCode).then(
    productResponse => {
      dispatch({
        type: UPDATE_FINISHED_PRODUCT_INFO,
        finishedProductPayload: productResponse.data || {}
      });

      return yieldModelResources.searchYieldModelsByFinishedProductCode(productCode).then(
        response => {
          const data = {
            ...response.data,
            finishedProductResults: _.map(
              response.data.finishedProductResults,
              transformCuttingYieldModelNumerics
            ),
            yieldModelGroupResult: response.data.yieldModelGroupResult
              ? transformCuttingYieldModelNumerics(response.data.yieldModelGroupResult)
              : response.data.yieldModelGroupResult
          };
          const yieldModels = data.finishedProductResults || [];
          const pricingModel =
            data.yieldModelGroupResult || data.grindingYieldModelGroupResult || {};
          dispatch({
            type: SEARCH_YIELD_MODEL_RESULTS,
            yieldModelPayload: yieldModels,
            pricingModelPayload: pricingModel,
            yieldModelTypePayload: 'cutting'
          });

          let productCodes = yieldModels.map(yieldModel => yieldModel.sourceProductCode);
          if (!_.isEmpty(data.yieldModelGroupResult)) {
            productCodes = _.concat(productCodes, [
              pricingModel.sourceProductCode,
              pricingModel.finishedProductCode
            ]);
          }

          if (!_.isEmpty(data.grindingYieldModelGroupResult)) {
            const yieldModelsSourceProductCodes = pricingModel.sourceProducts.map(
              sourceProduct => sourceProduct.code
            );
            productCodes = _.concat(productCodes, yieldModelsSourceProductCodes);
          }

          return getProductInfoByProductCodes(dispatch, productCodes);
        },
        error => rejectCallback(_.get(error, 'response.data', {}))
      );
    },
    error => rejectCallback(_.get(error, 'response.data', {}))
  );
};

export const searchYieldModelsByBlend = (blend, rejectCallback) => dispatch => {
  return yieldModelResources.searchYieldModelsByBlend(blend).then(
    searchYieldModelsResponse => {
      const yieldModels = searchYieldModelsResponse.data.grindingYieldModelResults || [];
      dispatch({
        type: SEARCH_YIELD_MODEL_RESULTS,
        yieldModelPayload: yieldModels,
        pricingModelPayload: null,
        yieldModelTypePayload: 'grinding'
      });
      let productDescription = null;
      if (yieldModels.length > 0 && !!yieldModels[0].blend) {
        productDescription = { description: yieldModels[0].blend.description };
        dispatch({
          type: UPDATE_FINISHED_PRODUCT_INFO,
          finishedProductPayload: productDescription || {}
        });
      } else {
        blendPromise.getBlendPromise(blend).then(
          response => {
            productDescription = { description: response.data.description };
            dispatch({
              type: UPDATE_FINISHED_PRODUCT_INFO,
              finishedProductPayload: productDescription || {}
            });
          },
          error => rejectCallback(_.get(error, 'response.data', {}))
        );
      }

      const yieldModelsSourceProductCodes = _.flatMap(
        yieldModels.map(yieldModel => {
          return yieldModel.sourceProducts.map(sourceProduct => sourceProduct.code);
        })
      );
      return getProductInfoByProductCodes(dispatch, yieldModelsSourceProductCodes);
    },
    error => rejectCallback(_.get(error, 'response.data', {}))
  );
};

const getProductInfoByProductCodes = (dispatch, productCodes) => {
  return productResources
    .getProductInfoByProductCodesPromise(productCodes.join(','))
    .then(productInfoResponse => {
      let formattedProductInfo = {};

      _.forEach(productInfoResponse.data, info => {
        formattedProductInfo[info.code] = info.description;
      });
      dispatch({
        type: YIELD_MODEL_RECEIVED
      });
      dispatch({
        type: UPDATE_YIELD_MODEL_PRODUCT_INFO,
        productInfoPayload: formattedProductInfo
      });
    });
};
