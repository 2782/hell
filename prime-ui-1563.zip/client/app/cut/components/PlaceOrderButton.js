import React from 'react';
import * as _ from 'lodash';
import { Button } from 'semantic-ui-react';

const PlaceOrderButton = ({ orders, submitting, valid, goBackToStationPage, focus }) => {
  return (
    !_.isEmpty(orders) && (
      <div className={'button-container'}>
        <Button
          primary
          size={'large'}
          loading={submitting}
          disabled={submitting || !valid}
          className='submit'
          autoFocus={focus}
        >
          PLACE ORDER
        </Button>
        <Button primary size={'large'} onClick={goBackToStationPage}>
          CANCEL
        </Button>
      </div>
    )
  );
};

export default PlaceOrderButton;
