import React from 'react';
import { Table } from 'semantic-ui-react';

export default function CutOrderTableHeader() {
  return (
    <Table.Header>
      <Table.Row pid='cut-orders-table__header'>
        <Table.HeaderCell width={6} pid='cut-orders-table__header-product'>
          PRODUCT
        </Table.HeaderCell>
        <Table.HeaderCell width={6} pid='cut-orders-table__header-customer'>
          CUSTOMER
        </Table.HeaderCell>
        <Table.HeaderCell width={2} pid='cut-orders-table__header-date'>
          DATE
        </Table.HeaderCell>
        <Table.HeaderCell width={2} pid='cut-orders-table__header-quantity'>
          QTY
        </Table.HeaderCell>
      </Table.Row>
    </Table.Header>
  );
}
