import React from 'react';
import PropTypes from 'prop-types';
import { Grid, Button, Header } from 'semantic-ui-react';

export default function CutOrderPrompt({
  handleYes,
  handleNo,
  yesButtonText,
  noButtonText,
  message,
  yesButtonDisbled
}) {
  return (
    <Grid padded textAlign='center' className='cut-order-prompt'>
      <Grid.Row color='teal' className='cut-order-prompt-row' centered>
        <Grid.Column width='11' verticalAlign='middle' textAlign='right'>
          <Header color='blue' size='large' pid='cut-orders-prompt__prompt'>
            {message}
          </Header>
        </Grid.Column>
        <Grid.Column width='2' verticalAlign='middle'>
          <Button
            primary
            disabled={yesButtonDisbled}
            onClick={handleYes}
            pid='cut-orders-prompt__yes-button'
            autoFocus
          >
            {yesButtonText}
          </Button>
        </Grid.Column>
        <Grid.Column width='3' verticalAlign='middle'>
          <Button primary onClick={handleNo} pid='cut-orders-prompt__no-button'>
            {noButtonText}
          </Button>
        </Grid.Column>
      </Grid.Row>
    </Grid>
  );
}

CutOrderPrompt.propTypes = {
  handleYes: PropTypes.func.isRequired,
  handleNo: PropTypes.func.isRequired,
  yesButtonText: PropTypes.string.isRequired,
  noButtonText: PropTypes.string.isRequired,
  message: PropTypes.string.isRequired,
  yesButtonDisbled: PropTypes.bool.isRequired
};
