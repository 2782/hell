import React from 'react';
import { mount } from 'enzyme';
import EmptyCutOrderTable from '../EmptyCutOrderTable';
import CutOrderTableHeader from '../CutOrderTableHeader';
import CutOrderTableBody from '../CutOrderTableBody';

describe('EmptyCutOrderTable', () => {
  let emptyCutOrderTable;

  beforeEach(() => {
    emptyCutOrderTable = mount(<EmptyCutOrderTable />);
  });

  test('should render a table header', () => {
    jestExpect(emptyCutOrderTable.find(CutOrderTableHeader)).toExist();
  });

  test('should not render a table body', () => {
    jestExpect(emptyCutOrderTable.find(CutOrderTableBody)).not.toExist();
  });

  test('should render an empty message', () => {
    jestExpect(emptyCutOrderTable.find('.empty-table-message')).toHaveText(
      'This list is empty, press (F4) to go back.'
    );
  });
});
