import React from 'react';
import { mount } from 'enzyme';
import CutOrderFactory from '../../../../test-factories/cutOrder';
import CutOrderTable from '../CutOrderTable';
import CutOrderTableHeader from '../CutOrderTableHeader';
import CutOrderTableBody from '../CutOrderTableBody';

describe('CutOrderTable', () => {
  let cutOrdersTable, handleSelect, handleConfirm;

  beforeEach(() => {
    handleSelect = jest.fn();
    handleConfirm = jest.fn();

    cutOrdersTable = mount(
      <CutOrderTable
        cutOrdersInfo={[
          {
            data: CutOrderFactory.build({ id: 12, productionType: 'CUTTING' }),
            index: 0,
            selected: false
          }
        ]}
        handleSelect={handleSelect}
        handleConfirm={handleConfirm}
      />
    );
  });

  test('should render a table header', () => {
    jestExpect(cutOrdersTable.find(CutOrderTableHeader)).toExist();
  });

  test('should render a table body', () => {
    jestExpect(cutOrdersTable.find(CutOrderTableBody)).toExist();
    jestExpect(cutOrdersTable.find(CutOrderTableBody)).toHaveProp({
      cutOrdersInfo: [
        {
          data: CutOrderFactory.build({ id: 12, productionType: 'CUTTING' }),
          index: 0,
          selected: false
        }
      ]
    });
    jestExpect(cutOrdersTable.find(CutOrderTableBody)).toHaveProp({ handleSelect });
    jestExpect(cutOrdersTable.find(CutOrderTableBody)).toHaveProp({ handleConfirm });
  });

  test('should make table body tabbable by default', () => {
    jestExpect(cutOrdersTable.find(CutOrderTableBody)).toHaveProp({ tabbable: true });
  });

  test('should make table body not tabbable', () => {
    cutOrdersTable.setProps({ tabbable: false });

    jestExpect(cutOrdersTable.find(CutOrderTableBody)).toHaveProp({ tabbable: false });
  });
});
