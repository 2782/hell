import React from 'react';
import { Table } from 'semantic-ui-react';
import ConsolidatedCutOrderTableBody from '../ConsolidatedCutOrderTableBody';
import { productCodeConsolidator, handleKeyDown } from '../cutOrderHelpers';
import { shallow } from 'enzyme';

jest.mock('../cutOrderHelpers', () => ({
  productCodeConsolidator: jest.fn(),
  handleKeyDown: jest.fn()
}));

describe('ConsolidatedCutOrderTableBody', () => {
  const expectedConsolidatedCutOrdersInfo = {
    '2111203': {
      orderIds: [12, 13],
      product: {
        code: '2111203',
        description: 'BEEF STEAK T-BONE CH #1174',
        productPortionSize: {
          portionSize: '12 OZ'
        },
        category: 'CATCH',
        minWeight: 1,
        maxWeight: 20
      },
      totalQuantity: 40,
      selected: false
    },
    '4102218': {
      orderIds: [14],
      product: {
        code: '4102218',
        description: 'BEEF STEAK T-BONE CLS',
        productPortionSize: {
          portionSize: {
            unitOfWeight: 'OZ',
            value: 5
          }
        },
        category: 'CATCH',
        minWeight: 1,
        maxWeight: 20
      },
      totalQuantity: 10,
      selected: false
    }
  };
  test('should call productCodeConsolidator', () => {
    productCodeConsolidator.mockReturnValue(expectedConsolidatedCutOrdersInfo);

    const fakeCutOrderInfo = ['fake', 'cut', 'orders'];
    shallow(
      <ConsolidatedCutOrderTableBody
        cutOrdersInfo={fakeCutOrderInfo}
        handleSelect={() => {}}
        handleConfirm={() => {}}
      />
    );

    jestExpect(productCodeConsolidator).toHaveBeenCalledWith(fakeCutOrderInfo);
  });

  test('should render rows with proper info', () => {
    productCodeConsolidator.mockReturnValue(expectedConsolidatedCutOrdersInfo);

    const wrapper = shallow(
      <ConsolidatedCutOrderTableBody
        cutOrdersInfo={[expectedConsolidatedCutOrdersInfo]}
        handleSelect={() => {}}
        handleConfirm={() => {}}
      />
    );

    jestExpect(wrapper.find(Table.Row).length).toEqual(2);

    const rowFor2111203 = wrapper.find(Table.Row).at(0);

    jestExpect(
      rowFor2111203
        .find('span')
        .at(0)
        .text()
    ).toEqual('2111203 / 12 OZ');
    jestExpect(
      rowFor2111203
        .find('span')
        .at(1)
        .text()
    ).toEqual('BEEF STEAK T-BONE CH #1174');
    jestExpect(
      rowFor2111203
        .find('span')
        .at(3)
        .text()
    ).toEqual('40');
  });

  test('should call handleSelect when clicking a row', () => {
    const handleSelect = jest.fn();

    productCodeConsolidator.mockReturnValue(expectedConsolidatedCutOrdersInfo);

    const wrapper = shallow(
      <ConsolidatedCutOrderTableBody
        cutOrdersInfo={[]}
        handleSelect={handleSelect}
        handleConfirm={() => {}}
      />
    );

    const firstRow = wrapper.find(Table.Row).at(0);

    let event = { target: { value: 'value clicked' } };
    firstRow.simulate('click', event);

    jestExpect(handleSelect).toHaveBeenCalledWith([12, 13], event, '2111203');
  });

  test('should call handleKeyDown when typing a key on a row', () => {
    const handleSelect = jest.fn();
    const handleConfirm = jest.fn();

    productCodeConsolidator.mockReturnValue(expectedConsolidatedCutOrdersInfo);

    const wrapper = shallow(
      <ConsolidatedCutOrderTableBody
        cutOrdersInfo={[]}
        handleSelect={handleSelect}
        handleConfirm={handleConfirm}
      />
    );

    const firstRow = wrapper.find(Table.Row).at(0);

    let event = { key: ' ', target: { value: 'value clicked' } };
    firstRow.simulate('keydown', event);

    jestExpect(handleKeyDown).toHaveBeenCalledWith(
      handleSelect,
      handleConfirm,
      [12, 13],
      event,
      '2111203'
    );
  });
});
