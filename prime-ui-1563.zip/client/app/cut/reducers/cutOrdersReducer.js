import {
  CUT_ORDER_SELECTION_CLEARED,
  CUT_ORDER_SELECTION_TOGGLED,
  CUT_ORDERS_UNSELECTED,
  CONSOLIDATION_TOGGLED,
  UPDATE_CUT_ORDERS_INFO,
  CONSOLIDATED_CUT_ORDERS_TOGGLED,
  CONSOLIDATION_CLEARED,
  CONFIRM_CUT_ORDERS_REQUESTED,
  CONFIRM_CUT_ORDERS_SUCCEEDED
} from '../actions/cutActionTypes';

const initialState = {
  cutOrdersInfo: null,
  isConsolidated: false,
  confirmingInProgress: false
};

export default (state = initialState, action) => {
  switch (action.type) {
    case CONFIRM_CUT_ORDERS_REQUESTED: {
      return {
        ...state,
        confirmingInProgress: true
      };
    }

    case CONFIRM_CUT_ORDERS_SUCCEEDED: {
      return {
        ...state,
        confirmingInProgress: false
      };
    }

    case UPDATE_CUT_ORDERS_INFO: {
      return {
        ...state,
        cutOrdersInfo: action.payload.map(data => ({ orderId: data.id, data, selected: false }))
      };
    }

    case CUT_ORDER_SELECTION_CLEARED:
      return {
        ...state,
        cutOrdersInfo: state.cutOrdersInfo.map(item => ({ ...item, selected: false }))
      };

    case CUT_ORDER_SELECTION_TOGGLED:
      return {
        ...state,
        cutOrdersInfo: state.cutOrdersInfo.map(item =>
          item.orderId === action.payload ? { ...item, selected: !item.selected } : item
        )
      };

    case CONSOLIDATED_CUT_ORDERS_TOGGLED:
      return {
        ...state,
        cutOrdersInfo: state.cutOrdersInfo.map(item =>
          action.payload.includes(item.orderId) ? { ...item, selected: !item.selected } : item
        )
      };

    case CONSOLIDATION_TOGGLED:
      return {
        ...state,
        isConsolidated: !state.isConsolidated
      };

    case CONSOLIDATION_CLEARED:
      return {
        ...state,
        isConsolidated: false
      };

    case CUT_ORDERS_UNSELECTED: {
      const indices = action.payload.map(item => item.orderId);
      return {
        ...state,
        cutOrdersInfo: state.cutOrdersInfo.map(item =>
          indices.includes(item.orderId) ? { ...item, selected: false } : item
        )
      };
    }

    default:
      return state;
  }
};
