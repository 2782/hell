import { UPDATE_CUT_STATION_SUMMARY } from '../actions/cutActionTypes';

const initialState = {
  stations: null
};

export default (state = initialState, action) => {
  switch (action.type) {
    case UPDATE_CUT_STATION_SUMMARY:
      return {
        ...state,
        stations: action.payload
      };

    default:
      return state;
  }
};
