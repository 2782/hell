import {
  RESET_CUT_STATION_INFO,
  RESET_CUT_TABLES_INFO,
  UPDATE_CUT_STATION_INFO,
  CUT_TABLES_INFO_UPDATED
} from '../actions/cutActionTypes';

const initialState = {
  tables: null,
  cutStation: {}
};

export default (state = initialState, action) => {
  switch (action.type) {
    case RESET_CUT_TABLES_INFO:
      return {
        ...state,
        tables: null
      };
    case CUT_TABLES_INFO_UPDATED:
      return {
        ...state,
        tables: action.payload
      };
    case RESET_CUT_STATION_INFO:
      return {
        ...state,
        cutStation: {}
      };
    case UPDATE_CUT_STATION_INFO:
      return {
        ...state,
        cutStation: action.payload
      };

    default:
      return state;
  }
};
