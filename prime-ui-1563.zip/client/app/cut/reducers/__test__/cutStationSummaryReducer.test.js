import cutStationSummaryReducer from '../cutStationSummaryReducer';
import { UPDATE_CUT_STATION_SUMMARY } from '../../actions/cutActionTypes';
import { STATION_SUMMARY_1, STATION_SUMMARY_2 } from '../../../../test-factories/station';

describe('cutStationSummaryReducer', () => {
  let initState;
  beforeEach(() => {
    initState = {
      stations: null
    };
  });

  test('should return initState when handle unexpect action', () => {
    let unexpectAction = { type: 'unexpect' };
    jestExpect(cutStationSummaryReducer(initState, unexpectAction)).toEqual(initState);
  });

  test('should update cut station summary when handling UPDATE_CUT_STATION_SUMMARY ', () => {
    let payload = [STATION_SUMMARY_1, STATION_SUMMARY_2];

    jestExpect(
      cutStationSummaryReducer(initState, {
        type: UPDATE_CUT_STATION_SUMMARY,
        payload: payload
      })
    ).toEqual({ stations: [STATION_SUMMARY_1, STATION_SUMMARY_2] });
  });
});
