import cutTablesReducer from '../cutTablesReducer';
import {
  RESET_CUT_STATION_INFO,
  RESET_CUT_TABLES_INFO,
  CUT_TABLES_INFO_UPDATED
} from '../../actions/cutActionTypes';
import { TABLE_SUMMARY_1, TABLE_SUMMARY_2 } from '../../../../test-factories/cutOrder';

describe('cutTablesReducer', () => {
  let initState;

  beforeEach(() => {
    initState = {
      tables: null
    };
  });

  test('should return init state when handling unexpected action', () => {
    let unexpectedAction = { type: 'UNEXPECTED' };
    jestExpect(cutTablesReducer(initState, unexpectedAction)).toEqual(initState);
  });

  test('should reset table state to null when handling RESET_CUT_TABLES_INFO', () => {
    let state = {
      tables: ['a table'],
      cutStation: {
        id: 1234
      }
    };
    jestExpect(cutTablesReducer(state, { type: RESET_CUT_TABLES_INFO })).toEqual({
      tables: null,
      cutStation: {
        id: 1234
      }
    });
  });

  test('should reset station info state to null when handling RESET_CUT_STATION_INFO', () => {
    let state = {
      tables: ['a table'],
      cutStation: {
        id: 1234
      }
    };
    jestExpect(cutTablesReducer(state, { type: RESET_CUT_STATION_INFO })).toEqual({
      tables: ['a table'],
      cutStation: {}
    });
  });

  test('should return new state based on the action payload', () => {
    const result = cutTablesReducer(initState, {
      type: CUT_TABLES_INFO_UPDATED,
      payload: [TABLE_SUMMARY_1, TABLE_SUMMARY_2]
    });
    jestExpect(result.tables).toEqual([TABLE_SUMMARY_1, TABLE_SUMMARY_2]);
  });
});
