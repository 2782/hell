import meatListReducer from '../sourceMeatReducer';
import { RESET_SOURCE_MEAT_INFO, UPDATE_SOURCE_MEAT_INFO } from '../../actions/cutActionTypes';

describe('meatListReducer', () => {
  let initState, meatOne, meatTwo;

  beforeEach(() => {
    initState = {
      sourceMeatOrders: null
    };

    meatOne = {
      cutOrderId: 1,
      targetProductCode: '0078889',
      targetProductDesc: 'PRIME CC TRUE BARREL FILET STK',
      productCode: '12345',
      productDecs: 'PRIME CC TRUE BARREL FILET STK',
      quantity: 4,
      unitOfMeasure: 'C'
    };

    meatTwo = {
      cutOrderId: 2,
      targetProductCode: '0078889',
      targetProductDesc: 'PRIME CC TRUE BARREL FILET STK',
      productCode: '12345',
      productDecs: 'PRIME CC TRUE BARREL FILET STK',
      quantity: 4,
      unitOfMeasure: 'C'
    };
  });

  test('should retuen init state when handle unexpected action', () => {
    let unexpectedAction = { type: 'UNEXPECTED' };
    jestExpect(meatListReducer(initState, unexpectedAction)).toEqual(initState);
  });

  test('should return new state based on the action payload', () => {
    const result = meatListReducer(initState, {
      type: UPDATE_SOURCE_MEAT_INFO,
      payload: [meatOne, meatTwo]
    });
    jestExpect(result.sourceMeatOrders).toEqual([meatOne, meatTwo]);
  });

  test('should clear sourceMeatOrders', () => {
    const result = meatListReducer(initState, {
      type: RESET_SOURCE_MEAT_INFO
    });
    jestExpect(result.sourceMeatOrders).toEqual(null);
  });
});
