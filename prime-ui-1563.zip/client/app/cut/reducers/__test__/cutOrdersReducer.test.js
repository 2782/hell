import cutOrdersReducer from '../cutOrdersReducer';
import {
  CONFIRM_CUT_ORDERS_REQUESTED,
  CONFIRM_CUT_ORDERS_SUCCEEDED,
  CONSOLIDATED_CUT_ORDERS_TOGGLED,
  CONSOLIDATION_CLEARED,
  CONSOLIDATION_TOGGLED,
  CUT_ORDER_SELECTION_CLEARED,
  CUT_ORDER_SELECTION_TOGGLED,
  CUT_ORDERS_UNSELECTED,
  UPDATE_CUT_ORDERS_INFO
} from '../../actions/cutActionTypes';

describe('cutOrdersReducer', () => {
  let initState;
  beforeEach(() => {
    initState = {
      cutOrdersInfo: null,
      isConsolidated: false,
      confirmingInProgress: false
    };
  });

  test('should return initState when handle unexpect action', () => {
    let unexpectAction = { type: 'unexpect' };
    jestExpect(cutOrdersReducer(undefined, unexpectAction)).toEqual(initState);
  });

  test('should toggle consolidated from false to true', () => {
    const action = { type: CONSOLIDATION_TOGGLED };
    const existingState = { cutOrdersInfo: [{ data: 'CAT' }], isConsolidated: false };
    const expectedResult = { cutOrdersInfo: [{ data: 'CAT' }], isConsolidated: true };

    jestExpect(cutOrdersReducer(existingState, action)).toEqual(expectedResult);
  });

  test('should toggle consolidated from true to false', () => {
    const action = { type: CONSOLIDATION_TOGGLED };
    const existingState = {
      cutOrdersInfo: [{ data: 'MOUSE' }, { data: 'DOG' }],
      isConsolidated: true
    };
    const expectedResult = {
      cutOrdersInfo: [{ data: 'MOUSE' }, { data: 'DOG' }],
      isConsolidated: false
    };

    jestExpect(cutOrdersReducer(existingState, action)).toEqual(expectedResult);
  });

  test('should clear consolidation, resetting to false', () => {
    const action = { type: CONSOLIDATION_CLEARED };
    const existingState = {
      cutOrdersInfo: [{ data: 'MOUSE' }, { data: 'DOG' }],
      isConsolidated: true
    };
    const expectedResult = {
      cutOrdersInfo: [{ data: 'MOUSE' }, { data: 'DOG' }],
      isConsolidated: false
    };

    jestExpect(cutOrdersReducer(existingState, action)).toEqual(expectedResult);
  });

  test('should update cutOrder state when handling UPDATE_CUT_ORDERS_ACTION ', () => {
    let payload = [{ id: 1, deliveryDate: '2017-10-22' }, { id: 2, deliveryDate: '2017-10-23' }];

    let result = {
      cutOrdersInfo: [
        { data: { id: 1, deliveryDate: '2017-10-22' }, orderId: 1, selected: false },
        { data: { id: 2, deliveryDate: '2017-10-23' }, orderId: 2, selected: false }
      ],
      isConsolidated: false,
      confirmingInProgress: false
    };
    jestExpect(
      cutOrdersReducer(undefined, {
        type: UPDATE_CUT_ORDERS_INFO,
        payload: payload
      })
    ).toEqual(result);
  });

  test('should update confirmingInProgress state when handling CONFIRM_CUT_ORDERS_SUCCEEDED ', () => {
    let initialStateData = {
      cutOrdersInfo: [
        { data: { id: 1, deliveryDate: '2017-10-22' }, orderId: 1, selected: false },
        { data: { id: 2, deliveryDate: '2017-10-23' }, orderId: 2, selected: false }
      ],
      isConsolidated: false,
      confirmingInProgress: true
    };

    let result = {
      cutOrdersInfo: [
        { data: { id: 1, deliveryDate: '2017-10-22' }, orderId: 1, selected: false },
        { data: { id: 2, deliveryDate: '2017-10-23' }, orderId: 2, selected: false }
      ],
      isConsolidated: false,
      confirmingInProgress: false
    };
    jestExpect(
      cutOrdersReducer(initialStateData, {
        type: CONFIRM_CUT_ORDERS_SUCCEEDED
      })
    ).toEqual(result);
  });

  test('should update confirmingInProgress state when handling CONFIRM_CUT_ORDERS_REQUESTED ', () => {
    let initialStateData = {
      cutOrdersInfo: [
        { data: { id: 1, deliveryDate: '2017-10-22' }, orderId: 1, selected: false },
        { data: { id: 2, deliveryDate: '2017-10-23' }, orderId: 2, selected: false }
      ],
      isConsolidated: false,
      confirmingInProgress: false
    };

    let result = {
      cutOrdersInfo: [
        { data: { id: 1, deliveryDate: '2017-10-22' }, orderId: 1, selected: false },
        { data: { id: 2, deliveryDate: '2017-10-23' }, orderId: 2, selected: false }
      ],
      isConsolidated: false,
      confirmingInProgress: true
    };
    jestExpect(
      cutOrdersReducer(initialStateData, {
        type: CONFIRM_CUT_ORDERS_REQUESTED
      })
    ).toEqual(result);
  });

  test('should clear cut order selection information', () => {
    let state = {
      cutOrdersInfo: [
        { orderId: 0, data: { id: 1, deliveryDate: '2017-10-22' }, selected: true },
        { orderId: 1, data: { id: 2, deliveryDate: '2017-10-23' }, selected: true }
      ]
    };

    jestExpect(
      cutOrdersReducer(state, {
        type: CUT_ORDER_SELECTION_CLEARED,
        payload: 1
      })
    ).toEqual({
      cutOrdersInfo: [
        { orderId: 0, data: { id: 1, deliveryDate: '2017-10-22' }, selected: false },
        { orderId: 1, data: { id: 2, deliveryDate: '2017-10-23' }, selected: false }
      ]
    });
  });

  test('should unselect existing selected cut orders', () => {
    let state = {
      cutOrdersInfo: [
        { orderId: 1, data: { id: 1, deliveryDate: '2017-10-22' }, selected: true },
        { orderId: 2, data: { id: 2, deliveryDate: '2017-10-23' }, selected: true },
        { orderId: 3, data: { id: 3, deliveryDate: '2017-10-24' }, selected: true }
      ]
    };

    jestExpect(
      cutOrdersReducer(state, {
        type: CUT_ORDERS_UNSELECTED,
        payload: [{ orderId: 2 }, { orderId: 3 }]
      })
    ).toEqual({
      cutOrdersInfo: [
        { orderId: 1, data: { id: 1, deliveryDate: '2017-10-22' }, selected: true },
        { orderId: 2, data: { id: 2, deliveryDate: '2017-10-23' }, selected: false },
        { orderId: 3, data: { id: 3, deliveryDate: '2017-10-24' }, selected: false }
      ]
    });
  });

  test('should toggle cut order from selected to unselected', () => {
    let state = {
      cutOrdersInfo: [
        { orderId: 1, data: { id: 1, deliveryDate: '2017-10-22' }, selected: true },
        { orderId: 2, data: { id: 2, deliveryDate: '2017-10-23' }, selected: true }
      ]
    };

    jestExpect(
      cutOrdersReducer(state, {
        type: CUT_ORDER_SELECTION_TOGGLED,
        payload: 2
      })
    ).toEqual({
      cutOrdersInfo: [
        { orderId: 1, data: { id: 1, deliveryDate: '2017-10-22' }, selected: true },
        { orderId: 2, data: { id: 2, deliveryDate: '2017-10-23' }, selected: false }
      ]
    });
  });

  test('should toggle cut order from unselected to selected', () => {
    let state = {
      cutOrdersInfo: [
        { orderId: 0, data: { id: 1, deliveryDate: '2017-10-22' }, selected: false },
        { orderId: 1, data: { id: 2, deliveryDate: '2017-10-23' }, selected: false }
      ]
    };

    jestExpect(
      cutOrdersReducer(state, {
        type: CUT_ORDER_SELECTION_TOGGLED,
        payload: 0
      })
    ).toEqual({
      cutOrdersInfo: [
        { orderId: 0, data: { id: 1, deliveryDate: '2017-10-22' }, selected: true },
        { orderId: 1, data: { id: 2, deliveryDate: '2017-10-23' }, selected: false }
      ]
    });
  });

  test('should toggle consolidated cut orders from selected to unselected', () => {
    let state = {
      cutOrdersInfo: [
        { orderId: 1, data: { id: 1, deliveryDate: '2017-10-22' }, selected: true },
        { orderId: 2, data: { id: 2, deliveryDate: '2017-10-23' }, selected: true }
      ]
    };

    jestExpect(
      cutOrdersReducer(state, {
        type: CONSOLIDATED_CUT_ORDERS_TOGGLED,
        payload: [2]
      })
    ).toEqual({
      cutOrdersInfo: [
        { orderId: 1, data: { id: 1, deliveryDate: '2017-10-22' }, selected: true },
        { orderId: 2, data: { id: 2, deliveryDate: '2017-10-23' }, selected: false }
      ]
    });
  });

  test('should toggle consolidated cut orders from unselected to selected', () => {
    let state = {
      cutOrdersInfo: [
        { orderId: 0, data: { id: 1, deliveryDate: '2017-10-22' }, selected: false },
        { orderId: 1, data: { id: 2, deliveryDate: '2017-10-23' }, selected: false }
      ]
    };

    jestExpect(
      cutOrdersReducer(state, {
        type: CONSOLIDATED_CUT_ORDERS_TOGGLED,
        payload: [0, 1]
      })
    ).toEqual({
      cutOrdersInfo: [
        { orderId: 0, data: { id: 1, deliveryDate: '2017-10-22' }, selected: true },
        { orderId: 1, data: { id: 2, deliveryDate: '2017-10-23' }, selected: true }
      ]
    });
  });
});
