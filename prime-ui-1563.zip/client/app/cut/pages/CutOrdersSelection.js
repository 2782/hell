import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import {
  hideModal,
  replacePath,
  setHeaderAndFooter,
  showModal
} from '../../shared/actions/actions';
import HeaderNavigation from '../../shared/components/HeaderNavigation';
import { CUT_STATION } from '../../shared/components/pageTitles';
import {
  clearCutOrderSelection,
  clearConsolidatedView,
  getCutOrdersInfo,
  toggleConsolidatedView,
  toggleCutOrderSelection,
  toggleConsolidatedCutOrderSelection,
  unSelectCutOrders
} from '../actions/cutActions';
import { bindActionCreators } from 'redux';
import CutOrderTable from '../components/CutOrderTable';
import EmptyCutOrderTable from '../components/EmptyCutOrderTable';
import { CUT_ORDERS_SELECTION_FOOTER } from '../../shared/components/pageFooters';
import _ from 'lodash';
import { POLLING_INTERVAL } from '../../shared/constants';
import subscriber from '../../shared/functionKeys/subscriber';
import ConsolidatedCutOrderTable from '../components/ConsolidatedCutOrderTable';

const filterSelected = orders => {
  return _(orders)
    .filter(item => item.selected)
    .value();
};

const filterOnHold = orders => {
  return _(orders)
    .filter(item => item.data.customerOrder && item.data.customerOrder.onHold)
    .value();
};

const mapUniqueCustomerCodes = orders => {
  return _(orders)
    .map(item => item.data.customerOrder.customer.customerCode)
    .uniq()
    .value();
};

const allOnHold = orders => {
  return !_.some(
    orders,
    item => _.isEmpty(item.data.customerOrder) || !item.data.customerOrder.onHold
  );
};

export const buildOnHoldCustomersModalMessage = onHoldCustomers => {
  if (onHoldCustomers.length === 1) {
    return (
      `Customer ${onHoldCustomers[0]} is on credit hold. ` +
      'Are you sure you want to produce orders for this customer?'
    );
  } else {
    const lastCustomer = onHoldCustomers.pop();
    return (
      `Customers ${onHoldCustomers.join(', ') + ` and ${lastCustomer}`} are on credit hold. ` +
      'Are you sure you want to produce orders for these customers?'
    );
  }
};

export class CutOrdersSelectionComponent extends React.Component {
  constructor(props) {
    super(props);

    this.handleConfirm = this.handleConfirm.bind(this);
    this.handleSelect = this.handleSelect.bind(this);
    this.handleConsolidatedSelect = this.handleConsolidatedSelect.bind(this);
  }

  componentDidMount() {
    this.props.setHeaderAndFooter({
      header: CUT_STATION,
      footer: CUT_ORDERS_SELECTION_FOOTER
    });

    const { tableId } = this.props.match.params;

    this.intervalNumber = setInterval(() => {
      this.props.getCutOrdersInfo(tableId);
    }, POLLING_INTERVAL);
  }

  componentWillUnmount() {
    clearInterval(this.intervalNumber);
  }

  handleConfirm() {
    const {
      cutOrdersInfo,
      showModal,
      unSelectCutOrders,
      match: {
        params: { stationId, tableId }
      },
      replacePath
    } = this.props;
    if (cutOrdersInfo && cutOrdersInfo.find(item => item.selected)) {
      const selectedCutOrders = filterSelected(cutOrdersInfo);
      const onHoldCutOrders = filterOnHold(selectedCutOrders);
      const onHoldCustomers = mapUniqueCustomerCodes(onHoldCutOrders);
      const allSelectedCutOrdersAreOnHold = allOnHold(selectedCutOrders);

      if (!_.isEmpty(onHoldCustomers)) {
        showModal({
          header: 'Customer on Credit Hold',
          content: buildOnHoldCustomersModalMessage(onHoldCustomers),
          cancelButton: 'No',
          cancelAction: () => {
            unSelectCutOrders(onHoldCutOrders);
            if (!allSelectedCutOrdersAreOnHold) {
              replacePath(`/cut/stations/${stationId}/tables/${tableId}/confirm`);
            }
          },
          confirmButton: 'Yes',
          confirmAction: () => replacePath(`/cut/stations/${stationId}/tables/${tableId}/confirm`)
        });
      } else {
        replacePath(`/cut/stations/${stationId}/tables/${tableId}/confirm`);
      }
    }
  }

  handleSelect(orderId, event, productCode) {
    const { toggleCutOrderSelection } = this.props;
    toggleCutOrderSelection(orderId, productCode, event);
  }

  handleConsolidatedSelect(orderIds, event, productCode) {
    const { toggleConsolidatedCutOrderSelection } = this.props;
    toggleConsolidatedCutOrderSelection(orderIds, productCode, event);
  }

  render() {
    const { cutOrdersInfo, toggleConsolidatedView, isConsolidated } = this.props;
    const { stationCode, name, tableCode, tableDescription } = this.props.portionRoomTableInfo;

    return (
      <div className='page-content'>
        <HeaderNavigation
          stationCode={stationCode}
          stationName={name}
          tableCode={tableCode}
          tableDescription={tableDescription}
          renderToggle={true}
          toggleText='Consolidate'
          onToggle={toggleConsolidatedView}
          toggleValue={isConsolidated}
          toggleDisabled={false}
        />

        {cutOrdersInfo === null ? null : !_.isEmpty(cutOrdersInfo) ? (
          isConsolidated ? (
            <ConsolidatedCutOrderTable
              cutOrdersInfo={cutOrdersInfo}
              handleSelect={this.handleConsolidatedSelect}
              handleConfirm={this.handleConfirm}
            />
          ) : (
            <CutOrderTable
              cutOrdersInfo={cutOrdersInfo}
              handleSelect={this.handleSelect}
              handleConfirm={this.handleConfirm}
            />
          )
        ) : (
          <EmptyCutOrderTable />
        )}
      </div>
    );
  }
}

CutOrdersSelectionComponent.propTypes = {
  cutOrdersInfo: PropTypes.array,
  isConsolidated: PropTypes.bool,
  isModalShowing: PropTypes.bool,
  match: PropTypes.object,
  portionRoomTableInfo: PropTypes.object,
  operatingDates: PropTypes.object,

  toggleCutOrderSelection: PropTypes.func,
  toggleConsolidatedCutOrderSelection: PropTypes.func,
  toggleConsolidatedView: PropTypes.func,
  clearCutOrderSelection: PropTypes.func,
  replacePath: PropTypes.func,
  setHeaderAndFooter: PropTypes.func,
  unSelectCutOrders: PropTypes.func,
  showModal: PropTypes.func,
  hideModal: PropTypes.func,
  getCutOrdersInfo: PropTypes.func
};

const mapStateToProps = state => ({
  cutOrdersInfo: state.cutOrdersInfo.cutOrdersInfo,
  isConsolidated: state.cutOrdersInfo.isConsolidated,
  portionRoomTableInfo: state.portionRoomTableInfo,
  isModalShowing: state.confirmationModal.showing,
  operatingDates: state.operatingDates
});

const mapDispatchToProps = dispatch =>
  bindActionCreators(
    {
      replacePath,
      getCutOrdersInfo,
      showModal,
      hideModal,
      toggleCutOrderSelection,
      toggleConsolidatedCutOrderSelection,
      toggleConsolidatedView,
      clearCutOrderSelection,
      clearConsolidatedView,
      setHeaderAndFooter,
      unSelectCutOrders
    },
    dispatch
  );

export const f4Behavior = props => {
  const {
    clearConsolidatedView,
    clearCutOrderSelection,
    cutOrdersInfo,
    isModalShowing,
    hideModal,
    replacePath,
    match: {
      params: { stationId }
    }
  } = props;
  if (isModalShowing) {
    hideModal();
  } else if (cutOrdersInfo && cutOrdersInfo.find(item => item.selected)) {
    clearCutOrderSelection();
  } else {
    clearConsolidatedView();
    replacePath(`/cut/stations/${stationId}/tables`);
  }
};

export const f2Behavior = props => {
  const { toggleConsolidatedView, clearCutOrderSelection } = props;
  clearCutOrderSelection();
  toggleConsolidatedView();
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(
  subscriber(CutOrdersSelectionComponent, {
    f2Behavior,
    f4Behavior,
    targetComponent: 'CutOrdersSelection',
    uris: {
      F2: ['#/cut/stations/*/tables/*/select'],
      F4: ['#/cut/stations/*/tables/*/select']
    }
  })
);
