import React from 'react';
import _ from 'lodash';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import { calcSourceMeat, generateSourceMeatOrders } from '../actions/cutActions';
import {
  replacePath,
  returnToPreviousPage,
  setHeaderAndFooter
} from '../../shared/actions/actions';
import { REQUEST_FOR_MEAT } from '../../shared/components/pageTitles';
import { CUT_ORDERS_SOURCE_MEAT_REQUEST_FOOTER } from '../../shared/components/pageFooters';
import SourceMeatTable from '../components/SourceMeatTable';
import PlaceOrderButton from '../components/PlaceOrderButton';
import { reduxForm } from 'redux-form';
import { Divider, Form } from 'semantic-ui-react';
import subscriber from '../../shared/functionKeys/subscriber';
import AdditivesTable from '../components/AdditivesTable';

export class CutOrdersSourceMeatRequestComponent extends React.Component {
  constructor(props) {
    super(props);

    this.onSubmit = this.onSubmit.bind(this);
    this.goBackToStationPage = this.goBackToStationPage.bind(this);
  }

  componentDidMount() {
    const { confirmedOrderIds, calcSourceMeat, setHeaderAndFooter } = this.props;
    calcSourceMeat(confirmedOrderIds);
    setHeaderAndFooter({
      header: REQUEST_FOR_MEAT,
      footer: CUT_ORDERS_SOURCE_MEAT_REQUEST_FOOTER
    });
  }

  goBackToStationPage() {
    const {
      match: {
        params: { stationId }
      },
      replacePath
    } = this.props;
    const path = `/cut/stations/${stationId}/tables`;
    replacePath(path);
  }

  onSubmit(values) {
    const { sourceMeatOrders, generateSourceMeatOrders } = this.props;
    let consolidatedValues = { ...values };

    let sourceMeatOrdersToGenerate = fetchSourceMeatOrders(sourceMeatOrders, consolidatedValues);
    addExtraSourceMeatQuantity(consolidatedValues, sourceMeatOrdersToGenerate);

    let sourceMeatOrdersWithAdditives = addAdditives(
      sourceMeatOrdersToGenerate,
      consolidatedValues
    );
    addExtraAdditives(consolidatedValues, sourceMeatOrdersWithAdditives);

    if (sourceMeatOrdersWithAdditives.length) {
      generateSourceMeatOrders(sourceMeatOrdersWithAdditives);
    }

    this.goBackToStationPage();
  }

  render() {
    const {
      consolidateSourceMeatOrders,
      handleSubmit,
      submitting,
      valid,
      consolidatedAdditives
    } = this.props;
    return (
      <div className='page-content' tabIndex={0}>
        <Form
          size={'large'}
          onSubmit={handleSubmit(this.onSubmit)}
          className={'source-meat-request-table'}
        >
          <Divider hidden className='divider-medium' />

          <SourceMeatTable sourceMeatOrders={consolidateSourceMeatOrders} />

          <Divider hidden />

          <AdditivesTable additives={consolidatedAdditives} />

          <Divider hidden />

          <PlaceOrderButton
            orders={consolidateSourceMeatOrders}
            submitting={submitting}
            valid={valid}
            goBackToStationPage={this.goBackToStationPage}
            focus={true}
          />
        </Form>
      </div>
    );
  }
}

export const addAdditives = (sourceMeatOrdersToGenerate, consolidateAdditives) => {
  return sourceMeatOrdersToGenerate.map(order => {
    const additives = order.additives;

    const allocatedAdditives = additives.map(additive => {
      const consolidatedQuantity = parseInt(
        _.get(consolidateAdditives, `${additive.productCode}-additives-quantity`, 0)
      );
      const additiveQuantity = _.get(additive, 'quantity', 0);

      if (consolidatedQuantity >= additiveQuantity) {
        consolidateAdditives[`${additive.productCode}-additives-quantity`] =
          consolidatedQuantity - additiveQuantity;
        return { ...additive, quantity: additiveQuantity };
      } else {
        consolidateAdditives[`${additive.productCode}-additives-quantity`] = 0;
        return { ...additive, quantity: consolidatedQuantity };
      }
    });

    return { ...order, additives: allocatedAdditives };
  });
};

export const addExtraSourceMeatQuantity = (consolidatedValues, sourceMeatOrdersToGenerate) => {
  _.forEach(consolidatedValues, (consolidatedValue, key) => {
    if (key.split('-').length === 2 && consolidatedValue > 0) {
      const index = _.findIndex(sourceMeatOrdersToGenerate, sourceMeatOrderToGenerate => {
        return sourceMeatOrderToGenerate.targetProductCode === key.split('-')[0];
      });

      sourceMeatOrdersToGenerate[index].quantity += consolidatedValue;
    }
  });
};

export const addExtraAdditives = (consolidateAdditives, sourceMeatOrders) => {
  _.forEach(consolidateAdditives, (consolidateAdditive, key) => {
    if (key.split('-').length === 3 && consolidateAdditive > 0) {
      const index = _.findIndex(sourceMeatOrders, sourceMeatOrder => {
        return _.includes(
          sourceMeatOrder.additives.map(additive => additive.productCode),
          key.split('-')[0]
        );
      });

      let additiveNeededToBeAddedExtra = _.find(sourceMeatOrders[index].additives, additive => {
        return additive.productCode === key.split('-')[0];
      });

      additiveNeededToBeAddedExtra.quantity += consolidateAdditive;
    }
  });
};

export const fetchSourceMeatOrders = (sourceMeatOrders, consolidatedValues) => {
  return sourceMeatOrders
    .map(sourceMeatOrder => {
      const targetProductCode = sourceMeatOrder.targetProductCode;
      const consolidatedQuantity = _.get(consolidatedValues, `${targetProductCode}-quantity`, 0);
      const sourceMeatOrderQuantity = _.get(sourceMeatOrder, 'quantity', 0);

      if (consolidatedQuantity >= sourceMeatOrderQuantity) {
        consolidatedValues[`${targetProductCode}-quantity`] =
          consolidatedQuantity - sourceMeatOrderQuantity;
        return { ...sourceMeatOrder, quantity: sourceMeatOrderQuantity };
      } else {
        consolidatedValues[`${targetProductCode}-quantity`] = 0;
        return { ...sourceMeatOrder, quantity: consolidatedQuantity };
      }
    })
    .filter(sourceMeatOrder => sourceMeatOrder.quantity > 0);
};

CutOrdersSourceMeatRequestComponent.propTypes = {
  sourceMeatOrders: PropTypes.array,
  consolidateSourceMeatOrders: PropTypes.array,
  match: PropTypes.object.isRequired,
  confirmedOrderIds: PropTypes.array.isRequired,
  consolidatedAdditives: PropTypes.array,
  calcSourceMeat: PropTypes.func.isRequired,
  replacePath: PropTypes.func.isRequired,
  returnToPreviousPage: PropTypes.func.isRequired,
  generateSourceMeatOrders: PropTypes.func.isRequired,
  setHeaderAndFooter: PropTypes.func.isRequired,
  handleSubmit: PropTypes.func.isRequired,
  submitting: PropTypes.bool,
  valid: PropTypes.bool
};

export const consolidateSourceMeatOrdersByProductCode = sourceMeatOrders => {
  const sourceMeatOrdersByProductCode = _.groupBy(sourceMeatOrders, 'targetProductCode');

  return _.map(sourceMeatOrdersByProductCode, sourceMeatOrder => {
    return { ...sourceMeatOrder[0], quantity: _.sumBy(sourceMeatOrder, 'quantity') };
  });
};

export const consolidateAdditives = sourceMeatOrders => {
  const additives = _.flatten(
    _.map(sourceMeatOrders, sourceMeatOrder => sourceMeatOrder.additives)
  );
  const additivesGroupedByCode = _.groupBy(additives, 'productCode');

  return _.map(additivesGroupedByCode, additive => {
    return { ...additive[0], quantity: _.sumBy(additive, 'quantity') };
  });
};

const mapStateToProps = state => {
  const sourceMeatOrders = state.sourceMeatInfo.sourceMeatOrders;
  const consolidateSourceMeatOrders = consolidateSourceMeatOrdersByProductCode(sourceMeatOrders);
  const consolidatedAdditives = consolidateAdditives(sourceMeatOrders);

  const initialValues = {};

  if (!_.isEmpty(consolidateSourceMeatOrders)) {
    consolidateSourceMeatOrders.forEach(sourceMeatOrder => {
      const key = `${sourceMeatOrder.targetProductCode}-quantity`;
      initialValues[key] = sourceMeatOrder.quantity;
    });
  }

  if (!_.isEmpty(consolidatedAdditives)) {
    consolidatedAdditives.forEach(additive => {
      const key = `${additive.productCode}-additives-quantity`;
      initialValues[key] = additive.quantity;
    });
  }

  return {
    initialValues,
    sourceMeatOrders,
    consolidateSourceMeatOrders,
    consolidatedAdditives,
    confirmedOrderIds: state.cutOrdersInfo.cutOrdersInfo
      .filter(item => item.selected)
      .map(item => item.data.id)
  };
};

const mapDispatchToProps = dispatch =>
  bindActionCreators(
    {
      calcSourceMeat,
      returnToPreviousPage,
      generateSourceMeatOrders,
      setHeaderAndFooter,
      replacePath
    },
    dispatch
  );

export const f4Behavior = props => {
  const {
    match: {
      params: { stationId }
    },
    replacePath
  } = props;
  const path = `/cut/stations/${stationId}/tables`;
  replacePath(path);
};

const CutOrdersSourceMeatRequest = connect(
  mapStateToProps,
  mapDispatchToProps
)(
  reduxForm({
    form: 'cutOrdersSourceMeatRequestForm',
    enableReinitialize: true
  })(
    subscriber(CutOrdersSourceMeatRequestComponent, {
      f4Behavior,
      targetComponent: 'CutOrdersSourceMeatRequest',
      uris: {
        F4: ['#/cut/stations/*/tables/*/source-meat/request']
      }
    })
  )
);

export default CutOrdersSourceMeatRequest;
