import React from 'react';
import PropTypes from 'prop-types';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import { getCutStationSummary } from '../actions/cutActions';
import { changePath, getOperatingDates, setHeaderAndFooter } from '../../shared/actions/actions';
import { prepareFormatOperatingDate, prepareStationItemData } from '../../shared/util/dataUtil';
import { CUTTING_STATIONS } from '../../shared/components/pageTitles';
import NavigationTable from '../../shared/components/tables/NavigationTable';
import { CUTTING_STATIONS_FOOTER } from '../../shared/components/pageFooters';

class CutStationSummary extends React.Component {
  componentDidMount() {
    this.props.getOperatingDates();
    this.props.getCutStationSummary();
    this.props.setHeaderAndFooter({
      header: CUTTING_STATIONS,
      footer: CUTTING_STATIONS_FOOTER
    });
  }

  getColumns() {
    const { firstDay, secondDay } = this.props;

    return [
      {
        key: 'stationCode',
        headerText: 'Station',
        width: 1,
        value: data => <div className='body-item__number'>{data.stationCode}</div>
      },
      { key: 'name', headerText: 'NAME', width: 7 },
      { key: 'todayTotal', headerText: firstDay, width: 2 },
      { key: 'tomorrowTotal', headerText: secondDay, width: 2 },
      { key: 'futureTotal', headerText: 'FUTURE', width: 2 },
      { key: 'total', headerText: 'TOTAL', width: 2 }
    ];
  }

  navigateToTableSummary(selectedStation) {
    this.props.changePath(`/cut/stations/${selectedStation.stationId}/tables`);
  }

  render() {
    return (
      <div className='page-content' tabIndex={0}>
        <NavigationTable
          className={'cut-station-summary'}
          columns={this.getColumns()}
          name={'cut-station-summary'}
          items={this.props.stations}
          onClick={item => this.navigateToTableSummary(item)}
        />
      </div>
    );
  }
}

CutStationSummary.propTypes = {
  stations: PropTypes.array,
  firstDay: PropTypes.string.isRequired,
  secondDay: PropTypes.string.isRequired,

  getCutStationSummary: PropTypes.func.isRequired,
  changePath: PropTypes.func.isRequired,
  getOperatingDates: PropTypes.func.isRequired,
  setHeaderAndFooter: PropTypes.func.isRequired
};

const mapStateToProps = state => {
  const { firstDay, secondDay } = prepareFormatOperatingDate(state.operatingDates);
  const cutStationSummary = state.cutStationSummary.stations
    ? state.cutStationSummary.stations.map(item => {
        const { todayTotal, tomorrowTotal, futureTotal, total } = prepareStationItemData(
          item,
          firstDay,
          secondDay
        );
        return { ...item, todayTotal, tomorrowTotal, futureTotal, total };
      })
    : null;

  return {
    stations: cutStationSummary,
    firstDay,
    secondDay
  };
};

const mapDispatchToProps = dispatch =>
  bindActionCreators(
    {
      getCutStationSummary,
      getOperatingDates,
      changePath,
      setHeaderAndFooter
    },
    dispatch
  );

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(CutStationSummary);
