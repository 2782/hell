import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { replacePath, setHeaderAndFooter } from '../../shared/actions/actions';
import HeaderNavigation from '../../shared/components/HeaderNavigation';
import { CUT_STATION } from '../../shared/components/pageTitles';
import { bindActionCreators } from 'redux';
import { clearConsolidatedView } from '../actions/cutActions';
import CutOrderTable from '../components/CutOrderTable';
import CutOrderPrompt from '../components/CutOrderPrompt';
import { CUT_ORDERS_SOURCE_MEAT_FOOTER } from '../../shared/components/pageFooters';
import subscriber from '../../shared/functionKeys/subscriber';
import ConsolidatedCutOrderTable from '../components/ConsolidatedCutOrderTable';

export class CutOrdersSourceMeat extends React.Component {
  constructor(props) {
    super(props);

    this.handleYes = this.handleYes.bind(this);
    this.handleNo = this.handleNo.bind(this);
  }

  componentDidMount() {
    this.props.setHeaderAndFooter({
      header: CUT_STATION,
      footer: CUT_ORDERS_SOURCE_MEAT_FOOTER
    });
  }

  handleYes() {
    const {
      replacePath,
      match: {
        params: { tableId, stationId }
      },
      clearConsolidatedView
    } = this.props;
    clearConsolidatedView();
    replacePath(`/cut/stations/${stationId}/tables/${tableId}/source-meat/request`);
  }

  handleNo() {
    const {
      replacePath,
      match: {
        params: { stationId }
      },
      clearConsolidatedView
    } = this.props;
    clearConsolidatedView();
    replacePath(`/cut/stations/${stationId}/tables`);
  }

  render() {
    const { cutOrdersInfo, isConsolidated } = this.props;
    const { stationCode, name, tableCode, tableDescription } = this.props.portionRoomTableInfo;

    return (
      <div className='page-content'>
        <HeaderNavigation
          stationCode={stationCode}
          stationName={name}
          tableCode={tableCode}
          tableDescription={tableDescription}
          renderToggle={true}
          toggleText='Consolidate'
          onToggle={() => {}}
          toggleValue={isConsolidated}
          toggleDisabled={true}
        />

        {isConsolidated ? (
          <ConsolidatedCutOrderTable
            tabbable={false}
            cutOrdersInfo={cutOrdersInfo.filter(item => item.selected)}
            handleSelect={() => {}}
            handleConfirm={() => {}}
          />
        ) : (
          <CutOrderTable
            key={0}
            tabbable={false}
            cutOrdersInfo={cutOrdersInfo.filter(item => item.selected)}
            handleSelect={() => {}}
            handleConfirm={() => {}}
          />
        )}

        <CutOrderPrompt
          handleYes={this.handleYes}
          handleNo={this.handleNo}
          yesButtonText='Yes'
          yesButtonDisbled={false}
          noButtonText='No'
          message='Do you need meat?'
        />
      </div>
    );
  }
}

CutOrdersSourceMeat.propTypes = {
  cutOrdersInfo: PropTypes.array,
  isConsolidated: PropTypes.bool,
  match: PropTypes.object,
  portionRoomTableInfo: PropTypes.object,
  operatingDates: PropTypes.object,

  replacePath: PropTypes.func,
  setHeaderAndFooter: PropTypes.func,
  clearConsolidatedView: PropTypes.func
};

const mapStateToProps = state => ({
  portionRoomTableInfo: state.portionRoomTableInfo,
  operatingDates: state.operatingDates,
  cutOrdersInfo: state.cutOrdersInfo.cutOrdersInfo,
  isConsolidated: state.cutOrdersInfo.isConsolidated
});

const mapDispatchToProps = dispatch =>
  bindActionCreators(
    {
      replacePath,
      clearConsolidatedView,
      setHeaderAndFooter
    },
    dispatch
  );

export const f4Behavior = props => {
  const {
    replacePath,
    match: {
      params: { stationId }
    },
    clearConsolidatedView
  } = props;
  clearConsolidatedView();
  replacePath(`/cut/stations/${stationId}/tables`);
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(
  subscriber(CutOrdersSourceMeat, {
    f4Behavior,
    targetComponent: 'CutOrdersSourceMeat',
    uris: {
      F4: ['#/cut/stations/*/tables/*/source-meat']
    }
  })
);
