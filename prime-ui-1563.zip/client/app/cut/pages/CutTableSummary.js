import _ from 'lodash';
import React from 'react';
import PropTypes from 'prop-types';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import { getCutOrdersInfo, getCutStation, getCutTablesInfo } from '../actions/cutActions';
import {
  replacePath,
  getOperatingDates,
  getPortionRoomTableInfo,
  setHeaderAndFooter
} from '../../shared/actions/actions';
import HeaderNavigation from '../../shared/components/HeaderNavigation';
import { prepareFormatOperatingDate, prepareTableItemData } from '../../shared/util/dataUtil';
import { TABLE_SUMMARY_CUTTING } from '../../shared/components/pageTitles';
import { NavigationTable } from '../../shared/components/tables/NavigationTable';
import { TABLE_SUMMARY_CUTTING_FOOTER } from '../../shared/components/pageFooters';

export class CutTableSummary extends React.Component {
  componentDidMount() {
    const stationId = _.get(this.props.match, 'params.stationId');

    this.props.getOperatingDates();
    this.props.getCutTablesInfo(stationId);
    this.props.getCutStation(stationId);
    this.props.setHeaderAndFooter({
      header: TABLE_SUMMARY_CUTTING,
      footer: TABLE_SUMMARY_CUTTING_FOOTER
    });
  }

  getColumns() {
    const { firstDay, secondDay } = this.props;

    return [
      {
        key: 'tableCode',
        headerText: 'TABLE',
        width: 1,
        value: data => <div className='body-item__number'>{data.tableCode}</div>
      },
      { key: 'tableDescription', headerText: 'DESCRIPTION', width: 7 },
      { key: 'todayTotal', headerText: firstDay, width: 2 },
      { key: 'tomorrowTotal', headerText: secondDay, width: 2 },
      { key: 'futureTotal', headerText: 'FUTURE', width: 2 },
      { key: 'total', headerText: 'TOTAL', width: 2 }
    ];
  }

  navigateToCutOrder({ tableId }) {
    const { stationId } = this.props.match.params;

    this.props.getCutOrdersInfo(tableId);
    this.props.getPortionRoomTableInfo(tableId);

    this.props.replacePath(`/cut/stations/${stationId}/tables/${tableId}/select`);
  }

  render() {
    const { cutTableSummary, cutStation } = this.props;

    return (
      <div className='page-content'>
        <HeaderNavigation stationCode={cutStation.stationCode} stationName={cutStation.name} />
        <NavigationTable
          className={'cut-table-summary'}
          columns={this.getColumns()}
          name={'cut-table-summary'}
          items={cutTableSummary}
          onClick={item => this.navigateToCutOrder(item)}
        />
      </div>
    );
  }
}

CutTableSummary.propTypes = {
  cutStation: PropTypes.object.isRequired,
  cutTableSummary: PropTypes.array,
  match: PropTypes.object.isRequired,
  firstDay: PropTypes.string.isRequired,
  secondDay: PropTypes.string.isRequired,

  getCutOrdersInfo: PropTypes.func.isRequired,
  getPortionRoomTableInfo: PropTypes.func.isRequired,
  getCutTablesInfo: PropTypes.func.isRequired,
  replacePath: PropTypes.func.isRequired,
  getCutStation: PropTypes.func.isRequired,
  getOperatingDates: PropTypes.func.isRequired,
  setHeaderAndFooter: PropTypes.func.isRequired
};

const mapStateToProps = state => {
  const { firstDay, secondDay } = prepareFormatOperatingDate(state.operatingDates);
  const tables = state.cutTablesInfo.tables;

  const cutTableSummary = tables
    ? tables.map(item => {
        const { todayTotal, tomorrowTotal, futureTotal, total } = prepareTableItemData(
          item,
          firstDay,
          secondDay
        );
        return { ...item, todayTotal, tomorrowTotal, futureTotal, total };
      })
    : null;

  return {
    cutStation: state.cutTablesInfo.cutStation,
    cutTableSummary: cutTableSummary,
    firstDay,
    secondDay
  };
};

const mapDispatchToProps = dispatch =>
  bindActionCreators(
    {
      getCutTablesInfo,
      getCutStation,
      getPortionRoomTableInfo,
      getCutOrdersInfo,
      getOperatingDates,
      replacePath,
      setHeaderAndFooter
    },
    dispatch
  );

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(CutTableSummary);
