import React from 'react';
import { mount, shallow } from 'enzyme';
import { Provider } from 'react-redux';
import store from '../../../store';
import CutTableSummary, { CutTableSummary as CutTableSummaryComponent } from '../CutTableSummary';
import cutTableSummaryResources from '../../../shared/api/cutTableSummaryResources';
import operatingDatesResource from '../../../shared/api/operatingDatesResource';
import { TABLE_SUMMARY_1, TABLE_SUMMARY_2 } from '../../../../test-factories/cutOrder';
import NavigationTable from '../../../shared/components/tables/NavigationTable';

jest.mock('../../../shared/api/cutTableSummaryResources');
jest.mock('../../../shared/api/operatingDatesResource');

const cutTableSummaryResponse = {
  data: [TABLE_SUMMARY_1, TABLE_SUMMARY_2]
};

const operatingDateResponse = {
  data: {
    today: '2018-05-04',
    first: '2018-05-04',
    second: '2018-05-05'
  }
};

describe('CutTableSummary', () => {
  let wrapper, instance;

  afterEach(() => {
    cutTableSummaryResources.getCutTablesSummary.mockReset();
    operatingDatesResource.getOperatingDates.mockReset();
  });

  test('should navigate to cut order selection, get orders info, and get table info when selecting a table', () => {
    const replacePath = jest.fn();
    const getCutOrdersInfo = jest.fn();
    const getPortionRoomTableInfo = jest.fn();

    const wrapper = shallow(
      <CutTableSummaryComponent
        match={{ params: { stationId: 12 } }}
        replacePath={replacePath}
        cutStation={{}}
        getOperatingDates={() => {}}
        getCutTablesInfo={() => {}}
        getCutStation={() => {}}
        firstDay={'today'}
        secondDay={'tomorrow'}
        getCutOrdersInfo={getCutOrdersInfo}
        getPortionRoomTableInfo={getPortionRoomTableInfo}
        setHeaderAndFooter={() => {}}
      />
    );

    wrapper.instance().navigateToCutOrder({ tableId: 14 });

    jestExpect(getCutOrdersInfo).toHaveBeenCalledWith(14);
    jestExpect(getPortionRoomTableInfo).toHaveBeenCalledWith(14);
    jestExpect(replacePath).toHaveBeenCalledWith('/cut/stations/12/tables/14/select');
  });

  test('should initialize redux store with tables to cut and map to props', () => {
    cutTableSummaryResources.getCutTablesSummary.mockImplementation((arg1, arg2, callback) =>
      callback(cutTableSummaryResponse)
    );
    operatingDatesResource.getOperatingDates.mockImplementation((arg, callback) =>
      callback(operatingDateResponse)
    );

    wrapper = mount(
      <Provider store={store}>
        <CutTableSummary match={{ params: { stationId: '1' } }} />
      </Provider>
    );

    instance = wrapper.find('CutTableSummary').instance();

    const cutTableSummary = [
      { ...TABLE_SUMMARY_1, todayTotal: 60, tomorrowTotal: 50, futureTotal: 0, total: 110 },
      { ...TABLE_SUMMARY_2, todayTotal: 6, tomorrowTotal: 15, futureTotal: 0, total: 21 }
    ];
    jestExpect(instance.props.cutTableSummary).toEqual(cutTableSummary);
    jestExpect(wrapper.find(NavigationTable)).toExist();
    jestExpect(wrapper.find(NavigationTable)).toHaveProp({
      name: 'cut-table-summary',
      items: cutTableSummary,
      columns: [
        {
          key: 'tableCode',
          headerText: 'TABLE',
          width: 1,
          value: jestExpect.any(Function)
        },
        {
          key: 'tableDescription',
          headerText: 'DESCRIPTION',
          width: 7
        },
        {
          key: 'todayTotal',
          headerText: '05-04',
          width: 2
        },
        {
          key: 'tomorrowTotal',
          headerText: '05-05',
          width: 2
        },
        {
          key: 'futureTotal',
          headerText: 'FUTURE',
          width: 2
        },
        {
          key: 'total',
          headerText: 'TOTAL',
          width: 2
        }
      ]
    });
  });
});
