import React from 'react';
import { mount, shallow } from 'enzyme';
import { Provider } from 'react-redux';
import { createReduxStore } from '../../../store';
import {
  cutOrder1WithNames,
  cutOrder2WithNames
} from '../../../shared/testData/cutOrdersForTesting';

import CutOrdersSourceMeat, {
  CutOrdersSourceMeat as CutOrdersSourceMeatComponent,
  f4Behavior
} from '../CutOrdersSourceMeat';
import CutOrderTable from '../../components/CutOrderTable';
import CutOrderPrompt from '../../components/CutOrderPrompt';
import ConsolidatedCutOrderTable from '../../components/ConsolidatedCutOrderTable';
import HeaderNavigation from '../../../shared/components/HeaderNavigation';

jest.mock('../../../shared/components/Header');
jest.mock('../../../shared/errors/ErrorNotification');

describe('CutOrdersSourceMeat', () => {
  let wrapper;
  let store;

  beforeEach(() => {
    store = createReduxStore({
      operatingDates: {
        today: '2017-01-07',
        firstDay: '2017-01-07',
        secondDay: '2017-01-08'
      },
      cutOrdersInfo: {
        cutOrdersInfo: [
          { index: 0, data: cutOrder2WithNames, selected: true },
          { index: 1, data: cutOrder1WithNames, selected: false }
        ]
      }
    });

    wrapper = mount(
      <Provider store={store}>
        <CutOrdersSourceMeat match={{ params: { tableId: '1', stationId: '1' } }} />
      </Provider>
    );
  });

  test('should render a modal asking if user would like to request meat', () => {
    jestExpect(wrapper.find(CutOrderTable)).toExist();
    jestExpect(wrapper.find(CutOrderTable)).toHaveProp({
      tabbable: false,
      cutOrdersInfo: [{ data: cutOrder2WithNames, index: 0, selected: true }]
    });
    jestExpect(wrapper.find(CutOrderPrompt)).toExist();
    jestExpect(wrapper.find(CutOrderPrompt)).toHaveProp({ message: 'Do you need meat?' });
  });

  test('should change to tables list and clear consolidated view when user chooses no', () => {
    const replacePath = jest.fn();
    const clearConsolidatedView = jest.fn();

    wrapper = mount(
      <CutOrdersSourceMeatComponent
        replacePath={replacePath}
        match={{ params: { stationId: 1, tableId: 1 } }}
        operatingDates={{
          today: '2017-01-07',
          firstDay: '2017-01-07',
          secondDay: '2017-01-08'
        }}
        cutOrdersInfo={[
          { index: 0, data: cutOrder2WithNames, selected: true },
          { index: 1, data: cutOrder1WithNames, selected: false }
        ]}
        portionRoomTableInfo={{}}
        setHeaderAndFooter={() => {}}
        clearConsolidatedView={clearConsolidatedView}
      />
    );

    wrapper
      .find(CutOrderPrompt)
      .props()
      .handleNo();

    jestExpect(clearConsolidatedView).toHaveBeenCalledTimes(1);
    jestExpect(replacePath).toHaveBeenCalledWith('/cut/stations/1/tables');
  });

  test('should change to source meat request and clear consolidated view when user chooses yes', () => {
    const replacePath = jest.fn();
    const clearConsolidatedView = jest.fn();

    wrapper = mount(
      <CutOrdersSourceMeatComponent
        replacePath={replacePath}
        match={{ params: { stationId: 1, tableId: 1 } }}
        operatingDates={{
          today: '2017-01-07',
          firstDay: '2017-01-07',
          secondDay: '2017-01-08'
        }}
        cutOrdersInfo={[
          { index: 0, data: cutOrder2WithNames, selected: true },
          { index: 1, data: cutOrder1WithNames, selected: false }
        ]}
        portionRoomTableInfo={{}}
        setHeaderAndFooter={() => {}}
        clearConsolidatedView={clearConsolidatedView}
      />
    );

    wrapper
      .find(CutOrderPrompt)
      .props()
      .handleYes();

    jestExpect(clearConsolidatedView).toHaveBeenCalledTimes(1);
    jestExpect(replacePath).toHaveBeenCalledWith('/cut/stations/1/tables/1/source-meat/request');
  });

  test('should return to table selection on f4 when no orders are selected', () => {
    const props = {
      match: { params: { stationId: 123 } },
      replacePath: jest.fn(),
      clearConsolidatedView: jest.fn()
    };

    f4Behavior(props);

    jestExpect(props.clearConsolidatedView).toHaveBeenCalledTimes(1);
    jestExpect(props.replacePath).toHaveBeenCalledWith('/cut/stations/123/tables');
  });

  describe('Header Navigation', () => {
    test('should pass in station, table, and consolidation toggle information to navigation header', () => {
      const portionRoomTableInfo = {
        stationCode: 45,
        name: 'JOHN',
        tableCode: 91,
        tableDescription: 'BEEF'
      };

      wrapper = shallow(
        <CutOrdersSourceMeatComponent
          match={{ params: { stationId: 1, tableId: 1 } }}
          setHeaderAndFooter={() => {}}
          cutOrdersInfo={[]}
          portionRoomTableInfo={portionRoomTableInfo}
          toggleConsolidatedView={() => {}}
          isConsolidated={true}
        />
      );

      jestExpect(wrapper.find(HeaderNavigation)).toExist();
      jestExpect(wrapper.find(HeaderNavigation)).toHaveProp({
        stationCode: portionRoomTableInfo.stationCode,
        stationName: portionRoomTableInfo.name,
        tableCode: portionRoomTableInfo.tableCode,
        tableDescription: portionRoomTableInfo.tableDescription,
        toggleText: 'Consolidate',
        toggleValue: true,
        renderToggle: true,
        toggleDisabled: true
      });
    });
  });

  test('should render consolidatedTable when consolidated toggle is on', () => {
    const wrapper = shallow(
      <CutOrdersSourceMeatComponent
        setHeaderAndFooter={() => {}}
        cutOrdersInfo={[{}]}
        portionRoomTableInfo={{}}
        match={{ params: { stationId: 123 } }}
        isConsolidated={true}
      />
    );

    jestExpect(wrapper.find(ConsolidatedCutOrderTable)).toExist();
  });
});
