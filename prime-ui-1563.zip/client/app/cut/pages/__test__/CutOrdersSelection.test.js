import { CUT_STATION } from '../../../shared/components/pageTitles';
import React from 'react';
import { mount, shallow } from 'enzyme';
import { Provider } from 'react-redux';
import { createReduxStore } from '../../../store';
import { Table } from 'semantic-ui-react';
import {
  cutOrder1WithNames,
  cutOrder2WithNames,
  cutOrderOnHold1,
  cutOrderOnHold2,
  cutOrderOnHold3
} from '../../../shared/testData/cutOrdersForTesting';

import CutOrdersSelection, {
  buildOnHoldCustomersModalMessage,
  CutOrdersSelectionComponent,
  f2Behavior,
  f4Behavior
} from '../CutOrdersSelection';
import EmptyCutOrderTable from '../../components/EmptyCutOrderTable';
import CutOrderTable from '../../components/CutOrderTable';
import { CUT_ORDERS_SELECTION_FOOTER } from '../../../shared/components/pageFooters';
import { getCostByProductCode_promise } from '../../../shared/api/costResources';
import HeaderNavigation from '../../../shared/components/HeaderNavigation';
import ConsolidatedCutOrderTable from '../../components/ConsolidatedCutOrderTable';

jest.mock('../../../shared/errors/ErrorNotification');

jest.mock('../../../shared/api/costResources', () => ({
  getCostByProductCode_promise: jest.fn()
}));
jest.mock('../../../shared/actions/actions', () => ({
  replacePath: jest.fn(() => ({ type: 'MOCK_REPLACE_PATH' })),
  changePath: jest.fn(() => ({ type: 'MOCK_CHANGE_PATH' })),
  hideModal: jest.fn(() => ({ type: 'MOCK_HIDE_MODAL' })),
  showModal: jest.fn(() => ({ type: 'MOCK_SHOW_MODAL' })),
  setHeaderAndFooter: jest.fn(() => ({ type: 'MOCK_SET_HEADER_FOOTER' }))
}));

describe('CutOrdersSelection', () => {
  let wrapper;
  let store;

  beforeEach(() => {
    jest.useFakeTimers();
    store = createReduxStore({
      operatingDates: {
        today: '2017-01-07',
        firstDay: '2017-01-07',
        secondDay: '2017-01-08'
      },
      cutOrdersInfo: {
        cutOrdersInfo: [
          { index: 0, data: cutOrder2WithNames, selected: false },
          { index: 1, data: cutOrder1WithNames, selected: false }
        ]
      }
    });

    getCostByProductCode_promise.mockImplementation(() => {
      return Promise.resolve({ data: { cost: 12, labor: 1.0 } });
    });

    wrapper = mount(
      <Provider store={store}>
        <CutOrdersSelection match={{ params: { tableId: '1', stationId: '1' } }} />
      </Provider>
    );
  });

  afterEach(() => {
    jest.clearAllTimers();
  });

  describe('Header Navigation', () => {
    test('should pass in station, table, and consolidation toggle information to navigation header', () => {
      const toggleConsolidatedView = jest.fn();
      const portionRoomTableInfo = {
        stationCode: 45,
        name: 'JOHN',
        tableCode: 91,
        tableDescription: 'BEEF'
      };

      wrapper = shallow(
        <CutOrdersSelectionComponent
          match={{ params: { stationId: 1, tableId: 1 } }}
          setHeaderAndFooter={() => {}}
          cutOrdersInfo={[{}]}
          portionRoomTableInfo={portionRoomTableInfo}
          toggleConsolidatedView={toggleConsolidatedView}
          isConsolidated={true}
        />
      );

      jestExpect(wrapper.find(HeaderNavigation)).toExist();
      jestExpect(wrapper.find(HeaderNavigation)).toHaveProp({
        stationCode: portionRoomTableInfo.stationCode,
        stationName: portionRoomTableInfo.name,
        tableCode: portionRoomTableInfo.tableCode,
        tableDescription: portionRoomTableInfo.tableDescription,
        toggleText: 'Consolidate',
        toggleValue: true,
        renderToggle: true,
        onToggle: toggleConsolidatedView,
        toggleDisabled: false
      });
    });
  });

  describe('when there are no orders to cut', () => {
    test('should not render empty table or cutOrderTable when cutOrdersInfo is null', () => {
      wrapper = shallow(
        <CutOrdersSelectionComponent
          match={{ params: { tableId: '1', stationId: '1' } }}
          cutOrdersInfo={null}
          portionRoomTableInfo={{}}
          setHeaderAndFooter={() => {}}
        />
      );

      jestExpect(wrapper.find(EmptyCutOrderTable)).not.toExist();
      jestExpect(wrapper.find(CutOrderTable)).not.toExist();
    });

    test('should render empty cut order table', () => {
      store = createReduxStore({
        operatingDates: {
          today: '2017-01-07',
          firstDay: '2017-01-07',
          secondDay: '2017-01-08'
        },
        cutOrdersInfo: {
          cutOrdersInfo: []
        }
      });

      wrapper = mount(
        <Provider store={store}>
          <CutOrdersSelection match={{ params: { tableId: '1', stationId: '1' } }} />
        </Provider>
      );

      jestExpect(wrapper.find(EmptyCutOrderTable)).toExist();
    });
  });

  describe('when there are orders to cut', () => {
    test('should render cut orders table with all cut orders when selecting', () => {
      jestExpect(wrapper.find(CutOrderTable)).toExist();
      jestExpect(wrapper.find(CutOrderTable).props().cutOrdersInfo).toEqual([
        { data: cutOrder2WithNames, index: 0, selected: false },
        { data: cutOrder1WithNames, index: 1, selected: false }
      ]);
    });

    test('should build credit hold message with single customer', () => {
      const message = buildOnHoldCustomersModalMessage(['9']);
      jestExpect(message).toEqual(
        'Customer 9 is on credit hold. Are you sure you want to produce orders for this customer?'
      );
    });

    test('should build credit hold message with two customers', () => {
      const message = buildOnHoldCustomersModalMessage(['6', '4']);
      jestExpect(message).toEqual(
        'Customers 6 and 4 are on credit hold. Are you sure you want to produce orders for these customers?'
      );
    });

    test('should build credit hold message with three customers', () => {
      const message = buildOnHoldCustomersModalMessage(['3', '4', '2']);
      jestExpect(message).toEqual(
        'Customers 3, 4 and 2 are on credit hold. Are you sure you want to produce orders for these customers?'
      );
    });

    test('should navigate to confirmation page on enter when a cut order is selected and none are on hold', () => {
      const replacePath = jest.fn();
      const stopPropagation = jest.fn();
      const preventDefault = jest.fn();
      const setHeaderAndFooter = jest.fn();

      wrapper = mount(
        <CutOrdersSelectionComponent
          replacePath={replacePath}
          clearCutOrderSelection={() => {}}
          match={{ params: { stationId: 1, tableId: 1 } }}
          operatingDates={{
            today: '2017-01-07',
            firstDay: '2017-01-07',
            secondDay: '2017-01-08'
          }}
          cutOrdersInfo={[
            { index: 0, data: cutOrder2WithNames, selected: true },
            { index: 1, data: cutOrder1WithNames, selected: false }
          ]}
          portionRoomTableInfo={{}}
          toggleCutOrderSelection={() => {}}
          toggleConsolidatedView={() => {}}
          setHeaderAndFooter={setHeaderAndFooter}
          getCutOrdersInfo={() => {}}
          hideModal={() => {}}
          showModal={() => {}}
          unSelectCutOrders={() => {}}
        />
      );

      wrapper
        .find(Table.Row)
        .at(1)
        .simulate('keydown', { key: 'Enter', stopPropagation, preventDefault });

      jestExpect(stopPropagation).toHaveBeenCalledTimes(1);
      jestExpect(preventDefault).toHaveBeenCalledTimes(1);
      jestExpect(replacePath).toHaveBeenCalledWith('/cut/stations/1/tables/1/confirm');
      jestExpect(setHeaderAndFooter).toHaveBeenCalledWith({
        header: CUT_STATION,
        footer: CUT_ORDERS_SELECTION_FOOTER
      });
    });

    test('should show on credit hold modal on enter when an on hold cut order is selected', () => {
      const replacePath = jest.fn();
      const showModal = jest.fn();

      wrapper = mount(
        <CutOrdersSelectionComponent
          replacePath={replacePath}
          showModal={showModal}
          hideModal={() => {}}
          clearCutOrderSelection={() => {}}
          match={{ params: { stationId: 1, tableId: 1 } }}
          operatingDates={{
            today: '2017-01-07',
            firstDay: '2017-01-07',
            secondDay: '2017-01-08'
          }}
          cutOrdersInfo={[{ index: 0, data: cutOrderOnHold1, selected: true }]}
          portionRoomTableInfo={{}}
          toggleCutOrderSelection={() => {}}
          toggleConsolidatedView={() => {}}
          setHeaderAndFooter={() => {}}
          getCutOrdersInfo={() => {}}
        />
      );

      wrapper
        .find(Table.Row)
        .at(1)
        .simulate('keydown', { key: 'Enter', stopPropagation: () => {}, preventDefault: () => {} });

      jestExpect(replacePath).not.toHaveBeenCalled();
      jestExpect(showModal).toHaveBeenCalledWith({
        header: 'Customer on Credit Hold',
        content:
          'Customer 99998 is on credit hold. Are you sure you want to produce orders for this customer?',
        cancelButton: 'No',
        confirmButton: 'Yes',
        cancelAction: jestExpect.any(Function),
        confirmAction: jestExpect.any(Function)
      });
    });

    test('should show on credit hold modal on enter when multiple on hold cut orders are selected', () => {
      const replacePath = jest.fn();
      const showModal = jest.fn();

      wrapper = mount(
        <CutOrdersSelectionComponent
          replacePath={replacePath}
          showModal={showModal}
          hideModal={() => {}}
          clearCutOrderSelection={() => {}}
          match={{ params: { stationId: 1, tableId: 1 } }}
          operatingDates={{
            today: '2017-01-07',
            firstDay: '2017-01-07',
            secondDay: '2017-01-08'
          }}
          cutOrdersInfo={[
            { index: 0, data: cutOrderOnHold1, selected: true },
            { index: 1, data: cutOrderOnHold2, selected: true },
            { index: 2, data: cutOrderOnHold3, selected: true }
          ]}
          portionRoomTableInfo={{}}
          toggleCutOrderSelection={() => {}}
          toggleConsolidatedView={() => {}}
          setHeaderAndFooter={() => {}}
          getCutOrdersInfo={() => {}}
        />
      );

      wrapper
        .find(Table.Row)
        .at(1)
        .simulate('keydown', { key: 'Enter', stopPropagation: () => {}, preventDefault: () => {} });

      jestExpect(replacePath).not.toHaveBeenCalled();
      jestExpect(showModal).toHaveBeenCalledWith({
        header: 'Customer on Credit Hold',
        content:
          'Customers 99998, 12121 and 23232 are on credit hold. Are you sure you want to produce orders for these customers?',
        cancelButton: 'No',
        confirmButton: 'Yes',
        cancelAction: jestExpect.any(Function),
        confirmAction: jestExpect.any(Function)
      });
    });

    test('should not navigate to confirmation page on enter when no cut order is selected', () => {
      const replacePath = jest.fn();
      wrapper = mount(
        <CutOrdersSelectionComponent
          replacePath={replacePath}
          clearCutOrderSelection={() => {}}
          match={{ params: { stationId: 1, tableId: 1 } }}
          operatingDates={{
            today: '2017-01-07',
            firstDay: '2017-01-07',
            secondDay: '2017-01-08'
          }}
          cutOrdersInfo={[
            { index: 0, data: cutOrder2WithNames, selected: false },
            { index: 1, data: cutOrder1WithNames, selected: false }
          ]}
          portionRoomTableInfo={{}}
          toggleCutOrderSelection={() => {}}
          toggleConsolidatedView={() => {}}
          setHeaderAndFooter={() => {}}
          getCutOrdersInfo={() => {}}
        />
      );

      wrapper
        .find(Table.Row)
        .at(1)
        .simulate('keydown', { key: 'Enter' });

      jestExpect(replacePath).not.toHaveBeenCalled();
    });
  });

  describe('auto-refresh data', () => {
    let cutOrdersSelectionComponent;

    beforeEach(() => {
      jest.useFakeTimers();
      cutOrdersSelectionComponent = new CutOrdersSelectionComponent({
        clearCutOrderSelection: () => {},
        setHeaderAndFooter: () => {},
        match: { params: { stationId: 1, tableId: 1 } },
        getCutOrdersInfo: () => {}
      });
    });

    afterEach(() => {
      jest.clearAllTimers();
    });

    test('should call setInterval when componentDidMount', () => {
      cutOrdersSelectionComponent.componentDidMount();
      jestExpect(setInterval).toHaveBeenCalledTimes(1);
    });

    test('should call clearInterval when componentWillUnmount', () => {
      cutOrdersSelectionComponent.componentWillUnmount();
      jestExpect(clearInterval).toHaveBeenCalledTimes(1);
    });
  });

  test('should hide modal on f4 when modal is showing', () => {
    const props = {
      match: { params: { stationId: 123 } },
      isModalShowing: true,
      hideModal: jest.fn(),
      clearCutOrderSelection: () => {},
      replacePath: () => {},
      clearConsolidatedView: () => {}
    };

    f4Behavior(props);

    jestExpect(props.hideModal).toHaveBeenCalledTimes(1);
  });

  test('should return to table selection on f4 when no orders are selected', () => {
    const props = {
      match: { params: { stationId: 123 } },
      isModalShowing: false,
      hideModal: () => {},
      clearCutOrderSelection: () => {},
      replacePath: jest.fn(),
      clearConsolidatedView: jest.fn()
    };

    f4Behavior(props);

    jestExpect(props.clearConsolidatedView).toHaveBeenCalledTimes(1);
    jestExpect(props.replacePath).toHaveBeenCalledWith('/cut/stations/123/tables');
  });

  test('should toggle consolidated view on f2 for cut order selection', () => {
    const props = { toggleConsolidatedView: jest.fn(), clearCutOrderSelection: jest.fn() };

    f2Behavior(props);

    jestExpect(props.clearCutOrderSelection).toHaveBeenCalledTimes(1);
    jestExpect(props.toggleConsolidatedView).toHaveBeenCalledTimes(1);
  });

  test('should clear existing selection on f4 when orders are selected', () => {
    const props = {
      cutOrdersInfo: [{ selected: true }],
      isModalShowing: false,
      hideModal: () => {},
      match: { params: { stationId: 123 } },
      clearCutOrderSelection: jest.fn(),
      replacePath: jest.fn(),
      clearConsolidatedView: () => {}
    };

    f4Behavior(props);

    jestExpect(props.clearCutOrderSelection).toHaveBeenCalledTimes(1);
    jestExpect(props.replacePath).not.toHaveBeenCalled();
  });

  test('should render consolidatedTable when consolidated toggle is on', () => {
    const wrapper = shallow(
      <CutOrdersSelectionComponent
        setHeaderAndFooter={() => {}}
        cutOrdersInfo={[{}]}
        portionRoomTableInfo={{}}
        match={{ params: { stationId: 123 } }}
        isConsolidated={true}
      />
    );

    jestExpect(wrapper.find(ConsolidatedCutOrderTable)).toExist();
  });

  test('should toggle consolidated cut orders as selected', () => {
    const toggleConsolidatedCutOrderSelection = jest.fn();
    const instance = shallow(
      <CutOrdersSelectionComponent
        setHeaderAndFooter={() => {}}
        toggleConsolidatedCutOrderSelection={toggleConsolidatedCutOrderSelection}
        cutOrdersInfo={[{}]}
        portionRoomTableInfo={{}}
        match={{ params: { stationId: 123 } }}
        isConsolidated={true}
      />
    ).instance();

    instance.handleConsolidatedSelect([1, 2, 3], 'event', '1122334');

    jestExpect(toggleConsolidatedCutOrderSelection).toHaveBeenCalledWith(
      [1, 2, 3],
      '1122334',
      'event'
    );
  });

  test('should toggle cut order as selected', () => {
    const toggleCutOrderSelection = jest.fn();
    const instance = shallow(
      <CutOrdersSelectionComponent
        setHeaderAndFooter={() => {}}
        toggleCutOrderSelection={toggleCutOrderSelection}
        cutOrdersInfo={[{}]}
        portionRoomTableInfo={{}}
        match={{ params: { stationId: 123 } }}
        isConsolidated={true}
      />
    ).instance();

    instance.handleSelect(2, 'event', '1122334');

    jestExpect(toggleCutOrderSelection).toHaveBeenCalledWith(2, '1122334', 'event');
  });
});
