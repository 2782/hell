import SourceMeatTable from '../../components/SourceMeatTable';
import PlaceOrderButton from '../../components/PlaceOrderButton';
import React from 'react';
import { mount } from 'enzyme';
import { Provider } from 'react-redux';
import { createReduxStore } from '../../../store';
import {
  cutOrder1WithNames,
  cutOrder2WithNames
} from '../../../shared/testData/cutOrdersForTesting';
import { sourceMeatOrder1, sourceMeatOrder2 } from '../../../../test-factories/sourceMeatOrder';
import CutOrdersSourceMeatRequest, {
  addAdditives,
  addExtraAdditives,
  addExtraSourceMeatQuantity,
  consolidateAdditives,
  consolidateSourceMeatOrdersByProductCode,
  f4Behavior,
  fetchSourceMeatOrders
} from '../CutOrdersSourceMeatRequest';
import sourceMeatResources from '../../../shared/api/sourceMeatResources';
import EmptyListMessage from '../../../shared/components/EmptyListMessage';
import { Table } from 'semantic-ui-react';
import AdditivesTable from '../../components/AdditivesTable';

jest.mock('../../../shared/components/Header');
jest.mock('../../../shared/errors/ErrorNotification');
jest.mock('../../../shared/api/sourceMeatResources');

const response = {
  data: [sourceMeatOrder1, sourceMeatOrder2]
};

describe('CutOrdersSourceMeatRequest', () => {
  let wrapper;
  let store;

  beforeEach(() => {
    store = createReduxStore({
      cutOrdersInfo: {
        cutOrdersInfo: [
          { index: 0, selected: true, data: cutOrder2WithNames },
          { index: 1, selected: true, data: cutOrder1WithNames }
        ]
      }
    });

    sourceMeatResources.calcSourceMeat.mockImplementation((arg, success) => success(response));
  });

  afterEach(() => {
    sourceMeatResources.calcSourceMeat.mockReset();
    sourceMeatResources.generateSourceMeatOrders.mockReset();
  });

  describe('has item exist', () => {
    beforeEach(() => {
      wrapper = mount(
        <Provider store={store}>
          <CutOrdersSourceMeatRequest match={{ params: { stationId: '1' } }} />
        </Provider>
      );
    });

    test('should calculate source meat and update store with calculation on mount', () => {
      jestExpect(sourceMeatResources.calcSourceMeat.mock.calls[0][0]).toEqual([2, 1]);
      jestExpect(wrapper.find(SourceMeatTable)).toHaveProp({
        sourceMeatOrders: [sourceMeatOrder1, sourceMeatOrder2]
      });
    });

    test('should show additives table', () => {
      jestExpect(wrapper.find(AdditivesTable)).toHaveProp({ additives: [] });
    });

    test('should display source meat table if items exist', () => {
      jestExpect(wrapper.find(Table.Body).find(Table.Row)).toHaveLength(2);
    });

    test('should generate meat order request when source meat exists for a cut order when submit ', () => {
      wrapper.find('form').simulate('submit');
      jestExpect(sourceMeatResources.generateSourceMeatOrders.mock.calls[0][0]).toEqual([
        sourceMeatOrder1,
        sourceMeatOrder2
      ]);
    });

    test('should autofocus place order button', () => {
      jestExpect(wrapper.find(PlaceOrderButton)).toHaveProp({ focus: true });
    });
  });

  describe('no item exist', () => {
    beforeEach(() => {
      sourceMeatResources.calcSourceMeat.mockImplementation((arg, success) =>
        success({ data: [] })
      );

      wrapper = mount(
        <Provider store={store}>
          <CutOrdersSourceMeatRequest match={{ params: { stationId: '1' } }} />
        </Provider>
      );
    });

    test('should display empty message if no items exist', () => {
      jestExpect(wrapper.find(EmptyListMessage)).toExist();
    });

    test('should not generate meat order request when source meat not exists for a cut order when submit ', () => {
      wrapper.find('form').simulate('submit');
      jestExpect(sourceMeatResources.generateSourceMeatOrders).not.toHaveBeenCalled();
    });
  });

  test('should change path when exiting this page', () => {
    const props = { match: { params: { stationId: 123 } }, replacePath: jest.fn() };

    f4Behavior(props);

    jestExpect(props.replacePath).toHaveBeenCalledWith('/cut/stations/123/tables');
  });

  describe('#addExtraSourceMeatQuantity', () => {
    test('should add extra source meat quantity to source orders', () => {
      const consolidatedValues = {
        '0078889-quantity': 12,
        '0068205-quantity': 10,
        '0068777-quantity': 0
      };

      const sourceMeatOrdersToGenerate = [
        { targetProductCode: '0078889', quantity: 1 },
        { targetProductCode: '0068205', quantity: 2 },
        { targetProductCode: '0068777', quantity: 3 }
      ];

      const result = [
        { targetProductCode: '0078889', quantity: 13 },
        { targetProductCode: '0068205', quantity: 12 },
        { targetProductCode: '0068777', quantity: 3 }
      ];

      addExtraSourceMeatQuantity(consolidatedValues, sourceMeatOrdersToGenerate);

      jestExpect(sourceMeatOrdersToGenerate).toEqual(result);
    });
  });

  describe('#fetchSourceMeatOrders', () => {
    test('should generate source meat orders', () => {
      const sourceMeatOrders = [
        { targetProductCode: '0078889', quantity: 1, desc: 'desc 1' },
        { targetProductCode: '0068205', quantity: 12, desc: 'desc 2' },
        { targetProductCode: '0068777', quantity: 0, desc: 'desc 3' }
      ];

      let consolidatedValues = {
        '0078889-quantity': 12,
        '0068205-quantity': 10,
        '0068777-quantity': 0
      };

      const result = fetchSourceMeatOrders(sourceMeatOrders, consolidatedValues);

      const jestExpectedValue = [
        { targetProductCode: '0078889', quantity: 1, desc: 'desc 1' },
        { targetProductCode: '0068205', quantity: 10, desc: 'desc 2' }
      ];

      const jestExpectedConsolidatedValues = {
        '0078889-quantity': 11,
        '0068205-quantity': 0,
        '0068777-quantity': 0
      };

      jestExpect(result).toEqual(jestExpectedValue);
      jestExpect(consolidatedValues).toEqual(jestExpectedConsolidatedValues);
    });
  });

  describe('#consolidateSourceMeatOrdersByProductCode', () => {
    test('should consolidate source meat orders by product code', () => {
      const sourceMeatOrders = [
        { targetProductCode: '0078889', quantity: 1, desc: 'desc 1' },
        { targetProductCode: '0068205', quantity: 12, desc: 'desc 2' },
        { targetProductCode: '0078889', quantity: 3, desc: 'desc 3' }
      ];

      const result = consolidateSourceMeatOrdersByProductCode(sourceMeatOrders);
      const jestExpectedResult = [
        { targetProductCode: '0078889', quantity: 4, desc: 'desc 1' },
        { targetProductCode: '0068205', quantity: 12, desc: 'desc 2' }
      ];

      jestExpect(result).toEqual(jestExpectedResult);
    });
  });

  describe('#consolidateAdditives', () => {
    test('should consolidate additives by product code', () => {
      const sourceMeatOrders = [
        {
          targetProductCode: '0078889',
          quantity: 1,
          additives: [
            { productCode: '0078891', quantity: 1 },
            { productCode: '0068205', quantity: 2 }
          ]
        },
        {
          targetProductCode: '0012345',
          quantity: 1,
          additives: [{ productCode: '0078891', quantity: 3 }]
        }
      ];

      const consolidatedAdditives = consolidateAdditives(sourceMeatOrders);

      jestExpect(consolidatedAdditives).toEqual([
        { productCode: '0078891', quantity: 4 },
        { productCode: '0068205', quantity: 2 }
      ]);
    });
  });

  describe('#addAdditives', () => {
    test('should calculate additives', () => {
      const consolidatedAdditives = {
        '0068205-additives-quantity': 1,
        '0078891-additives-quantity': 6,
        '0078889-additives-quantity': 2
      };

      const sourceMeatOrders = [
        {
          targetProductCode: '0012345',
          quantity: 1,
          additives: [
            { productCode: '0078891', quantity: 1 },
            { productCode: '0068205', quantity: 2 }
          ]
        },
        {
          targetProductCode: '0012335',
          quantity: 1,
          additives: [
            { productCode: '0078891', quantity: 3 },
            { productCode: '0078889', quantity: 2 }
          ]
        }
      ];

      const result = addAdditives(sourceMeatOrders, consolidatedAdditives);

      jestExpect(result).toEqual([
        {
          targetProductCode: '0012345',
          quantity: 1,
          additives: [
            { productCode: '0078891', quantity: 1 },
            { productCode: '0068205', quantity: 1 }
          ]
        },
        {
          targetProductCode: '0012335',
          quantity: 1,
          additives: [
            { productCode: '0078891', quantity: 3 },
            { productCode: '0078889', quantity: 2 }
          ]
        }
      ]);
    });
  });

  describe('#addExtraAdditives', () => {
    test('should add extra additives if having', () => {
      const consolidatedAdditives = {
        '0078891-additives-quantity': 6,
        '0078889-additives-quantity': 2
      };

      let sourceMeatOrders = [
        {
          targetProductCode: '0012345',
          quantity: 1,
          additives: [
            { productCode: '0078891', quantity: 1 },
            { productCode: '0068205', quantity: 2 }
          ]
        },
        {
          targetProductCode: '0012335',
          quantity: 1,
          additives: [
            { productCode: '0078891', quantity: 3 },
            { productCode: '0078889', quantity: 2 }
          ]
        }
      ];

      addExtraAdditives(consolidatedAdditives, sourceMeatOrders);

      jestExpect(sourceMeatOrders).toEqual([
        {
          targetProductCode: '0012345',
          quantity: 1,
          additives: [
            { productCode: '0078891', quantity: 7 },
            { productCode: '0068205', quantity: 2 }
          ]
        },
        {
          targetProductCode: '0012335',
          quantity: 1,
          additives: [
            { productCode: '0078891', quantity: 3 },
            { productCode: '0078889', quantity: 4 }
          ]
        }
      ]);
    });
  });
});
