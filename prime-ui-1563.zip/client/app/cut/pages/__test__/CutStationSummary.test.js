import CutStationSummary from '../CutStationSummary';
import { mount } from 'enzyme';
import React from 'react';
import cutStationSummaryResources from '../../../shared/api/cutStationSummaryResources';
import store from '../../../store';
import { Provider } from 'react-redux';
import NavigationTable from '../../../shared/components/tables/NavigationTable';
import operatingDatesResource from '../../../shared/api/operatingDatesResource';
import { STATION_SUMMARY_1, STATION_SUMMARY_2 } from '../../../../test-factories/station';

jest.mock('../../../shared/api/cutStationSummaryResources');
jest.mock('../../../shared/api/operatingDatesResource');

const stationSummaryResponse = {
  data: [STATION_SUMMARY_1, STATION_SUMMARY_2]
};

const operatingDateResponse = {
  data: {
    today: '2018-05-04',
    first: '2018-05-04',
    second: '2018-05-05'
  }
};

describe('CutStationSummary', () => {
  let wrapper, instance;

  afterEach(() => {
    cutStationSummaryResources.getCutStationSummary.mockReset();
    operatingDatesResource.getOperatingDates.mockReset();
  });

  test('should initialize redux store with tables to cut and map to props', () => {
    cutStationSummaryResources.getCutStationSummary.mockImplementation((arg, success) =>
      success(stationSummaryResponse)
    );
    operatingDatesResource.getOperatingDates.mockImplementation((arg, success) =>
      success(operatingDateResponse)
    );
    wrapper = mount(
      <Provider store={store}>
        <CutStationSummary />
      </Provider>
    );

    instance = wrapper.find('CutStationSummary').instance();

    const stationSummaryData = [
      { ...STATION_SUMMARY_1, todayTotal: 3, tomorrowTotal: 2, futureTotal: 0, total: 5 },
      { ...STATION_SUMMARY_2, todayTotal: 39, tomorrowTotal: 20, futureTotal: 0, total: 59 }
    ];

    jestExpect(instance.props.stations).toEqual(stationSummaryData);
    jestExpect(wrapper.find(NavigationTable)).toExist();
    jestExpect(wrapper.find(NavigationTable)).toHaveProp({
      name: 'cut-station-summary',
      items: stationSummaryData,
      columns: [
        {
          key: 'stationCode',
          headerText: 'Station',
          width: 1,
          value: jestExpect.any(Function)
        },
        {
          key: 'name',
          headerText: 'NAME',
          width: 7
        },
        {
          key: 'todayTotal',
          headerText: '05-04',
          width: 2
        },
        {
          key: 'tomorrowTotal',
          headerText: '05-05',
          width: 2
        },
        {
          key: 'futureTotal',
          headerText: 'FUTURE',
          width: 2
        },
        {
          key: 'total',
          headerText: 'TOTAL',
          width: 2
        }
      ]
    });
  });
});
