import cutTableSummaryResources from '../../shared/api/cutTableSummaryResources';
import cutOrdersResources from '../../shared/api/cutOrdersResources';
import cutStationSummaryResources from '../../shared/api/cutStationSummaryResources';
import cutStationResources from '../../shared/api/stationResources';
import sourceMeatResources from '../../shared/api/sourceMeatResources';
import {
  CONFIRM_CUT_ORDERS_REQUESTED,
  CONFIRM_CUT_ORDERS_SUCCEEDED,
  CONSOLIDATED_CUT_ORDERS_TOGGLED,
  CONSOLIDATION_CLEARED,
  CONSOLIDATION_TOGGLED,
  CUT_ORDER_SELECTION_CLEARED,
  CUT_ORDER_SELECTION_TOGGLED,
  CUT_ORDERS_UNSELECTED,
  CUT_TABLES_INFO_UPDATED,
  RESET_CUT_STATION_INFO,
  RESET_CUT_TABLES_INFO,
  RESET_SOURCE_MEAT_INFO,
  UPDATE_CUT_ORDERS_INFO,
  UPDATE_CUT_STATION_INFO,
  UPDATE_CUT_STATION_SUMMARY,
  UPDATE_SOURCE_MEAT_INFO
} from './cutActionTypes';
import { getCostByProductCode_promise } from '../../shared/api/costResources';
import { showNoCostWarningModal } from '../../shared/actions/actions';
import productResources from '../../shared/api/productResources';
import { addProduct } from '../../shared/components/product/actionsDuplicate';
import { replace } from 'react-router-redux';

export const getCutTablesInfo = stationId => {
  return (dispatch, getState) => {
    const roomCode = getState().portionRoomsInfo.currentPortionRoom.code;
    dispatch({
      type: RESET_CUT_TABLES_INFO
    });
    cutTableSummaryResources.getCutTablesSummary(roomCode, stationId, response => {
      dispatch({
        type: CUT_TABLES_INFO_UPDATED,
        payload: response.data
      });
    });
  };
};

export const unSelectCutOrders = cutOrdersIds => ({
  type: CUT_ORDERS_UNSELECTED,
  payload: cutOrdersIds
});

export const toggleCutOrderSelection = (cutOrderId, productCode, event) => dispatch => {
  return getCostByProductCode_promise(productCode).then(({ data }) => {
    if (!data || data.cost === 0) {
      dispatch(showNoCostWarningModal([productCode], event));
    } else {
      dispatch(toggleCutOrder(cutOrderId));
    }
  });
};

export const toggleConsolidatedCutOrderSelection = (
  cutOrderIds,
  productCode,
  event
) => dispatch => {
  return getCostByProductCode_promise(productCode).then(({ data }) => {
    if (!data || data.cost === 0) {
      dispatch(showNoCostWarningModal([productCode], event));
    } else {
      dispatch(toggleConsolidatedCutOrders(cutOrderIds));
    }
  });
};

export const toggleConsolidatedView = () => ({
  type: CONSOLIDATION_TOGGLED
});

export const toggleCutOrder = cutOrderId => ({
  type: CUT_ORDER_SELECTION_TOGGLED,
  payload: cutOrderId
});

export const toggleConsolidatedCutOrders = cutOrderIds => ({
  type: CONSOLIDATED_CUT_ORDERS_TOGGLED,
  payload: cutOrderIds
});

export const clearCutOrderSelection = () => ({
  type: CUT_ORDER_SELECTION_CLEARED
});

export const clearConsolidatedView = () => ({
  type: CONSOLIDATION_CLEARED
});

export const getCutOrdersInfo = tableId => {
  return (dispatch, getState) => {
    const roomCode = getState().portionRoomsInfo.currentPortionRoom.code;

    return cutOrdersResources.getOrdersByTableId(roomCode, tableId, cutOrdersResponse => {
      dispatch({
        type: UPDATE_CUT_ORDERS_INFO,
        payload: cutOrdersResponse.data
      });
    });
  };
};

export const confirmCutOrdersRequest = (stationId, tableId) => (dispatch, getState) => {
  dispatch({
    type: CONFIRM_CUT_ORDERS_REQUESTED
  });

  const roomCode = getState().portionRoomsInfo.currentPortionRoom.code;
  const cutOrderIds = getState()
    .cutOrdersInfo.cutOrdersInfo.filter(item => item.selected)
    .map(item => item.data.id);

  return cutOrdersResources.confirmCutOrders(roomCode, cutOrderIds).then(() => {
    cutOrdersResources.printCutTickets(cutOrderIds);
    dispatch({
      type: CONFIRM_CUT_ORDERS_SUCCEEDED
    });

    dispatch(replace(`/cut/stations/${stationId}/tables/${tableId}/source-meat`));
  });
};

export const getProductPromise = productCode => dispatch => {
  return productResources.getProductInfoPromise(productCode).then(({ data }) => {
    dispatch(addProduct(data));
  });
};

export const getCutStationSummary = () => (dispatch, getState) => {
  const roomCode = getState().portionRoomsInfo.currentPortionRoom.code;
  return cutStationSummaryResources.getCutStationSummary(roomCode, response => {
    dispatch({
      type: UPDATE_CUT_STATION_SUMMARY,
      payload: response.data
    });
  });
};

export const getCutStation = stationId => {
  return dispatch => {
    dispatch({
      type: RESET_CUT_STATION_INFO
    });
    cutStationResources.getStation(stationId, response => {
      dispatch({
        type: UPDATE_CUT_STATION_INFO,
        payload: response.data
      });
    });
  };
};

export const calcSourceMeat = cutOrderIds => {
  return dispatch => {
    sourceMeatResources.calcSourceMeat(cutOrderIds, response => {
      dispatch({
        type: UPDATE_SOURCE_MEAT_INFO,
        payload: response.data
      });
    });
  };
};

export const generateSourceMeatOrders = sourceMeatOrders => (dispatch, getState) => {
  const roomCode = getState().portionRoomsInfo.currentPortionRoom.code;
  return sourceMeatResources.generateSourceMeatOrders(sourceMeatOrders, roomCode, () => {
    dispatch({
      type: RESET_SOURCE_MEAT_INFO
    });
  });
};
