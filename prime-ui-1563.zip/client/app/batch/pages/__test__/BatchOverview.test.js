import React from 'react';
import { mount } from 'enzyme';
import { Provider } from 'react-redux';
import { createReduxStore } from '../../../store';
import { Grid } from 'semantic-ui-react';
import BatchOverview, {
  BaseBatchInfo,
  isGrindingBatch,
  ReadOnlyBatchInfoSection,
  ReadOnlyFinishedProductSection,
  ReadOnlyIngredientSection,
  ReadOnlySourceMeatSection,
  RenderBlendName
} from '../BatchOverview';
import BatchFactory, { MARINATION_BATCH } from '../../../../test-factories/batch';
import semanticUI from '../../../../test-helpers/semantic-ui';

const grindingBatch = BatchFactory.build();
const marinationBatch = MARINATION_BATCH;

describe('Batch overview', () => {
  let wrapper, store, products;

  beforeEach(() => {
    products = {
      '4391102': { description: 'test description 4391102' },
      '0078889': { description: 'test description 0078889' }
    };
    store = createReduxStore({});
  });

  test('should render page with no blend in batch', () => {
    const batchWithNoBlend = { ...grindingBatch, blend: null };

    wrapper = mount(
      <Provider store={store}>
        <BatchOverview location={{ state: { batch: batchWithNoBlend } }} />
      </Provider>
    );

    jestExpect(wrapper.find(RenderBlendName)).toExist();
  });

  test('should render page with ingredient and finished product for marination batch', () => {
    wrapper = mount(
      <Provider store={store}>
        <BatchOverview location={{ state: { batch: marinationBatch } }} />
      </Provider>
    );

    jestExpect(wrapper.find(ReadOnlyBatchInfoSection)).toExist();
    jestExpect(wrapper.find(ReadOnlyFinishedProductSection)).toExist();
    jestExpect(wrapper.find(ReadOnlyIngredientSection)).toExist();
    jestExpect(wrapper.find(ReadOnlySourceMeatSection)).toExist();
    jestExpect(wrapper.find(BaseBatchInfo)).toExist();
  });

  test('should render page without ingredient and finished product for grinding batch', () => {
    wrapper = mount(
      <Provider store={store}>
        <BatchOverview location={{ state: { batch: grindingBatch } }} />
      </Provider>
    );

    jestExpect(wrapper.find(ReadOnlyBatchInfoSection)).toExist();
    jestExpect(wrapper.find(ReadOnlyFinishedProductSection)).not.toExist();
    jestExpect(wrapper.find(ReadOnlyIngredientSection)).not.toExist();
    jestExpect(wrapper.find(ReadOnlySourceMeatSection)).toExist();
    jestExpect(wrapper.find(BaseBatchInfo)).toExist();
  });

  describe('ReadOnlyBatchInfoSection', () => {
    let wrapper;

    test('should render grinder info for grinding batch', () => {
      wrapper = mount(<ReadOnlyBatchInfoSection batch={grindingBatch} />);

      const findLabelWithName = createFindLabelWithNameSelector(wrapper);

      jestExpect(findLabelWithName('Grinder #')).toHaveProp({ value: '123' });
      jestExpect(findLabelWithName('Grinder start time')).toHaveProp({ value: '02:58 PM' });
      jestExpect(findLabelWithName('Grinder stop time')).toHaveProp({ value: '04:43 PM' });
      jestExpect(findLabelWithName('Grinder times(mins)')).toHaveProp({ value: 105 });
      jestExpect(findLabelWithName('Start batch temp.')).toHaveProp({ value: '23.20' });
      jestExpect(findLabelWithName('Finished batch temp.')).toHaveProp({ value: '27.40' });
      jestExpect(findLabelWithName('Lbs of Batch')).toHaveProp({ value: '12.13' });
    });

    test('should render tumber info for marination batch', () => {
      wrapper = mount(<ReadOnlyBatchInfoSection batch={marinationBatch} />);

      const findLabelWithName = createFindLabelWithNameSelector(wrapper);

      jestExpect(findLabelWithName('Tumbler #')).toHaveProp({ value: '123' });
      jestExpect(findLabelWithName('Tumbler start time')).toHaveProp({ value: '02:58 PM' });
      jestExpect(findLabelWithName('Tumbler stop time')).toHaveProp({ value: '04:43 PM' });
      jestExpect(findLabelWithName('Tumbler times(mins)')).toHaveProp({ value: 105 });
      jestExpect(findLabelWithName('Start batch temp.')).toHaveProp({ value: '23.20' });
      jestExpect(findLabelWithName('Finished batch temp.')).toHaveProp({ value: '27.40' });
      jestExpect(findLabelWithName('Lbs of Batch')).toHaveProp({ value: '24.26' });
    });
  });

  describe('ReadOnlyFinishedProductSection', () => {
    beforeEach(() => {
      wrapper = mount(
        <ReadOnlyFinishedProductSection
          finishedProducts={marinationBatch.finishedProducts}
          products={products}
        />
      );
    });

    test('should render finished product', () => {
      const productsBody = wrapper.find('tbody').at(0);
      jestExpect(semanticUI.findTableColumnWithRowIndex(productsBody, 0, 0)).toHaveText('4391102');
      jestExpect(semanticUI.findTableColumnWithRowIndex(productsBody, 0, 1)).toHaveText(
        'test description 4391102'
      );
    });
  });

  describe('ReadOnlyIngredientSection', () => {
    beforeEach(() => {
      wrapper = mount(
        <ReadOnlyIngredientSection
          ingredients={marinationBatch.ingredients}
          batchNumber={marinationBatch.batchNumber}
          products={products}
        />
      );
    });

    test('should render ingredient section', () => {
      const ingredientGrid = wrapper.find(Grid).at(0);

      const findLabelWithName = createFindLabelWithNameSelector(ingredientGrid);

      jestExpect(findLabelWithName('Ingredient #')).toHaveProp({ value: '0078889' });
      jestExpect(findLabelWithName('Description')).toHaveProp({
        value: 'test description 0078889'
      });
      jestExpect(findLabelWithName('Vendor')).toHaveProp({ value: 'vendor name' });
      jestExpect(findLabelWithName('PO #')).toHaveProp({ value: '12' });
      jestExpect(findLabelWithName('Actual Lbs')).toHaveProp({ value: '12.13' });
      jestExpect(findLabelWithName('Allergens')).toHaveProp({ value: 'Yes' });
    });
  });

  describe('isGrindingBatch', () => {
    test('should return correct result', () => {
      jestExpect(isGrindingBatch(grindingBatch)).toEqual(true);
      jestExpect(isGrindingBatch(marinationBatch)).toEqual(false);
    });
  });

  describe('ReadOnlySourceMeatSection', () => {
    beforeEach(() => {
      wrapper = mount(<ReadOnlySourceMeatSection batch={grindingBatch} products={products} />);
    });

    test('should render sourceMeat section', () => {
      const sourceMeatGrid = wrapper.find(Grid).at(0);

      const findLabelWithName = createFindLabelWithNameSelector(sourceMeatGrid);

      jestExpect(findLabelWithName('Source #')).toHaveProp({ value: '0078889' });
      jestExpect(findLabelWithName('Description')).toHaveProp({
        value: 'test description 0078889'
      });
      jestExpect(findLabelWithName('PO #')).toHaveProp({ value: '12' });
      jestExpect(findLabelWithName('LOT #')).toHaveProp({ value: '11' });
      jestExpect(findLabelWithName('Vendor')).toHaveProp({ value: 'vendor name' });
      jestExpect(findLabelWithName('Meat Temp.')).toHaveProp({ value: '12.12' });
      jestExpect(findLabelWithName('Actual Lbs')).toHaveProp({ value: '12.13' });
    });
  });

  describe('BaseBatchInfo', () => {
    test('should render base grindingBatch info with blend name', () => {
      wrapper = mount(<BaseBatchInfo batch={grindingBatch} />);
      const findLabelWithName = createFindLabelWithNameSelector(wrapper);

      jestExpect(findLabelWithName('Batch #')).toHaveProp({ value: 123 });
      jestExpect(findLabelWithName('Blend Name')).toHaveProp({ value: 'BLEND1013' });
      jestExpect(findLabelWithName('Production Date')).toHaveProp({ value: '05-29-2018' });
    });

    test('should render base marinationBatch info without blend name ', () => {
      wrapper = mount(<BaseBatchInfo batch={grindingBatch} />);
      const findLabelWithName = createFindLabelWithNameSelector(wrapper);

      jestExpect(findLabelWithName('Batch #')).toHaveProp({ value: 123 });
      jestExpect(findLabelWithName('Production Date')).toHaveProp({ value: '05-29-2018' });
    });
  });

  describe('componentDidMount', () => {
    test('scroll page to top', () => {
      const scrollToTop = jest.fn();
      const componentDidMount = jest.fn(() => ({ scrollToTop }));
      const component = new BatchOverview({ store });
      component.componentDidMount = componentDidMount;
      component.componentDidMount().scrollToTop();
      jestExpect(scrollToTop).toBeCalled();
    });
  });
});

function createFindLabelWithNameSelector(wrapper) {
  return function(name) {
    return semanticUI.findLabelWithName(wrapper, name);
  };
}
