import React from 'react';
import { mount } from 'enzyme';
import { Provider } from 'react-redux';
import { createReduxStore } from '../../../store';
import CreateBatch, { isMarinationBatch } from '../CreateBatch';
import { MARINATION_BATCH } from '../../../../test-factories/batch';
import BatchFactory from '../../../../test-factories/batch';
import blendFactory from '../../../../test-factories/blendFactory';

describe('createBatch', () => {
  let wrapper, store;

  beforeEach(() => {
    store = createReduxStore({
      portionRoomsInfo: { currentPortionRoom: { roomType: 'GRINDING' } }
    });
    wrapper = mount(
      <Provider store={store}>
        <CreateBatch location={{ state: { blend: blendFactory.build() } }} />
      </Provider>
    );
  });

  test('should render page for creating a batch', () => {
    jestExpect(wrapper.find(CreateBatch)).toExist();
  });

  test('should return correct result with given roomType and batch', () => {
    const grindingBatch = BatchFactory.build();

    jestExpect(isMarinationBatch('CUTTING', undefined)).toEqual(true);
    jestExpect(isMarinationBatch('CUTTING', MARINATION_BATCH)).toEqual(true);
    jestExpect(isMarinationBatch('CUTTING', grindingBatch)).toEqual(false);

    jestExpect(isMarinationBatch('GRINDING', undefined)).toEqual(false);
    jestExpect(isMarinationBatch('GRINDING', MARINATION_BATCH)).toEqual(true);
    jestExpect(isMarinationBatch('GRINDING', grindingBatch)).toEqual(false);
  });

  describe('componentDidMount', () => {
    test('scroll page to top', () => {
      const scrollToTop = jest.fn();
      const componentDidMount = jest.fn(() => ({ scrollToTop }));
      const component = new CreateBatch({ store });
      component.componentDidMount = componentDidMount;
      component.componentDidMount().scrollToTop();
      jestExpect(scrollToTop).toBeCalled();
    });
  });
});
