import React from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import PropTypes from 'prop-types';
import CreateGrindBatchForm from '../components/CreateGrindBatchForm';
import CreateMarinationBatchForm from '../components/CreateMarinationBatchForm';
import { setHeaderAndFooter } from '../../shared/actions/actions';
import { CREATE_BATCH } from '../../shared/components/pageTitles';
import { CREATE_BATCH_FOOTER } from '../../shared/components/pageFooters';

class CreateBatch extends React.Component {
  componentDidMount() {
    this.props.setHeaderAndFooter({
      header: CREATE_BATCH,
      footer: CREATE_BATCH_FOOTER
    });

    this.scrollToTop();
  }

  scrollToTop() {
    if (this.scrollToTopRef && this.scrollToTopRef.scrollIntoView) {
      this.scrollToTopRef.scrollIntoView({
        behavior: 'smooth',
        block: 'start',
        inline: 'nearest'
      });
    }
  }

  render() {
    const { roomType, location } = this.props;
    const batch = location.state && location.state.batch;
    return (
      <div className='page-content' ref={node => (this.scrollToTopRef = node)}>
        {isMarinationBatch(roomType, batch) ? (
          <CreateMarinationBatchForm {...location.state} />
        ) : (
          <CreateGrindBatchForm {...location.state} />
        )}
      </div>
    );
  }
}

export const isMarinationBatch = (currentRoomType, batch) => {
  const roomType = (batch && batch.portionRoomType) || currentRoomType;
  return roomType === 'CUTTING';
};

CreateBatch.propTypes = {
  setHeaderAndFooter: PropTypes.func.isRequired,
  roomType: PropTypes.string.isRequired,
  location: PropTypes.object.isRequired
};

const mapStateToProps = state => {
  return {
    roomType: state.portionRoomsInfo.currentPortionRoom.roomType
  };
};

const mapDispatchToProps = dispatch =>
  bindActionCreators(
    {
      setHeaderAndFooter
    },
    dispatch
  );

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(CreateBatch);
