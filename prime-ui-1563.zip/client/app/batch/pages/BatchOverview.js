import React from 'react';
import moment from 'moment';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import PropTypes from 'prop-types';
import { setHeaderAndFooter } from '../../shared/actions/actions';
import { BATCH_OVERVIEW } from '../../shared/components/pageTitles';
import { F4 } from '../../shared/components/pageFooters';
import FormLabel from '../../shared/FormLabel';
import { Divider, Form, Grid, Table } from 'semantic-ui-react';
import { getProduct } from '../../shared/components/product/actionsDuplicate';
import {
  calcTotalIngredientWeightLbs,
  calcTotalSourceMeatLbs,
  calcTumblerTimes,
  convertToMilitaryTime
} from '../components/batchUtils';
import _ from 'lodash';
import { formatNumberToTwoDecimalPlacesString } from '../../shared/util/dataUtil';
import { DEFAULT_DISPLAY_DATE_FORMAT } from '../../shared/util/dateUtil';

export const ReadOnlySourceMeatSection = ({ batch, products }) => {
  const { sourceMeats, batchNumber } = batch;
  const totalSourceWeight = calcTotalSourceMeatLbs(sourceMeats);
  return (
    <div>
      <div>Source Meat</div>
      <Divider hidden />
      <div className={'create-batch-source-meat-list create-batch-section'}>
        {sourceMeats.map((sourceMeat, index) => {
          const sourceMeatId = _.get(sourceMeat, 'id', '');
          const key = sourceMeatId ? `${batchNumber}-existing-product-${index}` : sourceMeat;
          const {
            poNumber,
            lotNumber,
            vendor,
            meatTemp,
            actualLbs,
            establishmentNumber,
            harvestDate,
            sourceProductCode
          } = sourceMeat;
          const description = _.get(products[sourceProductCode], 'description', '');
          return (
            <div
              key={key}
              pid={`create-batch-source-meat__grid-${index}`}
              className={'create-batch-source-meat batch-overview-source-meat'}
            >
              <Grid>
                <Grid.Row>
                  <Grid.Column width={3}>
                    <FormLabel label='Source #' value={sourceProductCode} width={15} />
                  </Grid.Column>
                  <Grid.Column width={8}>
                    <FormLabel label='Description' value={description} width={15} />
                  </Grid.Column>
                </Grid.Row>

                <Grid.Row>
                  <Grid.Column width={3}>
                    <FormLabel label='PO #' value={poNumber} width={15} />
                  </Grid.Column>
                  <Grid.Column width={3}>
                    <FormLabel label='LOT #' value={lotNumber} width={15} />
                  </Grid.Column>
                  <Grid.Column width={3}>
                    <FormLabel label='Vendor' value={vendor} width={15} />
                  </Grid.Column>
                  <Grid.Column width={3}>
                    <FormLabel
                      label='Meat Temp.'
                      value={formatNumberToTwoDecimalPlacesString(meatTemp)}
                      width={15}
                    />
                  </Grid.Column>
                  <Grid.Column width={3}>
                    <FormLabel
                      label='Actual Lbs'
                      value={formatNumberToTwoDecimalPlacesString(actualLbs)}
                      width={15}
                    />
                  </Grid.Column>
                </Grid.Row>

                <Grid.Row>
                  <Grid.Column width={5}>
                    <FormLabel label='Establishment #' value={establishmentNumber} width={15} />
                  </Grid.Column>
                  <Grid.Column width={5}>
                    <FormLabel label='Harvest Date(of animal)' value={harvestDate} width={15} />
                  </Grid.Column>
                </Grid.Row>
              </Grid>

              <Divider hidden />
            </div>
          );
        })}
        <Divider hidden />

        <div>
          {`Total source weight: ${formatNumberToTwoDecimalPlacesString(totalSourceWeight)} lbs`}{' '}
        </div>
      </div>
    </div>
  );
};

ReadOnlySourceMeatSection.propTypes = {
  batch: PropTypes.object.isRequired,
  products: PropTypes.object.isRequired
};

export const ReadOnlyBatchInfoSection = ({ batch }) => {
  const typeLabel = isGrindingBatch(batch) ? 'Grinder' : 'Tumbler';
  const {
    tumblerStartTime,
    tumblerStopTime,
    startBatchTemp,
    finishedBatchTemp,
    tumbler,
    ingredients,
    sourceMeats
  } = batch;

  const lbsOfBatch =
    calcTotalIngredientWeightLbs(ingredients) + calcTotalSourceMeatLbs(sourceMeats);

  const tumblerTimes = calcTumblerTimes(tumblerStartTime, tumblerStopTime);
  const formattedStartTime = convertToMilitaryTime(tumblerStartTime);
  const formattedStopTime = convertToMilitaryTime(tumblerStopTime);

  return (
    <div>
      <div>Batch Info (Production Instruction)</div>

      <Divider hidden />

      <div className={'create-batch-section'}>
        <Grid>
          <Grid.Row>
            <Grid.Column width={4}>
              <FormLabel label={`${typeLabel} #`} value={tumbler} width={15} />
            </Grid.Column>
            <Grid.Column width={4}>
              <FormLabel label={`${typeLabel} start time`} value={formattedStartTime} width={15} />
            </Grid.Column>
            <Grid.Column width={4}>
              <FormLabel label={`${typeLabel} stop time`} value={formattedStopTime} width={15} />
            </Grid.Column>
            <Grid.Column width={4}>
              <FormLabel label={`${typeLabel} times(mins)`} value={tumblerTimes} width={15} />
            </Grid.Column>
          </Grid.Row>
          <Grid.Row>
            <Grid.Column width={4}>
              <FormLabel
                label='Start batch temp.'
                value={formatNumberToTwoDecimalPlacesString(startBatchTemp)}
                width={15}
              />
            </Grid.Column>
            <Grid.Column width={4}>
              <FormLabel
                label='Finished batch temp.'
                value={formatNumberToTwoDecimalPlacesString(finishedBatchTemp)}
                width={15}
              />
            </Grid.Column>
            <Grid.Column width={3}>
              <FormLabel
                label='Lbs of Batch'
                value={formatNumberToTwoDecimalPlacesString(lbsOfBatch)}
                width={12}
              />
            </Grid.Column>
          </Grid.Row>
        </Grid>
      </div>
    </div>
  );
};

ReadOnlyBatchInfoSection.propTypes = {
  batch: PropTypes.object.isRequired
};

export const ReadOnlyIngredientSection = ({ ingredients, batchNumber, products }) => {
  const totalIngredientWeight = calcTotalIngredientWeightLbs(ingredients);
  return (
    <div>
      <div>Ingredients</div>
      <Divider hidden />

      <div className={'create-batch-ingredient-list create-batch-section'}>
        {ingredients.map((ingredient, index) => {
          const ingredientId = _.get(ingredient, 'id', '');
          const key = ingredientId ? `${batchNumber}-existing-product-${index}` : ingredient;
          const { ingredientProductCode, vendor, poNumber, actualLbs, allergens } = ingredient;
          const description = _.get(products[ingredientProductCode], 'description', '');
          return (
            <div key={key} className={'create-batch-ingredient batch-overview-ingredient'}>
              <Grid>
                <Grid.Row>
                  <Grid.Column width={3}>
                    <FormLabel label='Ingredient #' value={ingredientProductCode} width={15} />
                  </Grid.Column>

                  <Grid.Column width={8}>
                    <FormLabel label='Description' value={description} width={15} />
                  </Grid.Column>
                </Grid.Row>

                <Grid.Row>
                  <Grid.Column width={3}>
                    <FormLabel label='Vendor' value={vendor} width={15} />
                  </Grid.Column>
                  <Grid.Column width={3}>
                    <FormLabel label='PO #' value={poNumber} width={15} />
                  </Grid.Column>
                  <Grid.Column width={3}>
                    <FormLabel label='Actual Lbs' value={actualLbs} width={15} />
                  </Grid.Column>
                  <Grid.Column width={3}>
                    <FormLabel label='Allergens' value={allergens ? 'Yes' : 'No'} width={15} />
                  </Grid.Column>
                </Grid.Row>
              </Grid>
              <Divider hidden />
            </div>
          );
        })}

        <Divider hidden />

        <div>
          {`Total ingredient weight: ${formatNumberToTwoDecimalPlacesString(
            totalIngredientWeight
          )} lbs`}{' '}
        </div>

        <Divider hidden />
      </div>
    </div>
  );
};

ReadOnlyIngredientSection.propTypes = {
  products: PropTypes.object.isRequired,
  batchNumber: PropTypes.number.isRequired,
  ingredients: PropTypes.array.isRequired
};

export const ReadOnlyFinishedProductSection = ({ finishedProducts, products }) => {
  return (
    <div>
      <div>Finished Products</div>
      <Divider hidden />

      <div>
        <Table columns={2} fixed size='small'>
          <Table.Header>
            <Table.Row>
              <Table.HeaderCell width={2}>Product</Table.HeaderCell>
              <Table.HeaderCell width={10} />
            </Table.Row>
          </Table.Header>
          <Table.Body>
            {finishedProducts.map((finishedProduct, index) => {
              const { finishedProductCode } = finishedProduct;
              const description = _.get(products[finishedProductCode], 'description', '');
              return (
                <Table.Row key={`${finishedProductCode}-${index}-row`}>
                  <Table.Cell textAlign={'center'}>{finishedProductCode}</Table.Cell>
                  <Table.Cell textAlign={'left'}>{description}</Table.Cell>
                </Table.Row>
              );
            })}
          </Table.Body>
        </Table>
      </div>
    </div>
  );
};

ReadOnlyFinishedProductSection.propTypes = {
  finishedProducts: PropTypes.array.isRequired,
  products: PropTypes.object.isRequired
};

export const AddAdditionalCuttingRoomSections = ({ batch, products }) => {
  const { batchNumber, ingredients, finishedProducts } = batch;

  if (!isGrindingBatch(batch)) {
    return (
      <div>
        <ReadOnlyIngredientSection
          ingredients={ingredients}
          batchNumber={batchNumber}
          products={products}
        />

        <ReadOnlyFinishedProductSection finishedProducts={finishedProducts} products={products} />

        <Divider hidden />
      </div>
    );
  } else {
    return null;
  }
};

export const isGrindingBatch = batch => {
  return batch.portionRoomType === 'GRINDING';
};

AddAdditionalCuttingRoomSections.propTypes = {
  products: PropTypes.object.isRequired,
  batch: PropTypes.object.isRequired
};

export const RenderBlendName = ({ batch }) => {
  if (isGrindingBatch(batch)) {
    return (
      <Grid.Column width={5}>
        <FormLabel label='Blend Name' value={batch.blend ? batch.blend.name : ''} width={10} />
      </Grid.Column>
    );
  } else {
    return null;
  }
};

RenderBlendName.propTypes = {
  batch: PropTypes.object.isRequired
};

export const BaseBatchInfo = ({ batch }) => {
  const { batchNumber, productionDate } = batch;
  const formatProductionDate = moment(productionDate).format(DEFAULT_DISPLAY_DATE_FORMAT);
  return (
    <Grid>
      <Grid.Row>
        <Grid.Column width={5}>
          <FormLabel label='Batch #' value={batchNumber} width={10} />
        </Grid.Column>

        <RenderBlendName batch={batch} />

        <Grid.Column width={6}>
          <FormLabel label='Production Date' value={formatProductionDate} width={10} />
        </Grid.Column>
      </Grid.Row>
    </Grid>
  );
};

BaseBatchInfo.propTypes = {
  batch: PropTypes.object.isRequired
};

class BatchOverview extends React.Component {
  componentDidMount() {
    const { allProductCodes, setHeaderAndFooter, getProduct } = this.props;
    setHeaderAndFooter({
      header: BATCH_OVERVIEW,
      footer: F4
    });

    allProductCodes.forEach(code => {
      getProduct(code);
    });

    this.scrollToTop();
  }

  scrollToTop() {
    if (this.scrollToTopRef && this.scrollToTopRef.scrollIntoView) {
      this.scrollToTopRef.scrollIntoView({
        behavior: 'smooth',
        block: 'start',
        inline: 'nearest'
      });
    }
  }

  render() {
    const { batch, products } = this.props;

    return (
      <div
        className='page-content create-batch-form batch-overview'
        ref={node => (this.scrollToTopRef = node)}
      >
        <Form size={'large'}>
          <Divider hidden className='divider-medium' />
          <BaseBatchInfo batch={batch} />

          <Divider hidden />
          <ReadOnlyBatchInfoSection batch={batch} />

          <Divider hidden />
          <ReadOnlySourceMeatSection batch={batch} products={products} />

          <Divider hidden />
          <AddAdditionalCuttingRoomSections batch={batch} products={products} />
        </Form>
      </div>
    );
  }
}

BatchOverview.propTypes = {
  setHeaderAndFooter: PropTypes.func.isRequired,
  getProduct: PropTypes.func.isRequired,
  location: PropTypes.object.isRequired,
  allProductCodes: PropTypes.array.isRequired,
  products: PropTypes.object.isRequired,
  batch: PropTypes.object.isRequired
};

const fetchALlProductCodes = batch => {
  const sourceMeatProductCodes = _.map(
    batch.sourceMeats,
    sourceMeat => sourceMeat.sourceProductCode
  );
  const ingredientProductCodes = _.map(
    batch.ingredients,
    ingredient => ingredient.ingredientProductCode
  );
  const finishedProductCodes = _.map(
    batch.finishedProducts,
    finishedProduct => finishedProduct.finishedProductCode
  );

  return _([])
    .concat(sourceMeatProductCodes)
    .concat(ingredientProductCodes)
    .concat(finishedProductCodes)
    .value();
};

const mapStateToProps = (state, ownProps) => {
  const {
    location: {
      state: { batch }
    }
  } = ownProps;
  const products = state.productDuplicate.products;
  const allProductCodes = fetchALlProductCodes(batch);
  return { allProductCodes, batch, products };
};

const mapDispatchToProps = dispatch =>
  bindActionCreators(
    {
      setHeaderAndFooter,
      getProduct
    },
    dispatch
  );

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(BatchOverview);
