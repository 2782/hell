import React from 'react';
import PropTypes from 'prop-types';
import { Field } from 'redux-form';
import { Divider, Form, Grid } from 'semantic-ui-react';
import FormLabel from '../../shared/FormLabel';
import FormElement from '../../shared/FormElement';
import { normalizeToTwoDecimalPlaces } from '../../shared/components/product/normalizer';
import FormTimeInput from '../../shared/FormTimeInput';

export default function BatchInfo({ isGrinder, tumblerTimes, lbsOfBatch }) {
  const typeLabel = isGrinder ? 'Grinder' : 'Tumbler';

  return (
    <div>
      <div>Batch Info (Production Instruction)</div>

      <Divider hidden />

      <div className={'create-batch-section'}>
        <Grid>
          <Grid.Row>
            <Grid.Column width={4}>
              <Field
                component={FormElement}
                name='tumbler'
                as={Form.Input}
                pid='create-batch-form-tumbler'
                type='text'
                label={`${typeLabel} #`}
                width={15}
              />
            </Grid.Column>
            <Grid.Column width={4}>
              <Field
                component={FormTimeInput}
                name='tumblerStartTime'
                className='tumbler-time'
                pid='create-batch-form-tumbler-start-time'
                type='time'
                label={`${typeLabel} start time`}
                width={15}
              />
            </Grid.Column>
            <Grid.Column width={4}>
              <Field
                component={FormTimeInput}
                name='tumblerStopTime'
                className='tumbler-time'
                pid='create-batch-form-tumbler-stop-time'
                type='time'
                label={`${typeLabel} stop time`}
                width={15}
              />
            </Grid.Column>
            <Grid.Column width={4}>
              <FormLabel
                label={`${typeLabel} times(mins)`}
                pid='tumblertimesmins'
                value={tumblerTimes}
                width={15}
              />
            </Grid.Column>
          </Grid.Row>
        </Grid>

        <Divider hidden />

        <Grid>
          <Grid.Row>
            <Grid.Column width={4}>
              <Field
                component={FormElement}
                name='startBatchTemp'
                as={Form.Input}
                pid='create-batch-form-start-batch-temp'
                type='text'
                label='Start batch temp.'
                width={15}
                normalize={normalizeToTwoDecimalPlaces}
              />
            </Grid.Column>
            <Grid.Column width={4}>
              <Field
                component={FormElement}
                name='finishedBatchTemp'
                as={Form.Input}
                pid='create-batch-form-finished-batch-temp'
                type='text'
                label='Finished batch temp.'
                width={15}
                normalize={normalizeToTwoDecimalPlaces}
              />
            </Grid.Column>

            <Grid.Column width={3}>
              <FormLabel label='Lbs of Batch' value={lbsOfBatch} width={12} />
            </Grid.Column>
          </Grid.Row>
        </Grid>
      </div>
    </div>
  );
}

BatchInfo.propTypes = {
  isGrinder: PropTypes.bool,
  tumblerTimes: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  lbsOfBatch: PropTypes.oneOfType([PropTypes.string, PropTypes.number])
};
