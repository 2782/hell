import { Table } from 'semantic-ui-react';
import PropTypes from 'prop-types';
import React, { Fragment } from 'react';
import _ from 'lodash';
import { connect } from 'react-redux';
import { changePath } from '../../shared/actions/actions';
import { bindActionCreators } from 'redux';
import EmptyTableMessage from '../../shared/components/EmptyTableMessage';
import moment from 'moment';
import { batchStatus, batchType } from './batchUtils';
import { isoDateToDisplayDate } from '../../shared/util/dateUtil';

export const SearchBatchesTable = ({ batches }) => {
  return (
    <Fragment>
      <Table size='small' columns={15} fixed selectable>
        <SearchBatchesHeaders />
        <SearchBatchesTableBodyContainer batches={batches} />
      </Table>
      {_.isEmpty(batches) ? (
        <EmptyTableMessage className='prime-list-empty-message' message='No results found' />
      ) : null}
    </Fragment>
  );
};

SearchBatchesTable.propTypes = {
  batches: PropTypes.array
};

const SearchBatchesHeaders = () => {
  return (
    <Table.Header>
      <Table.Row>
        <Table.HeaderCell colSpan={3} width={3}>
          Date
        </Table.HeaderCell>
        <Table.HeaderCell colSpan={3} width={3}>
          Room
        </Table.HeaderCell>
        <Table.HeaderCell colSpan={3} width={3}>
          Type
        </Table.HeaderCell>
        <Table.HeaderCell colSpan={2} width={2} textAlign={'right'}>
          Batch #
        </Table.HeaderCell>
        <Table.HeaderCell colSpan={3} width={3} textAlign={'right'}>
          Source PO #
        </Table.HeaderCell>
        <Table.HeaderCell colSpan={3} width={3} textAlign={'right'}>
          Start Time
        </Table.HeaderCell>
        <Table.HeaderCell colSpan={3} width={3} textAlign={'right'}>
          Stop Time
        </Table.HeaderCell>
        <Table.HeaderCell colSpan={3} width={3} textAlign={'left'}>
          Status
        </Table.HeaderCell>
      </Table.Row>
    </Table.Header>
  );
};

const handleClick = (batch, changePath) => {
  const { batchNumber, blend, grindSize } = batch;
  let pathname = '/batch/create';
  let state = { batchNumber, blend, grindSize, batch };
  if (batch.finished) {
    pathname = `/batch/${batch.batchNumber}`;
    state = { batch };
  }

  changePath({ pathname, state });
};

const SearchBatchesTableBody = ({ batches, changePath }) => {
  return (
    <Table.Body key={'batch-search-table-content'}>
      {_.map(
        _.orderBy(batches, ['productionDate', 'batchNumber'], ['desc', 'desc']),
        (batch, itemIndex) => {
          return (
            <Table.Row
              pid={`batch-search__table-row-${itemIndex}`}
              key={`batch-search__table-row-${itemIndex}`}
              onClick={() => {
                handleClick(batch, changePath);
              }}
            >
              <Table.Cell colSpan={3} width={3}>
                {isoDateToDisplayDate(batch.productionDate)}
              </Table.Cell>
              <Table.Cell colSpan={3} width={3}>
                {batch.portionRoomCode}
              </Table.Cell>
              <Table.Cell colSpan={3} width={3}>
                {batchType(batch.portionRoomType)}
              </Table.Cell>
              <Table.Cell colSpan={2} width={2} textAlign={'right'}>
                {batch.batchNumber}
              </Table.Cell>
              <Table.Cell colSpan={3} width={3} textAlign={'right'}>
                {batch.sourceMeats.map((sourceMeat, indexNumber) => (
                  <div key={`batch-search__sourceMeat-${sourceMeat.batchNumber}-${indexNumber}`}>
                    {sourceMeat.poNumber}
                  </div>
                ))}
              </Table.Cell>
              <Table.Cell colSpan={3} width={3} textAlign={'right'}>
                {batch.tumblerStartTime &&
                  moment(batch.tumblerStartTime, 'HH:mm:ss').format('h:mm A')}
              </Table.Cell>
              <Table.Cell colSpan={3} width={3} textAlign={'right'}>
                {batch.tumblerStopTime &&
                  moment(batch.tumblerStopTime, 'HH:mm:ss').format('h:mm A')}
              </Table.Cell>
              <Table.Cell colSpan={3} width={3} textAlign={'left'}>
                {batchStatus(batch.finished)}
              </Table.Cell>
            </Table.Row>
          );
        }
      )}
    </Table.Body>
  );
};

SearchBatchesTableBody.propTypes = {
  batches: PropTypes.array,
  changePath: PropTypes.func
};

const mapDispatchToProps = dispatch =>
  bindActionCreators(
    {
      changePath
    },
    dispatch
  );

const SearchBatchesTableBodyContainer = connect(
  null,
  mapDispatchToProps
)(SearchBatchesTableBody);

SearchBatchesTableBody.propTypes = {
  batches: PropTypes.array
};
