import React from 'react';
import { createReduxStore } from '../../../store';
import { SearchBatchesTable } from '../SearchBatchesTable';
import BatchFactory from '../../../../test-factories/batch';
import { Provider } from 'react-redux';
import semanticUI from '../../../../test-helpers/semantic-ui';
import { changePath } from '../../../shared/actions/actions';

jest.mock('../../../shared/actions/actions', () => ({
  changePath: jest.fn(() => ({ type: 'MOCK_CHANGE_PATH' }))
}));

describe('search batch table', () => {
  test('should dispatch reroute when user clicks a batch search result', () => {
    const store = createReduxStore({});

    const batch = BatchFactory.build();

    const dispatchSpy = jest.spyOn(store, 'dispatch');

    const wrapper = mount(
      <Provider store={store}>
        <SearchBatchesTable batches={[batch]} />
      </Provider>
    );

    const batchTableBody = wrapper.find('tbody').at(0);

    semanticUI.findTableColumnWithRowIndex(batchTableBody, 0, 0).simulate('click');

    jestExpect(dispatchSpy).toHaveBeenCalledWith(changePath());
    jestExpect(changePath).toHaveBeenCalledWith(
      jestExpect.objectContaining({
        pathname: '/batch/create',
        state: jestExpect.objectContaining({ batch })
      })
    );
  });

  test('should change path to batch overview page when user clicks a batch search result', () => {
    const store = createReduxStore({});

    const batch = BatchFactory.build({ finished: true });

    const dispatchSpy = jest.spyOn(store, 'dispatch');

    const wrapper = mount(
      <Provider store={store}>
        <SearchBatchesTable batches={[batch]} />
      </Provider>
    );

    const batchTableBody = wrapper.find('tbody').at(0);

    semanticUI.findTableColumnWithRowIndex(batchTableBody, 0, 0).simulate('click');

    jestExpect(dispatchSpy).toHaveBeenCalledWith(changePath());
    jestExpect(changePath).toHaveBeenCalledWith(
      jestExpect.objectContaining({
        pathname: '/batch/123',
        state: jestExpect.objectContaining({ batch })
      })
    );
  });

  test('should show correct display date, room name, batch type, batch number and finished', () => {
    const store = createReduxStore({});

    const batch = BatchFactory.build();

    const wrapper = mount(
      <Provider store={store}>
        <SearchBatchesTable batches={[batch]} />
      </Provider>
    );

    const batchTableBody = wrapper.find('tbody').at(0);

    jestExpect(semanticUI.findTableColumnWithRowIndex(batchTableBody, 0, 0)).toHaveText(
      '05-29-2018'
    );
    jestExpect(semanticUI.findTableColumnWithRowIndex(batchTableBody, 0, 1)).toHaveText('D');
    jestExpect(semanticUI.findTableColumnWithRowIndex(batchTableBody, 0, 2)).toHaveText('GRINDING');
    jestExpect(semanticUI.findTableColumnWithRowIndex(batchTableBody, 0, 3)).toHaveText('123');
    jestExpect(semanticUI.findTableColumnWithRowIndex(batchTableBody, 0, 7)).toHaveText(
      'UNFINISHED'
    );
  });

  test('should show correct batch type and finished', () => {
    const store = createReduxStore({});

    const batch = BatchFactory.build({ finished: true, portionRoomType: 'CUTTING' });

    const wrapper = mount(
      <Provider store={store}>
        <SearchBatchesTable batches={[batch]} />
      </Provider>
    );

    const batchTableBody = wrapper.find('tbody').at(0);

    jestExpect(semanticUI.findTableColumnWithRowIndex(batchTableBody, 0, 2)).toHaveText(
      'MARINATION'
    );
    jestExpect(semanticUI.findTableColumnWithRowIndex(batchTableBody, 0, 7)).toHaveText('FINISHED');
  });

  test('should show correct time format for startTime and stopTime', () => {
    const store = createReduxStore({});

    const batch = BatchFactory.build();

    const wrapper = mount(
      <Provider store={store}>
        <SearchBatchesTable batches={[batch]} />
      </Provider>
    );

    const batchTableBody = wrapper.find('tbody').at(0);

    jestExpect(semanticUI.findTableColumnWithRowIndex(batchTableBody, 0, 5)).toHaveText('2:58 PM');
    jestExpect(semanticUI.findTableColumnWithRowIndex(batchTableBody, 0, 6)).toHaveText('4:43 PM');
  });

  test('should show empty string if stateTime or stop time is not set', () => {
    const store = createReduxStore({});

    const batch = BatchFactory.build({ tumblerStartTime: '', tumblerStopTime: '' });

    const wrapper = mount(
      <Provider store={store}>
        <SearchBatchesTable batches={[batch]} />
      </Provider>
    );

    const batchTableBody = wrapper.find('tbody').at(0);

    jestExpect(semanticUI.findTableColumnWithRowIndex(batchTableBody, 0, 5)).toHaveText('');
    jestExpect(semanticUI.findTableColumnWithRowIndex(batchTableBody, 0, 6)).toHaveText('');
  });
});
