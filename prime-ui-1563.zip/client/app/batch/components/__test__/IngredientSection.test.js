import React from 'react';
import { mount } from 'enzyme';
import { Provider } from 'react-redux';
import store from '../../../store';
import { IngredientList } from '../IngredientSection';
import { reduxForm } from 'redux-form';

describe('IngredientList', () => {
  let wrapper, Decorated, fields;
  const ingredient = {
    poNumber: '12',
    ingredientProductCode: '0078889',
    actualLbs: '12.13',
    allergens: false
  };

  beforeEach(() => {
    const fieldValue = [ingredient];
    const fieldNames = ['ingredients[0]'];
    fields = {
      getAll: () => fieldValue,
      get: index => fieldValue[index],
      map: callback => fieldNames.map((name, idx) => callback(name, idx)),
      push: data => {
        fieldValue.push(data);
        fieldNames.push(`ingredients[${fieldNames.length}]`);
      },
      length: fieldValue.length
    };

    Decorated = reduxForm({ form: 'testForm' })(IngredientList);
    wrapper = mount(
      <Provider store={store}>
        <Decorated
          fields={fields}
          meta={{ error: false, submitFailed: false }}
          ingredients={[ingredient]}
          totalIngredientWeight={20}
        />
      </Provider>
    );
  });

  test('should set initial fields', () => {
    jestExpect(wrapper.find('.create-batch-ingredient')).toExist();

    const fields = wrapper.find('Field');
    jestExpect(fields.at(0)).toHaveProp({ namespace: 'batchForm-ingredient-0' });
    jestExpect(fields.at(0)).toHaveProp({ name: 'ingredients[0].ingredientProductCode' });
    jestExpect(fields.at(0)).toHaveProp({ label: 'Ingredient #' });

    jestExpect(fields.at(1)).toHaveProp({ name: 'ingredients[0].vendor' });
    jestExpect(fields.at(1)).toHaveProp({ label: 'Vendor' });

    jestExpect(fields.at(2)).toHaveProp({ name: 'ingredients[0].poNumber' });
    jestExpect(fields.at(2)).toHaveProp({ label: 'PO #' });

    jestExpect(fields.at(3)).toHaveProp({ name: 'ingredients[0].actualLbs' });
    jestExpect(fields.at(3)).toHaveProp({ label: 'Actual Lbs' });

    jestExpect(fields.at(4)).toHaveProp({ name: 'ingredients[0].allergens' });
    jestExpect(fields.at(4)).toHaveProp({ label: 'Allergens' });
  });

  test('should show error when invalid and submit failed and has error', () => {
    wrapper = mount(
      <Provider store={store}>
        <Decorated
          fields={fields}
          meta={{ dirty: false, invalid: true, error: 'Error Message', submitFailed: true }}
        />
      </Provider>
    );
    jestExpect(wrapper.find('Label').last()).toHaveText('Error Message');
  });

  test('should show warning when invalid and submit failed and has warning', () => {
    wrapper = mount(
      <Provider store={store}>
        <Decorated
          fields={fields}
          meta={{ dirty: false, invalid: true, warning: 'Warning Message', submitFailed: true }}
        />
      </Provider>
    );
    jestExpect(wrapper.find('Label').last()).toHaveText('Warning Message');
  });

  test('should show message when valid failed and has message', () => {
    wrapper = mount(
      <Provider store={store}>
        <Decorated
          fields={fields}
          message={'Message'}
          meta={{ dirty: false, invalid: true, error: 'Error Message', submitFailed: true }}
        />
      </Provider>
    );
    jestExpect(wrapper.find('Label').last()).toHaveText('Message');
  });
});
