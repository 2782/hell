import {
  batchStatus,
  batchType,
  calcTotalSourceMeatLbs,
  calcTumblerTimes,
  convertToMilitaryTime
} from '../batchUtils';

describe('test batchUtil', () => {
  test('#calcTumblerTimes', () => {
    const startTime = '10:23:00';
    const stopTime = '10:25:01';
    let result = calcTumblerTimes(startTime, stopTime);

    jestExpect(result).toEqual(2);
  });

  test('#convertToMilitaryTime', () => {
    const time1 = '16:25:01';
    const time2 = '04:31:01';

    jestExpect(convertToMilitaryTime(time1)).toEqual('04:25 PM');
    jestExpect(convertToMilitaryTime(time2)).toEqual('04:31 AM');
  });

  test('#calcTotalSourceMeatLbs', () => {
    let sourceMeats = [{ actualLbs: 2 }, { actualLbs: 4 }];
    let result = calcTotalSourceMeatLbs(sourceMeats);
    jestExpect(result).toEqual(6);

    sourceMeats = [];
    result = calcTotalSourceMeatLbs(sourceMeats);
    jestExpect(result).toEqual(0);
  });

  test('#calcTotalIngredientWeightLbs', () => {
    let ingredients = [{ actualLbs: 2 }, { actualLbs: 4 }];
    let result = calcTotalSourceMeatLbs(ingredients);
    jestExpect(result).toEqual(6);

    ingredients = [];
    result = calcTotalSourceMeatLbs(ingredients);
    jestExpect(result).toEqual(0);
  });

  test('#batchType GRINDING', () => {
    const result = batchType('GRINDING');
    jestExpect(result).toEqual('GRINDING');
  });

  test('#batchType MARINATION', () => {
    const result = batchType('CUTTING');
    jestExpect(result).toEqual('MARINATION');
  });

  test('#batchStatus FINISHED', () => {
    const result = batchStatus(true);
    jestExpect(result).toEqual('FINISHED');
  });

  test('#batchStatus UNFINISHED', () => {
    const result = batchStatus(false);
    jestExpect(result).toEqual('UNFINISHED');
  });
});
