import { mount } from 'enzyme';
import React from 'react';
import { createReduxStore } from '../../../store';
import { Provider } from 'react-redux';
import CreateGrindBatchForm from '../CreateGrindBatchForm';
import semanticUI from '../../../../test-helpers/semantic-ui';
import batchResources from '../../../shared/api/batchResources';
import BatchFactory from '../../../../test-factories/batch';
import productResources from '../../../shared/api/productResources';
import productFactory from '../../../../test-factories/productFactory';
import blendFactory from '../../../../test-factories/blendFactory';

jest.mock('../../../shared/api/batchResources');
jest.mock('../../../shared/api/productResources');

describe('createGrindBatchForm', () => {
  let form, savedGrindingBatch, storeForGrindingRoom;

  beforeEach(() => {
    savedGrindingBatch = BatchFactory.build({ id: 1 });

    productResources.getProductInfo.mockImplementation((arg, callback) => {
      callback({ data: productFactory.build({ code: '0078889' }) });
    });

    storeForGrindingRoom = createReduxStore({
      portionRoomsInfo: {
        currentPortionRoom: {
          code: 'A',
          roomType: 'GRINDING'
        },
        portionRooms: [
          {
            code: 'A',
            lastOpenedAt: '07-05-2018'
          }
        ]
      }
    });
    form = mount(
      <Provider store={storeForGrindingRoom}>
        <CreateGrindBatchForm grindSize='' />
      </Provider>
    );
  });

  afterEach(() => {
    batchResources.create.mockReset();
    batchResources.update.mockReset();
    batchResources.finishGrind.mockReset();
    productResources.getProductInfo.mockReset();
  });

  test('should render input component without initialValue for grinding room', () => {
    const findLabelWithName = createFindLabelWithNameSelector(form);
    const getInputValue = createGetInputValueSelector(form);

    jestExpect(findLabelWithName('Batch #')).toHaveProp({ value: 'Pending' });
    jestExpect(findLabelWithName('Blend Name')).toHaveProp({ value: '' });
    jestExpect(findLabelWithName('Production Date')).toHaveProp({ value: '07-05-2018' });
    jestExpect(getInputValue('tumbler')).toEqual('');
    jestExpect(getInputValue('startBatchTemp')).toEqual('');
    jestExpect(getInputValue('finishedBatchTemp')).toEqual('');
    jestExpect(getInputValue('tumblerStartTime')).toEqual('');
    jestExpect(getInputValue('tumblerStopTime')).toEqual('');
    jestExpect(findLabelWithName('Lbs of Batch')).toHaveProp({ value: '' });
    jestExpect(getInputValue('sourceMeats[0].sourceProductCode')).toEqual('');
    jestExpect(getInputValue('sourceMeats[0].poNumber')).toEqual('');
    jestExpect(getInputValue('sourceMeats[0].lotNumber')).toEqual('');
    jestExpect(getInputValue('sourceMeats[0].vendor')).toEqual('');
    jestExpect(getInputValue('sourceMeats[0].meatTemp')).toEqual('');
    jestExpect(getInputValue('sourceMeats[0].actualLbs')).toEqual('');
    jestExpect(getInputValue('sourceMeats[0].establishmentNumber')).toEqual('');
    jestExpect(getInputValue('sourceMeats[0].harvestDate')).toEqual('');
    jestExpect(findLabelWithName('Ingredient #')).not.toExist();
    jestExpect(findLabelWithName('Finished Products')).not.toExist();
  });

  test('should render input component with initialValue for grinding room', () => {
    form = mount(
      <Provider store={storeForGrindingRoom}>
        <CreateGrindBatchForm
          blend={blendFactory.build()}
          batch={savedGrindingBatch}
          grindSize=''
        />
      </Provider>
    );
    const findLabelWithName = createFindLabelWithNameSelector(form);
    const getInputValue = createGetInputValueSelector(form);

    jestExpect(findLabelWithName('Batch #')).toHaveProp({ value: '123' });
    jestExpect(findLabelWithName('Blend Name')).toHaveProp({ value: 'BLEND1004' });
    jestExpect(getInputValue('tumbler')).toEqual('123');
    jestExpect(getInputValue('startBatchTemp')).toEqual('23.20');
    jestExpect(getInputValue('finishedBatchTemp')).toEqual('27.40');
    jestExpect(getInputValue('tumblerStartTime')).toEqual('14:58');
    jestExpect(getInputValue('tumblerStopTime')).toEqual('16:43');
    jestExpect(findLabelWithName('Lbs of Batch')).toHaveProp({ value: '12.13' });
    jestExpect(getInputValue('sourceMeats[0].sourceProductCode')).toEqual('0078889');
    jestExpect(getInputValue('sourceMeats[0].poNumber')).toEqual('12');
    jestExpect(getInputValue('sourceMeats[0].lotNumber')).toEqual('11');
    jestExpect(getInputValue('sourceMeats[0].vendor')).toEqual('vendor name');
    jestExpect(getInputValue('sourceMeats[0].meatTemp')).toEqual('12.12');
    jestExpect(getInputValue('sourceMeats[0].actualLbs')).toEqual('12.13');
    jestExpect(getInputValue('sourceMeats[0].establishmentNumber')).toEqual('ab1');
    jestExpect(getInputValue('sourceMeats[0].harvestDate')).toEqual('12-12-2018');
  });

  test('should update batch main info for grinding room', () => {
    form = mount(
      <Provider store={storeForGrindingRoom}>
        <CreateGrindBatchForm
          shouldAsyncValidate={() => false}
          blend={blendFactory.build()}
          grindSize='3/16'
          batch={savedGrindingBatch}
        />
      </Provider>
    );

    semanticUI.changeInput(form, 'tumbler', '234');
    semanticUI.changeInput(form, 'tumblerStartTime', '11:20');
    semanticUI.changeInput(form, 'tumblerStopTime', '12:20');

    form
      .find('button')
      .at(1)
      .simulate('click');

    jestExpect(batchResources.update.mock.calls[0][0]).toEqual({
      id: 1,
      blendName: 'BLEND1004',
      grindSize: '3/16',
      batchNumber: 123,
      tumbler: '234',
      tumblerStartTime: '11:20',
      tumblerStopTime: '12:20',
      finishedBatchTemp: '27.40',
      startBatchTemp: '23.20',
      portionRoomCode: 'D',
      sourceMeats: [
        {
          poNumber: '12',
          lotNumber: '11',
          sourceProductCode: '0078889',
          meatTemp: '12.12',
          actualLbs: '12.13',
          vendor: 'vendor name',
          establishmentNumber: 'ab1',
          harvestDate: '2018-12-12'
        }
      ],
      productionDate: '2018-05-29',
      finished: false
    });
  });

  test('should fill out form and create batch for grinding room', () => {
    form = mount(
      <Provider store={storeForGrindingRoom}>
        <CreateGrindBatchForm
          shouldAsyncValidate={() => false}
          blend={blendFactory.build()}
          grindSize='3/16'
        />
      </Provider>
    );
    semanticUI.changeInput(form, 'tumbler', '234');
    semanticUI.changeInput(form, 'tumblerStartTime', '11:20');
    semanticUI.changeInput(form, 'tumblerStopTime', '12:20');

    form
      .find('.save-batch-button')
      .at(0)
      .simulate('click');

    jestExpect(batchResources.create.mock.calls[0][0]).toEqual({
      id: '',
      blendName: 'BLEND1004',
      batchNumber: undefined,
      tumbler: '234',
      grindSize: '3/16',
      tumblerStartTime: '11:20',
      tumblerStopTime: '12:20',
      finishedBatchTemp: '',
      startBatchTemp: '',
      sourceMeats: [],
      productionDate: '2018-07-05',
      finished: false,
      portionRoomCode: 'A'
    });
  });

  test('should fill out form and create batch with source meat', () => {
    form = mount(
      <Provider store={storeForGrindingRoom}>
        <CreateGrindBatchForm
          shouldAsyncValidate={() => false}
          blend={blendFactory.build()}
          grindSize='3/16'
        />
      </Provider>
    );

    semanticUI.changeInput(form, 'tumbler', '234');
    semanticUI.changeInput(form, 'tumblerStartTime', '11:20');
    semanticUI.changeInput(form, 'tumblerStopTime', '12:20');

    semanticUI.changeInput(form, 'sourceMeats[0].sourceProductCode', '0078889');
    jestExpect(productResources.getProductInfo.mock.calls[0][0]).toEqual('0078889');

    semanticUI.changeInput(form, 'sourceMeats[0].poNumber', '12');
    semanticUI.changeInput(form, 'sourceMeats[0].lotNumber', '13');
    semanticUI.changeInput(form, 'sourceMeats[0].vendor', 'vendor name');
    semanticUI.changeInput(form, 'sourceMeats[0].meatTemp', '12.12');
    semanticUI.changeInput(form, 'sourceMeats[0].actualLbs', '12.20');
    semanticUI.changeInput(form, 'sourceMeats[0].establishmentNumber', 'ab1');
    semanticUI.changeInput(form, 'sourceMeats[0].harvestDate', '12-12-2018');

    form
      .find('.save-batch-button')
      .at(0)
      .simulate('click');

    jestExpect(batchResources.create.mock.calls[0][0]).toEqual({
      id: '',
      batchNumber: undefined,
      blendName: 'BLEND1004',
      grindSize: '3/16',
      tumbler: '234',
      tumblerStartTime: '11:20',
      tumblerStopTime: '12:20',
      finishedBatchTemp: '',
      startBatchTemp: '',
      sourceMeats: [
        {
          actualLbs: '12.20',
          establishmentNumber: 'ab1',
          harvestDate: '2018-12-12',
          lotNumber: '13',
          vendor: 'vendor name',
          meatTemp: '12.12',
          poNumber: '12',
          sourceProductCode: '0078889'
        }
      ],
      productionDate: '2018-07-05',
      finished: false,
      portionRoomCode: 'A'
    });
  });

  test('should fill out form and update batch', () => {
    savedGrindingBatch = BatchFactory.build({ id: 1 });

    form = mount(
      <Provider store={storeForGrindingRoom}>
        <CreateGrindBatchForm
          shouldAsyncValidate={() => false}
          blendName='kobe'
          grindSize='3/16'
          batch={savedGrindingBatch}
        />
      </Provider>
    );

    semanticUI.changeInput(form, 'tumbler', '234');
    form
      .find('.save-batch-button')
      .at(0)
      .simulate('click');

    jestExpect(batchResources.update).toHaveBeenCalled();
  });

  test('should fill out form and finish and existing batch', () => {
    storeForGrindingRoom = createReduxStore({
      portionRoomsInfo: {
        currentPortionRoom: {
          code: 'A',
          roomType: 'GRINDING'
        }
      }
    });
    form = mount(
      <Provider store={storeForGrindingRoom}>
        <CreateGrindBatchForm
          shouldAsyncValidate={() => false}
          blend={blendFactory.build()}
          grindSize='3/16'
          batch={savedGrindingBatch}
        />
      </Provider>
    );

    semanticUI.changeInput(form, 'tumbler', '234');

    const finishButton = form.find('button').at(2);
    finishButton.simulate('click');
    finishButton.simulate('submit');

    jestExpect(batchResources.finishGrind.mock.calls[0][0]).toEqual({
      batchNumber: 123,
      blendName: 'BLEND1004',
      grindSize: '3/16',
      portionRoomCode: 'D',
      finishedBatchTemp: '27.40',
      finished: true,
      id: 1,
      productionDate: '2018-05-29',
      sourceMeats: [
        {
          actualLbs: '12.13',
          establishmentNumber: 'ab1',
          harvestDate: '2018-12-12',
          lotNumber: '11',
          vendor: 'vendor name',
          meatTemp: '12.12',
          poNumber: '12',
          sourceProductCode: '0078889'
        }
      ],
      startBatchTemp: '23.20',
      tumbler: '234',
      tumblerStartTime: '14:58',
      tumblerStopTime: '16:43'
    });
  });

  test('should not submit when source meat is invalid', () => {
    form = mount(
      <Provider store={storeForGrindingRoom}>
        <CreateGrindBatchForm blendName='kobe' grindSize='3/16' />
      </Provider>
    );
    semanticUI.changeInput(form, 'tumbler', '234');
    semanticUI.changeInput(form, 'tumblerStartTime', '11:20');
    semanticUI.changeInput(form, 'tumblerStopTime', '12:20');
    semanticUI.changeInput(form, 'sourceMeats[0].poNumber', 'xx');

    form.find('form').simulate('submit');

    jestExpect(batchResources.create).not.toHaveBeenCalled();
  });

  test('should not finish when has empty fields', () => {
    form = mount(
      <Provider store={storeForGrindingRoom}>
        <CreateGrindBatchForm blendName='kobe' grindSize='3/16' />
      </Provider>
    );
    semanticUI.changeInput(form, 'tumbler', '234');
    semanticUI.changeInput(form, 'tumblerStartTime', '11:20');
    semanticUI.changeInput(form, 'tumblerStopTime', '12:20');
    semanticUI.changeInput(form, 'sourceMeats[0].poNumber', 'xx');

    const finishButton = form.find('button').at(2);
    finishButton.simulate('click');
    finishButton.simulate('submit');

    jestExpect(batchResources.create).not.toHaveBeenCalled();
  });
});

function createFindLabelWithNameSelector(wrapper) {
  return function(name) {
    return semanticUI.findLabelWithName(wrapper, name);
  };
}

function createGetInputValueSelector(wrapper) {
  return function(name) {
    return semanticUI.getInputValue(wrapper, name);
  };
}
