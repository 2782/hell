import React from 'react';
import PropTypes from 'prop-types';
import { Field, FieldArray } from 'redux-form';
import { Button, Divider, Form, Grid, Label } from 'semantic-ui-react';
import FormElement from '../../shared/FormElement';
import {
  normalizeProductCode,
  normalizeToTwoDecimalPlaces
} from '../../shared/components/product/normalizer';
import Product from '../../shared/components/product/product';
import _ from 'lodash';
import FormDayPickerInput from '../../shared/FormDayPickerInput';
import { DEFAULT_DISPLAY_DATE_FORMAT } from '../../shared/util/dateUtil';
import { mustBeValidDateFormat, notFutureDate } from '../../shared/validation/formFieldValidations';

export default function SourceMeatSection({ totalSourceWeight, batchNumber }) {
  return (
    <div>
      <div>Source Meat</div>
      <Divider hidden />
      <FieldArray
        name={'sourceMeats'}
        component={SourceMeatList}
        props={{ totalSourceWeight, batchNumber }}
      />
    </div>
  );
}

SourceMeatSection.propTypes = {
  totalSourceWeight: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  batchNumber: PropTypes.oneOfType([PropTypes.string, PropTypes.number])
};

export function SourceMeatList({
  fields,
  totalSourceWeight,
  batchNumber,
  message,
  meta: { error, warning, dirty, invalid, submitFailed }
}) {
  return (
    <div className={'create-batch-source-meat-list create-batch-section'}>
      {fields.map((sourceMeat, index) => {
        const sourceMeatData = fields.get(index);
        const productNamespace = `batchForm-sourceMeat-${index}`;
        const sourceMeatId = _.get(sourceMeatData, 'id', '');
        const key = sourceMeatId ? `${batchNumber}-existing-product-${index}` : sourceMeat;
        return (
          <div key={key} className={'create-batch-source-meat'}>
            <Grid>
              <Grid.Row>
                <Grid.Column>
                  <Field
                    component={Product}
                    name={`${sourceMeat}.sourceProductCode`}
                    namespace={productNamespace}
                    label='Source #'
                    normalize={normalizeProductCode}
                  />
                </Grid.Column>
              </Grid.Row>

              <Grid.Row>
                <Grid.Column width={3}>
                  <Field
                    component={FormElement}
                    name={`${sourceMeat}.poNumber`}
                    as={Form.Input}
                    type='text'
                    label='PO #'
                  />
                </Grid.Column>
                <Grid.Column width={3}>
                  <Field
                    component={FormElement}
                    name={`${sourceMeat}.lotNumber`}
                    as={Form.Input}
                    type='text'
                    label='LOT #'
                  />
                </Grid.Column>
                <Grid.Column width={3}>
                  <Field
                    component={FormElement}
                    name={`${sourceMeat}.vendor`}
                    as={Form.Input}
                    type='text'
                    label='Vendor'
                  />
                </Grid.Column>
                <Grid.Column width={4}>
                  <Field
                    component={FormElement}
                    name={`${sourceMeat}.meatTemp`}
                    as={Form.Input}
                    normalize={normalizeToTwoDecimalPlaces}
                    type='text'
                    label='Meat Temp.'
                  />
                </Grid.Column>
                <Grid.Column width={3}>
                  <Field
                    component={FormElement}
                    name={`${sourceMeat}.actualLbs`}
                    as={Form.Input}
                    normalize={normalizeToTwoDecimalPlaces}
                    type='text'
                    label='Actual Lbs'
                  />
                </Grid.Column>
              </Grid.Row>

              <Grid.Row>
                <Grid.Column width={6}>
                  <Field
                    component={FormElement}
                    name={`${sourceMeat}.establishmentNumber`}
                    as={Form.Input}
                    width={9}
                    type='text'
                    label='Establishment #'
                  />
                </Grid.Column>
                <Grid.Column width={5}>
                  <Field
                    component={FormDayPickerInput}
                    as={Form.Input}
                    name={`${sourceMeat}.harvestDate`}
                    label='Harvest Date (of animal)'
                    formatString={DEFAULT_DISPLAY_DATE_FORMAT}
                    placeholder={DEFAULT_DISPLAY_DATE_FORMAT}
                    dayPickerProps={{
                      showOutsideDays: true,
                      disabledDays: [{ after: new Date() }]
                    }}
                    validate={[mustBeValidDateFormat, notFutureDate]}
                  />
                </Grid.Column>
              </Grid.Row>
            </Grid>

            <Divider hidden />
          </div>
        );
      })}

      <Divider hidden />

      <Button type='button' secondary onClick={() => fields.push({})}>
        Add Source
      </Button>

      <Divider hidden />

      <div>{`Total source weight: ${totalSourceWeight} lbs`} </div>

      <Divider hidden />

      {invalid && (dirty || submitFailed) && !message
        ? (error && (
            <Label basic color='red' pointing>
              {error}
            </Label>
          )) ||
          (warning && (
            <Label basic color='orange' pointing>
              {warning}
            </Label>
          ))
        : message && (
            <Label basic color='red' pointing>
              {message}
            </Label>
          )}
    </div>
  );
}

SourceMeatList.propTypes = {
  fields: PropTypes.oneOfType([PropTypes.object, PropTypes.array]),
  totalSourceWeight: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  message: PropTypes.string,
  meta: PropTypes.object,
  batchNumber: PropTypes.oneOfType([PropTypes.string, PropTypes.number])
};
