import _ from 'lodash';
import moment from 'moment';
import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { createOrUpdateBatch, finishGrindBatch } from '../actions/batchActions';
import { formValueSelector, reduxForm } from 'redux-form';
import { Button, Divider, Form, Grid, Icon } from 'semantic-ui-react';
import FormLabel from '../../shared/FormLabel';
import { formatNumberToTwoDecimalPlacesString } from '../../shared/util/dataUtil';
import { validateFieldArray, validateGrindSubmission } from './batchFormValidator';
import BatchInfo from './BatchInfo';
import SourceMeatSection from './SourceMeatSection';
import { getProduct } from '../../shared/components/product/actionsDuplicate';
import { calcTotalSourceMeatLbs, calcTumblerTimes } from './batchUtils';
import { DEFAULT_DISPLAY_DATE_FORMAT } from '../../shared/util/dateUtil';

const formName = 'batchForm';

export class CreateGrindBatchForm extends React.Component {
  constructor(props) {
    super(props);
  }

  handleFinish(values) {
    const { finishGrindBatch, roomCode } = this.props;

    this.handleSubmit(values, roomCode, true, finishGrindBatch);
  }

  handleSave(values) {
    const { createOrUpdateBatch, roomCode } = this.props;

    this.handleSubmit(values, roomCode, false, createOrUpdateBatch);
  }

  handleSubmit(values, roomCode, finished, callback) {
    const submitSourceMeats = _.filter(values.sourceMeats, sourceMeat => !_.isEmpty(sourceMeat));

    validateGrindSubmission({ ...values, sourceMeats: submitSourceMeats }, this.props, finished);

    const submitValues = generateSubmitValues(values, submitSourceMeats, roomCode);

    callback({ ...submitValues, finished });
  }

  render() {
    const {
      isNewBatch,
      productionDate,
      tumblerTimes,
      totalSourceWeight,
      batchNumber,
      handleSubmit,
      submitting,
      pristine,
      finished,
      blend,
      totalLbsOfBatch
    } = this.props;

    const needDisableFinishButton = submitting || finished;

    return (
      <div className='create-batch-form'>
        <Form size={'large'}>
          <Divider hidden className='divider-medium' />
          <Grid>
            <Grid.Row>
              <Grid.Column width={5}>
                <FormLabel
                  label='Batch #'
                  value={batchNumber ? batchNumber.toString() : 'Pending'}
                  width={10}
                />
              </Grid.Column>

              <Grid.Column width={5}>
                <FormLabel label='Blend Name' value={blend ? blend.name : ''} width={10} />
              </Grid.Column>

              <Grid.Column width={6}>
                <FormLabel label='Production Date' value={productionDate} width={10} />
              </Grid.Column>
            </Grid.Row>
          </Grid>

          <Divider hidden />

          <BatchInfo isGrinder={true} tumblerTimes={tumblerTimes} lbsOfBatch={totalLbsOfBatch} />

          <Divider hidden />

          <SourceMeatSection totalSourceWeight={totalSourceWeight} batchNumber={batchNumber} />

          <Divider hidden />

          <Button
            primary
            size={'large'}
            loading={submitting}
            disabled={submitting || (!isNewBatch && pristine)}
            onClick={handleSubmit(values => {
              this.handleSave(values);
            })}
            className={'save-batch-button'}
            pid={'create-batch-save-button'}
          >
            <Icon className='icon-save' />
            Save
          </Button>

          <Button
            primary
            size={'large'}
            className={'finish-batch-button'}
            pid={'create-batch-finish-button'}
            loading={submitting}
            disabled={needDisableFinishButton}
            onClick={handleSubmit(values => {
              this.handleFinish(values);
            })}
          >
            Finish
          </Button>

          <Divider hidden />
        </Form>
      </div>
    );
  }
}

CreateGrindBatchForm.propTypes = {
  products: PropTypes.object,
  initialValues: PropTypes.object,
  submitting: PropTypes.bool.isRequired,
  pristine: PropTypes.bool.isRequired,
  handleSubmit: PropTypes.func.isRequired,
  productionDate: PropTypes.string,
  tumblerTimes: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  createOrUpdateBatch: PropTypes.func.isRequired,
  totalSourceWeight: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  totalLbsOfBatch: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  sourceMeatProductExist: PropTypes.object,
  batchNumber: PropTypes.number,
  batch: PropTypes.object,
  blend: PropTypes.object,
  grindSize: PropTypes.string,
  finished: PropTypes.bool,
  changeFieldValue: PropTypes.func,
  finishGrindBatch: PropTypes.func,
  getProduct: PropTypes.func.isRequired,
  isNewBatch: PropTypes.bool,
  roomCode: PropTypes.string,
  invalid: PropTypes.bool
};

export const generateSubmitValues = (formValues, submitSourceMeats, roomCode) => {
  let submitValues = {
    ...formValues,
    blendName: formValues.blend.name,
    sourceMeats: submitSourceMeats,
    portionRoomCode: roomCode
  };

  delete submitValues.blend;
  return submitValues;
};

const mapDispatchToProps = dispatch => {
  return bindActionCreators(
    {
      getProduct,
      createOrUpdateBatch,
      finishGrindBatch
    },
    dispatch
  );
};

const getInitialSourceMeats = batch => {
  const initialSourceMeats = _.map(_.get(batch, 'sourceMeats', []), sourceMeat => {
    return {
      ...sourceMeat,
      actualLbs: formatNumberToTwoDecimalPlacesString(_.get(sourceMeat, 'actualLbs', '')),
      meatTemp: formatNumberToTwoDecimalPlacesString(_.get(sourceMeat, 'meatTemp', ''))
    };
  });
  return initialSourceMeats.length > 0 ? initialSourceMeats : [{}];
};

const selector = formValueSelector(formName);
const mapStateToProps = (state, ownProps) => {
  const { portionRooms, currentPortionRoom } = state.portionRoomsInfo;
  const currentDate = _.get(
    _.find(portionRooms, { code: currentPortionRoom.code }),
    'lastOpenedAt'
  );
  const { batch, blend, grindSize } = ownProps;

  const batchNumber = selector(state, 'batchNumber');

  const tumblerStartTime = selector(state, 'tumblerStartTime');
  const tumblerStopTime = selector(state, 'tumblerStopTime');
  const tumblerTimes = calcTumblerTimes(tumblerStartTime, tumblerStopTime);
  const products = state.productDuplicate.products ? state.productDuplicate.products : {};
  const sourceMeats = selector(state, 'sourceMeats');
  const totalSourceWeight = calcTotalSourceMeatLbs(sourceMeats);

  const produceDate = _.get(batch, 'productionDate', currentDate);
  const formattedProductDate = moment(
    new Date(
      produceDate && produceDate != currentDate ? produceDate.replace(/-/g, '/') : produceDate
    )
  ).format(DEFAULT_DISPLAY_DATE_FORMAT);
  const isNewBatch = _.isEmpty(batch);
  const roomCode = _.get(batch, 'portionRoomCode', currentPortionRoom.code);

  const sourceMeatProductExist = _.reduce(
    sourceMeats,
    (result, sourceMeat, index) => {
      const sourceProductInfo = state.product[`${formName}-sourceMeat-${index}`] || {};
      if (!_.isEmpty(sourceMeat)) {
        result[sourceMeat.sourceProductCode] = !_.isEmpty(sourceProductInfo.description);
      }

      return result;
    },
    {}
  );

  const initialSourceMeats = getInitialSourceMeats(batch);

  return {
    initialValues: {
      id: _.get(batch, 'id', ''),
      batchNumber: _.get(batch, 'batchNumber', undefined),
      productionDate: formattedProductDate,
      tumbler: _.get(batch, 'tumbler', ''),
      tumblerStartTime: _.get(batch, 'tumblerStartTime', ''),
      tumblerStopTime: _.get(batch, 'tumblerStopTime', ''),
      startBatchTemp: formatNumberToTwoDecimalPlacesString(_.get(batch, 'startBatchTemp', '')),
      finishedBatchTemp: formatNumberToTwoDecimalPlacesString(
        _.get(batch, 'finishedBatchTemp', '')
      ),
      sourceMeats: initialSourceMeats,
      finished: _.get(batch, 'finished', false),
      blend: blend ? blend : { name: '' },
      grindSize
    },
    products,
    batchNumber,
    productionDate: formattedProductDate,
    totalSourceWeight: formatNumberToTwoDecimalPlacesString(totalSourceWeight) || '',
    totalLbsOfBatch: formatNumberToTwoDecimalPlacesString(totalSourceWeight) || '',
    finished: _.get(batch, 'finished', false),
    isNewBatch,
    tumblerTimes,
    sourceMeatProductExist,
    blend: blend ? blend : { name: '' },
    grindSize,
    roomCode
  };
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(
  reduxForm({
    form: formName,
    validate: validateFieldArray,
    enableReinitialize: true
  })(CreateGrindBatchForm)
);
