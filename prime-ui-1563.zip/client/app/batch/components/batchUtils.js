import { isTimeAfter } from '../../shared/util/dateUtil';
import moment from 'moment';
import _ from 'lodash';

export const calcTumblerTimes = (tumblerStartTime, tumblerStopTime) => {
  if (tumblerStartTime && tumblerStopTime && isTimeAfter(tumblerStopTime, tumblerStartTime)) {
    return moment
      .duration(moment(tumblerStopTime, 'HH:mm').diff(moment(tumblerStartTime, 'HH:mm')))
      .asMinutes();
  }
  return '';
};

export const convertToMilitaryTime = timeString => {
  return moment(timeString, 'HH:mm').format('hh:mm A');
};

export const calcTotalSourceMeatLbs = sourceMeats => {
  return !sourceMeats
    ? 0
    : _.sumBy(sourceMeats, sourceMeat => {
        const actualLbs = Number(_.get(sourceMeat, 'actualLbs', ''));
        return isNaN(actualLbs) ? 0 : actualLbs;
      });
};

export const calcTotalIngredientWeightLbs = ingredients => {
  return !ingredients
    ? 0
    : _.sumBy(ingredients, ingredient => {
        const actualLbs = Number(_.get(ingredient, 'actualLbs', ''));
        return isNaN(actualLbs) ? 0 : actualLbs;
      });
};

export const batchType = roomType => {
  return roomType === 'GRINDING' ? 'GRINDING' : 'MARINATION';
};

export const batchStatus = isFinished => {
  return isFinished ? 'FINISHED' : 'UNFINISHED';
};
