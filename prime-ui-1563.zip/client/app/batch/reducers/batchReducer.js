import { UPDATE_BATCH, UPDATE_BATCHES } from '../actions/batchActionTypes';

const initialState = {
  batch: {},
  batches: [],
  productsExist: {}
};

export default (state = initialState, action) => {
  switch (action.type) {
    case UPDATE_BATCH:
      return {
        ...state,
        batch: action.payload,
        isFinishing: false
      };
    case UPDATE_BATCHES:
      return {
        ...state,
        batches: action.payload
      };
    default:
      return state;
  }
};
