import { SEARCH_BATCHES_SUCCEEDED, SEARCH_BATCHES_CLEARED } from '../actions/batchActionTypes';

const initialState = {
  batches: []
};

export default (state = initialState, action) => {
  switch (action.type) {
    case SEARCH_BATCHES_SUCCEEDED:
      return {
        batches: action.payload
      };
    case SEARCH_BATCHES_CLEARED:
      return initialState;
    default:
      return state;
  }
};
