export const UPDATE_BATCH = 'updateBatch';
export const UPDATE_BATCHES = 'updateBatches';
export const SEARCH_BATCHES_SUCCEEDED = 'searchBatchesSucceeded';
export const SEARCH_BATCHES_CLEARED = 'SEARCH_BATCHES_CLEARED';
