import batchResources from '../../shared/api/batchResources';
import { UPDATE_BATCH } from './batchActionTypes';
import { SHOW_ERROR } from '../../settings/actions/settingsActionTypes';
import { returnToPreviousPage } from '../../shared/actions/actions';
import { searchBatchesSuccess, clearSearchBatches } from './batchActionCreators';
import { displayDateToIsoDate, isoDateToDisplayDate } from '../../shared/util/dateUtil';
import _ from 'lodash';

export const createOrUpdateBatch = batch => {
  return dispatch => {
    const successCallback = response => {
      dispatch({
        type: UPDATE_BATCH,
        payload: response.data
      });
      dispatch(returnToPreviousPage());
    };

    const errorCallback = error => {
      dispatch({
        type: SHOW_ERROR,
        payload: error
      });
    };

    const modifiedBatch = _.cloneDeep(batch);
    modifiedBatch.productionDate = displayDateToIsoDate(batch.productionDate);
    modifiedBatch.sourceMeats.map(
      meat => (meat.harvestDate = displayDateToIsoDate(meat.harvestDate))
    );
    if (batch.id) {
      batchResources.update(modifiedBatch, successCallback, errorCallback);
    } else {
      batchResources.create(modifiedBatch, successCallback, errorCallback);
    }
  };
};

export const finishGrindBatch = batch => {
  return dispatch => {
    const successCallback = response => {
      dispatch({
        type: UPDATE_BATCH,
        payload: response.data
      });
      dispatch(returnToPreviousPage());
    };

    const errorCallback = error => {
      dispatch({
        type: SHOW_ERROR,
        payload: error
      });
    };

    const modifiedBatch = _.cloneDeep(batch);
    modifiedBatch.productionDate = displayDateToIsoDate(batch.productionDate);
    modifiedBatch.sourceMeats.map(
      meat => (meat.harvestDate = displayDateToIsoDate(meat.harvestDate))
    );
    batchResources.finishGrind(modifiedBatch, successCallback, errorCallback);
  };
};

export const finishMarinationBatch = batch => {
  return dispatch => {
    const successCallback = response => {
      dispatch({
        type: UPDATE_BATCH,
        payload: response.data
      });
      dispatch(returnToPreviousPage());
    };

    const errorCallback = error => {
      dispatch({
        type: SHOW_ERROR,
        payload: error
      });
    };

    const modifiedBatch = _.cloneDeep(batch);
    modifiedBatch.productionDate = displayDateToIsoDate(batch.productionDate);
    modifiedBatch.sourceMeats.map(
      meat => (meat.harvestDate = displayDateToIsoDate(meat.harvestDate))
    );
    batchResources.finishMarination(modifiedBatch, successCallback, errorCallback);
  };
};

export const searchBatches = values => dispatch => {
  const modifiedValues = { ...values };
  modifiedValues.productionDateStart = displayDateToIsoDate(values.productionDateStart);
  modifiedValues.productionDateEnd = displayDateToIsoDate(values.productionDateEnd);

  return batchResources.search(modifiedValues).then(response => {
    response.data.map(batch =>
      batch.sourceMeats.map(meat => (meat.harvestDate = isoDateToDisplayDate(meat.harvestDate)))
    );

    dispatch(searchBatchesSuccess(response));
  });
};

export const resetBatches = () => dispatch => {
  dispatch(clearSearchBatches());
};
