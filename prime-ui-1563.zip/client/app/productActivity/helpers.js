import _ from 'lodash';
import {
  BOX_REPORT_TYPE_NAME,
  CUT_ORDER_SELECTION_REPORT_TYPE_NAME,
  RETURN_BOX_REPORT_TYPE_NAME,
  SOURCE_MEAT_ORDER_REPORT_TYPE_NAME,
  SOURCE_MEAT_RECEIPT_REPORT_TYPE_NAME,
  SOURCE_MEAT_WIP_RECEIPT_REPORT_TYPE_NAME,
  SOURCE_MEAT_WIP_REPORT_TYPE_NAME
} from './reportingTypes';
import moment from 'moment';

export const formatType = type => {
  switch (type) {
    case BOX_REPORT_TYPE_NAME:
      return 'Packoff';
    case CUT_ORDER_SELECTION_REPORT_TYPE_NAME:
      return 'Cut Selection';
    case SOURCE_MEAT_ORDER_REPORT_TYPE_NAME:
      return 'Request Meat';
    case SOURCE_MEAT_WIP_REPORT_TYPE_NAME:
      return 'Request Meat';
    case RETURN_BOX_REPORT_TYPE_NAME:
      return 'Packoff';
    case SOURCE_MEAT_RECEIPT_REPORT_TYPE_NAME:
      return 'Receive Meat';
    case SOURCE_MEAT_WIP_RECEIPT_REPORT_TYPE_NAME:
      return 'Receive Meat';
    default:
      return '';
  }
};
const formatProduceDate = produceDate => {
  if (!_.isEmpty(produceDate)) {
    const date = moment(produceDate).format('MM-DD-YY');
    const time = produceDate.substring(11, 19);
    const twelveHourTime = moment(time, 'HH:mm:ss').format('h:mm A');

    return date + ' ' + twelveHourTime;
  } else {
    return '';
  }
};

const formatEventDate = produceDate => {
  if (!_.isEmpty(produceDate)) {
    const date = moment(produceDate).format('MM-DD-YY');
    const time = produceDate.substring(11, 19);
    const twelveHourTime = moment(time, 'HH:mm:ss').format('h:mm A');

    return date + ' ' + twelveHourTime;
  } else {
    return '';
  }
};

const formatShipDate = shipDate => {
  if (!_.isEmpty(shipDate)) {
    return moment(shipDate).format('MM-DD');
  } else {
    return '';
  }
};

const formatCustomer = incomplete => (incomplete ? 'WIP' : 'Stock');
const formatUnitOfMeasure = unitOfMeasure => {
  switch ((unitOfMeasure ? unitOfMeasure : '').toUpperCase()) {
    case 'CASE':
      return 'CS';
    case 'LBS':
      return 'LB';
    case 'PIECE':
      return 'PC';
    default:
      return unitOfMeasure;
  }
};

export const reportingTableHelpers = {
  formatCustomer,
  formatEventDate,
  formatProduceDate,
  formatShipDate,
  formatType,
  formatUnitOfMeasure
};
