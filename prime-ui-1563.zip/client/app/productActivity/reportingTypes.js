export const CUT_ORDER_SELECTION_REPORT_TYPE_NAME = 'CutOrderSelection';
export const BOX_REPORT_TYPE_NAME = 'Box';
export const RETURN_BOX_REPORT_TYPE_NAME = 'ReturnBox';
export const SOURCE_MEAT_ORDER_REPORT_TYPE_NAME = 'SourceMeatOrder';
export const SOURCE_MEAT_RECEIPT_REPORT_TYPE_NAME = 'SourceMeatReceipt';
export const SOURCE_MEAT_WIP_RECEIPT_REPORT_TYPE_NAME = 'SourceMeatWipReceipt';
export const SOURCE_MEAT_WIP_REPORT_TYPE_NAME = 'SourceMeatWip';
