import {
  PRODUCT_ACTIVITY_CLEARED,
  PRODUCT_ACTIVITY_DETAIL_CRITERIA_SAVED,
  DETAILS_SORTED_BY_COLUMN
} from '../../actions/productActivityActionTypes';
import productActivityDetailReducer from '../productActivityDetailReducer';
import { ReportingBoxPackSequence, PageFactory } from '../../../../test-factories/productActivity';
import { fetchProductActivityDetails } from '../../actions/productActivityDetailActions';

describe('productActivityDetailReducer', () => {
  let initState;

  beforeEach(() => {
    initState = {
      productActivityDetailsPage: {},
      productActivityDetails: [],
      productActivityDetailCriteria: {},
      productActivityDetailsSortColumn: 'createdAt',
      productActivityDetailsSortDirection: 'desc'
    };
  });

  describe('PRODUCT_ACTIVITY_CLEARED', () => {
    test('should clear current data in productActivity reducer', () => {
      const currentState = { ...initState, productActivityDetails: ['box1'] };

      jestExpect(
        productActivityDetailReducer(currentState, {
          type: PRODUCT_ACTIVITY_CLEARED
        })
      ).toEqual(initState);
    });
  });

  describe('PRODUCT_ACTIVITY_DETAILS_FETCHED', () => {
    test('should fetch details for a product activity record', () => {
      const currentState = { ...initState };
      const box1 = ReportingBoxPackSequence.build();
      const page = PageFactory.build();
      const response = {
        data: {
          content: [box1],
          ...page
        }
      };

      const action = fetchProductActivityDetails(response);
      const result = productActivityDetailReducer(currentState, action);

      jestExpect(result).toEqual({
        ...initState,
        productActivityDetails: [box1],
        productActivityDetailsPage: page
      });
    });

    test('should not set page when content is empty', () => {
      const page = PageFactory.build();

      const response = {
        data: {
          content: [],
          ...page
        }
      };
      const action = fetchProductActivityDetails(response);

      jestExpect(productActivityDetailReducer({ ...initState }, action)).toEqual({
        ...initState,
        productActivityDetails: [],
        productActivityDetailsPage: {}
      });
    });
  });

  describe('DETAILS_SORTED_BY_COLUMN', () => {
    test('should change sort column and sort direction', () => {
      const expectedState = {
        ...initState,
        productActivityDetailsSortColumn: 'type',
        productActivityDetailsSortDirection: 'asc'
      };

      jestExpect(
        productActivityDetailReducer(initState, {
          type: DETAILS_SORTED_BY_COLUMN,
          payload: {
            productActivityDetailsSortColumn: 'type',
            productActivityDetailsSortDirection: 'asc'
          }
        })
      ).toEqual(expectedState);
    });
  });

  describe('PRODUCT_ACTIVITY_DETAIL_CRITERIA_SAVED', () => {
    test('should save product activity detail aggregate', () => {
      const details = {
        workingDate: '2018-12-20'
      };

      const expectedState = {
        productActivityDetailsPage: {},
        productActivityDetails: [],
        productActivityDetailCriteria: { workingDate: '2018-12-20' },
        productActivityDetailsSortColumn: 'createdAt',
        productActivityDetailsSortDirection: 'desc'
      };

      jestExpect(
        productActivityDetailReducer(initState, {
          type: PRODUCT_ACTIVITY_DETAIL_CRITERIA_SAVED,
          payload: details
        })
      ).toEqual(expectedState);
    });
  });
});
