import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { replacePath, setHeaderAndFooter } from '../../shared/actions/actions';
import { PRODUCT_ACTIVITY } from '../../shared/components/pageTitles';
import { F4_F2 } from '../../shared/components/pageFooters';
import { bindActionCreators } from 'redux';
import { clearFields, Field, formValueSelector, reduxForm } from 'redux-form';
import ProductDuplicate from '../../shared/components/product/ProductDuplicate';
import { Button, Divider, Form, Grid, Pagination } from 'semantic-ui-react';
import { normalizeProductCode } from '../../shared/components/product/normalizer';
import { getProduct, setProductExistTo } from '../../shared/components/product/actionsDuplicate';
import _ from 'lodash';
import {
  productActivitiesChangePage,
  clearProductActivities,
  getProductActivities,
  handleActivitiesSort
} from '../actions/productActivityActions';
import ReportingTable from './ReportingTable';
import FormLabel from '../../shared/FormLabel';
import FormDayPickerInput from '../../shared/FormDayPickerInput';
import { mustBeValidDateFormat, notFutureDate } from '../../shared/validation/formFieldValidations';
import { NOT_A_PRODUCT_CODE } from '../../../config/errorMessage';
import {
  validateProductionDates,
  validateSubmission
} from '../components/productActivityValidator';
import {
  getProductActivityDetails,
  saveProductActivityDetailCriteria
} from '../actions/productActivityDetailActions';
import { DEFAULT_DISPLAY_DATE_FORMAT } from '../../shared/util/dateUtil';

const FORM_NAME = 'productActivity';

export class ProductActivityComponent extends React.Component {
  constructor(props) {
    super(props);
    this.handleFinishedProductCodeBlur = this.handleFinishedProductCodeBlur.bind(this);
    this.handleFinishedProductCodeChange = this.handleFinishedProductCodeChange.bind(this);
    this.handleDetailsButtonClick = this.handleDetailsButtonClick.bind(this);
    this.scrollToTop = this.scrollToTop.bind(this);
    this.search = this.search.bind(this);
  }

  scrollToTop() {
    if (this.scrollToTopRef && this.scrollToTopRef.scrollIntoView) {
      this.scrollToTopRef.scrollIntoView({
        behavior: 'smooth',
        block: 'start',
        inline: 'nearest'
      });
    }
  }

  componentDidMount() {
    this.props.setHeaderAndFooter({
      header: PRODUCT_ACTIVITY,
      footer: F4_F2
    });

    this.scrollToTop();
  }

  componentWillUnmount() {
    const { finishedProductCode, setProductExistTo, clearProductActivities } = this.props;
    if (!_.isEmpty(finishedProductCode)) {
      setProductExistTo(finishedProductCode, true);
    }
    clearProductActivities();
  }

  handleFinishedProductCodeBlur(event, normalizedValue) {
    const { getProduct, setProductExistTo } = this.props;
    if (!_.isEmpty(normalizedValue)) {
      getProduct(normalizedValue, () => setProductExistTo(normalizedValue, false));
    }
  }

  handleFinishedProductCodeChange(event, value) {
    const { setProductExistTo, clearProductActivities, dispatch } = this.props;
    if (!_.isEmpty(value)) {
      setProductExistTo(value, true);
      clearProductActivities();
    }

    dispatch(clearFields(FORM_NAME, false, false, 'startDate', 'endDate'));
  }

  handleDetailsButtonClick(activityType, productActivity) {
    const {
      getProductActivityDetails,
      saveProductActivityDetailCriteria,
      replacePath
    } = this.props;

    return getProductActivityDetails({ activityType, productActivity }).then(() => {
      saveProductActivityDetailCriteria(activityType, productActivity);
      replacePath('/product/product-activity/details');
    });
  }

  search(values) {
    this.button.focus();

    validateSubmission(values);

    this.props.getProductActivities(values);
  }

  render() {
    const {
      productActivitiesChangePage,
      finishedProductCode,
      handleActivitiesSort,
      handleSubmit,
      invalid,
      page,
      pristine,
      productActivities,
      productsDuplicate,
      productsExistList,
      sortColumn,
      sortDirection,
      submitting
    } = this.props;

    const productExist = _.get(productsExistList, finishedProductCode, true);

    return (
      <div className={'activity-page'} ref={node => (this.scrollToTopRef = node)}>
        <Form size={'large'} onSubmit={handleSubmit(this.search)}>
          <Grid>
            <Grid.Row verticalAlign='top'>
              <Grid.Column width={12}>
                <Field
                  component={ProductDuplicate}
                  name='productCode'
                  autoFocus={true}
                  label='Finished/Source #'
                  product={productsDuplicate[finishedProductCode] || {}}
                  normalize={normalizeProductCode}
                  message={productExist ? null : NOT_A_PRODUCT_CODE}
                  onBlur={this.handleFinishedProductCodeBlur}
                  onChange={this.handleFinishedProductCodeChange}
                />
              </Grid.Column>
              <Grid.Column width={4}>
                <FormLabel
                  width={16}
                  className={''}
                  label={'PORTION SIZE'}
                  value={`${_.get(
                    productsDuplicate[finishedProductCode],
                    'productPortionSize.portionSize',
                    ''
                  )} `}
                />
              </Grid.Column>
            </Grid.Row>
            <Grid.Row>
              <Grid.Column width={4}>
                <Field
                  component={FormDayPickerInput}
                  as={Form.Input}
                  name='startDate'
                  label='Production Date'
                  formatString={DEFAULT_DISPLAY_DATE_FORMAT}
                  placeholder={DEFAULT_DISPLAY_DATE_FORMAT}
                  dayPickerProps={{
                    showOutsideDays: true,
                    disabledDays: [{ after: new Date() }]
                  }}
                  validate={[mustBeValidDateFormat, notFutureDate]}
                />
              </Grid.Column>
              <Grid.Column>
                <label>&nbsp;</label>
                <div className={'date-splitter'}>&mdash;</div>
              </Grid.Column>
              <Grid.Column width={4}>
                <Field
                  component={FormDayPickerInput}
                  as={Form.Input}
                  name='endDate'
                  label=' '
                  formatString={DEFAULT_DISPLAY_DATE_FORMAT}
                  placeholder={DEFAULT_DISPLAY_DATE_FORMAT}
                  dayPickerProps={{
                    showOutsideDays: true,
                    disabledDays: [{ after: new Date() }]
                  }}
                  validate={[mustBeValidDateFormat, notFutureDate]}
                />
              </Grid.Column>
            </Grid.Row>
          </Grid>

          <Divider hidden />

          <Grid>
            <Grid.Row verticalAlign='bottom'>
              <Grid.Column width={8}>
                <Button
                  ref={node => (this.button = node)}
                  primary
                  size={'large'}
                  type='submit'
                  disabled={submitting || pristine || invalid || !productExist}
                >
                  Search
                </Button>
              </Grid.Column>
              <Grid.Column textAlign='right' width={16}>
                {_.isEmpty(page) ? null : (
                  <Pagination
                    activePage={page.pageable.pageNumber + 1}
                    onPageChange={(event, data) =>
                      productActivitiesChangePage(data.activePage - 1).then(this.scrollToTop)
                    }
                    totalPages={page.totalPages}
                  />
                )}
              </Grid.Column>
            </Grid.Row>
          </Grid>
        </Form>

        <ReportingTable
          reportingData={productActivities}
          sortColumn={sortColumn}
          sortDirection={sortDirection}
          handleSort={handleActivitiesSort}
          handleDetailsButtonClick={this.handleDetailsButtonClick}
        />
        {_.isEmpty(page) ? null : (
          <Grid>
            <Grid.Row>
              <Grid.Column textAlign='right' width={16}>
                <Pagination
                  activePage={page.pageable.pageNumber + 1}
                  onPageChange={(event, data) =>
                    productActivitiesChangePage(data.activePage - 1).then(this.scrollToTop)
                  }
                  totalPages={page.totalPages}
                />
              </Grid.Column>
            </Grid.Row>
          </Grid>
        )}
      </div>
    );
  }
}

ProductActivityComponent.propTypes = {
  productActivitiesChangePage: PropTypes.func,
  saveProductActivityDetailCriteria: PropTypes.func,
  clearProductActivities: PropTypes.func,
  dispatch: PropTypes.func,
  finishedProductCode: PropTypes.string,
  finishedProductCodeExists: PropTypes.bool,
  getProduct: PropTypes.func,
  getProductActivities: PropTypes.func,
  handleActivitiesSort: PropTypes.func.isRequired,
  getProductActivityDetails: PropTypes.func,
  handleSubmit: PropTypes.func.isRequired,
  invalid: PropTypes.bool,
  page: PropTypes.object,
  pristine: PropTypes.bool,
  productActivities: PropTypes.array,
  productionDateEnd: PropTypes.any,
  productionDateStart: PropTypes.any,
  productsDuplicate: PropTypes.object,
  productsExistList: PropTypes.object,
  replacePath: PropTypes.func,
  setHeaderAndFooter: PropTypes.func.isRequired,
  setProductExistTo: PropTypes.func,
  sortColumn: PropTypes.string,
  sortDirection: PropTypes.string,
  submitting: PropTypes.bool
};

const mapDispatchToProps = dispatch =>
  bindActionCreators(
    {
      replacePath,
      productActivitiesChangePage,
      clearProductActivities,
      getProduct,
      getProductActivities,
      getProductActivityDetails,
      saveProductActivityDetailCriteria,
      handleActivitiesSort,
      setHeaderAndFooter,
      setProductExistTo
    },
    dispatch
  );

const selector = formValueSelector(FORM_NAME);
const mapStateToProps = state => {
  const finishedProductCode = selector(state, 'productCode');
  const productsDuplicate = state.productDuplicate.products;
  const {
    productActivitiesPage,
    productActivities,
    productActivitySearchCriteria,
    productActivitiesSortColumn,
    productActivitiesSortDirection
  } = state.productActivity;
  const productsExistList = state.productDuplicate.productsExist || {};

  return {
    initialValues: productActivitySearchCriteria,
    finishedProductCode,
    page: productActivitiesPage,
    productActivities,
    productsDuplicate,
    productsExistList,
    sortColumn: productActivitiesSortColumn,
    sortDirection: productActivitiesSortDirection
  };
};

const ProductActivity = connect(
  mapStateToProps,
  mapDispatchToProps
)(
  reduxForm({
    form: FORM_NAME,
    validate: validateProductionDates
  })(ProductActivityComponent)
);

export default ProductActivity;
