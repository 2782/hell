import React from 'react';
import PropTypes from 'prop-types';
import { Table } from 'semantic-ui-react';
import EmptyTableMessage from '../../shared/components/EmptyTableMessage';
import _ from 'lodash';
import {
  BOX_REPORT_TYPE_NAME,
  CUT_ORDER_SELECTION_REPORT_TYPE_NAME,
  RETURN_BOX_REPORT_TYPE_NAME,
  SOURCE_MEAT_ORDER_REPORT_TYPE_NAME,
  SOURCE_MEAT_RECEIPT_REPORT_TYPE_NAME,
  SOURCE_MEAT_WIP_RECEIPT_REPORT_TYPE_NAME,
  SOURCE_MEAT_WIP_REPORT_TYPE_NAME
} from '../reportingTypes';
import { FinishedPackoffRow } from '../components/FinishedPackoffRow';
import { SourceMeatRow } from '../components/SourceMeatRow';
import { CutSelectionRow } from '../components/CutSelectionRow';
import { SourceWipRow } from '../components/SourceWipRow';
import ReportingTableHeader from '../components/ReportingTableHeader';
import { SourceMeatReceiptRow } from '../components/SourceMeatReceiptRow';

const ReportingTable = ({
  reportingData,
  sortColumn,
  sortDirection,
  handleSort,
  handleDetailsButtonClick
}) => {
  if (_.isNull(reportingData)) {
    return null;
  } else if (_.isEmpty(reportingData)) {
    return (
      <EmptyTableMessage className={'prime-list-empty-message'} message={'No results found'} />
    );
  }

  return (
    <Table sortable>
      <ReportingTableHeader
        sortColumn={sortColumn}
        sortDirection={sortDirection}
        handleSort={handleSort}
      />
      <Table.Body>
        {reportingData.map(reportingEvent => {
          switch (reportingEvent.type) {
            case SOURCE_MEAT_ORDER_REPORT_TYPE_NAME:
              return <SourceMeatRow key={reportingEvent.key} sourceMeat={reportingEvent} />;
            case SOURCE_MEAT_WIP_REPORT_TYPE_NAME:
              return <SourceMeatRow key={reportingEvent.key} sourceMeat={reportingEvent} />;
            case BOX_REPORT_TYPE_NAME:
              return (
                <FinishedPackoffRow
                  key={reportingEvent.key}
                  productActivity={reportingEvent}
                  onClick={handleDetailsButtonClick}
                />
              );
            case CUT_ORDER_SELECTION_REPORT_TYPE_NAME:
              return <CutSelectionRow key={reportingEvent.key} cutOrder={reportingEvent} />;
            case RETURN_BOX_REPORT_TYPE_NAME:
              return (
                <SourceWipRow
                  key={reportingEvent.key}
                  productActivity={reportingEvent}
                  onClick={handleDetailsButtonClick}
                />
              );
            case SOURCE_MEAT_RECEIPT_REPORT_TYPE_NAME:
              return (
                <SourceMeatReceiptRow key={reportingEvent.key} sourceMeatReceipt={reportingEvent} />
              );
            case SOURCE_MEAT_WIP_RECEIPT_REPORT_TYPE_NAME:
              return (
                <SourceMeatReceiptRow key={reportingEvent.key} sourceMeatReceipt={reportingEvent} />
              );
            default:
              return null;
          }
        })}
      </Table.Body>
    </Table>
  );
};

ReportingTable.propTypes = {
  reportingData: PropTypes.arrayOf(PropTypes.object),
  sortColumn: PropTypes.string,
  sortDirection: PropTypes.string,
  handleSort: PropTypes.func.isRequired,
  handleDetailsButtonClick: PropTypes.func.isRequired
};

export default ReportingTable;
