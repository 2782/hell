import React from 'react';
import { mount, shallow } from 'enzyme';
import ProductActivityDetails, {
  f4Behavior,
  ProductActivityDetailsComponent
} from '../ProductActivityDetails';
import { ReportingBoxPackSequence } from '../../../../test-factories/productActivity';
import { PRODUCT_ACTIVITY } from '../../../shared/components/pageTitles';
import { F4 } from '../../../shared/components/pageFooters';
import { Grid, Pagination, Table } from 'semantic-ui-react';
import { Provider } from 'react-redux';
import { createReduxStore } from '../../../store';
import { clearProductActivities } from '../../actions/productActivityActions';
import ProductActivityDetailsHeader from '../../components/ProductActivityDetailsHeader';

jest.mock('../../actions/productActivityActions', () => ({
  clearProductActivities: jest.fn(() => ({ type: 'MOCK_PRODUCT_ACTIVITY_DATA_CLEARED' })),
  getProductActivities: jest.fn(() => ({ type: 'MOCK_PRODUCT_ACTIVITY_DATA_GRABBED' }))
}));

describe('ProductActivityDetails', () => {
  let store, wrapper, detail;

  beforeEach(() => {
    detail = ReportingBoxPackSequence.build();
    store = createReduxStore({
      productActivityDetail: {
        productActivityDetails: [
          ReportingBoxPackSequence.build({ id: 1 }),
          ReportingBoxPackSequence.build({ id: 2 })
        ],
        productActivityDetailCriteria: { quantity: 2, ...detail }
      },
      router: {
        location: {
          pathname: '/product/product-activity'
        }
      }
    });
  });

  describe('Integration', () => {
    test('should mount and pull boxes from store', () => {
      wrapper = mount(
        <Provider store={store}>
          <ProductActivityDetails />
        </Provider>
      );

      jestExpect(wrapper.find('.product-activity-details-page').exists()).toEqual(true);

      jestExpect(
        wrapper
          .find(Table.HeaderCell)
          .at(1)
          .children()
          .text()
      ).toContain('DATE');
      jestExpect(
        wrapper
          .find(Table.HeaderCell)
          .at(2)
          .children()
          .text()
      ).toContain('WEIGHT (LBS)');
      jestExpect(
        wrapper
          .find(Table.Cell)
          .at(3)
          .children()
          .text()
      ).toContain(3);
      jestExpect(
        wrapper
          .find(Table.Cell)
          .at(4)
          .children()
          .text()
      ).toContain('11-12-18 9:47 AM');
      jestExpect(
        wrapper
          .find(Table.Cell)
          .at(5)
          .children()
          .text()
      ).toContain(167.29);
    });

    test('should call clearProductActivities on unmount', () => {
      wrapper = mount(
        <Provider store={store}>
          <ProductActivityDetails />
        </Provider>
      );

      wrapper.unmount();

      jestExpect(clearProductActivities).toHaveBeenCalled();
    });
  });

  describe('Unit', () => {
    test('should call setHeaderAndFooter action upon mounting', () => {
      const setHeaderAndFooter = jest.fn();
      wrapper = shallow(
        <ProductActivityDetailsComponent
          setHeaderAndFooter={setHeaderAndFooter}
          clearProductActivities={() => {}}
          getProductActivities={() => {}}
          boxes={null}
          handleDetailsSort={() => {}}
        />
      );

      jestExpect(setHeaderAndFooter).toHaveBeenCalledWith({
        header: PRODUCT_ACTIVITY,
        footer: F4
      });
    });

    test('should render nothing when no boxes are returned', () => {
      const setHeaderAndFooter = jest.fn();
      wrapper = shallow(
        <ProductActivityDetailsComponent
          setHeaderAndFooter={setHeaderAndFooter}
          clearProductActivities={() => {}}
          getProductActivities={() => {}}
          boxes={null}
          handleDetailsSort={() => {}}
        />
      );

      jestExpect(wrapper.find('.product-activity-details-page').exists()).toEqual(false);
    });

    test('should render nothing when boxes are empty', () => {
      const setHeaderAndFooter = jest.fn();
      wrapper = shallow(
        <ProductActivityDetailsComponent
          setHeaderAndFooter={setHeaderAndFooter}
          clearProductActivities={() => {}}
          getProductActivities={() => {}}
          boxes={[]}
          handleDetailsSort={() => {}}
        />
      );

      jestExpect(wrapper.find('.product-activity-details-page').exists()).toEqual(false);
    });

    test('should render headers when boxes exist', () => {
      const setHeaderAndFooter = jest.fn();
      wrapper = shallow(
        <ProductActivityDetailsComponent
          setHeaderAndFooter={setHeaderAndFooter}
          clearProductActivities={() => {}}
          getProductActivities={() => {}}
          productActivityDetails={[detail]}
          productActivityDetailCriteria={{ quantity: 2, ...detail }}
          handleDetailsSort={() => {}}
        />
      );

      jestExpect(wrapper.find('.product-activity-details-page').exists()).toEqual(true);
      jestExpect(
        wrapper
          .find(Table.HeaderCell)
          .at(1)
          .children()
          .text()
      ).toContain('DATE');
      jestExpect(
        wrapper
          .find(Table.HeaderCell)
          .at(2)
          .children()
          .text()
      ).toContain('WEIGHT (LBS)');
    });

    test('should render table rows with boxes', () => {
      const setHeaderAndFooter = jest.fn();
      wrapper = shallow(
        <ProductActivityDetailsComponent
          setHeaderAndFooter={setHeaderAndFooter}
          clearProductActivities={() => {}}
          getProductActivities={() => {}}
          productActivityDetails={[detail]}
          productActivityDetailCriteria={{ quantity: 2, ...detail }}
          handleDetailsSort={() => {}}
        />
      );

      jestExpect(wrapper.find('.product-activity-details-page').exists()).toEqual(true);
      jestExpect(
        wrapper
          .find(Table.Cell)
          .at(0)
          .children()
          .text()
      ).toContain(3);
      jestExpect(
        wrapper
          .find(Table.Cell)
          .at(1)
          .children()
          .text()
      ).toContain('11-12-18 9:47 AM');
      jestExpect(
        wrapper
          .find(Table.Cell)
          .at(2)
          .children()
          .text()
      ).toContain(167.29);
    });

    test('should render aggregate information for boxes', () => {
      const setHeaderAndFooter = jest.fn();
      wrapper = shallow(
        <ProductActivityDetailsComponent
          setHeaderAndFooter={setHeaderAndFooter}
          clearProductActivities={() => {}}
          getProductActivities={() => {}}
          productActivityDetails={[detail]}
          productActivityDetailCriteria={{ quantity: 2, ...detail }}
          handleDetailsSort={() => {}}
        />
      );

      jestExpect(
        wrapper
          .find(Grid.Column)
          .at(0)
          .children()
          .text()
      ).toContain('PACKOFF');
      jestExpect(
        wrapper
          .find(Grid.Column)
          .at(1)
          .children()
          .text()
      ).toContain(detail.productCode);
      jestExpect(wrapper.find(ProductActivityDetailsHeader).exists()).toEqual(true);
    });
  });

  describe('F4', () => {
    test('should replacePath back to product activity on F4', () => {
      const replacePath = jest.fn();
      const getProductActivities = jest.fn();
      const productActivitySearchCriteria = 'SEARCH_CRITERIA';
      const productActivitiesPage = {
        pageable: {
          pageNumber: 7
        }
      };

      f4Behavior({
        replacePath,
        getProductActivities,
        productActivitySearchCriteria,
        productActivitiesPage
      });

      jestExpect(replacePath).toHaveBeenCalledWith('/product/product-activity');
      jestExpect(getProductActivities).toHaveBeenCalledWith({
        ...productActivitySearchCriteria,
        page: 7
      });
    });
  });

  describe('ProductActivityDetailsHeader', () => {
    test('should show more details for customer boxes', () => {
      wrapper = mount(
        <ProductActivityDetailsHeader
          detail={{
            customerName: 'CUSTOMER_NAME',
            customerCode: 'CUSTOMER_CODE',
            shipDate: '2019-02-28',
            workingDate: '2019-02-27',
            customerOrderNumber: '000123',
            tableDescription: 'BEEF',
            packoffStationName: 'NANCY',
            quantity: 2,
            incomplete: null
          }}
        />
      );

      const contentColumn1 = wrapper
        .find(Grid.Column)
        .children()
        .at(0);
      jestExpect(contentColumn1.text()).toContain('CUSTOMER_NAME');
      jestExpect(contentColumn1.text()).toContain('CUSTOMER_CODE');
      jestExpect(contentColumn1.text()).toContain('Ship Date:');
      jestExpect(contentColumn1.text()).toContain('02-28');
      jestExpect(contentColumn1.text()).toContain('Order #:');
      jestExpect(contentColumn1.text()).toContain('000123');

      const contentColumn2 = wrapper
        .find(Grid.Column)
        .children()
        .at(1);
      jestExpect(contentColumn2.text()).toContain('BEEF');
      jestExpect(contentColumn2.text()).toContain('NANCY');

      jestExpect(
        wrapper
          .find(Grid.Column)
          .children()
          .at(2)
          .text()
      ).toContain('2');
    });

    test('should show fewer details for stock boxes', () => {
      wrapper = mount(
        <ProductActivityDetailsHeader
          detail={{
            customerName: null,
            customerCode: null,
            shipDate: null,
            workingDate: '2019-02-27',
            customerOrderNumber: null,
            tableDescription: 'BEEF',
            packoffStationName: 'NANCY',
            quantity: 2,
            incomplete: false
          }}
        />
      );

      const content = wrapper
        .find(Grid.Column)
        .children()
        .at(0);
      jestExpect(content.text()).toContain('Stock');
      jestExpect(content.text()).toContain('Working Date:');
      jestExpect(content.text()).toContain('02-27');

      jestExpect(
        wrapper
          .find(Grid.Column)
          .children()
          .at(1)
          .text()
      ).toContain('NANCY');

      jestExpect(
        wrapper
          .find(Grid.Column)
          .children()
          .at(2)
          .text()
      ).toContain('2');
    });

    test('should show fewer details for WIP boxes', () => {
      wrapper = mount(
        <ProductActivityDetailsHeader
          detail={{
            customerName: null,
            customerCode: null,
            shipDate: null,
            workingDate: '2019-02-27',
            customerOrderNumber: null,
            tableDescription: 'BEEF',
            packoffStationName: 'NANCY',
            quantity: 2,
            incomplete: true
          }}
        />
      );

      const content = wrapper
        .find(Grid.Column)
        .children()
        .at(0);
      jestExpect(content.text()).toContain('WIP');
      jestExpect(content.text()).toContain('Working Date:');
      jestExpect(content.text()).toContain('02-27');

      jestExpect(
        wrapper
          .find(Grid.Column)
          .children()
          .at(1)
          .text()
      ).toContain('NANCY');

      jestExpect(
        wrapper
          .find(Grid.Column)
          .children()
          .at(2)
          .text()
      ).toContain('2');
    });
  });

  test('should render Pagination component when page object exists', () => {
    const changePage = jest.fn().mockResolvedValue({});
    const setHeaderAndFooter = jest.fn();
    wrapper = shallow(
      <ProductActivityDetailsComponent
        setHeaderAndFooter={setHeaderAndFooter}
        productActivityDetailsChangePage={changePage}
        handleSubmit={() => {}}
        productActivityDetailsPage={{ pageable: { pageNumber: 2 }, totalPages: 11 }}
        clearProductActivities={() => {}}
        getProductActivities={() => {}}
        productActivityDetails={[detail]}
        productActivityDetailCriteria={{ quantity: 2, ...detail }}
        handleDetailsSort={() => {}}
      />
    );
    const getPagination = wrapper.find(Pagination).at(0);

    jestExpect(getPagination.exists()).toEqual(true);
    jestExpect(getPagination.props().activePage).toEqual(3);
    jestExpect(getPagination.props().totalPages).toEqual(11);

    const onPageChange = wrapper
      .find(Pagination)
      .at(0)
      .props().onPageChange;

    onPageChange('EVENT', { activePage: 7 });

    jestExpect(changePage).toHaveBeenCalledWith(6);
  });
});
