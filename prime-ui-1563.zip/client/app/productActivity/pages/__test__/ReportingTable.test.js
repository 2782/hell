import React from 'react';
import { shallow } from 'enzyme';
import ReportingTable from '../ReportingTable';
import EmptyTableMessage from '../../../shared/components/EmptyTableMessage';
import { ProductActivitiesFactory } from '../../../../test-factories/productActivity';
import { SourceMeatRow } from '../../components/SourceMeatRow';
import { FinishedPackoffRow as BoxAggregateRow } from '../../components/FinishedPackoffRow';
import { CutSelectionRow } from '../../components/CutSelectionRow';
import { SourceWipRow } from '../../components/SourceWipRow';
import ReportingTableHeader from '../../components/ReportingTableHeader';

const sourceMeatOrder = ProductActivitiesFactory.build({
  key: 'event-10',
  type: 'SourceMeatOrder',
  timestamp: '2018-09-28T08:00:26.13-05:00',
  productCode: '4102218',
  customerCode: null,
  customerName: null,
  quantity: 11,
  weight: null,
  uom: 'CASE',
  portionRoomCode: 'A',
  stationCode: 90,
  tableCode: null,
  shipDate: null,
  packoffStationName: 'PORCINE'
});

const cutOrderSelection = {
  key: 'event-11',
  type: 'CutOrderSelection',
  timestamp: '2018-10-03T09:39:46.863-05:00',
  productCode: '4102218',
  customerCode: '137851',
  customerName: 'Sysco North Texas',
  quantity: 13,
  weight: null,
  uom: 'CASE',
  portionRoomCode: 'A',
  stationCode: 91,
  tableCode: 91,
  shipDate: '2018-10-02',
  packoffStationName: 'BOVINE'
};

const sourceWipBox = ProductActivitiesFactory.build({
  key: 'returnbox-22',
  type: 'ReturnBox',
  timestamp: '2018-10-02T09:41:46.863-05:00',
  productCode: '1663364',
  customerCode: null,
  customerName: 'WIP',
  quantity: 1,
  weight: 11,
  uom: 'CASE',
  portionRoomCode: 'A',
  stationCode: null,
  tableCode: null,
  shipDate: null,
  packoffStationName: 'FOWL'
});

const customerBox = ProductActivitiesFactory.build({
  customerCode: '245267',
  customerName: 'WILEYS STEAKHOUSE',
  customerOrderNumber: 123987,
  incomplete: false,
  key: 'box-2',
  packoffStationName: 'CERVINE',
  productCode: '4102218',
  quantity: 3,
  roomCode: 'A',
  shipDate: '2018-12-05',
  stationCode: 93,
  stationName: 'MAGGIE',
  status: 'ASSIGNED',
  tableCode: 92,
  tableName: 'DEER',
  timestamp: '2018-09-28T08:00:31.033-05:00',
  type: 'Box',
  uom: 'CASE',
  weight: 575.87,
  workingDate: '2018-09-20'
});

describe('ReportingTable', () => {
  describe('ReportingTable Component', () => {
    test('should show nothing when firstly rendering the page', () => {
      const wrapper = shallow(
        <ReportingTable
          handleCustomerBoxOnClick={() => {}}
          handleFinishedStockWipBoxOnClick={() => {}}
          handleSourceWipBoxOnClick={() => {}}
          reportingData={null}
          handleSort={() => {}}
          handleDetailsButtonClick={() => {}}
        />
      );

      jestExpect(wrapper.find(EmptyTableMessage)).not.toExist();
      jestExpect(wrapper.find(ReportingTableHeader)).not.toExist();
    });

    test('should show standard empty message when no results found', () => {
      const wrapper = shallow(
        <ReportingTable
          handleCustomerBoxOnClick={() => {}}
          handleFinishedStockWipBoxOnClick={() => {}}
          handleSourceWipBoxOnClick={() => {}}
          reportingData={[]}
          handleSort={() => {}}
          handleDetailsButtonClick={() => {}}
        />
      );

      jestExpect(wrapper.find(EmptyTableMessage)).toExist();
      jestExpect(wrapper.find(ReportingTableHeader)).not.toExist();
    });

    test('should show a header when there is data', () => {
      const wrapper = shallow(
        <ReportingTable
          handleSort={() => {}}
          reportingData={[customerBox]}
          handleCustomerBoxOnClick={() => {}}
          handleFinishedStockWipBoxOnClick={() => {}}
          handleSourceWipBoxOnClick={() => {}}
          handleDetailsButtonClick={() => {}}
        />
      );

      jestExpect(wrapper.find(EmptyTableMessage)).not.toExist();
      jestExpect(wrapper.find(ReportingTableHeader)).toExist();
    });

    test('should render SourceMeatRow when entering sourceMeat data', () => {
      const wrapper = shallow(
        <ReportingTable
          reportingData={[sourceMeatOrder]}
          handleSort={() => {}}
          handleCustomerBoxOnClick={() => {}}
          handleFinishedStockWipBoxOnClick={() => {}}
          handleSourceWipBoxOnClick={() => {}}
          handleDetailsButtonClick={() => {}}
        />
      );

      jestExpect(wrapper.find(SourceMeatRow)).toExist();
    });

    test('should render BoxRow when Box data present', () => {
      const wrapper = shallow(
        <ReportingTable
          reportingData={[customerBox]}
          handleSort={() => {}}
          handleCustomerBoxOnClick={() => {}}
          handleFinishedStockWipBoxOnClick={() => {}}
          handleSourceWipBoxOnClick={() => {}}
          handleDetailsButtonClick={() => {}}
        />
      );

      jestExpect(wrapper.find(BoxAggregateRow)).toExist();
    });

    test('should render CutOrderRow when CutOrder data present', () => {
      const wrapper = shallow(
        <ReportingTable
          reportingData={[cutOrderSelection]}
          handleSort={() => {}}
          handleCustomerBoxOnClick={() => {}}
          handleFinishedStockWipBoxOnClick={() => {}}
          handleSourceWipBoxOnClick={() => {}}
          handleDetailsButtonClick={() => {}}
        />
      );

      jestExpect(wrapper.find(CutSelectionRow)).toExist();
    });

    test('should render ReturnBox when ReturnBox data present', () => {
      const wrapper = shallow(
        <ReportingTable
          reportingData={[sourceWipBox]}
          handleSort={() => {}}
          handleCustomerBoxOnClick={() => {}}
          handleFinishedStockWipBoxOnClick={() => {}}
          handleSourceWipBoxOnClick={() => {}}
          handleDetailsButtonClick={() => {}}
        />
      );

      jestExpect(wrapper.find(SourceWipRow)).toExist();
    });

    test('should render ReturnBox when ReturnBox data present', () => {
      const wrapper = shallow(
        <ReportingTable
          reportingData={[sourceWipBox]}
          handleSort={() => {}}
          handleCustomerBoxOnClick={() => {}}
          handleFinishedStockWipBoxOnClick={() => {}}
          handleSourceWipBoxOnClick={() => {}}
          handleDetailsButtonClick={() => {}}
        />
      );

      jestExpect(wrapper.find(SourceWipRow)).toExist();
    });
  });
});
