import React from 'react';
import PropTypes from 'prop-types';
import { Grid } from 'semantic-ui-react';
import { reportingTableHelpers } from '../helpers';

export const isCustomerDetail = detail => {
  const { customerCode, customerName } = detail;

  return customerCode && customerName;
};

const ProductActivityDetailsHeader = ({ detail }) => {
  const {
    customerCode,
    customerName,
    customerOrderNumber,
    tableDescription,
    packoffStationName,
    quantity,
    shipDate,
    workingDate,
    incomplete
  } = detail;

  return isCustomerDetail(detail) ? (
    <Grid.Row>
      <Grid.Column width={6}>
        {customerName} {'\u00A0'} {customerCode} <br />
        {`Ship Date: ${reportingTableHelpers.formatShipDate(shipDate)}`} <br />
        Order #: {customerOrderNumber}
      </Grid.Column>
      <Grid.Column width={6}>
        Location: {tableDescription} {packoffStationName}
      </Grid.Column>
      <Grid.Column width={4} textAlign={'right'} className={'product-activity-details-qty'}>
        Qty: {quantity} CS
      </Grid.Column>
    </Grid.Row>
  ) : (
    <Grid.Row>
      <Grid.Column width={6}>
        {reportingTableHelpers.formatCustomer(incomplete)} <br />
        {`Working Date: ${reportingTableHelpers.formatShipDate(workingDate)}`}
      </Grid.Column>
      <Grid.Column width={6}>Location: {packoffStationName}</Grid.Column>
      <Grid.Column width={4} textAlign={'right'} className={'product-activity-details-qty'}>
        Qty: {quantity} CS
      </Grid.Column>
    </Grid.Row>
  );
};

export default ProductActivityDetailsHeader;

ProductActivityDetailsHeader.propTypes = {
  detail: PropTypes.object.isRequired
};
