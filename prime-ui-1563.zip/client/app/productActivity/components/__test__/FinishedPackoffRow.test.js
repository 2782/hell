import React from 'react';
import { shallow } from 'enzyme/build';
import { Button, Table } from 'semantic-ui-react';
import { ProductActivitiesFactory } from '../../../../test-factories/productActivity';
import { DetailsButton, FinishedPackoffRow } from '../FinishedPackoffRow';
import {
  CUSTOMER_PACKOFF,
  FINISHED_STOCK_WIP_PACKOFF
} from '../../actions/productActivityDetailActions';

const customerBoxAggregate = ProductActivitiesFactory.build({
  key: 'box-3',
  type: 'Box',
  timestamp: '2018-09-28T08:00:31.033-05:00',
  productCode: '2857102',
  quantity: 3,
  weight: 575.87,
  uom: 'CASE',
  customerCode: '245267',
  customerName: 'WILEYS STEAKHOUSE',
  customerOrderNumber: '012',
  status: 'ASSIGNED',
  tableCode: 91,
  tableName: 'BEEF',
  stationCode: 92,
  stationName: 'ALEX',
  roomCode: 'A',
  packoffStationName: 'BRAINS',
  shipDate: '2018-09-27',
  workingDate: '2018-09-28',
  incomplete: false
});

const stockWipBoxAggregate = ProductActivitiesFactory.build({
  key: 'box-3',
  type: 'Box',
  timestamp: '2018-09-28T08:00:31.033-05:00',
  productCode: '2857102',
  quantity: 3,
  weight: 575.87,
  uom: 'CASE',
  customerName: 'Stock',
  customerCode: null,
  customerOrderNumber: null,
  status: 'AVAILABLE',
  tableCode: null,
  tableName: null,
  stationCode: null,
  stationName: null,
  roomCode: 'A',
  packoffStationName: 'BRAINS',
  shipDate: null,
  workingDate: '2018-09-28',
  incomplete: false
});

describe('FinishedPackoffRow', () => {
  test('should show a row correctly for a box aggregate for customer order', () => {
    const wrapper = mount(
      <Table>
        <Table.Body>
          <FinishedPackoffRow productActivity={customerBoxAggregate} onClick={() => {}} />
        </Table.Body>
      </Table>
    );

    const cell = wrapper.find(Table.Cell);
    jestExpect(cell.at(0)).toHaveText('09-28-18 8:00 AM');
    jestExpect(cell.at(1)).toHaveText('Packoff');
    jestExpect(cell.at(3)).toHaveText('WILEYS STEAKHOUSE 245267');
    jestExpect(cell.at(5)).toHaveText(
      customerBoxAggregate.roomCode + customerBoxAggregate.packoffStationName
    );
    jestExpect(cell.at(6).find(DetailsButton)).toExist();
  });

  describe('DetailsButton', () => {
    test('should invoke onClick behavior with customer packoff activity type when button is pressed', () => {
      const onClick = jest.fn();

      const wrapper = shallow(
        <DetailsButton productActivity={customerBoxAggregate} onClick={onClick} />
      );

      wrapper.find(Button).simulate('click');

      jestExpect(onClick.mock.calls[0][0]).toEqual(CUSTOMER_PACKOFF);
    });

    test('should invoke onClick behavior with finished product stock/WIP activity type behavior when button is pressed', () => {
      const onClick = jest.fn();

      const wrapper = shallow(
        <DetailsButton productActivity={stockWipBoxAggregate} onClick={onClick} />
      );

      wrapper.find(Button).simulate('click');

      jestExpect(onClick.mock.calls[0][0]).toEqual(FINISHED_STOCK_WIP_PACKOFF);
    });
  });
});
