import { Table } from 'semantic-ui-react';
import React from 'react';
import { SourceMeatRow } from '../SourceMeatRow';
import { ProductActivitiesFactory } from '../../../../test-factories/productActivity';

describe('SourceMeatRow', () => {
  test('should render SourceMeatOrder row properly', () => {
    const sourceMeatOrderData = ProductActivitiesFactory.build({
      key: 'event-28',
      type: 'SourceMeatOrder',
      timestamp: '2018-09-28T08:00:26.13-05:00',
      productCode: '4102218',
      customerCode: null,
      customerName: null,
      quantity: 11,
      weight: null,
      uom: 'CASE',
      roomCode: 'A',
      stationName: 'ALEX',
      tableName: null,
      shipDate: null
    });
    const wrapper = mount(
      <Table>
        <Table.Body>
          <SourceMeatRow sourceMeat={sourceMeatOrderData} />
        </Table.Body>
      </Table>
    );
    jestExpect(wrapper.find(Table.Cell).at(0)).toHaveText('09-28-18 8:00 AM');
    jestExpect(wrapper.find(Table.Cell).at(1)).toHaveText('Request Meat');
    jestExpect(wrapper.find(Table.Cell).at(2)).toHaveText('11 CS');
    jestExpect(wrapper.find(Table.Cell).at(5)).toIncludeText(sourceMeatOrderData.roomCode);
    jestExpect(wrapper.find(Table.Cell).at(5)).toIncludeText(sourceMeatOrderData.stationName);
  });

  test('should render source meat wip row with customer name', () => {
    const sourceMeatOrderData = ProductActivitiesFactory.build({
      key: 'event-28',
      type: 'SourceMeatWip',
      timestamp: '2018-09-28T08:00:26.13-05:00',
      productCode: '4102218',
      customerCode: null,
      customerName: 'WIP',
      quantity: 1,
      weight: 11,
      uom: 'CASE',
      roomCode: 'A',
      stationName: 'ALEX',
      tableName: null,
      shipDate: null
    });
    const wrapper = mount(
      <Table>
        <Table.Body>
          <SourceMeatRow sourceMeat={sourceMeatOrderData} />
        </Table.Body>
      </Table>
    );
    jestExpect(wrapper.find(Table.Cell).at(0)).toHaveText('09-28-18 8:00 AM');
    jestExpect(wrapper.find(Table.Cell).at(1)).toHaveText('Request Meat');
    jestExpect(wrapper.find(Table.Cell).at(2)).toHaveText('11 LB');
    jestExpect(wrapper.find(Table.Cell).at(3)).toHaveText('WIP');
    jestExpect(wrapper.find(Table.Cell).at(5)).toIncludeText(sourceMeatOrderData.roomCode);
    jestExpect(wrapper.find(Table.Cell).at(5)).toIncludeText(sourceMeatOrderData.stationName);
  });
});
