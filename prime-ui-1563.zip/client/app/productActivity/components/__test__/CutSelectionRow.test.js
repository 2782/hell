import { Table } from 'semantic-ui-react';
import { CutSelectionRow } from '../CutSelectionRow';
import React from 'react';
import { ProductActivitiesFactory } from '../../../../test-factories/productActivity';

describe('ReportingCutOrderRow', () => {
  test('should render Cut Selection Event Row', () => {
    const cutSelectionData = ProductActivitiesFactory.build({
      key: 'event-11',
      type: 'CutOrderSelection',
      timestamp: '2018-10-03T09:39:46.863-05:00',
      productCode: '4102218',
      customerCode: '137851',
      customerName: 'Sysco North Texas',
      quantity: 13,
      weight: null,
      uom: 'CASE',
      portionRoomCode: 'A',
      stationName: 'ALEX',
      tableName: 'BEEF',
      shipDate: '2018-10-02'
    });

    const wrapper = mount(
      <Table>
        <Table.Body>
          <CutSelectionRow cutOrder={cutSelectionData} />
        </Table.Body>
      </Table>
    );

    jestExpect(wrapper.find(Table.Cell).at(0)).toHaveText('10-03-18 9:39 AM');
    jestExpect(wrapper.find(Table.Cell).at(1)).toHaveText('Cut Selection');
    jestExpect(wrapper.find(Table.Cell).at(2)).toHaveText('13 CS');
    jestExpect(wrapper.find(Table.Cell).at(3)).toHaveText('Sysco North Texas 137851');
    jestExpect(wrapper.find(Table.Cell).at(4)).toHaveText('10-02');
    jestExpect(wrapper.find(Table.Cell).at(5)).toIncludeText(cutSelectionData.stationName);
    jestExpect(wrapper.find(Table.Cell).at(5)).toIncludeText(cutSelectionData.tableName);
  });

  test('should render nothing for customer par order', () => {
    const cutSelectionData = {
      key: 'event-11',
      type: 'CutOrderSelection',
      timestamp: '2018-10-03T09:39:46.863-05:00',
      productCode: '4102218',
      customerCode: null,
      customerName: null,
      quantity: 17,
      weight: null,
      uom: 'CASE',
      portionRoomCode: 'A',
      stationName: 'ALEX',
      tableName: 'BEEF',
      shipDate: '2018-10-02',
      produceDate: null
    };

    const wrapper = mount(
      <Table>
        <Table.Body>
          <CutSelectionRow cutOrder={cutSelectionData} />
        </Table.Body>
      </Table>
    );

    jestExpect(wrapper.find(Table.Cell).at(0)).toHaveText('10-03-18 9:39 AM');
    jestExpect(wrapper.find(Table.Cell).at(1)).toHaveText('Cut Selection');
    jestExpect(wrapper.find(Table.Cell).at(2)).toHaveText('17 CS');
    jestExpect(wrapper.find(Table.Cell).at(4)).toHaveText('10-02');
    jestExpect(wrapper.find(Table.Cell).at(5)).toIncludeText(cutSelectionData.stationName);
    jestExpect(wrapper.find(Table.Cell).at(5)).toIncludeText(cutSelectionData.tableName);
  });
});
