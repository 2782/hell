import { validateSubmission } from '../productActivityValidator';

describe('productActivityValidator', () => {
  test('should not throw submission error when values are valid', () => {
    const values = {
      productCode: '4102218',
      startDate: '10-07-2018',
      endDate: '10-08-2018'
    };

    validateSubmission(values);
  });

  test('should throw submission error when start date is invalid', () => {
    try {
      const values = {
        productCode: '4102218',
        startDate: '2018-10-09',
        endDate: '10-08-2018'
      };

      validateSubmission(values);
    } catch ({ errors }) {
      jestExpect(errors).toEqual({
        startDate: 'Invalid date format',
        _error: 'Invalid search criteria'
      });
    }
  });

  test('should throw submission error when end date is invalid', () => {
    try {
      const values = {
        productCode: '4102218',
        startDate: '10-09-2018',
        endDate: '2018-10-08'
      };

      validateSubmission(values);
    } catch ({ errors }) {
      jestExpect(errors).toEqual({
        endDate: 'Invalid date format',
        _error: 'Invalid search criteria'
      });
    }
  });

  test('should throw submission error when start and end dates are invalid', () => {
    try {
      const values = {
        productCode: '4102218',
        startDate: '2018-10-09',
        endDate: '2018-10-08'
      };

      validateSubmission(values);
    } catch ({ errors }) {
      jestExpect(errors).toEqual({
        startDate: 'Invalid date format',
        endDate: 'Invalid date format',
        _error: 'Invalid search criteria'
      });
    }
  });

  test('should throw submission error when end date before start date', () => {
    try {
      const values = {
        productCode: '4102218',
        startDate: '10-09-2018',
        endDate: '10-08-2018'
      };

      validateSubmission(values);
    } catch ({ errors }) {
      jestExpect(errors).toEqual({
        endDate: 'Must be after start date',
        _error: 'Invalid search criteria'
      });
    }
  });

  test('should throw submission error  when productCode is empty', () => {
    try {
      const values = {
        productCode: '',
        startDate: '10-07-2018',
        endDate: '10-08-2018'
      };

      validateSubmission(values);
    } catch ({ errors }) {
      jestExpect(errors).toEqual({
        productCode: 'Please enter a product code',
        _error: 'Invalid search criteria'
      });
    }
  });
});
