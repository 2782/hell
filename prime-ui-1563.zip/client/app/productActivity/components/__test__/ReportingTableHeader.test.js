import React from 'react';
import { Table } from 'semantic-ui-react';
import ReportingTableHeader from '../ReportingTableHeader';

function findHeaderByText(wrapper, text) {
  return wrapper.find(`[children="${text}"]`).at(0);
}

describe('ReportingTableHeader rendering', () => {
  let wrapper, handleSort;
  beforeEach(() => {
    handleSort = jest.fn();

    wrapper = mount(
      <Table>
        <ReportingTableHeader handleSort={handleSort} handleBoxOnClick={() => {}} />
      </Table>
    );
  });
  test('should show header text in correctly order', () => {
    jestExpect(wrapper.find(Table.HeaderCell).at(0)).toHaveText('DATE');
    jestExpect(wrapper.find(Table.HeaderCell).at(1)).toHaveText('TYPE');
    jestExpect(wrapper.find(Table.HeaderCell).at(2)).toHaveText('QTY');
    jestExpect(wrapper.find(Table.HeaderCell).at(3)).toHaveText('CUSTOMER');
    jestExpect(wrapper.find(Table.HeaderCell).at(4)).toHaveText('SHIP DATE');
    jestExpect(wrapper.find(Table.HeaderCell).at(5)).toHaveText('LOCATION');
  });

  test("should call handle sort on 'timestamp' when click header", () => {
    findHeaderByText(wrapper, 'DATE').simulate('click');
    jestExpect(handleSort).toHaveBeenCalledWith('timestamp');
  });

  test("should call handle sort on 'type' when click header", () => {
    findHeaderByText(wrapper, 'TYPE').simulate('click');
    jestExpect(handleSort).toHaveBeenCalledWith('type');
  });

  test("should call handle sort on 'quantity' when click header", () => {
    findHeaderByText(wrapper, 'QTY').simulate('click');
    jestExpect(handleSort).toHaveBeenCalledWith('quantity,weight');
  });

  test("should call handle sort on 'customer' when click header", () => {
    findHeaderByText(wrapper, 'CUSTOMER').simulate('click');
    jestExpect(handleSort).toHaveBeenCalledWith('customerName');
  });

  test("should call handle sort on 'shipDate' when click header", () => {
    findHeaderByText(wrapper, 'SHIP DATE').simulate('click');
    jestExpect(handleSort).toHaveBeenCalledWith('shipDate');
  });

  test("should call handle sort on 'location' when click header", () => {
    findHeaderByText(wrapper, 'LOCATION').simulate('click');
    jestExpect(handleSort).toHaveBeenCalledWith('stationCode,tableCode');
  });
});
