import React from 'react';
import { Table } from 'semantic-ui-react';
import { formatType, reportingTableHelpers } from '../helpers';
import PropTypes from 'prop-types';

export const CutSelectionRow = ({ cutOrder }) => (
  <Table.Row pid={`productActivity__row-${cutOrder.key}`}>
    <Table.Cell pid={'productActivity__timestamp'}>
      {reportingTableHelpers.formatProduceDate(cutOrder.timestamp)}
    </Table.Cell>
    <Table.Cell width={3} pid={'productActivity__type'}>
      {formatType(cutOrder.type)}
    </Table.Cell>
    <Table.Cell pid={'productActivity__quantity'}>{`${
      cutOrder.quantity
    } ${reportingTableHelpers.formatUnitOfMeasure(cutOrder.uom)}`}</Table.Cell>
    <Table.Cell width={3} pid={'productActivity__customerName'}>
      {cutOrder.customerName && cutOrder.customerCode
        ? `${cutOrder.customerName} ${cutOrder.customerCode}`
        : null}
    </Table.Cell>
    <Table.Cell collapsing textAlign={'right'} pid={'productActivity__shipDate'}>
      {reportingTableHelpers.formatShipDate(cutOrder.shipDate)}
    </Table.Cell>
    <Table.Cell width={1} pid={'productActivity__location'}>
      <div>
        {cutOrder.roomCode}
        <br />
        {cutOrder.stationName}
        <br />
        {cutOrder.tableName}
      </div>
    </Table.Cell>
    <Table.Cell width={1} />
  </Table.Row>
);

CutSelectionRow.propTypes = {
  cutOrder: PropTypes.object.isRequired
};
