import { Table } from 'semantic-ui-react';
import PropTypes from 'prop-types';
import React from 'react';
import { formatType, reportingTableHelpers } from '../helpers';
import { SOURCE_MEAT_WIP_RECEIPT_REPORT_TYPE_NAME } from '../reportingTypes';

export const SourceMeatReceiptRow = ({ sourceMeatReceipt }) => (
  <Table.Row pid={`productActivity__row-${SourceMeatReceiptRow.key}`}>
    <Table.Cell pid={'productActivity__timestamp'}>
      {reportingTableHelpers.formatProduceDate(sourceMeatReceipt.timestamp)}
    </Table.Cell>
    <Table.Cell pid={'productActivity__type'}>{formatType(sourceMeatReceipt.type)}</Table.Cell>
    <Table.Cell pid={'productActivity__quantity'}>
      {sourceMeatReceipt.type == SOURCE_MEAT_WIP_RECEIPT_REPORT_TYPE_NAME
        ? `${sourceMeatReceipt.weight} LB`
        : `${sourceMeatReceipt.quantity} ${reportingTableHelpers.formatUnitOfMeasure(
            sourceMeatReceipt.uom
          )}`}
    </Table.Cell>
    <Table.Cell width={3} pid={'productActivity__customerName'}>
      {sourceMeatReceipt.customerName ? `${sourceMeatReceipt.customerName}` : null}
    </Table.Cell>
    <Table.Cell pid={'productActivity__shipDate'} />
    <Table.Cell width={1} pid={'productActivity__location'}>
      <div>
        {sourceMeatReceipt.roomCode}
        <br />
        {sourceMeatReceipt.stationName}
      </div>
    </Table.Cell>
    <Table.Cell width={1} />
  </Table.Row>
);

SourceMeatReceiptRow.propTypes = {
  sourceMeatReceipt: PropTypes.object.isRequired
};
