import reportingResources from '../../shared/api/reportingResources';
import {
  PRODUCT_ACTIVITIES_FETCHED,
  PRODUCT_ACTIVITY_CLEARED,
  PRODUCT_ACTIVITY_SEARCH_CRITERIA_SAVED,
  ACTIVITIES_SORTED_BY_COLUMN
} from './productActivityActionTypes';
import { calculateSort } from '../../shared/util/sortUtil';
import { displayDateToIsoDate, isoDateToDisplayDate } from '../../shared/util/dateUtil';

export const clearProductActivities = () => (dispatch, getState) => {
  const {
    location: { pathname }
  } = getState().router;
  if (
    pathname !== '/product/product-activity' &&
    pathname !== '/product/product-activity/details'
  ) {
    dispatch({
      type: PRODUCT_ACTIVITY_CLEARED
    });
  }
};

export const fetchProductActivities = response => ({
  type: PRODUCT_ACTIVITIES_FETCHED,
  payload: response.data
});

export const handleActivitiesSort = columnToSort => (dispatch, getState) => {
  const {
    productCode,
    startDate,
    endDate
  } = getState().productActivity.productActivitySearchCriteria;
  return getProductActivities({
    productCode,
    startDate,
    endDate,
    columnToSort
  })(dispatch, getState);
};

export const productActivitiesChangePage = changeToPage => (dispatch, getState) => {
  const {
    productCode,
    startDate,
    endDate
  } = getState().productActivity.productActivitySearchCriteria;
  return getProductActivities({ productCode, startDate, endDate, page: changeToPage })(
    dispatch,
    getState
  );
};

export const saveProductActivitySearchCriteria = searchCriteria => ({
  type: PRODUCT_ACTIVITY_SEARCH_CRITERIA_SAVED,
  payload: searchCriteria
});

export const getProductActivities = ({
  productCode,
  startDate,
  endDate,
  page = 0,
  columnToSort = null
}) => (dispatch, getState) => {
  const {
    productActivitiesSortColumn,
    productActivitiesSortDirection
  } = getState().productActivity;
  const { sortColumn, sortDirection } = calculateSort(
    columnToSort,
    productActivitiesSortColumn,
    productActivitiesSortDirection
  );

  startDate = displayDateToIsoDate(startDate);
  endDate = displayDateToIsoDate(endDate);

  return reportingResources
    .getProductActivities({
      productCode,
      startDate,
      endDate,
      page,
      sortColumn,
      sortDirection
    })
    .then(response => {
      dispatch({
        type: ACTIVITIES_SORTED_BY_COLUMN,
        payload: {
          productActivitiesSortColumn: sortColumn,
          productActivitiesSortDirection: sortDirection
        }
      });

      startDate = isoDateToDisplayDate(startDate);
      endDate = isoDateToDisplayDate(endDate);
      dispatch(saveProductActivitySearchCriteria({ productCode, startDate, endDate }));
      dispatch(fetchProductActivities(response));
    });
};
