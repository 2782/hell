import {
  clearProductActivities,
  getProductActivities,
  handleActivitiesSort,
  productActivitiesChangePage
} from '../productActivityActions';
import {
  ACTIVITIES_SORTED_BY_COLUMN,
  PRODUCT_ACTIVITIES_FETCHED,
  PRODUCT_ACTIVITY_CLEARED,
  PRODUCT_ACTIVITY_SEARCH_CRITERIA_SAVED
} from '../productActivityActionTypes';
import reportingResources from '../../../shared/api/reportingResources';

jest.mock('../../../shared/api/reportingResources', () => ({
  getCustomerBoxes: jest.fn(),
  getProductActivities: jest.fn(),
  getStockWipBoxesForFinished: jest.fn(),
  getWipBoxesForSource: jest.fn()
}));

describe('ProductActivityActions', () => {
  let dispatch;

  beforeEach(() => {
    dispatch = jest.fn();
  });

  afterEach(() => {
    reportingResources.getCustomerBoxes.mockReset();
    reportingResources.getProductActivities.mockReset();
    reportingResources.getStockWipBoxesForFinished.mockReset();
    reportingResources.getWipBoxesForSource.mockReset();
    dispatch.mockReset();
  });

  describe('PRODUCT_ACTIVITY_DATA_GRABBED', () => {
    test('should populate state with product activity', () => {
      const getState = () => ({
        productActivity: {
          productActivitiesSortColumn: 'quantity',
          productActivitiesSortDirection: 'asc'
        }
      });

      reportingResources.getProductActivities.mockResolvedValue({
        data: 'DATA'
      });

      const values = {
        productCode: '4102218',
        startDate: '11-14-2018',
        endDate: '11-14-2018'
      };

      return getProductActivities(values)(dispatch, getState).then(() => {
        jestExpect(dispatch).toHaveBeenCalledWith({
          type: ACTIVITIES_SORTED_BY_COLUMN,
          payload: {
            productActivitiesSortColumn: 'quantity',
            productActivitiesSortDirection: 'asc'
          }
        });
        jestExpect(dispatch).toHaveBeenCalledWith({
          type: PRODUCT_ACTIVITY_SEARCH_CRITERIA_SAVED,
          payload: values
        });

        jestExpect(dispatch).toHaveBeenCalledWith({
          type: PRODUCT_ACTIVITIES_FETCHED,
          payload: 'DATA'
        });
      });
    });

    test('should change page by calling product activities', () => {
      reportingResources.getProductActivities.mockResolvedValue({
        data: 'DATA'
      });

      const productActivitySearchCriteria = {
        productCode: '4102218',
        startDate: '11-14-2018',
        endDate: '11-14-2018'
      };

      const getState = () => ({
        productActivity: {
          productActivitySearchCriteria,
          productActivitiesSortColumn: 'shipDate',
          productActivitiesSortDirection: 'desc'
        }
      });

      return productActivitiesChangePage(32)(dispatch, getState).then(() => {
        jestExpect(reportingResources.getProductActivities).toHaveBeenCalledWith({
          productCode: '4102218',
          startDate: '2018-11-14',
          endDate: '2018-11-14',
          page: 32,
          sortColumn: 'shipDate',
          sortDirection: 'desc'
        });
      });
    });

    test('should handle sort when calling product activities', () => {
      reportingResources.getProductActivities.mockResolvedValue({
        data: 'DATA'
      });

      const getState = () => ({
        productActivity: {
          productActivitySearchCriteria: {
            productCode: '2111148',
            startDate: '01-01-2018',
            endDate: '01-01-2018'
          },
          productActivitiesSortColumn: 'EXISTING_SORT_COLUMN',
          productActivitiesSortDirection: 'asc'
        }
      });

      return handleActivitiesSort('type')(dispatch, getState).then(() => {
        jestExpect(reportingResources.getProductActivities).toHaveBeenCalledWith({
          productCode: '2111148',
          page: 0,
          startDate: '2018-01-01',
          endDate: '2018-01-01',
          sortColumn: 'type',
          sortDirection: 'asc'
        });
        jestExpect(dispatch).toHaveBeenCalledWith({
          type: ACTIVITIES_SORTED_BY_COLUMN,
          payload: {
            productActivitiesSortColumn: 'type',
            productActivitiesSortDirection: 'asc'
          }
        });
      });
    });
  });

  describe('PRODUCT_ACTIVITY_CLEARED', () => {
    test('should clear when pathname is not product activity or details', () => {
      const getState = () => ({
        router: { location: { pathname: '/other/pathname' } }
      });

      clearProductActivities()(dispatch, getState);

      jestExpect(dispatch).toHaveBeenCalledWith({
        type: PRODUCT_ACTIVITY_CLEARED
      });
    });

    test('should not clear when pathname is product activity details', () => {
      const getState = () => ({
        router: { location: { pathname: '/product/product-activity/details' } }
      });

      clearProductActivities()(dispatch, getState);

      jestExpect(dispatch).not.toHaveBeenCalledWith({
        type: PRODUCT_ACTIVITY_CLEARED
      });
    });

    test('should not clear when pathname is product activity', () => {
      const getState = () => ({
        router: { location: { pathname: '/product/product-activity' } }
      });

      clearProductActivities()(dispatch, getState);

      jestExpect(dispatch).not.toHaveBeenCalledWith({
        type: PRODUCT_ACTIVITY_CLEARED
      });
    });
  });
});
