import _ from 'lodash';
import grindOrdersResources from '../../shared/api/grindOrdersResources';
import batchResources from '../../shared/api/batchResources';
import {
  GRINDING_ORDERS_APPROVED,
  GRINDING_ORDERS_GRABBED,
  EDIT_QUANTITY_STOPPED,
  EDIT_QUANTITY_STARTED,
  STOCK_ALLOCATION_ALERT,
  GRINDING_ORDERS_NOT_APPROVED,
  UPDATE_GRINDING_ORDER_QUANTITY
} from './grindActionTypes';
import { UPDATE_BATCHES } from '../../batch/actions/batchActionTypes';
import moment from 'moment';
import portionRoomsResources from '../../shared/api/portionRoomsResources';
import { DEFAULT_DISPLAY_DATE_FORMAT } from '../../shared/util/dateUtil';

const mapToBlendNames = grindOrders => {
  return _.uniq(
    _.map(grindOrders, order => {
      return order.blend;
    })
  );
};

export const getGrindOrders = () => {
  return getGrindOrdersWithCallBack(() => {});
};

const getGrindOrdersWithCallBack = callback => {
  return (dispatch, getState) => {
    const { portionRooms, currentPortionRoom } = getState().portionRoomsInfo;
    const roomCode = currentPortionRoom.code;
    const openedAt = moment(
      new Date(_.get(_.find(portionRooms, { code: currentPortionRoom.code }), 'lastOpenedAt'))
    );

    grindOrdersResources.getGrindOrders(roomCode, response => {
      let grindOrders = response.data;
      dispatch({
        type: GRINDING_ORDERS_GRABBED,
        payload: grindOrders
      });

      callback(
        mapToBlendNames(grindOrders),
        openedAt.format(DEFAULT_DISPLAY_DATE_FORMAT),
        dispatch
      );
    });
  };
};

export const getGrindOrdersWithBatches = () => {
  const batchCallback = (blends, produceDate, dispatch) => {
    const blendSet = buildBlendNameSet(blends);
    batchResources.getBatchesByBlendNames(blendSet, produceDate, response => {
      dispatch({
        type: UPDATE_BATCHES,
        payload: response.data
      });
    });
  };

  return getGrindOrdersWithCallBack(batchCallback);
};

const buildBlendNameSet = blends => {
  let blendNames = [];
  blends.map(blend => blendNames.push(blend.name));
  return _.uniq(blendNames);
};

export const editQuantity = selectedGrindOrder => dispatch => {
  dispatch({
    type: EDIT_QUANTITY_STARTED,
    payload: selectedGrindOrder
  });
};

export const stopEditingQuantity = () => dispatch => {
  dispatch({ type: EDIT_QUANTITY_STOPPED });
};

export const updateGrindOrder = updatedGrindOrder => dispatch => {
  grindOrdersResources.updateGrindOrder(updatedGrindOrder, () => {
    dispatch({ type: EDIT_QUANTITY_STOPPED });
    dispatch({ type: UPDATE_GRINDING_ORDER_QUANTITY, payload: updatedGrindOrder });
  });
};

export const approveGrindOrders = () => (dispatch, getState) => {
  const roomCode = getState().portionRoomsInfo.currentPortionRoom.code;

  dispatch({
    type: GRINDING_ORDERS_APPROVED
  });

  return grindOrdersResources
    .approveGrindOrders(roomCode)
    .then()
    .catch(() => {
      dispatch({
        type: GRINDING_ORDERS_NOT_APPROVED
      });
    });
};

export const getStockAllocationAlert = roomCode => dispatch => {
  return portionRoomsResources.getStockAllocationAlert(roomCode).then(response => {
    const stockAllocationAlert = response.data;

    dispatch({
      type: STOCK_ALLOCATION_ALERT,
      payload: stockAllocationAlert
    });

    if (stockAllocationAlert) {
      dispatch({
        type: 'ERROR',
        payload: 'STOCK_ALLOCATION_ALERT'
      });
    }
  });
};
