import React from 'react';
import PropTypes from 'prop-types';
import _ from 'lodash';
import { Button } from 'semantic-ui-react';
import { PortionRoomState } from '../../landingPage/reducers/portionRoomReducer';

export const ApproveButton = ({
  grindOrdersInfo,
  submitting,
  isGrindingRoom,
  portionRoomState
}) => {
  if (
    !isGrindingRoom ||
    _.isEmpty(grindOrdersInfo) ||
    grindOrdersInfo.filter(order => order.qtyInBoxes > 0).length === 0
  ) {
    return null;
  }

  const disabled = portionRoomState !== PortionRoomState.CAN_APPROVE;

  return (
    <Button primary size='large' loading={submitting} disabled={disabled}>
      Approve
    </Button>
  );
};

ApproveButton.propTypes = {
  grindOrdersInfo: PropTypes.array,
  isGrindingRoom: PropTypes.bool,
  submitting: PropTypes.bool,
  portionRoomState: PropTypes.number
};
