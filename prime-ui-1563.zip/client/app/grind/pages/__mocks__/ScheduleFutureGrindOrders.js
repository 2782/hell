import React from 'react';

class ScheduleFutureGrindOrders extends React.Component {
  render() {
    return <div> Fake ScheduleFutureOrders </div>;
  }
}

export default ScheduleFutureGrindOrders;
