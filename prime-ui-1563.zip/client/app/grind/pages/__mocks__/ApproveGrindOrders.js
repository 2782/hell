import React from 'react';

class ApproveGrindOrders extends React.Component {
  render() {
    return <div> Fake ApproveGrindOrders </div>;
  }
}

export default ApproveGrindOrders;
