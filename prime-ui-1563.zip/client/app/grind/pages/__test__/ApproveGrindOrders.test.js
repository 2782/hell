import React from 'react';
import { mount, shallow } from 'enzyme';
import ApproveGrindOrders, {
  ApproveGrindOrdersComponent,
  calculateTotalPounds,
  mapStateToProps,
  sortBySpecialBlend
} from '../ApproveGrindOrders';
import { GRIND_ORDERS } from '../../../shared/components/pageTitles';
import { TAB_SHIFTTAB_F4_F2 } from '../../../shared/components/pageFooters';
import { Provider } from 'react-redux';
import { createReduxStore } from '../../../store';
import { Table } from 'semantic-ui-react';
import EmptyListMessage from '../../../shared/components/EmptyListMessage';
import { PortionRoomState } from '../../../landingPage/reducers/portionRoomReducer';
import { Field } from 'redux-form';
import GrindOrderFactory, {
  GRIND_ORDER_WITH_NO_QTY_IN_BOXES,
  GRIND_ORDER_WITH_SAME_BLEND_AND_DIFFERENT_SHIP_DATE,
  GRIND_WITH_NOLAN_75_25_GRIND
} from '../../../../test-factories/grindingOrderFactory';
import grindOrderValidator from '../../components/grindOrderValidator';

describe('ApproveGrindOrders', () => {
  describe('calculations', () => {
    test('should calculate weight using weightPerBox when unit of measure is pieces', () => {
      const grindOrderTestData = [
        {
          blend: 'Natural',
          source: 'LINE_ITEM',
          unitOfMeasure: 'PIECE',
          product: {
            productPortionSize: {
              portionSize: {
                unitOfWeight: 'OZ',
                value: 8
              },
              piecesPerCase: 20
            },
            weightPerBox: 10
          },
          qtyToProduce: 50,
          qtyPacked: 0,
          qtyInBoxes: 3,
          status: 'TO_GRIND'
        }
      ];

      const result = calculateTotalPounds(grindOrderTestData);

      jestExpect(result).toEqual(30);
    });

    test('should calculate pounds correctly when unit of measure is cases', () => {
      const grindOrderTestData = [
        {
          blend: 'Natural',
          source: 'LINE_ITEM',
          unitOfMeasure: 'CASE',
          product: {
            productPortionSize: {
              portionSize: {
                unitOfWeight: 'OZ',
                value: 8
              },
              piecesPerCase: 20
            },
            weightPerBox: 10.11
          },
          piecesPerCase: 20,
          qtyToProduce: 9,
          qtyInBoxes: 9,
          qtyPacked: 0
        }
      ];

      const result = calculateTotalPounds(grindOrderTestData);

      jestExpect(result).toEqual(91);
    });

    test('should calculate', () => {
      const grindOrders = [
        {
          blend: 'Natural',
          source: 'LINE_ITEM',
          unitOfMeasure: 'PIECE',
          product: {
            productPortionSize: {
              portionSize: {
                unitOfWeight: 'OZ',
                value: 8
              },
              piecesPerCase: 20
            },
            weightPerBox: 10
          },
          qtyToProduce: 50,
          qtyPacked: 0,
          qtyInBoxes: 3,
          status: 'TO_GRIND'
        },
        {
          blend: 'Natural',
          source: 'LINE_ITEM',
          unitOfMeasure: 'CASE',
          product: {
            productPortionSize: {
              portionSize: {
                unitOfWeight: 'OZ',
                value: 8
              },
              piecesPerCase: 20
            },
            weightPerBox: 10
          },
          piecesPerCase: 20,
          qtyToProduce: 9,
          qtyInBoxes: 9,
          qtyPacked: 0
        }
      ];

      const result = calculateTotalPounds(grindOrders);

      jestExpect(result).toEqual(120);
    });
  });

  describe('mount component', () => {
    let grindOrders;

    beforeEach(() => {
      grindOrders = [
        GrindOrderFactory.build(),
        GRIND_ORDER_WITH_SAME_BLEND_AND_DIFFERENT_SHIP_DATE,
        GRIND_WITH_NOLAN_75_25_GRIND
      ];
    });

    test('grabs orders from the API', () => {
      const getGrindOrdersSpy = jest.fn();
      const changePathSpy = jest.fn();
      const setHeaderAndFooterSpy = jest.fn();

      const form = new ApproveGrindOrdersComponent({
        getGrindOrders: getGrindOrdersSpy,
        setHeaderAndFooter: setHeaderAndFooterSpy,
        changePath: changePathSpy
      });

      form.componentDidMount();

      jestExpect(getGrindOrdersSpy).toBeCalled();
      jestExpect(setHeaderAndFooterSpy).toBeCalledWith({
        header: GRIND_ORDERS,
        footer: TAB_SHIFTTAB_F4_F2
      });
    });

    test('shows the empty list message when there are no rows', () => {
      const store = createReduxStore({
        grindOrdersInfo: {
          grindOrdersInfo: []
        }
      });

      const wrapper = mount(
        <Provider store={store}>
          <ApproveGrindOrders />
        </Provider>
      );

      jestExpect(wrapper.find(EmptyListMessage)).toExist();
    });

    test('shows the empty list message when there are no qtyInBoxes', () => {
      const store = createReduxStore({
        grindOrdersInfo: {
          grindOrdersInfo: [GRIND_ORDER_WITH_NO_QTY_IN_BOXES]
        }
      });

      const wrapper = mount(
        <Provider store={store}>
          <ApproveGrindOrders />
        </Provider>
      );

      jestExpect(wrapper.find(EmptyListMessage)).toExist();
    });

    test('shows a summary by blend row sorted by blend name', () => {
      const store = createReduxStore({
        grindOrdersInfo: {
          grindOrdersInfo: grindOrders
        }
      });

      const wrapper = mount(
        <Provider store={store}>
          <ApproveGrindOrders />
        </Provider>
      );

      const cells = wrapper
        .find(Table.Row)
        .at(1)
        .find(Table.Cell);
      jestExpect(cells.at(0)).toHaveText('Nolan - Trim 75/25');
      jestExpect(cells.at(1)).toHaveText('');
      jestExpect(cells.at(2)).toHaveText('');
      jestExpect(cells.at(3)).toHaveText('20 lbs');

      const NaturalCell = wrapper
        .find(Table.Row)
        .at(3)
        .find(Table.Cell);
      jestExpect(NaturalCell.at(0)).toHaveText('Natural');
      jestExpect(NaturalCell.at(1)).toHaveText('');
      jestExpect(NaturalCell.at(2)).toHaveText('');
      jestExpect(NaturalCell.at(3)).toHaveText('50 lbs');
    });

    test('shows a grind order row with edit button', () => {
      const store = createReduxStore({
        grindOrdersInfo: {
          grindOrdersInfo: grindOrders
        }
      });

      const wrapper = mount(
        <Provider store={store}>
          <ApproveGrindOrders />
        </Provider>
      );

      const cells = wrapper
        .find(Table.Row)
        .at(2)
        .find(Table.Cell);
      jestExpect(cells.at(0)).toHaveText('0012446 / 8.0 OZBF GRND PTY 90 FRSH GF');
      jestExpect(cells.at(1)).toHaveText('TIM HUSSMAN-CASH ACCOUNT956186');
      jestExpect(cells.at(2)).toHaveText('07-18');
      jestExpect(cells.at(3)).toHaveText('2');
      jestExpect(cells.find('a').find('i')).toHaveClassName('icon-edit');
    });

    test('only shows grind orders with qtyInBoxes greater than zero', () => {
      const grindOrdersWithEmptyOrder = grindOrders.concat(GRIND_ORDER_WITH_NO_QTY_IN_BOXES);
      const store = createReduxStore({
        grindOrdersInfo: {
          grindOrdersInfo: grindOrdersWithEmptyOrder
        }
      });

      const wrapper = mount(
        <Provider store={store}>
          <ApproveGrindOrders />
        </Provider>
      );

      jestExpect(wrapper.find(Table.Row)).toHaveLength(6);
    });

    test('should call editQuantity when clicked', () => {
      const editQuantitySpy = jest.fn();
      const handleSubmitSpy = jest.fn();

      let wrapper = shallow(
        <ApproveGrindOrdersComponent
          getGrindOrders={() => {}}
          grindOrdersInfo={grindOrders}
          setHeaderAndFooter={() => {}}
          goBack={() => {}}
          approveGrindOrders={() => {}}
          handleSubmit={handleSubmitSpy}
          isApprovedForDay={false}
          editQuantity={editQuantitySpy}
          stopEditingQuantity={() => {}}
          updateGrindOrder={() => {}}
        />
      );

      wrapper
        .find('a')
        .at(0)
        .simulate('click');

      jestExpect(editQuantitySpy).toHaveBeenCalledTimes(1);
      jestExpect(editQuantitySpy).toHaveBeenCalledWith(grindOrders[2]);
    });

    describe('when shouldEditQuantity is true', () => {
      test('should only render quantity text input with check and cross icon for selected order', () => {
        let wrapper = shallow(
          <ApproveGrindOrdersComponent
            getGrindOrders={() => {}}
            grindOrdersInfo={grindOrders}
            setHeaderAndFooter={() => {}}
            goBack={() => {}}
            approveGrindOrders={() => {}}
            handleSubmit={() => {}}
            editQuantity={() => {}}
            shouldEditQuantity={true}
            selectedGrindOrder={grindOrders[2]}
            stopEditingQuantity={() => {}}
            updateGrindOrder={() => {}}
          />
        );

        const firstGrindOrderCell = wrapper
          .find(Table.Row)
          .at(2)
          .find(Table.Cell);
        jestExpect(
          firstGrindOrderCell
            .at(4)
            .find('i')
            .at(0)
        ).toHaveClassName('big check circle outline icon');
        jestExpect(
          firstGrindOrderCell
            .at(4)
            .find('i')
            .at(1)
        ).toHaveClassName('big times circle outline icon');
        jestExpect(
          firstGrindOrderCell
            .at(3)
            .find(Field)
            .at(0)
        ).toHaveProp({ name: 'quantity' });
        jestExpect(firstGrindOrderCell.at(4).find('a')).not.toExist();
        const secondGrindOrderCell = wrapper
          .find(Table.Row)
          .at(5)
          .find(Table.Cell);
        jestExpect(secondGrindOrderCell.at(4).find('i')).not.toExist();
        jestExpect(secondGrindOrderCell.at(3).find(Field)).not.toExist();
        jestExpect(secondGrindOrderCell.at(3).html()).toContain('2');
        jestExpect(secondGrindOrderCell.at(4).find('a')).not.toExist();
      });

      test('should call stopEditingQuantity when click cancel', () => {
        const stopEditingQuantitySpy = jest.fn();
        let wrapper = shallow(
          <ApproveGrindOrdersComponent
            getGrindOrders={() => {}}
            grindOrdersInfo={grindOrders}
            setHeaderAndFooter={() => {}}
            goBack={() => {}}
            approveGrindOrders={() => {}}
            handleSubmit={() => {}}
            reset={() => {}}
            editQuantity={() => {}}
            stopEditingQuantity={stopEditingQuantitySpy}
            shouldEditQuantity={true}
            submitting={true}
            selectedGrindOrder={grindOrders[0]}
            updateGrindOrder={() => {}}
          />
        );

        wrapper.find('[pid="view-grind-orders-table__cross"]').simulate('click');

        jestExpect(stopEditingQuantitySpy).toHaveBeenCalledTimes(1);
      });

      test('should call stopEditingQuantity on unmount', () => {
        const stopEditingQuantitySpy = jest.fn();
        const component = new ApproveGrindOrdersComponent({
          stopEditingQuantity: stopEditingQuantitySpy
        });

        component.componentWillUnmount();

        jestExpect(stopEditingQuantitySpy).toHaveBeenCalledTimes(1);
      });

      test('should call updateGrindOrder when check is clicked and Validate is true', () => {
        jest.spyOn(grindOrderValidator, 'validateQuantity').mockImplementation(() => true);
        const updateProductOrderSpy = jest.fn();

        let wrapper = shallow(
          <ApproveGrindOrdersComponent
            getGrindOrders={() => {}}
            grindOrdersInfo={grindOrders}
            setHeaderAndFooter={() => {}}
            goBack={() => {}}
            approveGrindOrders={() => {}}
            handleSubmit={() => {}}
            reset={() => {}}
            editQuantity={() => {}}
            stopEditingQuantity={() => {}}
            shouldEditQuantity={true}
            updateGrindOrder={updateProductOrderSpy}
            selectedGrindOrder={grindOrders[0]}
            editQuantityValue={1}
          />
        );

        const updatedOrder = { ...grindOrders[0], qtyInBoxes: 1 };

        wrapper.find('[pid="view-grind-orders-table__check"]').simulate('click');

        jestExpect(updateProductOrderSpy).toBeCalledWith(updatedOrder);
      });
    });

    test('should not show edit button when already approved for day and portion room is open', () => {
      let wrapper = shallow(
        <ApproveGrindOrdersComponent
          getGrindOrders={() => {}}
          grindOrdersInfo={grindOrders}
          setHeaderAndFooter={() => {}}
          goBack={() => {}}
          approveGrindOrders={() => {}}
          handleSubmit={() => {}}
          editQuantity={() => {}}
          isApprovedForDay={true}
          isRoomOpen={true}
          stopEditingQuantity={() => {}}
          updateGrindOrder={() => {}}
        />
      );

      const firstGrindOrderCell = wrapper
        .find(Table.Row)
        .at(2)
        .find(Table.Cell);
      jestExpect(firstGrindOrderCell.at(4).find('a')).toHaveLength(0);
    });
  });

  describe('special sorting', () => {
    test('should firstly sort by shipping date chronologically', () => {
      const orderA = { customerOrder: { shipDate: '2011-02-03' } };
      const orderB = { customerOrder: { shipDate: '2010-01-02' } };

      jestExpect(sortBySpecialBlend([orderA, orderB])).toEqual([orderB, orderA]);
    });

    test('should secondly sort by product code falling', () => {
      const orderA = {
        customerOrder: { shipDate: '2010-01-02' },
        product: { code: 'A' }
      };
      const orderB = {
        customerOrder: { shipDate: '2010-01-02' },
        product: { code: 'B' }
      };

      jestExpect(sortBySpecialBlend([orderA, orderB])).toEqual([orderB, orderA]);
    });

    test('should thirdly sort by quantity the greater the better', () => {
      const orderA = {
        customerOrder: { shipDate: '2010-01-02' },
        product: { code: 'A' },
        qtyToProduce: 1
      };
      const orderB = {
        customerOrder: { shipDate: '2010-01-02' },
        product: { code: 'A' },
        qtyToProduce: 2
      };

      jestExpect(sortBySpecialBlend([orderA, orderB])).toEqual([orderB, orderA]);
    });
  });

  describe('Translating state into props', () => {
    test('should copy over the grind orders', () => {
      const state = {
        grindOrdersInfo: {
          grindOrdersInfo: 'abc'
        },
        portionRoomsInfo: {
          currentPortionRoom: {}
        }
      };

      jestExpect(mapStateToProps(state).grindOrdersInfo).toBe('abc');
    });

    /*
    isApprovedForDay: state.portionRoomsInfo.currentPortionRoom.approved === true
     */
    test('should see if the portion room is open', () => {
      const state = {
        grindOrdersInfo: {},
        portionRoomsInfo: {
          currentPortionRoom: {
            portionRoomState: PortionRoomState.CAN_CLOSE
          }
        }
      };

      jestExpect(mapStateToProps(state).isRoomOpen).toBe(true);
    });

    test('should see if the portion room is not open', () => {
      const state = {
        grindOrdersInfo: {},
        portionRoomsInfo: {
          currentPortionRoom: {
            portionRoomState: PortionRoomState.CAN_OPEN
          }
        }
      };

      jestExpect(mapStateToProps(state).isRoomOpen).toBe(false);
    });

    test('should note that this is not a grinding room', () => {
      const state = {
        grindOrdersInfo: {},
        portionRoomsInfo: {
          currentPortionRoom: {
            roomType: 'CUTTING'
          }
        }
      };

      jestExpect(mapStateToProps(state).isGrindingRoom).toBe(false);
    });

    test('should note that this is a grinding room', () => {
      const state = {
        grindOrdersInfo: {},
        portionRoomsInfo: {
          currentPortionRoom: {
            roomType: 'GRINDING'
          }
        }
      };

      jestExpect(mapStateToProps(state).isGrindingRoom).toBe(true);
    });

    test('should note that the grind orders are already approved for the day', () => {
      const state = {
        grindOrdersInfo: {},
        portionRoomsInfo: {
          currentPortionRoom: {
            approved: true
          }
        }
      };

      jestExpect(mapStateToProps(state).isApprovedForDay).toBe(true);
    });

    test('should note that the grind orders are not yet approved for the day', () => {
      const state = {
        grindOrdersInfo: {},
        portionRoomsInfo: {
          currentPortionRoom: {
            approved: false
          }
        }
      };

      jestExpect(mapStateToProps(state).isApprovedForDay).toBe(false);
    });
  });
});
