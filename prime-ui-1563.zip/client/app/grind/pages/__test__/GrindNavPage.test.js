import configureStore from 'redux-mock-store';
import thunk from 'redux-thunk';
import SidebarNavigation from '../../../shared/components/SideNavigation';
import { mount } from 'enzyme';
import React from 'react';
import { Provider } from 'react-redux';
import { Menu } from 'semantic-ui-react';
import { replace } from 'react-router-redux';
import GrindNavPage from '../GrindNavPage';

jest.mock('../ApproveGrindOrders');
jest.mock('../ScheduleFutureGrindOrders');

let middleware = [thunk];
const createStore = configureStore(middleware);

describe('YieldModel', () => {
  let wrapper;
  let mockStore;

  beforeEach(() => {
    mockStore = createStore({
      function: {}
    });
    wrapper = mount(
      <Provider store={mockStore}>
        <GrindNavPage
          location={{ pathname: '/grinding/future-orders/schedule' }}
          match={{ url: '/grinding' }}
          store={mockStore}
        />
      </Provider>
    );
  });

  test('should be aware of all relevant sidebar nav links', () => {
    const sidebar = wrapper.find(SidebarNavigation);
    jestExpect(sidebar.props().links[0].path).toEqual('future-orders/schedule');
    jestExpect(sidebar.props().links[1].path).toEqual('grinding-orders');
  });

  test('should changePath when click navigation links', () => {
    mockStore.clearActions();
    const sidebar = wrapper.find(SidebarNavigation);

    sidebar
      .find(Menu.Item)
      .at(0)
      .simulate('click');
    sidebar
      .find(Menu.Item)
      .at(1)
      .simulate('click');

    const actions = mockStore.getActions();
    jestExpect(actions[0]).toEqual(replace('/grinding/future-orders/schedule'));
    jestExpect(actions[1]).toEqual(replace('/grinding/grinding-orders'));
  });
});
