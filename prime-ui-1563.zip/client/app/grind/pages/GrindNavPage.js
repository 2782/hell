import PropTypes from 'prop-types';
import React from 'react';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import { Route, Switch } from 'react-router-dom';
import { replacePath } from '../../shared/actions/actions';
import SideNavigation from '../../shared/components/SideNavigation';
import ApproveGrindOrders from './ApproveGrindOrders';
import ScheduleFutureGrindOrders from './ScheduleFutureGrindOrders';
import subscriber, { f2BehaviorForSideNavigation } from '../../shared/functionKeys/subscriber';

class GrindNavPage extends React.Component {
  constructor(props) {
    super(props);
  }

  subRouteLinks() {
    const { match, replacePath } = this.props;
    return [
      {
        path: 'future-orders/schedule',
        name: 'Create Grind Schedule',
        toPath: () => {
          replacePath(`${match.url}/future-orders/schedule`);
        }
      },
      {
        path: 'grinding-orders',
        name: "View/Approve Today's Schedule",
        toPath: () => {
          replacePath(`${match.url}/grinding-orders`);
        }
      }
    ];
  }

  render() {
    const { match } = this.props;

    return (
      <div className='page-content grind-nav-page side-navigation-page left-right'>
        <SideNavigation
          links={this.subRouteLinks()}
          currentPath={this.props.location.pathname}
          ref={ref => (this.sideNavigation = ref)}
        />

        <div className='right'>
          <Switch>
            <Route
              exact
              path={`${match.url}/future-orders/schedule`}
              render={() => <ScheduleFutureGrindOrders />}
            />
            <Route
              exact
              path={`${match.url}/grinding-orders`}
              render={() => <ApproveGrindOrders />}
            />
          </Switch>
        </div>
      </div>
    );
  }
}

GrindNavPage.propTypes = {
  replacePath: PropTypes.func.isRequired,
  match: PropTypes.object.isRequired,
  keydown: PropTypes.object,
  location: PropTypes.object.isRequired
};

const mapDispatchToProps = dispatch =>
  bindActionCreators(
    {
      replacePath
    },
    dispatch
  );

export default connect(
  null,
  mapDispatchToProps
)(
  subscriber(GrindNavPage, {
    f2Behavior: f2BehaviorForSideNavigation,
    targetComponent: 'GrindNavPage',
    uris: {
      F2: ['#/grinding/future-orders/schedule', '#/grinding/grinding-orders']
    }
  })
);
