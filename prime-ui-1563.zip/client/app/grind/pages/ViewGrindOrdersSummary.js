import React from 'react';
import PropTypes from 'prop-types';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import { reduxForm } from 'redux-form';
import { changePath, setHeaderAndFooter } from '../../shared/actions/actions';
import { GRIND_ORDERS } from '../../shared/components/pageTitles';
import { TAB_SHIFTTAB_F4 } from '../../shared/components/pageFooters';
import { getGrindOrdersWithBatches } from '../actions/grindActions';
import { PortionRoomState } from '../../landingPage/reducers/portionRoomReducer';
import _ from 'lodash';
import EmptyListMessage from '../../shared/components/EmptyListMessage';
import { Button, Divider, Table } from 'semantic-ui-react';
import { calculateTotalPounds } from './ApproveGrindOrders';
import GrindSizePriorityEnum from './GrindSizePriorityEnum';
import { POLLING_INTERVAL } from '../../shared/constants';

export const GrindOrderSummaryContent = ({ grindOrdersInfo, batchesInfo, createBatch }) => {
  return _(grindOrdersInfo)
    .filter(order => order.qtyInBoxes > 0)
    .sortBy([
      order => order.blend.priority,
      order => GrindSizePriorityEnum[order.product.grindSpecific.grindSize],
      order => order.portionRoomTable.tableDescription
    ])
    .groupBy(order => `${order.blend.description}-${order.product.grindSpecific.grindSize}`)
    .map((blendOrders, key, orders) => {
      const blend = orders[key][0].blend;
      const blendDescription = blend.description;
      const grindSizeKey = key.substring(key.lastIndexOf('-') + 1);
      return (
        <Table.Body
          pid={`view-grind-orders-table__blend-table-${key}`}
          key={`grinding-orders-content-${key}`}
        >
          <Table.Row active>
            <Table.Cell width={4} pid={`view-grind-orders-table__blend-name-${key}`}>
              {blend ? blend.name : ''} {blendDescription} {grindSizeKey}
            </Table.Cell>
            <Table.Cell />
            <Table.Cell
              width={3}
              textAlign='right'
              pid={`view-grind-orders-table__blend-weight-${key}`}
            >
              {calculateTotalPounds(blendOrders)}
            </Table.Cell>
            <Table.Cell />
          </Table.Row>

          {_.map(
            _.groupBy(
              blendOrders,
              grindSizeOrder => grindSizeOrder.portionRoomTable.tableDescription
            ),
            (tableOrders, tableKey) => {
              return (
                <Table.Row key={`grinding-orders-content-${key}-${tableKey}`}>
                  <Table.Cell
                    width={6}
                    textAlign='left'
                    pid={`view-grind-orders-table__blend-name-${key}-${tableKey}`}
                  >
                    {tableKey}
                  </Table.Cell>
                  <Table.Cell />
                  <Table.Cell
                    width={3}
                    textAlign='right'
                    pid={`view-grind-orders-table__blend-weight-${key}-${tableKey}`}
                  >
                    {calculateTotalPounds(tableOrders)}
                  </Table.Cell>
                  <Table.Cell />
                </Table.Row>
              );
            }
          )}
          {
            <Batches
              batchesInfo={batchesInfo}
              blendName={blendDescription}
              grindSize={grindSizeKey}
              createBatch={createBatch}
            />
          }
          {
            <CreateButton
              batchesInfo={batchesInfo}
              blend={blend}
              grindSize={grindSizeKey}
              createBatch={createBatch}
            />
          }
        </Table.Body>
      );
    })
    .value();
};

export const Batches = ({ batchesInfo, blendName, grindSize, createBatch }) => {
  return _.map(
    _.sortBy(
      _.filter(batchesInfo, { blendName: blendName.toUpperCase(), grindSize }),
      'batchNumber'
    ),
    (batch, index) => {
      return (
        <Table.Row
          className={'grinding-orders-content-batches-table'}
          key={`grinding-orders-content-batches-${index}`}
          onClick={() => {
            createBatch({ batchesInfo, blendName, grindSize, batch });
          }}
        >
          <Table.Cell />
          <Table.Cell
            width={4}
            textAlign='left'
            pid={`view-grind-orders-table__blend-name-${batch.blendName}-${index}`}
          >
            Batch #{batch.batchNumber}
          </Table.Cell>
          <Table.Cell
            width={6}
            textAlign='right'
            pid={`view-grind-orders-table__blend-actualPounds-${batch.blendName}-${index}`}
          >
            {calcBatchTotalPounds(batch)}
          </Table.Cell>
          {batch.finished ? (
            <Table.Cell
              width={3}
              textAlign='right'
              pid={`view-grind-orders-table__blend-status-${batch.blendName}-${index}`}
            >
              Finished
            </Table.Cell>
          ) : (
            <Table.Cell />
          )}
        </Table.Row>
      );
    }
  );
};

export const CreateButton = ({ batchesInfo, blend, grindSize, createBatch }) => {
  return (
    <Table.Row key={'grinding-orders-content-batches-create-button'}>
      <Table.Cell />
      <Table.Cell />
      <Table.Cell />
      <Table.Cell width={3} textAlign='right'>
        <Button
          primary
          size={'small'}
          onClick={() => createBatch({ batchesInfo, blend, grindSize })}
        >
          {'Create'}
        </Button>
      </Table.Cell>
    </Table.Row>
  );
};

CreateButton.propTypes = {
  createBatch: PropTypes.func.isRequired,
  batchesInfo: PropTypes.array.isRequired,
  blend: PropTypes.object.isRequired,
  grindSize: PropTypes.string.isRequired
};

const calcBatchTotalPounds = batch => {
  return _.sumBy(batch.sourceMeats, sourceMeat => sourceMeat.actualLbs);
};

export class ViewGrindOrdersSummaryComponent extends React.Component {
  constructor(props) {
    super(props);
  }

  createBatch({ blend, grindSize, batch = {}, batchesInfo }) {
    const { changePath } = this.props;
    let pathname = '/batch/create';
    let state = { batchNumber: batch.number, blend, grindSize, batch, batchesInfo };
    if (batch.finished) {
      pathname = `/batch/${batch.batchNumber}`;
      state = { batch };
    }

    changePath({ pathname, state });
  }

  componentDidMount() {
    const { getGrindOrdersWithBatches, setHeaderAndFooter } = this.props;
    getGrindOrdersWithBatches();
    setHeaderAndFooter({
      header: GRIND_ORDERS,
      footer: TAB_SHIFTTAB_F4
    });

    this.intervalNumber = setInterval(() => {
      this.props.getGrindOrdersWithBatches();
    }, POLLING_INTERVAL);
  }

  componentWillUnmount() {
    clearInterval(this.intervalNumber);
  }

  render() {
    const { grindOrdersInfo, batchesInfo } = this.props;

    return (
      <div>
        <Divider hidden />
        {_.isEmpty(grindOrdersInfo) ? (
          <EmptyListMessage />
        ) : (
          <Table fixed pid='view-grind-orders-table' selectable>
            <Table.Header>
              <Table.Row>
                <Table.HeaderCell
                  width={4}
                  textAlign='left'
                  pid='view-grind-orders-table__header-machine'
                >
                  Machine
                </Table.HeaderCell>
                <Table.HeaderCell
                  width={6}
                  textAlign='left'
                  pid='view-grind-orders-table__header-batch'
                >
                  Batch
                </Table.HeaderCell>

                <Table.HeaderCell
                  width={3}
                  textAlign='right'
                  pid='view-grind-orders-table__header-pounds'
                >
                  Pounds
                </Table.HeaderCell>

                <Table.HeaderCell
                  width={3}
                  textAlign='right'
                  pid='view-grind-orders-table__header-status'
                >
                  Status
                </Table.HeaderCell>
              </Table.Row>
            </Table.Header>

            <GrindOrderSummaryContent
              grindOrdersInfo={grindOrdersInfo}
              batchesInfo={batchesInfo}
              createBatch={this.createBatch.bind(this)}
            />
          </Table>
        )}
      </div>
    );
  }
}

ViewGrindOrdersSummaryComponent.propTypes = {
  grindOrdersInfo: PropTypes.array,
  batchesInfo: PropTypes.array,
  isRoomOpen: PropTypes.bool,
  isGrindingRoom: PropTypes.bool,

  getGrindOrdersWithBatches: PropTypes.func.isRequired,
  changePath: PropTypes.func.isRequired,
  setHeaderAndFooter: PropTypes.func.isRequired
};

export const mapStateToProps = state => ({
  grindOrdersInfo: state.grindOrdersInfo.grindOrdersInfo,
  isRoomOpen:
    state.portionRoomsInfo.currentPortionRoom.portionRoomState === PortionRoomState.CAN_CLOSE,
  isGrindingRoom: state.portionRoomsInfo.currentPortionRoom.roomType === 'GRINDING',
  batchesInfo: state.batches.info.batches
});

const mapDispatchToProps = dispatch =>
  bindActionCreators(
    {
      getGrindOrdersWithBatches,
      changePath,
      setHeaderAndFooter
    },
    dispatch
  );

const ViewGrindOrdersSummary = connect(
  mapStateToProps,
  mapDispatchToProps
)(
  reduxForm({
    form: 'viewGrindOrdersSummary',
    enableReinitialize: true
  })(ViewGrindOrdersSummaryComponent)
);

export default ViewGrindOrdersSummary;
