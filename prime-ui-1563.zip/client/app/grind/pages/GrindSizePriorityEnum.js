//Grind size should be prioritized from largest to smallest
export const GrindSizePriorityEnum = {
  '3/32': 4,
  '3/16': 3,
  '3/8': 2,
  '1/2': 1
};

export default GrindSizePriorityEnum;
