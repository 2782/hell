import React from 'react';
import PropTypes from 'prop-types';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import { Field, formValueSelector, reduxForm } from 'redux-form';
import DotDotDot from 'react-dotdotdot';
import { Form, Table } from 'semantic-ui-react';
import _ from 'lodash';
import { formatDate } from '../../shared/util/dateUtil';
import { setHeaderAndFooter } from '../../shared/actions/actions';
import { GRIND_ORDERS } from '../../shared/components/pageTitles';
import { TAB_SHIFTTAB_F4_F2 } from '../../shared/components/pageFooters';
import {
  approveGrindOrders,
  editQuantity,
  getGrindOrders,
  stopEditingQuantity,
  updateGrindOrder
} from '../actions/grindActions';
import EmptyListMessage from '../../shared/components/EmptyListMessage';
import { PortionRoomState } from '../../landingPage/reducers/portionRoomReducer';
import FormElement from '../../shared/FormElement';
import { validateQuantity } from '../../shared/validation/formFieldValidations';
import { ApproveButton } from '../components/ApproveButton';

export const sortBySpecialBlend = orders => {
  return _.orderBy(
    orders,
    ['customerOrder.shipDate', 'product.code', 'qtyToProduce'],
    ['asc', 'desc', 'desc']
  );
};

export const calculateTotalPounds = blendOrders => {
  if (_.isEmpty(blendOrders)) {
    return 0;
  }

  return Math.ceil(
    blendOrders.reduce((acc, order) => {
      return acc + order.qtyInBoxes * order.product.weightPerBox;
    }, 0)
  );
};

export class ApproveGrindOrdersComponent extends React.Component {
  constructor(props) {
    super(props);

    this.onSubmit = this.onSubmit.bind(this);
    this.editQuantity = this.editQuantity.bind(this);
    this.cancelEditQuantity = this.cancelEditQuantity.bind(this);
    this.changeOrderQuantity = this.changeOrderQuantity.bind(this);
  }

  editQuantity(blendOrder) {
    const { editQuantity } = this.props;

    editQuantity(blendOrder);
  }

  cancelEditQuantity() {
    const { stopEditingQuantity, reset } = this.props;

    stopEditingQuantity();
    reset();
  }

  changeOrderQuantity(selectedGrindOrder, newQuantity) {
    const { updateGrindOrder } = this.props;

    updateGrindOrder({ ...selectedGrindOrder, qtyInBoxes: newQuantity });
  }

  componentDidMount() {
    const { getGrindOrders, setHeaderAndFooter } = this.props;

    getGrindOrders();
    setHeaderAndFooter({
      header: GRIND_ORDERS,
      footer: TAB_SHIFTTAB_F4_F2
    });
  }

  componentWillUnmount() {
    const { stopEditingQuantity } = this.props;

    stopEditingQuantity();
  }

  onSubmit() {
    const { approveGrindOrders } = this.props;

    approveGrindOrders();
  }

  render() {
    const {
      grindOrdersInfo,
      selectedGrindOrder,
      editQuantityValue,
      shouldEditQuantity,
      handleSubmit,
      isApprovedForDay,
      isRoomOpen
    } = this.props;

    return (
      <Form size={'large'} onSubmit={handleSubmit(this.onSubmit)}>
        {_.isEmpty(grindOrdersInfo) ||
        grindOrdersInfo.filter(order => order.qtyInBoxes > 0).length === 0 ? (
          <EmptyListMessage />
        ) : (
          <Table columns={16} size={'small'} fixed pid='view-grind-orders-table'>
            <Table.Header>
              <Table.Row>
                <Table.HeaderCell
                  colSpan={5}
                  width={5}
                  pid='view-grind-orders-table__header-product'
                >
                  Product
                </Table.HeaderCell>
                <Table.HeaderCell
                  colSpan={5}
                  width={5}
                  pid='view-grind-orders-table__header-customer'
                >
                  Customer
                </Table.HeaderCell>
                <Table.HeaderCell
                  colSpan={2}
                  width={2}
                  textAlign={'right'}
                  pid='view-grind-orders-table__header-ship-date'
                >
                  Ship Date
                </Table.HeaderCell>
                <Table.HeaderCell
                  colSpan={2}
                  width={2}
                  textAlign={'right'}
                  pid='view-grind-orders-table__header-quantity-cases'
                >
                  Quantity (Cases)
                </Table.HeaderCell>
                <Table.HeaderCell colSpan={2} width={2} />
              </Table.Row>
            </Table.Header>
            {_(grindOrdersInfo)
              .filter(order => order.qtyInBoxes > 0)
              .sortBy(order => order.blend.priority)
              .groupBy(order => `${order.blend.name}-${order.blend.description}`)
              .map((blendOrders, blendKey) => {
                const blendDescription = blendKey.substring(blendKey.indexOf('-') + 1);
                return (
                  <Table.Body
                    pid={`view-grind-orders-table__blend-table-${blendKey}`}
                    key={`grinding-orders-content-${blendKey}`}
                  >
                    <Table.Row>
                      <Table.Cell
                        colSpan={5}
                        active
                        pid={`view-grind-orders-table__blend-name-${blendKey}`}
                      >
                        {blendDescription}
                      </Table.Cell>
                      <Table.Cell colSpan={5} active />
                      <Table.Cell colSpan={2} active />
                      <Table.Cell
                        colSpan={4}
                        active
                        textAlign='right'
                        pid={`view-grind-orders-table__blend-weight-${blendKey}`}
                      >
                        {calculateTotalPounds(blendOrders)} lbs
                      </Table.Cell>
                    </Table.Row>
                    {_.map(sortBySpecialBlend(blendOrders), (blendOrder, index) => {
                      const portionSize = _.get(
                        blendOrder,
                        'product.productPortionSize.portionSize',
                        ''
                      );
                      const productInfo = `${blendOrder.product.code} / ${portionSize}`;
                      const shipDate = formatDate(_.get(blendOrder, 'deliveryDate', ''));
                      const customerName = _.get(blendOrder, 'customerOrder.customer.name', '');
                      const customerCode = _.get(
                        blendOrder,
                        'customerOrder.customer.customerCode',
                        ''
                      );

                      return (
                        <Table.Row
                          key={`${blendKey}-${blendOrder.itemNumber}-${index}`}
                          pid={`view-grind-orders-table__blend-${blendKey}-row-${index}`}
                        >
                          <Table.Cell colSpan={5}>
                            <div
                              pid={`view-grind-orders-table__blend-${blendKey}-row-${index}-product`}
                            >
                              {productInfo}
                            </div>
                            <DotDotDot clamp={1} title={blendOrder.product.description}>
                              <span
                                pid={`view-grind-orders-table__blend-${blendKey}-row-${index}-product-description`}
                              >
                                {blendOrder.product.description}
                              </span>
                            </DotDotDot>
                          </Table.Cell>
                          <Table.Cell colSpan={5} title={customerName}>
                            <DotDotDot clamp={1} title={customerName}>
                              <span
                                pid={`view-grind-orders-table__blend-${blendKey}-row-${index}-customer-name`}
                              >
                                {customerName}
                              </span>
                            </DotDotDot>
                            <div
                              pid={`view-grind-orders-table__blend-${blendKey}-row-${index}-customer-code`}
                            >
                              {customerCode}
                            </div>
                          </Table.Cell>
                          <Table.Cell
                            colSpan={2}
                            textAlign={'right'}
                            pid={`view-grind-orders-table__blend-${blendKey}-row-${index}-ship-date`}
                          >
                            {shipDate}
                          </Table.Cell>
                          <Table.Cell
                            colSpan={2}
                            textAlign={'right'}
                            pid={`view-grind-orders-table__blend-${blendKey}-row-${index}-qty-in-boxes`}
                          >
                            {shouldEditQuantity && selectedGrindOrder.id === blendOrder.id ? (
                              <Field
                                style={{ textAlign: 'right' }}
                                component={FormElement}
                                name='quantity'
                                validate={[validateQuantity]}
                                as={Form.Input}
                                width={10}
                                type='text'
                              />
                            ) : (
                              blendOrder.qtyInBoxes
                            )}
                          </Table.Cell>
                          {isRoomOpen && isApprovedForDay ? (
                            <Table.Cell
                              colSpan={2}
                              textAlign={'right'}
                              pid={`view-grind-orders-table__blend-${blendKey}-row-${index}-edit`}
                            />
                          ) : (
                            <Table.Cell
                              colSpan={2}
                              textAlign={'right'}
                              pid={`view-grind-orders-table__blend-${blendKey}-row-${index}-edit`}
                            >
                              {shouldEditQuantity && selectedGrindOrder.id === blendOrder.id ? (
                                <div style={{ marginRight: '5px' }}>
                                  <i
                                    className='big check circle outline icon'
                                    pid={'view-grind-orders-table__check'}
                                    onClick={() =>
                                      this.changeOrderQuantity(
                                        selectedGrindOrder,
                                        editQuantityValue
                                      )
                                    }
                                  />
                                  <i
                                    size='huge'
                                    className='big times circle outline icon'
                                    pid={'view-grind-orders-table__cross'}
                                    onClick={() => this.cancelEditQuantity()}
                                  />
                                </div>
                              ) : shouldEditQuantity ? null : (
                                <a
                                  onClick={() => this.editQuantity(blendOrder)}
                                  style={{ marginRight: '5px' }}
                                >
                                  <i className='icon-edit' />
                                </a>
                              )}
                            </Table.Cell>
                          )}
                        </Table.Row>
                      );
                    })}
                  </Table.Body>
                );
              })
              .value()}
          </Table>
        )}

        <ApproveButton {...this.props} />
      </Form>
    );
  }
}

ApproveGrindOrdersComponent.propTypes = {
  grindOrdersInfo: PropTypes.array,
  selectedGrindOrder: PropTypes.object,
  isRoomOpen: PropTypes.bool,
  isGrindingRoom: PropTypes.bool,
  isApprovedForDay: PropTypes.bool,
  shouldEditQuantity: PropTypes.bool,
  editQuantityValue: PropTypes.oneOfType([PropTypes.number, PropTypes.string]),

  getGrindOrders: PropTypes.func.isRequired,
  editQuantity: PropTypes.func.isRequired,
  stopEditingQuantity: PropTypes.func.isRequired,
  updateGrindOrder: PropTypes.func.isRequired,
  setHeaderAndFooter: PropTypes.func.isRequired,
  approveGrindOrders: PropTypes.func.isRequired,

  submitting: PropTypes.bool,
  pristine: PropTypes.bool,
  handleSubmit: PropTypes.func.isRequired,
  reset: PropTypes.func
};

const selector = formValueSelector('approveGrindOrders');
export const mapStateToProps = state => ({
  initialValues: {
    quantity: _.get(state, 'grindOrdersInfo.selectedGrindOrder.qtyInBoxes', '')
  },
  grindOrdersInfo: state.grindOrdersInfo.grindOrdersInfo,
  selectedGrindOrder: state.grindOrdersInfo.selectedGrindOrder,
  isRoomOpen:
    state.portionRoomsInfo.currentPortionRoom.portionRoomState === PortionRoomState.CAN_CLOSE,
  isGrindingRoom: state.portionRoomsInfo.currentPortionRoom.roomType === 'GRINDING',
  isApprovedForDay: state.portionRoomsInfo.currentPortionRoom.approved === true,
  portionRoomState: state.portionRoomsInfo.currentPortionRoom.portionRoomState,
  shouldEditQuantity: state.grindOrdersInfo.shouldEditQuantity,
  editQuantityValue: Number.parseInt(selector(state, 'quantity'))
});

const mapDispatchToProps = dispatch =>
  bindActionCreators(
    {
      getGrindOrders,
      editQuantity,
      stopEditingQuantity,
      updateGrindOrder,
      setHeaderAndFooter,
      approveGrindOrders
    },
    dispatch
  );

const ApproveGrindOrders = connect(
  mapStateToProps,
  mapDispatchToProps
)(
  reduxForm({
    form: 'approveGrindOrders',
    enableReinitialize: true
  })(ApproveGrindOrdersComponent)
);

export default ApproveGrindOrders;
