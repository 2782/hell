import productResources from '../../shared/api/productResources';
import {
  UPDATE_PRODUCTS,
  CLEAR_PRODUCTS,
  PRODUCT_RECEIVED,
  PRODUCT_REQUESTED
} from './productSearchActionTypes';

export const getProductsByDescriptions = descriptions => dispatch => {
  dispatch({
    type: PRODUCT_RECEIVED
  });
  return productResources.getProductsByDescriptions(
    descriptions,
    response => {
      dispatch({
        type: PRODUCT_REQUESTED
      });
      dispatch({
        type: UPDATE_PRODUCTS,
        payload: response
      });
    },
    () => {}
  );
};

export const clearProducts = () => dispatch => {
  dispatch({
    type: CLEAR_PRODUCTS
  });
};
