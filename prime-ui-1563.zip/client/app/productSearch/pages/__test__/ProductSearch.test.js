import React from 'react';
import { createReduxStore } from '../../../store';
import { Provider } from 'react-redux';
import semanticUI from '../../../../test-helpers/semantic-ui';
import ProductSearch, { ProductSearchPage } from '../ProductSearch';
import { PRODUCT_SEARCH } from '../../../shared/components/pageTitles';
import { F4_F2 } from '../../../shared/components/pageFooters';
import productFactory from '../../../../test-factories/productFactory';
import productResources from '../../../shared/api/productResources';
import EmptyTableMessage from '../../../shared/components/EmptyTableMessage';

jest.mock('../../../shared/api/productResources');

const products = [
  productFactory.build({ code: '1', description: 'LA 1' }),
  productFactory.build({ code: '2', description: 'LA 2' })
];

describe('ProductSetupMock', () => {
  let wrapper;
  let setHeaderAndFooter;
  let getProductsByDescriptions;
  let clearProducts;

  beforeEach(() => {
    setHeaderAndFooter = jest.fn();
    clearProducts = jest.fn();
    getProductsByDescriptions = jest.fn();
  });

  test('should render mapping fields', () => {
    wrapper = mount(
      <Provider store={createReduxStore({})}>
        <ProductSearch />
      </Provider>
    );

    jestExpect(semanticUI.getInputValue(wrapper, 'descriptions')).toEqual('');
  });

  test('should display products when type valid descriptions', () => {
    productResources.getProductsByDescriptions.mockImplementation((arg, success) =>
      success(products)
    );
    wrapper = mount(
      <Provider store={createReduxStore({ productsInfo: { loading: true } })}>
        <ProductSearch />
      </Provider>
    );

    semanticUI.changeInput(wrapper, 'descriptions', 'LA, Steak');
    wrapper.find('form').simulate('submit');
    const getHeaderCell = semanticUI.createHeaderCellSelector(wrapper);

    jestExpect(getHeaderCell(0).text()).toEqual('PRODUCT #');
    jestExpect(getHeaderCell(1).text()).toEqual('DESCRIPTION');
    jestExpect(getHeaderCell(2).text()).toEqual('SIZE');

    const productsBody = wrapper.find('tbody').at(0);
    const getTableCell = semanticUI.createCellSelector(productsBody);

    jestExpect(getTableCell(0, 0).text()).toEqual('1');
    jestExpect(getTableCell(0, 1).text()).toEqual('LA 1');
    jestExpect(getTableCell(0, 2).text()).toEqual('7 OZ');
    jestExpect(getTableCell(1, 0).text()).toEqual('2');
    jestExpect(getTableCell(1, 1).text()).toEqual('LA 2');
    jestExpect(getTableCell(1, 2).text()).toEqual('7 OZ');
  });

  test('should display empty message when no product match', () => {
    productResources.getProductsByDescriptions.mockImplementation((arg, success) => success([]));
    wrapper = mount(
      <Provider store={createReduxStore({})}>
        <ProductSearch />
      </Provider>
    );

    semanticUI.changeInput(wrapper, 'descriptions', 'LA, Steak');
    wrapper.find('form').simulate('submit');

    const getHeaderCell = semanticUI.createHeaderCellSelector(wrapper);

    jestExpect(getHeaderCell(0).text()).toEqual('PRODUCT #');
    jestExpect(getHeaderCell(1).text()).toEqual('DESCRIPTION');
    jestExpect(getHeaderCell(2).text()).toEqual('SIZE');

    jestExpect(wrapper.find(EmptyTableMessage).exists()).toEqual(true);
  });

  test('should call setHeaderAndFooter method when componendDitMount', () => {
    const component = new ProductSearchPage({
      setHeaderAndFooter,
      getProductsByDescriptions,
      clearProducts
    });

    component.componentDidMount();

    jestExpect(setHeaderAndFooter).toHaveBeenCalledWith({
      header: PRODUCT_SEARCH,
      footer: F4_F2
    });
  });

  test('should call clearProducts method when componentWillUnmount', () => {
    const component = new ProductSearchPage({
      setHeaderAndFooter,
      getProductsByDescriptions,
      clearProducts
    });

    component.componentWillUnmount();

    jestExpect(clearProducts).toHaveBeenCalledTimes(1);
  });
});
