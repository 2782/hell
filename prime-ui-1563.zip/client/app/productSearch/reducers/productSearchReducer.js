import {
  UPDATE_PRODUCTS,
  CLEAR_PRODUCTS,
  PRODUCT_RECEIVED,
  PRODUCT_REQUESTED
} from '../actions/productSearchActionTypes';

const initialState = {
  products: null,
  loading: false
};

export default (state = initialState, action) => {
  switch (action.type) {
    case UPDATE_PRODUCTS:
      return {
        ...state,
        products: action.payload
      };
    case CLEAR_PRODUCTS:
      return {
        ...state,
        products: null
      };
    case PRODUCT_RECEIVED:
      return {
        ...state,
        loading: true
      };
    case PRODUCT_REQUESTED:
      return {
        ...state,
        loading: false
      };
    default:
      return state;
  }
};
