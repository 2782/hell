export const GRABBED_BOX_TYPES = 'administration/grabBoxTypes';
export const GRABBED_FILM_TYPES = 'administration/grabFilmTypes';
export const GRABBED_TARE_PACKAGES = 'administration/grabTarePackages';
export const GRABBED_TARE_PACKAGE = 'administration/grabTarePackage';
export const CLEAR_TARE_PACKAGES = 'administration/clearTarePackage';
export const GRABBED_DEFAULT_TARE_PACKAGE = 'administration/grabDefaultTarePackage';
