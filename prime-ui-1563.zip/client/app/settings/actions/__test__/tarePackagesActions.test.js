import tarePackagesResources from '../../../shared/api/tarePackagesResources';
import {
  CLEAR_TARE_PACKAGES,
  GRABBED_BOX_TYPES,
  GRABBED_DEFAULT_TARE_PACKAGE,
  GRABBED_FILM_TYPES,
  GRABBED_TARE_PACKAGE,
  GRABBED_TARE_PACKAGES
} from '../tarePackagesActionTypes';
import {
  clearTarePackages,
  getDefaultTarePackage,
  createTarePackage,
  getAllBoxTypes,
  getAllFilmTypes,
  getAllTarePackages,
  getTarePackage
} from '../tarePackagesActions';

jest.mock('../../../shared/api/tarePackagesResources');

describe('tarePackagesActions', () => {
  let dispatch;

  const boxType = {
    boxDescription: 'black #10',
    packagingTare: 1.062
  };

  const filmType = {
    filmDescription: 'Brave Heart',
    filmTare: 2.06
  };

  const boxTypesResponse = [boxType];

  const simpleResponse = [filmType];

  const tarePackageResponse = {
    id: 123,
    boxType: boxType,
    filmType: filmType
  };

  beforeEach(() => {
    dispatch = jest.fn();
    tarePackagesResources.getAllBoxTypes.mockImplementation(callback =>
      callback({
        data: boxTypesResponse
      })
    );
    tarePackagesResources.getAllFilmTypes.mockImplementation(callback =>
      callback({
        data: simpleResponse
      })
    );

    tarePackagesResources.getAllTarePackages.mockImplementation(callback =>
      callback({
        data: simpleResponse
      })
    );
    tarePackagesResources.getTarePackage.mockImplementation((arg, success) =>
      success({
        data: tarePackageResponse
      })
    );
    tarePackagesResources.getDefaultTarePackage.mockImplementation(success =>
      success({
        data: tarePackageResponse
      })
    );
    tarePackagesResources.createTarePackage.mockImplementation((arg, success) =>
      success({
        data: simpleResponse
      })
    );
  });

  afterEach(() => {
    dispatch.mockReset();
    tarePackagesResources.getAllBoxTypes.mockReset();
    tarePackagesResources.getAllFilmTypes.mockReset();
    tarePackagesResources.getAllTarePackages.mockReset();
    tarePackagesResources.getTarePackage.mockReset();
    tarePackagesResources.getDefaultTarePackage.mockReset();
    tarePackagesResources.createTarePackage.mockReset();
  });

  test('should dispatch action on successful callback for getAllBoxTypes', () => {
    getAllBoxTypes()(dispatch);

    jestExpect(dispatch).toHaveBeenNthCalledWith(1, {
      type: GRABBED_BOX_TYPES,
      payload: boxTypesResponse
    });
  });

  test('should dispatch action on successful callback for getAllFilmTypes', () => {
    getAllFilmTypes()(dispatch);

    jestExpect(dispatch).toHaveBeenNthCalledWith(1, {
      type: GRABBED_FILM_TYPES,
      payload: simpleResponse
    });
  });

  test('should dispatch action on successful callback for getAllTarePackages', () => {
    getAllTarePackages()(dispatch);

    jestExpect(dispatch).toHaveBeenNthCalledWith(1, {
      type: GRABBED_TARE_PACKAGES,
      payload: simpleResponse
    });
  });

  test('should dispatch action on successful callback for submitTarePackage', () => {
    tarePackagesResources.createTarePackage.mockImplementation(
      jest.fn((arg, success) =>
        success({
          data: simpleResponse
        })
      )
    );
    createTarePackage()(dispatch);

    jestExpect(dispatch).toHaveBeenCalledTimes(1);
  });

  test('should make api call when submitTarePackage is ran', () => {
    const tarePackage = {
      boxType: {
        boxDescription: 'Sysco Classic',
        packagingTare: 0.088
      },
      filmType: {
        filmDescription: 'Notebook',
        filmTare: 1.88
      }
    };
    createTarePackage(tarePackage)(dispatch);

    jestExpect(tarePackagesResources.createTarePackage.mock.calls[0][0]).toEqual(tarePackage);
    jestExpect(dispatch).toHaveBeenCalled();
  });

  test('should dispatch GRABBED_TARE_PACKAGE when getTarePackage', () => {
    getTarePackage(123)(dispatch);

    jestExpect(dispatch).toHaveBeenNthCalledWith(1, {
      type: GRABBED_TARE_PACKAGE,
      payload: tarePackageResponse
    });
  });

  test('should dispatch GRABBED_DEFAULT_TARE_PACKAGE when getDefaultTarePackage', () => {
    getDefaultTarePackage()(dispatch);

    jestExpect(dispatch).toHaveBeenNthCalledWith(1, {
      type: GRABBED_DEFAULT_TARE_PACKAGE,
      payload: tarePackageResponse
    });
  });

  test('should dispatch CLEAR_TARE_PACKAGES when clearTarePackages', () => {
    clearTarePackages()(dispatch);

    jestExpect(dispatch).toHaveBeenNthCalledWith(1, {
      type: CLEAR_TARE_PACKAGES
    });
  });
});
