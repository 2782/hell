import { getTestStateForGrindingRoom } from '../../../../test-factories/testState';
import fiscalCalendarResources from '../../../shared/api/fiscalCalendarResources';
import settingsResources from '../../../shared/api/settingsResources';
import {
  allowToEditHoliday,
  cancelEditingHoliday,
  clearCustomer,
  clearHousePar,
  clearProfileInfo,
  clearStation,
  clearTable,
  createHoliday,
  createOrUpdateHousePar,
  createOrUpdateProfile,
  createRoom,
  createStation,
  createTable,
  deleteHoliday,
  deleteHousePar,
  editHoliday,
  getActiveFiscalCalendar,
  getAvailableGrindingHousePar,
  getCustomer,
  getCustomers,
  getHolidays,
  getHousePar,
  getHousePars,
  getProfile,
  getStation,
  getStations,
  getSubPrimal,
  getTable,
  getTables,
  getWeekends,
  setupCustomer,
  showError,
  updateActiveFiscalCalendar,
  updateStation,
  updateTable
} from '../settingsActions';
import {
  ALL_CUSTOMERS_RECEIVED,
  CLEAR_CUSTOMER,
  CLEAR_HOUSE_PAR,
  CLEAR_PROFILE_INFO,
  CLEAR_STATION,
  CLEAR_TABLE,
  DELETE_HOLIDAY,
  EDITING_ALLOWED,
  EDITING_OVER,
  GET_ACTIVE_FISCAL_CALENDAR,
  GET_CUSTOMER,
  GET_PROFILE,
  GRABBED_SUB_PRIMAL,
  SHOW_ERROR,
  UPDATE_GRINDING_HOUSE_PARS,
  UPDATE_HOLIDAYS,
  UPDATE_HOUSE_PAR,
  UPDATE_HOUSE_PARS,
  UPDATE_STATION,
  UPDATE_STATIONS,
  UPDATE_TABLE,
  UPDATE_TABLES,
  UPDATE_WEEKENDS
} from '../settingsActionTypes';
import StationFactory, { STATION_1, STATION_2 } from '../../../../test-factories/station';
import PortionRoomTableFactory, {
  TABLE_1
} from '../../../../test-factories/portionRoomTableFactory';
import { replacePath } from '../../../shared/actions/actions';
import profileFactory from '../../../../test-factories/Profile';
import houseParFactory from '../../../../test-factories/housePar';
import customerFactory from '../../../../test-factories/customerFactory';

jest.mock('../../../shared/actions/actions', () => ({
  replacePath: jest.fn(() => ({ type: 'MOCK_REPLACE_PATH' }))
}));
jest.mock('../../../shared/api/settingsResources');
jest.mock('../../../shared/api/fiscalCalendarResources');

const error = { showing: true, message: 'error message' };
const profileResponse = { data: profileFactory.build() };
const customerResponse = { data: customerFactory.build() };

const christmas = {
  id: 25,
  date: '2018-12-25',
  description: 'Christmas'
};

const holidaysResponse = {
  data: [
    {
      id: 35,
      date: '2018-01-15',
      description: 'Martin Luther King Jr. Day'
    },
    {
      id: 45,
      date: '2018-07-04',
      description: 'Independence Day'
    },
    christmas
  ]
};

const thanksgiving = {
  id: 55,
  date: '11-22-2018',
  description: 'Thanksgiving'
};

const createHolidayResponse = {
  data: thanksgiving
};

const weekendsResponse = [
  {
    key: 'sunday',
    value: 'false',
    id: 2
  },
  {
    key: 'saturday',
    value: 'true',
    id: 1
  }
];

const station1 = StationFactory.build(STATION_1);
const station2 = StationFactory.build(STATION_2);
const stations = [station1, station2];

const table1 = PortionRoomTableFactory.build(TABLE_1);

const portionRoomTableResponse = {
  data: table1
};

const stationResponse = {
  data: station1
};

const stationsResponse = {
  data: stations
};

const tablesResponse = {
  data: [
    { tableId: 1, tableCode: 1, stationId: 1, stationCode: 1, stationName: 'ENRIQUE', room: 'A' },
    { tableId: 2, tableCode: 2, stationId: 1, stationCode: 1, stationName: 'ENRIQUE', room: 'A' },
    { tableId: 3, tableCode: 3, stationId: 1, stationCode: 1, stationName: 'ENRIQUE', room: 'A' }
  ]
};

describe('settingsActions', () => {
  let dispatch;

  beforeEach(() => {
    dispatch = jest.fn();
  });

  afterEach(() => {
    dispatch.mockReset();
    replacePath.mockReset();
  });

  describe('get holidays', () => {
    beforeEach(() => {
      settingsResources.getHolidays.mockImplementation(callback => callback(holidaysResponse));
    });

    afterEach(() => {
      settingsResources.getHolidays.mockReset();
    });

    test('should call getHolidays from settingsResources and dispatch UPDATE_HOLIDAYS', () => {
      getHolidays()(dispatch);

      jestExpect(dispatch).toHaveBeenNthCalledWith(1, {
        type: UPDATE_HOLIDAYS,
        payload: holidaysResponse.data
      });
    });
  });

  describe('create valid holiday', () => {
    beforeEach(() => {
      settingsResources.createHoliday.mockImplementation((arg, success) =>
        success(createHolidayResponse)
      );
      settingsResources.getHolidays.mockImplementation(callback => callback(holidaysResponse));
    });

    afterEach(() => {
      settingsResources.createHoliday.mockReset();
      settingsResources.getHolidays.mockReset();
    });

    test('should call createHoliday from settingsResources and dispatch UPDATE_HOLIDAYS', () => {
      createHoliday(thanksgiving)(dispatch);
      holidaysResponse.data = [...holidaysResponse.data, createHolidayResponse.data];
      getHolidays()(dispatch);

      jestExpect(dispatch).toHaveBeenCalledWith({
        type: UPDATE_HOLIDAYS,
        payload: holidaysResponse.data
      });
    });
  });

  describe('editing Holiday', () => {
    test('should call EDITING_ALLOWED', () => {
      allowToEditHoliday(christmas)(dispatch);
      jestExpect(dispatch).toHaveBeenCalledWith({
        type: EDITING_ALLOWED,
        payload: christmas
      });
    });

    test('should call EDITING_OVER', () => {
      cancelEditingHoliday()(dispatch);
      jestExpect(dispatch).toHaveBeenCalledWith({
        type: EDITING_OVER
      });
    });

    test('should call EDITING_OVER on successful call', async () => {
      settingsResources.editHoliday.mockImplementation(() => {
        return Promise.resolve({ date: '2019-09-09', description: 'test data', id: 25 });
      });
      settingsResources.getHolidays.mockImplementation(callback => callback(holidaysResponse));

      await editHoliday(25, { date: '2019-09-09', description: 'test data' })(dispatch);

      jestExpect(dispatch).toHaveBeenNthCalledWith(1, { type: EDITING_OVER });
    });
  });

  describe('getWeekends()', () => {
    beforeEach(() => {
      settingsResources.getWeekends.mockImplementation(success => success(weekendsResponse));
    });

    test('should call getWeekends from settingsResources and dispatch UPDATE_WEEKENDS', () => {
      getWeekends()(dispatch);

      jestExpect(dispatch).toHaveBeenNthCalledWith(1, {
        type: UPDATE_WEEKENDS,
        payload: weekendsResponse
      });
    });
  });

  describe('handle invalid holidays', () => {
    beforeEach(() => {
      settingsResources.createHoliday.mockImplementation((arg1, success, fail) => fail(error));
    });

    afterEach(() => {
      settingsResources.createHoliday.mockReset();
    });

    test('should dispatch SHOW_ERROR if call fails', () => {
      createHoliday(thanksgiving)(dispatch);

      jestExpect(dispatch).toHaveBeenNthCalledWith(1, {
        type: SHOW_ERROR,
        payload: { showing: true, message: 'error message' }
      });
    });
  });

  describe('delete holiday', () => {
    beforeEach(() => {
      settingsResources.deleteHoliday.mockImplementation((arg, callback) => callback());
    });

    afterEach(() => {
      settingsResources.deleteHoliday.mockReset();
    });

    test('should call deleteHoliday from settingsResources and dispatch DELETE_HOLIDAY', () => {
      deleteHoliday(christmas.id)(dispatch);
      jestExpect(dispatch).toHaveBeenNthCalledWith(1, { type: DELETE_HOLIDAY, payload: 25 });
    });
  });

  describe('getStations()', () => {
    beforeEach(() => {
      settingsResources.getStations.mockImplementation(success => success(stationsResponse));
    });

    test('should call getStations from settingsResources and dispatch UPDATE_STATIONS', () => {
      getStations()(dispatch);

      jestExpect(dispatch).toHaveBeenNthCalledWith(1, {
        type: UPDATE_STATIONS,
        payload: stations
      });
    });
  });

  describe('createStation()', () => {
    let station;

    beforeEach(() => {
      station = { data: { name: 'name', stationCode: '1', room: 'A' } };
    });

    afterEach(() => {
      settingsResources.createStation.mockReset();
    });

    test('should call createStation from settingsResources and change path', () => {
      settingsResources.createStation.mockImplementation((arg, callback) => callback(station));

      createStation(station)(dispatch);

      jestExpect(settingsResources.createStation).toHaveBeenCalledTimes(1);
      jestExpect(dispatch).toHaveBeenCalledWith(replacePath('/settings/stations'));
    });

    test('should call rejectCallback if call fails', () => {
      settingsResources.createStation.mockImplementation((arg, success, fail) => fail(error));
      const rejectCallback = jest.fn();

      createStation(station, rejectCallback)(dispatch);

      jestExpect(settingsResources.createStation).toHaveBeenCalledTimes(1);
      jestExpect(rejectCallback).toHaveBeenCalledTimes(1);
    });
  });

  describe('update station', () => {
    afterEach(() => {
      settingsResources.updateStation.mockReset();
    });

    test('should update station successfully and replace the path', () => {
      settingsResources.updateStation.mockImplementation((arg, success) => success());
      updateStation(station2)(dispatch);

      jestExpect(settingsResources.updateStation.mock.calls[0][0]).toEqual(station2);
      jestExpect(dispatch).toHaveBeenCalledWith(replacePath('/settings/stations'));
    });

    test('should call rejectCallback when updating station fails', () => {
      settingsResources.updateStation.mockImplementation((arg, success, fail) =>
        fail({
          error: { details: [{ field: 'stationRequest', issue: 'some issue' }] }
        })
      );
      const rejectCallback = jest.fn();
      updateStation(station2, rejectCallback)(dispatch);

      jestExpect(settingsResources.updateStation.mock.calls[0][0]).toEqual(station2);
      jestExpect(rejectCallback).toHaveBeenCalledTimes(1);
    });
  });

  describe('clear station', () => {
    test('should update station and change path to get stations', () => {
      clearStation()(dispatch);

      jestExpect(dispatch).toHaveBeenCalledWith({ type: CLEAR_STATION });
    });
  });

  describe('clear table', () => {
    test('should update table and change path to get tables', () => {
      clearTable()(dispatch);

      jestExpect(dispatch).toHaveBeenCalledWith({ type: CLEAR_TABLE });
    });
  });

  describe('getStation()', () => {
    test('should call getStation from settingsResources and dispatch UPDATE_STATION', () => {
      settingsResources.getStation.mockImplementation((arg, callback) => callback(stationResponse));

      getStation(STATION_1.id)(dispatch);

      jestExpect(dispatch).toHaveBeenNthCalledWith(1, {
        type: UPDATE_STATION,
        payload: stationResponse.data
      });
    });
  });

  describe('getTables()', () => {
    afterEach(() => {
      settingsResources.getTables.mockReset();
    });

    test('should call getTables from settingsResources and dispatch UPDATE_TABLES', () => {
      settingsResources.getTables.mockImplementation(success => success(tablesResponse));

      getTables()(dispatch);

      jestExpect(dispatch).toHaveBeenNthCalledWith(1, {
        type: UPDATE_TABLES,
        payload: tablesResponse.data
      });
    });
  });

  describe('getTable()', () => {
    afterEach(() => {
      settingsResources.getTable.mockReset();
    });

    test('should call getTable from settingsResources and dispatch UPDATE_TABLE', () => {
      settingsResources.getTable.mockImplementation((arg, success) =>
        success(portionRoomTableResponse)
      );

      getTable(TABLE_1.id)(dispatch);

      jestExpect(dispatch).toHaveBeenNthCalledWith(1, {
        type: UPDATE_TABLE,
        payload: {
          id: 1,
          tableCode: 12,
          tableDescription: 'BEEF',
          poundsPerHour: '100',
          tableOpenTime: '10:00AM',
          tableCloseTime: '11:00AM',
          station: {
            id: 21421402141,
            name: 'JOHN',
            portionRoomTables: [12, 34, 23, 22],
            room: 'A',
            stationCode: 90
          },
          stationId: 21421402141
        }
      });
    });
  });

  describe('getProfile()', () => {
    test('should call getProfile from settingsResources and dispatch GET_PROFILE', () => {
      settingsResources.getProfile.mockImplementation(success => success(profileResponse));
      getProfile()(dispatch);

      jestExpect(dispatch).toHaveBeenNthCalledWith(1, {
        type: GET_PROFILE,
        payload: profileResponse.data
      });
      settingsResources.getProfile.mockReset();
    });
  });

  describe('createOrUpdateProfile()', () => {
    const profile = profileFactory.build();

    test('should call getProfile from settingsResources and dispatch GET_PROFILE', () => {
      settingsResources.createOrUpdateProfile.mockImplementation((arg, success) =>
        success(profile)
      );
      createOrUpdateProfile(profile)(dispatch);

      jestExpect(settingsResources.createOrUpdateProfile.mock.calls[0][0]).toEqual(profile);
      jestExpect(dispatch).toHaveBeenNthCalledWith(1, {
        type: GET_PROFILE,
        payload: profile
      });

      settingsResources.createOrUpdateProfile.mockReset();
    });
  });

  describe('clear profile', () => {
    test('should dispatch CLEAR_PROFILE_INFO', () => {
      clearProfileInfo()(dispatch);

      jestExpect(dispatch).toHaveBeenNthCalledWith(1, {
        type: CLEAR_PROFILE_INFO
      });
    });
  });

  describe('Table CRUD', () => {
    let table;

    afterEach(() => {
      settingsResources.createTable.mockReset();
      settingsResources.updateTable.mockReset();
    });

    beforeEach(() => {
      table = {
        tableCode: '1',
        tableDescription: 'Table Description',
        tableOpenTime: '08:00:00',
        tableCloseTime: '16:00:00',
        poundsPerHour: 100,
        station: { id: 1 }
      };
    });

    test('should call createTable from settingsResources and change path to get tables', async () => {
      settingsResources.createTable.mockResolvedValue({});

      await createTable(table)(dispatch);

      jestExpect(settingsResources.createTable.mock.calls[0][0]).toEqual(table);
      jestExpect(replacePath).toHaveBeenCalledWith('/settings/tables');
    });

    test('should return submission error when error is encountered during create table', () => {
      settingsResources.createTable.mockImplementation(() => {
        return Promise.reject({ response: { data: 'error' } });
      });

      return createTable(table)(dispatch).catch(error => {
        jestExpect(error.errors.tableCode).toEqual('Create Table Failed');
      });
    });

    test('should update table and change path to get tables', async () => {
      settingsResources.updateTable.mockResolvedValue({});

      await updateTable(111, table)(dispatch);

      jestExpect(settingsResources.updateTable.mock.calls[0][0]).toEqual(111);
      jestExpect(settingsResources.updateTable.mock.calls[0][1]).toEqual(table);
      jestExpect(replacePath).toHaveBeenCalledTimes(1);
    });

    test('should return submission error when error is encountered during update table', () => {
      settingsResources.updateTable.mockImplementation(() => {
        return Promise.reject({ response: { data: 'error' } });
      });

      return updateTable(111, table)(dispatch).catch(error => {
        jestExpect(error.errors.tableCode).toEqual('Create Table Failed');
      });
    });
  });

  describe('createOrUpdateHousePar()', () => {
    let housePar;

    beforeEach(() => {
      housePar = { productCode: '0079007', monday: '1' };
    });

    afterEach(() => {
      settingsResources.createHousePar.mockReset();
      settingsResources.updateHousePar.mockReset();
    });

    test('should call createHousePar from settingsResources and change path to house par maintenance page on success', () => {
      settingsResources.createHousePar.mockImplementation((arg, success) => success());

      createOrUpdateHousePar(housePar, () => {
        jest.fail();
      })(dispatch);

      jestExpect(settingsResources.createHousePar.mock.calls[0][0]).toEqual(housePar);
      jestExpect(replacePath).toHaveBeenCalledTimes(1);
    });

    test('should call updateHousePar from settingsResources and change path to house par maintenance page on success', () => {
      housePar = { productCode: '0079007', monday: '1', id: 1 };
      settingsResources.updateHousePar.mockImplementation((arg, success) => success());

      createOrUpdateHousePar(housePar, () => {
        jest.fail();
      })(dispatch);

      jestExpect(settingsResources.updateHousePar.mock.calls[0][0]).toEqual(housePar);
      jestExpect(replacePath).toHaveBeenCalledTimes(1);
    });

    test('should handle error if create housePar fails', () => {
      const rejectCallback = jest.fn();
      const errors = 'I failed';
      settingsResources.createHousePar.mockImplementation((arg1, success, fail) => fail(errors));

      createOrUpdateHousePar(
        {
          productCode: '0079007',
          monday: '1'
        },
        rejectCallback
      )(dispatch);

      jestExpect(rejectCallback).toHaveBeenCalledWith(errors);
    });

    test('should handle error if update housePar fails', () => {
      const rejectCallback = jest.fn();
      const errors = 'I failed';
      settingsResources.updateHousePar.mockImplementation((arg, success, fail) => fail(errors));

      createOrUpdateHousePar(
        {
          productCode: '0079007',
          monday: '1',
          id: 1
        },
        rejectCallback
      )(dispatch);

      jestExpect(rejectCallback).toHaveBeenCalledWith(errors);
    });
  });

  describe('createRoom()', () => {
    let room;

    beforeEach(() => {
      room = { code: 'AB', description: 'Room Description' };
    });

    afterEach(() => {
      settingsResources.createRoom.mockReset();
    });

    test('should call createRoom from settingsResources and change path to room maintenance page on success', () => {
      settingsResources.createRoom.mockImplementation((arg, success) => success());

      createRoom(room)(dispatch);

      jestExpect(settingsResources.createRoom.mock.calls[0][0]).toEqual(room);
      jestExpect(replacePath).toHaveBeenCalledTimes(1);
    });

    test('should handle error if create room fails', () => {
      settingsResources.createRoom.mockImplementation((arg, success, fail) =>
        fail({ showing: true, message: 'fails' })
      );
      const errorHandle = jest.fn();
      createRoom(room, errorHandle)(dispatch);

      jestExpect(settingsResources.createRoom.mock.calls[0][0]).toEqual(room);
      jestExpect(errorHandle).toHaveBeenCalledTimes(1);
    });
  });

  describe('showError()', () => {
    test('should call showError and dispatch SHOW_ERROR', () => {
      showError('error message')(dispatch);

      jestExpect(dispatch).toHaveBeenNthCalledWith(1, {
        type: SHOW_ERROR,
        payload: { showing: true, message: 'error message' }
      });
    });
  });

  describe('getHousePars', () => {
    afterEach(() => {
      settingsResources.getHousePars.mockReset();
    });

    test('should call getHousePars and dispatch UPDATE_HOUSE_PARS', () => {
      const houseParsResponse = { data: [houseParFactory.build()] };
      settingsResources.getHousePars.mockImplementation(success => success(houseParsResponse));
      getHousePars()(dispatch);

      jestExpect(dispatch).toHaveBeenNthCalledWith(1, {
        type: UPDATE_HOUSE_PARS,
        payload: houseParsResponse.data
      });
    });
  });

  describe('Customer actions', () => {
    afterEach(() => {
      settingsResources.setupCustomer.mockReset();
      settingsResources.getSubPrimal.mockReset();
    });

    test('should call getCustomers and dispatch ALL_CUSTOMERS_RECEIVED', async () => {
      const fakeData = { data: 'this is so fake' };
      settingsResources.getCustomers.mockResolvedValue(fakeData);

      await getCustomers()(dispatch);
      jestExpect(dispatch).toHaveBeenCalledWith({
        type: ALL_CUSTOMERS_RECEIVED,
        payload: fakeData.data
      });
    });

    test('should call getCustomer and dispatch GET_CUSTOMER', async () => {
      settingsResources.getCustomer.mockResolvedValue(customerResponse);

      await getCustomer('000170')(dispatch);

      jestExpect(dispatch).toHaveBeenNthCalledWith(1, {
        type: GET_CUSTOMER,
        payload: customerResponse.data
      });
    });

    test('should call setup customer and dispatch GET_CUSTOMER', () => {
      const getState = jest.fn(() => ({
        uploadFileReducer: {
          selectedFile: 'value'
        }
      }));

      settingsResources.setupCustomer.mockImplementation(() => {
        return Promise.resolve(customerResponse);
      });

      return setupCustomer({ customerCode: '000170', bestBy: 10 })(dispatch, getState).then(() => {
        jestExpect(dispatch).toHaveBeenNthCalledWith(1, {
          type: GET_CUSTOMER,
          payload: customerResponse.data
        });
        jestExpect(dispatch).toHaveBeenNthCalledWith(
          2,
          replacePath('/settings/customers-packoff-display')
        );
      });
    });

    test('should call clear customer and dispatch CLEAR_CUSTOMER', () => {
      clearCustomer()(dispatch);

      jestExpect(dispatch).toHaveBeenNthCalledWith(1, {
        type: CLEAR_CUSTOMER
      });
    });

    test('should call get sub primal and dispatch GRABBED_SUB_PRIMAL', () => {
      const subPrimalResponse = {
        data: { subPrimalCode: '123', subPrimalDescription: 'desc for 123' }
      };

      settingsResources.getSubPrimal.mockImplementation((arg, callback) =>
        callback(subPrimalResponse)
      );

      getSubPrimal('123')(dispatch);

      jestExpect(dispatch).toHaveBeenNthCalledWith(1, {
        type: GRABBED_SUB_PRIMAL,
        payload: subPrimalResponse.data
      });
    });
  });

  describe('getHousePar', () => {
    afterEach(() => {
      settingsResources.getHousePar.mockReset();
    });

    test('should call getHousePar and dispatch UPDATE_HOUSE_PAR', () => {
      const houseParResponse = { data: houseParFactory.build() };
      settingsResources.getHousePar.mockImplementation((arg, success) => success(houseParResponse));

      getHousePar('0078889')(dispatch);

      jestExpect(settingsResources.getHousePar.mock.calls[0][0]).toEqual('0078889');
      jestExpect(dispatch).toHaveBeenNthCalledWith(1, {
        type: UPDATE_HOUSE_PAR,
        payload: houseParResponse.data
      });
    });
  });

  describe('deleteHousePar', () => {
    test('should call deleteHousePar and then active getHousePars', () => {
      const houseParsResponse = { data: [houseParFactory.build()] };
      settingsResources.deleteHousePar.mockImplementation((arg, success) => success());
      settingsResources.getHousePars.mockImplementation(success => success(houseParsResponse));

      deleteHousePar('0068205')(dispatch);

      jestExpect(settingsResources.deleteHousePar.mock.calls[0][0]).toEqual('0068205');
      jestExpect(settingsResources.getHousePars).toHaveBeenCalledTimes(1);
      jestExpect(dispatch).toHaveBeenNthCalledWith(1, {
        type: UPDATE_HOUSE_PARS,
        payload: houseParsResponse.data
      });
    });
  });

  describe('clearHousePar', () => {
    test('should call getHousePars and dispatch UPDATE_HOUSE_PARS', () => {
      clearHousePar()(dispatch);

      jestExpect(dispatch).toHaveBeenNthCalledWith(1, {
        type: CLEAR_HOUSE_PAR
      });
    });
  });

  describe('setupFiscalCalendar', () => {
    test('should get active fiscal calendar and dispatch GET_ACTIVE_FISCAL_CALENDAR', () => {
      const activeFiscalCalendarResponse = {
        id: 1,
        startDate: '2017-07-02',
        nextStartDate: '2018-07-01'
      };

      fiscalCalendarResources.getActiveFiscalCalendar.mockImplementation(success =>
        success({ data: activeFiscalCalendarResponse })
      );

      getActiveFiscalCalendar()(dispatch);

      jestExpect(dispatch).toHaveBeenNthCalledWith(1, {
        type: GET_ACTIVE_FISCAL_CALENDAR,
        payload: activeFiscalCalendarResponse
      });
    });

    test('should update fiscal calendar success and dispatch GET_ACTIVE_FISCAL_CALENDAR', () => {
      const activeFiscalCalendarResponse = {
        id: 1,
        startDate: '2017-07-02',
        nextStartDate: '2018-07-01'
      };

      fiscalCalendarResources.updateActiveFiscalCalendar.mockImplementation((arg, callback) =>
        callback({
          data: activeFiscalCalendarResponse
        })
      );

      updateActiveFiscalCalendar(activeFiscalCalendarResponse)(dispatch);

      jestExpect(dispatch).toHaveBeenNthCalledWith(1, {
        type: GET_ACTIVE_FISCAL_CALENDAR,
        payload: activeFiscalCalendarResponse
      });
    });
  });

  describe('getGrindingHousePars', () => {
    test('should call getAvailableGrindingHousePar and dispatch UPDATE_GRINDING_HOUSE_PARS', () => {
      const grindingHouseParsResponse = { data: houseParFactory.build() };
      settingsResources.getAvailableGrindingHousePar.mockImplementation((arg, success) =>
        success(grindingHouseParsResponse)
      );

      getAvailableGrindingHousePar()(dispatch, getTestStateForGrindingRoom);

      jestExpect(settingsResources.getAvailableGrindingHousePar.mock.calls[0][0]).toEqual('D');
      jestExpect(dispatch).toHaveBeenNthCalledWith(1, {
        type: UPDATE_GRINDING_HOUSE_PARS,
        payload: grindingHouseParsResponse.data
      });
    });

    test('should call getAvailableGrindingHousePar and successCallback when given successCallback', () => {
      const grindingHouseParsResponse = { data: houseParFactory.build() };
      const successCallback = jest.fn();
      settingsResources.getAvailableGrindingHousePar.mockImplementation((arg, success) =>
        success(grindingHouseParsResponse)
      );

      getAvailableGrindingHousePar(successCallback)(dispatch, getTestStateForGrindingRoom);

      jestExpect(successCallback).toHaveBeenNthCalledWith(1, grindingHouseParsResponse.data);
    });
  });
});
