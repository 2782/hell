import {
  CLEAR_TARE_PACKAGES,
  GRABBED_BOX_TYPES,
  GRABBED_DEFAULT_TARE_PACKAGE,
  GRABBED_FILM_TYPES,
  GRABBED_TARE_PACKAGE,
  GRABBED_TARE_PACKAGES
} from './tarePackagesActionTypes';
import tarePackagesResources from '../../shared/api/tarePackagesResources';
import { replacePath } from '../../shared/actions/actions';

export const getAllBoxTypes = () => dispatch => {
  return tarePackagesResources.getAllBoxTypes(response => {
    dispatch({
      type: GRABBED_BOX_TYPES,
      payload: response.data
    });
  });
};

export const getAllFilmTypes = () => dispatch => {
  return tarePackagesResources.getAllFilmTypes(response => {
    dispatch({
      type: GRABBED_FILM_TYPES,
      payload: response.data
    });
  });
};

export const getAllTarePackages = () => dispatch => {
  return tarePackagesResources.getAllTarePackages(response => {
    dispatch({
      type: GRABBED_TARE_PACKAGES,
      payload: response.data
    });
  });
};

export const getTarePackage = tareId => dispatch => {
  return tarePackagesResources.getTarePackage(tareId, response => {
    dispatch({
      type: GRABBED_TARE_PACKAGE,
      payload: response.data
    });
  });
};

export const getDefaultTarePackage = () => dispatch => {
  return tarePackagesResources.getDefaultTarePackage(response => {
    dispatch({
      type: GRABBED_DEFAULT_TARE_PACKAGE,
      payload: response.data
    });
  });
};

export const createTarePackage = (tarePackage, rejectCallback = () => {}) => dispatch => {
  return tarePackagesResources.createTarePackage(
    tarePackage,
    () => {
      dispatch(replacePath('/settings/tare-packages'));
    },
    rejectCallback
  );
};

export const clearTarePackages = () => {
  return dispatch => {
    dispatch({
      type: CLEAR_TARE_PACKAGES
    });
  };
};

export const hideConfirmation = () => {
  return dispatch => {
    dispatch({
      type: 'HIDE_TARE_PACKAGE_CONFIRMATION'
    });
  };
};

export const showConfirmation = () => {
  return dispatch => {
    dispatch({
      type: 'SHOW_TARE_PACKAGE_CONFIRMATION'
    });
  };
};
