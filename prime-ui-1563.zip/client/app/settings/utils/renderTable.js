import React from 'react';
import _ from 'lodash';
import { Table } from 'semantic-ui-react';

export const renderMaintenanceTableBody = (columns, items) => {
  if (!_.isNull(items)) {
    return <Table.Body key={'maintenance-table-content'}>{renderRows(columns, items)}</Table.Body>;
  }
};

export const renderStationMaintenanceTableBody = (columns, items) => {
  const stationsByTypes = _.groupBy(items, station => station.type);
  const stationTypes = ['PRODUCTION', 'PACKOFF'];

  return _.map(stationTypes, (type, index) => {
    return (
      <Table.Body key={`maintenance-table-content-${index}`}>
        <Table.Row>
          <Table.Cell colSpan={7}>{type}</Table.Cell>
        </Table.Row>

        {renderRows(columns, stationsByTypes[type])}
      </Table.Body>
    );
  });
};

export const renderTableMaintenanceTableBody = (columns, items) => {
  return <Table.Body key={'maintenance-table-content'}>{renderRows(columns, items)}</Table.Body>;
};

export const renderPackageMaintenanceTableBody = (columns, items) => {
  if (!_.isNull(items)) {
    const packages = items.map(item => {
      return {
        ...item.boxType,
        ...item.filmType,
        ...{ defaulted: <input type='checkbox' checked={item.defaulted} disabled={true} /> },
        id: item.id
      };
    });

    return (
      <Table.Body key={'maintenance-table-content'}>{renderRows(columns, packages)}</Table.Body>
    );
  }
};

export const renderCustomerPackoffDisplay = (columns, items) => {
  if (!_.isNull(items)) {
    const validCustomers = _.filter(items, item => item.dateType !== 'NONE').map(item => {
      let className = !_.isEmpty(item.subPrimals) ? 'has-sub-primals' : '';
      return {
        ...item,
        dateValue: <div className={className}>{item.dateValue}</div>
      };
    });

    return (
      <Table.Body key={'maintenance-table-content'}>
        {renderRows(columns, validCustomers)}
      </Table.Body>
    );
  }
};

export const renderRows = (columns, items) => {
  return _.map(items, (item, itemIndex) => (
    <Table.Row
      pid={`maintenance__table-row-${itemIndex}`}
      key={`maintenance__table-row-${itemIndex}`}
    >
      {_.map(columns, (column, index) => (
        <Table.Cell
          pid={`maintenance__${column.pid}`}
          key={`maintenance__${column.key}-${index}`}
          textAlign={column.textAlign}
        >
          {renderCell(column, item)}
        </Table.Cell>
      ))}
    </Table.Row>
  ));
};

const renderCell = (column, item) => {
  if (column.value && typeof column.value === 'function') {
    return column.value(item);
  } else {
    if (Array.isArray(item[column.key])) {
      return `${item[column.key].join(', ')}`;
    } else {
      return item[column.key];
    }
  }
};
