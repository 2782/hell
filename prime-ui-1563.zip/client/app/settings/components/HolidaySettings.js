import _ from 'lodash';
import moment from 'moment';
import React from 'react';
import PropTypes from 'prop-types';
import HolidayTable from './HolidayTable';
import FormElement from '../../shared/FormElement';
import { Field, reduxForm, SubmissionError } from 'redux-form';
import { Form, Button, Grid, Divider } from 'semantic-ui-react';
import { connect } from 'react-redux';
import FormDayPickerInput from '../../shared/FormDayPickerInput';
import { ISO_DATE_FORMAT, DEFAULT_DISPLAY_DATE_FORMAT } from '../../shared/util/dateUtil';

const DATE_PLACEHOLDER = DEFAULT_DISPLAY_DATE_FORMAT;

export const isHolidayDateInValid = (values, props) => {
  const holidayDate = moment(values.date, DATE_PLACEHOLDER);
  const today = moment(props.today, ISO_DATE_FORMAT);
  if (!holidayDate.isValid() || holidayDate < today) {
    throw new SubmissionError({ date: 'Please enter valid date' });
  }
  if (_.some(props.holidays, item => item.data.date === values.date)) {
    if (!props.editableHoliday || props.editableHoliday.date !== values.date) {
      throw new SubmissionError({ date: 'Please enter valid date' });
    }
  }
  if (!values.description) {
    throw new SubmissionError({ description: 'Required' });
  }
};

class HolidaySettingsComponent extends React.Component {
  constructor(props) {
    super(props);

    this.submit = this.submit.bind(this);
  }

  submit(values) {
    const { date, description } = values;
    const { createHoliday, reset } = this.props;

    if (isHolidayDateInValid(values, this.props)) {
      reset();
    } else {
      createHoliday({ date, description });
      reset();
    }
  }

  render() {
    const { holidays, handleSubmit, submitting, reset, allowedToEdit } = this.props;

    return (
      <div>
        <label className='config-heading'>Holidays</label>
        <Form size={'large'} onSubmit={handleSubmit(this.submit)}>
          <Grid>
            <Grid.Row>
              <Grid.Column width={'5'}>
                <Field
                  name='date'
                  component={FormDayPickerInput}
                  as={Form.Input}
                  autoFocus={true}
                  label='Holiday Date'
                  placeholder={DEFAULT_DISPLAY_DATE_FORMAT}
                  formatString={DEFAULT_DISPLAY_DATE_FORMAT}
                  dayPickerProps={{ disabledDays: { before: new Date() } }}
                />
              </Grid.Column>
              <Grid.Column width={'9'}>
                <Field
                  name='description'
                  component={FormElement}
                  as={Form.Input}
                  type='text'
                  label='Holiday Description'
                  maxLength={30}
                />
              </Grid.Column>
              <Grid.Column width={'2'}>
                <Button
                  size={'large'}
                  className='holiday-add-button'
                  width={3}
                  disabled={allowedToEdit}
                  loading={submitting}
                >
                  <i className='icon-plus' />
                </Button>
              </Grid.Column>
            </Grid.Row>
          </Grid>
        </Form>
        <Divider />
        <HolidayTable holidays={holidays} holidayAddReset={reset} />
      </div>
    );
  }
}

HolidaySettingsComponent.propTypes = {
  holidays: PropTypes.array.isRequired,
  createHoliday: PropTypes.func.isRequired,
  today: PropTypes.string.isRequired,
  deleteHoliday: PropTypes.func,
  hideError: PropTypes.func,
  handleSubmit: PropTypes.func.isRequired,
  submitting: PropTypes.bool.isRequired,
  showError: PropTypes.func,
  reset: PropTypes.func,
  allowedToEdit: PropTypes.bool
};

const mapStateToProps = state => ({
  allowedToEdit: state.settingsInfo.allowedToEdit
});

const HolidaySettings = connect(
  mapStateToProps,
  null
)(
  reduxForm({
    form: 'HolidaySettings'
  })(HolidaySettingsComponent)
);

export default HolidaySettings;
