import React from 'react';
import PropTypes from 'prop-types';
import Switch from '../../shared/components/controls/Switch';

class WeekendSettings extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      weekends: []
    };
  }

  componentWillReceiveProps(nextProps) {
    this.setState({ weekends: nextProps.weekends });
  }

  componentDidMount() {
    this.setState({ weekends: this.props.weekends });
  }

  updateWeekendConfig(newConfig) {
    let config = this.state.weekends.find(item => item.key === newConfig.key);
    config.value = newConfig.value;
    return config;
  }

  onChange(config) {
    const newWeekendsConfig = this.updateWeekendConfig(config);
    if (this.props.onchange) {
      this.props.onchange(newWeekendsConfig);
    }
  }

  getWeekendCheckboxes() {
    if (this.state.weekends.length > 0) {
      return this.state.weekends.map(item => {
        return (
          <div key={`checkbox-${item.id}`}>
            <Switch checked={item.value} value={item.key} onChange={this.onChange.bind(this)} />
          </div>
        );
      });
    }
  }

  render() {
    return (
      <div className='weekend-config'>
        <label className='config-heading'>Allow Portion room to be opened</label>
        <div className='weekends'>{this.getWeekendCheckboxes()}</div>
      </div>
    );
  }
}

WeekendSettings.propTypes = {
  weekends: PropTypes.array.isRequired,
  onchange: PropTypes.func.isRequired
};

export default WeekendSettings;
