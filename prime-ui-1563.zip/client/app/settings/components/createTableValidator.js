import _ from 'lodash';
import { SubmissionError } from 'redux-form';
import { isStopTimeAfterStartTime, validate, validateTime } from '../../shared/formValidations';
import { CREATE_TABLE_ERROR_MESSAGE, MUST_BE_UNIQUE_MESSAGE } from '../../../config/errorMessage';

export const validateSubmission = values => {
  const { tableOpenTime, tableCloseTime } = values;
  let errors = {};

  errors = validate(errors, tableOpenTime, 'tableOpenTime', [validateTime]);
  errors = validate(errors, tableCloseTime, 'tableCloseTime', [validateTime]);

  if (_.isEmpty(errors)) {
    errors = validate(errors, tableCloseTime, 'tableCloseTime', [
      isStopTimeAfterStartTime(tableOpenTime, 'Close time should be greater than open time')
    ]);
  }

  if (!_.isEmpty(errors)) {
    throw new SubmissionError(Object.assign({}, errors, { _error: 'Submission Failed!' }));
  }

  return errors;
};

export const validateField = values => {
  let errors = {};
  const { tableOpenTime, tableCloseTime } = values;

  errors = validate(errors, tableOpenTime, 'tableOpenTime', [validateTime]);
  errors = validate(errors, tableCloseTime, 'tableCloseTime', [validateTime]);

  if (_.isEmpty(errors)) {
    errors = validate(errors, tableCloseTime, 'tableCloseTime', [
      isStopTimeAfterStartTime(tableOpenTime, 'Close time should be greater than open time')
    ]);
  }

  return errors;
};

export const processTableErrorResponse = errorResponse => {
  const errorDetails = _.get(errorResponse, 'error.details', []);
  let errors = {};

  const errorDetailInfo = errorDetails.find(detail => !_.isEmpty(detail.field) === true);
  const errorDetailStatusText = !_.isEmpty(errorResponse.statusText) === true;
  const issue = errorDetailInfo
    ? errorDetailInfo.issue
    : errorDetailStatusText
    ? errorResponse.statusText
    : '';

  switch (issue) {
    case 'UNIQUE':
      errors = {
        tableCode: MUST_BE_UNIQUE_MESSAGE,
        ...errors
      };
      break;
    default:
      errors = { tableCode: CREATE_TABLE_ERROR_MESSAGE, ...errors };
      break;
  }

  if (!_.isEmpty(errors)) {
    throw new SubmissionError({ ...errors });
  }
};
