import React, { Fragment } from 'react';
import PropTypes from 'prop-types';
import { Button, Table, Form, Icon } from 'semantic-ui-react';
import { Field, reduxForm } from 'redux-form';
import { connect } from 'react-redux';
import {
  allowToEditHoliday,
  cancelEditingHoliday,
  deleteHoliday,
  editHoliday,
  getHolidays
} from '../actions/settingsActions';
import { bindActionCreators } from 'redux';
import FormElement from '../../shared/FormElement';
import { isHolidayDateInValid } from './HolidaySettings';
import _ from 'lodash';

const getTableColumns = [
  {
    key: 'date',
    pid: 'Holiday-date',
    width: '4',
    headerText: 'Date',
    textAlign: 'left'
  },
  {
    key: 'description',
    pid: 'Holiday-description',
    width: '8',
    headerText: 'Description',
    textAlign: 'left'
  },
  {
    key: 'edit',
    pid: 'Holiday-edit',
    width: '2',
    headerText: '',
    textAlign: 'right'
  },
  {
    key: 'remove',
    pid: 'Holiday-remove',
    width: '2',
    headerText: '',
    textAlign: 'left'
  }
];

const bigButtons = {
  fontSize: '1.2rem',
  cursor: 'pointer'
};

const EditableHolidayRow = ({ columns, holiday, cancelEditingHoliday, submitting }) => {
  return (
    <Fragment>
      {columns.map((column, index) => (
        <Table.Cell
          pid={`${column.pid}-${index}`}
          key={`${column.pid}-${index}`}
          textAlign={column.textAlign}
          width={column.width}
        >
          {column.key !== 'remove' && column.key !== 'edit' ? (
            <Field
              name={column.key}
              component={FormElement}
              as={Form.Input}
              autoFocus={column.key === 'date'}
              type='text'
              placeholder={holiday.data[column.key]}
              maxLength={column.key === 'description' ? 30 : null}
            />
          ) : column.key === 'remove' ? (
            <Button
              icon
              size={'small'}
              onClick={() => {
                cancelEditingHoliday();
              }}
            >
              <Icon name='close' pid={'holiday-table__cross'} />
            </Button>
          ) : (
            <Button icon size={'small'} type={'submit'} loading={submitting}>
              <Icon name='check' pid={'holiday-table__check'} />
            </Button>
          )}
        </Table.Cell>
      ))}
    </Fragment>
  );
};

export class HolidayTableComponent extends React.Component {
  constructor(props) {
    super(props);

    this.submit = this.submit.bind(this);
  }

  componentWillUnmount() {
    const { cancelEditingHoliday } = this.props;
    cancelEditingHoliday();
  }

  async submit(values) {
    const { editableHoliday, getHolidays, reset, editHoliday } = this.props;

    isHolidayDateInValid(values, this.props);
    const successfulEdit = await editHoliday(editableHoliday.id, values);
    if (successfulEdit) {
      reset();
      getHolidays();
    }
  }

  render() {
    const {
      holidays,
      holidayAddReset,
      deleteHoliday,
      allowToEditHoliday,
      cancelEditingHoliday,
      editableHoliday,
      allowedToEdit,
      submitting,
      handleSubmit
    } = this.props;
    return (
      <Form size={'large'} className='table-wrapper' onSubmit={handleSubmit(this.submit)}>
        <Table size='large' columns={16} fixed selectable>
          <Table.Header>
            <Table.Row>
              <Table.HeaderCell
                key={'date'}
                pid={'holiday__header-date'}
                textAlign={'left'}
                width={4}
              >
                Date
              </Table.HeaderCell>
              <Table.HeaderCell
                key={'description'}
                pid={'holiday__header-description'}
                textAlign={'left'}
                width={8}
              >
                Description
              </Table.HeaderCell>
              <Table.HeaderCell
                key={'edit'}
                pid={'holiday__header-edit'}
                textAlign={'right'}
                width={2}
              >
                &nbsp;
              </Table.HeaderCell>
              <Table.HeaderCell
                key={'remove'}
                pid={'holiday__header-remove'}
                textAlign={'left'}
                width={2}
              >
                &nbsp;
              </Table.HeaderCell>
            </Table.Row>
          </Table.Header>
          <Table.Body key={'table-content-holidays'}>
            {holidays.map((holiday, index) => (
              <Table.Row verticalAlign='top' pid={`holiday-${index}`} key={`holiday-${index}`}>
                {allowedToEdit && holiday.data.id === editableHoliday.id ? (
                  <EditableHolidayRow
                    holiday={holiday}
                    columns={getTableColumns}
                    submitting={submitting}
                    cancelEditingHoliday={cancelEditingHoliday}
                  />
                ) : (
                  getTableColumns.map((column, index) => (
                    <Table.Cell
                      pid={`${column.pid}-${index}`}
                      key={`${column.pid}-${index}`}
                      textAlign={column.textAlign}
                      width={column.width}
                    >
                      {column.key !== 'remove' && column.key !== 'edit' ? (
                        holiday.data[column.key]
                      ) : allowedToEdit ? null : column.key === 'remove' ? (
                        <i
                          className='icon-minus'
                          style={bigButtons}
                          onClick={() => {
                            deleteHoliday(holiday.data.id);
                          }}
                        />
                      ) : (
                        <i
                          className='icon-edit'
                          style={bigButtons}
                          onClick={() => {
                            holidayAddReset();
                            allowToEditHoliday(holiday.data);
                          }}
                        />
                      )}
                    </Table.Cell>
                  ))
                )}
              </Table.Row>
            ))}
          </Table.Body>
        </Table>
      </Form>
    );
  }
}

EditableHolidayRow.propTypes = {
  columns: PropTypes.array,
  cancelEditingHoliday: PropTypes.func,
  deleteHoliday: PropTypes.func,
  editableHoliday: PropTypes.object,
  editHoliday: PropTypes.func,
  handleSubmit: PropTypes.func,
  holiday: PropTypes.object,
  submitting: PropTypes.bool,
  reset: PropTypes.func
};

HolidayTableComponent.propTypes = {
  allowToEditHoliday: PropTypes.func,
  allowedToEdit: PropTypes.bool,
  cancelEditingHoliday: PropTypes.func,
  deleteHoliday: PropTypes.func,
  editableHoliday: PropTypes.object,
  editHoliday: PropTypes.func,
  handleSubmit: PropTypes.func,
  holidays: PropTypes.array.isRequired,
  submitting: PropTypes.bool,
  reset: PropTypes.func,
  holidayAddReset: PropTypes.func
};

const mapStateToProps = state => ({
  initialValues: {
    date: _.get(state, 'settingsInfo.editableHoliday.date', ''),
    description: _.get(state, 'settingsInfo.editableHoliday.description', '')
  },
  editableHoliday: state.settingsInfo.editableHoliday,
  allowedToEdit: state.settingsInfo.allowedToEdit,
  today: state.operatingDates ? state.operatingDates.today : undefined
});

const mapDispatchToProps = dispatch =>
  bindActionCreators(
    {
      allowToEditHoliday,
      deleteHoliday,
      cancelEditingHoliday,
      editHoliday,
      getHolidays
    },
    dispatch
  );

const HolidayTable = connect(
  mapStateToProps,
  mapDispatchToProps
)(
  reduxForm({
    form: 'HolidayTable',
    enableReinitialize: true
  })(HolidayTableComponent)
);

export default HolidayTable;
