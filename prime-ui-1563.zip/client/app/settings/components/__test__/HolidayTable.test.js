import { mount, shallow } from 'enzyme';
import React from 'react';
import { Provider } from 'react-redux';
import { createReduxStore } from '../../../store';
import { HolidayTableComponent } from '../HolidayTable';
import { reduxForm } from 'redux-form';

jest.mock('../../../shared/api/settingsResources');
jest.mock('../../actions/settingsActions');

const christmas = {
  index: 2,
  data: {
    date: '2018-12-25',
    description: 'Christmas',
    id: 1234
  }
};

const mlk = {
  index: 0,
  data: {
    date: '2018-01-15',
    description: 'Martin Luther King Jr. Day',
    id: 2341
  }
};

const independenceDay = {
  index: 1,
  data: {
    date: '2018-07-04',
    description: 'Independence Day',
    id: 3412
  }
};

const holidays = [mlk, independenceDay, christmas];

describe('HolidayTable', () => {
  let wrapper, deleteHolidaySpy, allowToEditHolidaySpy, DecoratedComponent, holidayAddResetSpy;

  beforeEach(() => {
    deleteHolidaySpy = jest.fn();
    allowToEditHolidaySpy = jest.fn();
    holidayAddResetSpy = jest.fn();
    DecoratedComponent = reduxForm({ form: 'testForm' })(HolidayTableComponent);
    wrapper = mount(
      <Provider store={createReduxStore({})}>
        <DecoratedComponent
          holidays={holidays}
          deleteHoliday={deleteHolidaySpy}
          allowToEditHoliday={allowToEditHolidaySpy}
          holidayAddReset={holidayAddResetSpy}
        />
      </Provider>
    );
  });

  test('should render expected rows', () => {
    jestExpect(wrapper.find('tbody').find('tr').length).toEqual(3);
  });

  test('should call deleteHoliday on minus button click', () => {
    wrapper
      .find('.icon-minus')
      .at(0)
      .simulate('click');

    jestExpect(deleteHolidaySpy).toBeCalledWith(mlk.data.id);
  });

  test('should call editSelectedHoliday on edit button click', () => {
    wrapper
      .find('.icon-edit')
      .at(0)
      .simulate('click');
    jestExpect(holidayAddResetSpy).toBeCalledTimes(1);
    jestExpect(allowToEditHolidaySpy).toBeCalledWith(mlk.data);
  });

  describe('editable table', () => {
    test('should render formFields and yes and no check boxes when allowed to edit', () => {
      wrapper = mount(
        <Provider store={createReduxStore({})}>
          <DecoratedComponent
            holidays={holidays}
            deleteHoliday={deleteHolidaySpy}
            editableHoliday={christmas.data}
            allowedToEdit={true}
            allowToEditHoliday={allowToEditHolidaySpy}
          />
        </Provider>
      );

      const formFieldsOnRowThree = wrapper
        .find('tbody')
        .find('tr')
        .at(2)
        .find('input');
      const checkboxAccept = wrapper.find('i[pid="holiday-table__check"]');
      const checkboxCancel = wrapper.find('i[pid="holiday-table__cross"]');

      jestExpect(checkboxAccept.exists()).toEqual(true);
      jestExpect(checkboxCancel.exists()).toEqual(true);
      jestExpect(formFieldsOnRowThree.length).toEqual(2);
    });

    test('should call cancelEditingHoliday on close click', () => {
      let cancelEditingSpy = jest.fn();
      wrapper = mount(
        <Provider store={createReduxStore({})}>
          <DecoratedComponent
            holidays={holidays}
            deleteHoliday={deleteHolidaySpy}
            editableHoliday={christmas.data}
            allowedToEdit={true}
            allowToEditHoliday={allowToEditHolidaySpy}
            cancelEditingHoliday={cancelEditingSpy}
          />
        </Provider>
      );

      wrapper.find('i[pid="holiday-table__cross"]').simulate('click');

      jestExpect(cancelEditingSpy).toBeCalledTimes(1);
    });

    test('should call handleSubmit, on check click', () => {
      let handleSubmitSpy = jest.fn();
      wrapper = mount(
        <Provider store={createReduxStore({})}>
          <DecoratedComponent
            holidays={holidays}
            deleteHoliday={deleteHolidaySpy}
            editableHoliday={christmas.data}
            allowedToEdit={true}
            allowToEditHoliday={allowToEditHolidaySpy}
            handleSubmit={handleSubmitSpy}
            cancelEditingHoliday={() => {}}
          />
        </Provider>
      );

      wrapper.find('form').simulate('submit');
      jestExpect(handleSubmitSpy).toBeCalledTimes(1);
    });

    test('should not render edit and remove buttons when edit field is displayed', () => {
      wrapper = mount(
        <Provider store={createReduxStore({})}>
          <DecoratedComponent
            holidays={holidays}
            deleteHoliday={deleteHolidaySpy}
            editableHoliday={christmas.data}
            allowedToEdit={true}
            allowToEditHoliday={allowToEditHolidaySpy}
            cancelEditingHoliday={() => {}}
          />
        </Provider>
      );

      const descriptionEditRow = wrapper
        .find('tbody')
        .find('tr')
        .at(2)
        .find('input')
        .at(1);

      jestExpect(descriptionEditRow.props().maxLength).toEqual(30);
    });

    describe('on render', () => {
      test('should render description input field with max length of 30 characters', () => {
        wrapper = mount(
          <Provider store={createReduxStore({})}>
            <DecoratedComponent
              holidays={holidays}
              deleteHoliday={deleteHolidaySpy}
              editableHoliday={christmas.data}
              allowedToEdit={true}
              allowToEditHoliday={allowToEditHolidaySpy}
              cancelEditingHoliday={() => {}}
            />
          </Provider>
        );
        jestExpect(
          wrapper
            .find('form')
            .at(0)
            .find('input')
            .at(1)
            .props().maxLength
        ).toEqual(30);
      });

      test('should call cancelEditingHoliday on unmount', () => {
        let cancelEditingSpy = jest.fn();
        wrapper = shallow(
          <HolidayTableComponent
            holidays={holidays}
            cancelEditingHoliday={cancelEditingSpy}
            handleSubmit={() => {}}
          />
        );

        wrapper.unmount();

        jestExpect(cancelEditingSpy).toBeCalledTimes(1);
      });
    });
  });
});
