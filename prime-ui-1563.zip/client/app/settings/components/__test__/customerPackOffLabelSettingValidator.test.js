import {
  processErrorResponse,
  touchErrorFields,
  validateFields
} from '../customerPackOffLabelSettingValidator';

describe('customerPackOffLabelSettingValidator', () => {
  let props;

  beforeEach(() => {
    props = { touch: () => {} };
  });

  test('should return empty object when values are empty', () => {
    const errors = validateFields({}, props);

    jestExpect(errors).toEqual({});
  });

  describe('subprimal validation', () => {
    test('should return empty object when no subprimals', () => {
      const errors = validateFields({ subPrimals: [] }, props);

      jestExpect(errors).toEqual({});
    });

    test('should pass all validations when valid', () => {
      const values = {
        subPrimals: [
          { subPrimalCode: '123', dateValue: 1 },
          { subPrimalCode: '124c', dateValue: 2 }
        ]
      };

      const errors = validateFields(values, props);

      jestExpect(errors).toEqual({});
    });

    test('check for duplicate subprimal codes', () => {
      const values = {
        subPrimals: [
          { subPrimalCode: '124', dateValue: 10 },
          { subPrimalCode: '123', dateValue: 1 },
          { subPrimalCode: '123', dateValue: 2 }
        ]
      };

      const errors = validateFields(values, props);

      jestExpect(errors).toEqual({
        subPrimals: [
          {},
          { subPrimalCode: 'Subprimal is already listed' },
          { subPrimalCode: 'Subprimal is already listed' }
        ]
      });
    });

    test('check for duplicate subprimal codes is case insensitive', () => {
      const values = {
        subPrimals: [
          { subPrimalCode: '109D', dateValue: 1 },
          { subPrimalCode: '109d', dateValue: 2 }
        ]
      };

      const errors = validateFields(values, props);

      jestExpect(errors).toEqual({
        subPrimals: [
          { subPrimalCode: 'Subprimal is already listed' },
          { subPrimalCode: 'Subprimal is already listed' }
        ]
      });
    });

    test('should show date value required error when missing date value', () => {
      const values = {
        subPrimals: [
          { subPrimalCode: '123', dateValue: '' },
          { subPrimalCode: '125', dateValue: 3 }
        ]
      };

      const errors = validateFields(values, props);

      jestExpect(errors).toEqual({ subPrimals: [{ dateValue: 'Required' }, {}] });
    });

    test('should show date value whole number error when date value contains non-number', () => {
      const values = {
        subPrimals: [
          { subPrimalCode: '123', dateValue: 12.4 },
          { subPrimalCode: '125', dateValue: '123abc' }
        ]
      };

      const errors = validateFields(values, props);

      jestExpect(errors).toEqual({
        subPrimals: [
          { dateValue: 'Only whole number characters' },
          { dateValue: 'Only whole number characters' }
        ]
      });
    });

    test('should show date value not in range error when date value is not between 1 and 99', () => {
      const values = {
        subPrimals: [
          { subPrimalCode: '123', dateValue: 0 },
          { subPrimalCode: '125', dateValue: 100 }
        ]
      };

      const errors = validateFields(values, props);

      jestExpect(errors).toEqual({
        subPrimals: [
          { dateValue: 'Date value should be between 1 and 99' },
          { dateValue: 'Date value should be between 1 and 99' }
        ]
      });
    });

    test('should touch error field when subprimal code has errors', () => {
      const touch = jest.fn();
      const subPrimalCodeArrayErrors = [
        { subPrimalCode: 'Subprimal is already listed' },
        { subPrimalCode: 'Subprimal is already listed' }
      ];
      touchErrorFields(subPrimalCodeArrayErrors, touch);

      jestExpect(touch).toHaveBeenCalledWith(
        'subPrimals[0].subPrimalCode',
        'subPrimals[1].subPrimalCode'
      );
    });
  });

  describe('customer specific item numbers', () => {
    test('should return empty object when no values', () => {
      const errors = validateFields({ customerSpecificItemNumbers: [] }, props);

      jestExpect(errors).toEqual({});
    });

    test('should return empty object when customer specific item number fields are blank', () => {
      const errors = validateFields(
        { customerSpecificItemNumbers: [{ productCode: '', itemNumber: '' }] },
        props
      );

      jestExpect(errors).toEqual({});
    });

    test('should pass all validations when customerSpecificItemNumbers are valid', () => {
      const values = {
        customerSpecificItemNumbers: [
          { productCode: '12345678', itemNumber: 'abcd1234' },
          { productCode: '4102218', itemNumber: 'buzzword' }
        ]
      };

      const errors = validateFields(values, props);

      jestExpect(errors).toEqual({});
    });

    test('should show errors when productCode are duplicated', () => {
      const productCode = '12345678';
      const values = {
        customerSpecificItemNumbers: [
          { productCode: '1961172', itemNumber: 'asdf' },
          { productCode, itemNumber: 'abcd1234' },
          { productCode, itemNumber: 'buzzword' }
        ]
      };

      const errors = validateFields(values, props);

      jestExpect(errors).toEqual({
        customerSpecificItemNumbers: [
          {},
          { productCode: 'Duplicate item number' },
          { productCode: 'Duplicate item number' }
        ]
      });
    });

    test('productCode and item number are required', () => {
      const values = {
        customerSpecificItemNumbers: [
          { productCode: '1961172', itemNumber: '' },
          { productCode: '', itemNumber: 'asdf' }
        ]
      };

      const errors = validateFields(values, props);

      jestExpect(errors).toEqual({
        customerSpecificItemNumbers: [{ itemNumber: 'Required' }, { productCode: 'Required' }]
      });
    });

    describe('processErrorResponse', () => {
      test('should parse the error response', () => {
        const errorResponse = {
          timestamp: 1561404137242,
          method: 'POST',
          path: '/api/customers/setup',
          status: 0,
          statusText: '',
          exceptionClass: 'org.opensaml.xml.validation.ValidationException',
          exceptionMessage:
            'org.springframework.web.multipart.support.StandardMultipartHttpServletRequest$StandardMultipartFile@439e136 is Maximum file size exceeded. Current restriction is 1MB for setupCustomer.file'
        };

        try {
          processErrorResponse(errorResponse);
        } catch ({ errors }) {
          jestExpect(errors).toEqual({
            fileImporter: 'Image size must be less than 1MB.',
            _error: 'Customer Setup Failed'
          });
        }
      });

      test('should parse the error response to handle invalid file', () => {
        const errorResponse = {
          exceptionClass: 'org.opensaml.xml.validation.ValidationException',
          exceptionMessage:
            'org.springframework.web.multipart.support.StandardMultipartHttpServletRequest$StandardMultipartFile@51f3279e is Invalid file type. Only JPG, JPEG, PNG or BMP images are allowed. for setupCustomer.file',
          method: 'POST',
          path: '/api/customers/setup',
          status: 0,
          statusText: '',
          timestamp: 1561484647438
        };

        try {
          processErrorResponse(errorResponse);
        } catch ({ errors }) {
          jestExpect(errors).toEqual({
            fileImporter: 'Invalid file type. Only JPG, JPEG, PNG or BMP images are allowed.',
            _error: 'Customer Setup Failed'
          });
        }
      });
    });
  });
});
