import { mount } from 'enzyme';
import React from 'react';
import WeekendSettings from '../WeekendSettings';

const saturday = {
  key: 'saturday',
  value: true,
  id: 1
};

const sunday = {
  key: 'sunday',
  value: false,
  id: 2
};
const weekends = [saturday, sunday];

describe('WeekendSettings', () => {
  let wrapper;

  const onChange = jest.fn();

  beforeEach(() => {
    wrapper = mount(<WeekendSettings weekends={weekends} onchange={onChange} />);
  });

  describe('on render', () => {
    test('should render weekends config', () => {
      jestExpect(wrapper.find('.weekend-config').exists()).toBe(true);

      let weekends = wrapper.find('.switch-control');
      let saturday = weekends.get(0).props.children[0];
      let sunday = weekends.get(1).props.children[0];
      jestExpect(saturday.props.checked).toEqual(true);
      jestExpect(sunday.props.checked).toEqual(false);
    });

    test('should call onChange when click the checkbox', () => {
      wrapper
        .find('input')
        .first()
        .simulate('change', {});
      jestExpect(onChange).toHaveBeenCalledWith({ id: 1, key: 'saturday', value: false });
    });
  });
});
