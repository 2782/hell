import _ from 'lodash';
import { SubmissionError } from 'redux-form';
import {
  exactLength,
  productionProduct,
  productWithPricingModel,
  productWithWeight,
  required,
  validate,
  wholeNumber
} from '../../shared/formValidations';
import {
  CREATE_HOUSE_PAR_MESSAGE,
  NOT_A_PRODUCTION_PRODUCT,
  PRODUCT_LACKS_PRICING_MODEL,
  UPDATE_HOUSE_PAR_MESSAGE
} from '../../../config/errorMessage';

const atLeastOneRequired = (arrValue, fieldName) => {
  const nonZeroConfig = _.find(arrValue, item => {
    return item !== '' && parseInt(item) !== 0;
  });
  if (!nonZeroConfig) {
    return {
      [fieldName]: 'At least one field required'
    };
  }
};

export const validateSubmission = (
  values,
  { productIsProduction, productHasPricingModel, product }
) => {
  const { productCode } = values;
  const parConfig = _.values(_.omit(values, ['productCode', 'id']));
  const maxWeight = _.get(product, 'maxWeight', '');
  const minWeight = _.get(product, 'minWeight', '');
  const update = !!values.id;

  let errors = {};

  errors = validate(errors, productCode, 'productCode', [
    required,
    wholeNumber,
    exactLength(7),
    productionProduct(productCode, productIsProduction),
    productWithPricingModel(productCode, productHasPricingModel),
    productWithWeight(maxWeight, minWeight)
  ]);
  errors = validate(errors, parConfig, 'monday', [atLeastOneRequired]);

  if (_.isEmpty(errors)) {
    return;
  }

  throw new SubmissionError({
    ...errors,
    _error: update ? UPDATE_HOUSE_PAR_MESSAGE : CREATE_HOUSE_PAR_MESSAGE
  });
};

export const processProductCodeError = (errors, errorDetails, values, update) => {
  const detail = errorDetails.find(detail => detail.field === 'productCode');
  if (!detail) {
    return errors;
  }

  switch (detail.issue) {
    case 'PRODUCT_IS_NOT_PRODUCTION_ITEM':
      errors = {
        ...errors,
        productCode: NOT_A_PRODUCTION_PRODUCT
      };
      break;
    case 'PRODUCT_LACKS_PRICING_MODEL':
      errors = {
        ...errors,
        productCode: PRODUCT_LACKS_PRICING_MODEL
      };
      break;
    case 'UNIQUE':
      errors = {
        ...errors,
        productCode: UPDATE_HOUSE_PAR_MESSAGE
      };
      break;
    default:
      errors = {
        ...errors,
        productCode: update ? UPDATE_HOUSE_PAR_MESSAGE : CREATE_HOUSE_PAR_MESSAGE
      };
      break;
  }

  return errors;
};

export const processErrorResponse = (errorResponse, values) => {
  const { update } = errorResponse;
  const errorDetails = _.get(errorResponse, 'error.details', []);
  let errors = {};

  errors = processProductCodeError(errors, errorDetails, values, update);

  throw new SubmissionError({
    ...errors,
    _error: update ? UPDATE_HOUSE_PAR_MESSAGE : CREATE_HOUSE_PAR_MESSAGE
  });
};
