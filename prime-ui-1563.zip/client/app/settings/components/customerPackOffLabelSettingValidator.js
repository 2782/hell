import * as _ from 'lodash';
import { getDuplicatedSubset } from '../../shared/util/dataUtil';
import {
  isAlreadyExisted,
  isInRange,
  required,
  validate,
  wholeNumber
} from '../../shared/formValidations';
import { SubmissionError } from 'redux-form';

const duplicateMessage = 'Duplicate item number';

export const validateFields = ({ subPrimals, customerSpecificItemNumbers }, props) => {
  const { touch } = props;
  let errors = {};

  validateSubPrimals(errors, subPrimals, touch);
  validateCustomerSpecificItemNumber(errors, customerSpecificItemNumbers, touch);

  return errors;
};

function validateCustomerSpecificItemNumber(errors, customerSpecificItemNumbers) {
  const filteredItemNumbers = _.filter(
    customerSpecificItemNumbers,
    item => !_.isEmpty(item) && (!_.isEmpty(item.productCode) || !_.isEmpty(item.itemNumber))
  );

  if (_.isEmpty(filteredItemNumbers)) {
    return;
  }

  const customerSpecificItemNumberErrors = [];
  const duplicateProductCodes = getDuplicatedSubset(
    filteredItemNumbers.map(item => item.productCode)
  );

  filteredItemNumbers.forEach((item, index) => {
    let customerSpecificError = {};

    customerSpecificError = validate(customerSpecificError, item.productCode, 'productCode', [
      isAlreadyExisted(duplicateProductCodes, duplicateMessage),
      required
    ]);

    customerSpecificError = validate(customerSpecificError, item.itemNumber, 'itemNumber', [
      required
    ]);

    customerSpecificItemNumberErrors[index] = customerSpecificError;
  });

  if (_.filter(customerSpecificItemNumberErrors, row => !_.isEmpty(row)).length > 0) {
    errors.customerSpecificItemNumbers = customerSpecificItemNumberErrors;
  }
}

function validateSubPrimals(errors, subPrimals, touch) {
  const filteredSubPrimals = _.filter(
    subPrimals,
    value => value && (!_.isEmpty(value) && value['subPrimalCode'])
  );

  if (_.isEmpty(filteredSubPrimals)) {
    return;
  }

  const subPrimalCodeArrayErrors = [];
  const duplicateSubPrimals = getDuplicatedSubset(
    filteredSubPrimals.map(subPrimal => subPrimal.subPrimalCode.toUpperCase())
  );

  filteredSubPrimals.forEach((item, itemIndex) => {
    let subPrimalErrors = {};

    subPrimalErrors = validate(subPrimalErrors, item.subPrimalCode.toUpperCase(), 'subPrimalCode', [
      isAlreadyExisted(duplicateSubPrimals, 'Subprimal is already listed')
    ]);

    subPrimalErrors = validate(subPrimalErrors, item.dateValue, 'dateValue', [
      required,
      wholeNumber,
      isInRange(0, 100, 'Date value should be between 1 and 99')
    ]);

    subPrimalCodeArrayErrors[itemIndex] = subPrimalErrors;
  });

  if (_.filter(subPrimalCodeArrayErrors, row => !_.isEmpty(row)).length > 0) {
    errors.subPrimals = subPrimalCodeArrayErrors;
    touchErrorFields(subPrimalCodeArrayErrors, touch);
  }
}

export const touchErrorFields = (subPrimalCodeArrayErrors, touch) => {
  const fieldToTouch = [];
  subPrimalCodeArrayErrors.forEach((subPrimalCodeError, index) => {
    if (subPrimalCodeError.subPrimalCode) {
      fieldToTouch.push(`subPrimals[${index}].subPrimalCode`);
    }
  });
  touch(...fieldToTouch);
};

export const processErrorResponse = errorResponse => {
  let errors = {};

  const message = errorResponse.exceptionMessage;
  if (message) {
    if (message.includes('Maximum file size exceeded')) {
      errors = {
        ...errors,
        fileImporter: 'Image size must be less than 1MB.'
      };
    } else if (message.includes('Invalid file type')) {
      errors = {
        ...errors,
        fileImporter: 'Invalid file type. Only JPG, JPEG, PNG or BMP images are allowed.'
      };
    }
  }

  throw new SubmissionError(Object.assign({}, { _error: 'Customer Setup Failed' }, errors));
};
