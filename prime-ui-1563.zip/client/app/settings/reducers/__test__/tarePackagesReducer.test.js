import tarePackagesReducer, {
  createBoxTypeByIdSelector,
  createFilmTypeByIdSelector
} from '../tarePackagesReducer';
import {
  CLEAR_TARE_PACKAGES,
  GRABBED_BOX_TYPES,
  GRABBED_DEFAULT_TARE_PACKAGE,
  GRABBED_FILM_TYPES,
  GRABBED_TARE_PACKAGE,
  GRABBED_TARE_PACKAGES
} from '../../actions/tarePackagesActionTypes';
import boxTypeFactory from '../../../../test-factories/boxTypeFactory';
import filmTypeFactory from '../../../../test-factories/filmTypeFactory';

const tarePackageResponse = {
  boxType: {
    boxDescription: 'Sysco Classic',
    packagingTare: 1.04
  },
  filmType: {
    filmDescription: 'Men in Black',
    filmTare: 1.44
  },
  defaulted: false
};

describe('tarePackagingReducer', () => {
  let initState;

  beforeEach(() => {
    initState = {
      boxTypes: [],
      filmTypes: [],
      tarePackages: null,
      confirmationShowing: false,
      tarePackage: null,
      defaultTarePackage: null
    };
  });

  test('should return initial state when state is not defined', () => {
    jestExpect(tarePackagesReducer(undefined, { type: 'IM FAKE' })).toEqual(initState);
  });

  describe('GRABBED_BOX_TYPE', () => {
    const boxTypesResponse = [
      {
        boxDescription: 'black #10',
        packagingTare: 1.062
      }
    ];
    test('should change boxTypeOptions in state to response when action is called', () => {
      const stateWithBoxTypes = {
        ...initState,
        boxTypes: boxTypesResponse
      };

      jestExpect(
        tarePackagesReducer(initState, { type: GRABBED_BOX_TYPES, payload: boxTypesResponse })
      ).toEqual(stateWithBoxTypes);
    });
  });

  describe('GRABBED_FILM_TYPE', () => {
    const filmTypesResponse = [
      {
        filmDescription: 'Men in Black',
        filmTare: 1.44
      }
    ];

    test('should change filmTypeOptions in state to response when action is called', () => {
      const stateWithFilmTypes = {
        ...initState,
        filmTypes: filmTypesResponse
      };

      jestExpect(
        tarePackagesReducer(initState, { type: GRABBED_FILM_TYPES, payload: filmTypesResponse })
      ).toEqual(stateWithFilmTypes);
    });
  });

  describe('GRABBED_TARE_PACKAGES', () => {
    const tarePackagesResponse = [
      {
        boxType: {
          boxDescription: 'Sysco Classic',
          packagingTare: 1.04
        },
        filmType: {
          filmDescription: 'Men in Black',
          filmTare: 1.44
        },
        defaulted: false
      }
    ];

    test('should change filmTypeOptions in state to response when action is called', () => {
      const stateWithTarePackages = {
        ...initState,
        tarePackages: tarePackagesResponse
      };

      jestExpect(
        tarePackagesReducer(initState, {
          type: GRABBED_TARE_PACKAGES,
          payload: tarePackagesResponse
        })
      ).toEqual(stateWithTarePackages);
    });
  });

  describe('show/hide confirmation modal', () => {
    test('should change confirmationShowing to true when action is called', () => {
      const stateWithConfirmationHidden = {
        ...initState,
        confirmationShowing: false
      };

      jestExpect(
        tarePackagesReducer(
          { ...initState, confirmationShowing: true },
          { type: 'HIDE_TARE_PACKAGE_CONFIRMATION' }
        )
      ).toEqual(stateWithConfirmationHidden);
    });

    test('should change confirmationShowing to false when action is called', () => {
      const stateWithConfirmationShowing = {
        ...initState,
        confirmationShowing: true
      };

      jestExpect(
        tarePackagesReducer(initState, { type: 'SHOW_TARE_PACKAGE_CONFIRMATION' })
      ).toEqual(stateWithConfirmationShowing);
    });
  });

  describe('GRABBED_TARE_PACKAGE', () => {
    test('should get tare package when action is called', () => {
      const stateWithTarePackage = {
        ...initState,
        tarePackage: tarePackageResponse
      };

      jestExpect(
        tarePackagesReducer(initState, { type: GRABBED_TARE_PACKAGE, payload: tarePackageResponse })
      ).toEqual(stateWithTarePackage);
    });
  });

  describe('GRABBED_DEFAULT_TARE_PACKAGE', () => {
    test('should get default tare package when action is called', () => {
      const stateWithTarePackage = {
        ...initState,
        defaultTarePackage: tarePackageResponse
      };

      jestExpect(
        tarePackagesReducer(initState, {
          type: GRABBED_DEFAULT_TARE_PACKAGE,
          payload: tarePackageResponse
        })
      ).toEqual(stateWithTarePackage);
    });
  });

  describe('CLEAR_TARE_PACKAGES', () => {
    test('should reset to initial state when action is called', () => {
      jestExpect(tarePackagesReducer(initState, { type: CLEAR_TARE_PACKAGES })).toEqual(initState);
    });
  });

  describe('state selectors', () => {
    const boxTypes = [
      boxTypeFactory.build({
        boxDescription: 'black #10',
        boxTare: 1.062,
        id: 1231231
      }),
      boxTypeFactory.build({
        boxDescription: '#1',
        boxTare: 0.692,
        id: 1293443
      })
    ];

    const filmTypes = [
      filmTypeFactory.build({
        filmDescription: 'Grand Hotel',
        filmTare: 1.062,
        id: 12312
      }),
      filmTypeFactory.build({
        filmDescription: 'History of the World part 1',
        filmTare: 0.692,
        id: 12399
      })
    ];

    const state = { tarePackages: { boxTypes, filmTypes } };

    test('we can select a boxType object by id', () => {
      const getBoxTypeById = createBoxTypeByIdSelector(state);

      jestExpect(getBoxTypeById(1231231)).toEqual(boxTypes[0]);
    });

    test('if boxType not found we retrieve an empty object', () => {
      const getBoxTypeById = createBoxTypeByIdSelector(state);

      jestExpect(getBoxTypeById(123)).toBeUndefined();
    });

    test('we can select a filmType object by id', () => {
      const getFilmTypeById = createFilmTypeByIdSelector(state);

      jestExpect(getFilmTypeById(12399)).toEqual(filmTypes[1]);
    });

    test('if filmType is not found we retrieve an empty object', () => {
      const getFilmTypeById = createFilmTypeByIdSelector(state);

      jestExpect(getFilmTypeById(999)).toBeUndefined();
    });
  });
});
