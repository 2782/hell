import settingsReducer from '../settingsReducer';
import {
  ALL_CUSTOMERS_RECEIVED,
  EDITING_ALLOWED,
  CLEAR_CUSTOMER,
  CLEAR_HOUSE_PAR,
  CLEAR_PROFILE_INFO,
  CLEAR_STATION,
  CLEAR_TABLE,
  DELETE_HOLIDAY,
  GET_ACTIVE_FISCAL_CALENDAR,
  GET_CUSTOMER,
  GET_PROFILE,
  GRABBED_SUB_PRIMAL,
  HIDE_ERROR,
  EDITING_OVER,
  SHOW_ERROR,
  UPDATE_GRINDING_HOUSE_PARS,
  UPDATE_HOLIDAYS,
  UPDATE_HOUSE_PAR,
  UPDATE_HOUSE_PARS,
  UPDATE_ROOMS,
  UPDATE_STATION,
  UPDATE_STATIONS,
  UPDATE_TABLE,
  UPDATE_TABLES,
  UPDATE_WEEKENDS
} from '../../actions/settingsActionTypes';
import StationFactory from '../../../../test-factories/station';
import PortionRoomTableFactory from '../../../../test-factories/portionRoomTableFactory';
import { states } from '../../../shared/staticInfo/states';
import profileFactory from '../../../../test-factories/Profile';
import houseParFactory from '../../../../test-factories/housePar';
import customerFactory from '../../../../test-factories/customerFactory';

const profile = profileFactory.build();
const christmas = { date: '12-25-18', description: 'Christmas', id: 12 };
const mlk = { date: '01-15-18', description: 'Martin Luther King Jr. Day', id: 34 };
const independenceDay = { date: '07-04-18', description: 'Independence Day', id: 45 };
const thanksgiving = { date: '11-22-18', description: 'Thanksgiving', id: 56 };
const housePar = [houseParFactory.build()];
const housePars = [housePar];

describe('settingsReducer', () => {
  let initState, payload, result;
  beforeEach(() => {
    initState = {
      rooms: null,
      holidays: [],
      editableHoliday: {},
      weekends: [
        {
          key: 'saturday',
          value: false,
          id: 1
        },
        {
          key: 'sunday',
          value: false,
          id: 2
        }
      ],
      table: {},
      station: {},
      stations: null,
      tables: null,
      profile: {},
      states: states,
      housePars: [],
      housePar: {},
      error: { message: '', showing: false },
      grindingHousePars: [],
      activeFiscalCalendar: {},
      customer: {},
      customers: [],
      subPrimals: {},
      subPrimalsExist: {},
      allowedToEdit: false
    };
  });

  test('given new data when I inform the reducer about that data and the reducer does not know how to handle it then the reducer returns the existing data as is', () => {
    jestExpect(settingsReducer(undefined, { type: 'unexpect' })).toEqual(initState);
  });

  test('given a list of new holidays when I inform the reducer about that list and the previous list of holiday then the reducer replaces the old list with the new', () => {
    payload = [christmas, mlk, independenceDay];

    result = {
      ...initState,
      holidays: [
        { index: 0, data: christmas },
        { index: 1, data: mlk },
        { index: 2, data: independenceDay }
      ]
    };
    jestExpect(
      settingsReducer(initState, {
        type: UPDATE_HOLIDAYS,
        payload: payload
      })
    ).toEqual(result);
  });

  test('should set allowToEdit flag to true and save data when EDITING_ALLOWED is called', () => {
    const expectedState = {
      ...initState,
      editableHoliday: christmas,
      allowedToEdit: true
    };

    jestExpect(settingsReducer(initState, { type: EDITING_ALLOWED, payload: christmas })).toEqual(
      expectedState
    );
  });

  test('should set allowToEdit flag to false and remove editable data when EDITING_OVER is called', () => {
    const currentState = {
      ...initState,
      editableHoliday: christmas,
      allowedToEdit: true
    };

    jestExpect(settingsReducer(currentState, { type: EDITING_OVER })).toEqual(initState);
  });

  test('should update weekends state when handling UPDATE_WEEKENDS action', () => {
    let payload = [
      {
        key: 'sunday',
        value: false,
        id: 2
      },
      {
        key: 'saturday',
        value: true,
        id: 1
      }
    ];

    let result = {
      ...initState,
      weekends: [{ key: 'sunday', value: false, id: 2 }, { key: 'saturday', value: true, id: 1 }]
    };
    jestExpect(
      settingsReducer(initState, {
        type: UPDATE_WEEKENDS,
        payload: payload
      })
    ).toEqual(result);
  });

  test('given thanksgiving holiday when I ask the reducer to delete the holiday, it gives back the previous list of holidays without that holiday', () => {
    initState = {
      ...initState,
      holidays: [
        { index: 0, data: mlk },
        { index: 1, data: christmas },
        { index: 2, data: thanksgiving },
        { index: 3, data: independenceDay }
      ]
    };

    const holidaysWithoutThanksgiving = {
      ...initState,
      holidays: [
        { index: 0, data: mlk },
        { index: 1, data: christmas },
        { index: 3, data: independenceDay }
      ]
    };

    jestExpect(
      settingsReducer(initState, {
        type: DELETE_HOLIDAY,
        payload: thanksgiving.id
      })
    ).toEqual(holidaysWithoutThanksgiving);
  });

  test('given there is an error, when I tell the reducer about it, then I want the error state to be toggled on', () => {
    const expectedState = {
      ...initState,
      weekends: [
        {
          key: 'saturday',
          value: false,
          id: 1
        },
        {
          key: 'sunday',
          value: false,
          id: 2
        }
      ],
      error: { message: 'nonsense', showing: true }
    };

    jestExpect(
      settingsReducer(initState, {
        type: SHOW_ERROR,
        payload: { message: 'nonsense' }
      })
    ).toEqual(expectedState);
  });

  test('given a station, when I tell the reducer about it, then I want the reducer to return state with that station', () => {
    const station = { stationCode: 1, portionRoomTables: [3, 4, 6, 7], name: 'PHILIP', room: 'A' };

    const expectedState = {
      ...initState,
      station: station
    };

    jestExpect(
      settingsReducer(initState, {
        type: UPDATE_STATION,
        payload: station
      })
    ).toEqual(expectedState);
  });

  test('given that I want to clear station data, when I tell the reducer to, then I expect the reducer to return state with station empty', () => {
    const existingState = {
      ...initState,
      station: StationFactory.build()
    };

    jestExpect(
      settingsReducer(existingState, {
        type: CLEAR_STATION
      })
    ).toEqual(initState);
  });

  test('given station 1 and 2, when I tell the reducer about it, then I want the reducer to return station 1 and 2', () => {
    const station1 = { stationCode: 1, portionRoomTables: [3, 4, 6, 7], name: 'PHILIP', room: 'A' };

    const station2 = { stationCode: 2, portionRoomTables: [14, 17], name: 'MANUEL', room: 'A' };
    const expectedState = {
      ...initState,
      holidays: [],
      weekends: [
        {
          key: 'saturday',
          value: false,
          id: 1
        },
        {
          key: 'sunday',
          value: false,
          id: 2
        }
      ],
      rooms: null,
      station: {},
      stations: [station1, station2],
      tables: null,
      error: { message: '', showing: false }
    };

    jestExpect(
      settingsReducer(initState, {
        type: UPDATE_STATIONS,
        payload: [station1, station2]
      })
    ).toEqual(expectedState);
  });

  test('given table 1 and 2, when I tell the reducer about it, then I want the reducer to return table 1 and 2', () => {
    const table1 = {
      tableId: 1,
      tableCode: 1,
      stationId: 1,
      stationCode: 12,
      name: 'ENRIQUE ONE',
      room: 'A'
    };
    const table2 = {
      tableId: 2,
      tableCode: 2,
      stationId: 2,
      stationCode: 22,
      name: 'ENRIQUE TWO',
      room: 'A'
    };

    const expectedState = {
      ...initState,
      tables: [table1, table2]
    };
    jestExpect(
      settingsReducer(initState, {
        type: UPDATE_TABLES,
        payload: [table1, table2]
      })
    ).toEqual(expectedState);
  });

  test('given a table, when I tell the reducer about it, then I want the reducer to return state with that table', () => {
    const table = {
      tableCode: 1,
      station: {
        id: 1,
        stationCode: 12
      },
      tableDescription: 'STEAK'
    };

    const expectedState = {
      ...initState,
      table: table
    };

    jestExpect(
      settingsReducer(initState, {
        type: UPDATE_TABLE,
        payload: table
      })
    ).toEqual(expectedState);
  });

  test(
    'Given the table data needs to be cleared, when reducer gets an action, it ' +
      'returns state with table empty',
    () => {
      const existingState = {
        ...initState,
        table: PortionRoomTableFactory.build()
      };

      jestExpect(
        settingsReducer(existingState, {
          type: CLEAR_TABLE
        })
      ).toEqual(initState);
    }
  );

  test('given profile, when I tell reducer about it, then I want the reducer to return profile', () => {
    const expectedState = {
      ...initState,
      profile
    };
    jestExpect(
      settingsReducer(initState, {
        type: GET_PROFILE,
        payload: profile
      })
    ).toEqual(expectedState);
  });

  test('given room 1 and 2, when I tell the reducer about it, then I want the reducer to return room 1 and 2', () => {
    const room1 = {
      id: 2142140215,
      code: 'QB',
      description: 'QA TEST ROOM - B',
      portionRoomStatus: 'opened'
    };
    const room2 = {
      id: 2142140216,
      code: 'QC',
      description: 'QA TEST ROOM - C',
      portionRoomStatus: 'opened'
    };

    const expectedState = {
      ...initState,
      rooms: [room1, room2]
    };
    jestExpect(
      settingsReducer(initState, {
        type: UPDATE_ROOMS,
        payload: [room1, room2]
      })
    ).toEqual(expectedState);
  });

  test('given stationCreateError in initState, when I tell the reducer about it, then I want the reducer to clean the error', () => {
    const stationCreateError = { message: 'create station fails', showing: true };
    initState = {
      ...initState,
      error: stationCreateError
    };

    const expectedState = {
      ...initState,
      error: { message: '', showing: false }
    };

    jestExpect(
      settingsReducer(initState, {
        type: HIDE_ERROR
      })
    ).toEqual(expectedState);
  });

  test('given empty stationCreateError in initState, when I tell the reducer about it, then I want the reducer to add the error', () => {
    const emptyStationCreateError = { message: '', showing: false };
    initState = {
      ...initState,
      error: emptyStationCreateError
    };

    const expectedState = {
      ...initState,
      error: { message: 'error', showing: true }
    };

    jestExpect(
      settingsReducer(initState, {
        type: SHOW_ERROR,
        payload: { message: 'error' }
      })
    ).toEqual(expectedState);
  });

  test('given empty stationCreateError in initState, when I tell the reducer about it, then I want the reducer to add the error, if I call it again, it still needs to show', () => {
    const emptyStationCreateError = { message: '', showing: false };
    initState = {
      ...initState,
      error: emptyStationCreateError
    };

    const expectedState = {
      ...initState,
      error: { message: 'error', showing: true }
    };

    const firstCallResult = settingsReducer(initState, {
      type: SHOW_ERROR,
      payload: { message: 'error' }
    });

    const secondCallResult = settingsReducer(initState, {
      type: SHOW_ERROR,
      payload: { message: 'error' }
    });

    jestExpect(firstCallResult).toEqual(expectedState);
    jestExpect(secondCallResult).toEqual(expectedState);
  });

  test('given empty housePars in initState, when I tell the reducer about it, then I want the reducer to add the house pars', () => {
    const expectedState = {
      ...initState,
      housePars
    };
    jestExpect(
      settingsReducer(initState, {
        type: UPDATE_HOUSE_PARS,
        payload: housePars
      })
    ).toEqual(expectedState);
  });

  test('given empty housePar in initState, when I tell the reducer UPDATE_HOUSE_PAR, then I want the reducer to add the house par', () => {
    const expectedState = {
      ...initState,
      housePar
    };
    jestExpect(
      settingsReducer(initState, {
        type: UPDATE_HOUSE_PAR,
        payload: housePar
      })
    ).toEqual(expectedState);
  });

  test('should update grinding house par when call UPDATE_GRINDING_HOUSE_PARS', () => {
    const expectedState = {
      ...initState,
      grindingHousePars: housePars
    };
    jestExpect(
      settingsReducer(initState, {
        type: UPDATE_GRINDING_HOUSE_PARS,
        payload: housePars
      })
    ).toEqual(expectedState);
  });

  test('given has housePar in initState, when I tell the reducer CLEAR_HOUSE_PAR, then I want clear house par', () => {
    const expectedState = {
      ...initState
    };
    jestExpect(
      settingsReducer(initState, {
        type: CLEAR_HOUSE_PAR,
        payload: housePar
      })
    ).toEqual(expectedState);
  });

  test('should update customer when call GET_CUSTOMER', () => {
    const customer = customerFactory.build();
    const expectedState = {
      ...initState,
      customer: customer
    };
    jestExpect(
      settingsReducer(initState, {
        type: GET_CUSTOMER,
        payload: customer
      })
    ).toEqual(expectedState);
  });

  test('should update customers when ALL_CUSTOMERS_RECEIVED', () => {
    const fakeCustomer = { foo: 'bar' };
    const expectedState = {
      ...initState,
      customers: fakeCustomer
    };

    jestExpect(
      settingsReducer(initState, {
        type: ALL_CUSTOMERS_RECEIVED,
        payload: fakeCustomer
      })
    ).toEqual(expectedState);
  });

  test('should clear customer when call CLEAR_CUSTOMER', () => {
    const expectedState = {
      ...initState,
      customer: {}
    };
    jestExpect(
      settingsReducer(initState, {
        type: CLEAR_CUSTOMER
      })
    ).toEqual(expectedState);
  });

  test('give empty activeFiscalCalendar in initState, when I tell the reducer GET_ACTIVE_FISCAL_CALENDAR, then I want the reducer to add the activeFiscalCalendar', () => {
    const activeFiscalCalendar = {
      id: 1,
      startDate: '2017-07-02',
      nextStartDate: '2017-07-02'
    };

    const expectedState = {
      ...initState,
      activeFiscalCalendar
    };

    jestExpect(
      settingsReducer(initState, {
        type: GET_ACTIVE_FISCAL_CALENDAR,
        payload: activeFiscalCalendar
      })
    ).toEqual(expectedState);
  });

  test('should update subPrimals when GRABBED_SUB_PRIMAL called', () => {
    const subPrimal = {
      subPrimalCode: '123',
      subPrimalDescription: 'desc for 123'
    };

    const expectedState = {
      ...initState,
      subPrimals: {
        '123': subPrimal
      }
    };
    jestExpect(
      settingsReducer(initState, {
        type: GRABBED_SUB_PRIMAL,
        payload: subPrimal
      })
    ).toEqual(expectedState);
  });

  test('should clear profile info when CLEAR_PROFILE_INFO', () => {
    jestExpect(
      settingsReducer(
        { ...initState, profile: { plantNumber: 123 } },
        {
          type: CLEAR_PROFILE_INFO
        }
      )
    ).toEqual({ ...initState, profile: {} });
  });
});
