import React from 'react';

class WorkdaySettings extends React.Component {
  render() {
    return <div>Fake WorkdaySettings Component</div>;
  }
}

export default WorkdaySettings;
