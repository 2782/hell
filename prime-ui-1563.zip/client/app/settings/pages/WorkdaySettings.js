import React from 'react';
import PropTypes from 'prop-types';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import Notification from '../../shared/components/Notification';
import { F2 } from '../../../config/keymap';
import keydown from 'react-keydown';
import { changePath, getOperatingDates } from '../../shared/actions/actions';
import {
  createHoliday,
  deleteHoliday,
  allowToEditHoliday,
  getHolidays,
  getWeekends,
  hideError,
  showError,
  updateWeekend
} from '../actions/settingsActions';
import HolidaySettings from '../components/HolidaySettings';
import WeekendSettings from '../components/WeekendSettings';
import { Divider } from 'semantic-ui-react';

class WorkdaySettings extends React.Component {
  constructor(props) {
    super(props);
  }

  componentDidMount() {
    this.props.getHolidays();
    this.props.getWeekends();
    this.props.getOperatingDates();
    this.props.hideError();
  }

  @keydown(F2)
  onF2() {
    this.props.switchTab && this.props.switchTab();
  }

  render() {
    const { weekends, holidays } = this.props;

    return (
      <div className='workday-holiday-settings-wrapper'>
        <WeekendSettings weekends={weekends} onchange={this.props.updateWeekend} />
        <Divider />
        <HolidaySettings
          holidays={holidays}
          today={this.props.operatingDates.today}
          deleteHoliday={this.props.deleteHoliday}
          createHoliday={this.props.createHoliday}
          allowToEditHoliday={this.props.allowToEditHoliday}
          hideError={this.props.hideError.bind(this)}
          showError={this.props.showError.bind(this)}
        />
        {this.props.error.showing ? (
          <Notification message={this.props.error.message} onEnter={this.props.hideError} />
        ) : null}
      </div>
    );
  }
}

WorkdaySettings.propTypes = {
  holidays: PropTypes.array.isRequired,
  weekends: PropTypes.array.isRequired,
  operatingDates: PropTypes.object.isRequired,
  allowToEditHoliday: PropTypes.func,
  changePath: PropTypes.func.isRequired,
  getHolidays: PropTypes.func.isRequired,
  createHoliday: PropTypes.func.isRequired,
  deleteHoliday: PropTypes.func.isRequired,
  getWeekends: PropTypes.func.isRequired,
  updateWeekend: PropTypes.func.isRequired,
  hideError: PropTypes.func.isRequired,
  showError: PropTypes.func.isRequired,
  getOperatingDates: PropTypes.func.isRequired,
  error: PropTypes.object.isRequired,
  switchTab: PropTypes.func,
  editHoliday: PropTypes.func
};

const mapStateToProps = state => ({
  holidays: state.settingsInfo.holidays,
  weekends: state.settingsInfo.weekends,
  operatingDates: state.operatingDates,
  error: state.settingsInfo.error
});

const mapDispatchToProps = dispatch =>
  bindActionCreators(
    {
      changePath,
      getOperatingDates,
      getHolidays,
      createHoliday,
      deleteHoliday,
      allowToEditHoliday,
      getWeekends,
      updateWeekend,
      hideError,
      showError
    },
    dispatch
  );

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(WorkdaySettings);
