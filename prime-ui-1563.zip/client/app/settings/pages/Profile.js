import PropTypes from 'prop-types';
import React from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { Field, getFormValues, reduxForm } from 'redux-form';

import { Button, Form } from 'semantic-ui-react';
import FormElement from '../../shared/FormElement';

import { clearProfileInfo, createOrUpdateProfile, getProfile } from '../actions/settingsActions';
import { validateSubmission } from './profileValidator';
import * as _ from 'lodash';
import { hideModal, replacePath, showModal } from '../../shared/actions/actions';
import subscriber from '../../shared/functionKeys/subscriber';

const FORM_NAME = 'ProfileForm';

export class ProfileComponent extends React.Component {
  constructor(props) {
    super(props);

    this.submitWithConfirmation = this.submitWithConfirmation.bind(this);
  }

  submitWithConfirmation(values) {
    const { isNewProfile, initialValues, showModal, hideModal, createOrUpdateProfile } = this.props;
    const { vendorShipFrom, sequenceNumber, plantNumber } = values;

    validateSubmission(values);

    if (
      !isNewProfile &&
      (_.toString(initialValues.plantNumber) !== _.toString(plantNumber) ||
        _.toString(initialValues.sequenceNumber) !== _.toString(sequenceNumber) ||
        _.toString(initialValues.vendorShipFrom) !== _.toString(vendorShipFrom))
    ) {
      showModal({
        header: 'Warning',
        content:
          'Changing this field could disrupt the flow of data between SUS and Prime. Are you sure you want to make this change?',
        cancelButton: 'No',
        cancelAction: () => hideModal(),
        confirmButton: 'Yes',
        confirmAction: () => createOrUpdateProfile(values)
      });
    } else {
      createOrUpdateProfile(values);
    }
  }

  componentDidMount() {
    this.props.getProfile();
  }

  componentWillUnmount() {
    this.props.clearProfileInfo();
  }

  render() {
    const { handleSubmit, statesOption, submitting, pristine } = this.props;

    return (
      <div className='profile'>
        <Form size={'large'} onSubmit={handleSubmit(this.submitWithConfirmation)}>
          <Form.Group>
            <Field
              name='plantNumber'
              className='plant-number'
              component={FormElement}
              as={Form.Input}
              type='text'
              label='PLANT #'
              width={3}
            />
          </Form.Group>
          <Form.Group>
            <Field
              name='name'
              className='name'
              component={FormElement}
              as={Form.Input}
              type='text'
              label='NAME'
              width={15}
            />
          </Form.Group>
          <Form.Group>
            <Field
              name='address'
              className='address'
              component={FormElement}
              as={Form.Input}
              type='text'
              label='ADDRESS'
              width={15}
            />
          </Form.Group>
          <Form.Group>
            <Field
              name='city'
              className='city'
              component={FormElement}
              as={Form.Input}
              type='text'
              label='CITY'
              width={6}
            />
            <Field
              name='state'
              className='state'
              component={FormElement}
              as={Form.Select}
              selection
              options={statesOption}
              type='text'
              label='STATE'
              width={3}
            />
            <Field
              name='zipCode'
              className='zip-code'
              component={FormElement}
              as={Form.Input}
              type='text'
              label='ZIP CODE'
              width={4}
            />
          </Form.Group>
          <Form.Group>
            <Field
              name='establishmentNumber'
              className='establishment-number'
              component={FormElement}
              as={Form.Input}
              type='text'
              label='ESTABLISHMENT #'
              width={5}
            />
          </Form.Group>
          <Form.Group>
            <Field
              name='vendorShipFrom'
              className='vendor-ship-from'
              component={FormElement}
              as={Form.Input}
              type='text'
              label='VENDOR SHIP-FROM'
              width={4}
            />
            <Field
              name='sequenceNumber'
              className='sequence-number'
              component={FormElement}
              as={Form.Input}
              type='text'
              label='SEQUENCE #'
              width={3}
            />
          </Form.Group>
          <div>
            <Button
              primary
              loading={submitting}
              disabled={submitting || pristine}
              size={'large'}
              className='submit'
            >
              Save
            </Button>
          </div>
        </Form>
      </div>
    );
  }
}

ProfileComponent.propTypes = {
  getProfile: PropTypes.func.isRequired,
  showModal: PropTypes.func.isRequired,
  hideModal: PropTypes.func.isRequired,
  createOrUpdateProfile: PropTypes.func.isRequired,
  statesOption: PropTypes.array.isRequired,
  handleSubmit: PropTypes.func.isRequired,
  clearProfileInfo: PropTypes.func,
  initialValues: PropTypes.object,
  formValues: PropTypes.object,
  isNewProfile: PropTypes.bool,
  submitting: PropTypes.bool,
  pristine: PropTypes.bool,
  replacePath: PropTypes.func,
  isModalShowing: PropTypes.bool
};

const mapStateToProps = state => {
  const profile = state.settingsInfo.profile;
  return {
    initialValues: {
      ...profile
    },
    statesOption: state.settingsInfo.states,
    isModalShowing: state.confirmationModal.showing,
    formValues: getFormValues(FORM_NAME)(state),
    isNewProfile: _.isEmpty(profile)
  };
};

const mapDispatchToProps = dispatch => {
  return bindActionCreators(
    {
      getProfile,
      createOrUpdateProfile,
      showModal,
      hideModal,
      clearProfileInfo,
      replacePath
    },
    dispatch
  );
};

export const f4Behavior = props => {
  const { hideModal, isModalShowing, replacePath } = props;

  if (isModalShowing) {
    hideModal();
  } else {
    replacePath('/main-navigation');
  }
};

const Profile = connect(
  mapStateToProps,
  mapDispatchToProps
)(
  reduxForm({
    form: FORM_NAME,
    enableReinitialize: true
  })(
    subscriber(ProfileComponent, {
      f4Behavior,
      targetComponent: FORM_NAME,
      uris: {
        F4: ['#/settings/profile']
      }
    })
  )
);

export default Profile;
