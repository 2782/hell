import React from 'react';
import MaintenanceTable, { iconButton } from '../components/MaintenanceTable';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import { bindActionCreators } from 'redux';
import { Button } from 'semantic-ui-react';
import { replacePath, showModal } from '../../shared/actions/actions';
import { deleteHousePar, getHousePars } from '../actions/settingsActions';
import _ from 'lodash';
import DotDotDot from 'react-dotdotdot';
import { findWithDayOfWeek } from '../../shared/util/dataUtil';
import { renderMaintenanceTableBody } from '../utils/renderTable';

class HouseParMaintenance extends React.Component {
  constructor(props) {
    super(props);

    this.createHousePar = this.createHousePar.bind(this);
    this.editHousePar = this.editHousePar.bind(this);
    this.deleteHousePar = this.deleteHousePar.bind(this);
  }

  componentDidMount() {
    this.props.getHousePars();
  }

  createHousePar() {
    this.props.replacePath('/settings/house-pars/create');
  }

  editHousePar(productCode) {
    this.props.replacePath(`/settings/house-pars/create/${productCode}`);
  }

  deleteHousePar(productCode) {
    const { deleteHousePar, showModal } = this.props;
    showModal({
      confirmButton: 'Delete',
      cancelButton: 'Cancel',
      content: 'Deletion will occur on the next working day. Are you sure you want to delete?',
      header: 'Delete House Par',
      confirmAction: () => deleteHousePar(productCode)
    });
  }

  getHouseParsColumns() {
    return [
      {
        key: 'productInfo',
        pid: 'house-par-product',
        width: '6',
        headerText: 'Product'
      },
      {
        key: 'mon',
        pid: 'house-par-mon',
        width: '1',
        headerText: 'Mon',
        textAlign: 'right'
      },
      {
        key: 'tue',
        pid: 'house-par-tue',
        width: '1',
        headerText: 'Tue',
        textAlign: 'right'
      },
      {
        key: 'wed',
        pid: 'house-par-wed',
        width: '1',
        headerText: 'Wed',
        textAlign: 'right'
      },
      {
        key: 'thur',
        pid: 'house-par-thur',
        width: '1',
        headerText: 'Thur',
        textAlign: 'right'
      },
      {
        key: 'fri',
        pid: 'house-par-fri',
        width: '1',
        headerText: 'Fri',
        textAlign: 'right'
      },
      {
        key: 'createButton',
        pid: 'house-par-create-button',
        width: '2',
        headerText: (
          <Button primary size={'small'} onClick={this.createHousePar}>
            {'New'}
          </Button>
        ),
        textAlign: 'center',
        value: data => {
          return (
            <div>
              <a onClick={() => this.editHousePar(data.productCode)} style={{ marginRight: '5px' }}>
                <i style={iconButton} className='icon-edit' />
              </a>
              <a onClick={() => this.deleteHousePar(data.productCode)}>
                <i style={iconButton} className='icon-delete' />
              </a>
            </div>
          );
        }
      }
    ];
  }

  render() {
    return (
      <MaintenanceTable
        items={this.props.housePars}
        columns={this.getHouseParsColumns()}
        tableBody={renderMaintenanceTableBody}
      />
    );
  }
}

const generateProductInfo = product => {
  const {
    code,
    productPortionSize: { portionSize: portionSize },
    description
  } = product;

  return (
    <div>
      <div pid='house-pars__product-info' className='house-pars-product-info'>
        {`${code} / ${portionSize}`}
      </div>
      <DotDotDot clamp={1} title={description} pid='house-pars__product-description'>
        {description}
      </DotDotDot>
    </div>
  );
};

export const formatHousePars = housePars => {
  return _.map(_.sortBy(housePars, ['product.code']), sortedHousePar => {
    const { product, configValues } = sortedHousePar;

    return {
      productInfo: generateProductInfo(product),
      mon: findWithDayOfWeek(configValues, 1),
      tue: findWithDayOfWeek(configValues, 2),
      wed: findWithDayOfWeek(configValues, 3),
      thur: findWithDayOfWeek(configValues, 4),
      fri: findWithDayOfWeek(configValues, 5),
      productCode: product.code
    };
  });
};

HouseParMaintenance.propTypes = {
  replacePath: PropTypes.func.isRequired,
  getHousePars: PropTypes.func.isRequired,
  deleteHousePar: PropTypes.func.isRequired,
  showModal: PropTypes.func.isRequired,
  housePars: PropTypes.array
};

const mapStateToProps = state => ({
  housePars: formatHousePars(_.get(state, 'settingsInfo.housePars', []))
});

const mapDispatchToProps = dispatch =>
  bindActionCreators(
    {
      getHousePars,
      deleteHousePar,
      replacePath,
      showModal
    },
    dispatch
  );

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(HouseParMaintenance);
