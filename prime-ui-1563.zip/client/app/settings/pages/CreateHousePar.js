import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { Field, formValueSelector, reduxForm } from 'redux-form';
import { Button, Divider, Form, Grid, Icon } from 'semantic-ui-react';
import _ from 'lodash';
import ProductDuplicate from '../../shared/components/product/ProductDuplicate';
import FormElement from '../../shared/FormElement';
import FormLabel from '../../shared/FormLabel';
import { clearHousePar, createOrUpdateHousePar, getHousePar } from '../actions/settingsActions';
import { normalizeProductCode } from '../../shared/components/product/normalizer';
import { replacePath } from '../../shared/actions/actions';
import { findWithDayOfWeek } from '../../shared/util/dataUtil';
import { processErrorResponse, validateSubmission } from '../components/createHouseParValidator';
import { getNonByproductOnlyProduct } from '../../shared/components/product/actionsDuplicate';
import { NOT_A_PRODUCT_CODE } from '../../../config/errorMessage';
import { nonNegativeNumber } from '../../shared/validation/formFieldValidations';
import subscriber from '../../shared/functionKeys/subscriber';

export const FORM_NAME = 'houseParForm';

// Contra name, this should use the "positive number" message:
// It's ok to put zeroes when typing, only on submit are they all
// checked for at least 1 non-zero value

const normalizeToLength3 = value => {
  let number = Number(value.slice(0, 3));
  return isNaN(number) ? value : number;
};

class CreateHousePar extends React.Component {
  componentDidMount() {
    const {
      getHousePar,
      getNonByproductOnlyProduct,
      match: {
        params: { productCode }
      }
    } = this.props;

    if (!_.isEmpty(productCode)) {
      getNonByproductOnlyProduct(productCode);
      getHousePar(productCode);
    }
  }

  componentWillUnmount() {
    this.props.clearHousePar();
  }

  handleKeyUp(event) {
    const productCode = this.props.productCode;
    if (event.keyCode === 13 && !_.isEmpty(productCode)) {
      document.querySelector('div#monday.thirteen.wide.field .input').firstElementChild.focus();
    }
    return Promise.resolve();
  }

  render() {
    const {
      handleSubmit,
      submitting,
      pristine,
      invalid,
      total,
      products,
      productCode
    } = this.props;

    return (
      <div className={'create-house-par-wrapper'}>
        <Form size={'large'} onSubmit={handleSubmit(onSubmit)}>
          <Grid>
            <Grid.Row>
              <Grid.Column width={13}>
                <Field
                  component={ProductDuplicate}
                  name='productCode'
                  autoFocus={true}
                  label='Product ID'
                  useDotDotDot={false}
                  descriptionFontSize={'21px'}
                  product={products[productCode] || {}}
                  normalize={normalizeProductCode}
                  onKeyUp={this.handleKeyUp.bind(this)}
                />
              </Grid.Column>
              <Grid.Column width={3}>
                <FormLabel
                  label='PORTION'
                  value={preparePortionSize(products[productCode] || {})}
                  width={15}
                />
              </Grid.Column>
            </Grid.Row>
          </Grid>

          <Divider hidden />

          <Grid>
            <Grid.Row columns='equal'>
              <Grid.Column>
                <Field
                  component={FormElement}
                  name='monday'
                  as={Form.Input}
                  pid='create-batch-form-monday'
                  validate={[nonNegativeNumber]}
                  normalize={normalizeToLength3}
                  type='text'
                  label='MONDAY'
                  width={13}
                />
              </Grid.Column>
              <Grid.Column>
                <Field
                  component={FormElement}
                  name='tuesday'
                  as={Form.Input}
                  pid='create-batch-form-tuesday'
                  validate={[nonNegativeNumber]}
                  normalize={normalizeToLength3}
                  type='text'
                  label='TUESDAY'
                  width={13}
                />
              </Grid.Column>
              <Grid.Column>
                <Field
                  component={FormElement}
                  name='wednesday'
                  as={Form.Input}
                  pid='create-batch-form-wednesday'
                  validate={[nonNegativeNumber]}
                  normalize={normalizeToLength3}
                  type='text'
                  label='WEDNESDAY'
                  width={13}
                />
              </Grid.Column>
              <Grid.Column>
                <Field
                  component={FormElement}
                  name='thursday'
                  as={Form.Input}
                  pid='create-batch-form-thursday'
                  validate={[nonNegativeNumber]}
                  normalize={normalizeToLength3}
                  type='text'
                  label='THURSDAY'
                  width={13}
                />
              </Grid.Column>
              <Grid.Column>
                <Field
                  component={FormElement}
                  name='friday'
                  as={Form.Input}
                  pid='create-batch-form-friday'
                  validate={[nonNegativeNumber]}
                  normalize={normalizeToLength3}
                  type='text'
                  label='FRIDAY'
                  width={13}
                />
              </Grid.Column>
              <Grid.Column>
                <FormLabel label='Total' value={total} width={15} />
              </Grid.Column>
            </Grid.Row>
          </Grid>

          <Divider hidden />

          <Button
            primary
            size={'large'}
            loading={submitting}
            disabled={submitting || pristine || invalid}
          >
            <Icon className='icon-save' />
            Save
          </Button>
        </Form>
      </div>
    );
  }
}

CreateHousePar.propTypes = {
  createOrUpdateHousePar: PropTypes.func.isRequired,
  clearHousePar: PropTypes.func.isRequired,
  productCode: PropTypes.string.isRequired,
  getNonByproductOnlyProduct: PropTypes.func.isRequired,
  getHousePar: PropTypes.func.isRequired,
  products: PropTypes.object.isRequired,
  replacePath: PropTypes.func.isRequired,
  handleSubmit: PropTypes.func.isRequired,
  submitting: PropTypes.bool.isRequired,
  pristine: PropTypes.bool.isRequired,
  product: PropTypes.object,
  invalid: PropTypes.bool.isRequired,
  match: PropTypes.shape({
    params: PropTypes.shape({
      productCode: PropTypes.string
    })
  }),
  total: PropTypes.number.isRequired,
  productIsProduction: PropTypes.bool.isRequired,
  productHasPricingModel: PropTypes.bool.isRequired
};

const calculateTotalPar = formConfigValues => {
  return _.reduce(
    _.values(formConfigValues),
    (sum, parValue) => {
      parValue = parseInt(parValue) || 0;
      return sum + parValue;
    },
    0
  );
};

const prepareHouseParInfo = (houseParId, configValues) => {
  if (!_.isEmpty(configValues)) {
    return {
      id: houseParId,
      monday: findWithDayOfWeek(configValues, 1),
      tuesday: findWithDayOfWeek(configValues, 2),
      wednesday: findWithDayOfWeek(configValues, 3),
      thursday: findWithDayOfWeek(configValues, 4),
      friday: findWithDayOfWeek(configValues, 5)
    };
  }

  return {};
};

const preparePortionSize = product => {
  if (!_.isEmpty(product)) {
    return product.productPortionSize.portionSize;
  }

  return '';
};

const selector = formValueSelector(FORM_NAME);

export const mapStateToProps = (state, { match: { params } }) => {
  const { configValues, id } = state.settingsInfo.housePar;
  const { products } = state.productDuplicate;

  const formProductCode = selector(state, 'productCode');
  const productCode = formProductCode === undefined ? params.productCode : formProductCode;
  const monday = selector(state, 'monday');
  const tuesday = selector(state, 'tuesday');
  const wednesday = selector(state, 'wednesday');
  const thursday = selector(state, 'thursday');
  const friday = selector(state, 'friday');
  const product = _.get(products, `${productCode}`, {});

  const total = calculateTotalPar({ monday, tuesday, wednesday, thursday, friday });
  const housePar = prepareHouseParInfo(id, configValues);

  const productIsProduction = _.get(product, 'productOutput', 'SOURCE') === 'FINISHED';
  const productHasPricingModel = !!_.get(product, 'cost');

  return {
    initialValues: {
      ...housePar,
      productCode
    },
    products,
    productCode: productCode || '',
    total,
    product,
    productIsProduction,
    productHasPricingModel
  };
};

const asyncValidate = (values, dispatch, props) => {
  const { productCode } = values;
  const { getHousePar, getNonByproductOnlyProduct } = props;

  if (!_.isEmpty(productCode)) {
    getHousePar(productCode);
    return getNonByproductOnlyProduct(productCode, () => ({ productCode: NOT_A_PRODUCT_CODE }));
  }

  return Promise.resolve();
};

const onSubmit = (values, dispatch, props) => {
  const { createOrUpdateHousePar } = props;
  validateSubmission(values, props);
  return createOrUpdateHousePar(values, errorResponse => {
    processErrorResponse(errorResponse, values);
  });
};

const mapDispatchToProps = dispatch =>
  bindActionCreators(
    {
      replacePath,
      createOrUpdateHousePar,
      getHousePar,
      clearHousePar,
      getNonByproductOnlyProduct
    },
    dispatch
  );

export const f4Behavior = props => {
  props.replacePath('/settings/house-pars');
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(
  reduxForm({
    form: FORM_NAME,
    enableReinitialize: true,
    asyncValidate,
    asyncBlurFields: ['productCode'],
    onSubmit
  })(
    subscriber(CreateHousePar, {
      f4Behavior,
      targetComponent: 'CreateHousePar',
      uris: {
        F4: ['#/settings/house-pars/create', '#/settings/house-pars/create/*']
      }
    })
  )
);
