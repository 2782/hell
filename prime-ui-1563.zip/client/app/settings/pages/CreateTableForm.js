import React from 'react';
import PropTypes from 'prop-types';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import { Field, reduxForm } from 'redux-form';
import { Button, Divider, Form } from 'semantic-ui-react';
import FormElement from '../../shared/FormElement';
import {
  clearTable,
  createTable,
  getStations,
  getTable,
  updateTable
} from '../actions/settingsActions';
import { validateField, validateSubmission } from '../components/createTableValidator';
import _ from 'lodash';
import subscriber from '../../shared/functionKeys/subscriber';
import { required } from '../../shared/validation/formFieldValidations';
import FormTimeInput from '../../shared/FormTimeInput';
import {
  noStartingSpaces,
  onlyPositiveWholeNumber
} from '../../shared/normalizers/formFieldNormalizers';

const TABLE_CODE_MAX_LENGTH = 2;
const POUNDS_PER_HOUR_MAX_LENGTH = 5;
const TABLE_DESCRIPTION_MAX_LENGTH = 20;

export class CreateTableFormPage extends React.Component {
  constructor(props) {
    super(props);
    this.submit = this.submit.bind(this);
  }

  submit(values) {
    const {
      modifyingExistingTable,
      stations,
      createTable,
      updateTable,
      match: {
        params: { tableId }
      }
    } = this.props;

    validateSubmission(values);

    const selectedStation = _.find(stations, item => {
      return item.stationCode === values.stationCode;
    });

    if (modifyingExistingTable) {
      return updateTable(tableId, {
        station: selectedStation,
        tableCode: values.tableCode,
        tableDescription: values.tableDescription,
        poundsPerHour: values.poundsPerHour,
        tableCloseTime: values.tableCloseTime,
        tableOpenTime: values.tableOpenTime
      });
    } else {
      return createTable({
        station: selectedStation,
        tableCode: values.tableCode,
        tableDescription: values.tableDescription,
        poundsPerHour: values.poundsPerHour,
        tableCloseTime: values.tableCloseTime,
        tableOpenTime: values.tableOpenTime
      });
    }
  }

  componentDidMount() {
    const {
      getStations,
      getTable,
      match: {
        params: { tableId }
      }
    } = this.props;

    if (tableId) {
      getTable(tableId);
    }
    getStations();
  }

  componentWillMount() {
    const { clearTable } = this.props;
    clearTable();
  }

  render() {
    const {
      handleSubmit,
      stationOptions,
      submitting,
      pristine,
      modifyingExistingTable,
      invalid
    } = this.props;

    return (
      <div className={'create-table-wrapper'}>
        <Form size={'large'} onSubmit={handleSubmit(this.submit)}>
          <Form.Group>
            <Field
              name='tableCode'
              component={FormElement}
              disabled={modifyingExistingTable}
              as={Form.Input}
              autoFocus={true}
              type='text'
              label='Table #'
              width={4}
              validate={[required]}
              maxLength={TABLE_CODE_MAX_LENGTH}
              normalize={onlyPositiveWholeNumber}
            />
            <Field
              name='poundsPerHour'
              component={FormElement}
              as={Form.Input}
              type='text'
              label='Pounds/Hour'
              validate={[required]}
              width={3}
              maxLength={POUNDS_PER_HOUR_MAX_LENGTH}
              normalize={onlyPositiveWholeNumber}
            />
            <Field
              component={FormTimeInput}
              name='tableOpenTime'
              className='tableOpenTime'
              type='time'
              label='Table Open'
              width={4}
            />
            <Field
              component={FormTimeInput}
              name='tableCloseTime'
              className='tableCloseTime'
              type='time'
              label='Table Close'
              width={4}
            />
          </Form.Group>

          <Form.Group>
            <Field
              name='tableDescription'
              component={FormElement}
              as={Form.Input}
              type='text'
              label='Description'
              width={10}
              validate={[required]}
              maxLength={TABLE_DESCRIPTION_MAX_LENGTH}
              normalize={noStartingSpaces}
            />
          </Form.Group>

          <Form.Group>
            <Field
              component={FormElement}
              name='stationCode'
              as={Form.Select}
              options={stationOptions}
              type='text'
              label='station'
              width={8}
              validate={[required]}
            />
          </Form.Group>

          <Button
            primary
            size={'large'}
            loading={submitting}
            disabled={submitting || pristine || invalid}
            id='save-table-button'
          >
            <i className={'icon icon-save'} />
            Save
          </Button>
          <Divider hidden />
        </Form>
      </div>
    );
  }
}

const generateStationOptions = stations => {
  const productionStations = _.filter(stations, station => 'PRODUCTION' === station.type);

  return productionStations.map(({ stationCode, name }, index) => {
    return { key: index, text: `${stationCode} - ${name}`, value: stationCode };
  });
};

CreateTableFormPage.propTypes = {
  clearTable: PropTypes.func.isRequired,
  createTable: PropTypes.func.isRequired,
  updateTable: PropTypes.func.isRequired,
  getTable: PropTypes.func.isRequired,
  getStations: PropTypes.func.isRequired,
  stationOptions: PropTypes.array.isRequired,
  stations: PropTypes.array,
  invalid: PropTypes.bool,
  modifyingExistingTable: PropTypes.bool.isRequired,

  match: PropTypes.shape({
    params: PropTypes.shape({
      tableId: PropTypes.oneOfType([PropTypes.string, PropTypes.number])
    })
  }),

  handleSubmit: PropTypes.func.isRequired,
  submitting: PropTypes.bool.isRequired,
  pristine: PropTypes.bool.isRequired
};

const mapStateToProps = state => {
  const table = state.settingsInfo.table;
  const stations = state.settingsInfo.stations;

  return {
    initialValues: {
      tableCode: String(_.get(table, 'tableCode', '')),
      tableDescription: _.get(table, 'tableDescription', ''),
      poundsPerHour: _.get(table, 'poundsPerHour', ''),
      tableOpenTime: _.get(table, 'tableOpenTime', ''),
      tableCloseTime: _.get(table, 'tableCloseTime', ''),
      stationCode: _.get(table, 'station.stationCode', '')
    },
    modifyingExistingTable: !_.isEmpty(table),
    stationOptions: stations ? generateStationOptions(stations) : [],
    stations: stations
  };
};

const mapDispatchToProps = dispatch =>
  bindActionCreators(
    {
      clearTable,
      createTable,
      updateTable,
      getStations,
      getTable
    },
    dispatch
  );

export const f4Behavior = props => {
  props.replacePath('/settings/tables');
};

const CreateTableForm = connect(
  mapStateToProps,
  mapDispatchToProps
)(
  reduxForm({
    form: 'createTable',
    validate: validateField,
    enableReinitialize: true
  })(
    subscriber(CreateTableFormPage, {
      f4Behavior,
      targetComponent: 'CreateTableForm',
      uris: {
        F4: ['#/settings/tables/create', '#/settings/tables/create/*']
      }
    })
  )
);

export default CreateTableForm;
