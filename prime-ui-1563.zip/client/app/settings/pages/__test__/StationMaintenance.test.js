import React from 'react';
import { mount } from 'enzyme';
import thunk from 'redux-thunk';
import configureStore from 'redux-mock-store';

import StationMaintenance from '../StationMaintenance';
import settingsResources from '../../../shared/api/settingsResources';
import EmptyListMessage from '../../../shared/components/EmptyListMessage';
import { createReduxStore } from '../../../store';
import { Provider } from 'react-redux';
import StationFactory from '../../../../test-factories/station';
import { Table } from 'semantic-ui-react';
import MaintenanceTable from '../../components/MaintenanceTable';

jest.mock('../../../shared/errors/ErrorNotification');
jest.mock('../../../shared/api/settingsResources');

let middleware = [thunk];
const createMockStore = configureStore(middleware);

const station1 = StationFactory.build({
  stationCode: 4,
  portionRoomTables: [8, 9, 10, 11, 12, 13],
  name: 'PEDRO',
  printer: 'PRINTER-4',
  realPrinter: 'PRINTER-4',
  room: 'A',
  type: 'PRODUCTION',
  userId: 'production-user-1'
});

const station2 = StationFactory.build({
  stationCode: 35,
  portionRoomTables: [3, 1, 2, 4, 5, 6, 7],
  name: 'ENRIQUE',
  printer: 'PRINTER-35',
  realPrinter: '',
  room: 'A',
  type: 'PRODUCTION',
  userId: 'production-user-1'
});

const station3 = StationFactory.build({
  stationCode: 39,
  portionRoomTables: [],
  name: 'ENRIQUE 2',
  printer: 'PRINTER-39',
  realPrinter: '',
  room: 'A',
  type: 'PACKOFF',
  userId: 'packoff-user-1'
});

const stationResponse = {
  data: [station1, station2, station3]
};

function replacePathAction(path) {
  return {
    type: '@@router/CALL_HISTORY_METHOD',
    payload: { method: 'replace', args: [path] }
  };
}

describe('StationMaintenance', () => {
  test('should render room headers when there are no rooms', () => {
    let mockStore = createReduxStore({ settingsInfo: {} });
    const wrapper = mount(<StationMaintenance store={mockStore} />);

    const stationDom = wrapper.find(MaintenanceTable);

    jestExpect(stationDom.props().columns[0]).toEqual({
      key: 'stationCode',
      pid: 'station-code',
      textAlign: 'right',
      width: '2',
      headerText: 'Station'
    });

    jestExpect(stationDom.props().columns[1]).toEqual({
      key: 'name',
      pid: 'station-name',
      width: '3',
      headerText: 'Name'
    });
    jestExpect(stationDom.props().columns[2]).toEqual({
      key: 'room',
      pid: 'station-room',
      width: '1',
      headerText: 'Room'
    });
    jestExpect(stationDom.props().columns[3]).toEqual({
      key: 'portionRoomTables',
      pid: 'station-tables',
      width: '3',
      headerText: 'Tables'
    });
    jestExpect(stationDom.props().columns[4]).toEqual({
      key: 'printer',
      pid: 'station-printer',
      width: '2',
      headerText: 'Printer IP'
    });
    jestExpect(stationDom.props().columns[5]).toEqual({
      key: 'userId',
      pid: 'station-user-id',
      width: '2',
      headerText: 'User ID'
    });
    jestExpect(stationDom.props().columns[6]).toMatchObject({
      key: 'createButton',
      pid: 'station-create-button'
    });
  });

  test('should get all stations and pass them to MaintenanceTable', () => {
    const store = createReduxStore({});
    settingsResources.getStations.mockImplementation(callback =>
      callback({ data: [station1, station2, station3] })
    );

    const wrapper = mount(
      <Provider store={store}>
        <StationMaintenance />
      </Provider>
    );

    const stationDom = wrapper.find(MaintenanceTable);

    jestExpect(stationDom).toHaveProp({ items: [station1, station2, station3] });
  });

  test('should render station info with name, room, and tables when station data exists', () => {
    let mockStore = createReduxStore({ settingsInfo: { stations: stationResponse.data } });
    const wrapper = mount(<StationMaintenance store={mockStore} />);

    let roomCodes = wrapper.find('[pid="maintenance__station-code"]');
    jestExpect(roomCodes.at(1)).toIncludeText(station1.stationCode);
    jestExpect(roomCodes.at(2)).toIncludeText(station2.stationCode);

    jestExpect(wrapper.find(EmptyListMessage)).not.toExist();
  });

  test('should render production and packoff group', () => {
    let mockStore = createReduxStore({ settingsInfo: { stations: stationResponse.data } });
    const wrapper = mount(<StationMaintenance store={mockStore} />);

    const tableBodies = wrapper.find(Table.Body);
    jestExpect(tableBodies.length).toEqual(2);

    jestExpect(
      tableBodies
        .at(0)
        .find(Table.Row)
        .at(0)
        .find(Table.Cell)
        .text()
    ).toEqual('PRODUCTION');
    jestExpect(
      tableBodies
        .at(1)
        .find(Table.Row)
        .at(0)
        .find(Table.Cell)
        .text()
    ).toEqual('PACKOFF');
  });

  test('clicking on create button should navigate us to create station page', () => {
    let mockStore = createMockStore({ settingsInfo: { stations: [] } });
    const wrapper = mount(<StationMaintenance store={mockStore} />);

    let buttonWrapper = wrapper.find('.primary.button');

    jestExpect(buttonWrapper).toHaveText('New');

    mockStore.clearActions();
    buttonWrapper.simulate('click');

    let actions = mockStore.getActions();

    jestExpect(actions).toEqual([
      {
        type: '@@router/CALL_HISTORY_METHOD',
        payload: {
          method: 'replace',
          args: ['/settings/stations/create']
        }
      }
    ]);
  });

  test('should on edit button should navigate us to modify station page', () => {
    const mockStore = createMockStore({ settingsInfo: { stations: [station1, station2] } });

    const wrapper = mount(<StationMaintenance store={mockStore} />);

    const firstRowEditButton = wrapper.find('a').at(0);
    mockStore.clearActions();
    firstRowEditButton.simulate('click');

    let actions = mockStore.getActions();

    jestExpect(actions).toEqual([replacePathAction('/settings/stations/create/1')]);
  });
});
