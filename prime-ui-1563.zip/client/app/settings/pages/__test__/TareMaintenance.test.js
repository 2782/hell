import React from 'react';
import { TareMaintenanceComponent } from '../TareMaintenance';
import { mount } from 'enzyme';
import MaintenanceTable from '../../components/MaintenanceTable';
import { Button, Table } from 'semantic-ui-react';

describe('TareMaintenance', () => {
  test('should display description headers for tare setup when table are not empty', () => {
    const wrapper = mount(
      <TareMaintenanceComponent
        replacePath={() => {}}
        getAllTarePackages={() => {}}
        tarePackages={null}
      />
    );

    const maintenanceHeader = wrapper.find(MaintenanceTable);

    jestExpect(maintenanceHeader).toExist();

    jestExpect(
      maintenanceHeader.find('[pid="maintenance__header-box-description"]').at(2)
    ).toHaveText('Box Description');
    jestExpect(maintenanceHeader.find('[pid="maintenance__header-box-tare"]').at(2)).toHaveText(
      'Box Tare'
    );
    jestExpect(
      maintenanceHeader.find('[pid="maintenance__header-film-description"]').at(2)
    ).toHaveText('Film Description');
    jestExpect(maintenanceHeader.find('[pid="maintenance__header-film-tare"]').at(2)).toHaveText(
      'Film Tare'
    );
    jestExpect(maintenanceHeader.find('[pid="maintenance__header-defaulted"]').at(2)).toHaveText(
      'Default'
    );
    jestExpect(maintenanceHeader.find(Button)).toIncludeText('New');
  });

  test('should act to navigate away from this page', () => {
    let replacePathSpy = jest.fn();

    const wrapper = mount(
      <TareMaintenanceComponent
        replacePath={replacePathSpy}
        getAllTarePackages={() => {}}
        tarePackages={null}
      />
    );
    const maintenanceHeader = wrapper.find(MaintenanceTable);
    maintenanceHeader.find(Button).simulate('click');

    jestExpect(replacePathSpy).toHaveBeenCalledWith('/settings/tare-packages/create');
  });

  test('should act to navigate away from this page when clicking edit button', () => {
    let replacePathSpy = jest.fn();

    const wrapper = mount(
      <TareMaintenanceComponent
        replacePath={replacePathSpy}
        getAllTarePackages={() => {}}
        tarePackages={[{ id: 1 }, { id: 3 }]}
      />
    );
    wrapper
      .find('.icon-edit')
      .at(1)
      .simulate('click');

    jestExpect(replacePathSpy).toHaveBeenCalledWith('/settings/tare-packages/create/3');
  });

  test('should call get for all tare packages upon mount', () => {
    let getAllTarePackagesSpy = jest.fn();

    mount(
      <TareMaintenanceComponent
        replacePath={() => {}}
        getAllTarePackages={getAllTarePackagesSpy}
        tarePackages={null}
      />
    );

    jestExpect(getAllTarePackagesSpy).toHaveBeenCalledTimes(1);
  });

  test('should display tare details for tare setup when table is not empty', () => {
    const packages = [
      {
        boxType: {
          boxDescription: 'test box',
          boxTare: 7.3
        },
        filmType: {
          filmDescription: 'test',
          filmTare: 3.5
        },
        defaulted: false
      }
    ];

    let getAllTarePackagesSpy = jest.fn();

    const wrapper = mount(
      <TareMaintenanceComponent
        replacePath={() => {}}
        getAllTarePackages={getAllTarePackagesSpy}
        tarePackages={packages}
      />
    );

    const tableBody = wrapper.find(Table.Body);

    jestExpect(tableBody).toExist();

    jestExpect(tableBody.find('[pid="maintenance__box-description"]').at(1)).toHaveText('test box');
    jestExpect(tableBody.find('[pid="maintenance__box-tare"]').at(1)).toHaveText('7.3');
    jestExpect(tableBody.find('[pid="maintenance__film-description"]').at(1)).toHaveText('test');
    jestExpect(tableBody.find('[pid="maintenance__film-tare"]').at(1)).toHaveText('3.5');

    let isDefaulted = tableBody.find('[pid="maintenance__defaulted"]');
    jestExpect(isDefaulted.find('input')).toHaveProp({ checked: false, disabled: true });
  });
});
