import React from 'react';
import { mount } from 'enzyme';
import CreateTableForm, { CreateTableFormPage, f4Behavior } from '../CreateTableForm';
import settingsResources from '../../../shared/api/settingsResources';
import StationFactory from '../../../../test-factories/station';
import { createReduxStore } from '../../../store';
import PortionRoomTableFactory from '../../../../test-factories/portionRoomTableFactory';
import { Provider } from 'react-redux';
import semanticUI from '../../../../test-helpers/semantic-ui';
import { replacePath } from '../../../shared/actions/actions';

jest.mock('../../../shared/actions/actions', () => ({
  replacePath: jest.fn(() => ({ type: 'MOCK_REPLACE_PATH' }))
}));
jest.mock('../../../shared/api/settingsResources');

describe('editing tables', () => {
  let form;

  beforeEach(() => {
    settingsResources.createTable.mockResolvedValue({});
    settingsResources.getTable.mockImplementation((tableId, success) =>
      success({ data: PortionRoomTableFactory.build() })
    );

    const store = createReduxStore({});

    settingsResources.getStations.mockImplementation(callback =>
      callback({
        data: [StationFactory.build({ id: 1, stationCode: 3, name: 'cutter' })]
      })
    );

    form = mount(
      <Provider store={store}>
        <CreateTableForm match={{ params: { tableId: 1 } }} />
      </Provider>
    );
  });

  afterEach(() => {
    settingsResources.createTable.mockReset();
    settingsResources.getTable.mockReset();
    settingsResources.getStations.mockReset();
  });

  test('should disable editing table code when editing an existing table', () => {
    jestExpect(semanticUI.getInputProp(form, 'tableCode', 'disabled')).toEqual(true);
  });

  test('should have a pre-filled table code when editing an existing table', () => {
    jestExpect(semanticUI.getInputValue(form, 'tableCode')).toEqual('97');
  });

  test('should have a pre-filled table description when editing an existing table', () => {
    jestExpect(semanticUI.getInputValue(form, 'tableDescription')).toEqual('SAUSAGE');
  });

  test('should have a pre-filled table station when editing an existing table', () => {
    jestExpect(semanticUI.getSelectValue(form, 'stationCode')).toEqual(3);
  });
});

describe('createTableForm', () => {
  let form;

  beforeEach(() => {
    const store = createReduxStore({});

    settingsResources.getStations.mockImplementation(callback =>
      callback({
        data: [
          StationFactory.build({ stationCode: 3, name: 'cutter', type: 'PRODUCTION' }),
          StationFactory.build({ stationCode: 2, name: 'cutter', type: 'PACKOFF' }),
          StationFactory.build({ stationCode: 4, name: 'cutter', type: 'PRODUCTION' })
        ]
      })
    );

    afterEach(() => {
      settingsResources.createTable.mockReset();
      settingsResources.getTable.mockReset();
      settingsResources.getStations.mockReset();
      settingsResources.updateTable.mockReset();
    });

    form = mount(
      <Provider store={store}>
        <CreateTableForm match={{ params: {} }} />
      </Provider>
    );
  });

  test('should fill out form and save it', () => {
    settingsResources.createTable.mockResolvedValue({});

    jestExpect(settingsResources.getTable).not.toHaveBeenCalled();
    jestExpect(settingsResources.getStations).toHaveBeenCalled();

    semanticUI.changeInput(form, 'tableCode', '42');
    semanticUI.changeInput(form, 'poundsPerHour', '100');
    semanticUI.changeInput(form, 'tableOpenTime', '01:20');
    semanticUI.changeInput(form, 'tableCloseTime', '03:20');
    semanticUI.changeInput(form, 'tableDescription', 'Big Steak');
    semanticUI.selectOption(form, 'stationCode', 1);

    form.find('form').simulate('submit');

    jestExpect(settingsResources.createTable.mock.calls[0][0]).toEqual({
      tableCode: '42',
      tableDescription: 'Big Steak',
      poundsPerHour: '100',
      tableOpenTime: '01:20',
      tableCloseTime: '03:20',
      station: {
        id: 3
      }
    });
  });

  test('should fill out form and normalize data to be valid and save it', () => {
    settingsResources.createTable.mockResolvedValue({});

    jestExpect(settingsResources.getTable).not.toHaveBeenCalled();
    jestExpect(settingsResources.getStations).toHaveBeenCalled();

    semanticUI.changeInput(form, 'tableCode', ' 42xx');
    semanticUI.changeInput(form, 'poundsPerHour', ' 100xyz');
    semanticUI.changeInput(form, 'tableOpenTime', '01:20');
    semanticUI.changeInput(form, 'tableCloseTime', '03:20');
    semanticUI.changeInput(form, 'tableDescription', '  Big Steak');
    semanticUI.selectOption(form, 'stationCode', 1);

    form.find('form').simulate('submit');

    jestExpect(settingsResources.createTable.mock.calls[0][0]).toEqual({
      tableCode: '42',
      tableDescription: 'Big Steak',
      poundsPerHour: '100',
      tableOpenTime: '01:20',
      tableCloseTime: '03:20',
      station: {
        id: 3
      }
    });
  });

  describe('check will mount will invoke clear table', () => {
    let component;
    let clearTable = jest.fn();

    test('check table in cleared in store', () => {
      component = new CreateTableFormPage({ clearTable });
      component.componentWillMount();
      jestExpect(clearTable).toHaveBeenCalledTimes(1);
    });
  });

  describe('render component', () => {
    let form;
    beforeEach(() => {
      const store = createReduxStore({});

      form = mount(
        <Provider store={store}>
          <CreateTableForm match={{ params: {} }} />
        </Provider>
      );
    });

    test('should enable editing table code when creating a new table', () => {
      jestExpect(semanticUI.getInputProp(form, 'tableCode', 'disabled')).toEqual(false);
    });

    test('should have empty table code when creating a new table', () => {
      jestExpect(semanticUI.getInputValue(form, 'tableCode')).toEqual('');
      jestExpect(semanticUI.getInputValue(form, 'tableOpenTime')).toEqual('');
      jestExpect(semanticUI.getInputValue(form, 'tableCloseTime')).toEqual('');
    });
  });

  describe('Error Handling component', () => {
    let form;

    test('should render submit error when API call fails and hide error after a field is changed', () => {
      const store = createReduxStore({});
      settingsResources.getStations.mockImplementation(callback =>
        callback({
          data: [StationFactory.build({ stationCode: 3, name: 'cutter' })]
        })
      );
      settingsResources.getTable.mockImplementation((tableId, callback) =>
        callback({
          data: PortionRoomTableFactory.build()
        })
      );
      settingsResources.updateTable.mockImplementation(() => {
        return Promise.reject({ response: { data: 'error' } });
      });

      const dispatchSpy = jest.spyOn(store, 'dispatch');

      form = mount(
        <Provider store={store}>
          <CreateTableForm match={{ params: { tableId: 12 } }} />
        </Provider>
      );

      form.find('form').simulate('submit');

      jestExpect(dispatchSpy).not.toHaveBeenCalledWith(replacePath('/settings/tables'));

      settingsResources.updateTable.mockReset();
    });
  });

  test('should go return to table maintenance on f4', () => {
    const props = { replacePath: jest.fn() };

    f4Behavior(props);

    jestExpect(props.replacePath).toHaveBeenCalledWith('/settings/tables');
  });
});
