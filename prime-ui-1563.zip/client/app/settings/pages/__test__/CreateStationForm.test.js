import React from 'react';
import { mount } from 'enzyme';
import CreateStationForm, { CreateStationFormPage, f4Behavior } from '../CreateStationForm';
import { createReduxStore } from '../../../store';
import { Provider } from 'react-redux';
import settingsResources from '../../../shared/api/settingsResources';
import portionRoomFactory from '../../../../test-factories/portionRoomFactory';
import semanticUI from '../../../../test-helpers/semantic-ui';
import StationFactory from '../../../../test-factories/station';
import { Message } from 'semantic-ui-react';
import { getPortionRooms } from '../../../landingPage/actions/landingPageActions';

jest.mock('../../../landingPage/actions/landingPageActions', () => ({
  getPortionRooms: jest.fn(() => ({ type: 'MOCK_GET_PORTION_ROOMS_ACTION' }))
}));
jest.mock('../../../shared/api/settingsResources');

describe('CreateStationForm', () => {
  afterEach(() => {
    settingsResources.createStation.mockReset();
    settingsResources.updateStation.mockReset();
    settingsResources.getStation.mockReset();

    getPortionRooms.mockClear();
  });

  test('should call getStations and getPortionRooms upon mount', () => {
    let getStation = jest.fn();
    let getPortionRooms = jest.fn();
    let form = new CreateStationFormPage({
      getStations: getStation,
      getPortionRooms: getPortionRooms,
      match: { params: {} },
      hideError: jest.fn()
    });

    form.componentDidMount();

    jestExpect(getStation).not.toHaveBeenCalled();
    jestExpect(getPortionRooms).toHaveBeenCalled();
  });

  test('should clear any existing station or error data upon mounting', () => {
    const store = createReduxStore({
      settingsInfo: {
        error: { message: 'there is an error', showing: true },
        station: { stationCode: 12, name: 'PEDRO', room: 'A', printer: '10.1.1.1' }
      }
    });

    const form = mount(
      <Provider store={store}>
        <CreateStationForm match={{ params: {} }} />
      </Provider>
    );

    jestExpect(semanticUI.getInputValue(form, 'stationCode')).toEqual('');
    jestExpect(semanticUI.getInputValue(form, 'name')).toEqual('');
    jestExpect(semanticUI.getSelectValue(form, 'room')).toEqual(undefined);
    jestExpect(semanticUI.getInputValue(form, 'printer')).toEqual('');
    jestExpect(form.find(Message).exists()).toEqual(false);
  });

  test('should fill out form for production type and save it', () => {
    const store = createReduxStore({
      portionRoomsInfo: {
        portionRooms: [
          portionRoomFactory.build({ code: 'A', description: 'Room A' }),
          portionRoomFactory.build({ code: 'B', description: 'Room B' }),
          portionRoomFactory.build({ code: 'C', description: 'Room C' })
        ]
      }
    });

    const form = mount(
      <Provider store={store}>
        <CreateStationForm match={{ params: {} }} />
      </Provider>
    );

    jestExpect(settingsResources.getStation).not.toHaveBeenCalled();
    jestExpect(getPortionRooms).toHaveBeenCalledTimes(1);
    jestExpect(form.find('#type').find('.disabled')).not.toExist();

    semanticUI.changeInput(form, 'stationCode', '42');
    semanticUI.changeInput(form, 'name', 'Pork');
    semanticUI.changeInput(form, 'printer', '10.2.2.20');
    semanticUI.changeInput(form, 'userId', 'user-id-1');
    semanticUI.selectOption(form, 'type', 0);
    semanticUI.selectOption(form, 'room', 1);

    form.find('form').simulate('submit');

    jestExpect(settingsResources.createStation.mock.calls[0][0]).toEqual({
      stationCode: '42',
      name: 'Pork',
      room: 'B',
      printer: '10.2.2.20',
      type: 'PRODUCTION',
      retailPrinter: '',
      userId: 'user-id-1'
    });
  });

  test('should fill out form for packoff type and save it', () => {
    const store = createReduxStore({
      portionRoomsInfo: {
        portionRooms: [
          portionRoomFactory.build({ code: 'A', description: 'Room A' }),
          portionRoomFactory.build({ code: 'B', description: 'Room B' }),
          portionRoomFactory.build({ code: 'C', description: 'Room C' })
        ]
      }
    });

    const form = mount(
      <Provider store={store}>
        <CreateStationForm match={{ params: {} }} />
      </Provider>
    );

    jestExpect(settingsResources.getStation).not.toHaveBeenCalled();
    jestExpect(getPortionRooms).toHaveBeenCalledTimes(1);
    jestExpect(form.find('#type').find('.disabled')).not.toExist();

    semanticUI.changeInput(form, 'stationCode', '42');
    semanticUI.changeInput(form, 'name', 'Pork');
    semanticUI.selectOption(form, 'type', 1);
    semanticUI.changeInput(form, 'printer', '10.2.2.20');
    semanticUI.changeInput(form, 'retailPrinter', '10.2.2.21');
    semanticUI.changeInput(form, 'userId', 'user-id-1');
    semanticUI.selectOption(form, 'room', 1);

    form.find('form').simulate('submit');

    jestExpect(settingsResources.createStation.mock.calls[0][0]).toEqual({
      stationCode: '42',
      name: 'Pork',
      room: 'B',
      printer: '10.2.2.20',
      retailPrinter: '10.2.2.21',
      type: 'PACKOFF',
      userId: 'user-id-1'
    });
  });

  test('should fill out form and save it but failed when having errors', () => {
    const store = createReduxStore({
      portionRoomsInfo: {
        portionRooms: [
          portionRoomFactory.build({ code: 'A', description: 'Room A' }),
          portionRoomFactory.build({ code: 'B', description: 'Room B' }),
          portionRoomFactory.build({ code: 'C', description: 'Room C' })
        ]
      }
    });

    const form = mount(
      <Provider store={store}>
        <CreateStationForm match={{ params: {} }} />
      </Provider>
    );

    jestExpect(settingsResources.getStation).not.toHaveBeenCalled();
    jestExpect(getPortionRooms).toHaveBeenCalledTimes(1);

    semanticUI.changeInput(form, 'stationCode', '42');
    semanticUI.changeInput(form, 'name', 'Pork');
    semanticUI.changeInput(form, 'printer', '10.2.2.20');
    semanticUI.changeInput(form, 'userId', 'user-id-1');
    semanticUI.selectOption(form, 'type', 0);
    semanticUI.selectOption(form, 'room', 1);

    form.find('form').simulate('submit');

    settingsResources.createStation.mockImplementation((arg, success, fail) => {
      fail({
        error: {
          details: [{ issue: 'an issue', type: 'model', value: 'UserAssignedValidation' }]
        }
      });
    });

    form.find('form').simulate('submit');
    jestExpect(form.find('.pointing')).toHaveText('an issue');
    semanticUI.changeInput(form, 'userId', 'ALEX');
    jestExpect(form.find('.pointing')).not.toExist();
  });

  describe('check willmount will invoke clear station', () => {
    let component;
    let clearStation = jest.fn();

    test('check station in cleared in store', () => {
      component = new CreateStationFormPage({ clearStation: clearStation });
      component.componentWillMount();
      jestExpect(clearStation).toHaveBeenCalledTimes(1);
    });
  });

  test('should get existing station, pre-fill form and lock changing of stationCode, and update room selected', () => {
    const store = createReduxStore({
      portionRoomsInfo: {
        portionRooms: [
          portionRoomFactory.build({ code: 'A', description: 'Room A' }),
          portionRoomFactory.build({ code: 'B', description: 'Room B' }),
          portionRoomFactory.build({ code: 'C', description: 'Room C' })
        ]
      }
    });
    settingsResources.getStation.mockImplementation((arg, success) =>
      success({
        data: StationFactory.build()
      })
    );

    const form = mount(
      <Provider store={store}>
        <CreateStationForm match={{ params: { stationId: 12 } }} />
      </Provider>
    );

    jestExpect(settingsResources.getStation.mock.calls[0][0]).toEqual(12);

    jestExpect(semanticUI.getInputProp(form, 'stationCode', 'disabled')).toEqual(true);
    semanticUI.selectOption(form, 'room', 2);
    semanticUI.changeInput(form, 'printer', '10.1.1.1');
    semanticUI.changeInput(form, 'userId', 'user new id');

    jestExpect(form.find('#type').find('.disabled')).toExist();

    form.find('form').simulate('submit');

    jestExpect(settingsResources.updateStation.mock.calls[0][0]).toEqual({
      id: 12,
      stationCode: '12',
      name: 'PEDRO',
      room: 'C',
      printer: '10.1.1.1',
      retailPrinter: '',
      type: 'PRODUCTION',
      userId: 'user new id'
    });
  });

  test('should render submit error when API call fails and hide error after a field is changed', () => {
    const store = createReduxStore({
      portionRoomsInfo: {
        portionRooms: [
          portionRoomFactory.build({ code: 'A', description: 'Room A' }),
          portionRoomFactory.build({ code: 'B', description: 'Room B' }),
          portionRoomFactory.build({ code: 'C', description: 'Room C' })
        ]
      }
    });
    settingsResources.getStation.mockImplementation((arg, success) =>
      success({
        data: StationFactory.build()
      })
    );

    settingsResources.updateStation.mockImplementation((arg, success, fail) =>
      fail({
        error: {
          details: [{ issue: 'an issue', type: 'model', value: 'UserAssignedValidation' }]
        }
      })
    );

    const form = mount(
      <Provider store={store}>
        <CreateStationForm match={{ params: { stationId: 12 } }} />
      </Provider>
    );

    form.find('form').simulate('submit');
    jestExpect(form.find('.pointing')).toHaveText('an issue');
    semanticUI.changeInput(form, 'userId', 'ALEX');
    jestExpect(form.find('.pointing')).not.toExist();
  });

  test('should go return to station maintenance on f4', () => {
    const props = { replacePath: jest.fn() };

    f4Behavior(props);

    jestExpect(props.replacePath).toHaveBeenCalledWith('/settings/stations');
  });
});
