import React from 'react';
import { Provider } from 'react-redux';
import { mount } from 'enzyme';
import CreateHousePar, { f4Behavior, FORM_NAME, mapStateToProps } from '../CreateHousePar';
import settingsResources from '../../../shared/api/settingsResources';
import productResources from '../../../shared/api/productResources';
import semanticUI from '../../../../test-helpers/semantic-ui';
import { createReduxStore } from '../../../store';
import productFactory from '../../../../test-factories/productFactory';
import HouseParFactory from '../../../../test-factories/housePar';

jest.mock('../../../shared/api/productResources');
jest.mock('../../../shared/api/settingsResources');

const productCode = '0079007';
const product = productFactory.build({ code: productCode });
const housePar = HouseParFactory.build({ product });

describe('createHousePar', () => {
  test('should set initial value on the redux form from path param', () => {
    productResources.getProductInfo.mockImplementation((arg, success) =>
      success({ data: product })
    );
    settingsResources.getHousePar.mockImplementation((arg, success) => success({ data: housePar }));

    const form = mount(
      <Provider store={createReduxStore({})}>
        <CreateHousePar
          match={{ params: { productCode: '0079007' } }}
          shouldAsyncValidate={() => true}
        />
      </Provider>
    );

    jestExpect(semanticUI.getInputValue(form, 'productCode')).toEqual('0079007');
    jestExpect(semanticUI.getLabelProp(form, 'PORTION', 'value')).toEqual('7 OZ');
    jestExpect(semanticUI.getInputValue(form, 'monday')).toEqual(12);
    jestExpect(semanticUI.getInputValue(form, 'tuesday')).toEqual(0);
    jestExpect(semanticUI.getInputValue(form, 'wednesday')).toEqual(0);
    jestExpect(semanticUI.getInputValue(form, 'thursday')).toEqual(0);
    jestExpect(semanticUI.getInputValue(form, 'friday')).toEqual(0);
  });

  test('should set initial value on the redux form from input change', () => {
    productResources.getProductInfo.mockImplementation((arg, success) =>
      Promise.resolve(success({ data: product }))
    );
    settingsResources.getHousePar.mockImplementation((arg, success) => success({ data: housePar }));

    const form = mount(
      <Provider store={createReduxStore({})}>
        <CreateHousePar match={{ params: {} }} shouldAsyncValidate={() => true} />
      </Provider>
    );

    semanticUI.changeInput(form, 'productCode', '0079007');

    jestExpect(semanticUI.getInputValue(form, 'productCode')).toEqual('0079007');
    jestExpect(semanticUI.getLabelProp(form, 'PORTION', 'value')).toEqual('7 OZ');
    jestExpect(semanticUI.getInputValue(form, 'monday')).toEqual(12);
    jestExpect(semanticUI.getInputValue(form, 'tuesday')).toEqual(0);
    jestExpect(semanticUI.getInputValue(form, 'wednesday')).toEqual(0);
    jestExpect(semanticUI.getInputValue(form, 'thursday')).toEqual(0);
    jestExpect(semanticUI.getInputValue(form, 'friday')).toEqual(0);
  });

  test('should set initial value on the redux form from input onBlur', () => {
    productResources.getProductInfo.mockImplementation((arg, success) =>
      Promise.resolve(success({ data: product }))
    );
    settingsResources.getHousePar.mockImplementation((arg, success) => success({ data: housePar }));

    const form = mount(
      <Provider store={createReduxStore({})}>
        <CreateHousePar match={{ params: {} }} shouldAsyncValidate={() => true} />
      </Provider>
    );

    semanticUI.blurInput(form, 'productCode', '0079007');

    jestExpect(semanticUI.getInputValue(form, 'productCode')).toEqual('0079007');
    jestExpect(semanticUI.getLabelProp(form, 'PORTION', 'value')).toEqual('7 OZ');
    jestExpect(semanticUI.getInputValue(form, 'monday')).toEqual(12);
    jestExpect(semanticUI.getInputValue(form, 'tuesday')).toEqual(0);
    jestExpect(semanticUI.getInputValue(form, 'wednesday')).toEqual(0);
    jestExpect(semanticUI.getInputValue(form, 'thursday')).toEqual(0);
    jestExpect(semanticUI.getInputValue(form, 'friday')).toEqual(0);
  });

  test('should fill out form and create successfully', () => {
    settingsResources.getHousePar.mockImplementation((arg, success) => success({ data: housePar }));
    settingsResources.createHousePar.mockImplementation((arg, success) => success({ data: {} }));

    const simulateEffectOfAsyncValidation = {
      productDuplicate: {
        products: {
          [productCode]: product
        }
      }
    };
    const form = mount(
      <Provider store={createReduxStore(simulateEffectOfAsyncValidation)}>
        <CreateHousePar match={{ params: {} }} shouldAsyncValidate={() => false} />
      </Provider>
    );

    semanticUI.changeInput(form, 'productCode', productCode);
    semanticUI.changeInput(form, 'monday', '1');

    form.find('form').simulate('submit');

    jestExpect(settingsResources.createHousePar.mock.calls[0][0]).toEqual({
      productCode,
      monday: 1
    });
  });

  test('should fill out form and update successfully', () => {
    settingsResources.getHousePar.mockImplementation((arg, success) => success({ data: housePar }));
    settingsResources.updateHousePar.mockImplementation((arg, success) => success({ data: {} }));

    const simulateEffectOfAsyncValidation = {
      productDuplicate: {
        products: {
          [productCode]: product
        }
      }
    };
    const form = mount(
      <Provider store={createReduxStore(simulateEffectOfAsyncValidation)}>
        <CreateHousePar match={{ params: { productCode } }} shouldAsyncValidate={() => false} />
      </Provider>
    );

    semanticUI.changeInput(form, 'monday', '314');

    form.find('form').simulate('submit');

    jestExpect(settingsResources.updateHousePar.mock.calls[0][0]).toEqual({
      id: housePar.id,
      productCode,
      monday: 314
    });
  });
});

describe('Mapping state to props', () => {
  test('should notice production products', () => {
    const productCode = '0079007';
    const state = {
      form: {
        [FORM_NAME]: {
          values: {
            productCode
          }
        }
      },
      settingsInfo: {
        housePar: {}
      },
      productDuplicate: {
        products: {
          [productCode]: {
            productOutput: 'FINISHED'
          }
        }
      },
      cuttingYieldModelInfo: {
        yieldModel: {}
      },
      yieldModelInfo: {}
    };

    jestExpect(mapStateToProps(state, { match: {} }).productIsProduction).toBe(true);
  });

  test('should warn of source products', () => {
    const productCode = '0079007';
    const state = {
      form: {
        [FORM_NAME]: {
          values: {
            productCode
          }
        }
      },
      settingsInfo: {
        housePar: {}
      },
      productDuplicate: {
        products: {
          [productCode]: {
            productOutput: 'SOURCE'
          }
        }
      },
      cuttingYieldModelInfo: {
        yieldModel: {}
      },
      yieldModelInfo: {}
    };

    jestExpect(mapStateToProps(state, { match: {} }).productIsProduction).toBe(false);
  });

  test('should notice products with pricing models', () => {
    const productCode = '0079007';
    const state = {
      form: {
        [FORM_NAME]: {
          values: {
            productCode
          }
        }
      },
      settingsInfo: {
        housePar: {}
      },
      productDuplicate: {
        products: {
          [productCode]: {
            cost: 10.5
          }
        }
      },
      cuttingYieldModelInfo: {
        yieldModel: {}
      },
      yieldModelInfo: {}
    };

    jestExpect(mapStateToProps(state, { match: {} }).productHasPricingModel).toBe(true);
  });

  test('should warn of products without pricing models', () => {
    const productCode = '0079007';
    const state = {
      form: {
        [FORM_NAME]: {
          values: {
            productCode
          }
        }
      },
      settingsInfo: {
        housePar: {}
      },
      productDuplicate: {
        products: {
          [productCode]: {}
        }
      },
      cuttingYieldModelInfo: {
        yieldModel: {}
      },
      yieldModelInfo: {}
    };

    jestExpect(mapStateToProps(state, { match: {} }).productHasPricingModel).toBe(false);
  });

  test('should go return to house par maintenance on f4', () => {
    const props = { replacePath: jest.fn() };

    f4Behavior(props);

    jestExpect(props.replacePath).toHaveBeenCalledWith('/settings/house-pars');
  });
});
