import React from 'react';
import { mount } from 'enzyme';
import configureStore from 'redux-mock-store';
import thunk from 'redux-thunk';
import settingsResources from '../../../shared/api/settingsResources';
import { UPDATE_HOUSE_PARS } from '../../actions/settingsActionTypes';
import HouseParFactory, { HOUSE_PAR_WITH_PRODUCT_2 } from '../../../../test-factories/housePar';
import productFactory from '../../../../test-factories/productFactory';
import MaintenanceTable from '../../components/MaintenanceTable';
import HouseParMaintenance, { formatHousePars } from '../HouseParMaintenance';
import { createReduxStore } from '../../../store';
import { replace } from 'react-router-redux';
import { Provider } from 'react-redux';

jest.mock('../../../shared/errors/ErrorNotification');
jest.mock('../../../shared/api/settingsResources');

let middleware = [thunk];
const createStore = configureStore(middleware);

const houseParsResponse = {
  data: [HouseParFactory.build()]
};

describe('HouseParMaintenance', () => {
  let wrapper;

  afterEach(() => {
    settingsResources.getHousePars.mockReset();
    settingsResources.deleteHousePar.mockReset();
  });

  test('should update settings reducer with list of house pars', () => {
    settingsResources.getHousePars.mockImplementation(callback => callback(houseParsResponse));

    let mockStore = createStore({ settingsInfo: { housePars: [] } });
    wrapper = mount(<HouseParMaintenance store={mockStore} />);

    jestExpect(mockStore.getActions()).toEqual([
      { type: UPDATE_HOUSE_PARS, payload: houseParsResponse.data }
    ]);
  });

  test('should render house pars headers when there are no house pars', () => {
    let mockStore = createStore({ settingsInfo: {} });
    wrapper = mount(<HouseParMaintenance store={mockStore} />);

    const houseParDom = wrapper.find(MaintenanceTable);

    jestExpect(houseParDom).toHaveLength(1);
    jestExpect(houseParDom.props().columns).toHaveLength(7);
    jestExpect(houseParDom.props().columns).toEqual(
      jestExpect.arrayContaining([
        {
          key: 'productInfo',
          pid: 'house-par-product',
          width: '6',
          headerText: 'Product'
        },
        {
          key: 'mon',
          pid: 'house-par-mon',
          width: '1',
          headerText: 'Mon',
          textAlign: 'right'
        },
        {
          key: 'tue',
          pid: 'house-par-tue',
          width: '1',
          headerText: 'Tue',
          textAlign: 'right'
        },
        {
          key: 'wed',
          pid: 'house-par-wed',
          width: '1',
          headerText: 'Wed',
          textAlign: 'right'
        },
        {
          key: 'thur',
          pid: 'house-par-thur',
          width: '1',
          headerText: 'Thur',
          textAlign: 'right'
        },
        {
          key: 'fri',
          pid: 'house-par-fri',
          width: '1',
          headerText: 'Fri',
          textAlign: 'right'
        }
      ])
    );

    jestExpect(houseParDom.props().columns[6].key).toEqual('createButton');
  });

  describe('column buttons', () => {
    test('should navigate to new house par on new button click', () => {
      const mockStore = createStore({ settingsInfo: {} });
      wrapper = mount(<HouseParMaintenance store={mockStore} />);
      mockStore.clearActions();

      wrapper.find('.primary.button').simulate('click');

      jestExpect(mockStore.getActions()).toEqual([replace('/settings/house-pars/create')]);
    });

    test('should navigate to existing house par via product code on edit button click', () => {
      const mockStore = createStore({
        settingsInfo: {
          housePars: [HouseParFactory.build({ product: productFactory.build({ code: '0078889' }) })]
        }
      });
      wrapper = mount(<HouseParMaintenance store={mockStore} />);
      mockStore.clearActions();

      wrapper.find('.icon-edit').simulate('click');

      jestExpect(mockStore.getActions()).toEqual([replace('/settings/house-pars/create/0078889')]);
    });

    test('should delete house par via product code on delete button click and delete modal click', () => {
      const store = createReduxStore({
        settingsInfo: {
          housePars: [HouseParFactory.build({ product: productFactory.build({ code: '0078889' }) })]
        }
      });

      wrapper = mount(
        <Provider store={store}>
          <HouseParMaintenance />
        </Provider>
      );

      wrapper.find('.icon-delete').simulate('click');

      const storeModalState = store.getState().confirmationModal;
      jestExpect(storeModalState).toMatchObject({
        content: 'Deletion will occur on the next working day. Are you sure you want to delete?',
        header: 'Delete House Par',
        showing: true,
        confirmButton: 'Delete',
        cancelButton: 'Cancel'
      });

      storeModalState.confirmAction();
      jestExpect(settingsResources.deleteHousePar.mock.calls[0][0]).toEqual('0078889');
    });
  });

  describe('formatHousePars', () => {
    test('should format and show house pars with correct order', () => {
      const housePars = [HouseParFactory.build(), HouseParFactory.build(HOUSE_PAR_WITH_PRODUCT_2)];
      const result = formatHousePars(housePars);

      jestExpect(result[0].productInfo.props.children[0].props.children).toEqual('0078889 / 4 OZ');
      jestExpect(result[0].productInfo.props.children[1].props.children).toEqual(
        'PRODUCT DESCRIPTION'
      );
      jestExpect(result[0]).toMatchObject({ mon: 0, tue: 14, wed: 0, thur: 4, fri: 0 });
      jestExpect(result[0].productCode).toEqual('0078889');

      jestExpect(result[1].productInfo.props.children[0].props.children).toEqual('0079007 / 2 OZ');
      jestExpect(result[1].productInfo.props.children[1].props.children).toEqual(
        'FLEMINGS CAB PRHOUSE STK'
      );
      jestExpect(result[1]).toMatchObject({ mon: 12, tue: 0, wed: 0, thur: 0, fri: 0 });
      jestExpect(result[1].productCode).toEqual('0079007');
    });
  });
});
