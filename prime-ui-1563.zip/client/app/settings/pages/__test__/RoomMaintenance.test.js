import React from 'react';
import { mount } from 'enzyme';
import configureStore from 'redux-mock-store';
import thunk from 'redux-thunk';

import RoomMaintenance from '../RoomMaintenance';
import settingsResources from '../../../shared/api/settingsResources';
import { UPDATE_ROOMS } from '../../actions/settingsActionTypes';
import MaintenanceTable from '../../components/MaintenanceTable';

jest.mock('../../../shared/errors/ErrorNotification');
jest.mock('../../../shared/api/settingsResources');

let middleware = [thunk];
const createStore = configureStore(middleware);

const roomsResponse = {
  data: [
    {
      id: 9999999,
      code: 'Q',
      description: 'Goat',
      portionRoomStatus: 'closed',
      roomType: 'CUTTING',
      openable: true
    },
    {
      id: 8888888,
      code: 'B',
      description: 'Steak',
      portionRoomStatus: 'open',
      roomType: 'CUTTING',
      openable: false
    }
  ]
};

describe('RoomMaintenance', () => {
  let wrapper;

  test('should update settings reducer with list of rooms', async done => {
    settingsResources.getRooms.mockImplementation(() => Promise.resolve({ roomsResponse }));
    done();

    let mockStore = createStore({ settingsInfo: { rooms: [] } });
    wrapper = mount(<RoomMaintenance store={mockStore} />);

    jestExpect(mockStore.getActions()).toEqual([
      { type: UPDATE_ROOMS, payload: roomsResponse.data }
    ]);
  });

  test('should order rooms alphabetically by room code', () => {
    let mockStore = createStore({ settingsInfo: { rooms: roomsResponse.data } });
    wrapper = mount(<RoomMaintenance store={mockStore} />);

    let roomCodes = wrapper.find('[pid="maintenance__room-code"]');
    jestExpect(roomCodes.at(1)).toHaveText(roomsResponse.data[1].code);
    jestExpect(roomCodes.at(2)).toHaveText(roomsResponse.data[0].code);
  });

  test('should render room headers when there are no rooms', () => {
    let mockStore = createStore({ settingsInfo: {} });
    wrapper = mount(<RoomMaintenance store={mockStore} />);

    const roomDom = wrapper.find(MaintenanceTable);

    jestExpect(roomDom).toHaveLength(1);

    jestExpect(roomDom.props()).toMatchObject({
      columns: jestExpect.arrayContaining([
        {
          key: 'code',
          pid: 'room-code',
          width: '2',
          headerText: 'Room'
        },
        {
          key: 'description',
          pid: 'room-description',
          width: '5',
          headerText: 'Description'
        },
        {
          key: 'roomType',
          pid: 'room-type',
          width: '3',
          headerText: 'Room Type'
        },
        {
          key: 'customerNumber',
          pid: 'room-customer-number',
          width: '3',
          headerText: 'Customer #',
          textAlign: 'right'
        }
      ])
    });
    jestExpect(roomDom.props().columns[4].key).toEqual('createButton');
    jestExpect(roomDom.props().items).toBeNull();
  });

  test('should navigate to create room page when clicking button', () => {
    let mockStore = createStore({ settingsInfo: { rooms: [] } });
    wrapper = mount(<RoomMaintenance store={mockStore} />);

    let buttonWrapper = wrapper.find('.primary.button');

    jestExpect(buttonWrapper).toHaveText('New');

    mockStore.clearActions();
    buttonWrapper.simulate('click');

    jestExpect(mockStore.getActions()).toEqual([
      {
        type: '@@router/CALL_HISTORY_METHOD',
        payload: { method: 'replace', args: ['/settings/rooms/create'] }
      }
    ]);
  });
});
