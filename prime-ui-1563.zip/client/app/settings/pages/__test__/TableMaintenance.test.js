import React from 'react';
import { mount } from 'enzyme';
import configureStore from 'redux-mock-store';
import thunk from 'redux-thunk';
import TableMaintenance from '../TableMaintenance';
import settingsResources from '../../../shared/api/settingsResources';
import MaintenanceTable from '../../components/MaintenanceTable';
import { createReduxStore } from '../../../store';
import { Provider } from 'react-redux';

jest.mock('../../../shared/errors/ErrorNotification');
jest.mock('../../../shared/api/settingsResources');

let middleware = [thunk];
const createStore = configureStore(middleware);

const tablesResponse = {
  data: [
    {
      tableId: 1,
      tableDescription: 'Prime Porterhouse Steak',
      tableCode: 3,
      stationId: 4,
      stationCode: 1,
      stationName: 'ENRIQUE',
      room: 'A'
    },
    {
      tableId: 2,
      tableDescription: 'Prime Porterhouse Steak',
      tableCode: 34,
      stationId: 5,
      stationCode: 17,
      stationName: 'ENRIQUE',
      room: 'A'
    },
    {
      tableId: 3,
      tableDescription: 'Prime Porterhouse Steak',
      tableCode: 56,
      stationId: 6,
      stationCode: 23,
      stationName: 'ENRIQUE',
      room: 'A'
    }
  ]
};

function replacePathAction(path) {
  return {
    type: '@@router/CALL_HISTORY_METHOD',
    payload: { method: 'replace', args: [path] }
  };
}

describe('TableMaintenance', () => {
  let wrapper, mockStore;

  test('should on edit button should navigate us to modify table page', () => {
    const mockStore = createStore({
      settingsInfo: { tables: tablesResponse.data }
    });

    const wrapper = mount(<TableMaintenance store={mockStore} />);

    const firstRowEditButton = wrapper.find('a').at(0);
    mockStore.clearActions();
    firstRowEditButton.simulate('click');

    let actions = mockStore.getActions();

    jestExpect(actions[0]).toEqual(replacePathAction('/settings/tables/create/1'));

    settingsResources.getTables.mockReset();
  });

  test('should get all tables and pass them to MaintenanceTable', () => {
    mockStore = createReduxStore({});
    settingsResources.getTables.mockImplementation(callback => callback(tablesResponse));

    const wrapper = mount(
      <Provider store={mockStore}>
        <TableMaintenance />
      </Provider>
    );

    const stationDom = wrapper.find(MaintenanceTable);

    jestExpect(stationDom).toHaveProp({
      items: [tablesResponse.data[0], tablesResponse.data[1], tablesResponse.data[2]]
    });
  });

  test('clicking on create button should navigate us to create table page', () => {
    let mockStore = createStore({ settingsInfo: { tables: [] } });
    wrapper = mount(<TableMaintenance store={mockStore} />);

    let buttonWrapper = wrapper.find('.primary.button');

    jestExpect(buttonWrapper).toHaveText('New');

    mockStore.clearActions();
    buttonWrapper.simulate('click');

    let actions = mockStore.getActions();

    jestExpect(actions).toEqual([
      {
        type: '@@router/CALL_HISTORY_METHOD',
        payload: {
          method: 'replace',
          args: ['/settings/tables/create']
        }
      }
    ]);
  });
});
