import { mount } from 'enzyme';
import React from 'react';
import { Provider } from 'react-redux';
import { createReduxStore } from '../../../store';
import Profile, { f4Behavior, ProfileComponent } from '../Profile';
import settingsResources from '../../../shared/api/settingsResources';
import ProfileFactory from '../../../../test-factories/Profile';
import semanticUI from '../../../../test-helpers/semantic-ui';
import { reduxForm } from 'redux-form';
import { showModal } from '../../../shared/actions/actions';
import { states } from '../../../shared/staticInfo/states';

const profileResponse = { data: ProfileFactory.build() };

jest.mock('../../../shared/actions/actions', () => ({
  showModal: jest.fn(() => ({ type: 'MOCK_SHOW_MODAL' })),
  hideModal: jest.fn(() => ({ type: 'MOCK_HIDE_MODAL' }))
}));
jest.mock('../../../shared/api/settingsResources');

describe('Profile', () => {
  let form, store;

  describe('on render', () => {
    test('should not set initial values for any fields on the redux form', () => {
      store = createReduxStore({});
      form = mount(
        <Provider store={store}>
          <Profile />
        </Provider>
      );

      jestExpect(semanticUI.getInputValue(form, 'plantNumber')).toEqual('');
      jestExpect(semanticUI.getInputValue(form, 'name')).toEqual('');
      jestExpect(semanticUI.getInputValue(form, 'address')).toEqual('');
      jestExpect(semanticUI.getInputValue(form, 'city')).toEqual('');
      jestExpect(semanticUI.getInputValue(form, 'zipCode')).toEqual('');
      jestExpect(semanticUI.getInputValue(form, 'establishmentNumber')).toEqual('');
      jestExpect(semanticUI.getInputValue(form, 'vendorShipFrom')).toEqual('');
      jestExpect(semanticUI.getInputValue(form, 'sequenceNumber')).toEqual('');
    });

    test('should pre-populate profile if profile exists', () => {
      settingsResources.getProfile.mockImplementation(callback => callback(profileResponse));

      store = createReduxStore({});
      form = mount(
        <Provider store={store}>
          <Profile />
        </Provider>
      );

      jestExpect(semanticUI.getInputValue(form, 'plantNumber')).toEqual('123');
      jestExpect(semanticUI.getInputValue(form, 'name')).toEqual('Sysco & newport');
      jestExpect(semanticUI.getInputValue(form, 'address')).toEqual("dont't know");
      jestExpect(semanticUI.getInputValue(form, 'city')).toEqual('Culver');
      jestExpect(semanticUI.getInputValue(form, 'zipCode')).toEqual('90230');
      jestExpect(semanticUI.getInputValue(form, 'establishmentNumber')).toEqual('4195');
      jestExpect(semanticUI.getInputValue(form, 'vendorShipFrom')).toEqual('123456');
      jestExpect(semanticUI.getInputValue(form, 'sequenceNumber')).toEqual('12');
    });

    test('call clearProfileInfoSpy when componentWillUnMount', () => {
      let DecoratedComponent = reduxForm({ form: 'testForm' })(ProfileComponent);
      let clearProfileInfo = jest.fn();
      let defaultInitialValues = {
        plantNumber: '111'
      };
      let wrapper = mount(
        <Provider store={createReduxStore({})}>
          <DecoratedComponent
            getProfile={() => {}}
            clearProfileInfo={clearProfileInfo}
            hideModal={() => {}}
            showModal={() => {}}
            replacePath={() => {}}
            createOrUpdateProfile={() => {}}
            confirmationModal={true}
            initialValues={defaultInitialValues}
            statesOption={states}
          />
        </Provider>
      );

      wrapper.unmount();

      jestExpect(clearProfileInfo).toHaveBeenCalled();
    });

    test('should hide modal on f4 when modal is showing', () => {
      let replacePath = jest.fn(() => ({ type: 'MOCK_REPLACE_PATH' }));
      const props = {
        hideModal: () => {},
        replacePath,
        createOrUpdateProfile: () => {},
        isModalShowing: false,
        initialValues: {
          plantNumber: '111'
        }
      };

      f4Behavior(props);

      jestExpect(replacePath).toHaveBeenCalledWith('/main-navigation');
    });
  });

  describe('profile warning popup', () => {
    const WARNING_HEADER = 'Warning';
    const POP_UP_CONTENT =
      'Changing this field could disrupt the flow of data between SUS and Prime. ' +
      'Are you sure you want to make this change?';

    beforeEach(() => {
      settingsResources.getProfile.mockImplementation(success => success(profileResponse));
      store = createReduxStore();
      form = mount(
        <Provider store={store}>
          <Profile />
        </Provider>
      );
    });

    afterEach(() => {
      settingsResources.getProfile.mockReset();
    });

    test('should show profile warning popup when changing plant number', () => {
      semanticUI.changeInput(form, 'plantNumber', '999');
      form.find('form').simulate('submit');

      jestExpect(showModal).toHaveBeenCalledWith(
        jestExpect.objectContaining({
          header: WARNING_HEADER,
          content: POP_UP_CONTENT,
          cancelButton: 'No',
          cancelAction: jestExpect.any(Function),
          confirmButton: 'Yes',
          confirmAction: jestExpect.any(Function)
        })
      );
    });

    test('should show profile warning popup when changing sequence number', () => {
      semanticUI.changeInput(form, 'sequenceNumber', '3');
      form.find('form').simulate('submit');

      jestExpect(showModal).toHaveBeenCalledWith(
        jestExpect.objectContaining({
          header: WARNING_HEADER,
          content: POP_UP_CONTENT,
          cancelButton: 'No',
          cancelAction: jestExpect.any(Function),
          confirmButton: 'Yes',
          confirmAction: jestExpect.any(Function)
        })
      );
    });

    test('should show profile warning popup when changing vendor ship from', () => {
      semanticUI.changeInput(form, 'vendorShipFrom', '999');

      form.find('form').simulate('submit');
      jestExpect(showModal).toHaveBeenCalledWith(
        jestExpect.objectContaining({
          header: WARNING_HEADER,
          content: POP_UP_CONTENT,
          cancelButton: 'No',
          cancelAction: jestExpect.any(Function),
          confirmButton: 'Yes',
          confirmAction: jestExpect.any(Function)
        })
      );
    });
  });

  describe('profile popup actions', () => {
    const profileValues = {
      plantNumber: '123',
      name: 'Sysco',
      address: '111',
      city: '111',
      zipCode: '90230',
      establishmentNumber: '111',
      vendorShipFrom: '1111',
      sequenceNumber: '11'
    };

    test('should hide modal on f4 when modal is showing', () => {
      const replacePath = jest.fn(() => ({ type: 'MOCK_REPLACE_PATH' }));
      const hideModal = jest.fn(() => ({ type: 'MOCK_HIDE_MODEL' }));
      const props = {
        hideModal,
        replacePath,
        createOrUpdateProfile: () => {},
        isModalShowing: true,
        initialValues: {
          plantNumber: '111'
        }
      };

      f4Behavior(props);

      jestExpect(hideModal).toHaveBeenCalledTimes(1);
      jestExpect(replacePath).not.toHaveBeenCalledWith('/main-navigation');
    });

    test('should call create action when confirming warning message ', () => {
      const createOrUpdateProfileAction = jest.fn();
      const props = {
        showModal: jest.fn(options => options.confirmAction()),
        hideModal: jest.fn(),
        createOrUpdateProfile: createOrUpdateProfileAction,
        confirmationModal: true,
        initialValues: {
          plantNumber: '111'
        }
      };
      const component = new ProfileComponent(props);

      component.submitWithConfirmation(profileValues);

      jestExpect(createOrUpdateProfileAction).toHaveBeenCalled();
    });

    test('should not call create Action when cancelling profile update ', () => {
      const createOrUpdateProfileAction = jest.fn();
      const hideModalAction = jest.fn();
      const props = {
        showModal: jest.fn(options => options.cancelAction()),
        hideModal: hideModalAction,
        createOrUpdateProfile: createOrUpdateProfileAction,
        confirmationModal: true,
        initialValues: {
          plantNumber: '111'
        }
      };

      const component = new ProfileComponent(props);
      component.submitWithConfirmation(profileValues);

      jestExpect(hideModalAction).toHaveBeenCalled();
      jestExpect(createOrUpdateProfileAction).not.toHaveBeenCalled();
    });
  });
});
