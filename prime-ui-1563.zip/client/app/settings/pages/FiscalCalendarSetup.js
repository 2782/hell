import React from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { Field, reduxForm } from 'redux-form';
import PropTypes from 'prop-types';
import { Button, Form } from 'semantic-ui-react';
import FormLabel from '../../shared/FormLabel';
import FormDayPickerInput from '../../shared/FormDayPickerInput';
import { getActiveFiscalCalendar, updateActiveFiscalCalendar } from '../actions/settingsActions';
import {
  fiscalCalendarMustSunday,
  mustFutureDate,
  mustBeValidDateFormat
} from '../../shared/validation/formFieldValidations';
import { DEFAULT_DISPLAY_DATE_FORMAT } from '../../shared/util/dateUtil';

class FiscalCalendarSetup extends React.Component {
  constructor(props) {
    super(props);
  }

  componentDidMount() {
    this.props.getActiveFiscalCalendar();
  }

  submit(values) {
    const { updateActiveFiscalCalendar, activeFiscalCalendar } = this.props;
    const data = { id: activeFiscalCalendar.id, nextStartDate: values.nextStartDate };
    updateActiveFiscalCalendar(data);
  }

  render() {
    const { handleSubmit, activeFiscalCalendar, submitting, pristine, valid } = this.props;

    return (
      <div className={'fiscal-calendar'}>
        <Form size={'large'} onSubmit={handleSubmit(this.submit.bind(this))}>
          <FormLabel
            width={6}
            label='CURRENT FISCAL CALENDAR START DATE'
            value={activeFiscalCalendar.startDate}
            pid={'fiscal-calendar_current_start_date'}
          />
          <Field
            component={FormDayPickerInput}
            width={6}
            name='nextStartDate'
            as={Form.Input}
            label='NEXT FISCAL CALENDAR START DATE'
            formatString={DEFAULT_DISPLAY_DATE_FORMAT}
            placeholder={DEFAULT_DISPLAY_DATE_FORMAT}
            value={activeFiscalCalendar.nextStartDate}
            dayPickerProps={{
              showOutsideDays: true,
              disabledDays: [{ daysOfWeek: [1, 2, 3, 4, 5, 6] }, { before: new Date() }]
            }}
            validate={[mustBeValidDateFormat, mustFutureDate, fiscalCalendarMustSunday]}
          />
          <div className={'submit-btn'}>
            <Button
              primary
              size={'large'}
              className='submit'
              loading={submitting}
              disabled={submitting || pristine || !valid}
            >
              Submit
            </Button>
          </div>
        </Form>
      </div>
    );
  }
}

FiscalCalendarSetup.propTypes = {
  handleSubmit: PropTypes.func.isRequired,
  getActiveFiscalCalendar: PropTypes.func.isRequired,
  updateActiveFiscalCalendar: PropTypes.func.isRequired,
  activeFiscalCalendar: PropTypes.object,
  submitting: PropTypes.bool.isRequired,
  pristine: PropTypes.bool.isRequired,
  valid: PropTypes.bool.isRequired
};

const mapStateToProps = state => {
  const { activeFiscalCalendar } = state.settingsInfo;
  return {
    initialValues: {
      nextStartDate: activeFiscalCalendar.nextStartDate
    },
    activeFiscalCalendar: activeFiscalCalendar
  };
};

const mapDispatchToProps = dispatch => {
  return bindActionCreators(
    {
      getActiveFiscalCalendar,
      updateActiveFiscalCalendar
    },
    dispatch
  );
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(
  reduxForm({
    form: 'fiscalCalendar',
    enableReinitialize: true
  })(FiscalCalendarSetup)
);
