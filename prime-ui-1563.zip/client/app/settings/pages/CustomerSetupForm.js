import React from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import {
  change,
  clearSubmitErrors,
  Field,
  FieldArray,
  formValueSelector,
  getFormSubmitErrors,
  reduxForm
} from 'redux-form';
import { Button, Divider, Form, Grid, Segment } from 'semantic-ui-react';
import FormLabel from '../../shared/FormLabel';
import FormElement from '../../shared/FormElement';
import {
  clearCustomer,
  getCustomer,
  getSubPrimal,
  setupCustomer
} from '../actions/settingsActions';
import _ from 'lodash';
import { NOT_A_CUSTOMER_CODE } from '../../../config/errorMessage';
import PropTypes from 'prop-types';
import subscriber from '../../shared/functionKeys/subscriber';
import SubPrimalTable from './SubPrimalTable';
import * as Validator from '../components/customerPackOffLabelSettingValidator';
import CustomerSpecificItemNumberTable from './CustomerSpecificItemNumberTable';
import { getProductPromise } from '../../shared/components/product/actionsDuplicate';
import FileImportSection from '../../uploadFile/FileImportSection';
import CheckBox from '../../shared/components/CheckBox';
import { clearUploadState } from '../../uploadFile/fileUploadActions';

const FORM_NAME = 'customerSetupForm';

const initFormSubPrimals = customer => {
  const subPrimals = [
    {
      default: true,
      subPrimalCode: 'Default',
      dateValue: _.toString(_.get(customer, 'dateValue', ''))
    }
  ];
  let existSubPrimals = [];
  if (customer.subPrimals) {
    existSubPrimals = customer.subPrimals.map(subPrimal => {
      const { subPrimalCode, dateValue } = subPrimal;
      return { default: false, subPrimalCode, dateValue: _.toString(dateValue) };
    });
  }
  return subPrimals.concat(existSubPrimals).concat({});
};

const initFormCustomerSpecificItemNumber = customer => {
  let existCustomerSpecificItemNumbers = [];
  if (!_.isUndefined(customer.customerSpecificItemNumbers)) {
    existCustomerSpecificItemNumbers = customer.customerSpecificItemNumbers.map(
      customerSpecificItem => {
        return { ...customerSpecificItem };
      }
    );
  }
  return existCustomerSpecificItemNumbers.concat({});
};

const getFileImporterErrorMessage = props => {
  const { fileImporterError } = props;

  let errorMessage = null;

  if (fileImporterError) {
    errorMessage = fileImporterError;
  }

  return errorMessage && <div className={'ui red message'}>{errorMessage}</div>;
};

export class CustomerSetup extends React.Component {
  constructor(props) {
    super(props);
    this.handleChangeOfIncludeCustomerLogo = this.handleChangeOfIncludeCustomerLogo.bind(this);
  }

  handleChangeOfIncludeCustomerLogo(e, { checked }) {
    const { clearState, clearSubmitErrors } = this.props;
    if (!checked) {
      clearState();
      clearSubmitErrors(FORM_NAME);
    }
  }

  componentWillUnmount() {
    const { clearCustomer, clearState } = this.props;
    clearCustomer();
    clearState();
  }

  componentDidUpdate(prevProps) {
    const { customer, getSubPrimal, getProductPromise } = this.props;

    if (customer && customer.subPrimals && !_.isEqual(prevProps.customer, customer)) {
      customer.subPrimals.forEach(subPrimal => {
        if (!subPrimal.default && !_.isEmpty(subPrimal.subPrimalCode)) {
          getSubPrimal(subPrimal.subPrimalCode);
        }
      });
    }

    if (
      customer &&
      customer.customerSpecificItemNumbers &&
      !_.isEqual(prevProps.customer, customer)
    ) {
      customer.customerSpecificItemNumbers.forEach(item => {
        if (!_.isEmpty(item.productCode)) {
          getProductPromise(item.productCode);
        }
      });
    }
  }

  submit(values) {
    const { subPrimals, customerSpecificItemNumbers } = values;
    const { setupCustomer } = this.props;

    const defaultDateValue = _.find(subPrimals, 'default').dateValue;

    const validSubPrimals = _.filter(subPrimals, subPrimal => {
      return !subPrimal.default && !_.isEmpty(subPrimal.subPrimalCode);
    });

    const validItemNumbers = _.filter(customerSpecificItemNumbers, itemNumber => {
      return !_.isEmpty(itemNumber) && !_.isEmpty(itemNumber.itemNumber);
    });

    const customerSetupData = {
      ...values,
      dateValue: defaultDateValue,
      subPrimals: validSubPrimals,
      customerSpecificItemNumbers: validItemNumbers
    };

    return setupCustomer(customerSetupData);
  }

  handleDateTypeOnChange(newValue) {
    const { customer, changeSubPrimals } = this.props;

    if (customer.dateType !== newValue) {
      changeSubPrimals([{ default: true, subPrimalCode: 'Default' }]);
    } else {
      changeSubPrimals(initFormSubPrimals(customer));
    }
  }

  render() {
    const {
      handleSubmit,
      submitting,
      pristine,
      invalid,
      customer,
      clearCustomer,
      subPrimals,
      subPrimalsExist,
      currentlySelectedDateType,
      currentlyChoiceIncludeCustomerLogo,
      fileSelected,
      initialValues,
      fileImporterError
    } = this.props;

    const fileChanged =
      (!initialValues.includeCustomerLogo && fileSelected) ||
      (initialValues.includeCustomerLogo && fileSelected);

    const dateTypeOptions = [
      { key: 0, text: 'NONE', value: 'NONE' },
      { key: 1, text: 'FREEZE BY', value: 'FREEZEBY' },
      { key: 2, text: 'BEST BY', value: 'BESTBY' },
      { key: 3, text: 'SELL BY', value: 'SELLBY' }
    ];

    return (
      <div className={'customer-setup'}>
        <Form size={'large'} onSubmit={handleSubmit(this.submit.bind(this))}>
          <Grid>
            <Grid.Row>
              <Grid.Column width={5}>
                <Field
                  name='customerCode'
                  component={FormElement}
                  as={Form.Input}
                  autoFocus={true}
                  type='text'
                  label='Customer #'
                  onChange={clearCustomer}
                  width={15}
                />
              </Grid.Column>

              <Grid.Column width={10}>
                <FormLabel
                  className={'customer-setup-customer-name'}
                  width={15}
                  label={''}
                  value={customer.name}
                />
              </Grid.Column>
            </Grid.Row>
          </Grid>

          <Divider hidden className='customer-divider' />

          <div className='dateType-container'>
            <Grid>
              <Grid.Row>
                <Grid.Column width={6}>
                  <Field
                    component={FormElement}
                    as={Form.Select}
                    name='dateType'
                    options={dateTypeOptions}
                    type='text'
                    width={15}
                    onChange={(event, newValue) => {
                      this.handleDateTypeOnChange(newValue);
                    }}
                    className='date-type-dropdown'
                    label='Date Type'
                  />
                </Grid.Column>
              </Grid.Row>
            </Grid>

            <Divider hidden className='date-type-divider' />

            {currentlySelectedDateType === 'NONE' ? null : (
              <Form.Group className='customer-setup-fields'>
                <FieldArray
                  name={'subPrimals'}
                  component={SubPrimalTable}
                  props={{ subPrimals, subPrimalsExist }}
                />
              </Form.Group>
            )}
          </div>

          <div className='dateType-container'>
            <FormLabel
              className='date-type-dropdown'
              width={16}
              label='Customer Specific Item Numbers'
            />

            <Form.Group className='customer-setup-fields'>
              <FieldArray
                name='customerSpecificItemNumbers'
                width={16}
                component={CustomerSpecificItemNumberTable}
              />
            </Form.Group>
          </div>

          <div className='dateType-container'>
            <Form.Group inline>
              <span className='logo-image-checkbox' />
              <Field
                width={16}
                component={CheckBox}
                name='includeCustomerLogo'
                pid='customer-setup__include-customer-logo'
                className='logo-image-checkbox'
                label='Display Customer Logo'
                disabled={_.isEmpty(customer)}
                onChange={this.handleChangeOfIncludeCustomerLogo}
              />
            </Form.Group>

            {!currentlyChoiceIncludeCustomerLogo ? null : (
              <Segment>
                {customer.customerImageFile ? (
                  <span>
                    Current Logo File: <u>{customer.customerImageFile.fileName}</u>
                    <p />
                  </span>
                ) : null}
                <FileImportSection
                  message={'Choose a file to import. Must be a .jpg, .jpeg, .png. or .bmp'}
                  fileTypes={'.jpg,.jpeg,.png,.bmp'}
                  formName={FORM_NAME}
                  maxFileSizeMb={1}
                />
                {getFileImporterErrorMessage(this.props)}
              </Segment>
            )}
          </div>

          <Divider hidden />

          <Button
            primary
            size={'large'}
            className='submit'
            disabled={
              _.isEmpty(customer) ||
              (invalid || fileImporterError) ||
              submitting ||
              (fileChanged
                ? false
                : !initialValues.includeCustomerLogo && currentlyChoiceIncludeCustomerLogo
                ? true
                : pristine)
            }
          >
            Save
          </Button>
        </Form>
      </div>
    );
  }
}

CustomerSetup.propTypes = {
  clearState: PropTypes.func,
  getCustomer: PropTypes.func.isRequired,
  setupCustomer: PropTypes.func.isRequired,
  clearCustomer: PropTypes.func.isRequired,
  changeSubPrimals: PropTypes.func.isRequired,
  handleSubmit: PropTypes.func.isRequired,
  submitting: PropTypes.bool.isRequired,
  pristine: PropTypes.bool.isRequired,
  invalid: PropTypes.bool.isRequired,
  initialValues: PropTypes.object,
  customer: PropTypes.object,
  subPrimals: PropTypes.object,
  subPrimalsExist: PropTypes.object,
  getSubPrimal: PropTypes.func.isRequired,
  getProductPromise: PropTypes.func.isRequired,
  currentlySelectedDateType: PropTypes.oneOf(['NONE', 'FREEZEBY', 'BESTBY', 'SELLBY']),
  currentlyChoiceIncludeCustomerLogo: PropTypes.bool,
  includeCustomerLogo: PropTypes.bool,
  fileSelected: PropTypes.bool,
  fileImporterError: PropTypes.string,
  error: PropTypes.string,
  clearSubmitErrors: PropTypes.func
};

const selector = formValueSelector(FORM_NAME);

const mapStateToProps = state => {
  const { customer, subPrimals, subPrimalsExist } = state.settingsInfo;
  const customerCode = _.get(customer, 'customerCode', '');
  const dateType = customer && customer.dateType ? customer.dateType : 'NONE';
  const customerDateValue = _.toString(_.get(customer, 'dateValue', ''));
  const initSubPrimals = initFormSubPrimals(customer);
  const initCustomerSpecificItemNumbers = initFormCustomerSpecificItemNumber(customer);
  const currentlySelectedDateType = selector(state, 'dateType');
  const currentlyChoiceIncludeCustomerLogo = selector(state, 'includeCustomerLogo');
  const includeCustomerLogo = customer && !_.isEmpty(customer.customerImageFile);
  const fileSelected =
    currentlyChoiceIncludeCustomerLogo && state.uploadFileReducer.selectedFile ? true : false;
  const { errorMessages } = state.uploadFileReducer;

  return {
    initialValues: {
      customerCode,
      dateType,
      dateValue: customerDateValue,
      subPrimals: initSubPrimals,
      customerSpecificItemNumbers: initCustomerSpecificItemNumbers,
      includeCustomerLogo
    },
    customer,
    subPrimals,
    subPrimalsExist,
    currentlySelectedDateType,
    currentlyChoiceIncludeCustomerLogo,
    fileSelected,
    fileImporterError: !_.isEmpty(errorMessages)
      ? errorMessages
      : getFormSubmitErrors(FORM_NAME)(state).fileImporter
  };
};

export const asyncValidate = (values, dispatch, props) => {
  const { customerCode } = values;
  const { getCustomer } = props;

  if (!_.isEmpty(customerCode)) {
    return getCustomer(customerCode).catch(() => ({ customerCode: NOT_A_CUSTOMER_CODE }));
  } else {
    return Promise.reject({ customerCode: 'Required' });
  }
};

const mapDispatchToProps = dispatch => {
  return bindActionCreators(
    {
      clearState: clearUploadState,
      clearSubmitErrors,
      getCustomer,
      setupCustomer,
      clearCustomer,
      changeSubPrimals: value => {
        return dispatch(change(FORM_NAME, 'subPrimals', value));
      },
      getSubPrimal,
      getProductPromise
    },
    dispatch
  );
};

export const f4Behavior = props => {
  const { replacePath, clearState } = props;
  clearState();
  replacePath('/settings/customers-packoff-display');
};

const CustomerSetupForm = connect(
  mapStateToProps,
  mapDispatchToProps
)(
  reduxForm({
    form: FORM_NAME,
    enableReinitialize: true,
    asyncValidate,
    asyncBlurFields: ['customerCode'],
    validate: Validator.validateFields
  })(
    subscriber(CustomerSetup, {
      f4Behavior,
      targetComponent: 'CustomerSetup',
      uris: {
        F4: ['#/settings/customers-packoff-display/customer-setup']
      }
    })
  )
);

export default CustomerSetupForm;
