import React from 'react';
import PropTypes from 'prop-types';
import MaintenanceTable, { iconButton } from '../components/MaintenanceTable';
import { Button } from 'semantic-ui-react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { replacePath } from '../../shared/actions/actions';
import { getAllTarePackages } from '../actions/tarePackagesActions';
import { renderPackageMaintenanceTableBody } from '../utils/renderTable';

export class TareMaintenanceComponent extends React.Component {
  componentDidMount() {
    const { getAllTarePackages } = this.props;
    getAllTarePackages();
  }

  editTare(tareId) {
    this.props.replacePath(`/settings/tare-packages/create/${tareId}`);
  }

  createTare() {
    this.props.replacePath('/settings/tare-packages/create');
  }

  createHeaderColumns() {
    return [
      {
        key: 'boxDescription',
        pid: 'box-description',
        width: '4',
        headerText: 'Box Description'
      },
      {
        key: 'boxTare',
        pid: 'box-tare',
        width: '2',
        headerText: 'Box Tare',
        textAlign: 'right'
      },
      {
        key: 'filmDescription',
        pid: 'film-description',
        width: '4',
        headerText: 'Film Description',
        textAlign: 'right'
      },
      {
        key: 'filmTare',
        pid: 'film-tare',
        width: '2',
        headerText: 'Film Tare',
        textAlign: 'right'
      },
      {
        key: 'defaulted',
        pid: 'defaulted',
        width: '2',
        headerText: 'Default',
        textAlign: 'center'
      },
      {
        key: 'createButton',
        pid: 'room-create-button',
        width: '3',
        headerText: (
          <Button primary size={'small'} onClick={this.createTare.bind(this)}>
            {'New'}
          </Button>
        ),
        textAlign: 'center',
        value: data => {
          return (
            <a onClick={this.editTare.bind(this, data.id)}>
              <i style={iconButton} className='icon-edit' />
            </a>
          );
        }
      }
    ];
  }

  render() {
    return (
      <MaintenanceTable
        columns={this.createHeaderColumns()}
        tableBody={renderPackageMaintenanceTableBody}
        items={this.props.tarePackages}
      />
    );
  }
}

TareMaintenanceComponent.propTypes = {
  replacePath: PropTypes.func.isRequired,
  getAllTarePackages: PropTypes.func.isRequired,
  tarePackages: PropTypes.array
};

const mapStateToProps = state => ({
  tarePackages: state.tarePackages.tarePackages
});

const mapDispatchToProps = dispatch =>
  bindActionCreators(
    {
      replacePath,
      getAllTarePackages
    },
    dispatch
  );

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(TareMaintenanceComponent);
