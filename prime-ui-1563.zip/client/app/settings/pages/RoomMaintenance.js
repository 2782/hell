import _ from 'lodash';
import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { getRooms } from '../actions/settingsActions';
import { replacePath } from '../../shared/actions/actions';
import { Button } from 'semantic-ui-react';
import MaintenanceTable from '../components/MaintenanceTable';
import { renderMaintenanceTableBody } from '../utils/renderTable';

class RoomMaintenance extends React.Component {
  constructor(props) {
    super(props);

    this.createRoom = this.createRoom.bind(this);
  }

  componentWillMount() {
    this.props.getRooms();
  }

  createRoom() {
    this.props.replacePath('/settings/rooms/create');
  }

  getRoomColumns() {
    return [
      {
        key: 'code',
        pid: 'room-code',
        width: '2',
        headerText: 'Room'
      },
      {
        key: 'description',
        pid: 'room-description',
        width: '5',
        headerText: 'Description'
      },
      {
        key: 'roomType',
        pid: 'room-type',
        width: '3',
        headerText: 'Room Type'
      },
      {
        key: 'customerNumber',
        pid: 'room-customer-number',
        width: '3',
        headerText: 'Customer #',
        textAlign: 'right'
      },
      {
        key: 'createButton',
        pid: 'room-create-button',
        width: '3',
        headerText: (
          <Button primary size={'small'} onClick={this.createRoom}>
            {'New'}
          </Button>
        ),
        textAlign: 'center'
      }
    ];
  }

  sortRoomsAlphabetically() {
    return this.props.rooms ? _.orderBy(this.props.rooms, ['code', 'description']) : null;
  }

  render() {
    return (
      <MaintenanceTable
        items={this.sortRoomsAlphabetically()}
        columns={this.getRoomColumns()}
        tableBody={renderMaintenanceTableBody}
      />
    );
  }
}

RoomMaintenance.propTypes = {
  rooms: PropTypes.array,
  replacePath: PropTypes.func.isRequired,
  getRooms: PropTypes.func.isRequired
};

const mapStateToProps = state => ({
  rooms: state.settingsInfo.rooms
});

const mapDispatchToProps = dispatch =>
  bindActionCreators(
    {
      getRooms,
      replacePath
    },
    dispatch
  );

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(RoomMaintenance);
