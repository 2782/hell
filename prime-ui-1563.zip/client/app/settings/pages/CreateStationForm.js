import React from 'react';
import PropTypes from 'prop-types';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import { Field, formValueSelector, reduxForm } from 'redux-form';
import { Button, Divider, Form, Message } from 'semantic-ui-react';
import FormElement from '../../shared/FormElement';
import {
  clearStation,
  createStation,
  getStation,
  hideError,
  updateStation
} from '../actions/settingsActions';
import { getPortionRooms } from '../../landingPage/actions/landingPageActions';
import { processErrorResponse, validateSubmission } from '../components/createStationFormValidator';
import _ from 'lodash';
import subscriber from '../../shared/functionKeys/subscriber';
import {
  noStartingSpaces,
  onlyPositiveWholeNumber
} from '../../shared/normalizers/formFieldNormalizers';
import { required } from '../../shared/validation/formFieldValidations';

const FORM_NAME = 'createStation';

export class CreateStationFormPage extends React.Component {
  constructor(props) {
    super(props);

    this.submit = this.submit.bind(this);
    this.onChange = this.onChange.bind(this);
  }

  submit(values) {
    const {
      modifyingExistingStation,
      createStation,
      updateStation,
      match: {
        params: { stationId }
      }
    } = this.props;

    validateSubmission(values);
    if (modifyingExistingStation) {
      values.id = stationId;
      return updateStation(values, error => processErrorResponse(error));
    } else {
      return createStation(values, error => processErrorResponse(error));
    }
  }

  componentDidMount() {
    const {
      getPortionRooms,
      getStation,
      hideError,
      match: {
        params: { stationId }
      }
    } = this.props;

    hideError();

    if (stationId) {
      getStation(stationId);
    }
    getPortionRooms();
  }

  componentWillMount() {
    const { clearStation } = this.props;
    clearStation();
  }

  onChange() {
    const { submitError, hideError } = this.props;
    if (submitError) {
      hideError();
    }
  }

  getNotification() {
    const { submitError } = this.props;
    if (submitError) {
      return <Message color='red'>{submitError}</Message>;
    }
  }

  render() {
    const {
      handleSubmit,
      portionRoomOptions,
      submitting,
      pristine,
      modifyingExistingStation,
      shouldShowRetail
    } = this.props;

    return (
      <div className={'create-station-wrapper'}>
        <Form size={'large'} onSubmit={handleSubmit(this.submit)}>
          <Form.Group>
            <Field
              name='stationCode'
              component={FormElement}
              disabled={modifyingExistingStation}
              as={Form.Input}
              autoFocus={true}
              type='text'
              label='Station #'
              width={6}
              onChange={this.onChange}
              maxLength={2}
              normalize={onlyPositiveWholeNumber}
              validate={[required]}
            />

            <Field
              name='name'
              component={FormElement}
              as={Form.Input}
              type='text'
              label='Name'
              width={8}
              onChange={this.onChange}
              maxLength={12}
              normalize={noStartingSpaces}
              validate={[required]}
            />
          </Form.Group>

          <Form.Group>
            <Field
              name='printer'
              component={FormElement}
              as={Form.Input}
              type='text'
              label='Printer IP'
              width={8}
              onChange={this.onChange}
              validate={[required]}
              normalize={noStartingSpaces}
            />
            <Field
              name='userId'
              component={FormElement}
              as={Form.Input}
              type='text'
              label='User ID'
              width={6}
              onChange={this.onChange}
              maxLength={20}
              normalize={noStartingSpaces}
            />
          </Form.Group>

          <Form.Group>
            <Field
              component={FormElement}
              name='type'
              as={Form.Select}
              options={[
                { key: 0, text: 'PRODUCTION', value: 'PRODUCTION' },
                { key: 1, text: 'PACKOFF', value: 'PACKOFF' }
              ]}
              type='text'
              label='type'
              disabled={modifyingExistingStation}
              width={8}
              onChange={this.onChange}
              validate={[required]}
            />
          </Form.Group>

          {shouldShowRetail ? (
            <Form.Group>
              <Field
                name='retailPrinter'
                component={FormElement}
                as={Form.Input}
                type='text'
                label='Retail Printer IP'
                width={8}
                onChange={this.onChange}
                validate={[required]}
                normalize={noStartingSpaces}
              />
            </Form.Group>
          ) : null}

          <Form.Group>
            <Field
              component={FormElement}
              name='room'
              as={Form.Select}
              options={portionRoomOptions}
              type='text'
              label='room'
              width={8}
              onChange={this.onChange}
              validate={[required]}
            />
          </Form.Group>

          <Button
            primary
            size={'large'}
            loading={submitting}
            disabled={submitting || pristine}
            id='save-station-button'
          >
            <i className={'icon icon-save'} />
            Save
          </Button>
          <Divider hidden />
          {this.getNotification()}
        </Form>
      </div>
    );
  }
}

CreateStationFormPage.propTypes = {
  clearStation: PropTypes.func.isRequired,
  createStation: PropTypes.func.isRequired,
  updateStation: PropTypes.func.isRequired,
  getStation: PropTypes.func.isRequired,
  getPortionRooms: PropTypes.func.isRequired,
  portionRoomOptions: PropTypes.array.isRequired,
  modifyingExistingStation: PropTypes.bool.isRequired,
  hideError: PropTypes.func.isRequired,
  submitError: PropTypes.string.isRequired,

  match: PropTypes.shape({
    params: PropTypes.shape({
      stationId: PropTypes.oneOfType([PropTypes.string, PropTypes.number])
    })
  }),

  handleSubmit: PropTypes.func.isRequired,
  submitting: PropTypes.bool.isRequired,
  pristine: PropTypes.bool.isRequired,
  shouldShowRetail: PropTypes.bool
};

const generatePortionRoomOptions = portionRooms => {
  return portionRooms.map(({ code, description }, index) => {
    return { key: index, text: `${code} - ${description}`, value: code };
  });
};

const selector = formValueSelector(FORM_NAME);
const mapStateToProps = state => {
  const portionRooms = state.portionRoomsInfo.portionRooms;
  const station = state.settingsInfo.station;
  const error = state.settingsInfo.error;

  return {
    initialValues: {
      stationCode: String(_.get(station, 'stationCode', '')),
      room: _.get(station, 'room', ''),
      name: _.get(station, 'name', ''),
      printer: _.get(station, 'printer', ''),
      retailPrinter: _.get(station, 'retailPrinter', ''),
      type: _.get(station, 'type', ''),
      userId: _.get(station, 'userId', '')
    },
    submitError: error.message,
    shouldShowRetail: selector(state, 'type') === 'PACKOFF',
    modifyingExistingStation: !_.isEmpty(station),
    portionRoomOptions: generatePortionRoomOptions(portionRooms)
  };
};

const mapDispatchToProps = dispatch =>
  bindActionCreators(
    {
      clearStation,
      createStation,
      updateStation,
      getPortionRooms,
      getStation,
      hideError
    },
    dispatch
  );

export const f4Behavior = props => {
  props.replacePath('/settings/stations');
};

const CreateStationForm = connect(
  mapStateToProps,
  mapDispatchToProps
)(
  reduxForm({
    form: FORM_NAME,
    enableReinitialize: true
  })(
    subscriber(CreateStationFormPage, {
      f4Behavior,
      targetComponent: 'CreateStationForm',
      uris: {
        F4: ['#/settings/stations/create', '#/settings/stations/create/*']
      }
    })
  )
);

export default CreateStationForm;
