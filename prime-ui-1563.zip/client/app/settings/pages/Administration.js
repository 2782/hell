import _ from 'lodash';
import PropTypes from 'prop-types';
import React from 'react';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import { Route, Switch } from 'react-router-dom';
import { replacePath, setHeaderAndFooter } from '../../shared/actions/actions';
import {
  COMPANY_PROFILE_FOOTER,
  F4_F2,
  MODIFY_STATION_FOOTER,
  MODIFY_TABLE_FOOTER,
  NEW_ROOM_FOOTER,
  NEW_STATION_FOOTER,
  NEW_TABLE_FOOTER
} from '../../shared/components/pageFooters';
import SideNavigation from '../../shared/components/SideNavigation';
import WorkdaySettings from './WorkdaySettings';
import CreateStationForm from './CreateStationForm';
import CreateTableForm from './CreateTableForm';
import StationMaintenance from './StationMaintenance';
import TableMaintenance from './TableMaintenance';
import RoomMaintenance from './RoomMaintenance';
import CreateRoom from './CreateRoom';
import HouseParMaintenance from './HouseParMaintenance';
import {
  COMPANY_PROFILE,
  CREATE_HOUSE_PAR,
  CREATE_NEW_PACKAGE_TARE,
  CUSTOMER_SETUP,
  FISCAL_CALENDAR,
  HOUSE_PAR,
  MODIFY_HOUSE_PAR,
  MODIFY_PACKAGE_TARE,
  MODIFY_STATION,
  MODIFY_TABLE,
  NEW_ROOM,
  NEW_STATION,
  NEW_TABLE,
  PACKAGE_TARE_SETUP,
  ROOM_MAINTENANCE,
  STATION_MAINTENANCE,
  TABLE_MAINTENANCE,
  WORKDAY_SETTINGS
} from '../../shared/components/pageTitles';
import Profile from './Profile';
import CreateHousePar from './CreateHousePar';
import TareMaintenance from './TareMaintenance';
import CreateTarePackage from './CreateTarePackage';
import FiscalCalendarSetup from './FiscalCalendarSetup';
import CustomerPackoffSetupMaintenance from './CustomerPackoffSetupMaintenance';
import CustomerSetupForm from './CustomerSetupForm';
import subscriber, { f2BehaviorForSideNavigation } from '../../shared/functionKeys/subscriber';

const WORKDAY_SETTINGS_PATH = '/workday';
const CREATE_TABLE_PATH = '/tables/create';
const UPDATE_TABLE_PATH = '/tables/create/:tableId(\\d+)';
const TABLE_MAINTENANCE_PATH = '/tables';
const CREATE_STATION_PATH = '/stations/create';
const UPDATE_STATION_PATH = '/stations/create/:stationId(\\d+)';
const STATION_MAINTENANCE_PATH = '/stations';
const CREATE_ROOM_PATH = '/rooms/create';
const ROOM_MAINTENANCE_PATH = '/rooms';
const COMPANY_PROFILE_PATH = '/profile';
const HOUSE_PAR_PATH = '/house-pars';
const CREATE_HOUSE_PAR_PATH = '/house-pars/create';
const UPDATE_HOUSE_PAR_PATH = '/house-pars/create/:productCode(\\d+)';
const TARE_PACKAGES_PATH = '/tare-packages';
const CREATE_TARE_PACKAGE_PATH = '/tare-packages/create';
const UPDATE_TARE_PACKAGE_PATH = '/tare-packages/create/:tareId(\\d+)';
const FISCAL_CALENDAR_SETUP_PATH = '/fiscal-calendar-setup';
const CUSTOMERS_PACKOFF_DISPLAY_PATH = '/customers-packoff-display';
const CUSTOMER_SETUP_PATH = '/customers-packoff-display/customer-setup';

const SUB_PAGE_CONFIG = [
  {
    path: COMPANY_PROFILE_PATH,
    pageTitle: COMPANY_PROFILE,
    footerSpecification: COMPANY_PROFILE_FOOTER
  },
  {
    path: WORKDAY_SETTINGS_PATH,
    pageTitle: WORKDAY_SETTINGS
  },
  {
    path: `${CREATE_TABLE_PATH}/(\\d+)`,
    pageTitle: MODIFY_TABLE,
    footerSpecification: MODIFY_TABLE_FOOTER
  },
  {
    path: CREATE_TABLE_PATH,
    pageTitle: NEW_TABLE,
    footerSpecification: NEW_TABLE_FOOTER
  },
  {
    path: TABLE_MAINTENANCE_PATH,
    pageTitle: TABLE_MAINTENANCE
  },
  {
    path: `${CREATE_STATION_PATH}/(\\d+)`,
    pageTitle: MODIFY_STATION,
    footerSpecification: MODIFY_STATION_FOOTER
  },
  {
    path: CREATE_STATION_PATH,
    pageTitle: NEW_STATION,
    footerSpecification: NEW_STATION_FOOTER
  },
  {
    path: STATION_MAINTENANCE_PATH,
    pageTitle: STATION_MAINTENANCE
  },
  {
    path: CREATE_ROOM_PATH,
    pageTitle: NEW_ROOM,
    footerSpecification: NEW_ROOM_FOOTER
  },
  {
    path: ROOM_MAINTENANCE_PATH,
    pageTitle: ROOM_MAINTENANCE
  },
  {
    path: `${CREATE_HOUSE_PAR_PATH}/(\\d+)`,
    pageTitle: MODIFY_HOUSE_PAR
  },
  {
    path: CREATE_HOUSE_PAR_PATH,
    pageTitle: CREATE_HOUSE_PAR
  },
  {
    path: HOUSE_PAR_PATH,
    pageTitle: HOUSE_PAR
  },
  {
    path: `${CREATE_TARE_PACKAGE_PATH}/(\\d+)`,
    pageTitle: MODIFY_PACKAGE_TARE
  },
  {
    path: CREATE_TARE_PACKAGE_PATH,
    pageTitle: CREATE_NEW_PACKAGE_TARE
  },
  {
    path: TARE_PACKAGES_PATH,
    pageTitle: PACKAGE_TARE_SETUP
  },
  {
    path: FISCAL_CALENDAR_SETUP_PATH,
    pageTitle: FISCAL_CALENDAR
  },
  {
    path: CUSTOMERS_PACKOFF_DISPLAY_PATH,
    pageTitle: CUSTOMER_SETUP
  },
  {
    path: CUSTOMER_SETUP_PATH,
    pageTitle: CUSTOMER_SETUP
  }
];

class Administration extends React.Component {
  componentWillReceiveProps(nextProps) {
    this.setPageConfig(nextProps.location.pathname);
  }

  componentWillUpdate() {
    setTimeout(() => this.scrollToTop(), 50);
  }

  componentDidMount() {
    this.setPageConfig(this.props.location.pathname);
    this.scrollToTop();
  }

  scrollToTop() {
    if (this.scrollToTopRef && this.scrollToTopRef.scrollIntoView) {
      this.scrollToTopRef.scrollIntoView({
        behavior: 'smooth',
        block: 'start',
        inline: 'nearest'
      });
    }
  }

  setPageConfig(currentPath) {
    const matched = config => !!currentPath.match(`/settings${config.path}`);
    const pageConfig = _.find(SUB_PAGE_CONFIG, matched);

    this.props.setHeaderAndFooter({
      header: pageConfig.pageTitle,
      footer: _.get(pageConfig, 'footerSpecification', F4_F2)
    });
  }

  subRouteLinks() {
    const { match } = this.props;
    return [
      {
        path: COMPANY_PROFILE_PATH,
        name: 'profile',
        toPath: () => {
          this.props.replacePath(`${match.url}${COMPANY_PROFILE_PATH}`);
        },
        category: 'company'
      },
      {
        path: WORKDAY_SETTINGS_PATH,
        name: 'workday/holidays',
        toPath: () => {
          this.props.replacePath(`${match.url}${WORKDAY_SETTINGS_PATH}`);
        },
        category: 'company'
      },
      {
        path: FISCAL_CALENDAR_SETUP_PATH,
        name: 'Fiscal Calendar',
        toPath: () => {
          this.props.replacePath(`${match.url}${FISCAL_CALENDAR_SETUP_PATH}`);
        },
        category: 'corporate'
      },
      {
        path: TABLE_MAINTENANCE_PATH,
        name: 'table maintenance',
        toPath: () => {
          this.props.replacePath(`${match.url}${TABLE_MAINTENANCE_PATH}`);
        },
        category: 'portion room'
      },
      {
        path: STATION_MAINTENANCE_PATH,
        name: 'station maintenance',
        toPath: () => {
          this.props.replacePath(`${match.url}${STATION_MAINTENANCE_PATH}`);
        },
        category: 'portion room'
      },
      {
        path: ROOM_MAINTENANCE_PATH,
        name: 'room maintenance',
        toPath: () => {
          this.props.replacePath(`${match.url}${ROOM_MAINTENANCE_PATH}`);
        },
        category: 'portion room'
      },
      {
        path: HOUSE_PAR_PATH,
        name: 'house par',
        toPath: () => {
          this.props.replacePath(`${match.url}${HOUSE_PAR_PATH}`);
        },
        category: 'portion room'
      },
      {
        path: CUSTOMERS_PACKOFF_DISPLAY_PATH,
        name: 'customer packoff label',
        toPath: () => {
          this.props.replacePath(`${match.url}${CUSTOMERS_PACKOFF_DISPLAY_PATH}`);
        },
        category: 'portion room'
      },
      {
        path: TARE_PACKAGES_PATH,
        name: 'tare setup',
        toPath: () => {
          this.props.replacePath(`${match.url}${TARE_PACKAGES_PATH}`);
        },
        category: 'packaging'
      }
    ];
  }

  render() {
    const { match } = this.props;

    return (
      <div className='page-content administration side-navigation-page left-right'>
        <SideNavigation
          links={this.subRouteLinks()}
          currentPath={this.props.location.pathname}
          ref={ref => (this.sideNavigation = ref)}
        />

        <div className='right' ref={node => (this.scrollToTopRef = node)}>
          <Switch>
            <Route exact path={`${match.url}${COMPANY_PROFILE_PATH}`} component={Profile} />
            <Route
              exact
              path={`${match.url}${WORKDAY_SETTINGS_PATH}`}
              component={WorkdaySettings}
            />
            <Route
              exact
              path={`${match.url}${TABLE_MAINTENANCE_PATH}`}
              component={TableMaintenance}
            />
            <Route path={`${match.url}${UPDATE_TABLE_PATH}`} component={CreateTableForm} />
            <Route exact path={`${match.url}${CREATE_TABLE_PATH}`} component={CreateTableForm} />
            <Route
              exact
              path={`${match.url}${STATION_MAINTENANCE_PATH}`}
              component={StationMaintenance}
            />
            <Route path={`${match.url}${UPDATE_STATION_PATH}`} component={CreateStationForm} />
            <Route
              exact
              path={`${match.url}${CREATE_STATION_PATH}`}
              component={CreateStationForm}
            />
            <Route
              exact
              path={`${match.url}${ROOM_MAINTENANCE_PATH}`}
              component={RoomMaintenance}
            />
            <Route exact path={`${match.url}${CREATE_ROOM_PATH}`} component={CreateRoom} />
            <Route exact path={`${match.url}${HOUSE_PAR_PATH}`} component={HouseParMaintenance} />
            <Route exact path={`${match.url}${CREATE_HOUSE_PAR_PATH}`} component={CreateHousePar} />
            <Route path={`${match.url}${UPDATE_HOUSE_PAR_PATH}`} component={CreateHousePar} />
            <Route exact path={`${match.url}${TARE_PACKAGES_PATH}`} component={TareMaintenance} />
            <Route
              exact
              path={`${match.url}${CREATE_TARE_PACKAGE_PATH}`}
              component={CreateTarePackage}
            />
            <Route path={`${match.url}${UPDATE_TARE_PACKAGE_PATH}`} component={CreateTarePackage} />
            <Route
              path={`${match.url}${FISCAL_CALENDAR_SETUP_PATH}`}
              component={FiscalCalendarSetup}
            />
            <Route
              exact
              path={`${match.url}${CUSTOMERS_PACKOFF_DISPLAY_PATH}`}
              component={CustomerPackoffSetupMaintenance}
            />
            <Route
              exact
              path={`${match.url}${CUSTOMER_SETUP_PATH}`}
              component={CustomerSetupForm}
            />
          </Switch>
        </div>
      </div>
    );
  }
}

Administration.propTypes = {
  replacePath: PropTypes.func.isRequired,
  match: PropTypes.object.isRequired,
  keydown: PropTypes.object,
  location: PropTypes.object.isRequired,
  setHeaderAndFooter: PropTypes.func.isRequired
};

const mapDispatchToProps = dispatch =>
  bindActionCreators(
    {
      replacePath,
      setHeaderAndFooter
    },
    dispatch
  );

export default connect(
  null,
  mapDispatchToProps
)(
  subscriber(Administration, {
    f2Behavior: f2BehaviorForSideNavigation,
    targetComponent: 'Administration',
    uris: {
      F2: SUB_PAGE_CONFIG.map(subPage => `#/settings${subPage.path.replace('(\\d+)', '*')}`)
    }
  })
);
