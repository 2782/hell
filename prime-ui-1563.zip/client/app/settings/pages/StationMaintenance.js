import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { getStations } from '../actions/settingsActions';
import { replacePath } from '../../shared/actions/actions';
import _ from 'lodash';
import { Button } from 'semantic-ui-react';
import MaintenanceTable, { iconButton } from '../components/MaintenanceTable';
import { renderStationMaintenanceTableBody } from '../utils/renderTable';

export class StationMaintenance extends React.Component {
  constructor(props) {
    super(props);

    this.createStation = this.createStation.bind(this);
  }

  componentDidMount() {
    const { getStations } = this.props;
    getStations();
  }

  createStation() {
    this.props.replacePath('/settings/stations/create');
  }

  editStation(stationId) {
    this.props.replacePath(`/settings/stations/create/${stationId}`);
  }

  getTableColumns() {
    return [
      {
        key: 'stationCode',
        pid: 'station-code',
        width: '2',
        headerText: 'Station',
        textAlign: 'right'
      },
      {
        key: 'name',
        pid: 'station-name',
        width: '3',
        headerText: 'Name'
      },
      {
        key: 'room',
        pid: 'station-room',
        width: '1',
        headerText: 'Room'
      },
      {
        key: 'portionRoomTables',
        pid: 'station-tables',
        width: '3',
        headerText: 'Tables'
      },
      {
        key: 'printer',
        pid: 'station-printer',
        width: '2',
        headerText: 'Printer IP'
      },
      {
        key: 'userId',
        pid: 'station-user-id',
        width: '2',
        headerText: 'User ID'
      },
      {
        key: 'createButton',
        pid: 'station-create-button',
        width: '3',
        headerText: (
          <Button primary size={'small'} onClick={this.createStation}>
            {'New'}
          </Button>
        ),
        textAlign: 'center',
        value: data => {
          return (
            <a onClick={this.editStation.bind(this, data.id)}>
              <i style={iconButton} className='icon-edit' />
            </a>
          );
        }
      }
    ];
  }

  sortStationsAlphabetically() {
    return this.props.stations ? _.orderBy(this.props.stations, ['stationCode', 'name']) : null;
  }

  render() {
    return (
      <MaintenanceTable
        items={this.sortStationsAlphabetically()}
        columns={this.getTableColumns()}
        tableBody={renderStationMaintenanceTableBody}
      />
    );
  }
}

StationMaintenance.propTypes = {
  stations: PropTypes.array,
  getStations: PropTypes.func.isRequired,
  replacePath: PropTypes.func
};

const mapStateToProps = state => ({
  stations: state.settingsInfo.stations
});

const mapDispatchToProps = dispatch =>
  bindActionCreators(
    {
      getStations,
      replacePath
    },
    dispatch
  );

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(StationMaintenance);
