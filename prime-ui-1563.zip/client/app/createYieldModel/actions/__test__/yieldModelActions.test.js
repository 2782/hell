jest.mock('../../../shared/actions/actions');
import { changeYieldModelType } from '../yieldModelActions';
import { CHANGE_YIELD_MODEL_TYPE } from '../yieldModelActionTypes';

describe('yieldModelActions', () => {
  test('should change yield model type', () => {
    const dispatch = jest.fn();

    changeYieldModelType('cutting')(dispatch);

    jestExpect(dispatch).toBeCalledWith({ type: CHANGE_YIELD_MODEL_TYPE, payload: 'cutting' });
  });
});
