import { formValueSelector } from 'redux-form';
import yieldModelResources from '../../../shared/api/yieldModelResources';
import {
  calculateFinishedCost,
  checkByProduct,
  clearYieldModelInfo,
  createOrUpdateCuttingYieldModel,
  getActualYieldTests,
  getYieldModel,
  initFinishedProductCode,
  removeInvalidData,
  updateCuttingYieldModelInfo
} from '../cuttingYieldModelActions';
import {
  CALCULATED_COSTS_ON_CUTTING_YIELD_MODEL,
  CHECK_BYPRODUCT_COST_AND_LABOR,
  CUTTING_YIELD_MODEL_CLEARED,
  GET_ACTUAL_YIELD_TESTS,
  GET_ACTUAL_YIELD_TESTS_FAILED,
  INIT_FINISHED_PRODUCT_CODE,
  UPDATE_YIELD_MODEL
} from '../cuttingYieldModelActionTypes';
import costResources from '../../../shared/api/costResources';

import CuttingYieldModelFactory from '../../../../test-factories/cuttingYieldModel';
import yieldModelTestsFactory from '../../../../test-factories/yieldModelTests';

jest.mock('../../../shared/actions/actions');
jest.mock('../../../shared/api/yieldModelResources');
jest.mock('../../../shared/api/costResources');

describe('yieldModelActions', () => {
  let dispatch;
  const yieldModel = CuttingYieldModelFactory.build();
  const yieldModelTests = yieldModelTestsFactory.build();

  beforeEach(() => {
    dispatch = jest.fn();
  });

  describe('calculate finished product cost', () => {
    test('should call resource with portionRoomType and yieldModel and then dispatch cost in response to store', async () => {
      yieldModelResources.calculateCuttingYieldModelFinishedCost.mockResolvedValue({
        data: CuttingYieldModelFactory.build({})
      });

      const values = {
        finishedProductCode: '4391102',
        yieldByproducts: [{ byproductCode: '2111012' }, {}],
        yieldAdditives: [{ additiveCode: '6396391' }, {}],
        pickupPercent: 5.5
      };

      await calculateFinishedCost(values)(dispatch);

      jestExpect(yieldModelResources.calculateCuttingYieldModelFinishedCost).toBeCalledWith({
        finishedProductCode: '4391102',
        yieldByproducts: [{ byproductCode: '2111012' }],
        yieldAdditives: [{ additiveCode: '6396391' }],
        pickupPercent: 5.5
      });

      jestExpect(dispatch).toBeCalledWith({
        type: CALCULATED_COSTS_ON_CUTTING_YIELD_MODEL,
        payload: {
          actualYieldTestList: [{ createdat: '02/06/2018' }, { createdat: '02/06/2019' }],
          additives: 0.12,
          byproductCredit: 0.07,
          estimatedYield: 49.99,
          finishedProductCode: '0078889',
          finishedProductCost: 33.17,
          id: 2,
          labor: 2.59,
          overhead: 1.12,
          packaging: 0.31,
          pricingModel: true,
          sourceLbs: 20,
          pickupPercent: 5.5,
          sourceProductCode: '0079007',
          yieldAdditives: [{ cost: 5, productCode: '4181840', weight: 15 }],
          yieldByproducts: [
            {
              byproductCode: '0079006',
              byproductCredit: 1.25,
              cost: 1.23,
              labor: 1.2,
              overhead: 0.38,
              packaging: 1.5,
              yieldPercentage: 30.01
            },
            {
              byproductCode: '0214101',
              byproductCredit: 1.54,
              cost: 3.2,
              labor: 1.34,
              overhead: 0.38,
              packaging: 1.5,
              yieldPercentage: 20
            }
          ],
          yieldModelCurrentPricingModel: false
        }
      });
    });
  });

  describe('clear yield model', () => {
    test('should dispatch CLEAR_YIELD_MODEL when pathname is not change log', () => {
      const getState = () => ({
        router: { location: { pathname: '/other' } }
      });
      clearYieldModelInfo()(dispatch, getState);

      jestExpect(dispatch).toBeCalledWith({
        type: CUTTING_YIELD_MODEL_CLEARED
      });
    });

    test('should not clear when pathname is yield model change log', () => {
      const getState = () => ({
        router: { location: { pathname: '/yield-model/changelog' } }
      });

      clearYieldModelInfo()(dispatch, getState);

      jestExpect(dispatch).not.toHaveBeenCalledWith({
        type: CUTTING_YIELD_MODEL_CLEARED
      });
    });
  });

  describe('get yield model', () => {
    test('should call getYieldModel from yieldModelResources and dispatch UPDATE_YIELD_MODEL', async () => {
      yieldModelResources.getYieldModel.mockResolvedValue({ data: yieldModel });
      costResources.getCostByProductCode.mockImplementation((arg, callback) =>
        callback({ cost: 1.23, labor: 1.2 })
      );

      await getYieldModel('0078889', '0078891')(dispatch, () => {});

      jestExpect(dispatch).toBeCalledWith({
        type: UPDATE_YIELD_MODEL,
        payload: {
          actualYieldTestList: [{ createdat: '02/06/2018' }, { createdat: '02/06/2019' }],
          additives: 0.12,
          byproductCredit: 0.07,
          estimatedYield: 49.99,
          finishedProductCode: '0078889',
          finishedProductCost: 33.17,
          id: 1,
          labor: 2.59,
          overhead: 1.12,
          packaging: 0.31,
          pricingModel: true,
          sourceLbs: 20,
          pickupPercent: 5.5,
          sourceProductCode: '0079007',
          yieldAdditives: [{ cost: 5, productCode: '4181840', weight: 15 }],
          yieldByproducts: [
            {
              byproductCode: '0079006',
              byproductCredit: 1.25,
              cost: 1.23,
              labor: 1.2,
              overhead: 0.38,
              packaging: 1.5,
              yieldPercentage: 30.01
            },
            {
              byproductCode: '0214101',
              byproductCredit: 1.54,
              cost: 3.2,
              labor: 1.34,
              overhead: 0.38,
              packaging: 1.5,
              yieldPercentage: 20
            }
          ],
          yieldModelCurrentPricingModel: false
        }
      });

      jestExpect(dispatch).toBeCalledWith({
        type: CHECK_BYPRODUCT_COST_AND_LABOR,
        payload: {
          productCode: '0214101',
          cost: false,
          labor: false
        }
      });

      jestExpect(dispatch).toBeCalledWith({
        type: CHECK_BYPRODUCT_COST_AND_LABOR,
        payload: {
          productCode: '0079006',
          cost: true,
          labor: true
        }
      });
    });

    test('should dispatch UPDATE_YIELD_MODEL with payload just contain finish and source product code when get null', async () => {
      yieldModelResources.getYieldModel.mockResolvedValue({ data: null });

      await getYieldModel('0078889', '0078891')(dispatch, () => {});

      jestExpect(dispatch).toBeCalledWith({
        type: UPDATE_YIELD_MODEL,
        payload: {}
      });
    });

    test('should call resource with finishedProductCode and sourceProductCode from redux form store when nulls passed in', async () => {
      yieldModelResources.getYieldModel.mockResolvedValue({ data: null });
      const selector = formValueSelector('TEST_FORM');
      const getState = () => ({
        form: {
          TEST_FORM: {
            values: {
              finishedProductCode: 'FINISHED_PRODUCT_CODE_FROM_STORE',
              sourceProductCode: 'SOURCE_PRODUCT_CODE_FROM_STORE'
            }
          }
        }
      });

      await getYieldModel(null, null, selector)(dispatch, getState);

      jestExpect(yieldModelResources.getYieldModel).toBeCalledWith(
        'FINISHED_PRODUCT_CODE_FROM_STORE',
        'SOURCE_PRODUCT_CODE_FROM_STORE'
      );
    });
  });

  describe('create cutting yield model', () => {
    afterEach(() => {
      yieldModelResources.createOrUpdateCuttingYieldModel.mockReset();
    });

    test('should call createOrUpdateCuttingYieldModel from yieldModelResources successfully and call successCallback', async () => {
      const rejectCallback = jest.fn();
      const yieldModel = CuttingYieldModelFactory.build();

      yieldModelResources.createOrUpdateCuttingYieldModel.mockResolvedValue({ data: yieldModel });

      await createOrUpdateCuttingYieldModel(yieldModel, rejectCallback)(dispatch);

      jestExpect(yieldModelResources.createOrUpdateCuttingYieldModel).toBeCalledWith(yieldModel);
      jestExpect(dispatch).toBeCalledWith({
        type: UPDATE_YIELD_MODEL,
        payload: {
          actualYieldTestList: [{ createdat: '02/06/2018' }, { createdat: '02/06/2019' }],
          additives: 0.12,
          byproductCredit: 0.07,
          estimatedYield: 49.99,
          finishedProductCode: '0078889',
          finishedProductCost: 33.17,
          id: 3,
          labor: 2.59,
          overhead: 1.12,
          packaging: 0.31,
          pricingModel: true,
          sourceLbs: 20,
          pickupPercent: 5.5,
          sourceProductCode: '0079007',
          yieldAdditives: [{ cost: 5, productCode: '4181840', weight: 15 }],
          yieldByproducts: [
            {
              byproductCode: '0079006',
              byproductCredit: 1.25,
              cost: 1.23,
              labor: 1.2,
              overhead: 0.38,
              packaging: 1.5,
              yieldPercentage: 30.01
            },
            {
              byproductCode: '0214101',
              byproductCredit: 1.54,
              cost: 3.2,
              labor: 1.34,
              overhead: 0.38,
              packaging: 1.5,
              yieldPercentage: 20
            }
          ],
          yieldModelCurrentPricingModel: false
        }
      });
    });

    test('should remove invalid data before createOrUpdateCuttingYieldModel', () => {
      const validYieldByproducts = [
        {
          byproductCode: '0079006',
          yieldPercentage: '30.01',
          cost: '1.23',
          labor: '1.20',
          packaging: 1.5,
          overhead: 0.38
        },
        {
          byproductCode: '0214101',
          yieldPercentage: '20.00',
          cost: '3.20',
          labor: '1.34',
          packaging: 1.5,
          overhead: 0.38
        }
      ];
      const validYieldAdditives = [
        {
          productCode: '4181840',
          weight: '15.00'
        }
      ];

      const yieldModel = CuttingYieldModelFactory.build({
        yieldByproducts: validYieldByproducts.concat({}),
        yieldAdditives: validYieldAdditives.concat({})
      });

      const validYieldModel = removeInvalidData(yieldModel);
      jestExpect(validYieldModel.yieldByproducts).toEqual(validYieldByproducts);
      jestExpect(validYieldModel.yieldAdditives).toEqual(validYieldAdditives);
    });
  });

  describe('Update Yield Model Info', () => {
    test('hide pricing model confirmation', () => {
      const yieldModel = {};
      updateCuttingYieldModelInfo(yieldModel)(dispatch);

      jestExpect(dispatch).toBeCalledWith({ type: UPDATE_YIELD_MODEL, payload: yieldModel });
    });
  });

  describe('init finished product code', () => {
    test('should dispatch INIT_FINISHED_PRODUCT_CODE', () => {
      initFinishedProductCode('0078889')(dispatch);

      jestExpect(dispatch).toBeCalledWith({ type: INIT_FINISHED_PRODUCT_CODE, payload: '0078889' });
    });
  });

  describe('check by product cost and labor', () => {
    test('should dispatch CHECK_BYPRODUCT_COST_AND_LABOR', () => {
      costResources.getCostByProductCode.mockImplementationOnce((arg, callback) =>
        callback({ cost: 12.34, labor: 34.12 })
      );
      checkByProduct({ byproductCode: '0078889', cost: '12.34', labor: '43.21' }, () => {})(
        dispatch
      );

      jestExpect(dispatch).toBeCalledWith({
        type: CHECK_BYPRODUCT_COST_AND_LABOR,
        payload: {
          productCode: '0078889',
          cost: true,
          labor: false
        }
      });
    });

    test('should not dispatch CHECK_BYPRODUCT_COST_AND_LABOR when response is empty', () => {
      costResources.getCostByProductCode.mockImplementationOnce((arg, callback) => callback(null));
      checkByProduct({ byproductCode: '0078889', cost: '12.34', labor: '43.21' }, () => {})(
        dispatch
      );
      jestExpect(dispatch).not.toHaveBeenCalled();
    });
  });

  describe('get actual yield tests', () => {
    const response = {
      data: yieldModelTests
    };

    afterEach(() => {
      yieldModelResources.getActualYieldTests.mockReset();
    });

    test('should get actual yield tests successfully', () => {
      yieldModelResources.getActualYieldTests.mockImplementation(
        (yieldModelId, successCallback) => {
          successCallback(response);
        }
      );
      getActualYieldTests(1)(dispatch);
      jestExpect(yieldModelResources.getActualYieldTests).toBeCalledWith(
        1,
        jestExpect.any(Function),
        jestExpect.any(Function)
      );
      jestExpect(dispatch).toBeCalledWith({
        type: GET_ACTUAL_YIELD_TESTS,
        payload: response.data
      });
    });

    test('should failed to get actual yield tests', () => {
      const error = {};
      yieldModelResources.getActualYieldTests.mockImplementation(
        (yieldModelId, successCallback, rejectCallback) => {
          rejectCallback(error);
        }
      );
      getActualYieldTests(2)(dispatch);
      jestExpect(yieldModelResources.getActualYieldTests).toBeCalledWith(
        2,
        jestExpect.any(Function),
        jestExpect.any(Function)
      );
      jestExpect(dispatch).toBeCalledWith({
        type: GET_ACTUAL_YIELD_TESTS_FAILED
      });
    });
  });
});
