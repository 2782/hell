import _ from 'lodash';
import yieldModelResources from '../../../shared/api/yieldModelResources';
import {
  calculateFinishedCost,
  clearGrindingYieldModel,
  createGrindingYieldModel,
  getBlends,
  updateGrindingYieldModelInfo,
  yieldModelAlreadyExists
} from '../grindingYieldModelActions';
import {
  GET_BLENDS,
  GRABBED_GRINDING_YIELD_MODEL_FINISHED_COST,
  GRINDING_YIELD_MODEL_CLEARED,
  UPDATE_YIELD_MODEL
} from '../grindingYieldModelActionTypes';

jest.mock('../../../shared/actions/actions');

jest.mock('../../../shared/api/yieldModelResources');

describe('yieldModelActions', () => {
  let dispatch;

  beforeEach(() => {
    dispatch = jest.fn();
  });

  describe('clear grinding yield model', () => {
    test('should dispatch CLEAR_YIELD_MODEL when pathname is not change log', () => {
      const getState = () => ({
        router: { location: { pathname: '/other' } }
      });
      clearGrindingYieldModel()(dispatch, getState);

      jestExpect(dispatch).toBeCalledWith({
        type: GRINDING_YIELD_MODEL_CLEARED
      });
    });

    test('should not clear when pathname is yield model change log', () => {
      const getState = () => ({
        router: { location: { pathname: '/yield-model/changelog' } }
      });

      clearGrindingYieldModel()(dispatch, getState);

      jestExpect(dispatch).not.toHaveBeenCalledWith({
        type: GRINDING_YIELD_MODEL_CLEARED
      });
    });
  });

  describe('create grinding yield model', () => {
    test('should call createGrindingYieldModel from yieldModelResources and call success callback', () => {
      const rejectCallback = jest.fn();
      const grindingYieldModel = {
        blend: 'Natural',
        pricingModel: true,
        sourceProducts: [{ code: 'CODE', blendPercentage: '%' }]
      };
      const updatedYieldModel = {
        blend: 'Organic',
        sourceProducts: [{ code: 'CODE', blendPercentage: '%' }],
        cost: '4.00'
      };

      yieldModelResources.createGrindingYieldModel.mockImplementation(
        (yieldModel, successCallback) => {
          successCallback(updatedYieldModel);
        }
      );

      createGrindingYieldModel(grindingYieldModel, rejectCallback)(dispatch);

      jestExpect(yieldModelResources.createGrindingYieldModel).toBeCalledWith(
        grindingYieldModel,
        jestExpect.any(Function),
        jestExpect.any(Function)
      );

      jestExpect(dispatch).toBeCalledWith({
        type: UPDATE_YIELD_MODEL,
        payload: {
          ...updatedYieldModel,
          finishedCost: '4.00'
        }
      });
    });

    test('should filter out empty sourceProducts before creating grinding yield model', () => {
      const rejectCallback = jest.fn();
      const grindingYieldModel = {
        blend: 'Natural',
        sourceProducts: [
          { code: 'CODE', blendPercentage: '%' },
          { code: '', blendPercentage: '%' },
          { code: 'CODE', blendPercentage: '' },
          {},
          ''
        ]
      };
      const updatedYieldModel = {
        blend: 'Organic',
        sourceProducts: [{ code: 'CODE', blendPercentage: '%' }],
        cost: '4.00'
      };

      yieldModelResources.createGrindingYieldModel.mockImplementation(
        (yieldModel, successCallback) => {
          successCallback(updatedYieldModel);
        }
      );

      createGrindingYieldModel(grindingYieldModel, rejectCallback)(dispatch);

      jestExpect(yieldModelResources.createGrindingYieldModel).toBeCalledWith(
        {
          blend: 'Natural',
          pricingModel: true,
          sourceProducts: [{ code: 'CODE', blendPercentage: '%' }]
        },
        jestExpect.any(Function),
        jestExpect.any(Function)
      );

      jestExpect(dispatch).toBeCalledWith({
        type: UPDATE_YIELD_MODEL,
        payload: {
          ...updatedYieldModel,
          finishedCost: '4.00'
        }
      });
    });
  });

  test('should update grinding yield model', () => {
    const grindingYieldModel = {
      blend: 'Natural',
      sourceProducts: [{ code: 'CODE', blendPercentage: '%' }]
    };

    jestExpect(updateGrindingYieldModelInfo(grindingYieldModel)).toEqual({
      type: UPDATE_YIELD_MODEL,
      payload: {
        ..._.omit(grindingYieldModel, ['sourceProducts']),
        sourceProducts: [{ code: 'CODE', blendPercentage: '%' }]
      }
    });
  });

  describe('calculate grinding yield model cost for what-if scenarios', () => {
    test('should call createGrindingYieldModel from yieldModelResources and call success callback', () => {
      const grindingYieldModel = {
        blend: 'Natural',
        sourceProducts: [{ code: 'CODE', blendPercentage: '%' }]
      };

      yieldModelResources.calculateGrindingYieldModelFinishedCost.mockResolvedValue({
        data: '3.00'
      });

      return calculateFinishedCost(grindingYieldModel)(dispatch).then(() => {
        jestExpect(yieldModelResources.calculateGrindingYieldModelFinishedCost).toBeCalledWith(
          grindingYieldModel
        );
        jestExpect(dispatch).toBeCalledWith({
          type: GRABBED_GRINDING_YIELD_MODEL_FINISHED_COST,
          payload: {
            finishedCost: '3.00'
          }
        });
      });
    });

    test('should filter out empty sourceProducts before creating grinding yield model', () => {
      const grindingYieldModel = {
        blend: 'Natural',
        sourceProducts: [
          { code: 'CODE', blendPercentage: '%' },
          { code: '', blendPercentage: '%' },
          { code: 'CODE', blendPercentage: '' },
          {},
          ''
        ]
      };

      yieldModelResources.calculateGrindingYieldModelFinishedCost.mockResolvedValue({
        data: '3.00'
      });

      return calculateFinishedCost(grindingYieldModel)(dispatch).then(() => {
        jestExpect(yieldModelResources.calculateGrindingYieldModelFinishedCost).toBeCalledWith({
          blend: 'Natural',
          sourceProducts: [{ code: 'CODE', blendPercentage: '%' }]
        });

        jestExpect(dispatch).toBeCalledWith({
          type: GRABBED_GRINDING_YIELD_MODEL_FINISHED_COST,
          payload: {
            finishedCost: '3.00'
          }
        });
      });
    });
  });

  describe('get all blends', () => {
    test('should get all blends', async () => {
      const blends = {
        data: [{ name: 'BLEND01', displayName: 'BLEND01 - 50/90 - TRIM 75/25', priority: 1 }]
      };

      yieldModelResources.getBlends.mockResolvedValue(blends);

      await getBlends()(dispatch);

      jestExpect(dispatch).toBeCalledWith({
        type: GET_BLENDS,
        payload: blends.data
      });
    });

    test('should remove empty blendPercentage object when submitting to async call', async () => {
      const grindingYieldModel = {
        additives: '3.00',
        blend: 'BLEND1013',
        labor: '4.00',
        pricingModel: false,
        sourceProducts: [{ code: '2963082', blendPercentage: '100.00' }, { blendPercentage: '' }],
        blendPercentage: '100.00',
        code: '2963082',
        wastePercentage: '2.00'
      };

      const filteredGrindingYieldModel = {
        additives: '3.00',
        blend: 'BLEND1013',
        labor: '4.00',
        pricingModel: false,
        sourceProducts: [{ code: '2963082', blendPercentage: '100.00' }],
        blendPercentage: '100.00',
        code: '2963082',
        wastePercentage: '2.00'
      };

      // This doesn't matter what it resolves to, just have to resolve for the test
      yieldModelResources.checkGrindingYieldModelExists.mockResolvedValue(null);

      return yieldModelAlreadyExists(grindingYieldModel)().then(() => {
        jestExpect(yieldModelResources.checkGrindingYieldModelExists).toBeCalledWith(
          filteredGrindingYieldModel
        );
      });
    });
  });
});
