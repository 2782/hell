export const UPDATE_YIELD_MODEL = '@@cuttingYieldModel/update';
export const INIT_FINISHED_PRODUCT_CODE = '@@cuttingYieldModel/initFinishedProductCode';
export const CUTTING_YIELD_MODEL_CLEARED = '@@cuttingYieldModel/clear';
export const CHECK_BYPRODUCT_COST_AND_LABOR = '@@cuttingYieldModel/byproduct/check';
export const CLEAR_BYPRODUCT_COST_AND_LABOR = '@@cuttingYieldModel/byproduct/clear';
export const GET_ACTUAL_YIELD_TESTS = '@@yieldModelTests/get';
export const GET_ACTUAL_YIELD_TESTS_FAILED = '@@yieldModelTests/failedToGet';
export const CALCULATED_COSTS_ON_CUTTING_YIELD_MODEL = '@@prime/calculateCostsOnCuttingYieldModel';
