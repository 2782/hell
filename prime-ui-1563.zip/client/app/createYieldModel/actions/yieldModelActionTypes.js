export const YIELD_MODEL_CLEARED = '@@yieldModel/clear';
export const CHANGE_YIELD_MODEL_TYPE = '@@yieldModel/changeYieldModelType';
