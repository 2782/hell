export const UPDATE_YIELD_MODEL = '@@grindingYieldModel/update';
export const GRINDING_YIELD_MODEL_CLEARED = '@@grindingYieldModel/clear';
export const GRABBED_GRINDING_YIELD_MODEL_FINISHED_COST =
  '@@prime/GRABBED_GRINDING_YIELD_MODEL_FINISHED_COST';
export const GET_BLENDS = '@@grindingYieldModel/get/blends';
