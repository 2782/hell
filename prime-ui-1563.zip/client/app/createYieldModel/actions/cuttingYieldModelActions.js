import _ from 'lodash';
import yieldModelResources from '../../shared/api/yieldModelResources';
import costResources from '../../shared/api/costResources';
import {
  CALCULATED_COSTS_ON_CUTTING_YIELD_MODEL,
  CHECK_BYPRODUCT_COST_AND_LABOR,
  CLEAR_BYPRODUCT_COST_AND_LABOR,
  CUTTING_YIELD_MODEL_CLEARED,
  GET_ACTUAL_YIELD_TESTS,
  GET_ACTUAL_YIELD_TESTS_FAILED,
  INIT_FINISHED_PRODUCT_CODE,
  UPDATE_YIELD_MODEL
} from './cuttingYieldModelActionTypes';
import Validator from '../components/cuttingYieldModelFormValidator';
import { zeroIfInvalid } from '../../shared/util/dataUtil';

function parseSourceLbs(sourceLbs) {
  return null === sourceLbs ? null : parseFloat(sourceLbs);
}

export const transformCuttingYieldModelNumerics = cuttingYieldModel => {
  return _.isEmpty(cuttingYieldModel)
    ? {}
    : {
        ...cuttingYieldModel,
        estimatedYield: parseFloat(cuttingYieldModel.estimatedYield),
        byproductCredit: parseFloat(cuttingYieldModel.byproductCredit),
        sourceLbs: parseSourceLbs(cuttingYieldModel.sourceLbs),
        finishedProductCost: parseFloat(cuttingYieldModel.finishedProductCost),
        labor: parseFloat(cuttingYieldModel.labor),
        additives: parseFloat(cuttingYieldModel.additives),
        packaging: parseFloat(cuttingYieldModel.packaging),
        overhead: parseFloat(cuttingYieldModel.overhead),
        yieldByproducts: _.map(cuttingYieldModel.yieldByproducts, byproduct => ({
          ...byproduct,
          yieldPercentage: parseFloat(byproduct.yieldPercentage),
          cost: parseFloat(byproduct.cost),
          labor: parseFloat(byproduct.labor),
          packaging: parseFloat(byproduct.packaging),
          overhead: parseFloat(byproduct.overhead),
          byproductCredit: parseFloat(byproduct.byproductCredit)
        })),
        yieldAdditives: _.map(cuttingYieldModel.yieldAdditives, additive => ({
          ...additive,
          weight: parseFloat(additive.weight),
          cost: parseFloat(additive.cost)
        }))
      };
};

export const getYieldModel = (finishedProductCode, sourceProductCode, reduxFormSelector) => (
  dispatch,
  getState
) => {
  const state = getState();
  const finishedForLookup = finishedProductCode
    ? finishedProductCode
    : reduxFormSelector(state, 'finishedProductCode');
  const sourceForLookup = sourceProductCode
    ? sourceProductCode
    : reduxFormSelector(state, 'sourceProductCode');

  return yieldModelResources.getYieldModel(finishedForLookup, sourceForLookup).then(
    response => {
      const yieldModel = transformCuttingYieldModelNumerics(response.data);
      dispatch({
        type: UPDATE_YIELD_MODEL,
        payload: !_.isEmpty(yieldModel) ? yieldModel : {}
      });

      if (!_.isEmpty(yieldModel)) {
        yieldModel.yieldByproducts.map(byproductCode =>
          checkByProduct(byproductCode, () => {})(dispatch)
        );
      }

      return yieldModel;
    },
    () => Promise.reject('Failed to fetch cutting yield model.')
  );
};

export const removeInvalidData = yieldModel => {
  _.remove(yieldModel.yieldByproducts, yieldByProduct => {
    return _.get(yieldByProduct, 'byproductCode', '') === '';
  });
  _.remove(yieldModel.yieldAdditives, yieldAdditive => {
    return _.get(yieldAdditive, 'productCode', '') === '';
  });

  return yieldModel;
};

export const createOrUpdateCuttingYieldModel = yieldModel => dispatch => {
  yieldModel = removeInvalidData(yieldModel);

  return yieldModelResources.createOrUpdateCuttingYieldModel(yieldModel).then(
    response => {
      const updatedYieldModel = transformCuttingYieldModelNumerics(response.data);
      dispatch({
        type: UPDATE_YIELD_MODEL,
        payload: updatedYieldModel
      });
    },
    error => {
      const errorResponse = _.get(error, 'response.data', {});
      Validator.processErrorResponse(errorResponse, yieldModel);
    }
  );
};

export const updateCuttingYieldModelInfo = yieldModel => {
  return dispatch => {
    dispatch({
      type: UPDATE_YIELD_MODEL,
      payload: yieldModel
    });
  };
};

export const clearYieldModelInfo = () => (dispatch, getState) => {
  const {
    location: { pathname }
  } = getState().router;

  if (!pathname.includes('/yield-model/changelog')) {
    dispatch({
      type: CUTTING_YIELD_MODEL_CLEARED
    });
  }
};

export const initFinishedProductCode = productCode => {
  return dispatch => {
    dispatch({
      type: INIT_FINISHED_PRODUCT_CODE,
      payload: productCode
    });
  };
};

export const checkByProduct = (byproduct, rejectCallback = () => {}) => {
  return dispatch => {
    return costResources.getCostByProductCode(
      byproduct.byproductCode,
      cost => {
        if (cost) {
          dispatch({
            type: CHECK_BYPRODUCT_COST_AND_LABOR,
            payload: {
              productCode: byproduct.byproductCode,
              cost: toFixedDigits(cost.cost, 2) === toFixedDigits(byproduct.cost, 2),
              labor: toFixedDigits(cost.labor, 2) === toFixedDigits(byproduct.labor, 2)
            }
          });
        }
      },
      rejectCallback
    );
  };
};

export const clearByproductCost = () => ({
  type: CLEAR_BYPRODUCT_COST_AND_LABOR
});

export const getActualYieldTests = yieldModelId => {
  return dispatch => {
    return yieldModelResources.getActualYieldTests(
      yieldModelId,
      response => {
        dispatch({
          type: GET_ACTUAL_YIELD_TESTS,
          payload: response.data
        });
      },
      () => {
        dispatch({
          type: GET_ACTUAL_YIELD_TESTS_FAILED
        });
      }
    );
  };
};

const toFixedDigits = (number, digitalCount) => {
  return parseFloat(zeroIfInvalid(number)).toFixed(digitalCount);
};

const buildPayload = values => {
  const yieldModelRequest = _.clone(values);
  yieldModelRequest.yieldByproducts = _.filter(
    values.yieldByproducts,
    byProduct => !_.isEmpty(byProduct)
  );
  yieldModelRequest.yieldAdditives = _.filter(
    values.yieldAdditives,
    additive => !_.isEmpty(additive)
  );
  return yieldModelRequest;
};

export const calculateFinishedCost = values => dispatch => {
  const cuttingYieldModel = buildPayload(values);

  return yieldModelResources.calculateCuttingYieldModelFinishedCost(cuttingYieldModel).then(
    response => {
      const preview = transformCuttingYieldModelNumerics(response.data);
      dispatch({
        type: CALCULATED_COSTS_ON_CUTTING_YIELD_MODEL,
        payload: preview
      });
    },
    () => Promise.reject({ _error: 'Calculation of finished cost failed.' })
  );
};
