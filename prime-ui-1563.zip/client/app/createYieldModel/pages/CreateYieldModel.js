import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import CuttingYieldModelForm from '../components/CuttingYieldModelForm';
import { ESTABLISH_YIELD_MODEL } from '../../shared/components/pageTitles';
import { changePath, setHeaderAndFooter } from '../../shared/actions/actions';
import { ESTABLISH_YIELD_MODEL_FOOTER } from '../../shared/components/pageFooters';

import { Button, Form, Grid } from 'semantic-ui-react';
import GrindingYieldModelForm from '../components/GrindingYieldModelForm';
import { changeYieldModelType } from '../actions/yieldModelActions';
import _ from 'lodash';
import FormLabel from '../../shared/FormLabel';

export const YIELD_TYPE_CUTTING = 'Cutting';
export const YIELD_TYPE_GRINDING = 'Grinding';
const YIELD_TYPE_LABEL = 'Type';

class CreateYieldModel extends React.Component {
  constructor(props) {
    super(props);
    this.toYieldModelChangelogPage = this.toYieldModelChangelogPage.bind(this);
  }

  componentDidMount() {
    this.props.setHeaderAndFooter({
      header: ESTABLISH_YIELD_MODEL,
      footer: ESTABLISH_YIELD_MODEL_FOOTER
    });
    this.scrollToTop();
  }

  scrollToTop() {
    if (this.scrollToTopRef && this.scrollToTopRef.scrollIntoView) {
      this.scrollToTopRef.scrollIntoView({
        behavior: 'smooth',
        block: 'start',
        inline: 'nearest'
      });
    }
  }

  toYieldModelChangelogPage() {
    const {
      changePath,
      yieldModelType,
      grindingYieldModel,
      grindingSourceProducts,
      sourceProductCode,
      finishedProductCode
    } = this.props;
    if (yieldModelType === 'cutting') {
      changePath(
        '/yield-model/changelog/finishedProduct/' +
          finishedProductCode +
          '/sourceProduct/' +
          sourceProductCode
      );
    } else {
      const blend = _.get(grindingYieldModel.blend, 'name');
      let sourceProductCodes = '';
      grindingSourceProducts.map(sourceProduct =>
        sourceProduct.code !== '' ? (sourceProductCodes += sourceProduct.code + ',') : null
      );
      sourceProductCodes = sourceProductCodes.substr(0, sourceProductCodes.length - 1);
      changePath('/yield-model/changelog/blend/' + blend + '/sourceProducts/' + sourceProductCodes);
    }
  }

  render() {
    const { yieldModelType, yieldModelExists } = this.props;
    return (
      <div
        className='page-content create-yield-model-page'
        ref={node => (this.scrollToTopRef = node)}
      >
        <Form size='large'>
          {!yieldModelExists ? (
            <Form.Field width={4}>
              <Form.Select
                label={YIELD_TYPE_LABEL}
                name='yieldModelType'
                pid='create-yield-model-type-select'
                onChange={(e, { value }) => {
                  this.props.changeYieldModelType(value);
                }}
                options={[
                  { key: 0, text: YIELD_TYPE_CUTTING, value: 'cutting' },
                  { key: 1, text: YIELD_TYPE_GRINDING, value: 'grinding' }
                ]}
                selection
                value={yieldModelType}
              />
            </Form.Field>
          ) : (
            <Grid>
              <Grid.Row>
                <Grid.Column width={13}>
                  <Form.Field>
                    <FormLabel
                      name='yieldType'
                      pid='create-yield-model-type-label'
                      label={YIELD_TYPE_LABEL}
                      width={11}
                      value={
                        yieldModelType === 'cutting' ? YIELD_TYPE_CUTTING : YIELD_TYPE_GRINDING
                      }
                    />
                  </Form.Field>
                </Grid.Column>
                <Grid.Column width={3}>
                  <Button
                    primary
                    size={'medium'}
                    className={'yield-model-changelog'}
                    onClick={this.toYieldModelChangelogPage}
                  >
                    Change Log
                  </Button>
                </Grid.Column>
              </Grid.Row>
            </Grid>
          )}
        </Form>
        {yieldModelType === 'cutting' ? <CuttingYieldModelForm /> : <GrindingYieldModelForm />}
      </div>
    );
  }
}

CreateYieldModel.propTypes = {
  setHeaderAndFooter: PropTypes.func.isRequired,
  changeYieldModelType: PropTypes.func.isRequired,
  yieldModelType: PropTypes.string.isRequired,
  yieldModelExists: PropTypes.bool,
  changePath: PropTypes.func,
  sourceProductCode: PropTypes.string,
  finishedProductCode: PropTypes.string,
  grindingYieldModel: PropTypes.object,
  grindingSourceProducts: PropTypes.array
};

export const mapStateToProps = state => {
  const isCuttingYieldModelType = state.yieldModelInfo.yieldModelType === 'cutting';
  const yieldModelExists = isCuttingYieldModelType
    ? !_.isNil(state.cuttingYieldModelInfo.yieldModel.id)
    : !_.isNil(state.grindingYieldModelInfo.yieldModel.id);

  const grindingYieldModel =
    !isCuttingYieldModelType && yieldModelExists
      ? state.grindingYieldModelInfo.yieldModel
      : undefined;
  return {
    yieldModelType: state.yieldModelInfo.yieldModelType,
    yieldModelExists,
    grindingYieldModel,
    grindingSourceProducts: grindingYieldModel ? state.grindingYieldModelInfo.sourceProducts : null,
    finishedProductCode:
      isCuttingYieldModelType && yieldModelExists
        ? state.cuttingYieldModelInfo.yieldModel.finishedProductCode
        : '',
    sourceProductCode:
      isCuttingYieldModelType && yieldModelExists
        ? state.cuttingYieldModelInfo.yieldModel.sourceProductCode
        : ''
  };
};

const mapDispatchToProps = dispatch =>
  bindActionCreators(
    {
      setHeaderAndFooter,
      changeYieldModelType,
      changePath
    },
    dispatch
  );

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(CreateYieldModel);
