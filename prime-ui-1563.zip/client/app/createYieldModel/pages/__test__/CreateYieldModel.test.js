import React from 'react';
import { mount } from 'enzyme';
import { Provider } from 'react-redux';
import { createReduxStore } from '../../../store';
import CreateYieldModel from '../CreateYieldModel';
import CuttingYieldModelForm from '../../components/CuttingYieldModelForm';
import semanticUI from '../../../../test-helpers/semantic-ui';
import GrindingYieldModelForm from '../../components/GrindingYieldModelForm';
import CuttingYieldModelFactory from '../../../../test-factories/cuttingYieldModel';
import GrindingYieldModelFactory from '../../../../test-factories/grindingYieldModel';
import { Button } from 'semantic-ui-react';
import { changePath } from '../../../shared/actions/actions';

jest.mock('../../../shared/actions/actions', () => ({
  changePath: jest.fn(path => ({ type: 'MOCK_CHANGE_PATH', payload: path })),
  setHeaderAndFooter: jest.fn(() => ({ type: 'MOCK_SET_HEADER_AND_FOOTER' })),
  hideModal: jest.fn(() => ({ type: 'MOCK_HIDE_MODAL' })),
  showModal: jest.fn(() => ({ type: 'MOCK_SHOW_MODAL' }))
}));

describe('CreateYieldModel', () => {
  let wrapper, store;

  beforeEach(() => {
    store = createReduxStore({ router: { location: { pathname: '/other/pathname' } } });
    wrapper = mount(
      <Provider store={store}>
        <CreateYieldModel />
      </Provider>
    );
  });

  describe('selectYieldModelForm', () => {
    test('by default the form is cutting yield model', () => {
      jestExpect(wrapper.find(GrindingYieldModelForm).exists()).toEqual(false);
      jestExpect(wrapper.find(CuttingYieldModelForm).exists()).toEqual(true);
    });

    test('should select grinding yield model form', () => {
      semanticUI.selectOption(wrapper, 'yieldModelType', 1);

      jestExpect(wrapper.find(GrindingYieldModelForm).exists()).toEqual(true);
      jestExpect(wrapper.find(CuttingYieldModelForm).exists()).toEqual(false);
    });

    test('should display form label as cutting when cutting yield model exists and view change log', () => {
      store = createReduxStore({
        yieldModelInfo: {
          yieldModelType: 'cutting'
        },
        cuttingYieldModelInfo: {
          yieldModel: CuttingYieldModelFactory.build({}),
          pricingModelCostsAndLabors: {},
          actualYieldTests: {},
          actualYieldTestsAvailableStatus: -1
        },
        productDuplicate: {
          products: {},
          productsExist: {},
          additiveSourceItem: true
        }
      });
      const form = mount(
        <Provider store={store}>
          <CreateYieldModel />
        </Provider>
      );

      jestExpect(semanticUI.doesSelectExist(form, 'yieldModelType')).toEqual(false);
      jestExpect(semanticUI.findLabelWithName(form, 'Type')).toExist();
      jestExpect(semanticUI.findLabelWithValue(form, 'Cutting').exists()).toEqual(true);

      const viewLogButton = form.find(Button).at(0);
      viewLogButton.simulate('click');

      jestExpect(changePath).toHaveBeenCalledWith(
        '/yield-model/changelog/finishedProduct/0078889/sourceProduct/0079007'
      );
    });

    test('should display form label as grinding when grinding yield model exists', () => {
      store = createReduxStore({
        yieldModelInfo: {
          yieldModelType: 'grinding'
        },
        grindingYieldModelInfo: {
          yieldModel: GrindingYieldModelFactory.build(),
          sourceProducts: [
            { code: '0204000', blendPercentage: '30.00' },
            { code: '0204001', blendPercentage: '70.00' }
          ],
          blends: []
        },
        productDuplicate: {
          products: {}
        }
      });
      const form = mount(
        <Provider store={store}>
          <CreateYieldModel />
        </Provider>
      );

      jestExpect(semanticUI.doesSelectExist(form, 'yieldModelType')).toEqual(false);
      jestExpect(semanticUI.findLabelWithName(form, 'Type')).toExist();
      jestExpect(semanticUI.findLabelWithValue(form, 'Grinding').exists()).toEqual(true);

      const viewLogButton = form.find(Button).at(0);
      viewLogButton.simulate('click');

      jestExpect(changePath).toHaveBeenCalledWith(
        '/yield-model/changelog/blend/NATURAL/sourceProducts/0204000,0204001'
      );
    });

    test('should display form selector when no cutting yield model exists', () => {
      store = createReduxStore({
        yieldModelInfo: {
          yieldModelType: 'grinding'
        },
        cuttingYieldModelInfo: {
          yieldModel: {},
          pricingModelCostsAndLabors: {},
          actualYieldTests: {},
          actualYieldTestsAvailableStatus: -1
        },
        productDuplicate: {
          products: {},
          productsExist: {}
        }
      });
      const form = mount(
        <Provider store={store}>
          <CreateYieldModel />
        </Provider>
      );

      jestExpect(semanticUI.doesSelectExist(form, 'yieldModelType')).toEqual(true);
      jestExpect(semanticUI.findLabelWithName(form, 'Type')).not.toExist();
    });

    test('should display form selector when no grinding yield model exists', () => {
      store = createReduxStore({
        yieldModelInfo: {
          yieldModelType: 'grinding'
        },
        grindingYieldModelInfo: {
          yieldModel: {},
          sourceProducts: [],
          blends: []
        },
        productDuplicate: {
          products: {}
        }
      });
      const form = mount(
        <Provider store={store}>
          <CreateYieldModel />
        </Provider>
      );

      jestExpect(semanticUI.doesSelectExist(form, 'yieldModelType')).toEqual(true);
      jestExpect(semanticUI.findLabelWithName(form, 'Type').exists()).toEqual(false);
    });
  });

  describe('componentDidMount', () => {
    test('scroll page to top', () => {
      const scrollToTop = jest.fn();
      const componentDidMount = jest.fn(() => ({ scrollToTop }));
      const component = new CreateYieldModel({ store });
      component.componentDidMount = componentDidMount;
      component.componentDidMount().scrollToTop();
      jestExpect(scrollToTop).toBeCalled();
    });
  });
});
