import {
  CHECK_BYPRODUCT_COST_AND_LABOR,
  CUTTING_YIELD_MODEL_CLEARED,
  INIT_FINISHED_PRODUCT_CODE,
  UPDATE_YIELD_MODEL,
  GET_ACTUAL_YIELD_TESTS,
  GET_ACTUAL_YIELD_TESTS_FAILED,
  CALCULATED_COSTS_ON_CUTTING_YIELD_MODEL,
  CLEAR_BYPRODUCT_COST_AND_LABOR
} from '../actions/cuttingYieldModelActionTypes';
import _ from 'lodash';

// actualYieldTestsAvailableStatus
//   -1 : initial values
//    0 : yield test is not available
//    1 : yield test is available
const initialState = {
  yieldModel: {
    byproductCredit: 0,
    finishedProductCost: 0,
    estimatedYield: 100,
    additives: 0
  },
  pricingModelCostsAndLabors: {},
  actualYieldTests: {},
  actualYieldTestsAvailableStatus: -1
};

export default (state = initialState, action) => {
  switch (action.type) {
    case UPDATE_YIELD_MODEL:
      return {
        ...state,
        yieldModel: action.payload,
        finishedProductIsReadOnly: !_.isEmpty(action.payload),
        sourceProductIsReadOnly: !_.isEmpty(action.payload)
      };

    case CUTTING_YIELD_MODEL_CLEARED:
      return {
        ...initialState
      };

    case INIT_FINISHED_PRODUCT_CODE:
      return {
        ...state,
        initFinishedProductCode: action.payload
      };

    case CLEAR_BYPRODUCT_COST_AND_LABOR: {
      return {
        ...state,
        pricingModelCostsAndLabors: {}
      };
    }

    case CHECK_BYPRODUCT_COST_AND_LABOR: {
      let previousStateValues = { ...state };
      previousStateValues.pricingModelCostsAndLabors[action.payload.productCode] = action.payload;

      return { ...previousStateValues };
    }

    case GET_ACTUAL_YIELD_TESTS:
      return {
        ...state,
        actualYieldTests: action.payload,
        actualYieldTestsAvailableStatus: 1
      };

    case GET_ACTUAL_YIELD_TESTS_FAILED:
      return {
        ...state,
        actualYieldTests: {},
        actualYieldTestsAvailableStatus: 0
      };

    case CALCULATED_COSTS_ON_CUTTING_YIELD_MODEL: {
      const { finishedProductCost, byproductCredit, estimatedYield, additives } = action.payload;
      return {
        ...state,
        yieldModel: {
          ...state.yieldModel,
          finishedProductCost,
          byproductCredit,
          estimatedYield,
          additives
        }
      };
    }

    default:
      return state;
  }
};
