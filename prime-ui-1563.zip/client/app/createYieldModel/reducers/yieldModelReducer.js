import { YIELD_MODEL_CLEARED, CHANGE_YIELD_MODEL_TYPE } from '../actions/yieldModelActionTypes';
import { GRINDING_YIELD_MODEL_CLEARED } from '../actions/grindingYieldModelActionTypes';

const initialState = {
  pricingModelConfirmationShowing: false,
  yieldModelType: 'cutting'
};

export default (state = initialState, action) => {
  switch (action.type) {
    case YIELD_MODEL_CLEARED:
    case GRINDING_YIELD_MODEL_CLEARED:
      return {
        ...initialState
      };

    case CHANGE_YIELD_MODEL_TYPE:
      return {
        ...state,
        yieldModelType: action.payload
      };

    default:
      return state;
  }
};
