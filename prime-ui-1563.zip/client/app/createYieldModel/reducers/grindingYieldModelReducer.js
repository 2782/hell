import {
  GRINDING_YIELD_MODEL_CLEARED,
  GRABBED_GRINDING_YIELD_MODEL_FINISHED_COST,
  UPDATE_YIELD_MODEL,
  GET_BLENDS
} from '../actions/grindingYieldModelActionTypes';

const emptySourceProduct = { code: '', blendPercentage: '' };
const initialState = {
  yieldModel: {},
  sourceProducts: [emptySourceProduct],
  blends: []
};

export default (state = initialState, action) => {
  switch (action.type) {
    case UPDATE_YIELD_MODEL: {
      const { sourceProducts, ...yieldModel } = action.payload;
      return {
        ...state,
        yieldModel,
        sourceProducts: sourceProducts.concat(emptySourceProduct)
      };
    }
    case GRABBED_GRINDING_YIELD_MODEL_FINISHED_COST: {
      const { finishedCost } = action.payload;
      return {
        ...state,
        yieldModel: { ...state.yieldModel, finishedCost }
      };
    }
    case GET_BLENDS: {
      return {
        ...state,
        blends: action.payload
      };
    }
    case GRINDING_YIELD_MODEL_CLEARED:
      return {
        ...initialState
      };

    default:
      return state;
  }
};
