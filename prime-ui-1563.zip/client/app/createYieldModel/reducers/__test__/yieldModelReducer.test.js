import yieldModelReducer from '../yieldModelReducer';
import { CHANGE_YIELD_MODEL_TYPE, YIELD_MODEL_CLEARED } from '../../actions/yieldModelActionTypes';
import CuttingYieldModelFactory from '../../../../test-factories/cuttingYieldModel';
import { GRINDING_YIELD_MODEL_CLEARED } from '../../actions/grindingYieldModelActionTypes';

describe('yieldModelReducer', () => {
  let initState, yieldModel;

  beforeEach(() => {
    initState = {
      pricingModelConfirmationShowing: false,
      yieldModelType: 'cutting'
    };

    yieldModel = CuttingYieldModelFactory.build({
      finishedProductCode: '0007889',
      sourceProductCode: '0007891'
    });
  });

  test('should return initial reducer state when first initialized', () => {
    jestExpect(yieldModelReducer(undefined, { type: 'unexpect' })).toEqual(initState);
  });

  test('should return initial reducer state when action type unknown', () => {
    jestExpect(yieldModelReducer(initState, { type: 'unexpect' })).toEqual(initState);
  });

  test('should clear yield model and pricing model confirmation when dispatch action CLEAR_YIELD_MODEL_INFO', () => {
    jestExpect(
      yieldModelReducer(
        { yieldModel: yieldModel, pricingModelConfirmationShowing: true },
        {
          type: YIELD_MODEL_CLEARED
        }
      )
    ).toEqual({
      ...initState
    });
  });

  test('should clear yield model and pricing model confirmation when dispatch action CLEAR_YIELD_MODEL', () => {
    jestExpect(
      yieldModelReducer(
        { yieldModel: yieldModel, pricingModelConfirmationShowing: true },
        {
          type: GRINDING_YIELD_MODEL_CLEARED
        }
      )
    ).toEqual({
      ...initState
    });
  });

  test('should change state yield model type when action is CHANGE_YIELD_MODEL_TYPE', () => {
    jestExpect(
      yieldModelReducer(initState, { type: CHANGE_YIELD_MODEL_TYPE, payload: 'grinding' })
    ).toEqual({
      ...initState,
      yieldModelType: 'grinding'
    });
  });
});
