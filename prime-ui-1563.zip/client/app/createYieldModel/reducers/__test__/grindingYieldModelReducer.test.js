import grindingYieldModelReducer from '../grindingYieldModelReducer';
import _ from 'lodash';
import {
  GRINDING_YIELD_MODEL_CLEARED,
  GRABBED_GRINDING_YIELD_MODEL_FINISHED_COST,
  UPDATE_YIELD_MODEL,
  GET_BLENDS
} from '../../actions/grindingYieldModelActionTypes';
import GrindingYieldModelFactory from '../../../../test-factories/grindingYieldModel';

describe('grindingYieldModelReducer', () => {
  let initState, yieldModel, sourceProducts;

  beforeEach(() => {
    initState = {
      yieldModel: {},
      sourceProducts: [
        {
          code: '',
          blendPercentage: ''
        }
      ],
      blends: []
    };

    sourceProducts = [
      {
        code: '0078889',
        blendPercentage: '40.00'
      }
    ];
    yieldModel = GrindingYieldModelFactory.build({
      sourceProducts
    });
  });

  test('should return initial reducer state when first initialized', () => {
    jestExpect(grindingYieldModelReducer(undefined, { type: 'unexpect' })).toEqual(initState);
  });

  test('should return initial reducer state when action type unknown', () => {
    jestExpect(grindingYieldModelReducer(initState, { type: 'unexpect' })).toEqual(initState);
  });

  test('should update yield model when dispatch action UPDATE_YIELD_MODEL', () => {
    jestExpect(
      grindingYieldModelReducer(initState, {
        type: UPDATE_YIELD_MODEL,
        payload: yieldModel
      })
    ).toEqual({
      yieldModel: _.omit(yieldModel, 'sourceProducts'),
      blends: [],
      sourceProducts: [
        {
          code: '0078889',
          blendPercentage: '40.00'
        },
        {
          code: '',
          blendPercentage: ''
        }
      ]
    });
  });

  test('should update finished cost', () => {
    jestExpect(
      grindingYieldModelReducer(initState, {
        type: GRABBED_GRINDING_YIELD_MODEL_FINISHED_COST,
        payload: {
          finishedCost: '3.00'
        }
      })
    ).toEqual({
      blends: [],
      yieldModel: {
        finishedCost: '3.00'
      },
      sourceProducts: [
        {
          code: '',
          blendPercentage: ''
        }
      ]
    });
  });

  test('should clear yield model and pricing model confirmation when dispatch action CLEAR_YIELD_MODEL', () => {
    jestExpect(
      grindingYieldModelReducer(
        { yieldModel: yieldModel, pricingModelConfirmationShowing: true },
        {
          type: GRINDING_YIELD_MODEL_CLEARED
        }
      )
    ).toEqual({
      ...initState
    });
  });

  test('should set blends when dispatch action CLEAR_YIELD_MODEL', () => {
    jestExpect(
      grindingYieldModelReducer(initState, {
        type: GET_BLENDS,
        payload: [{ name: 'BLEND01', displayName: 'BLEND01 - 50/90 - TRIM 75/25', priority: 1 }]
      })
    ).toEqual({
      ...initState,
      blends: [{ name: 'BLEND01', displayName: 'BLEND01 - 50/90 - TRIM 75/25', priority: 1 }]
    });
  });
});
