import React from 'react';
import PropTypes from 'prop-types';
import _ from 'lodash';
import { Field } from 'redux-form';
import { Form, Label, Table } from 'semantic-ui-react';
import ProductDuplicate from '../../shared/components/product/ProductDuplicate';
import {
  normalizeProductCode,
  normalizeToTwoDecimalPlaces
} from '../../shared/components/product/normalizer';
import FormElement from '../../shared/FormElement';
import { formatNumberToTwoDecimalPlacesString } from '../../shared/util/dataUtil';

class SourceProductsTable extends React.Component {
  constructor(props) {
    super(props);

    this.onChange = this.onChange.bind(this);
    this.onBlur = this.onBlur.bind(this);
  }

  onChange(event, nextValue, prevValue, fieldName) {
    const { fields } = this.props;

    let index = 0;
    if (fieldName && fieldName.match('sourceProducts.*\\.code$')) {
      const regex = /sourceProducts\[([\w-]*)].code/;
      index = parseInt(fieldName.match(regex)[1]);
    }
    if (fieldName && fieldName.match('sourceProducts.*\\.blendPercentage$')) {
      const regex = /sourceProducts\[([\w-]*)].blendPercentage/;
      index = parseInt(fieldName.match(regex)[1]);
    }

    if (index === fields.length - 1 && _.isEmpty(prevValue) && !_.isEmpty(nextValue)) {
      fields.push({ code: '', blendPercentage: '' });
    }
  }

  onBlur(event, productCode, index) {
    const { fields } = this.props;

    if (_.isEmpty(productCode)) {
      if (fields.length - 1 !== index) {
        event.preventDefault();
        fields.remove(index);
      }
    }
  }

  getNotification() {
    const {
      meta: { error, warning }
    } = this.props;
    return (
      (error && (
        <Label basic color='red' pointing>
          {error}
        </Label>
      )) ||
      (warning && (
        <Label basic color='orange' pointing>
          {warning}
        </Label>
      ))
    );
  }

  render() {
    const { fields, products } = this.props;

    return (
      <div pid='source-products__full-table'>
        <Table columns={3} fixed size='small'>
          <Table.Header>
            <Table.Row>
              <Table.HeaderCell width={10}>Source Products</Table.HeaderCell>
              <Table.HeaderCell width={3}>Blend %</Table.HeaderCell>
              <Table.HeaderCell width={3}>Cost</Table.HeaderCell>
            </Table.Row>
          </Table.Header>
          <Table.Body>
            {fields.map((fieldString, index) => {
              const product = products[fields.get(index).code] || {};

              return (
                <Table.Row key={`${index}-${fieldString}`}>
                  <Table.Cell width={10}>
                    <Field
                      component={ProductDuplicate}
                      name={`${fieldString}.code`}
                      normalize={normalizeProductCode}
                      onChange={this.onChange}
                      onBlur={(event, productCode) => this.onBlur(event, productCode, index)}
                      hideDescriptionLabel={true}
                      product={product}
                      useDotDotDot={false}
                      descriptionFontSize={'15px'}
                    />
                  </Table.Cell>
                  <Table.Cell width={3}>
                    <Field
                      component={FormElement}
                      name={`${fieldString}.blendPercentage`}
                      as={Form.Input}
                      type='text'
                      normalize={normalizeToTwoDecimalPlaces}
                    />
                  </Table.Cell>
                  <Table.Cell width={3} pid={`${fieldString}-cost`}>
                    {formatNumberToTwoDecimalPlacesString(product.cost)}
                  </Table.Cell>
                </Table.Row>
              );
            })}
          </Table.Body>
        </Table>
        {this.getNotification()}
      </div>
    );
  }
}

SourceProductsTable.propTypes = {
  meta: PropTypes.object.isRequired,
  fields: PropTypes.object.isRequired,
  products: PropTypes.object.isRequired
};

export default SourceProductsTable;
