import React, { Fragment } from 'react';
import { Field } from 'redux-form';
import { normalizeToTwoDecimalPlaces } from '../../shared/components/product/normalizer';
import { Form } from 'semantic-ui-react';
import PropTypes from 'prop-types';
import FormElement from '../../shared/FormElement';
import FormLabel from '../../shared/FormLabel';
import {
  formatNumberToTwoDecimalPlacesString,
  formatNumberToTwoDecimalPlacesStringIncludeZero
} from '../../shared/util/dataUtil';

const CuttingYieldModelPricingFactors = ({ sourceProductCost, additives }) => {
  return (
    <Fragment>
      <FormLabel
        label='Source Cost'
        value={formatNumberToTwoDecimalPlacesString(sourceProductCost)}
        width={3}
      />
      <Field
        component={FormElement}
        name='labor'
        as={Form.Input}
        type='text'
        label='Labor'
        width={2}
        normalize={normalizeToTwoDecimalPlaces}
      />
      <Field
        component={FormElement}
        name='packaging'
        as={Form.Input}
        type='text'
        label='packaging'
        width={2}
        normalize={normalizeToTwoDecimalPlaces}
      />
      <Field
        component={FormElement}
        name='overhead'
        as={Form.Input}
        type='text'
        label='overhead'
        width={2}
        normalize={normalizeToTwoDecimalPlaces}
      />
      <FormLabel
        label='additives'
        value={formatNumberToTwoDecimalPlacesStringIncludeZero(additives)}
        width={2}
      />
    </Fragment>
  );
};

CuttingYieldModelPricingFactors.propTypes = {
  sourceProductCost: PropTypes.number,
  additives: PropTypes.number
};

export default CuttingYieldModelPricingFactors;
