import React from 'react';
import PropTypes from 'prop-types';
import _ from 'lodash';
import { Field, formValueSelector } from 'redux-form';
import { Form, Label, Table } from 'semantic-ui-react';
import ProductDuplicate from '../../shared/components/product/ProductDuplicate';
import {
  normalizeProductCode,
  normalizeToTwoDecimalPlaces
} from '../../shared/components/product/normalizer';
import FormElement from '../../shared/FormElement';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import { checkByProduct, clearByproductCost } from '../actions/cuttingYieldModelActions';
import { getProduct, setProductExistTo } from '../../shared/components/product/actionsDuplicate';
import { NOT_A_PRODUCT_CODE } from '../../../config/errorMessage';
import { formatNumberToTwoDecimalPlacesString } from '../../shared/util/dataUtil';

export class ByproductTableComponent extends React.Component {
  constructor(props) {
    super(props);

    this.byProductCostBlur = this.byProductCostBlur.bind(this);
    this.byProductLaborBlur = this.byProductLaborBlur.bind(this);
    this.handleProductCodeChange = this.handleProductCodeChange.bind(this);
  }

  componentDidUpdate() {
    const { fields } = this.props;
    let noEmptyByProductCodes = _.every(fields.getAll(), field => {
      return _.get(field, 'byproductCode', '') !== '';
    });

    if (noEmptyByProductCodes) {
      fields.push({});
    }
  }

  componentWillUnmount() {
    const { fields, setProductExistTo } = this.props;
    fields.getAll().forEach((field, index) => {
      const byProductCode = _.get(field, 'byproductCode', '');
      if (!_.isEmpty(byProductCode)) {
        setProductExistTo(`yieldByproducts[${index}].byproductCode`, true);
      }
    });
  }

  handleAddNewByproductOnBlur(event, productCode, fieldName, index) {
    const { fields, getProduct, setProductExistTo, clearByproductCost } = this.props;
    if (_.isEmpty(productCode)) {
      if (fields.length - 1 !== index) {
        setProductExistTo(fieldName, true);
        event.preventDefault();
        fields.remove(index);
        clearByproductCost();
      }
    } else {
      getProduct(productCode, () => setProductExistTo(fieldName, false));
    }
  }

  handleProductCodeChange(event, productCode, prevValue, fieldName) {
    const { setProductExistTo } = this.props;
    if (!_.isEmpty(productCode)) {
      setProductExistTo(fieldName, true);
    }
  }

  getNotification() {
    const {
      message,
      meta: { error, warning, dirty, invalid, submitFailed }
    } = this.props;
    if (invalid && (dirty || submitFailed) && !message) {
      return (
        (error && (
          <Label basic color='red' pointing>
            {error}
          </Label>
        )) ||
        (warning && (
          <Label basic color='orange' pointing>
            {warning}
          </Label>
        ))
      );
    } else {
      return (
        message && (
          <Label basic color='red' pointing>
            {message}
          </Label>
        )
      );
    }
  }

  byProductCostBlur(event, byproduct) {
    if (byproduct.cost) {
      this.props.checkByProduct(byproduct);
    }
  }

  byProductLaborBlur(event, byproduct) {
    if (byproduct.labor) {
      this.props.checkByProduct(byproduct);
    }
  }

  render() {
    const { fields, pricingModelCostsAndLabors, products, productsExist } = this.props;

    return (
      <div>
        <Table columns={4} fixed size='small'>
          <Table.Header>
            <Table.Row>
              <Table.HeaderCell width={10}>BYPRODUCTS</Table.HeaderCell>
              <Table.HeaderCell width={2}>YIELD %</Table.HeaderCell>
              <Table.HeaderCell width={2}>COST</Table.HeaderCell>
              <Table.HeaderCell width={2}>LABOR</Table.HeaderCell>
            </Table.Row>
          </Table.Header>
          <Table.Body>
            {fields.map((byproduct, index) => {
              const byProductInfo = fields.get(index);
              let sameCost = true;
              let sameLabor = true;
              if (pricingModelCostsAndLabors[byProductInfo.byproductCode]) {
                sameCost = pricingModelCostsAndLabors[byProductInfo.byproductCode].cost;
                sameLabor = pricingModelCostsAndLabors[byProductInfo.byproductCode].labor;
              }
              const sameCostClass = !byProductInfo.byproductCode || sameCost ? '' : ' not-same';
              const sameLaborClass = !byProductInfo.byproductCode || sameLabor ? '' : ' not-same';

              const productInformation = products[byProductInfo.byproductCode] || {};

              return (
                <Table.Row key={`${index}`}>
                  <Table.Cell width={10} className={'byproduct'}>
                    <Field
                      component={ProductDuplicate}
                      name={`${byproduct}.byproductCode`}
                      normalize={normalizeProductCode}
                      maxLength={7}
                      message={
                        _.get(productsExist, `${byproduct}.byproductCode`, true)
                          ? null
                          : NOT_A_PRODUCT_CODE
                      }
                      onBlur={(event, byproductCode, prevValue, fieldName) =>
                        this.handleAddNewByproductOnBlur(event, byproductCode, fieldName, index)
                      }
                      onChange={this.handleProductCodeChange}
                      hideDescriptionLabel={true}
                      useDotDotDot={false}
                      descriptionFontSize='15px'
                      product={productInformation}
                    />
                  </Table.Cell>
                  <Table.Cell width={2}>
                    <Field
                      component={FormElement}
                      name={`${byproduct}.yieldPercentage`}
                      className={'yield-percentage'}
                      as={Form.Input}
                      normalize={normalizeToTwoDecimalPlaces}
                    />
                  </Table.Cell>
                  <Table.Cell width={2} className={'byproduct-cost'}>
                    <Field
                      component={FormElement}
                      name={`${byproduct}.cost`}
                      onBlur={event => this.byProductCostBlur(event, fields.get(index))}
                      className={`yield-byproduct-cost${sameCostClass}`}
                      as={Form.Input}
                      normalize={normalizeToTwoDecimalPlaces}
                    />
                  </Table.Cell>
                  <Table.Cell width={2} className={'byproduct-labor'}>
                    <Field
                      component={FormElement}
                      name={`${byproduct}.labor`}
                      onBlur={event => this.byProductLaborBlur(event, fields.get(index))}
                      className={`yield-byproduct-labor${sameLaborClass}`}
                      as={Form.Input}
                      normalize={normalizeToTwoDecimalPlaces}
                    />
                  </Table.Cell>
                </Table.Row>
              );
            })}
          </Table.Body>
        </Table>
        {this.getNotification()}
      </div>
    );
  }
}

ByproductTableComponent.propTypes = {
  fields: PropTypes.object.isRequired,
  meta: PropTypes.object.isRequired,
  message: PropTypes.string,
  pricingModelCostsAndLabors: PropTypes.object.isRequired,
  checkByProduct: PropTypes.func,
  getProduct: PropTypes.func,
  setProductExistTo: PropTypes.func,
  productsExist: PropTypes.object.isRequired,
  products: PropTypes.object.isRequired,
  clearByproductCost: PropTypes.func.isRequired
};

const handleNewGetByproduct = (product, yieldByproductFromForm, yieldByproducts) => {
  const byproductCode = _.get(yieldByproductFromForm, 'byproductCode', '');
  if (byproductCode === _.get(product, 'code', '')) {
    const yieldByproduct = _.find(yieldByproducts, { byproductCode: byproductCode });
    const cost = yieldByproduct ? yieldByproduct.cost : product.cost;
    const labor = yieldByproduct ? yieldByproduct.labor : product.labor;
    const packaging = yieldByproduct ? yieldByproduct.packaging : product.packaging;
    const overhead = yieldByproduct ? yieldByproduct.overhead : product.overhead;
    yieldByproductFromForm.cost = formatNumberToTwoDecimalPlacesString(cost);
    yieldByproductFromForm.labor = formatNumberToTwoDecimalPlacesString(labor);
    yieldByproductFromForm.packaging = formatNumberToTwoDecimalPlacesString(packaging);
    yieldByproductFromForm.overhead = formatNumberToTwoDecimalPlacesString(overhead);
  }
};

const initNewYieldByProduct = (products, yieldByproducts, yieldByproductsFromForm) => {
  _.forEach(yieldByproductsFromForm, (formYieldByProduct, index) => {
    const product = formYieldByProduct.byproductCode && products[formYieldByProduct.byproductCode];
    if (product && !formYieldByProduct.yieldPercentage) {
      const yieldByproductFromForm = yieldByproductsFromForm[index];
      handleNewGetByproduct(product, yieldByproductFromForm, yieldByproducts);
      product.isNewGet = false;
    }
  });
};

const formatYieldByproducts = yieldByproducts => {
  return _.map(yieldByproducts, yieldByproduct => {
    yieldByproduct.yieldPercentage = formatNumberToTwoDecimalPlacesString(
      yieldByproduct.yieldPercentage
    );
    yieldByproduct.cost = formatNumberToTwoDecimalPlacesString(yieldByproduct.cost);
    yieldByproduct.labor = formatNumberToTwoDecimalPlacesString(yieldByproduct.labor);
    yieldByproduct.packaging = formatNumberToTwoDecimalPlacesString(yieldByproduct.packaging);
    yieldByproduct.overhead = formatNumberToTwoDecimalPlacesString(yieldByproduct.overhead);
    return yieldByproduct;
  });
};

const initialYieldByProducts = (yieldByproducts, products, yieldByproductsFromForm) => {
  const formattedYieldByproducts = formatYieldByproducts(yieldByproducts);
  const initializedYieldByproducts =
    formattedYieldByproducts && !_.isEmpty(formattedYieldByproducts)
      ? formattedYieldByproducts
      : [{}];
  if (yieldByproductsFromForm) {
    initNewYieldByProduct(products, initializedYieldByproducts, yieldByproductsFromForm);
  }

  return _.isEmpty(initializedYieldByproducts[0])
    ? initializedYieldByproducts
    : initializedYieldByproducts.concat([{}]);
};

const selector = formValueSelector('createCuttingYieldModelForm');
export const byproductsMapStateToPropsForYieldModelForm = state => {
  const { yieldByproducts } = state.cuttingYieldModelInfo.yieldModel;
  const products = state.productDuplicate.products ? state.productDuplicate.products : {};
  const productsExist = state.productDuplicate.productsExist || {};
  const formYieldByproducts = selector(state, 'yieldByproducts');
  const initYieldByproducts = initialYieldByProducts(
    yieldByproducts,
    products,
    formYieldByproducts
  );

  return {
    initialValues: {
      yieldByproducts: initYieldByproducts
    },
    products,
    productsExist
  };
};

const mapStateToProps = state => ({
  pricingModelCostsAndLabors: state.cuttingYieldModelInfo.pricingModelCostsAndLabors
});

const mapDispatchToProps = dispatch =>
  bindActionCreators(
    {
      clearByproductCost,
      checkByProduct,
      getProduct,
      setProductExistTo
    },
    dispatch
  );

const ByproductTable = connect(
  mapStateToProps,
  mapDispatchToProps
)(ByproductTableComponent);

export default ByproductTable;
