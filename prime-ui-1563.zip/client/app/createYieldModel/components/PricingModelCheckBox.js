// Implementation from - https://gist.github.com/mairh/233f6b4ffdbaaed8ec75bb0bef087e8f

import React from 'react';
import PropTypes from 'prop-types';
import { Form } from 'semantic-ui-react';
import FormLabel from '../../shared/FormLabel';
import _ from 'lodash';

class PricingModelCheckBox extends React.Component {
  constructor(props) {
    super(props);
    this.handleChange = this.handleChange.bind(this);
  }

  handleChange(e, { checked }) {
    const { input } = this.props;
    return input.onChange(checked);
  }

  render() {
    const { input, label, isYieldModelCurrentPricingModel, ...props } = this.props;

    if (isYieldModelCurrentPricingModel) {
      return (
        <FormLabel pid='pricing-model-yes-label' value='YES' label='Pricing Model' width={3} />
      );
    } else {
      return (
        <Form.Field width={props.width}>
          <label>{label}</label>
          <Form.Checkbox
            {..._.omit(props, ['width'])}
            {..._.omit(input, ['value'])}
            checked={!!input.value}
            type='checkbox'
            onChange={this.handleChange}
          />
        </Form.Field>
      );
    }
  }
}

PricingModelCheckBox.propTypes = {
  as: PropTypes.any,
  isYieldModelCurrentPricingModel: PropTypes.bool.isRequired,
  input: PropTypes.object,
  label: PropTypes.string,
  meta: PropTypes.object,
  message: PropTypes.string
};

export default PricingModelCheckBox;
