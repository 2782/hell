import _ from 'lodash';
import { SubmissionError } from 'redux-form';
import {
  exactLength,
  isAlreadyExisted,
  isGreaterThan,
  isGreaterThanEqual,
  isInRange,
  validOutputForYieldModel,
  number,
  positiveNumber,
  required,
  sameProductCode,
  validate,
  wholeNumber
} from '../../shared/formValidations';
import { inRange, isNetPositive, isWholeNumber } from '../../shared/util/validation';
import { getDuplicatedSubset } from '../../shared/util/dataUtil';
import { validProductCode } from '../../shared/validation/formFieldValidations';

const validateSubmission = (values, props) => {
  const { finishedProductCode, sourceProductCode, labor, additives } = values;
  const { productOutput, finishedProductCost, byproductValue } = props;
  let errors = validateFields(values);

  errors = validate(errors, finishedProductCode, 'finishedProductCode', [
    required,
    wholeNumber,
    exactLength(7),
    validOutputForYieldModel(productOutput)
  ]);
  errors = validate(errors, sourceProductCode, 'sourceProductCode', [
    required,
    wholeNumber,
    exactLength(7)
  ]);
  errors = validate(errors, labor, 'labor', [number]);
  errors = validate(errors, additives, 'additives', [number]);
  errors = validate(errors, finishedProductCost, 'finishedProductCost', [positiveNumber]);
  errors = validate(errors, byproductValue, 'byproductValue', [isGreaterThanEqual(0)]);

  if (!_.has(errors, 'finishedProductCode') && !_.has(errors, 'sourceProductCode')) {
    errors = validate(
      errors,
      sourceProductCode,
      'sourceProductCode',
      [sameProductCode(finishedProductCode)],
      'Source cannot be the same as Finished product'
    );
  }

  if (!_.isEmpty(errors)) {
    throw new SubmissionError(Object.assign({}, errors, { _error: 'Submission Failed!' }));
  }
};

const positionYieldPercentageErrorOnLastFilledInRow = byProducts => {
  let lastFilledIn = -1;
  byProducts.forEach((row, index) => {
    if (!_.isEmpty(row.yieldPercentage)) {
      lastFilledIn = index;
    }
  });
  const lastErrorRow = [];
  for (let i = 0; i < lastFilledIn; ++i) {
    lastErrorRow.push({});
  }
  lastErrorRow.push({ yieldPercentage: 'Yield % is invalid' });
  return lastErrorRow;
};

const validateFields = values => {
  const byproductErrors = validateByproducts(values);
  const additiveErrors = validateAdditives(values);
  const sourceLbsError = validateSourceLbs(values);
  const pickupPercentError = validatePickupPercent(values);

  return { ...byproductErrors, ...additiveErrors, ...sourceLbsError, ...pickupPercentError };
};

const validatePickupPercent = values => {
  let error = {};
  if (!_.isEmpty(values.pickupPercent)) {
    error = validate(error, values.pickupPercent, 'pickupPercent', [
      isInRange(0, 100, 'Pickup % is invalid')
    ]);
  }
  return error;
};

const validateByproducts = values => {
  let errors = {};
  const yieldByproducts = values.yieldByproducts;
  const yieldAdditives = values.yieldAdditives;

  if (!_.isEmpty(yieldByproducts)) {
    const yieldByproductsArrayErrors = [];
    const duplicatedByproductCode = getDuplicatedSubset(_.map(yieldByproducts, 'byproductCode'));
    const additivesProductCodes = _.map(yieldAdditives, 'productCode');

    yieldByproducts.forEach((item, itemIndex) => {
      let byproductErrors = {};

      if (item.byproductCode) {
        byproductErrors = validate(byproductErrors, item.byproductCode, 'byproductCode', [
          sameProductCode(values.finishedProductCode, 'Duplicate item number.'),
          sameProductCode(values.sourceProductCode, 'Duplicate item number.'),
          isAlreadyExisted(duplicatedByproductCode, 'Byproduct is already listed.'),
          isAlreadyExisted(additivesProductCodes, 'Duplicate item number.')
        ]);

        byproductErrors = validate(byproductErrors, item.yieldPercentage, 'yieldPercentage', [
          required,
          isInRange(0, 100, 'Yield % is invalid')
        ]);
      } else {
        byproductErrors = validate(byproductErrors, item, 'byproductCode', [
          noByProductCode('Required')
        ]);
      }

      yieldByproductsArrayErrors[itemIndex] = byproductErrors;
    });

    // Honor missing required field complaints before checking of the total == 100%
    if (_.filter(yieldByproductsArrayErrors, row => !_.isEmpty(row)).length > 0) {
      errors.yieldByproducts = yieldByproductsArrayErrors;
      return errors;
    }

    const yieldByproductsWithByproductCode = _.filter(
      yieldByproducts,
      yieldByProduct =>
        yieldByProduct && (!_.isEmpty(yieldByProduct) && yieldByProduct.byproductCode)
    );

    if (!_.isEmpty(yieldByproductsWithByproductCode)) {
      const totalByproductPercentage = _.sumBy(
        yieldByproductsWithByproductCode,
        byProduct => parseFloat(byProduct.yieldPercentage) || 0
      );
      if (!inRange(totalByproductPercentage, 0, 100)) {
        errors = {
          ...errors,
          yieldByproducts: positionYieldPercentageErrorOnLastFilledInRow(
            yieldByproductsWithByproductCode
          )
        };
      }
    }
  }
  return errors;
};

const noByProductCode = (errorMessage = 'Required') => (value, fieldName) => {
  if (
    (!_.isEmpty(value.yieldPercentage) || !_.isEmpty(value.cost) || !_.isEmpty(value.labor)) &&
    _.isEmpty(value.byproductCode)
  ) {
    return _.set({}, fieldName, errorMessage);
  }
};

const validateAdditives = values => {
  let errors = {};
  const yieldAdditives = values.yieldAdditives;
  const yieldByproducts = values.yieldByproducts;

  if (!_.isEmpty(yieldAdditives)) {
    const yieldAdditivesArrayErrors = [];
    const duplicatedAdditives = getDuplicatedSubset(_.map(yieldAdditives, 'productCode'));
    const byproductCodes = _.map(yieldByproducts, 'byproductCode');

    yieldAdditives.forEach((item, itemIndex) => {
      let additiveErrors = {};
      if (item.productCode) {
        additiveErrors = validate(additiveErrors, item.productCode, 'productCode', [
          sameProductCode(values.finishedProductCode, 'Duplicate item number.'),
          sameProductCode(values.sourceProductCode, 'Duplicate item number.'),
          isAlreadyExisted(duplicatedAdditives, 'Additive is already listed.'),
          isAlreadyExisted(byproductCodes, 'Duplicate item number.')
        ]);

        additiveErrors = validate(additiveErrors, item.weight, 'weight', [
          required,
          isGreaterThan(0, 'Invalid quantity')
        ]);
      } else {
        additiveErrors = validate(additiveErrors, item, 'productCode', [
          noAdditiveCode('Required')
        ]);
      }

      yieldAdditivesArrayErrors[itemIndex] = additiveErrors;
    });

    if (_.filter(yieldAdditivesArrayErrors, row => !_.isEmpty(row)).length > 0) {
      errors.yieldAdditives = yieldAdditivesArrayErrors;
      return errors;
    }
  }
  return errors;
};

const noAdditiveCode = (errorMessage = 'Required') => (value, fieldName) => {
  if (!_.isEmpty(value.weight) && _.isEmpty(value.productCode)) {
    return _.set({}, fieldName, errorMessage);
  }
};

const validateSourceLbs = values => {
  let errors = {};
  const { sourceLbs } = values;
  const yieldAdditives = _.filter(
    values.yieldAdditives,
    yieldAdditive => yieldAdditive && (!_.isEmpty(yieldAdditive) && yieldAdditive.productCode)
  );

  const yieldAdditivesLbs = _.sumBy(yieldAdditives, additive => _.toNumber(additive.weight));

  if (!_.isEmpty(yieldAdditives) && !sourceLbs) {
    errors.sourceLbs = 'Required';
    return errors;
  }

  if (
    sourceLbs &&
    !(
      inRange(sourceLbs, 0, 99999, '(]') &&
      isWholeNumber(sourceLbs) &&
      isNetPositive(sourceLbs, yieldAdditivesLbs)
    )
  ) {
    errors.sourceLbs = 'Invalid quantity';
    return errors;
  }
  return errors;
};

const processFinishedProductCodeError = (errors, errorDetails, values) => {
  const finishedProductErrorDetails = errorDetails.find(
    detail => detail.value === values.finishedProductCode
  );
  const issue = finishedProductErrorDetails ? finishedProductErrorDetails.issue : '';

  switch (issue) {
    case 'PRODUCT_IS_NOT_PRODUCTION_ITEM':
      errors = {
        finishedProductCode: 'Not a production item. Cannot create yield model for this product',
        ...errors
      };
      break;
    case 'PRODUCT_IS_BYPRODUCT_ONLY_ITEM':
      errors = {
        finishedProductCode: 'Byproduct only items cannot have pricing model.',
        ...errors
      };
      break;
    case 'IN_PRODUCT_GROUP':
      // TODO: Sync this with the pre-POST message, above.  It is trickier to access the finished
      // product's primary group code by the time we get here
      errors = {
        finishedProductCode: 'N/A. Finished product is part of Yield Model Product Group',
        ...errors
      };
      break;
    default:
      break;
  }

  return errors;
};

const processYieldByproductCodeErrors = (errors, errorDetails, values) => {
  const byproductCodes = values.yieldByproducts.map(byproduct => byproduct.byproductCode);
  const byproductErrors = [];

  byproductCodes.forEach((byproductCode, index) => {
    const byproductErrorDetail = errorDetails.find(
      detail => `yieldByproducts[${index}].byproductCode` === detail.field
    );

    const issue = byproductErrorDetail ? byproductErrorDetail.issue : '';
    let byproductError = {};

    switch (issue) {
      case 'PRODUCT_IS_NOT_PRODUCTION_ITEM':
        byproductError = {
          byproductCode: 'Must be produced item.'
        };
        break;
      case 'NOT_EXIST':
        byproductError = {
          byproductCode: 'Product does not exist.'
        };
        break;
      default:
        break;
    }

    byproductErrors.push(byproductError);
  });

  return { yieldByproducts: byproductErrors, ...errors };
};

const processFinishedProductCostError = (errors, errorDetails) => {
  const finishedProductCostErrorDetails = errorDetails.find(
    detail => detail.field === 'finishedProductCost'
  );
  if (finishedProductCostErrorDetails) {
    return { ...errors, finishedProductCost: finishedProductCostErrorDetails.issue };
  } else {
    return errors;
  }
};

const processErrorResponse = (errorResponse, values) => {
  const errorDetails = _.get(errorResponse, 'error.details', []);
  let errors = {};

  errors = processFinishedProductCodeError(errors, errorDetails, values);
  errors = processYieldByproductCodeErrors(errors, errorDetails, values);
  errors = processFinishedProductCostError(errors, errorDetails);

  throw new SubmissionError(
    Object.assign({}, { _error: 'Cannot create yield model for this product.' }, errors)
  );
};

const validateSourceProduct = props => {
  const { sourceProductCode, finishedProductCode } = props;

  if (!_.isEmpty(sourceProductCode) && sourceProductCode === finishedProductCode) {
    return 'Source cannot be the same as Finished product';
  }

  return checkSourceProductCostExist(props) ? 'Source product does not have a cost' : undefined;
};

const checkSourceProductCostExist = props => {
  const { sourceProductCode, productsDuplicate, sourceProductCost } = props;
  return (
    sourceProductCode &&
    validProductCode(productsDuplicate, sourceProductCode) &&
    !sourceProductCost
  );
};

export default {
  validateSubmission,
  validateFields,
  positionYieldPercentageErrorOnLastFilledInRow,
  processErrorResponse,
  validateSourceProduct
};
