import React from 'react';
import PropTypes from 'prop-types';
import { mount, shallow } from 'enzyme';
import { Field, FieldArray, Form, reduxForm } from 'redux-form';
import { connect, Provider } from 'react-redux';
import { createReduxStore } from '../../../store';
import semanticUI from '../../../../test-helpers/semantic-ui';
import productFactory from '../../../../test-factories/productFactory';
import { NOT_A_PRODUCT_CODE, MUST_BE_A_SOURCE_ITEM } from '../../../../config/errorMessage';
import AdditiveTable, {
  additivesMapStateToPropsForYieldModelForm,
  AdditiveTableComponent
} from '../AdditiveTable';

describe('additiveTable', () => {
  let wrapper,
    fields,
    fieldNames,
    Decorated,
    removeSpy,
    pushSpy,
    fieldValue,
    products,
    productsExist;

  describe('with reduxForm decoration', () => {
    class AdditivesWrapper extends React.Component {
      render() {
        const { handleSubmit, products, productsExist } = this.props;
        return (
          <Form onSubmit={handleSubmit}>
            <FieldArray
              name={'yieldAdditives'}
              component={AdditiveTable}
              props={{ products, productsExist }}
            />
          </Form>
        );
      }
    }

    AdditivesWrapper.propTypes = {
      handleSubmit: PropTypes.func.isRequired,
      products: PropTypes.object.isRequired,
      productsExist: PropTypes.object.isRequired
    };

    const DecoratedAdditivesWrapper = connect(additivesMapStateToPropsForYieldModelForm)(
      reduxForm({
        form: 'createCuttingYieldModelForm'
      })(AdditivesWrapper)
    );

    beforeEach(() => {
      fieldValue = [
        { productCode: '4181840', weight: '30.00', id: 100, cost: 12.8 },
        { productCode: '3401581', weight: '99.99', id: 101, cost: 11.5 }
      ];
      const additives = [
        {
          productCode: '0079006',
          weight: '30.00',
          id: 100,
          cost: 12.8
        },
        {
          productCode: '0565109',
          weight: '99.99',
          id: 101,
          cost: 11.5
        }
      ];

      const store = createReduxStore({
        productDuplicate: {
          products: {
            '0079006': productFactory.build({ code: '0079006' }),
            '0565109': productFactory.build({ code: '0565109' })
          },
          productsExist: {}
        },
        cuttingYieldModelInfo: {
          pricingModelCostsAndLabors: {
            '0079006': { productCode: '0079006', cost: true, labor: false },
            '0565109': { productCode: '0565109', cost: false, labor: true }
          },
          yieldModel: {
            yieldAdditives: additives
          }
        }
      });

      wrapper = mount(
        <Provider store={store}>
          <DecoratedAdditivesWrapper />
        </Provider>
      );
    });

    test('should remove row for additive when no product code on blur', () => {
      semanticUI.changeInput(wrapper, 'yieldAdditives[0].productCode', '');
      jestExpect(semanticUI.doesInputExist(wrapper, 'yieldAdditives[0].productCode')).toEqual(true);
      jestExpect(semanticUI.getInputValue(wrapper, 'yieldAdditives[0].productCode')).toEqual(
        '0565109'
      );

      jestExpect(semanticUI.doesInputExist(wrapper, 'yieldAdditives[1].productCode')).toEqual(true);
      jestExpect(semanticUI.getInputValue(wrapper, 'yieldAdditives[1].productCode')).toEqual('');

      jestExpect(semanticUI.doesInputExist(wrapper, 'yieldAdditives[2].productCode')).toEqual(
        false
      );
    });
  });

  describe('without redux form decoration', () => {
    beforeEach(() => {
      removeSpy = jest.fn();
      pushSpy = jest.fn();
      fieldValue = [
        { productCode: '4181840', weight: '30.00', id: 100, cost: 12.8 },
        { productCode: '3401581', weight: '99.99', id: 101, cost: 11.5 }
      ];

      products = {
        '4181840': productFactory.build({
          code: '4181840',
          description: 'PRIME T-BONE STEAK For 4181840',
          productOutput: 'SOURCE'
        }),
        '3401581': productFactory.build({
          code: '3401581',
          description: 'PRIME T-BONE STEAK For 3401581',
          productOutput: 'SOURCE'
        })
      };
      productsExist = {
        'yieldAdditives[0].productCode': true,
        'yieldAdditives[1].productCode': true
      };
      fieldNames = ['yieldAdditives[0]', 'yieldAdditives[1]'];
      fields = {
        getAll: () => fieldValue,
        get: index => fieldValue[index],
        map: callback => fieldNames.map((name, idx) => callback(name, idx)),
        push: pushSpy,
        forEach: callback => {
          fieldValue.forEach((field, index) => callback(field, index));
        },
        remove: removeSpy,
        length: fieldValue.length
      };
      Decorated = reduxForm({ form: 'testForm' })(AdditiveTable);
      const store = createReduxStore({
        cuttingYieldModelInfo: {}
      });

      wrapper = mount(
        <Provider store={store}>
          <Decorated
            fields={fields}
            meta={{ dirty: true, invalid: true, error: 'Error Message', submitFailed: false }}
            products={products}
            productsExist={productsExist}
          />
        </Provider>
      );
    });

    test('should set the initial value', () => {
      const tableHeader = wrapper.find('TableHeader');
      jestExpect(tableHeader.find('TableHeaderCell').at(0)).toHaveText('ADDITIVES');
      jestExpect(tableHeader.find('TableHeaderCell').at(1)).toHaveText('WEIGHT (LBS)');
      jestExpect(tableHeader.find('TableHeaderCell').at(2)).toHaveText('COST');

      const tableBody = wrapper.find('TableBody');
      jestExpect(tableBody.find('TableRow')).toHaveLength(2);

      const row1 = tableBody.find('TableRow').at(0);
      jestExpect(
        row1
          .find('TableCell')
          .at(0)
          .find('Field')
      ).toHaveProp({ product: products['4181840'] });
      jestExpect(
        row1
          .find('TableCell')
          .at(2)
          .text()
      ).toEqual('12.8');

      const row2 = tableBody.find('TableRow').at(1);
      jestExpect(
        row2
          .find('TableCell')
          .at(0)
          .find('Field')
      ).toHaveProp({ product: products['3401581'] });

      jestExpect(
        row2
          .find('TableCell')
          .at(2)
          .text()
      ).toEqual('11.5');
    });

    test('should show error when invalid', () => {
      jestExpect(wrapper.find('Label')).toHaveLength(1);
      jestExpect(wrapper.find('Label')).toHaveText('Error Message');
    });

    test('should add row for new additive when on blur', () => {
      semanticUI.changeInput(wrapper, 'yieldAdditives[1].productCode', '0096505');
      jestExpect(pushSpy).toBeCalledWith({});
    });

    test('should call setProductTo action on change', () => {
      const setProductExistToSpy = jest.fn();
      wrapper = shallow(
        <AdditiveTableComponent
          setProductExistTo={setProductExistToSpy}
          fields={fields}
          meta={{}}
          products={{}}
          productsExist={{}}
        />
      );

      const fieldName = 'yieldAdditives[0].productCode';
      wrapper
        .find(Field)
        .at(0)
        .simulate('change', { target: { value: '' } }, '340158', '3401581', fieldName);

      jestExpect(setProductExistToSpy).toBeCalledWith(fieldName, true);
    });

    test('should call getProduct action on blur', () => {
      const getProductMock = jest.fn();

      wrapper = shallow(
        <AdditiveTableComponent
          setProductExistTo={() => {}}
          fields={fields}
          getProduct={getProductMock}
          meta={{}}
          products={{}}
          productsExist={{}}
        />
      );

      const fieldName = 'yieldAdditives[0].productCode';
      wrapper
        .find(Field)
        .at(0)
        .simulate(
          'blur',
          {
            target: { value: '' },
            preventDefault: () => {}
          },
          '3401581',
          '340158',
          fieldName
        );

      jestExpect(getProductMock).toHaveBeenCalledWith('3401581', jestExpect.any(Function));
    });

    test('should call setProductExistTo action on unsuccessful getProduct call on blur', () => {
      const getProductStub = jest.fn();
      const setProductExistToSpy = jest.fn();
      wrapper = shallow(
        <AdditiveTableComponent
          setProductExistTo={setProductExistToSpy}
          fields={fields}
          getProduct={getProductStub}
          meta={{}}
          products={{}}
          productsExist={{}}
        />
      );

      const fieldName = 'yieldAdditives[0].productCode';
      getProductStub.mockImplementation((productCode, callback) => callback());
      wrapper
        .find(Field)
        .at(0)
        .simulate(
          'blur',
          {
            target: { value: '' },
            preventDefault: () => {}
          },
          '3401581',
          '340158',
          fieldName
        );

      jestExpect(setProductExistToSpy).toBeCalledWith(fieldName, false);
    });

    describe('rendering message for Product Component', () => {
      test('should pass NOT_A_PRODUCT_CODE when product does not exist', () => {
        productsExist = {
          'yieldAdditives[0].productCode': false
        };

        const setProductExistToSpy = jest.fn();
        const wrapper = shallow(
          <AdditiveTableComponent
            setProductExistTo={setProductExistToSpy}
            fields={fields}
            getProduct={jest.fn()}
            meta={{}}
            products={{}}
            productsExist={productsExist}
          />
        );

        const productField = wrapper.find(Field).at(0);

        jestExpect(productField).toHaveProp({ message: NOT_A_PRODUCT_CODE });
      });

      test('should pass null when product does exist', () => {
        productsExist = {
          'yieldAdditives[0].productCode': true
        };

        const setProductExistToSpy = jest.fn();
        const wrapper = shallow(
          <AdditiveTableComponent
            setProductExistTo={setProductExistToSpy}
            fields={fields}
            getProduct={jest.fn()}
            meta={{}}
            products={{}}
            productsExist={productsExist}
          />
        );

        const productField = wrapper.find(Field).at(0);

        jestExpect(productField).toHaveProp({ message: null });
      });

      test('should pass MUST_BE_A_SOURCE_ITEM when product is a finished product', () => {
        productsExist = {
          'yieldAdditives[0].productCode': true
        };

        products = {
          '4181840': productFactory.build({
            code: '4181840',
            description: 'PRIME T-BONE STEAK For 4181840'
          }),
          '3401581': productFactory.build({
            code: '3401581',
            description: 'PRIME T-BONE STEAK For 3401581',
            productOutput: 'SOURCE'
          })
        };

        const setProductExistToSpy = jest.fn();
        const wrapper = shallow(
          <AdditiveTableComponent
            setProductExistTo={setProductExistToSpy}
            fields={fields}
            getProduct={jest.fn()}
            meta={{}}
            products={products}
            productsExist={productsExist}
          />
        );

        const productField = wrapper.find(Field).at(0);

        jestExpect(productField).toHaveProp({ message: MUST_BE_A_SOURCE_ITEM });
      });
    });

    describe('componentWillUnmount', () => {
      test('should call setProductExistsTo for additive upon unmount', () => {
        const setProductExistToSpy = jest.fn();
        const wrapper = shallow(
          <AdditiveTableComponent
            setProductExistTo={setProductExistToSpy}
            fields={fields}
            getProduct={jest.fn()}
            meta={{}}
            products={{}}
            productsExist={productsExist}
          />
        );

        wrapper.unmount();

        jestExpect(setProductExistToSpy).toBeCalledWith('yieldAdditives[0].productCode', true);
        jestExpect(setProductExistToSpy).toBeCalledWith('yieldAdditives[1].productCode', true);
      });
    });
  });
});
