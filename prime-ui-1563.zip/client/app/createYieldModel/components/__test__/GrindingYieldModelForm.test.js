import React from 'react';
import { mount, shallow } from 'enzyme';
import { createReduxStore } from '../../../store';
import GrindingYieldModelForm, {
  areSourceProductsUnchanged,
  asyncValidate,
  FinishedCost,
  FORM_NAME,
  mandatoryFieldsAvaliable,
  mapStateToProps,
  SaveButton
} from '../GrindingYieldModelForm';
import { Provider } from 'react-redux';
import yieldModelResources from '../../../shared/api/yieldModelResources';
import semanticUI from '../../../../test-helpers/semantic-ui';
import productResources from '../../../shared/api/productResources';
import productFactory from '../../../../test-factories/productFactory';
import { Button } from 'semantic-ui-react';
import GrindingYieldModelFactory from '../../../../test-factories/grindingYieldModel';
import FormLabel from '../../../shared/FormLabel';
import { showModal } from '../../../shared/actions/actions';

jest.mock('../../../shared/actions/actions', () => ({
  showModal: jest.fn(() => ({ type: 'MOCK_SHOW_MODAL' })),
  hideModal: jest.fn(() => ({ type: 'MOCK_HIDE_MODAL' }))
}));

jest.mock('../../../shared/api/yieldModelResources');
jest.mock('../../../shared/api/productResources');

const finishedProduct = productFactory.build({
  code: '4100158',
  description: 'Beef Tenderloin 12OZ'
});

const sourceProductA = productFactory.build({
  code: '0204000',
  description: 'Cow Shoulder 8OZ'
});

const sourceProductB = productFactory.build({
  code: '0204001',
  description: 'Chicken Leg 10OZ'
});

describe('GrindingYieldModelForm', () => {
  let form;

  beforeEach(() => {
    yieldModelResources.calculateGrindingYieldModelFinishedCost.mockResolvedValue({});
    productResources.getProductInfo.mockResolvedValue({});
    yieldModelResources.checkGrindingYieldModelExists.mockImplementation(() => {});
    yieldModelResources.getBlends.mockResolvedValue({
      data: [{ name: 'BLEND01', displayName: 'BLEND01 - 50/90 - TRIM 75/25', priority: 1 }]
    });
  });

  test('should initialize form value when no yield model in store', () => {
    form = mount(
      <Provider store={createReduxStore({})}>
        <GrindingYieldModelForm shouldAsyncValidate={() => false} />
      </Provider>
    );

    jestExpect(semanticUI.getDropDownSelectionOptionsText(form, 'blend')).toEqual([]);
    jestExpect(semanticUI.getInputValue(form, 'labor')).toEqual('');
    jestExpect(semanticUI.getInputValue(form, 'additives')).toEqual('');
    jestExpect(semanticUI.getInputValue(form, 'wastePercentage')).toEqual('');
    jestExpect(semanticUI.getInputValue(form, 'packaging')).toEqual('');
    jestExpect(semanticUI.getInputValue(form, 'overhead')).toEqual('');
    jestExpect(semanticUI.getInputValue(form, 'sourceProducts[0].code')).toEqual('');
    jestExpect(semanticUI.getInputValue(form, 'sourceProducts[0].blendPercentage')).toEqual('');
    jestExpect(semanticUI.getCheckBoxValue(form, 'pricingModel')).toEqual(false);
  });

  test('should initialize form value when have yieldModel in store', async () => {
    form = mount(
      <Provider
        store={createReduxStore({
          form: {
            [FORM_NAME]: {
              values: {}
            }
          },
          grindingYieldModelInfo: {
            yieldModel: GrindingYieldModelFactory.build(),
            sourceProducts: [
              { code: sourceProductA.code, blendPercentage: '30.00' },
              { code: sourceProductB.code, blendPercentage: '70.00' },
              { code: '', blendPercentage: '' }
            ],
            blends: []
          },
          productDuplicate: {
            products: {}
          },
          yieldModelInfo: {
            pricingModelConfirmationShowing: false
          }
        })}
      >
        <GrindingYieldModelForm shouldAsyncValidate={() => false} />
      </Provider>
    );

    await waitForAsyncTasks();
    form = form.update();

    semanticUI.findLabelWithName(form, 'blend');
    jestExpect(semanticUI.getLabelProp(form, 'Blend', 'value')).toEqual('Natural');

    jestExpect(semanticUI.getInputValue(form, 'labor')).toEqual('2.59');
    jestExpect(semanticUI.getInputValue(form, 'additives')).toEqual('1.31');
    jestExpect(semanticUI.getInputValue(form, 'wastePercentage')).toEqual('5.5');
    jestExpect(semanticUI.getInputValue(form, 'packaging')).toEqual('2.5');
    jestExpect(semanticUI.getInputValue(form, 'overhead')).toEqual('12.0');
    jestExpect(semanticUI.getInputValue(form, 'sourceProducts[0].code')).toEqual(
      sourceProductA.code
    );
    jestExpect(semanticUI.getInputValue(form, 'sourceProducts[0].blendPercentage')).toEqual(
      '30.00'
    );
    jestExpect(semanticUI.getInputValue(form, 'sourceProducts[1].code')).toEqual(
      sourceProductB.code
    );
    jestExpect(semanticUI.getInputValue(form, 'sourceProducts[1].blendPercentage')).toEqual(
      '70.00'
    );
    jestExpect(semanticUI.getInputValue(form, 'sourceProducts[2].code')).toEqual('');
    jestExpect(semanticUI.getInputValue(form, 'sourceProducts[2].blendPercentage')).toEqual('');
    jestExpect(semanticUI.getLabelProp(form, 'Pricing Model', 'value')).toEqual('YES');
  });

  test('should populate product description, cost with product info details', () => {
    productResources.getProductInfo.mockImplementation((productCode, callback) => {
      if (productCode === sourceProductA.code) {
        return Promise.resolve(callback({ data: sourceProductA }));
      } else if (productCode === sourceProductB.code) {
        return Promise.resolve(callback({ data: sourceProductB }));
      }
    });

    form = mount(
      <Provider store={createReduxStore()}>
        <GrindingYieldModelForm shouldAsyncValidate={() => true} />
      </Provider>
    );

    semanticUI.changeInput(form, 'sourceProducts[0].code', '204000');
    semanticUI.changeInput(form, 'sourceProducts[1].code', '204001');

    jestExpect(semanticUI.findLabelWithValue(form, sourceProductA.description).exists()).toEqual(
      true
    );
    jestExpect(semanticUI.findLabelWithValue(form, sourceProductB.description).exists()).toEqual(
      true
    );
  });

  test('Should populate product description and update finished cost when blend percentage changes', () => {
    productResources.getProductInfo.mockImplementation((productCode, callback) => {
      if (productCode === sourceProductA.code) {
        return Promise.resolve(callback({ data: sourceProductA }));
      } else if (productCode === sourceProductB.code) {
        return Promise.resolve(callback({ data: sourceProductB }));
      }
    });

    form = mount(
      <Provider store={createReduxStore()}>
        <GrindingYieldModelForm shouldAsyncValidate={() => true} />
      </Provider>
    );

    semanticUI.changeInput(form, 'sourceProducts[0].code', '204001');
    semanticUI.changeInput(form, 'sourceProducts[0].blendPercentage', '1');

    jestExpect(semanticUI.findLabelWithValue(form, sourceProductB.description)).toExist();
  });

  test('Should populate product description and update finished cost when blend percentage changes and  code is null', () => {
    productResources.getProductInfo.mockImplementation((productCode, callback) => {
      if (productCode === sourceProductA.code) {
        return Promise.resolve(callback({ data: sourceProductA }));
      } else if (productCode === sourceProductB.code) {
        return Promise.resolve(callback({ data: sourceProductB }));
      }
    });

    form = mount(
      <Provider store={createReduxStore()}>
        <GrindingYieldModelForm shouldAsyncValidate={() => true} />
      </Provider>
    );

    semanticUI.changeInput(form, 'sourceProducts[0].code', '');
    semanticUI.changeInput(form, 'sourceProducts[0].blendPercentage', '1');

    jestExpect(semanticUI.findLabelWithValue(form, sourceProductB.description)).not.toExist();
  });

  test('should fill out form and submit', async done => {
    productResources.getProductInfo.mockImplementation((productCode, callback) => {
      if (productCode === sourceProductA.code) {
        return Promise.resolve(callback({ data: sourceProductA }));
      } else if (productCode === sourceProductB.code) {
        return Promise.resolve(callback({ data: sourceProductB }));
      }
    });

    yieldModelResources.checkGrindingYieldModelExists.mockImplementation(() => {
      return Promise.resolve(null);
    });

    done();
    form = mount(
      <Provider
        store={createReduxStore({
          grindingYieldModelInfo: {
            yieldModel: {},
            sourceProducts: [{ code: '', blendPercentage: '' }],
            blends: []
          },
          productDuplicate: {
            products: {
              [finishedProduct.code]: {
                productOutput: 'FINISHED'
              }
            }
          }
        })}
      >
        <GrindingYieldModelForm shouldAsyncValidate={() => false} />
      </Provider>
    );

    await waitForAsyncTasks();
    form = form.update();

    semanticUI.selectOption(form, 'blend', 0);
    semanticUI.changeInput(form, 'additives', '2.3');
    semanticUI.changeInput(form, 'labor', '3.3');
    semanticUI.changeInput(form, 'wastePercentage', '5.5');
    semanticUI.changeInput(form, 'packaging', '7.2');
    semanticUI.changeInput(form, 'overhead', '16.1');
    semanticUI.changeInput(form, 'sourceProducts[0].code', '204000');
    semanticUI.changeInput(form, 'sourceProducts[0].blendPercentage', '60');
    semanticUI.changeInput(form, 'sourceProducts[1].code', '204001');
    semanticUI.changeInput(form, 'sourceProducts[1].blendPercentage', '40');

    form.find('form').simulate('submit');

    jestExpect(yieldModelResources.createGrindingYieldModel.mock.calls[0][0]).toEqual({
      blend: 'BLEND01',
      additives: '2.30',
      labor: '3.30',
      wastePercentage: '5.50',
      pricingModel: false,
      packaging: '7.20',
      overhead: '16.10',
      sourceProducts: [
        { code: '0204000', blendPercentage: '60.00' },
        { code: '0204001', blendPercentage: '40.00' }
      ]
    });
  });

  test('should fill out form and show a modal when submit when there is a yield model duplicate to pricing model', async done => {
    productResources.getProductInfo.mockImplementation((productCode, callback) => {
      if (productCode === sourceProductA.code) {
        return Promise.resolve(callback({ data: sourceProductA }));
      } else if (productCode === sourceProductB.code) {
        return Promise.resolve(callback({ data: sourceProductB }));
      }
    });

    yieldModelResources.checkGrindingYieldModelExists.mockImplementation(() => {
      Promise.resolve({
        blend: 0,
        additives: 2.3,
        labor: 3.3,
        wastePercentage: 5.5,
        packaging: 7.2,
        pricingModel: true,
        overhead: 16.1,
        sourceProducts: [
          {
            code: 204000,
            blendPercentage: 60
          },
          {
            code: 204001,
            blendPercentage: 40
          }
        ]
      });
      done();
    });

    form = mount(
      <Provider
        store={createReduxStore({
          router: { location: { pathname: '/other' } },
          grindingYieldModelInfo: {
            yieldModel: {},
            sourceProducts: [{ code: '', blendPercentage: '' }],
            blends: []
          },
          productDuplicate: {
            products: {
              [finishedProduct.code]: {
                productOutput: 'FINISHED'
              }
            }
          }
        })}
      >
        <GrindingYieldModelForm shouldAsyncValidate={() => false} />
      </Provider>
    );

    await waitForAsyncTasks();
    form = form.update();

    semanticUI.selectOption(form, 'blend', 0);
    semanticUI.changeInput(form, 'additives', '2.3');
    semanticUI.changeInput(form, 'labor', '3.3');
    semanticUI.changeInput(form, 'wastePercentage', '5.5');
    semanticUI.changeInput(form, 'packaging', '7.2');
    semanticUI.changeInput(form, 'overhead', '16.1');
    semanticUI.changeInput(form, 'sourceProducts[0].code', '204000');
    semanticUI.changeInput(form, 'sourceProducts[0].blendPercentage', '60');
    semanticUI.changeInput(form, 'sourceProducts[1].code', '204001');
    semanticUI.changeInput(form, 'sourceProducts[1].blendPercentage', '40');

    form.find('form').simulate('submit');

    jestExpect(showModal).toHaveBeenCalledWith(
      jestExpect.objectContaining({
        header: 'Continue with saving grinding model?',
        content: 'If you save this yield model, you will be updating an existing yield model',
        cancelButton: 'Cancel',
        cancelAction: jestExpect.any(Function),
        confirmButton: 'OK',
        confirmAction: jestExpect.any(Function)
      })
    );
  });

  test('should show confirmation if pricing model is selected', () => {
    productResources.getProductInfo.mockImplementation((productCode, callback) => {
      if (productCode === sourceProductA.code) {
        return Promise.resolve(callback({ data: sourceProductA }));
      } else if (productCode === sourceProductB.code) {
        return Promise.resolve(callback({ data: sourceProductB }));
      }
    });

    semanticUI.selectOption(form, 'blend', 0);
    semanticUI.changeInput(form, 'labor', '3.3');
    semanticUI.changeInput(form, 'wastePercentage', '2');
    semanticUI.changeInput(form, 'pricingModel', true);
    semanticUI.changeInput(form, 'sourceProducts[0].code', '204000');
    semanticUI.changeInput(form, 'sourceProducts[0].blendPercentage', '60');
    semanticUI.changeInput(form, 'sourceProducts[1].code', '204001');
    semanticUI.changeInput(form, 'sourceProducts[1].blendPercentage', '40');

    form.find('form').simulate('submit');

    jestExpect(showModal).toHaveBeenCalledWith(
      jestExpect.objectContaining({
        header: 'Continue with setting as pricing model?',
        content:
          'If you save this yield model as the pricing model, any previously defined pricing model will no longer be the pricing model.',
        cancelButton: 'Cancel',
        confirmButton: 'OK'
      })
    );
  });

  test('should clear yield model data upon unmount', () => {
    const yieldModel = GrindingYieldModelFactory.build();
    const store = createReduxStore({
      grindingYieldModelInfo: {
        yieldModel: yieldModel,
        blends: []
      },
      router: { location: { pathname: '/other' } },
      yieldModelInfo: {
        pricingModelConfirmationShowing: true
      },
      form: {
        [FORM_NAME]: {
          values: {
            sourceProducts: [
              { code: '0204000', blendPercentage: '60.00' },
              { code: '', blendPercentage: '' }
            ]
          }
        }
      }
    });
    form = mount(
      <Provider store={store}>
        <GrindingYieldModelForm shouldAsyncValidate={() => false} />
      </Provider>
    );

    form.unmount();

    jestExpect(store.getState().grindingYieldModelInfo.yieldModel).toEqual({});
    jestExpect(store.getState().yieldModelInfo.pricingModelConfirmationShowing).toEqual(false);
    jestExpect(store.getState().form.grindingYieldModel).toBeUndefined();
  });

  test('should have a finished cost displayed', () => {
    const yieldModel = GrindingYieldModelFactory.build();
    const store = createReduxStore({
      grindingYieldModelInfo: {
        yieldModel: yieldModel,
        blends: []
      },
      yieldModelInfo: {
        pricingModelConfirmationShowing: true
      },
      form: {
        [FORM_NAME]: {
          values: {
            sourceProducts: [
              { code: '0204000', blendPercentage: '60.00' },
              { code: '', blendPercentage: '' }
            ]
          }
        }
      }
    });
    form = mount(
      <Provider store={store}>
        <GrindingYieldModelForm shouldAsyncValidate={() => false} />
      </Provider>
    );

    jestExpect(form.find(FinishedCost).exists()).toEqual(true);
  });

  test('should have a save button displayed', () => {
    const yieldModel = GrindingYieldModelFactory.build();
    const store = createReduxStore({
      grindingYieldModelInfo: {
        yieldModel: yieldModel,
        blends: []
      },
      yieldModelInfo: {
        pricingModelConfirmationShowing: true
      },
      form: {
        grindingYieldModel: {
          values: {
            sourceProducts: [
              { code: '0204000', blendPercentage: '60.00' },
              { code: '', blendPercentage: '' }
            ]
          }
        }
      }
    });
    form = mount(
      <Provider store={store}>
        <GrindingYieldModelForm shouldAsyncValidate={() => false} />
      </Provider>
    );

    jestExpect(form.find(SaveButton).exists()).toEqual(true);
  });
});

describe('Finished cost', () => {
  test('should be nicely labelled', () => {
    const wrapper = shallow(<FinishedCost finishedCost={undefined} />);

    jestExpect(wrapper.find(FormLabel).props().label).toBe('UNIT COST PER LB');
  });

  test('should show a number', () => {
    const wrapper = shallow(<FinishedCost finishedCost={'3.00'} />);

    jestExpect(wrapper.find(FormLabel).props().value).toBe('3.00');
  });

  test('should show empty string if finished cost not a number', () => {
    const wrapper = shallow(<FinishedCost finishedCost={undefined} />);

    jestExpect(wrapper.find(FormLabel).props().value).toBe('');
  });
});

describe('Save button', () => {
  test('should not work when submitting and mandatory fields available', () => {
    const wrapper = shallow(<SaveButton submitting={true} pristine={false} available={true} />);

    jestExpect(wrapper.find(Button)).toBeDisabled();
  });

  test('should not work when submitting and mandatory fields not available', () => {
    const wrapper = shallow(<SaveButton submitting={true} pristine={false} available={false} />);

    jestExpect(wrapper.find(Button)).toBeDisabled();
  });

  test('should not work when pristine and mandatory fields available', () => {
    const wrapper = shallow(<SaveButton submitting={false} pristine={true} available={true} />);

    jestExpect(wrapper.find(Button)).toBeDisabled();
  });

  test('should not work when pristine and mandatory fields not available', () => {
    const wrapper = shallow(<SaveButton submitting={false} pristine={true} available={false} />);

    jestExpect(wrapper.find(Button)).toBeDisabled();
  });

  test('should normally work', () => {
    const wrapper = shallow(<SaveButton submitting={false} pristine={false} available={true} />);

    jestExpect(wrapper.find(Button)).not.toBeDisabled();
  });
});

describe('Async validation', () => {
  ['labor', 'additives', 'wastePercentage', 'packaging', 'overhead'].forEach(field => {
    test(`Should update finished cost when ${field} changes`, () => {
      const calculateFinishedCost = jest.fn();
      const values = {
        blend: 'Un',
        [field]: '2.00',
        pricingModel: false,
        sourceProducts: [
          {
            code: '0204000',
            blendPercentage: '100.00'
          },
          {}
        ]
      };

      asyncValidate(
        values,
        null,
        {
          products: {
            ['0204000']: {
              cost: 21.0
            }
          },
          calculateFinishedCost,
          finishedProductIsProduction: true
        },
        field
      );

      jestExpect(calculateFinishedCost.mock.calls[0][0]).toEqual(values);
    });
  });

  test('Should update finished cost when sourceProducts[0].blendPercentage changes', async () => {
    const calculateFinishedCost = jest.fn(values);
    const values = {
      blend: 'Blend01',
      pricingModel: false,
      sourceProducts: [
        {
          code: '0204000',
          blendPercentage: '100.00'
        },
        {}
      ]
    };

    await asyncValidate(
      values,
      null,
      {
        products: {
          ['0204000']: {
            cost: 21.0
          }
        },
        calculateFinishedCost,
        finishedProductIsProduction: true
      },
      'sourceProducts[0].blendPercentage'
    );
    jestExpect(calculateFinishedCost.mock.calls[0][0]).toEqual(values);
  });
});

describe('Comparing sourceProduct field changes', () => {
  test('should see as changed if length is different', () => {
    const sourceProducts1 = [1];
    const sourceProducts2 = [2, 3];

    jestExpect(areSourceProductsUnchanged(sourceProducts1, sourceProducts2)).toEqual(false);
  });

  test('should see blendPercentages unchanged if one is number and other is string', () => {
    const sourceProducts1 = [{ code: '0078889', blendPercentage: 25 }];
    const sourceProducts2 = [{ code: '0078889', blendPercentage: '25.00' }];
    jestExpect(areSourceProductsUnchanged(sourceProducts1, sourceProducts2)).toEqual(true);
  });

  test('should see blendPercentages unchanged if one string has greater precision than other string', () => {
    const sourceProducts1 = [{ code: '0078889', blendPercentage: '25' }];
    const sourceProducts2 = [{ code: '0078889', blendPercentage: '25.00' }];
    jestExpect(areSourceProductsUnchanged(sourceProducts1, sourceProducts2)).toEqual(true);
  });

  test('should see as change if one code is different than the other', () => {
    const sourceProducts1 = [{ code: '0068205', blendPercentage: '25' }];
    const sourceProducts2 = [{ code: '0078889', blendPercentage: '25' }];
    jestExpect(areSourceProductsUnchanged(sourceProducts1, sourceProducts2)).toEqual(false);
  });

  test('should see as changed if sourceProduct order is reversed', () => {
    const sourceProducts1 = [
      { code: '0068205', blendPercentage: '75' },
      { code: '0078889', blendPercentage: '25' }
    ];
    const sourceProducts2 = [
      { code: '0078889', blendPercentage: '25' },
      { code: '0068205', blendPercentage: '75' }
    ];
    jestExpect(areSourceProductsUnchanged(sourceProducts1, sourceProducts2)).toEqual(false);
  });

  test('should see as unchanged if sourceProducts are equal', () => {
    const sourceProducts1 = [
      { code: '0078889', blendPercentage: '25' },
      { code: '', blendPercentage: '' }
    ];
    const sourceProducts2 = [
      { code: '0078889', blendPercentage: '25' },
      { code: '', blendPercentage: '' }
    ];

    jestExpect(areSourceProductsUnchanged(sourceProducts1, sourceProducts2)).toEqual(true);
  });
});

describe('Mandatory fields avaliablity check', () => {
  test('Should check if both blend and source products are empty', () => {
    const blendOnForm = '';
    const sourceProductsOnForm = [{ code: '', blendPercentage: '' }];

    jestExpect(mandatoryFieldsAvaliable(blendOnForm, sourceProductsOnForm)).toEqual(false);
  });

  test('Should check if blend is not empty and source products is empty', () => {
    const blendOnForm = 'Natural';
    const sourceProductsOnForm = [{ code: '', blendPercentage: '' }];

    jestExpect(mandatoryFieldsAvaliable(blendOnForm, sourceProductsOnForm)).toEqual(false);
  });

  test('Should check if blend is empty and source products is not empty', () => {
    const blendOnForm = '';
    const sourceProductsOnForm = [
      { code: sourceProductA.code, blendPercentage: '30.00' },
      { code: sourceProductB.code, blendPercentage: '70.00' },
      { code: '', blendPercentage: '' }
    ];

    jestExpect(mandatoryFieldsAvaliable(blendOnForm, sourceProductsOnForm)).toEqual(false);
  });

  test('Should check if both blend and source products are not empty', () => {
    const blendOnForm = 'Natural';
    const sourceProductsOnForm = [
      { code: sourceProductA.code, blendPercentage: '30.00' },
      { code: sourceProductB.code, blendPercentage: '70.00' },
      { code: '', blendPercentage: '' }
    ];

    jestExpect(mandatoryFieldsAvaliable(blendOnForm, sourceProductsOnForm)).toEqual(true);
  });
});

describe('Mapping state into props', () => {
  test('should read finished cost from state', () => {
    const state = {
      grindingYieldModelInfo: {
        yieldModel: {
          finishedCost: '3.00'
        },
        blends: []
      },
      productDuplicate: {
        products: 'dependency not handled nicely'
      }
    };

    jestExpect(mapStateToProps(state).finishedCost).toBe('3.00');
  });
});
