import React from 'react';
import PricingModelCheckBox from '../PricingModelCheckBox';

describe('PricingModelCheckBox', () => {
  test('should show YES if YieldModel Is PricingModel', () => {
    const inputValue = { value: true };
    const wrapper = mount(
      <PricingModelCheckBox isYieldModelCurrentPricingModel={true} input={inputValue} />
    );

    jestExpect(wrapper.find('[pid="pricing-model-yes-label"]').at(0)).toHaveText(
      'Pricing ModelYES'
    );
  });
});
