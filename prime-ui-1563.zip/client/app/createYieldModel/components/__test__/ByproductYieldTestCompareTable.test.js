import React from 'react';
import { mount } from 'enzyme';
import { reduxForm } from 'redux-form';
import { Provider } from 'react-redux';
import { createReduxStore } from '../../../store';
import productFactory from '../../../../test-factories/productFactory';
import _ from 'lodash';
import ByproductYieldTestCompareTable from '../ByproductYieldTestCompareTable';
import yieldModelTestsFactory from '../../../../test-factories/yieldModelTests';

describe('ByproductYieldTestCompareTable', () => {
  let wrapper, Decorated, store, yieldByproducts, yieldModelTests, products;

  beforeEach(() => {
    yieldModelTests = yieldModelTestsFactory.build();
    yieldByproducts = [
      {
        byproductCode: '2111011',
        yieldPercentage: '32.00',
        cost: '5.83',
        labor: '',
        packaging: '',
        overhead: '',
        id: 313,
        createdAt: '2018-12-23T00:00:00',
        updatedAt: null
      },
      {
        byproductCode: '2536993',
        yieldPercentage: '4.00',
        cost: '5.83',
        labor: '',
        packaging: '',
        overhead: '',
        id: 312,
        createdAt: '2018-12-23T00:00:00',
        updatedAt: null
      }
    ];

    products = {
      '2111011': productFactory.build({ code: '2111011', description: 'BEEF INEDIBLE SUET' }),
      '2111148': productFactory.build({
        code: '2111148',
        description: 'BEEF STEAK T-BONE CH #1174'
      }),
      '2536993': productFactory.build({ code: '2536993', description: 'VEAL BONE' })
    };

    Decorated = reduxForm({ form: 'testForm' })(ByproductYieldTestCompareTable);

    store = createReduxStore({
      cuttingYieldModelInfo: {}
    });
  });

  describe('should render table', () => {
    test('by product record number = yield tests record number', () => {
      wrapper = mount(
        <Provider store={store}>
          <Decorated
            yieldByproducts={yieldByproducts}
            actualByproducts={yieldModelTests.actualByproducts}
            products={products}
          />
        </Provider>
      );

      const tableHeader = wrapper.find('TableHeader');
      jestExpect(tableHeader).toExist();
      jestExpect(tableHeader.find('TableHeaderCell')).toEqual(
        jestExpect.objectContaining({ length: 5 })
      );
      jestExpect(
        tableHeader
          .find('TableHeaderCell')
          .at(0)
          .text()
      ).toEqual('BYPRODUCTS');
      jestExpect(
        tableHeader
          .find('TableHeaderCell')
          .at(1)
          .text()
      ).toEqual('');
      jestExpect(
        tableHeader
          .find('TableHeaderCell')
          .at(2)
          .text()
      ).toEqual('YIELD %');
      jestExpect(
        tableHeader
          .find('TableHeaderCell')
          .at(3)
          .text()
      ).toEqual('COST');
      jestExpect(
        tableHeader
          .find('TableHeaderCell')
          .at(4)
          .text()
      ).toEqual('LABOR');

      const tableBody = wrapper.find('TableBody');
      jestExpect(tableBody.find('TableRow')).toEqual(jestExpect.objectContaining({ length: 2 }));

      const row1 = tableBody.find('TableRow').at(0);
      jestExpect(
        row1
          .find('TableCell')
          .at(0)
          .text()
      ).toEqual('2111011');
      jestExpect(
        row1
          .find('TableCell')
          .at(1)
          .text()
      ).toEqual('BEEF INEDIBLE SUET');
      jestExpect(
        row1
          .find('TableCell')
          .at(2)
          .text()
      ).toEqual('32.0030.67');
      jestExpect(
        row1
          .find('TableCell')
          .at(3)
          .text()
      ).toEqual('5.835.83');
      jestExpect(
        row1
          .find('TableCell')
          .at(4)
          .text()
      ).toEqual('0.000.92');

      const row2 = tableBody.find('TableRow').at(1);
      jestExpect(
        row2
          .find('TableCell')
          .at(0)
          .text()
      ).toEqual('2536993');
      jestExpect(
        row2
          .find('TableCell')
          .at(1)
          .text()
      ).toEqual('VEAL BONE');
      jestExpect(
        row2
          .find('TableCell')
          .at(2)
          .text()
      ).toEqual('4.003.33');
      jestExpect(
        row2
          .find('TableCell')
          .at(3)
          .text()
      ).toEqual('5.835.83');
      jestExpect(
        row2
          .find('TableCell')
          .at(4)
          .text()
      ).toEqual('0.000.94');
    });

    test('should set value in table: record# of by product > record# of yield tests ', () => {
      const additionalByProduct = {
        byproductCode: '2111148',
        yieldPercentage: '12.00',
        cost: '15.99',
        labor: '2.23',
        packaging: '',
        overhead: '',
        id: 312,
        createdAt: '2018-12-23T00:00:00',
        updatedAt: null
      };

      yieldByproducts = _.concat(yieldByproducts, additionalByProduct);

      wrapper = mount(
        <Provider store={store}>
          <Decorated
            yieldByproducts={yieldByproducts}
            actualByproducts={yieldModelTests.actualByproducts}
            products={products}
          />
        </Provider>
      );

      const tableHeader = wrapper.find('TableHeader');
      jestExpect(tableHeader).toExist();
      jestExpect(tableHeader.find('TableHeaderCell')).toEqual(
        jestExpect.objectContaining({ length: 5 })
      );
      jestExpect(
        tableHeader
          .find('TableHeaderCell')
          .at(0)
          .text()
      ).toEqual('BYPRODUCTS');
      jestExpect(
        tableHeader
          .find('TableHeaderCell')
          .at(1)
          .text()
      ).toEqual('');
      jestExpect(
        tableHeader
          .find('TableHeaderCell')
          .at(2)
          .text()
      ).toEqual('YIELD %');
      jestExpect(
        tableHeader
          .find('TableHeaderCell')
          .at(3)
          .text()
      ).toEqual('COST');
      jestExpect(
        tableHeader
          .find('TableHeaderCell')
          .at(4)
          .text()
      ).toEqual('LABOR');

      const tableBody = wrapper.find('TableBody');
      jestExpect(tableBody.find('TableRow')).toEqual(jestExpect.objectContaining({ length: 3 }));

      const row1 = tableBody.find('TableRow').at(0);
      jestExpect(
        row1
          .find('TableCell')
          .at(0)
          .text()
      ).toEqual('2111011');
      jestExpect(
        row1
          .find('TableCell')
          .at(1)
          .text()
      ).toEqual('BEEF INEDIBLE SUET');
      jestExpect(
        row1
          .find('TableCell')
          .at(2)
          .text()
      ).toEqual('32.0030.67');
      jestExpect(
        row1
          .find('TableCell')
          .at(3)
          .text()
      ).toEqual('5.835.83');
      jestExpect(
        row1
          .find('TableCell')
          .at(4)
          .text()
      ).toEqual('0.000.92');

      const row2 = tableBody.find('TableRow').at(1);
      jestExpect(
        row2
          .find('TableCell')
          .at(0)
          .text()
      ).toEqual('2111148');
      jestExpect(
        row2
          .find('TableCell')
          .at(1)
          .text()
      ).toEqual('BEEF STEAK T-BONE CH #1174');
      jestExpect(
        row2
          .find('TableCell')
          .at(2)
          .text()
      ).toEqual('12.000.00');
      jestExpect(
        row2
          .find('TableCell')
          .at(3)
          .text()
      ).toEqual('15.990.00');
      jestExpect(
        row2
          .find('TableCell')
          .at(4)
          .text()
      ).toEqual('2.230.00');

      const row3 = tableBody.find('TableRow').at(2);
      jestExpect(
        row3
          .find('TableCell')
          .at(0)
          .text()
      ).toEqual('2536993');
      jestExpect(
        row3
          .find('TableCell')
          .at(1)
          .text()
      ).toEqual('VEAL BONE');
      jestExpect(
        row3
          .find('TableCell')
          .at(2)
          .text()
      ).toEqual('4.003.33');
      jestExpect(
        row3
          .find('TableCell')
          .at(3)
          .text()
      ).toEqual('5.835.83');
      jestExpect(
        row3
          .find('TableCell')
          .at(4)
          .text()
      ).toEqual('0.000.94');
    });

    test('by product record number < yield tests record number', () => {
      yieldByproducts = _.remove(yieldByproducts, yieldByproduct => {
        return yieldByproduct.byproductCode != '2111011';
      });

      wrapper = mount(
        <Provider store={store}>
          <Decorated
            yieldByproducts={yieldByproducts}
            actualByproducts={yieldModelTests.actualByproducts}
            products={products}
          />
        </Provider>
      );

      const tableHeader = wrapper.find('TableHeader');
      jestExpect(tableHeader).toExist();
      jestExpect(tableHeader.find('TableHeaderCell')).toEqual(
        jestExpect.objectContaining({ length: 5 })
      );
      jestExpect(
        tableHeader
          .find('TableHeaderCell')
          .at(0)
          .text()
      ).toEqual('BYPRODUCTS');
      jestExpect(
        tableHeader
          .find('TableHeaderCell')
          .at(1)
          .text()
      ).toEqual('');
      jestExpect(
        tableHeader
          .find('TableHeaderCell')
          .at(2)
          .text()
      ).toEqual('YIELD %');
      jestExpect(
        tableHeader
          .find('TableHeaderCell')
          .at(3)
          .text()
      ).toEqual('COST');
      jestExpect(
        tableHeader
          .find('TableHeaderCell')
          .at(4)
          .text()
      ).toEqual('LABOR');

      const tableBody = wrapper.find('TableBody');
      jestExpect(tableBody.find('TableRow')).toHaveLength(2);

      const row1 = tableBody.find('TableRow').at(0);
      jestExpect(
        row1
          .find('TableCell')
          .at(0)
          .text()
      ).toEqual('2111011');
      jestExpect(
        row1
          .find('TableCell')
          .at(1)
          .text()
      ).toEqual('BEEF INEDIBLE SUET');
      jestExpect(
        row1
          .find('TableCell')
          .at(2)
          .text()
      ).toEqual('0.0030.67');
      jestExpect(
        row1
          .find('TableCell')
          .at(3)
          .text()
      ).toEqual('0.005.83');
      jestExpect(
        row1
          .find('TableCell')
          .at(4)
          .text()
      ).toEqual('0.000.92');

      const row2 = tableBody.find('TableRow').at(1);
      jestExpect(
        row2
          .find('TableCell')
          .at(0)
          .text()
      ).toEqual('2536993');
      jestExpect(
        row2
          .find('TableCell')
          .at(1)
          .text()
      ).toEqual('VEAL BONE');
      jestExpect(
        row2
          .find('TableCell')
          .at(2)
          .text()
      ).toEqual('4.003.33');
      jestExpect(
        row2
          .find('TableCell')
          .at(3)
          .text()
      ).toEqual('5.835.83');
      jestExpect(
        row2
          .find('TableCell')
          .at(4)
          .text()
      ).toEqual('0.000.94');
    });
  });

  test('actual model ref should show', () => {
    const comparison = wrapper.find('[pid="by-products-table-ref"]');
    jestExpect(comparison.at(0).text()).toEqual('YIELD MODELYIELD TEST AVERAGE');
  });
});
