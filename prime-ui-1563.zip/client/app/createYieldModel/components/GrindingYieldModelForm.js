import React from 'react';
import PropTypes from 'prop-types';
import _ from 'lodash';
import { change, Field, FieldArray, formValueSelector, reduxForm } from 'redux-form';
import { Button, Divider, Form, Grid, Icon } from 'semantic-ui-react';
import { getProduct } from '../../shared/components/product/actionsDuplicate';
import {
  calculateFinishedCost,
  clearGrindingYieldModel,
  createGrindingYieldModel,
  getBlends,
  yieldModelAlreadyExists
} from '../actions/grindingYieldModelActions';
import FormElement from '../../shared/FormElement';
import PricingModelCheckBox from './PricingModelCheckBox';
import Validator, {
  findGrindYieldModelErrors,
  validateSubmission
} from './grindingYieldModelFormValidator';
import SourceProductsTable from './SourceProductsTable';
import FormLabel from '../../shared/FormLabel';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import { formatNumberToTwoDecimalPlacesString } from '../../shared/util/dataUtil';
import GrindingYieldModelPricingFactors from './GrindingYieldModelPricingFactors';
import {
  PRICING_MODEL_CONFIRMATION_MESSAGE,
  UPDATING_EXISTING_YIELD_MODEL
} from '../../yieldModelProductGroup/components/yieldGroupMessages';
import { hideModal, showModal } from '../../shared/actions/actions';

export const FORM_NAME = 'grindingYieldModel';

const BLEND_LABEL = 'Blend';

export const FinishedCost = ({ finishedCost }) => {
  return (
    <FormLabel
      label='UNIT COST PER LB'
      value={formatNumberToTwoDecimalPlacesString(finishedCost)}
      width={16}
    />
  );
};
FinishedCost.propTypes = {
  finishedCost: PropTypes.string
};

export const SaveButton = ({ pristine, submitting, available }) => {
  return (
    <Button
      primary
      size={'large'}
      loading={submitting}
      disabled={submitting || pristine || !available}
    >
      <Icon className='icon-save' />
      Save
    </Button>
  );
};

SaveButton.propTypes = {
  pristine: PropTypes.bool,
  submitting: PropTypes.bool,
  available: PropTypes.bool
};

const doSubmit = (values, props) => {
  const { createGrindingYieldModel } = props;

  validateSubmission(values, props);

  return createGrindingYieldModel(values, errorResponse => {
    return Validator.processErrorResponse(errorResponse);
  });
};

class GrindingYieldModelForm extends React.Component {
  constructor(props) {
    super(props);

    this.submitWithConfirmation = this.submitWithConfirmation.bind(this);
  }

  componentDidMount() {
    const { getProduct, initialValues, calculateFinishedCost, getBlends } = this.props;

    getBlends();

    if (!_.isEmpty(initialValues.sourceProducts)) {
      initialValues.sourceProducts.forEach(sourceProduct => {
        if (!_.isEmpty(sourceProduct.code)) {
          getProduct(sourceProduct.code);
        }
      });
    }

    if (!_.isEmpty(initialValues.blend)) {
      calculateFinishedCost(initialValues);
    }
  }

  componentWillUnmount() {
    this.props.clearGrindingYieldModel();
    this.props.hideModal();
  }

  async submitWithConfirmation(values) {
    const { pricingModel } = values;
    const {
      showModal,
      changeFieldValue,
      yieldModelAlreadyExists,
      isYieldModelCurrentPricingModel
    } = this.props;

    if (!isYieldModelCurrentPricingModel && pricingModel) {
      validateSubmission(values, this.props);
      showModal({
        confirmButton: 'OK',
        content: PRICING_MODEL_CONFIRMATION_MESSAGE,
        cancelButton: 'Cancel',
        header: 'Continue with setting as pricing model?',
        confirmAction: () => Promise.resolve(doSubmit(values, this.props)),
        cancelAction: () => changeFieldValue('pricingModel', false)
      });
    } else if (!pricingModel) {
      validateSubmission(values, this.props);
      const grindingYieldModel = await yieldModelAlreadyExists(values);
      if (grindingYieldModel) {
        let newYieldModel = { ...values };
        newYieldModel.pricingModel = grindingYieldModel.pricingModel;
        showModal({
          confirmButton: 'OK',
          content: UPDATING_EXISTING_YIELD_MODEL,
          cancelButton: 'Cancel',
          header: 'Continue with saving grinding model?',
          confirmAction: () => doSubmit(newYieldModel, this.props),
          cancelAction: () => changeFieldValue('pricingModel', false)
        });
      }
      return doSubmit(values, this.props);
    } else {
      return doSubmit(values, this.props);
    }
  }

  render() {
    const {
      products,
      handleSubmit,
      isYieldModelCurrentPricingModel,
      blendsOptions,
      initialValues: { blend, existingBlend, blendDisplayName }
    } = this.props;

    return (
      <div className='create-yield-model-form'>
        <Form size='large' onSubmit={handleSubmit(this.submitWithConfirmation)}>
          <Divider hidden />
          <Grid>
            <Grid.Row>
              <Grid.Column width={11}>
                {!existingBlend ? (
                  <Field
                    component={FormElement}
                    pid='grinding-yield-model-blend-select'
                    name='blend'
                    autoFocus={true}
                    as={Form.Select}
                    type='text'
                    options={blendsOptions}
                    value={blend}
                    label={BLEND_LABEL}
                    width={11}
                  />
                ) : (
                  <FormLabel
                    name='blend'
                    pid='grinding-yield-model-blend-label'
                    label={BLEND_LABEL}
                    value={blendDisplayName}
                    width={11}
                  />
                )}
                <Divider hidden />
              </Grid.Column>

              <Grid.Column width={1} />
              <Grid.Column width={4}>
                <FinishedCost {...this.props} />
              </Grid.Column>
            </Grid.Row>
          </Grid>

          <Form.Group>
            <GrindingYieldModelPricingFactors />
            <Field
              component={PricingModelCheckBox}
              className='price-model-check'
              isYieldModelCurrentPricingModel={isYieldModelCurrentPricingModel}
              name='pricingModel'
              label='Pricing Model'
              width={3}
            />
          </Form.Group>

          <Divider hidden />

          <Form.Group>
            <FieldArray
              name={'sourceProducts'}
              component={SourceProductsTable}
              props={{ products, getProduct }}
            />
          </Form.Group>

          <Divider hidden />

          <SaveButton {...this.props} />
        </Form>
      </div>
    );
  }
}

GrindingYieldModelForm.propTypes = {
  getProduct: PropTypes.func.isRequired,
  clearGrindingYieldModel: PropTypes.func,
  calculateFinishedCost: PropTypes.func,
  createGrindingYieldModel: PropTypes.func,
  yieldModelAlreadyExists: PropTypes.func,
  getBlends: PropTypes.func.isRequired,
  isYieldModelCurrentPricingModel: PropTypes.bool,
  products: PropTypes.object.isRequired,
  handleSubmit: PropTypes.func.isRequired,
  changeFieldValue: PropTypes.func,
  finishedCost: PropTypes.string,
  finishedCode: PropTypes.string,
  submitting: PropTypes.bool,
  pristine: PropTypes.bool,
  initialValues: PropTypes.object,
  blendsOptions: PropTypes.array,
  showModal: PropTypes.func,
  hideModal: PropTypes.func,
  existingBlend: PropTypes.bool,
  blendDisplayName: PropTypes.string
};

const areSourceProductFieldsEqual = (field1, field2) => {
  const areCodesEqual = field1.code === field2.code;
  const blendPercentage1String = formatNumberToTwoDecimalPlacesString(field1.blendPercentage);
  const blendPercentage2String = formatNumberToTwoDecimalPlacesString(field2.blendPercentage);
  const areBlendPercentagesEqual = blendPercentage1String === blendPercentage2String;
  return areCodesEqual && areBlendPercentagesEqual;
};

export const areSourceProductsUnchanged = (sourceProducts1 = [], sourceProducts2 = []) => {
  if (sourceProducts1.length !== sourceProducts2.length) {
    return false;
  }

  for (let i = 0; i < sourceProducts1.length; i++) {
    if (!areSourceProductFieldsEqual(sourceProducts1[i], sourceProducts2[i])) {
      return false;
    }
  }
  return true;
};

export const mandatoryFieldsAvaliable = (blendOnForm, sourceProductsOnForm) => {
  if (!_.isEmpty(blendOnForm) && !_.isEmpty(sourceProductsOnForm)) {
    const firstSourceProduct = _.head(sourceProductsOnForm);
    if (
      !_.isEmpty(firstSourceProduct) &&
      !_.isEmpty(firstSourceProduct.code) &&
      (!_.isEmpty(firstSourceProduct.blendPercentage) || firstSourceProduct.blendPercentage > 0)
    ) {
      return true;
    }
  }
  return false;
};

const selector = formValueSelector('grindingYieldModel');
export const mapStateToProps = state => {
  const { products } = state.productDuplicate;
  const {
    yieldModel: {
      pricingModel,
      wastePercentage,
      labor,
      additives,
      blend,
      packaging,
      overhead,
      finishedCost
    },
    sourceProducts,
    blends
  } = state.grindingYieldModelInfo;
  const blendName = _.get(blend, 'name');
  const blendDisplayName = _.get(blend, 'displayName');
  const sourceProductsOnForm = selector(state, 'sourceProducts');
  const blendOnForm = selector(state, 'blend');
  const existingBlend = !_.isNil(state.grindingYieldModelInfo.yieldModel.id);

  return {
    initialValues: {
      blend: blendName,
      labor,
      additives,
      pricingModel: !!pricingModel,
      wastePercentage,
      packaging,
      overhead,
      sourceProducts,
      existingBlend,
      blendDisplayName
    },
    products,
    blendsOptions: generateBlendOptions(blends),
    finishedCost,
    available: mandatoryFieldsAvaliable(blendOnForm, sourceProductsOnForm),
    isYieldModelCurrentPricingModel:
      !!pricingModel && areSourceProductsUnchanged(sourceProducts, sourceProductsOnForm)
  };
};

const generateBlendOptions = blends => {
  return blends.map((blend, index) => {
    const { displayName, name } = blend;
    return { key: index, text: displayName, value: name };
  });
};

const mapDispatchToProps = dispatch => {
  const changeFieldValue = (field, value) => dispatch(change(FORM_NAME, field, value));
  return bindActionCreators(
    {
      calculateFinishedCost,
      changeFieldValue,
      createGrindingYieldModel,
      yieldModelAlreadyExists,
      clearGrindingYieldModel,
      getProduct,
      getBlends,
      showModal,
      hideModal
    },
    dispatch
  );
};

const getSourceProduct = (blurredField, values, props, sourceProductErrors) => {
  let value, key;
  const codeRegex = /sourceProducts\[([\w-]*)].code/;
  const blendPercentageRegex = /sourceProducts\[([\w-]*)].blendPercentage/;
  const { sourceProducts } = values;
  const { products } = props;
  const sourceProductsFiltered = _.filter(sourceProducts, sourceProduct => {
    return !_.isEmpty(sourceProduct.code);
  });

  if (blurredField.match(codeRegex)) {
    key = parseInt(blurredField.match(codeRegex)[1]);
    value = values.sourceProducts[key].code;
    sourceProductsFiltered.forEach((sourceProduct, index) => {
      if (!products[sourceProduct.code] && index != key) {
        sourceProductErrors[index] = { code: 'Invalid Item Number' };
      }
    });
  } else if (blurredField.match(blendPercentageRegex)) {
    sourceProductsFiltered.forEach((sourceProduct, index) => {
      if (!products[sourceProduct.code]) {
        sourceProductErrors[index] = { code: 'Invalid Item Number' };
      }
    });
  }
  return !_.isEmpty(value)
    ? props.getProduct(value, () => {
        sourceProductErrors[key] = { code: 'Invalid Item Number' };
      })
    : Promise.resolve();
};

const updateFinishedCost = (values, props) => {
  const { valid, errors } = findGrindYieldModelErrors(values, props, 'onBlur');

  return valid ? props.calculateFinishedCost(values, () => errors) : Promise.resolve({ ...errors });
};

const checkSourceProduct = (index, values) => {
  if (
    values.sourceProducts[index].code === '' &&
    values.sourceProducts[index].blendPercentage !== ''
  ) {
    let sourceProductErrors = Array.apply(null, { length: index + 1 }).map(() => ({}));
    sourceProductErrors[index] = { code: 'Required' };
    return sourceProductErrors;
  }
};

export const asyncValidate = (values, dispatch, props, blurredField) => {
  switch (blurredField) {
    case 'labor':
    case 'additives':
    case 'wastePercentage':
    case 'packaging':
    case 'overhead':
      return updateFinishedCost(values, props);
  }
  if (blurredField && blurredField.match('sourceProducts.*\\.code$')) {
    let sourceProductErrors = Array.apply(null, { length: values.sourceProducts.length }).map(
      () => ({})
    );
    return getSourceProduct(blurredField, values, props, sourceProductErrors).then(() => {
      return { sourceProducts: sourceProductErrors };
    });
  }
  if (blurredField && blurredField.match('sourceProducts.*\\.blendPercentage$')) {
    const regex = /sourceProducts\[([\w-]*)].blendPercentage/;
    const index = parseInt(blurredField.match(regex)[1]);
    const sourceProductErrors = checkSourceProduct(index, values);

    return getSourceProduct(blurredField, values, props, sourceProductErrors).then(() => {
      return sourceProductErrors === undefined ||
        (!!sourceProductErrors && sourceProductErrors[index].code === '')
        ? updateFinishedCost(values, props)
        : Promise.resolve({ sourceProducts: sourceProductErrors });
    });
  }
  return Promise.resolve();
};

const onSubmit = (values, dispatch, props) => {
  return doSubmit(values, props);
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(
  reduxForm({
    form: FORM_NAME,
    enableReinitialize: true,
    asyncValidate,
    onSubmit,
    asyncBlurFields: [
      'labor',
      'additives',
      'wastePercentage',
      'packaging',
      'overhead',
      'sourceProducts[].code',
      'sourceProducts[].blendPercentage'
    ]
  })(GrindingYieldModelForm)
);
