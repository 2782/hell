import React from 'react';
import * as _ from 'lodash';
import { Table, Divider } from 'semantic-ui-react';
import PropTypes from 'prop-types';
import { formatNumberToTwoDecimalPlacesString } from '../../shared/util/dataUtil';

const mergeActualYieldTestsWithYieldModel = (yieldByproducts, actualByproducts, products) => {
  const actualByproductsClone = _.cloneDeep(actualByproducts);

  let mergedActualYieldTests = [];
  _.each(yieldByproducts, yieldByproduct => {
    if (_.size(yieldByproduct) > 0) {
      // Ignore the case: yieldByproduct == {}
      let mergedActualYieldTest = _.find(actualByproductsClone, actualByproduct => {
        return yieldByproduct.byproductCode === actualByproduct.byProductCode;
      });
      if (!_.isUndefined(mergedActualYieldTest)) {
        mergedActualYieldTest = {
          ...mergedActualYieldTest,
          modelYieldPercentage: yieldByproduct.yieldPercentage,
          modelCost: yieldByproduct.cost,
          modelLabor: yieldByproduct.labor
        };
        mergedActualYieldTests = _.concat(mergedActualYieldTests, mergedActualYieldTest);
      } else {
        if (!_.isEmpty(_.get(products, yieldByproduct.byproductCode))) {
          mergedActualYieldTest = {
            byProductCode: yieldByproduct.byproductCode,
            byProductDescription: _.get(products, yieldByproduct.byproductCode).description,
            modelYieldPercentage: yieldByproduct.yieldPercentage,
            modelCost: yieldByproduct.cost,
            modelLabor: yieldByproduct.labor
          };
          mergedActualYieldTests = _.concat(mergedActualYieldTests, mergedActualYieldTest);
        }
      }
    }
  });

  // The products only in actual tests not in yield model.
  _.each(actualByproductsClone, actualByproduct => {
    let mergedActualYieldTest = _.find(mergedActualYieldTests, yieldTest => {
      return actualByproduct.byProductCode === yieldTest.byProductCode;
    });
    if (_.isEmpty(mergedActualYieldTest)) {
      mergedActualYieldTests = _.concat(mergedActualYieldTests, actualByproduct);
    }
  });

  return mergedActualYieldTests;
};

const getFieldValue = (byProduct, field) => {
  const value = _.toNumber(_.get(byProduct, field, 0));
  return _.eq(value, 0) ? '0.00' : formatNumberToTwoDecimalPlacesString(value);
};

const ByproductYieldTestCompareTable = props => {
  const { yieldByproducts, actualByproducts, products } = props;
  const mergeActualYieldTests = mergeActualYieldTestsWithYieldModel(
    yieldByproducts,
    actualByproducts,
    products
  );

  return (
    <div>
      <Divider hidden />
      <Table columns={10} fixed pid='yield-test-byproduct-table'>
        <Table.Header>
          <Table.Row>
            <Table.HeaderCell textAlign='left' colSpan={2} width={2}>
              BYPRODUCTS
            </Table.HeaderCell>
            <Table.HeaderCell colSpan={5} width={5} />
            <Table.HeaderCell textAlign='right' colSpan={1} width={1}>
              YIELD %
            </Table.HeaderCell>
            <Table.HeaderCell textAlign='right' colSpan={1} width={1}>
              COST
            </Table.HeaderCell>
            <Table.HeaderCell textAlign='right' colSpan={1} width={1}>
              LABOR
            </Table.HeaderCell>
          </Table.Row>
        </Table.Header>
        <Table.Body key={'yield-test-byproduct-table-content'}>
          {_.map(
            _.sortBy(_.toArray(mergeActualYieldTests), ['byProductCode']),
            (byProduct, itemIndex) => {
              return (
                <Table.Row
                  className='yield-test-by-products'
                  pid={`yield-test-byproduct-table-row-${itemIndex}`}
                  key={`yield-test-byproduct-table-row-${itemIndex}`}
                >
                  <Table.Cell
                    textAlign='left'
                    colSpan={2}
                    width={2}
                    pid={`yield-test-byproduct-table-row-${itemIndex}-byProductCode`}
                  >
                    {byProduct.byProductCode}
                  </Table.Cell>
                  <Table.Cell
                    textAlign='left'
                    colSpan={5}
                    width={5}
                    pid={`yield-test-byproduct-table-row-${itemIndex}-byProductDescription`}
                  >
                    {byProduct.byProductDescription}
                  </Table.Cell>
                  <Table.Cell
                    className='two-line-td'
                    colSpan={1}
                    width={1}
                    pid={`yield-test-byproduct-table-row-${itemIndex}-yieldPercentage`}
                  >
                    <div className='model-value'>
                      {getFieldValue(byProduct, 'modelYieldPercentage')}
                    </div>
                    <Divider fitted={true} />
                    <div>{getFieldValue(byProduct, 'actualYieldPercentage')}</div>
                  </Table.Cell>
                  <Table.Cell
                    className='two-line-td'
                    colSpan={1}
                    width={1}
                    pid={`yield-test-byproduct-table-row-${itemIndex}-cost`}
                  >
                    <div className='model-value'>{getFieldValue(byProduct, 'modelCost')}</div>
                    <Divider fitted={true} />
                    <div>{getFieldValue(byProduct, 'actualCost')}</div>
                  </Table.Cell>
                  <Table.Cell
                    className='two-line-td'
                    colSpan={1}
                    width={1}
                    pid={`yield-test-byproduct-table-row-${itemIndex}-labor`}
                  >
                    <div className='model-value'>{getFieldValue(byProduct, 'modelLabor')}</div>
                    <Divider fitted={true} />
                    <div>{getFieldValue(byProduct, 'actualLabor')}</div>
                  </Table.Cell>
                </Table.Row>
              );
            }
          )}
        </Table.Body>
      </Table>
      <div className='by-products-table-ref' pid='by-products-table-ref'>
        <div className='model-value'>YIELD MODEL</div>
        <Divider fitted={true} />
        <div>YIELD TEST AVERAGE</div>
      </div>
    </div>
  );
};

ByproductYieldTestCompareTable.propTypes = {
  yieldByproducts: PropTypes.array,
  actualByproducts: PropTypes.array,
  products: PropTypes.object
};

export default ByproductYieldTestCompareTable;
