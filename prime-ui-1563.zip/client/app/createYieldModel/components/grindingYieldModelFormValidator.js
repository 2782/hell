import { required, validate } from '../../shared/formValidations';
import { SubmissionError } from 'redux-form';
import _ from 'lodash';
import { CREATE_YIELD_MODEL_REQUEST_MESSAGE } from '../../../config/errorMessage';

const constructCountMap = sourceProducts => {
  return sourceProducts.reduce((map, { code }) => {
    if (map.hasOwnProperty(code)) {
      return Object.assign({}, map, { [code]: map[code] + 1 });
    } else {
      return Object.assign({}, map, { [code]: 1 });
    }
  }, {});
};

const checkDuplicateSourceProducts = countMap => (value, fieldName) => {
  if (countMap[value] > 1) {
    return { [fieldName]: 'Source is already listed' };
  }
};

const checkCost = products => (value, fieldName) => {
  if (!_.isEmpty(value)) {
    const product = products[value];
    if (product && !product.cost) {
      return { [fieldName]: 'Item does not have a cost' };
    }
  }
};

export const findGrindYieldModelErrors = (values, props, triggeredAction) => {
  const { blend, pricingModel } = values;
  let errors = {};

  errors = validate(errors, pricingModel, 'pricingModel', [required]);
  errors = validate(errors, blend, 'blend', [required]);

  errors = validateFieldArray(errors, values.sourceProducts, props, triggeredAction);
  const valid = !checkForErrors(errors);

  return {
    valid,
    errors
  };
};

export const validateSubmission = (values, props) => {
  const { valid, errors } = findGrindYieldModelErrors(values, props, 'onSubmit');

  if (!valid) {
    throw new SubmissionError({ ...errors, _error: 'Submission Failed!' });
  }
};

const checkForErrors = ({ sourceProducts, ...errors }) => {
  const errorExists = !_.isEmpty(errors);
  const sourceProductCodeErrorExists = !!sourceProducts.find(member => !_.isEmpty(member));
  const blendPercentageNot100PercentError = !_.isEmpty(sourceProducts._error);
  return errorExists || sourceProductCodeErrorExists || blendPercentageNot100PercentError;
};

const positionBlendPercentageErrorOnLastFilledInRow = sourceProducts => {
  let lastFilledIn = -1;
  sourceProducts.forEach((row, index) => {
    if (!_.isEmpty(row.blendPercentage)) {
      lastFilledIn = index;
    }
  });
  const lastErrorRow = [];
  for (let i = 0; i < lastFilledIn; ++i) {
    lastErrorRow.push({});
  }
  lastErrorRow.push({ blendPercentage: 'Source blend % is invalid' });
  return lastErrorRow;
};

function sourceProductsBlendPercentageEqualsHundred(
  sourceProductsFiltered,
  errors,
  sourceProducts
) {
  const totalBlendPercent = _.sumBy(
    sourceProductsFiltered,
    ({ blendPercentage }) => parseFloat(blendPercentage) || 0
  );
  if (totalBlendPercent !== 100) {
    errors = {
      ...errors,
      sourceProducts: positionBlendPercentageErrorOnLastFilledInRow(sourceProducts)
    };
  }
  return errors;
}

export const validateFieldArray = (errors, sourceProducts, props, triggeredAction) => {
  const { products } = props;
  const sourceProductsFiltered = _.filter(sourceProducts, sourceProduct => {
    return !_.isEmpty(sourceProduct.code) || !_.isEmpty(sourceProduct.blendPercentage);
  });

  if (sourceProductsFiltered.length === 0 && triggeredAction === 'onSubmit') {
    return { ...errors, sourceProducts: [{ code: 'Required', blendPercentage: 'Required' }] };
  }

  const countMap = constructCountMap(sourceProductsFiltered);
  let sourceProductsArrayErrors = [];
  sourceProductsFiltered.forEach(({ code, blendPercentage }) => {
    let sourceProductError = {};

    sourceProductError = validate(sourceProductError, code, 'code', [
      required,
      checkDuplicateSourceProducts(countMap),
      checkCost(products)
    ]);
    sourceProductError = validate(sourceProductError, blendPercentage, 'blendPercentage', [
      required
    ]);

    sourceProductsArrayErrors = sourceProductsArrayErrors.concat(sourceProductError);
  });

  errors = { ...errors, sourceProducts: sourceProductsArrayErrors };

  // Honor missing required field complaints before checking of the total == 100%
  if (_.filter(sourceProductsArrayErrors, row => !_.isEmpty(row)).length > 0) {
    return errors;
  }

  if (triggeredAction === 'onSubmit') {
    errors = sourceProductsBlendPercentageEqualsHundred(
      sourceProductsFiltered,
      errors,
      sourceProducts
    );
  }

  return errors;
};

const processErrorResponse = errorResponse => {
  const errorDetails = _.get(errorResponse, 'error.details', []);
  let errors = {};

  const errorDetailsForGrindingYieldModel = errorDetails.find(
    detail => !_.isEmpty(detail.field) === true
  );
  const issue = errorDetailsForGrindingYieldModel ? errorDetailsForGrindingYieldModel.issue : '';

  switch (issue) {
    case 'UNIQUE':
      errors = { blend: 'Model already exists', ...errors };
      break;
    case 'NOT_EXIST':
      errors = { blend: 'Invalid Blend Name', ...errors };
      break;
    default:
      errors = { _error: CREATE_YIELD_MODEL_REQUEST_MESSAGE, ...errors };
      break;
  }

  if (!_.isEmpty(errors)) {
    throw new SubmissionError({ _error: 'Submission Failed!', ...errors });
  }
};

export default {
  validateSubmission,
  processErrorResponse
};
