#!/usr/bin/env bash

set -e
PROJECT_HOME=$(cd `dirname $0`/ && pwd)

VERSION_NUMBER=${1:?"Please specify your version number"}

rm -rf dist-syscodev

npm run build:web:syscodev

mkdir -p ${PROJECT_HOME}/tmp

cp -r dist-syscodev ${PROJECT_HOME}/tmp/app
cp docker/nginx-app/* ${PROJECT_HOME}/tmp/

IMAGE_NAME="sysco/prime-ui:syscodev-0.1.0-${VERSION_NUMBER}-alb-test"

cd ${PROJECT_HOME}/tmp

docker build --rm --tag ${IMAGE_NAME} .

docker push ${IMAGE_NAME}

cd ${PROJECT_HOME}

rm -rf tmp/