# API Test for Prime-API

## Getting Started

### Folder Structure
1. /collections stores all collections for single api testing (grouped by controller) and e2e api testing.
2. /environments stores all environments for api testing.
    1) local.json for dev local
    2) syscodev.json for Sysco Dev environment
    3) syscoqa.json for Sysco QA environment
3. run_api_testing.sh will run the collection one by one in /collections folder. You could pass 3 parameters.
    1) ```run_api_testing local``` to run the test on local environment
    1) ```run_api_testing syscodev``` to run the test on Sysco Dev
    1) ```run_api_testing syscoqa``` to run the test on Sysco QA

### Running the tests

if you run postgresql in docker container, then add docker in you command

1. ```npm install``` to install dependencies.
2. Reset data by ```test_data reset```
3. Run the test locally
```
dev-local-run-api-tests
```





### Something more
prime-api api test was written with Postman and run it via Newman runner.
