#!/usr/bin/env bash

set -e
set -o pipefail

printf -v preset "\e[0m"
printf -v pbold "\e[1m"
printf -v pred "\e[31m"

print-usage() {
    echo "Usage: $0 [-hq] <ENVIRONMENT>"
}

print-help() {
    print-usage
    cat <<EOH

Options:
   -h   Print help and exit
   -q   Quiet output (only show errors)
   -H   Write single HTML report for all collections

Environments:
   local      Local development environment
   syscodev   CI development environment
   syscoqa    CI qa/showcase environment

Exit codes:
   0   All collections passed
   N   N collections failed; outputs copied in the current directory
EOH
}

tmpdir=${TMPDIR-/tmp}/${0##*/}.$$.tmp
trap 'rm -rf $tmpdir' EXIT
mkdir $tmpdir

declare -a failed_collections
quiet=false
run-collection() {
    environment=$1
    collection=$2

    # Turn ./collection/a/b/c.json into /tmp/a-b-c
    tmp=${collection#./collections/}
    tmp=${tmp//\//-}
    tmp=${tmp%.json}
    tmp=$tmpdir/$tmp

    if ! newman run $collection -e $environment $color >$tmp
    then
        failed_collections=("${failed_collections[@]}" $collection)
        echo "$0: ${pbold}newman run $collection -e $environment${preset}" >&2
        cat $tmp >&2
    elif ! $quiet
    then
        echo "$0: ${pbold}newman run $collection -e $environment${preset}"
        cat $tmp
    fi
}

run-all-collections-and-html-report() {
    environment=$1
    html_report=$2
    combined=$tmpdir/all-api-tests.json

    postman-combine-collections -f 'collections/**/*.json' -o $combined
    newman run $combined -e $environment --reporters html,cli,junit \
        --reporter-html-export $html_report \
        || failed_collections=(all-collections)
}

html=false
while getopts :hqH opt
do
    case $opt in
    h ) print-help ; exit 0 ;;
    q ) quiet=true ;;
    H ) html=true ;;
    * ) print-usage >&2 ; exit 2 ;;
    esac
done
shift $((OPTIND - 1))

case $# in
1 ) environment="$1" ;;
* ) print-usage >&2 ; exit 2 ;;
esac

if ! [[ -e ./environments/$environment.json ]]
then
    echo "$0: No environment found: $environment" >&2
    exit 2
fi
environment=./environments/$environment.json

# Do not assume newman installed globally
export PATH=./node_modules/.bin:"$PATH"

case $(newman --version) in
4* ) color='--color on' ;;
3* ) color='--color' ;;
* ) echo "$0: Please run npm install in the api-test directory" >&2 ; exit 2 ;;
esac

if $html
then
    run-all-collections-and-html-report $environment all-api-tests-report.html
else
    for collection in ./collections/**/*.json
    do
        run-collection $environment $collection
    done
fi

case ${#failed_collections[@]} in
0 ) ! $quiet && echo "$0: ${pbold}All collections passed${preset}" ;;
* ) echo "$0: See above: ${pred}${#failed_collections[@]} collections failed: ${failed_collections[@]}${preset}" >&2
esac

exit ${#failed_collections[@]}
