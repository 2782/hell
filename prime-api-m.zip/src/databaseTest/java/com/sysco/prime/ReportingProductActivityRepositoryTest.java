package com.sysco.prime;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sysco.prime.DummyObjectFactory.RoomStationTable;
import com.sysco.prime.cost.Money;
import com.sysco.prime.portionRoom.PortionRoom;
import com.sysco.prime.portionRoom.PortionRoomRepository;
import com.sysco.prime.product.Product;
import com.sysco.prime.product.ProductCategory;
import com.sysco.prime.reporting.model.ReportingBox;
import com.sysco.prime.reporting.model.ReportingBox.ReportingBoxBuilder;
import com.sysco.prime.reporting.model.ReportingEvent;
import com.sysco.prime.reporting.model.ReportingEvent.ReportingEventBuilder;
import com.sysco.prime.reporting.model.ReportingProductActivity;
import com.sysco.prime.reporting.model.ReportingReturnBox;
import com.sysco.prime.reporting.model.ReportingReturnBox.ReportingReturnBoxBuilder;
import com.sysco.prime.reporting.repository.ReportingProductActivityRepository;
import com.sysco.prime.sourceMeat.PublishingSourceMeatOrder;
import com.sysco.prime.sourceMeat.PublishingSourceMeatReceipt;
import com.sysco.prime.sourceMeat.PublishingSourceMeatReceiptItem;
import com.sysco.prime.sourceMeat.PublishingSourceMeatWip;
import com.sysco.prime.sourceMeat.PublishingSourceMeatWipReceipt;
import com.sysco.prime.sourceMeat.SourceMeatOrder;
import com.sysco.prime.sourceMeat.SourceMeatReceipt;
import com.sysco.prime.station.Station;
import com.sysco.prime.station.StationRepository;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.json.JsonTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.OffsetDateTime;

import static com.sysco.prime.DummyObjectFactory.buildPublishingSourceMeatWip;
import static com.sysco.prime.DummyObjectFactory.buildRoomStationTable;
import static com.sysco.prime.DummyObjectFactory.portionRoomBuilder;
import static com.sysco.prime.DummyObjectFactory.productBuilder;
import static com.sysco.prime.DummyObjectFactory.publishingSourceMeatReceiptItemBuilder;
import static com.sysco.prime.DummyObjectFactory.publishingSourceMeatWipReceiptBuilder;
import static com.sysco.prime.DummyObjectFactory.sourceMeatOrderBuilder;
import static com.sysco.prime.DummyObjectFactory.sourceMeatReceiptBuilder;
import static com.sysco.prime.DummyObjectFactory.stationBuilder;
import static com.sysco.prime.reporting.model.ReportingBox.Status.ASSIGNED;
import static com.sysco.prime.reporting.model.ReportingBox.Status.AVAILABLE;
import static com.sysco.prime.utils.TimeUtils.toOffsetDateTime;
import static com.sysco.prime.utils.TimeUtilsTest.offsetDateTime;
import static java.math.BigDecimal.ONE;
import static java.util.Arrays.asList;
import static java.util.Collections.singletonList;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace.NONE;

@ActiveProfiles("test")
@AutoConfigureTestDatabase(replace = NONE)
@DataJpaTest
@RunWith(SpringRunner.class)
@JsonTest
public class ReportingProductActivityRepositoryTest {
    @Autowired
    private ReportingProductActivityRepository repository;
    @Autowired
    private StationRepository stations;
    @Autowired
    private PortionRoomRepository room;
    @Autowired
    private TestEntityManager entityManager;
    @Autowired
    private ObjectMapper objectMapper;

    @Test
    public void shouldFindAggregatedRows() {
        final LocalDate today = LocalDate.of(2018, 12, 17);
        final LocalDateTime customerTimestamp = LocalDateTime.of(
                today,
                LocalTime.of(10, 11, 12));
        final LocalDateTime finishedStockTimestamp = customerTimestamp.plusMinutes(5);
        final LocalDateTime finishedWipTimestamp = finishedStockTimestamp.plusMinutes(5);
        final LocalDateTime sourceWipTimestamp = finishedWipTimestamp.plusMinutes(5);

        final RoomStationTable location = buildRoomStationTable(entityManager);

        final ReportingBox customerBoxA = save(ReportingBox.builder()
                        .netWeight(6.78)
                        .customerCode("SECRET")
                        .customerName("Bob the Builder")
                        .customerOrderNumber("ABCDEFG")
                        .weightPerBox(1.23)
                        .packageTareWeight(0.739)
                        .incomplete(false)
                        .isFixWeightProduct(true)
                        .laborCost(2.34)
                        .packoffStationName("Over there")
                        .portionRoomCode("A")
                        .principal("Mr. Mackey")
                        .productCode("1010101")
                        .productDescription("I AM A FINISHED PRODUCT")
                        .replacementCost(5.67)
                        .shipDate(today.plusDays(1))
                        .sourceProductCode("0101010")
                        .stationCode(location.station.getStationCode())
                        .status(ASSIGNED)
                        .tableCode(location.table.getTableCode())
                        .tableDescription(location.table.getTableDescription())
                        .workingDate(today)
                        .yieldPercentage(99),
                customerTimestamp);

        final ReportingBox customerBoxB = save(customerBoxA.toBuilder()
                        .netWeight(customerBoxA.getNetWeight() + 1),
                customerTimestamp);

        final ReportingBox finishedStockBoxA = save(customerBoxB.toBuilder()
                        .netWeight(customerBoxB.getNetWeight() + 1)
                        .customerCode(null)
                        .customerName(null)
                        .customerOrderNumber(null)
                        .incomplete(false)
                        .status(AVAILABLE),
                finishedStockTimestamp);

        final ReportingBox finishedStockBoxB = save(finishedStockBoxA.toBuilder()
                        .netWeight(finishedStockBoxA.getNetWeight() + 1),
                finishedStockTimestamp);

        final ReportingBox finishedWipBoxA = save(finishedStockBoxB.toBuilder()
                        .netWeight(finishedStockBoxB.getNetWeight() + 1)
                        .incomplete(true),
                finishedWipTimestamp);

        final ReportingBox finishedWipBoxB = save(finishedWipBoxA.toBuilder()
                        .netWeight(finishedWipBoxA.getNetWeight() + 1),
                finishedWipTimestamp);

        final ReportingReturnBox sourceWipBoxA = save(ReportingReturnBox.builder()
                        .netWeight(BigDecimal.valueOf(finishedWipBoxB.getNetWeight() + 1))
                        .isFixWeightProduct(true)
                        .packageTareWeight(BigDecimal.valueOf(0.739))
                        .marketCost(Money.of(17.89))
                        .packoffStationName(finishedWipBoxB.getPackoffStationName())
                        .portionRoomCode(finishedWipBoxB.getPortionRoomCode())
                        .productCode(finishedWipBoxB.getSourceProductCode())
                        .productDescription("I AM A SOURCE PRODUCT")
                        .weightedAverageCost(Money.of(22.22))
                        .workingDate(today),
                sourceWipTimestamp);
        final ReportingReturnBox sourceWipBoxB = save(sourceWipBoxA.toBuilder()
                        .netWeight(sourceWipBoxA.getNetWeight().add(ONE)),
                sourceWipTimestamp);

        final int pageSize = 4;
        final Page<ReportingProductActivity> found = repository.findAll(PageRequest.of(0, pageSize));

        assertThat(found.getContent(), is(asList(
                ReportingProductActivity.builder()
                        .customerCode(null)
                        .customerName("WIP")
                        .customerOrderNumber(null)
                        .incomplete(true)
                        .key("returnbox-" + sourceWipBoxA.getId())
                        .packoffStationName(sourceWipBoxA.getPackoffStationName())
                        .productCode(sourceWipBoxA.getProductCode())
                        .quantity(2)
                        .roomCode(sourceWipBoxA.getPortionRoomCode())
                        .shipDate(null)
                        .stationCode(null)
                        .stationName(null)
                        .tableCode(null)
                        .tableName(null)
                        .timestamp(toOffsetDateTime(sourceWipBoxA.getCreatedAt()))
                        .type("ReturnBox")
                        .uom("CASE")
                        .weight(sourceWipBoxA.getNetWeight()
                                .add(sourceWipBoxB.getNetWeight()))
                        .workingDate(sourceWipBoxA.getWorkingDate())
                        .build(),
                ReportingProductActivity.builder()
                        .customerCode(null)
                        .customerName("WIP")
                        .customerOrderNumber(null)
                        .incomplete(finishedWipBoxA.isIncomplete())
                        .key("box-" + finishedWipBoxA.getId())
                        .packoffStationName(finishedWipBoxA.getPackoffStationName())
                        .productCode(finishedWipBoxA.getProductCode())
                        .quantity(2)
                        .roomCode(finishedWipBoxA.getPortionRoomCode())
                        .shipDate(null)
                        .stationCode(null)
                        .stationName(null)
                        .tableCode(null)
                        .tableName(null)
                        .timestamp(toOffsetDateTime(finishedWipBoxA.getCreatedAt()))
                        .type("Box")
                        .uom("CASE")
                        .weight(BigDecimal.valueOf(finishedWipBoxA.getNetWeight())
                                .add(BigDecimal.valueOf(finishedWipBoxB.getNetWeight())))
                        .workingDate(finishedWipBoxA.getWorkingDate())
                        .build(),
                ReportingProductActivity.builder()
                        .customerCode(null)
                        .customerName("Stock")
                        .customerOrderNumber(null)
                        .incomplete(finishedStockBoxA.isIncomplete())
                        .key("box-" + finishedStockBoxA.getId())
                        .packoffStationName(finishedStockBoxA.getPackoffStationName())
                        .productCode(finishedStockBoxA.getProductCode())
                        .quantity(2)
                        .roomCode(finishedStockBoxA.getPortionRoomCode())
                        .shipDate(null)
                        .stationCode(null)
                        .stationName(null)
                        .tableCode(null)
                        .tableName(null)
                        .timestamp(toOffsetDateTime(finishedStockBoxA.getCreatedAt()))
                        .type("Box")
                        .uom("CASE")
                        .weight(BigDecimal.valueOf(finishedStockBoxA.getNetWeight())
                                .add(BigDecimal.valueOf(finishedStockBoxB.getNetWeight())))
                        .workingDate(finishedStockBoxA.getWorkingDate())
                        .build(),
                ReportingProductActivity.builder()
                        .customerCode(customerBoxA.getCustomerCode())
                        .customerName(customerBoxA.getCustomerName())
                        .customerOrderNumber(customerBoxA.getCustomerOrderNumber())
                        .incomplete(customerBoxA.isIncomplete())
                        .key("box-" + customerBoxA.getId())
                        .packoffStationName(customerBoxA.getPackoffStationName())
                        .productCode(customerBoxA.getProductCode())
                        .quantity(2)
                        .roomCode(customerBoxA.getPortionRoomCode())
                        .shipDate(customerBoxA.getShipDate())
                        .stationCode(customerBoxA.getStationCode())
                        .stationName(location.station.getName())
                        .tableCode(customerBoxA.getTableCode())
                        .tableName(customerBoxA.getTableDescription())
                        .timestamp(toOffsetDateTime(customerBoxA.getCreatedAt()))
                        .type("Box")
                        .uom("CASE")
                        .weight(BigDecimal.valueOf(customerBoxA.getNetWeight())
                                .add(BigDecimal.valueOf(customerBoxB.getNetWeight())))
                        .workingDate(customerBoxA.getWorkingDate())
                        .build())));
    }

    @Test
    public void shouldGetSourceMeatReceiptEventForCatchWeight() {
        final PortionRoom roomA = room.save(portionRoomBuilder().build());
        final Station station = stations.save(stationBuilder().room(roomA).build());

        final LocalDate today = LocalDate.of(2018, 12, 17);
        final LocalDateTime customerTimestamp = LocalDateTime.of(
                today, LocalTime.of(10, 11, 12));

        final Product catchProduct = productBuilder()
                .category(ProductCategory.CATCH)
                .build();

        final SourceMeatReceipt receipt = sourceMeatReceiptBuilder().build();
        final SourceMeatOrder order = sourceMeatOrderBuilder()
                .roomCode(roomA.getCode())
                .quantity(13)
                .stationId(station.getId())
                .productCode(catchProduct.getCode())
                .workingDate(today)
                .build();
        final PublishingSourceMeatReceiptItem catchWeight = publishingSourceMeatReceiptItemBuilder()
                .currentQty(7)
                .catchWeightIndicator("Y")
                .itemNumber(catchProduct.getCode())
                .build();

        final PublishingSourceMeatReceipt sourceMeatOrderReceipt = receipt
                .toReporting(order, catchWeight, station);
        final OffsetDateTime timestamp = offsetDateTime(2011, 2, 3, 4, 5, 0, 0);
        final ReportingEventBuilder receiptEvent = ReportingEvent.builder()
                .type("SourceMeatReceipt")
                .timestamp(timestamp)
                .principal("user-1")
                .productCode(catchProduct.getCode())
                .data(sourceMeatOrderReceipt.asMap(objectMapper));
        final ReportingEvent savedEvent = save(receiptEvent, customerTimestamp);

        final Page<ReportingProductActivity> found =
                repository.findAll(PageRequest.of(0, 5));

        assertThat(found.getContent(), is(singletonList(
                ReportingProductActivity.builder()
                        .customerCode(null)
                        .customerName(null)
                        .customerOrderNumber(null)
                        .incomplete(null)
                        .key("event-" + savedEvent.getId())
                        .packoffStationName(null)
                        .productCode(catchProduct.getCode())
                        .quantity(catchWeight.getCurrentQty())
                        .roomCode(order.getRoomCode())
                        .shipDate(null)
                        .stationCode(station.getStationCode())
                        .stationName(station.getName())
                        .tableCode(null)
                        .tableName(null)
                        .timestamp(timestamp)
                        .type("SourceMeatReceipt")
                        .uom("CASE")
                        .weight(BigDecimal.valueOf(catchWeight.getCurrentTotalCatchWeight()))
                        .workingDate(order.getWorkingDate())
                        .build()
        )));
    }

    @Test
    public void shouldGetSourceMeatReceiptEventForFixedWeight() {
        final PortionRoom roomA = room.save(portionRoomBuilder().build());
        final Station station = stations.save(stationBuilder().room(roomA).build());

        final LocalDate today = LocalDate.of(2018, 12, 17);
        final LocalDateTime customerTimestamp = LocalDateTime.of(
                today, LocalTime.of(10, 11, 12));

        final Product fixedProduct = productBuilder()
                .category(ProductCategory.FIXED)
                .code("7203474").build();

        final SourceMeatReceipt receipt = sourceMeatReceiptBuilder().build();
        final SourceMeatOrder order = sourceMeatOrderBuilder()
                .roomCode(roomA.getCode())
                .quantity(13)
                .stationId(station.getId())
                .productCode(fixedProduct.getCode())
                .workingDate(today)
                .build();
        final PublishingSourceMeatReceiptItem fixed = publishingSourceMeatReceiptItemBuilder()
                .currentQty(6)
                .catchWeightIndicator("N")
                .itemNumber(fixedProduct.getCode())
                .build();

        final PublishingSourceMeatReceipt sourceMeatOrderReceipt = receipt
                .toReporting(order, fixed, station);
        final OffsetDateTime timestamp = offsetDateTime(2011, 2, 3, 4, 5, 0, 0);
        final ReportingEventBuilder receiptEvent = ReportingEvent.builder()
                .type("SourceMeatReceipt")
                .timestamp(timestamp)
                .principal("user-1")
                .productCode(fixedProduct.getCode())
                .data(sourceMeatOrderReceipt.asMap(objectMapper));
        final ReportingEvent savedEvent = save(receiptEvent, customerTimestamp);

        final Page<ReportingProductActivity> found =
                repository.findAll(PageRequest.of(0, 5));

        assertThat(found.getContent(), is(singletonList(
                ReportingProductActivity.builder()
                        .customerCode(null)
                        .customerName(null)
                        .customerOrderNumber(null)
                        .incomplete(null)
                        .key("event-" + savedEvent.getId())
                        .packoffStationName(null)
                        .productCode(fixedProduct.getCode())
                        .quantity(fixed.getCurrentQty())
                        .roomCode(order.getRoomCode())
                        .shipDate(null)
                        .stationCode(station.getStationCode())
                        .stationName(station.getName())
                        .tableCode(null)
                        .tableName(null)
                        .timestamp(timestamp)
                        .type("SourceMeatReceipt")
                        .uom("CASE")
                        .weight(BigDecimal.valueOf(fixed.getCurrentQty() * fixed.getFixedWeightPerBox()))
                        .workingDate(order.getWorkingDate())
                        .build()
        )));
    }

    @Test
    public void shouldGetSourceMeatOrderEvent() {
        final PortionRoom roomA = room.save(portionRoomBuilder()
                .code("A")
                .build());
        final Station station = stations.save(stationBuilder()
                .room(roomA)
                .build());

        final LocalDate today = LocalDate.of(2018, 12, 17);
        final LocalDateTime customerTimestamp = LocalDateTime.of(
                today, LocalTime.of(10, 11, 12));
        final Product sourceProduct = productBuilder().build();
        final SourceMeatOrder order = sourceMeatOrderBuilder()
                .roomCode("A")
                .stationId(station.getId())
                .productCode(sourceProduct.getCode())
                .workingDate(today)
                .build();

        final PublishingSourceMeatOrder sourceMeatOrder = order
                .toReporting(sourceProduct, station.getStationCode());
        final OffsetDateTime timestamp = offsetDateTime(2011, 2, 3, 4, 5, 0, 0);
        final ReportingEventBuilder sourceMeatEvent = ReportingEvent.builder()
                .type("SourceMeatOrder")
                .timestamp(timestamp)
                .principal("user-1")
                .productCode(sourceProduct.getCode())
                .data(sourceMeatOrder.asMap(objectMapper));
        final ReportingEvent savedEvent = save(sourceMeatEvent, customerTimestamp);

        final Page<ReportingProductActivity> found =
                repository.findAll(PageRequest.of(0, 5));

        assertThat(found.getContent(), is(singletonList(
                ReportingProductActivity.builder()
                        .customerCode(null)
                        .customerName(null)
                        .customerOrderNumber(null)
                        .incomplete(null)
                        .key("event-" + savedEvent.getId())
                        .packoffStationName(null)
                        .productCode(sourceProduct.getCode())
                        .quantity(order.getQuantity())
                        .roomCode(order.getRoomCode())
                        .shipDate(null)
                        .stationCode(station.getStationCode())
                        .stationName(station.getName())
                        .tableCode(null)
                        .tableName(null)
                        .timestamp(timestamp)
                        .type("SourceMeatOrder")
                        .uom("CASE")
                        .weight(null)
                        .workingDate(order.getWorkingDate())
                        .build()
        )));
    }

    @Test
    public void shouldGetSourceMeatWipEvent() {
        final LocalDate today = LocalDate.of(2018, 12, 17);
        final LocalDateTime customerTimestamp = LocalDateTime.of(
                today, LocalTime.of(10, 11, 12));
        final Product sourceProduct = productBuilder().build();

        final PublishingSourceMeatWip sourceMeatWip = buildPublishingSourceMeatWip();
        final OffsetDateTime timestamp = offsetDateTime(2011, 2, 3, 4, 5, 0, 0);
        final ReportingEventBuilder sourceMeatEvent = ReportingEvent.builder()
                .type("SourceMeatWip")
                .timestamp(timestamp)
                .principal("user-1")
                .productCode(sourceProduct.getCode())
                .data(sourceMeatWip.asMap(objectMapper));
        final ReportingEvent savedEvent = save(sourceMeatEvent, customerTimestamp);

        final Page<ReportingProductActivity> found =
                repository.findAll(PageRequest.of(0, 5));

        assertThat(found.getContent(), is(singletonList(
                ReportingProductActivity.builder()
                        .customerCode(null)
                        .customerName("WIP")
                        .customerOrderNumber(null)
                        .incomplete(null)
                        .key("event-" + savedEvent.getId())
                        .packoffStationName(null)
                        .productCode(sourceProduct.getCode())
                        .quantity(1)
                        .roomCode(sourceMeatWip.getPortionRoomCode())
                        .shipDate(null)
                        .stationCode(null)
                        .stationName(null)
                        .tableCode(null)
                        .tableName(null)
                        .timestamp(timestamp)
                        .type("SourceMeatWip")
                        .uom("CASE")
                        .weight(new BigDecimal("2.0"))
                        .workingDate(sourceMeatWip.getWorkingDate())
                        .build()
        )));
    }

    @Test
    public void shouldGetSourceMeatWipReceiptEvent() {
        final LocalDate today = LocalDate.of(2018, 12, 17);
        final LocalDateTime customerTimestamp = LocalDateTime.of(
                today, LocalTime.of(10, 11, 12));
        final Product sourceProduct = productBuilder().build();

        final PublishingSourceMeatWipReceipt sourceMeatWipReceipt = publishingSourceMeatWipReceiptBuilder();
        final OffsetDateTime timestamp = offsetDateTime(2011, 2, 3, 4, 5, 0, 0);
        final ReportingEventBuilder sourceMeatReceiptEvent = ReportingEvent.builder()
                .type("SourceMeatWipReceipt")
                .timestamp(timestamp)
                .principal("user-1")
                .productCode(sourceProduct.getCode())
                .data(sourceMeatWipReceipt.asMap(objectMapper));
        final ReportingEvent savedEvent = save(sourceMeatReceiptEvent, customerTimestamp);

        final Page<ReportingProductActivity> found =
                repository.findAll(PageRequest.of(0, 5));

        assertThat(found.getContent(), is(singletonList(
                ReportingProductActivity.builder()
                        .customerCode(null)
                        .customerName("WIP")
                        .customerOrderNumber(null)
                        .incomplete(null)
                        .key("event-" + savedEvent.getId())
                        .packoffStationName(null)
                        .productCode(sourceProduct.getCode())
                        .quantity(1)
                        .roomCode(sourceMeatWipReceipt.getPortionRoomCode())
                        .shipDate(null)
                        .stationCode(null)
                        .stationName(null)
                        .tableCode(null)
                        .tableName(null)
                        .timestamp(timestamp)
                        .type("SourceMeatWipReceipt")
                        .uom("CASE")
                        .weight(new BigDecimal("2.0"))
                        .workingDate(sourceMeatWipReceipt.getWorkingDate())
                        .build()
        )));
    }

    @Test
    public void shouldGetSourceMeatEventCreateByBlendWhichHasMissingStationCode() {
        final LocalDate today = LocalDate.of(2018, 12, 17);
        final LocalDateTime customerTimestamp = LocalDateTime.of(
                today, LocalTime.of(10, 11, 12));
        final Product sourceProduct = productBuilder().build();
        final SourceMeatOrder order = sourceMeatOrderBuilder()
                .roomCode("A")
                .stationId(null)
                .productCode(sourceProduct.getCode())
                .workingDate(today)
                .build();

        final PublishingSourceMeatOrder sourceMeatOrder = order
                .toReporting(sourceProduct, null);
        final OffsetDateTime timestamp = offsetDateTime(2011, 2, 3, 4, 5, 0, 0);
        final ReportingEventBuilder sourceMeatEvent = ReportingEvent.builder()
                .type("SourceMeatOrder")
                .timestamp(timestamp)
                .principal("user-1")
                .productCode(sourceProduct.getCode())
                .data(sourceMeatOrder.asMap(objectMapper));
        final ReportingEvent savedEvent = save(sourceMeatEvent, customerTimestamp);

        final Page<ReportingProductActivity> found =
                repository.findAll(PageRequest.of(0, 5));

        assertThat(found.getContent(), is(singletonList(
                ReportingProductActivity.builder()
                        .customerCode(null)
                        .customerName(null)
                        .customerOrderNumber(null)
                        .incomplete(null)
                        .key("event-" + savedEvent.getId())
                        .packoffStationName(null)
                        .productCode(sourceProduct.getCode())
                        .quantity(order.getQuantity())
                        .roomCode(order.getRoomCode())
                        .shipDate(null)
                        .stationCode(null)
                        .stationName(null)
                        .tableCode(null)
                        .tableName(null)
                        .timestamp(timestamp)
                        .type("SourceMeatOrder")
                        .uom("CASE")
                        .weight(null)
                        .workingDate(order.getWorkingDate())
                        .build()
        )));
    }

    public ReportingEvent save(final ReportingEventBuilder builder, final LocalDateTime createdAt) {
        final ReportingEvent box = builder.build();
        box.setCreatedAt(createdAt);
        return entityManager.persistFlushFind(box);
    }

    public ReportingBox save(final ReportingBoxBuilder builder, final LocalDateTime createdAt) {
        final ReportingBox box = builder.build();
        box.setCreatedAt(createdAt);
        return entityManager.persistFlushFind(box);
    }

    public ReportingReturnBox save(final ReportingReturnBoxBuilder builder, final LocalDateTime createdAt) {
        final ReportingReturnBox returnBox = builder.build();
        returnBox.setCreatedAt(createdAt);
        return entityManager.persistFlushFind(returnBox);
    }
}
