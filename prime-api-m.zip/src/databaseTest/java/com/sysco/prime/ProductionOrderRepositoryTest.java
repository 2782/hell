package com.sysco.prime;

import com.sysco.prime.customer.Customer;
import com.sysco.prime.customerOrder.CustomerOrder;
import com.sysco.prime.customerOrder.LineItem;
import com.sysco.prime.portionRoom.PortionRoom;
import com.sysco.prime.portionRoom.PortionRoomType;
import com.sysco.prime.portionRoomTable.PortionRoomTable;
import com.sysco.prime.product.Product;
import com.sysco.prime.productionOrder.ProductionOrder;
import com.sysco.prime.productionOrder.ProductionOrderRepository;
import com.sysco.prime.productionOrder.ProductionOrderStatus;
import com.sysco.prime.productionOrder.ProductionType;
import com.sysco.prime.station.Station;
import com.sysco.prime.utils.TimeUtils;
import org.junit.Before;
import org.junit.Test;

import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import static com.sysco.prime.DummyObjectFactory.buildCustomer;
import static com.sysco.prime.DummyObjectFactory.customerOrderBuilder;
import static com.sysco.prime.DummyObjectFactory.lineItemBuilder;
import static com.sysco.prime.DummyObjectFactory.portionRoomBuilder;
import static com.sysco.prime.DummyObjectFactory.portionRoomTableBuilder;
import static com.sysco.prime.DummyObjectFactory.productBuilder;
import static com.sysco.prime.DummyObjectFactory.productionOrderBuilder;
import static com.sysco.prime.DummyObjectFactory.stationBuilder;
import static com.sysco.prime.productionOrder.ProductionOrderStatus.CLOSED;
import static com.sysco.prime.productionOrder.ProductionOrderStatus.PACKED;
import static com.sysco.prime.productionOrder.ProductionOrderStatus.TO_CUT;
import static com.sysco.prime.productionOrder.ProductionOrderStatus.TO_GRIND;
import static com.sysco.prime.productionOrder.ProductionOrderStatus.TO_PACK;
import static java.util.Arrays.asList;
import static java.util.Collections.emptyList;
import static java.util.Collections.singletonList;
import static java.util.Optional.empty;
import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThat;

public class ProductionOrderRepositoryTest extends RepositoryTestBase<ProductionOrder, ProductionOrderRepository> {
    private static final LocalDate deliveryDate = LocalDate.parse("2017-10-24");
    private static final OffsetDateTime cutSelectedAt = OffsetDateTime.now();

    private PortionRoomTable table111;
    private PortionRoomTable table222;
    private PortionRoom roomC;
    private Station stationA;
    private Station stationB;
    private PortionRoom roomB;
    private Long stationAId;
    private transient ProductionOrder cutOrderToProductionOnTable111;
    private transient ProductionOrder cutOrderNotCancelledToProductionOnTable111;
    private transient ProductionOrder cutOrderCancelledToProductionOnTable111;
    private transient ProductionOrder grindOrder1ToProductionOnTable333;
    private transient ProductionOrder grindOrder2ToProductionOnTable333;
    private transient ProductionOrder grindOrder3ToProductionOnTable333;
    private List<ProductionOrder> table111Orders;
    private List<ProductionOrder> table333Orders;
    private PortionRoom roomA;
    private Product product;

    @Before
    public void setUp() {
        final Customer customer = entityManager.persist(buildCustomer());

        roomA = entityManager.persist(portionRoomBuilder()
                .code("A")
                .roomType(PortionRoomType.CUTTING)
                .build());
        roomB = entityManager.persist(portionRoomBuilder()
                .code("B")
                .roomType(PortionRoomType.CUTTING)
                .build());
        roomC = entityManager.persist(portionRoomBuilder()
                .code("C")
                .roomType(PortionRoomType.GRINDING)
                .build());

        stationA = entityManager.persist(stationBuilder()
                .stationCode(11)
                .room(roomA)
                .build());
        stationB = entityManager.persist(stationBuilder()
                .room(roomB)
                .stationCode(22)
                .build());
        final Station stationC = entityManager.persist(stationBuilder()
                .room(roomC)
                .stationCode(33)
                .build());
        stationAId = stationA.getId();
        table111 = entityManager.persist(portionRoomTableBuilder()
                .tableCode(111)
                .station(stationA)
                .build());
        table222 = entityManager.persist(portionRoomTableBuilder()
                .tableCode(222)
                .station(stationB)
                .build());
        final PortionRoomTable table333 = entityManager.persist(portionRoomTableBuilder()
                .tableCode(333)
                .station(stationC)
                .build());
        CustomerOrder cancelledCustomerOrder = entityManager.persist(customerOrderBuilder()
                .cancelled(true)
                .lineItems(emptyList())
                .customer(customer)
                .build());
        CustomerOrder notCancelledCustomerOrder = entityManager.persist(customerOrderBuilder()
                .cancelled(false)
                .orderNumber("12435")
                .lineItems(emptyList())
                .customer(customer)
                .build());
        product = entityManager.persist(productBuilder().build());
        final LineItem deletedLineItem = entityManager.persist(lineItemBuilder()
                .customerOrder(cancelledCustomerOrder)
                .product(product)
                .deleted(true)
                .build());
        final LineItem lineItem = entityManager.persist(lineItemBuilder()
                .customerOrder(notCancelledCustomerOrder)
                .product(product)
                .deleted(false)
                .build());
        cancelledCustomerOrder.setLineItems(singletonList(deletedLineItem));
        notCancelledCustomerOrder.setLineItems(singletonList(lineItem));
        cancelledCustomerOrder = entityManager.persist(cancelledCustomerOrder);
        notCancelledCustomerOrder = entityManager.persist(notCancelledCustomerOrder);

        grindOrder1ToProductionOnTable333 = entityManager.persist(
                productionOrderBuilder()
                        .productionType(ProductionType.GRINDING)
                        .status(TO_GRIND)
                        .packInstruction("PACK 1")
                        .deliveryDate(deliveryDate)
                        .portionRoomTable(table333)
                        .startProducingAt(null)
                        .product(null)
                        .build()
        );
        grindOrder2ToProductionOnTable333 = entityManager.persist(
                productionOrderBuilder()
                        .productionType(ProductionType.GRINDING)
                        .status(TO_PACK)
                        .deliveryDate(deliveryDate)
                        .portionRoomTable(table333)
                        .packInstruction("PACK 2")
                        .startProducingAt(null)
                        .product(null)
                        .build()
        );
        grindOrder3ToProductionOnTable333 = entityManager.persist(
                productionOrderBuilder()
                        .productionType(ProductionType.GRINDING)
                        .status(PACKED)
                        .deliveryDate(deliveryDate)
                        .portionRoomTable(table333)
                        .packInstruction("PACK 3")
                        .startProducingAt(null)
                        .product(null)
                        .build()
        );

        cutOrderCancelledToProductionOnTable111 = entityManager.persist(
                productionOrderBuilder()
                        .status(TO_CUT)
                        .sourceId(deletedLineItem.getId())
                        .customerOrder(cancelledCustomerOrder)
                        .deliveryDate(deliveryDate)
                        .portionRoomTable(table111)
                        .packInstruction("PACK 4")
                        .startProducingAt(null)
                        .product(null)
                        .build()
        );

        cutOrderNotCancelledToProductionOnTable111 = entityManager.persist(
                productionOrderBuilder()
                        .status(TO_CUT)
                        .customerOrder(notCancelledCustomerOrder)
                        .deliveryDate(deliveryDate)
                        .portionRoomTable(table111)
                        .packInstruction("PACK 5")
                        .startProducingAt(null)
                        .product(null)
                        .build()
        );

        cutOrderToProductionOnTable111 = entityManager.persist(
                productionOrderBuilder()
                        .status(TO_CUT)
                        .deliveryDate(deliveryDate)
                        .portionRoomTable(table111)
                        .packInstruction("PACK 6")
                        .startProducingAt(null)
                        .product(null)
                        .build()
        );

        entityManager.persist(
                productionOrderBuilder()
                        .status(TO_CUT)
                        .deliveryDate(deliveryDate)
                        .portionRoomTable(table222)
                        .packInstruction("PACK 7")
                        .startProducingAt(cutSelectedAt)
                        .product(null)
                        .build()
        );

        entityManager.persist(
                productionOrderBuilder()
                        .status(TO_PACK)
                        .deliveryDate(deliveryDate)
                        .portionRoomTable(table222)
                        .packInstruction("PACK 8")
                        .startProducingAt(cutSelectedAt)
                        .product(null)
                        .build()
        );
        final ProductionOrder productionOrderToPackOnTable111 = entityManager.persist(
                productionOrderBuilder()
                        .status(TO_PACK)
                        .deliveryDate(deliveryDate)
                        .portionRoomTable(table111)
                        .packInstruction("PACK 9")
                        .startProducingAt(cutSelectedAt)
                        .product(null)
                        .build()
        );
        final ProductionOrder productionOrderPackedOnTable111 = entityManager.persist(
                productionOrderBuilder()
                        .status(PACKED)
                        .deliveryDate(deliveryDate)
                        .packInstruction("PACK 10")
                        .startProducingAt(cutSelectedAt)
                        .portionRoomTable(table111)
                        .product(null)
                        .build()
        );

        final ProductionOrder productionOrderClosedOnTable111 = entityManager.persist(
                productionOrderBuilder()
                        .status(CLOSED)
                        .deliveryDate(deliveryDate)
                        .packInstruction("PACK 11")
                        .startProducingAt(cutSelectedAt)
                        .portionRoomTable(table111)
                        .product(null)
                        .build()
        );

        entityManager.flush();

        table111Orders = asList(
                cutOrderToProductionOnTable111,
                cutOrderCancelledToProductionOnTable111,
                cutOrderNotCancelledToProductionOnTable111,
                productionOrderPackedOnTable111,
                productionOrderToPackOnTable111,
                productionOrderClosedOnTable111);
        table333Orders = asList(
                grindOrder1ToProductionOnTable333,
                grindOrder2ToProductionOnTable333,
                grindOrder3ToProductionOnTable333);
    }

    @Test
    public void shouldFindToPackGrindOrders() {
        final List<ProductionOrder> productionOrders =
                repository.findGrindingOrders(roomC.getCode(), Optional.of(singletonList(TO_PACK.toString())),
                        Optional.empty());

        assertThat(productionOrders, is(singletonList(grindOrder2ToProductionOnTable333)));
    }

    @Test
    public void shouldFindGrindOrdersWithoutStatus() {
        final List<ProductionOrder> result = repository.findGrindingOrders(roomC.getCode(), Optional.empty(),
                Optional.empty());

        final List<ProductionOrder> productionOrders = Arrays.asList(
                grindOrder1ToProductionOnTable333,
                grindOrder2ToProductionOnTable333,
                grindOrder3ToProductionOnTable333);

        assertThat(result, containsInAnyOrder(productionOrders.toArray()));
    }

    @Test
    public void shouldFindCutOrderByStatusAndTableId() {
        final List<ProductionOrder> productionOrders = repository.findAll(
                stationA.getRoom().getCode(),
                Optional.of(ProductionType.CUTTING),
                singletonList(stationAId),
                Optional.of(table111),
                empty(),
                singletonList(TO_CUT)
        );

        assertThat(asList(cutOrderToProductionOnTable111,
                cutOrderCancelledToProductionOnTable111,
                cutOrderNotCancelledToProductionOnTable111),
                containsInAnyOrder(productionOrders.toArray()));
    }

    @Test
    public void shouldFindCutOrderByStatusAndTableIdAndNotExcludeCancelled() {
        final List<ProductionOrder> productionOrders = repository.findAll(
                stationA.getRoom().getCode(),
                Optional.of(ProductionType.CUTTING),
                singletonList(stationAId),
                Optional.of(table111),
                Optional.of(true),
                singletonList(TO_CUT)
        );

        assertThat(singletonList(cutOrderCancelledToProductionOnTable111),
                containsInAnyOrder(productionOrders.toArray()));
    }

    @Test
    public void shouldFindCutOrderByStatusAndTableIdAndExcludeCancelled() {
        final List<ProductionOrder> productionOrders = repository.findAll(
                stationA.getRoom().getCode(),
                Optional.of(ProductionType.CUTTING),
                singletonList(stationAId),
                Optional.of(table111),
                Optional.of(false),
                singletonList(TO_CUT)
        );

        assertThat(asList(cutOrderToProductionOnTable111, cutOrderNotCancelledToProductionOnTable111),
                containsInAnyOrder(productionOrders.toArray()));
    }

    @Test
    public void shouldFindAllCutOrderByTableId() {
        final List<ProductionOrder> productionOrders = repository.findAll(
                stationA.getRoom().getCode(),
                Optional.of(ProductionType.CUTTING),
                singletonList(stationAId),
                Optional.of(table111),
                empty(),
                emptyList()
        );

        assertThat(table111Orders, containsInAnyOrder(productionOrders.toArray()));
    }

    @Test
    public void shouldFindAllCutOrderByTableIdWhenStationIdsIsNull() {
        final List<ProductionOrder> productionOrders = repository.findAll(
                stationA.getRoom().getCode(),
                Optional.of(ProductionType.CUTTING), null, Optional.of(table111), empty(), emptyList()
        );

        assertThat(table111Orders, containsInAnyOrder(productionOrders.toArray()));
    }

    @Test
    public void shouldFindAllCutOrderByTableIdWhenStationIdsIsEmpty() {
        final List<ProductionOrder> productionOrders = repository.findAll(
                stationA.getRoom().getCode(),
                Optional.of(ProductionType.CUTTING), emptyList(), Optional.of(table111), empty(), emptyList()
        );

        assertThat(table111Orders, containsInAnyOrder(productionOrders.toArray()));
    }

    @Test
    public void shouldFindAllGrindOrdersByRoomCode() {
        final List<ProductionOrder> productionOrders = repository.findAll(
                roomC.getCode(),
                Optional.of(ProductionType.GRINDING),
                emptyList(),
                empty(), empty(), emptyList()
        );

        assertThat(table333Orders, containsInAnyOrder(productionOrders.toArray()));
    }

    @Test
    public void shouldFindAllCutOrdersByRoomCode() {
        final List<ProductionOrder> productionOrders = repository.findAll(
                stationA.getRoom().getCode(),
                Optional.of(ProductionType.CUTTING), emptyList(), empty(), empty(), emptyList()
        );

        assertThat(table111Orders, containsInAnyOrder(productionOrders.toArray()));
    }

    @Test
    public void shouldFindNewCutOrdersToOverview() {
        final List<ProductionOrder> found = repository.findAll(
                stationA.getRoom().getCode(),
                Optional.of(ProductionType.CUTTING), singletonList(stationAId), empty(), empty(), singletonList(TO_CUT)
        );

        assertThat(asList(
                cutOrderNotCancelledToProductionOnTable111,
                cutOrderCancelledToProductionOnTable111,
                cutOrderToProductionOnTable111), containsInAnyOrder(found.toArray()));
    }

    @Test
    public void shouldFindNothingToReviewWhenThereAreNoMatchingCutOrders() {
        final List<ProductionOrder> found = repository.findAll(
                stationA.getRoom().getCode(),
                Optional.of(ProductionType.CUTTING),
                singletonList(1111L),
                empty(),
                empty(),
                singletonList(TO_CUT)
        );

        assertThat(found, is(emptyList()));
    }

    @Test
    public void shouldFindUnfinishedOrders() {
        final List<ProductionOrder> productionOrders = repository.findAll(
                stationA.getRoom().getCode(),
                Optional.of(ProductionType.CUTTING),
                singletonList(stationAId),
                empty(),
                empty(),
                asList(TO_CUT, TO_PACK)
        );

        final long unfinishedCount = productionOrders.stream()
                .map(ProductionOrder::getStatus)
                .filter(status -> PACKED != status)
                .count();

        assertThat(unfinishedCount, is(4L));
    }

    @Test
    public void shouldNotFindOrderIfDeliveryDateDoesNotMatch() {
        entityManager.persist(
                productionOrderBuilder()
                        .status(TO_PACK)
                        .deliveryDate(deliveryDate.plusDays(10))
                        .portionRoomTable(table111)
                        .packInstruction("PACK 6")
                        .product(null)
                        .build());

        final List<ProductionOrder> found =
                repository.findByDeliveryDateAndPortionRoomTableStationRoomCodeAndStatusOrderByIdDesc(
                        deliveryDate.plusDays(11),
                        roomA.getCode(),
                        ProductionOrderStatus.TO_PACK);

        assertThat(found, hasSize(0));
    }

    @Test
    public void shouldNotFindOrderIfRoomCodeDoesNotMatch() {
        entityManager.persist(
                productionOrderBuilder()
                        .status(TO_PACK)
                        .deliveryDate(deliveryDate.plusDays(10))
                        .portionRoomTable(table111)
                        .packInstruction("PACK 6")
                        .product(null)
                        .build());

        final List<ProductionOrder> found =
                repository.findByDeliveryDateAndPortionRoomTableStationRoomCodeAndStatusOrderByIdDesc(
                        deliveryDate.plusDays(10),
                        roomC.getCode(),
                        ProductionOrderStatus.TO_PACK);

        assertThat(found, hasSize(0));
    }

    @Test
    public void shouldNotFindOrderIfCutTypeDoesNotMatch() {
        entityManager.persist(
                productionOrderBuilder()
                        .status(TO_PACK)
                        .deliveryDate(deliveryDate.plusDays(10))
                        .portionRoomTable(table111)
                        .packInstruction("PACK 6")
                        .product(null)
                        .build());

        final List<ProductionOrder> found =
                repository.findByDeliveryDateAndPortionRoomTableStationRoomCodeAndStatusOrderByIdDesc(
                        deliveryDate.plusDays(10),
                        roomA.getCode(),
                        TO_CUT);

        assertThat(found, hasSize(0));
    }

    @Test
    public void shouldOrderByDeliveryDateDescendingForOrdersFound() {

        entityManager.persist(
                productionOrderBuilder()
                        .status(TO_PACK)
                        .deliveryDate(deliveryDate.plusDays(10))
                        .portionRoomTable(table111)
                        .packInstruction("THIRD")
                        .product(null)
                        .build());
        entityManager.persist(
                productionOrderBuilder()
                        .status(TO_PACK)
                        .deliveryDate(deliveryDate.plusDays(10))
                        .portionRoomTable(table111)
                        .packInstruction("SECOND")
                        .product(null)
                        .build());
        entityManager.persist(
                productionOrderBuilder()
                        .status(TO_PACK)
                        .deliveryDate(deliveryDate.plusDays(10))
                        .portionRoomTable(table111)
                        .packInstruction("FIRST")
                        .product(null)
                        .build());

        final List<ProductionOrder> found =
                repository.findByDeliveryDateAndPortionRoomTableStationRoomCodeAndStatusOrderByIdDesc(
                        deliveryDate.plusDays(10),
                        roomA.getCode(),
                        TO_PACK);

        assertThat(found, hasSize(3));
        assertEquals(
                found.stream()
                        .map(ProductionOrder::getPackInstruction)
                        .collect(Collectors.toList()),
                asList("FIRST", "SECOND", "THIRD"));
    }

    @Test
    public void findByStartProducingAtGreaterThanEqualAndStartProducingAtLessThanAndProduct_CodeAndStatusIsToPack() {
        final OffsetDateTime yesterday = OffsetDateTime.now().minusDays(1);
        final OffsetDateTime yesterdayNoTime = TimeUtils.getStartTimeOfDay(LocalDate.now().minusDays(1));
        entityManager.persist(
                productionOrderBuilder()
                        .status(TO_PACK)
                        .deliveryDate(deliveryDate.plusDays(10))
                        .portionRoomTable(table111)
                        .packInstruction("SECOND")
                        .product(product)
                        .startProducingAt(yesterday)
                        .build());
        entityManager.persist(
                productionOrderBuilder()
                        .status(TO_PACK)
                        .deliveryDate(deliveryDate.plusDays(10))
                        .portionRoomTable(table111)
                        .packInstruction("FIRST")
                        .product(product)
                        .startProducingAt(cutSelectedAt)
                        .build());
        final List<ProductionOrder> found =
                repository.findByStartProducingAtGreaterThanEqualAndStartProducingAtLessThanAndProduct_CodeAndStatusIs(
                        yesterdayNoTime, yesterdayNoTime.plusDays(1), "0771188", TO_PACK);
        assertThat(found, hasSize(1));
        assertThat(found.get(0).getStartProducingAt(), is(yesterday));
    }

    @Test
    public void shouldFindByRoomCodeAndProductCode() {

        Product product1 = entityManager.persist(productBuilder()
                .code("4391102")
                .table(table111)
                .build());
        Product product2 = entityManager.persist(productBuilder()
                .code("1961172")
                .table(table222)
                .build());

        entityManager.persist(
                productionOrderBuilder()
                        .portionRoomTable(table111)
                        .product(product1)
                        .packInstruction("FIRST")
                        .build());
        entityManager.persist(
                productionOrderBuilder()
                        .portionRoomTable(table222)
                        .product(product2)
                        .packInstruction("TWO")
                        .build());
        entityManager.persist(
                productionOrderBuilder()
                        .portionRoomTable(table111)
                        .product(product1)
                        .packInstruction("THREE")
                        .build());

        final List<ProductionOrder> found =
                repository.findByProductTableStationRoomCodeAndProductCode(
                        table111.getStation().getRoom().getCode(),
                        "4391102");

        assertThat(found, hasSize(2));
        assertEquals(found.stream()
                        .map(ProductionOrder::getPackInstruction)
                        .collect(Collectors.toList()),
                asList("FIRST", "THREE"));
    }

    @Test
    public void shouldNotFindByRoomCodeAndProductCodeIfNoOrdersWithSpecifiedRoomCode() {

        Product product1 = entityManager.persist(productBuilder()
                .code("4391102")
                .table(table111)
                .build());
        Product product2 = entityManager.persist(productBuilder()
                .code("1961172")
                .table(table111)
                .build());

        entityManager.persist(
                productionOrderBuilder()
                        .portionRoomTable(table111)
                        .product(product1)
                        .packInstruction("FIRST")
                        .build());
        entityManager.persist(
                productionOrderBuilder()
                        .portionRoomTable(table111)
                        .product(product2)
                        .packInstruction("TWO")
                        .build());
        entityManager.persist(
                productionOrderBuilder()
                        .portionRoomTable(table111)
                        .product(product1)
                        .packInstruction("THREE")
                        .build());

        final List<ProductionOrder> found =
                repository.findByProductTableStationRoomCodeAndProductCode(
                        table222.getStation().getRoom().getCode(),
                        "4391102");

        assertThat(found, hasSize(0));
    }

    @Test
    public void shouldNotFindByRoomCodeAndProductCodeIfNoOrdersWithSpecifiedProductCode() {

        Product product1 = entityManager.persist(productBuilder()
                .code("4391102")
                .table(table111)
                .build());
        Product product2 = entityManager.persist(productBuilder()
                .code("1961172")
                .table(table111)
                .build());

        entityManager.persist(
                productionOrderBuilder()
                        .portionRoomTable(table111)
                        .product(product1)
                        .packInstruction("FIRST")
                        .build());
        entityManager.persist(
                productionOrderBuilder()
                        .portionRoomTable(table111)
                        .product(product2)
                        .packInstruction("TWO")
                        .build());
        entityManager.persist(
                productionOrderBuilder()
                        .portionRoomTable(table111)
                        .product(product1)
                        .packInstruction("THREE")
                        .build());

        final List<ProductionOrder> found =
                repository.findByProductTableStationRoomCodeAndProductCode(
                        table111.getStation().getRoom().getCode(),
                        "12345667");

        assertThat(found, hasSize(0));
    }

}
