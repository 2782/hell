package com.sysco.prime;

import com.sysco.prime.portionRoom.PortionRoomWorkingDates;
import com.sysco.prime.portionRoom.PortionRoomWorkingDatesRepository;
import org.junit.Test;

import static com.sysco.prime.utils.TimeUtilsTest.offsetDateTime;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

// TODO: No. A repository test is not for testing buisiness logic
public class PortionRoomWorkingDatesRepositoryTest extends RepositoryTestBase<PortionRoomWorkingDates,
        PortionRoomWorkingDatesRepository> {
    @Test
    public void shouldOpenPortionRoom() {
        final PortionRoomWorkingDates workingDatesForOpenedRoom = PortionRoomWorkingDates.builder()
                .roomCode("A")
                .opening(offsetDateTime(2011, 2, 3, 4, 5, 0, 0))
                .closing(null)
                .build();

        repository.save(workingDatesForOpenedRoom);

        assertThat(repository.getOneOrNull(workingDatesForOpenedRoom.getId()), is(workingDatesForOpenedRoom));
    }

    @Test
    public void shouldClosePortionRoom() {
        final PortionRoomWorkingDates workingDatesForClosedRoom = PortionRoomWorkingDates.builder()
                .roomCode("A")
                .opening(offsetDateTime(2011, 2, 3, 4, 5, 0, 0))
                .closing(offsetDateTime(2011, 2, 3, 14, 15, 0, 0))
                .build();

        repository.save(workingDatesForClosedRoom);

        assertThat(repository.getOneOrNull(workingDatesForClosedRoom.getId()), is(workingDatesForClosedRoom));
    }

    @Test
    public void shouldReopenPortionRoom() {
        final PortionRoomWorkingDates workingDatesForClosedRoom = repository.save(PortionRoomWorkingDates.builder()
                .roomCode("A")
                .opening(offsetDateTime(2011, 2, 3, 4, 5, 0, 0))
                .closing(offsetDateTime(2011, 2, 3, 14, 15, 0, 0))
                .build());

        final PortionRoomWorkingDates workingDatesForReopenedRoom = PortionRoomWorkingDates.builder()
                .roomCode(workingDatesForClosedRoom.getRoomCode())
                .opening(offsetDateTime(2011, 2, 3, 16, 17, 0, 0))
                .closing(null)
                .build();

        repository.save(workingDatesForReopenedRoom);

        assertThat(repository.getOneOrNull(workingDatesForReopenedRoom.getId()), is(workingDatesForReopenedRoom));
    }
}
