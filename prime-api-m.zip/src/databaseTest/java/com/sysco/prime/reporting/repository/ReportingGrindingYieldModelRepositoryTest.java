package com.sysco.prime.reporting.repository;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sysco.prime.cost.Money;
import com.sysco.prime.reporting.model.ReportingEvent;
import com.sysco.prime.reporting.model.ReportingGrindingYieldModel;
import com.sysco.prime.reporting.model.ReportingGrindingYieldModelChangeLog;
import com.sysco.prime.reporting.model.ReportingGrindingYieldModelSourceProduct;
import com.sysco.prime.yieldModel.GrindingYieldModel;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.json.JsonTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import static com.sysco.prime.DummyObjectFactory.grindingYieldModelBuilder;
import static java.util.stream.Collectors.toSet;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import static org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace.NONE;

@ActiveProfiles("test")
@AutoConfigureTestDatabase(replace = NONE)
@DataJpaTest
@RunWith(SpringRunner.class)
@JsonTest
public class ReportingGrindingYieldModelRepositoryTest {
    @Autowired
    private ReportingGrindingYieldModelRepository repository;
    @Autowired
    private TestEntityManager entityManager;
    @Autowired
    private ObjectMapper objectMapper;

    private ReportingGrindingYieldModel saved;

    private LocalDate activityDate;

    @Before
    public void setup() {
        final OffsetDateTime timestamp = ZonedDateTime.of(2011, 2, 15, 4, 10, 0, 0, ZoneId.systemDefault())
                .toOffsetDateTime();
        activityDate = LocalDate.of(2011, 2, 15);

        final GrindingYieldModel grindingYieldModel = grindingYieldModelBuilder()
                .cost(Money.of(1.0))
                .build();

        final ReportingEvent event = ReportingEvent.builder().type("YieldModel")
                .timestamp(timestamp)
                .principal("user-1")
                .data(grindingYieldModel.asMap(objectMapper))
                .build();
        final ReportingEvent savedEvent = entityManager.persistFlushFind(event);

        final Set<String> sourceProductCodes = grindingYieldModel.sourceProductCodes();

        final Set<ReportingGrindingYieldModelSourceProduct> reportingSourceProducts =
                sourceProductCodes.stream()
                        .map(sourceProductCode ->
                                ReportingGrindingYieldModelSourceProduct.builder()
                                        .sourceProductCode(sourceProductCode)
                                        .build())
                        .collect(toSet());
        final ReportingGrindingYieldModel reportingGrindingYieldModel = ReportingGrindingYieldModel
                .builder()
                .blend(grindingYieldModel.getBlend().getName())
                .build()
                .addAll(reportingSourceProducts)
                .addChangelog(ReportingGrindingYieldModelChangeLog
                        .builder()
                        .fieldName(ReportingGrindingYieldModelChangeLog.FieldType.CREATED)
                        .userId("user-1")
                        .timestamp(timestamp)
                        .reportingEventId(savedEvent.getId())
                        .activityDate(activityDate).build())
                .addChangelog(ReportingGrindingYieldModelChangeLog
                        .builder()
                        .fieldName(ReportingGrindingYieldModelChangeLog.FieldType.LABOR)
                        .userId("user-1")
                        .oldValue(Money.of(0.0))
                        .newValue(Money.of(1.0))
                        .timestamp(timestamp.plusDays(1))
                        .reportingEventId(savedEvent.getId())
                        .activityDate(activityDate.plusDays(1)).build());
        saved = entityManager.persistFlushFind(reportingGrindingYieldModel);
    }

    @Test
    public void shouldFindByBlendName() {
        final List<ReportingGrindingYieldModel> foundBlend = repository.findByBlend(saved.getBlend());

        assertThat(foundBlend.get(0).getId(), is(saved.getId()));
    }
}