package com.sysco.prime.reporting.repository;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sysco.prime.reporting.model.ReportingCuttingYieldModelActivity;
import com.sysco.prime.reporting.model.ReportingCuttingYieldModelActivity.ReportingCuttingYieldModelActivityBuilder;
import com.sysco.prime.reporting.model.ReportingEvent;
import com.sysco.prime.reporting.model.ReportingEvent.ReportingEventBuilder;
import com.sysco.prime.yieldModel.CuttingYieldAdditive;
import com.sysco.prime.yieldModel.CuttingYieldModel;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.json.JsonTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.OffsetDateTime;
import java.util.List;

import static com.sysco.prime.DummyObjectFactory.cuttingYieldModelBuilder;
import static com.sysco.prime.utils.TimeUtilsTest.offsetDateTime;
import static java.util.Arrays.asList;
import static java.util.Collections.singleton;
import static java.util.Collections.singletonList;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThat;
import static org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace.NONE;

@ActiveProfiles("test")
@AutoConfigureTestDatabase(replace = NONE)
@DataJpaTest
@RunWith(SpringRunner.class)
@JsonTest
public class ReportingCuttingYieldModelActivityRepositoryTest {
    @Autowired
    private ReportingCuttingYieldModelActivityRepository repository;
    @Autowired
    private TestEntityManager entityManager;
    @Autowired
    private ObjectMapper objectMapper;

    @Test
    public void shouldFindByFinishAndSourcProductCode() {
        final LocalDate today = LocalDate.of(2018, 12, 17);
        final LocalDateTime customerTimestamp = LocalDateTime.of(
                today,
                LocalTime.of(10, 11, 12));

        final OffsetDateTime timestamp = offsetDateTime(2011, 2, 3, 4, 5, 0, 0);

        final CuttingYieldAdditive yieldAdditive = CuttingYieldAdditive.builder()
                .productCode("4181840")
                .weight(BigDecimal.valueOf(30.0d))
                .build();

        final String finishedProductCode = "1961172";
        final String sourceProductCode = "3401581";
        final CuttingYieldModel yieldModelOne = cuttingYieldModelBuilder()
                .finishedProductCode(finishedProductCode)
                .sourceProductCode(sourceProductCode)
                .labor(new BigDecimal("1.11"))
                .finishedProductCost(BigDecimal.valueOf(17.65d))
                .pricingModel(true)
                .yieldAdditives(singleton(yieldAdditive))
                .build();
        yieldModelOne.setId(1L);
        final ReportingEventBuilder yieldModelEvent = ReportingEvent.builder()
                .type("YieldModel")
                .timestamp(timestamp)
                .principal("user-1")
                .productCode("1961172")
                .data(yieldModelOne.asMap(objectMapper));
        save(yieldModelEvent, customerTimestamp);

        final List<ReportingCuttingYieldModelActivity> found = repository
                .findByFinishedProductCodeAndSourceProductCode(finishedProductCode,
                        sourceProductCode);

        assertThat(found, is(singletonList(
                ReportingCuttingYieldModelActivity.builder()
                        .type("YieldModel")
                        .timestamp(timestamp)
                        .additives(new BigDecimal("0.0"))
                        .pricingModel(true)
                        .labor(new BigDecimal("1.11"))
                        .pickupPercent(new BigDecimal("15.0"))
                        .byProductCredit(new BigDecimal("1.06"))
                        .principal("user-1")
                        .packaging(new BigDecimal("2.0"))
                        .yieldPercentage(new BigDecimal("90.0"))
                        .overhead(new BigDecimal("3.0"))
                        .key("event-1")
                        .sourceProductCode(sourceProductCode)
                        .finishedProductCode(finishedProductCode)
                        .finishedProductCost(new BigDecimal("17.65"))
                        .activityDate(LocalDate.of(2011, 2, 3))
                        .build())));
    }

    @Test
    public void shouldFindTop2ByFinishAndSourceProductCode() {
        final LocalDate today = LocalDate.of(2018, 12, 17);
        final LocalDateTime customerTimestamp = LocalDateTime.of(
                today,
                LocalTime.of(10, 11, 12));

        final OffsetDateTime timestamp = offsetDateTime(2011, 2, 3, 4, 5, 0, 0);

        final String finishedProductCode = "1961172";
        final String sourceProductCode = "3401581";
        final CuttingYieldModel yieldModelOne = cuttingYieldModelBuilder()
                .finishedProductCode(finishedProductCode)
                .sourceProductCode(sourceProductCode)
                .labor(new BigDecimal("1.11"))
                .finishedProductCost(BigDecimal.valueOf(17.65d))
                .pricingModel(true)
                .build();
        yieldModelOne.setId(1L);
        final ReportingEventBuilder yieldModelEvent = ReportingEvent.builder()
                .type("YieldModel")
                .timestamp(timestamp.minusMinutes(3))
                .principal("user-1")
                .productCode("1961172")
                .data(yieldModelOne.asMap(objectMapper));
        save(yieldModelEvent, customerTimestamp);

        final ReportingEventBuilder yieldModelEventSecond = ReportingEvent.builder()
                .type("YieldModel")
                .timestamp(timestamp.minusMinutes(2))
                .principal("user-1")
                .productCode("1961172")
                .data(yieldModelOne.asMap(objectMapper));
        save(yieldModelEventSecond, customerTimestamp);

        final ReportingEventBuilder yieldModelEventThird = ReportingEvent.builder()
                .type("YieldModel")
                .timestamp(timestamp.minusMinutes(1))
                .principal("user-1")
                .productCode("1961172")
                .data(yieldModelOne.asMap(objectMapper));
        save(yieldModelEventThird, customerTimestamp);

        final List<ReportingCuttingYieldModelActivity> found = repository
                .findTop2ByFinishedProductCodeAndSourceProductCode(finishedProductCode,
                        sourceProductCode);

        final ReportingCuttingYieldModelActivityBuilder expectedYieldModelBuilder = ReportingCuttingYieldModelActivity
                .builder()
                .type("YieldModel")
                .additives(new BigDecimal("0"))
                .pricingModel(true)
                .labor(new BigDecimal("1.11"))
                .pickupPercent(new BigDecimal("15.0"))
                .byProductCredit(new BigDecimal("1.06"))
                .principal("user-1")
                .packaging(new BigDecimal("2.0"))
                .yieldPercentage(new BigDecimal("90.0"))
                .overhead(new BigDecimal("3.0"))
                .key("event-1")
                .sourceProductCode(sourceProductCode)
                .finishedProductCode(finishedProductCode)
                .finishedProductCost(new BigDecimal("17.65"))
                .activityDate(LocalDate.of(2011, 2, 3));
        assertThat(found, is(asList(
                expectedYieldModelBuilder
                        .timestamp(timestamp.minusMinutes(1))
                        .build(),
                expectedYieldModelBuilder
                        .timestamp(timestamp.minusMinutes(2))
                        .build())));
    }

    @Test
    public void shouldUniqueDate() {
        final LocalDate today = LocalDate.of(2018, 12, 17);
        final LocalDateTime customerTimestamp = LocalDateTime.of(
                today,
                LocalTime.of(10, 11, 12));

        final OffsetDateTime timestamp = offsetDateTime(2011, 2, 3, 4, 5, 0, 0);

        final CuttingYieldAdditive yieldAdditive = CuttingYieldAdditive.builder()
                .productCode("4181840")
                .weight(BigDecimal.valueOf(30.0d))
                .build();

        final String finishedProductCode = "1961172";
        final String sourceProductCode = "3401581";
        final CuttingYieldModel yieldModelOne = cuttingYieldModelBuilder()
                .finishedProductCode(finishedProductCode)
                .sourceProductCode(sourceProductCode)
                .labor(new BigDecimal("1.11"))
                .finishedProductCost(BigDecimal.valueOf(17.65d))
                .pricingModel(true)
                .yieldAdditives(singleton(yieldAdditive))
                .build();
        yieldModelOne.setId(1L);
        final ReportingEventBuilder yieldModelEvent = ReportingEvent.builder()
                .type("YieldModel")
                .timestamp(timestamp)
                .principal("user-1")
                .productCode("1961172")
                .data(yieldModelOne.asMap(objectMapper));
        save(yieldModelEvent, customerTimestamp);

        final List<LocalDate> foundList = repository.findUniqueActivityDates(finishedProductCode,
                sourceProductCode);

        assertEquals(foundList.get(0).compareTo(LocalDate.of(2011, 2, 3)), 0);
    }

    public ReportingEvent save(final ReportingEventBuilder builder, final LocalDateTime createdAt) {
        final ReportingEvent box = builder.build();
        box.setCreatedAt(createdAt);
        return entityManager.persistFlushFind(box);
    }
}
