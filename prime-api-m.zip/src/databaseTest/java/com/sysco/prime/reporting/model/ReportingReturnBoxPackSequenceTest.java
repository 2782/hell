package com.sysco.prime.reporting.model;

import com.sysco.prime.RepositoryTestBase;
import com.sysco.prime.reporting.repository.ReportingReturnBoxPackSequenceRepository;
import org.junit.Before;
import org.junit.Test;
import org.springframework.boot.test.autoconfigure.json.JsonTest;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

import static com.sysco.prime.DummyObjectFactory.reportingReturnBoxBuilder;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

@JsonTest
public class ReportingReturnBoxPackSequenceTest extends RepositoryTestBase<ReportingReturnBoxPackSequence,
        ReportingReturnBoxPackSequenceRepository> {

    @Before
    public void setup() {
        final LocalDate localDate = LocalDate.of(2011, 2, 3);

        final ReportingReturnBox reportingReturnBoxSummary = reportingReturnBoxBuilder()
                .productDescription("description")
                .portionRoomCode("portionroomcode")
                .weight(BigDecimal.valueOf(1.0))
                .productCode("1234567")
                .isFixWeightProduct(true)
                .weightedAverageCost(BigDecimal.valueOf(2.0))
                .packoffStationName("stationname")
                .portionRoomCode("A")
                .workingDate(localDate)
                .productCode("1234567")
                .weight(BigDecimal.valueOf(2.0))
                .marketCost(BigDecimal.valueOf(2.0))
                .productDescription("TASTY FOWL")
                .build();
        reportingReturnBoxSummary.setCreatedAt(LocalDateTime
                .of(2019, 1, 1, 12, 12, 12));

        entityManager.persist(reportingReturnBoxSummary);
        entityManager.flush();
    }

    @Test
    public void shouldGetOneReturnBoxPackSequence() {
        final List<ReportingReturnBoxPackSequence> readBack = repository.findAll();

        assertThat(readBack.size(), is(1));
    }
}