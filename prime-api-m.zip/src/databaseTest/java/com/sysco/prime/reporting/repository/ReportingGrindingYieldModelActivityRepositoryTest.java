
package com.sysco.prime.reporting.repository;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sysco.prime.productionOrder.Blend;
import com.sysco.prime.reporting.model.ReportingEvent;
import com.sysco.prime.reporting.model.ReportingEvent.ReportingEventBuilder;
import com.sysco.prime.reporting.model.ReportingGrindingYieldModelActivity;
import com.sysco.prime.yieldModel.GrindingYieldModel;
import com.sysco.prime.yieldModel.GrindingYieldModelSourceProduct;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.json.JsonTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.OffsetDateTime;
import java.util.Comparator;
import java.util.List;
import java.util.Set;

import static com.sysco.prime.DummyObjectFactory.SECOND_SOURCE_PRODUCT_CODE;
import static com.sysco.prime.DummyObjectFactory.SOURCE_PRODUCT_CODE;
import static com.sysco.prime.DummyObjectFactory.THIRD_SOURCE_PRODUCT_CODE;
import static com.sysco.prime.DummyObjectFactory.grindingYieldModelBuilder;
import static com.sysco.prime.DummyObjectFactory.grindingYieldModelSourceProductBuilder;
import static com.sysco.prime.utils.SetUtils.asSet;
import static com.sysco.prime.utils.TimeUtilsTest.offsetDateTime;
import static java.util.Arrays.asList;
import static java.util.Collections.emptyList;
import static java.util.Collections.singletonList;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace.NONE;

@ActiveProfiles("test")
@AutoConfigureTestDatabase(replace = NONE)
@DataJpaTest
@RunWith(SpringRunner.class)
@JsonTest
public class ReportingGrindingYieldModelActivityRepositoryTest {
    @Autowired
    private ReportingGrindingYieldModelActivityRepository repository;
    @Autowired
    private TestEntityManager entityManager;
    @Autowired
    private ObjectMapper objectMapper;

    private String blendName = "BLEND04";
    private GrindingYieldModel angusYieldModelWithTwoSource;
    private GrindingYieldModel angusYieldModelWithSecondTwoSource;

    private GrindingYieldModel angusYieldModelWithOneSource;
    private LocalDateTime customerTimestamp;
    private OffsetDateTime timestamp;

    @Before
    public void setup() {
        final LocalDate today = LocalDate.of(2018, 12, 17);
        customerTimestamp = LocalDateTime.of(
                today,
                LocalTime.of(10, 11, 12));

        timestamp = offsetDateTime(2011, 2, 3, 4, 5, 0, 0);

        angusYieldModelWithTwoSource = grindingYieldModelBuilder()
                .blend(Blend.builder().name(blendName).build())
                .pricingModel(true)
                .additives(BigDecimal.ONE)
                .grindingYieldModelSourceProducts(emptyList())
                .build();
        angusYieldModelWithOneSource = angusYieldModelWithTwoSource.toBuilder()
                .build();
        angusYieldModelWithSecondTwoSource = angusYieldModelWithTwoSource.toBuilder()
                .build();
        final GrindingYieldModelSourceProduct grindingYieldModelSourceProduct1ForOneSource =
                grindingYieldModelSourceProductBuilder()
                        .sourceProductCode(SOURCE_PRODUCT_CODE)
                        .sourceProductCost(1.0d)
                        .grindingYieldModel(angusYieldModelWithOneSource)
                        .build();
        final GrindingYieldModelSourceProduct grindingYieldModelSourceProduct1ForTwoSource =
                grindingYieldModelSourceProductBuilder()
                        .sourceProductCode(SOURCE_PRODUCT_CODE)
                        .sourceProductCost(1.0d)
                        .grindingYieldModel(angusYieldModelWithTwoSource)
                        .build();
        final GrindingYieldModelSourceProduct grindingYieldModelSourceProduct2ForTwoSource =
                grindingYieldModelSourceProductBuilder()
                        .sourceProductCode(SECOND_SOURCE_PRODUCT_CODE)
                        .sourceProductCost(2.0d)
                        .grindingYieldModel(angusYieldModelWithTwoSource)
                        .build();

        final GrindingYieldModelSourceProduct grindingYieldModelSourceProduct1ForSecondTwoSource =
                grindingYieldModelSourceProductBuilder()
                        .sourceProductCode(SOURCE_PRODUCT_CODE)
                        .sourceProductCost(1.0d)
                        .grindingYieldModel(angusYieldModelWithSecondTwoSource)
                        .build();
        final GrindingYieldModelSourceProduct grindingYieldModelSourceProduct2ForSecondTwoSource =
                grindingYieldModelSourceProductBuilder()
                        .sourceProductCode(THIRD_SOURCE_PRODUCT_CODE)
                        .sourceProductCost(2.0d)
                        .grindingYieldModel(angusYieldModelWithSecondTwoSource)
                        .build();
        final List<GrindingYieldModelSourceProduct> grindingYieldModelSourceProducts =
                asList(grindingYieldModelSourceProduct1ForTwoSource, grindingYieldModelSourceProduct2ForTwoSource);
        angusYieldModelWithTwoSource.setGrindingYieldModelSourceProducts(
                grindingYieldModelSourceProducts);
        angusYieldModelWithSecondTwoSource.setGrindingYieldModelSourceProducts(
                asList(grindingYieldModelSourceProduct1ForSecondTwoSource,
                        grindingYieldModelSourceProduct2ForSecondTwoSource));
        angusYieldModelWithOneSource.setGrindingYieldModelSourceProducts(
                singletonList(grindingYieldModelSourceProduct1ForOneSource));
    }

    @Test
    public void shouldFindTop2EventsForBlendNameAndSourceProductCodesCombinationOfGrinding() {
        createEvent(timestamp.minusMinutes(3), angusYieldModelWithTwoSource, customerTimestamp);
        createEvent(timestamp.minusMinutes(2), angusYieldModelWithTwoSource, customerTimestamp);
        createEvent(timestamp.minusMinutes(1), angusYieldModelWithTwoSource, customerTimestamp);

        final List<ReportingGrindingYieldModelActivity> found = repository
                .findTop2ByBlendNameAndSourceProductCodes(blendName,
                        asSet(SOURCE_PRODUCT_CODE, SECOND_SOURCE_PRODUCT_CODE), 2L);

        assertThat(found.get(0).getTimestamp(), is(timestamp.minusMinutes(1)));
        assertThat(found.get(1).getTimestamp(), is(timestamp.minusMinutes(2)));
    }

    @Test
    public void shouldFindByBlendNameAndCorrectSourceProductCodesList() {
        final ReportingEventBuilder yieldModelEvent = ReportingEvent.builder()
                .type("YieldModel")
                .timestamp(timestamp.minusMinutes(3))
                .principal("user-1")
                .productCode(null)
                .data(angusYieldModelWithTwoSource.asMap(objectMapper));
        final ReportingEvent savedEventWithTwoSource = save(yieldModelEvent, customerTimestamp);

        final ReportingEventBuilder yieldModelEventSecond = ReportingEvent.builder()
                .type("YieldModel")
                .timestamp(timestamp.minusMinutes(2))
                .principal("user-1")
                .productCode(null)
                .data(angusYieldModelWithOneSource.asMap(objectMapper));
        save(yieldModelEventSecond, customerTimestamp);

        final List<ReportingGrindingYieldModelActivity> found = repository
                .findTop2ByBlendNameAndSourceProductCodes(blendName,
                        asSet(SOURCE_PRODUCT_CODE, SECOND_SOURCE_PRODUCT_CODE), 2L);

        assertThat(found.get(0).getEventId(), is(savedEventWithTwoSource.getId()));
        assertThat(found.size(), is(1));
    }

    @Test
    public void shouldFindByTwoActivitiesForBlendNameAndCorrectOneSourceProductCodesList() {
        createEvent(timestamp.minusMinutes(3), angusYieldModelWithOneSource, customerTimestamp);
        createEvent(timestamp.minusMinutes(2), angusYieldModelWithTwoSource, customerTimestamp);
        createEvent(timestamp.minusMinutes(1), angusYieldModelWithOneSource
                .toBuilder()
                .overhead(BigDecimal.valueOf(5))
                .build(), customerTimestamp);

        final Set<String> productCodes = asSet(SOURCE_PRODUCT_CODE);
        final List<ReportingGrindingYieldModelActivity> found = repository
                .findTop2ByBlendNameAndSourceProductCodes(blendName,
                        productCodes, (long) productCodes.size());

        assertThat(found.get(0).getSourceProductList(), is(singletonList(SOURCE_PRODUCT_CODE)));
        assertThat(found.get(1).getSourceProductList(), is(singletonList(SOURCE_PRODUCT_CODE)));
    }

    @Test
    public void shouldFindByTwoActivitiesForBlendNameAndOnlyTwoSourceProductCodesList() {
        createEvent(timestamp.minusMinutes(3), angusYieldModelWithTwoSource, customerTimestamp);
        createEvent(timestamp.minusMinutes(2), angusYieldModelWithOneSource, customerTimestamp);
        createEvent(timestamp.minusMinutes(1), angusYieldModelWithTwoSource
                .toBuilder()
                .overhead(BigDecimal.valueOf(5))
                .build(), customerTimestamp);

        final Set<String> productCodes = asSet(SOURCE_PRODUCT_CODE, SECOND_SOURCE_PRODUCT_CODE);
        final List<ReportingGrindingYieldModelActivity> resultsFound = repository
                .findTop2ByBlendNameAndSourceProductCodes(blendName,
                        productCodes, (long) productCodes.size());

        checkResultsContainFirstAndSecondSourceProductCodeResults(resultsFound);
    }

    private void createEvent(final OffsetDateTime requestedTimestamp, final GrindingYieldModel yieldModel,
                             final LocalDateTime customerTimestamp) {
        final ReportingEventBuilder saveEvent = ReportingEvent.builder()
                .type("YieldModel")
                .timestamp(requestedTimestamp)
                .principal("user-1")
                .productCode(null)
                .data(yieldModel.asMap(objectMapper));
        save(saveEvent, customerTimestamp);
    }

    @Test
    public void shouldFindByTwoActivitiesForBlendNameAndOCorrectTwoSourceProductCodesList() {
        createEvent(timestamp.minusMinutes(3), angusYieldModelWithTwoSource, customerTimestamp);
        createEvent(timestamp.minusMinutes(2), angusYieldModelWithSecondTwoSource, customerTimestamp);
        createEvent(timestamp.minusMinutes(1), angusYieldModelWithTwoSource
                .toBuilder()
                .overhead(BigDecimal.valueOf(5))
                .build(), customerTimestamp);

        final Set<String> productCodes = asSet(SOURCE_PRODUCT_CODE, SECOND_SOURCE_PRODUCT_CODE);
        final List<ReportingGrindingYieldModelActivity> found = repository
                .findTop2ByBlendNameAndSourceProductCodes(blendName,
                        productCodes, (long) productCodes.size());

        checkResultsContainFirstAndSecondSourceProductCodeResults(found);
    }

    private void checkResultsContainFirstAndSecondSourceProductCodeResults(final
                                                                           List<ReportingGrindingYieldModelActivity>
                                                                                   found) {
        final List<String> expectedProductCodeList = asList(SOURCE_PRODUCT_CODE, SECOND_SOURCE_PRODUCT_CODE);
        expectedProductCodeList.sort(Comparator.comparing(String::toString));
        final List<String> firstActualActivitySourceProductList = found.get(0).getSourceProductList();
        firstActualActivitySourceProductList.sort(Comparator.comparing(String::toString));

        final List<String> secondActualActivitySourceProductList = found.get(1).getSourceProductList();
        secondActualActivitySourceProductList.sort(Comparator.comparing(String::toString));

        assertThat(firstActualActivitySourceProductList, is(expectedProductCodeList));
        assertThat(secondActualActivitySourceProductList, is(expectedProductCodeList));
    }

    public ReportingEvent save(final ReportingEventBuilder builder, final LocalDateTime createdAt) {
        final ReportingEvent box = builder.build();
        box.setCreatedAt(createdAt);
        return entityManager.persistFlushFind(box);
    }
}
