package com.sysco.prime.reporting.repository;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sysco.prime.RepositoryTestBase;
import com.sysco.prime.cost.Cost;
import com.sysco.prime.portionRoom.PortionRoomWorkingDates;
import com.sysco.prime.portionRoom.PublishingPortionRoom;
import com.sysco.prime.reporting.model.ReportingBatch;
import com.sysco.prime.reporting.model.ReportingEvent;
import com.sysco.prime.reporting.model.ReportingPortionRoom;
import com.sysco.prime.reporting.model.ReportingSourceMeatOrder;
import com.sysco.prime.sourceMeat.PublishingSourceMeatOrder;
import com.sysco.prime.sourceMeat.PublishingSourceMeatReceipt;
import com.sysco.prime.sourceMeat.PublishingSourceMeatReceiptItem;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.json.JsonTest;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.OffsetDateTime;

import static com.sysco.prime.DummyObjectFactory.buildCost;
import static com.sysco.prime.DummyObjectFactory.buildPortionRoom;
import static com.sysco.prime.DummyObjectFactory.buildProduct;
import static com.sysco.prime.DummyObjectFactory.buildReportingBatch;
import static com.sysco.prime.DummyObjectFactory.buildReportingSourceMeatOrder;
import static com.sysco.prime.DummyObjectFactory.buildSourceMeatOrder;
import static com.sysco.prime.DummyObjectFactory.buildSourceMeatReceipt;
import static com.sysco.prime.DummyObjectFactory.buildSourceMeatReceiptItem;
import static com.sysco.prime.DummyObjectFactory.buildStation;
import static com.sysco.prime.DummyObjectFactory.reportingPortionRoomBuilder;
import static com.sysco.prime.utils.TimeUtilsTest.offsetDateTime;
import static java.time.OffsetDateTime.now;
import static java.util.Collections.singletonList;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

@JsonTest
public class ReportingEventRepositoryTest extends RepositoryTestBase<ReportingEvent, ReportingEventRepository> {
    @Autowired
    private ReportingSourceMeatOrderRepository reportingSourceMeatOrderRepository;
    @Autowired
    private ReportingPortionRoomRepository reportingPortionRoomRepository;
    @Autowired
    private ReportingBatchRepository reportingBatchRepository;
    @Autowired
    private ObjectMapper objectMapper;

    private static void workAroundJsonbLongReturningAsInt(final ReportingEvent readBack) {
        readBack.getData().put("cutOrderId", Long.valueOf((Integer) readBack.getData().get("cutOrderId")));
    }

    @Test
    public void shouldRoundtripOpenPortionRoom() {
        final OffsetDateTime timestamp = offsetDateTime(2011, 2, 3, 4, 5, 0, 0);
        final PortionRoomWorkingDates workingDates = PortionRoomWorkingDates.builder()
                .opening(timestamp.minusDays(1))
                .closing(null)
                .build();
        final PublishingPortionRoom reportingRoom = buildPortionRoom()
                .toReporting(
                        workingDates.getOpening(),
                        workingDates.getClosing());
        final ReportingEvent event = ReportingEvent.builder()
                .type("PortionRoom")
                .timestamp(timestamp)
                .principal("user-1")
                .data(reportingRoom.asMap(objectMapper))
                .build();

        final ReportingEvent saved = saveAndDisableCaching(event, repository);
        final ReportingEvent readBack = repository.findById(saved.getId()).orElse(null);

        assertThat(readBack, is(equalTo(saved)));
    }

    @Test
    public void shouldRoundtripOpeningOfReportingPortionRoom() {
        final OffsetDateTime opening = now();
        final ReportingPortionRoom reportingPortionRoom = reportingPortionRoomBuilder()
                .opening(opening)
                .build();

        final ReportingPortionRoom saved = saveAndDisableCaching(reportingPortionRoom, reportingPortionRoomRepository);
        final ReportingPortionRoom readBack = reportingPortionRoomRepository.getOneOrNull(saved.getId());

        assertThat(readBack, is(equalTo(saved)));
    }

    @Test
    public void shouldRoundtripClosedPortionRoom() {
        final OffsetDateTime timestamp = now();
        final PortionRoomWorkingDates workingDates = PortionRoomWorkingDates.builder()
                .opening(timestamp.minusDays(1))
                .closing(timestamp.plusDays(1))
                .build();
        final PublishingPortionRoom reportingRoom = buildPortionRoom()
                .toReporting(
                        workingDates.getOpening(),
                        workingDates.getClosing());
        final ReportingEvent event = ReportingEvent.builder()
                .type("PortionRoom")
                .timestamp(timestamp)
                .principal("user-1")
                .data(reportingRoom.asMap(objectMapper))
                .build();

        final ReportingEvent saved = saveAndDisableCaching(event, repository);
        final ReportingEvent readBack = repository.findById(saved.getId()).orElse(null);

        assertThat(readBack, is(equalTo(saved)));
    }

    @Test
    public void shouldRoundtripPrimeSourceMeatOrder() {
        final OffsetDateTime timestamp = now();
        final PublishingSourceMeatOrder reportingOrder = buildSourceMeatOrder()
                .toReporting(buildProduct(), buildStation().getStationCode());
        final ReportingEvent event = ReportingEvent.builder()
                .type("SourceMeatOrder")
                .timestamp(timestamp)
                .principal("Bob the Builder")
                .data(reportingOrder.asMap(objectMapper))
                .build();

        final ReportingEvent saved = saveAndDisableCaching(event, repository);
        final ReportingEvent readBack = repository.findById(saved.getId()).orElse(null);

        workAroundJsonbLongReturningAsInt(readBack);

        assertThat(readBack, is(equalTo(saved)));
    }

    @Test
    public void shouldRoundtripReportingSourceMeatOrder() {
        final ReportingSourceMeatOrder order = buildReportingSourceMeatOrder();
        order.getReceiptItem().setReportingSourceMeatOrder(order);

        final ReportingSourceMeatOrder saved = saveAndDisableCaching(order, reportingSourceMeatOrderRepository);
        final ReportingSourceMeatOrder readBack = reportingSourceMeatOrderRepository.getOneOrNull(saved.getId());

        assertThat(readBack, is(equalTo(saved)));
    }

    @Test
    public void shouldRoundtripReportingBatch() {
        final ReportingBatch order = buildReportingBatch();

        final ReportingBatch saved = saveAndDisableCaching(order, reportingBatchRepository);
        final ReportingBatch readBack = reportingBatchRepository.getOneOrNull(saved.getId());

        assertThat(readBack, is(equalTo(saved)));
    }

    @Test
    public void shouldRoundtripReportingSourceMeatOrderAndReceipt() {
        final ReportingSourceMeatOrder orderOnly = buildReportingSourceMeatOrder();
        final ReportingSourceMeatOrder saved = saveAndDisableCaching(orderOnly, reportingSourceMeatOrderRepository);
        final ReportingSourceMeatOrder readBack = reportingSourceMeatOrderRepository.getOneOrNull(saved.getId());
        final com.sysco.prime.sourceMeat.SourceMeatOrder order = buildSourceMeatOrder();

        final Cost cost = buildCost();
        final PublishingSourceMeatReceiptItem sourceMeatReceiptItem = buildSourceMeatReceiptItem()
                .toReporting(cost, "product desc", 12.4);
        final PublishingSourceMeatReceipt sourceMeatReceipt = buildSourceMeatReceipt()
                .toReporting(order, sourceMeatReceiptItem, buildStation());
        readBack.assignReceipt(sourceMeatReceipt);

        final ReportingSourceMeatOrder savedOrder = saveAndDisableCaching(readBack, reportingSourceMeatOrderRepository);
        final ReportingSourceMeatOrder readBackOrderWithReceipt =
                reportingSourceMeatOrderRepository.findByPoNumber(orderOnly.getPoNumber());

        assertThat(readBackOrderWithReceipt, is(equalTo(savedOrder)));
    }

    private <T> T saveAndDisableCaching(final T item, final JpaRepository<T, Long> repository) {
        final T saved = repository.saveAndFlush(item);
        entityManager.clear();
        return saved;
    }
}
