package com.sysco.prime.reporting.repository;

import com.sysco.prime.RepositoryTestBase;
import com.sysco.prime.reporting.model.ReportingSourceMeatWipReceipt;
import com.sysco.prime.sourceMeat.PublishingSourceMeatWipReceipt;
import org.junit.Test;

import java.time.LocalDate;

import static com.sysco.prime.DummyObjectFactory.createLocalDate;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

public class ReportingSourceMeatWipReceiptRepositoryTest extends
        RepositoryTestBase<ReportingSourceMeatWipReceipt,
                ReportingSourceMeatWipReceiptRepository> {

    @Test
    public void shouldRoundtrip() {
        final LocalDate workingDate = createLocalDate();

        final PublishingSourceMeatWipReceipt sourceMeatWipReceiptItem = PublishingSourceMeatWipReceipt.builder()
                .productCode("7203474")
                .weight(14.0)
                .portionRoomCode("A")
                .workingDate(workingDate)
                .build();

        final ReportingSourceMeatWipReceipt unsavedSourceMeatWipReceipt = sourceMeatWipReceiptItem.toReporting();

        final ReportingSourceMeatWipReceipt readBack = saveAndReadBack(unsavedSourceMeatWipReceipt);

        assertThat(readBack, is(unsavedSourceMeatWipReceipt));
    }
}