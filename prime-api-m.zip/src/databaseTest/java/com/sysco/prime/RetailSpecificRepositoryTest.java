package com.sysco.prime;

import com.sysco.prime.packages.BoxType;
import com.sysco.prime.packages.FilmType;
import com.sysco.prime.packages.TarePackage;
import com.sysco.prime.product.Product;
import com.sysco.prime.product.RetailSpecific;
import com.sysco.prime.product.RetailSpecificRepository;
import org.junit.Test;

import java.math.BigDecimal;

import static com.sysco.prime.DummyObjectFactory.buildBoxType;
import static com.sysco.prime.DummyObjectFactory.buildFilmType;
import static com.sysco.prime.DummyObjectFactory.buildTarePackage;
import static com.sysco.prime.DummyObjectFactory.productBuilder;
import static com.sysco.prime.DummyObjectFactory.tarePackageBuilder;
import static org.assertj.core.api.Assertions.assertThat;

public class RetailSpecificRepositoryTest extends RepositoryTestBase<RetailSpecific, RetailSpecificRepository> {
    @Test
    public void shouldBeAbleToRoundTrip() {
        Product product = productBuilder()
                .code("4102218")
                .description("Beavens tacos")
                .build();

        Product savedProduct = entityManager.persistFlushFind(product);
        BoxType savedBox = entityManager.persistFlushFind(buildBoxType());
        FilmType savedFilm = entityManager.persistFlushFind(buildFilmType());

        TarePackage tarePackage = tarePackageBuilder()
                .boxType(savedBox)
                .filmType(savedFilm)
                .build();

        TarePackage savedPackage = entityManager.persistFlushFind(tarePackage);

        final RetailSpecific retailSpecific = RetailSpecific.builder()
                .price(BigDecimal.valueOf(10))
                .maxWeight(BigDecimal.valueOf(3))
                .minWeight(BigDecimal.valueOf(1))
                .tare(savedPackage)
                .product(savedProduct)
                .build();

        final RetailSpecific readBack = saveAndReadBack(retailSpecific);

        assertThat(readBack.getProduct().getId()).isEqualTo(product.getId());
        assertThat(readBack.getPrice()).isEqualTo(retailSpecific.getPrice());
        assertThat(readBack.getMaxWeight()).isEqualTo(retailSpecific.getMaxWeight());
        assertThat(readBack.getMinWeight()).isEqualTo(retailSpecific.getMinWeight());
        assertThat(readBack.getTare()).isEqualTo(retailSpecific.getTare());
    }
}
