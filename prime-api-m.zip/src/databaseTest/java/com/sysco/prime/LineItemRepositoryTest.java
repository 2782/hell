package com.sysco.prime;

import com.sysco.prime.customer.Customer;
import com.sysco.prime.customerOrder.CustomerOrder;
import com.sysco.prime.customerOrder.LineItem;
import com.sysco.prime.customerOrder.LineItemRepository;
import com.sysco.prime.portionRoom.PortionRoom;
import com.sysco.prime.portionRoomTable.PortionRoomTable;
import com.sysco.prime.product.Product;
import com.sysco.prime.product.ProductOutput;
import com.sysco.prime.station.Station;
import org.junit.Before;
import org.junit.Test;

import java.time.LocalDate;
import java.util.List;

import static com.sysco.prime.DummyObjectFactory.buildCustomer;
import static com.sysco.prime.DummyObjectFactory.customerOrderBuilder;
import static com.sysco.prime.DummyObjectFactory.lineItemBuilder;
import static com.sysco.prime.DummyObjectFactory.portionRoomBuilder;
import static com.sysco.prime.DummyObjectFactory.portionRoomTableBuilder;
import static com.sysco.prime.DummyObjectFactory.productBuilder;
import static com.sysco.prime.DummyObjectFactory.stationBuilder;
import static java.util.Arrays.asList;
import static java.util.Collections.emptyList;
import static java.util.Collections.singletonList;
import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.junit.Assert.assertThat;

public class LineItemRepositoryTest extends RepositoryTestBase<LineItem, LineItemRepository> {
    private static final LocalDate shipDate1 = LocalDate.parse("2018-06-01");
    private static final LocalDate shipDate2 = LocalDate.parse("2018-06-02");
    private static final LocalDate shipDate3 = LocalDate.parse("2018-06-03");
    private List<LineItem> lineItemList;
    private CustomerOrder customerOrder2;
    private Product portionRoomProductInRoomA;

    @Before
    public void setUp() {
        final PortionRoom roomA = entityManager.persist(portionRoomBuilder()
                .code("A")
                .build());
        final PortionRoom roomB = entityManager.persist(portionRoomBuilder()
                .code("B")
                .build());

        Customer customer1 = buildCustomer();
        customer1 = entityManager.persist(customer1);

        Customer customer2 = buildCustomer();
        customer2 = entityManager.persist(customer2);

        Customer customer3 = buildCustomer();
        customer3 = entityManager.persist(customer3);

        final CustomerOrder customerOrder1 = entityManager.persist(customerOrderBuilder()
                .customer(customer1)
                .orderNumber("11001")
                .lineItems(emptyList())
                .shipDate(shipDate1)
                .build());

        customerOrder2 = entityManager.persist(customerOrderBuilder()
                .customer(customer2)
                .orderNumber("11002")
                .lineItems(emptyList())
                .shipDate(shipDate2)
                .build());

        final CustomerOrder customerOrder3 = entityManager.persist(customerOrderBuilder()
                .customer(customer3)
                .orderNumber("11003")
                .lineItems(emptyList())
                .shipDate(shipDate3)
                .build());

        final Station stationInRoomA = entityManager.persist(stationBuilder()
                .room(roomA)
                .build());
        final Station stationInRoomB = entityManager.persist(stationBuilder()
                .room(roomB)
                .stationCode(123)
                .build());

        final PortionRoomTable tableInRoomA = entityManager.persist(portionRoomTableBuilder()
                .station(stationInRoomA)
                .build());
        final PortionRoomTable tableInRoomB = entityManager.persist(portionRoomTableBuilder()
                .station(stationInRoomB)
                .tableCode(123)
                .build());

        portionRoomProductInRoomA = entityManager.persist(productBuilder().table(tableInRoomA).build());
        final Product portionRoomProductInRoomB = entityManager.persist(productBuilder()
                .code("123")
                .table(tableInRoomB)
                .build());
        final Product nonPortionRoomProductInRoomA = entityManager.persist(productBuilder()
                .code("124")
                .table(tableInRoomA)
                .productOutput(ProductOutput.SOURCE)
                .build());

        entityManager.persist(lineItemBuilder()
                .customerOrder(customerOrder1)
                .product(portionRoomProductInRoomB)
                .build());

        entityManager.persist(lineItemBuilder()
                .customerOrder(customerOrder1)
                .product(nonPortionRoomProductInRoomA)
                .build());

        entityManager.persist(lineItemBuilder()
                .product(portionRoomProductInRoomA)
                .customerOrder(customerOrder3)
                .build());

        final LineItem validLineItem1 = entityManager.persist(lineItemBuilder()
                .customerOrder(customerOrder1)
                .lineNumber(1)
                .product(portionRoomProductInRoomA)
                .build());

        final LineItem validLineItem2 = entityManager.persist(lineItemBuilder()
                .product(portionRoomProductInRoomA)
                .lineNumber(2)
                .customerOrder(customerOrder2)
                .build());

        entityManager.flush();
        lineItemList = asList(validLineItem1, validLineItem2);
    }

    @Test
    public void shouldFindLineItemsByGivenRoomAndDate() {
        final List<LineItem> result = repository
                .findByCustomerOrderShipDateBetweenAndProductTableStationRoomCodeAndProductProductOutputInAndDeletedIsFalseAndCustomerOrderCancelledIsFalseAndCustomerOrderOnHoldIsFalse(
                        shipDate1, shipDate2, "A", singletonList(ProductOutput.FINISHED));

        assertThat(lineItemList, containsInAnyOrder(result.toArray()));
    }

    @Test
    public void shouldNotFindDeletedLineItem() {
        entityManager.persist(lineItemBuilder()
                .product(portionRoomProductInRoomA)
                .lineNumber(3)
                .deleted(true)
                .customerOrder(customerOrder2)
                .build());

        entityManager.flush();
        final List<LineItem> result = repository
                .findByCustomerOrderShipDateBetweenAndProductTableStationRoomCodeAndProductProductOutputInAndDeletedIsFalseAndCustomerOrderCancelledIsFalseAndCustomerOrderOnHoldIsFalse(
                        shipDate1, shipDate2, "A", singletonList(ProductOutput.FINISHED));

        assertThat(lineItemList, containsInAnyOrder(result.toArray()));
    }
}
