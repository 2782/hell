package com.sysco.prime;

import com.sysco.prime.batch.BatchNumber;
import com.sysco.prime.batch.BatchNumberRepository;
import com.sysco.prime.portionRoom.PortionRoom;
import org.junit.Before;
import org.junit.Test;

import static com.sysco.prime.DummyObjectFactory.buildPortionRoom;
import static com.sysco.prime.batch.BatchNumber.resetBatchNumber;
import static java.util.Arrays.asList;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

public class BatchNumberRepositoryTest extends RepositoryTestBase<BatchNumber, BatchNumberRepository> {
    private PortionRoom portionRoom;

    @Before
    public void setUp() {
        portionRoom = saveAndReadBack(buildPortionRoom());
    }

    @Test
    public void shouldRoundtrip() {
        final BatchNumber unsaved = BatchNumber.builder()
                .portionRoom(portionRoom)
                .lastBatchNumber(2)
                .build();

        final BatchNumber readBack = saveAndReadBack(unsaved);

        assertThat(readBack, is(unsaved));
    }

    @Test
    public void shouldFetchNextBatchNumber() {
        saveAndReadBack(resetBatchNumber(portionRoom));

        for (final int n : asList(1, 2, 3)) {
            assertThat(repository.nextBatchNumber(portionRoom), is(n));
        }
    }
}
