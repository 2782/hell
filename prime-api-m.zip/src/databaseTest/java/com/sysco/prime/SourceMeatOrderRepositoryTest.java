package com.sysco.prime;

import com.sysco.prime.sourceMeat.SourceMeatOrder;
import com.sysco.prime.sourceMeat.SourceMeatOrderRepository;
import org.junit.Test;

import java.time.LocalDate;

import static com.sysco.prime.DummyObjectFactory.sourceMeatOrderBuilder;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;
import static org.junit.Assert.assertThat;

public class SourceMeatOrderRepositoryTest extends RepositoryTestBase<SourceMeatOrder, SourceMeatOrderRepository> {
    @Test
    public void shouldRoundtripPrimeSourceMeatOrder() {
        final SourceMeatOrder order = sourceMeatOrderBuilder()
                .roomCode("A")
                .workingDate(LocalDate.now())
                .build();

        final SourceMeatOrder saved = saveAndReadBack(order);
        final SourceMeatOrder readBack = repository.getOneOrNull(saved.getId());

        assertThat(readBack.getUomOrderNumber(), is(notNullValue()));
        assertThat(readBack, is(equalTo(saved)));
    }
}
