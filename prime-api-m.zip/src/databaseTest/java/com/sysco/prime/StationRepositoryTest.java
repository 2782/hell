package com.sysco.prime;

import com.sysco.prime.portionRoom.PortionRoom;
import com.sysco.prime.portionRoomTable.PortionRoomTable;
import com.sysco.prime.station.Station;
import com.sysco.prime.station.StationRepository;
import com.sysco.prime.station.StationType;
import org.junit.Before;
import org.junit.Test;

import java.time.LocalTime;

import static com.google.common.collect.Lists.newArrayList;
import static com.sysco.prime.DummyObjectFactory.portionRoomBuilder;
import static com.sysco.prime.station.StationType.PACKOFF;
import static com.sysco.prime.station.StationType.PRODUCTION;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.Matchers.hasSize;
import static org.junit.Assert.assertThat;

public class StationRepositoryTest extends RepositoryTestBase<Station, StationRepository> {
    @Before
    public void setUp() {
        final PortionRoom roomA = entityManager.persist(portionRoomBuilder()
                .code("A")
                .build());
        final PortionRoom roomB = entityManager.persist(portionRoomBuilder()
                .code("B")
                .build());
        final Station station17 = Station.builder()
                .name("Alec Baldwin")
                .room(roomB)
                .stationCode(17)
                .printer("PRINTER-17")
                .userId(null)
                .type(PRODUCTION)
                .build();
        final Station station2 = Station.builder()
                .name("Bruce Willis")
                .room(roomA)
                .stationCode(2)
                .printer("PRINTER-2")
                .userId(null)
                .type(PRODUCTION)
                .build();
        final Station station5 = Station.builder()
                .name("Naomi Watts")
                .room(roomA)
                .stationCode(5)
                .printer("PRINTER-5")
                .userId("user-id")
                .type(PACKOFF)
                .build();
        final PortionRoomTable table9 = PortionRoomTable.builder()
                .tableCode(9)
                .tableDescription("Table 9")
                .tableOpenTime(LocalTime.parse("08:00"))
                .tableCloseTime(LocalTime.parse("16:00"))
                .poundsPerHour(100)
                .build();
        final PortionRoomTable table4 = PortionRoomTable.builder()
                .tableCode(4)
                .tableDescription("Table 4")
                .tableOpenTime(LocalTime.parse("08:00"))
                .tableCloseTime(LocalTime.parse("16:00"))
                .poundsPerHour(100)
                .build();
        final PortionRoomTable table64 = PortionRoomTable.builder()
                .tableCode(64)
                .tableDescription("Table 64")
                .tableOpenTime(LocalTime.parse("08:00"))
                .tableCloseTime(LocalTime.parse("16:00"))
                .poundsPerHour(100)
                .build();

        entityManager.persist(table9);
        entityManager.persist(table4);
        entityManager.persist(table64);
        station17.setPortionRoomTables(newArrayList(table9, table4, table64));
        station5.setPortionRoomTables(newArrayList(table64, table9));
        entityManager.persist(station17);
        entityManager.persist(station2);
        entityManager.persist(station5);

        entityManager.flush();
    }

    @Test
    public void shouldOnlyFindStationsForARoom() {
        assertThat(repository.findByRoomCode("A"), hasSize(2));
    }

    @Test
    public void shouldReturnStationByUserId() {
        final Station station = repository.findByUserId("user-id").get();

        assertThat(station.getName(), is("Naomi Watts"));
        assertThat(station.getType(), is(PACKOFF));
    }

    @Test
    public void shouldReturnStationByUserIdAndType() {
        final Station station = repository.findByUserIdAndType("user-id", StationType.PACKOFF).get();

        assertThat(station.getName(), is("Naomi Watts"));
        assertThat(station.getType(), is(PACKOFF));
    }
}
