package com.sysco.prime;

import com.sysco.prime.portionRoom.PortionRoom;
import com.sysco.prime.portionRoom.PortionRoomRepository;
import org.junit.Test;

import static com.sysco.prime.DummyObjectFactory.portionRoomBuilder;
import static java.util.Collections.emptyList;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

public class PortionRoomRepositoryTest extends RepositoryTestBase<PortionRoom, PortionRoomRepository> {
    @Test
    public void shouldRoundtrip() {
        final PortionRoom room = portionRoomBuilder()
                .stations(emptyList())
                .build();

        final PortionRoom saved = saveAndReadBack(room);
        final PortionRoom readBack = repository.getOneOrNull(saved.getId());

        assertThat(readBack, is(equalTo(saved)));
    }
}
