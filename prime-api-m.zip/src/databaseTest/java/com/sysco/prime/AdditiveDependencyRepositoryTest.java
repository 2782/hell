package com.sysco.prime;

import com.sysco.prime.cost.Money;
import com.sysco.prime.product.Product;
import com.sysco.prime.product.ProductOutput;
import com.sysco.prime.yieldModel.AdditiveDependency;
import com.sysco.prime.yieldModel.AdditiveDependencyRepository;
import com.sysco.prime.yieldModel.CuttingYieldModelCopy;
import com.sysco.prime.yieldModel.YieldModelFactory;
import org.junit.Assert;
import org.junit.Test;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import static com.sysco.prime.DummyObjectFactory.productBuilder;
import static java.math.BigDecimal.ROUND_HALF_UP;
import static java.util.Collections.emptySet;
import static java.util.Collections.singleton;
import static org.hamcrest.CoreMatchers.is;

public class AdditiveDependencyRepositoryTest extends
        RepositoryTestBase<AdditiveDependency, AdditiveDependencyRepository> {

    @Test
    public void shouldFindAdditiveDependenciesByProductCodeCorrespondingToAllModels() {
        final Product finishedProduct = productBuilder()
                .minWeight(BigDecimal.valueOf(1.0d).setScale(5, ROUND_HALF_UP))
                .maxWeight(BigDecimal.valueOf(25.0d).setScale(5, ROUND_HALF_UP))
                .code("1961172")
                .productOutput(ProductOutput.FINISHED)
                .build();
        final Product finishedProductTwo = productBuilder()
                .code("7734412")
                .productOutput(ProductOutput.FINISHED)
                .build();
        final Product finishedProductThree = productBuilder()
                .code("4102218")
                .productOutput(ProductOutput.FINISHED)
                .build();
        final Product additive = YieldModelFactory.additiveProduct();

        final AdditiveDependency additiveDependency = AdditiveDependency.builder()
                .product(additive)
                .build();
        final CuttingYieldModelCopy model1 = CuttingYieldModelCopy.builder()
                .finishedProduct(finishedProduct)
                .yieldByproducts(emptySet())
                .ingredients("Soy,milk,love")
                .labor(Money.ofCost(BigDecimal.ONE))
                .overhead(Money.ofCost(BigDecimal.ONE))
                .packaging(Money.ofCost(BigDecimal.ONE))
                .pickupPercent(BigDecimal.TEN)
                .pricingModel(true)
                .sourceLbs(BigDecimal.TEN.setScale(3, RoundingMode.HALF_UP))
                .yieldAdditives(singleton(additiveDependency))
                .build();

        additiveDependency.setOwner(model1);

        entityManager.persist(model1);

        final AdditiveDependency additiveDependencyTwo = AdditiveDependency.builder()
                .product(additive)
                .build();
        final CuttingYieldModelCopy model2 = CuttingYieldModelCopy.builder()
                .finishedProduct(finishedProductTwo)
                .yieldByproducts(emptySet())
                .ingredients("Soy,milk,fear")
                .labor(Money.ofCost(BigDecimal.TEN))
                .overhead(Money.ofCost(BigDecimal.TEN))
                .packaging(Money.ofCost(BigDecimal.TEN))
                .pickupPercent(BigDecimal.TEN)
                .pricingModel(true)
                .sourceLbs(BigDecimal.TEN.setScale(3, RoundingMode.HALF_UP))
                .yieldAdditives(singleton(additiveDependencyTwo))
                .build();
        additiveDependencyTwo.setOwner(model2);

        entityManager.persist(model2);

        final AdditiveDependency additiveDependencyThree = AdditiveDependency.builder()
                .product(additive)
                .build();
        // Not a Pricing Model
        final CuttingYieldModelCopy model3 = CuttingYieldModelCopy.builder()
                .finishedProduct(finishedProductThree)
                .yieldByproducts(emptySet())
                .ingredients("Soy,milk,fear")
                .labor(Money.ofCost(BigDecimal.TEN))
                .overhead(Money.ofCost(BigDecimal.TEN))
                .packaging(Money.ofCost(BigDecimal.TEN))
                .pickupPercent(BigDecimal.TEN)
                .pricingModel(false)
                .sourceLbs(BigDecimal.TEN.setScale(3, RoundingMode.HALF_UP))
                .yieldAdditives(singleton(additiveDependencyThree))
                .build();
        additiveDependencyThree.setOwner(model3);

        entityManager.persist(model3);
        entityManager.flush();

        final String additiveCode = additive.getCode();

        final List<AdditiveDependency> readBack = repository.findByProduct_Code(additiveCode);

        Assert.assertThat(readBack.stream()
                .map(AdditiveDependency::getOwner)
                .collect(Collectors.toList()), is(Arrays.asList(model1, model2, model3)));
    }
}