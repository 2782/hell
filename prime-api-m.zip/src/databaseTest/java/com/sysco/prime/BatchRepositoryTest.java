package com.sysco.prime;

import com.sysco.prime.batch.Batch;
import com.sysco.prime.batch.BatchRepository;
import com.sysco.prime.batch.BatchSourceMeat;
import com.sysco.prime.portionRoom.PortionRoom;
import com.sysco.prime.product.Product;
import com.sysco.prime.productionOrder.Blend;
import org.junit.Test;

import java.time.LocalDate;
import java.time.LocalTime;

import static com.sysco.prime.DummyObjectFactory.buildBatchFinishedProduct;
import static com.sysco.prime.DummyObjectFactory.buildBatchIngredient;
import static com.sysco.prime.DummyObjectFactory.buildPortionRoom;
import static com.sysco.prime.DummyObjectFactory.buildProduct;
import static com.sysco.prime.product.GrindSize.THREE_SIXTEEN;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

public class BatchRepositoryTest extends RepositoryTestBase<Batch, BatchRepository> {
    @Test
    public void shouldRoundtrip() {
        final PortionRoom portionRoom = entityManager.persistFlushFind(buildPortionRoom());
        final Product sourceProduct = entityManager.persistFlushFind(buildProduct().toBuilder()
                .code("1234567")
                .build());
        final Product ingredientsProduct = entityManager.persistFlushFind(buildProduct().toBuilder()
                .code("1010101")
                .build());
        final Product finishedProduct = entityManager.persistFlushFind(buildProduct().toBuilder()
                .code("0101010")
                .build());
        final Blend blend = entityManager.find(Blend.class, 1L);

        final Batch unsaved = Batch.builder()
                .allergens(true)
                .batchNumber(1234)
                .blend(blend)
                .finished(true)
                .finishedBatchTemp(32.7d)
                .grindSize(/* JOHN */ THREE_SIXTEEN)
                .portionRoom(portionRoom)
                .productionDate(LocalDate.of(1999, 12, 31))
                .startBatchTemp(31.9d)
                .tumbler("Left side, down the hall")
                .tumblerStartTime(LocalTime.of(11, 32, 9))
                .tumblerStopTime(LocalTime.of(12, 1, 44))
                .build();
        unsaved.addIngredient(buildBatchIngredient().toBuilder()
                .ingredientProduct(ingredientsProduct)
                .build());
        unsaved.addFinishedProduct(buildBatchFinishedProduct().toBuilder()
                .finishedProduct(finishedProduct)
                .build());
        unsaved.addSourceMeat(BatchSourceMeat.builder()
                .actualLbs(11.1d)
                .establishmentNumber("6666666")
                .harvestDate(LocalDate.of(1999, 12, 20))
                .lotNumber("555555")
                .meatTemp(31.1d)
                .poNumber("827374")
                .sourceProduct(sourceProduct)
                .vendor("BOB'S MEAT EMPORIUM AND GIFT SHOP")
                .build());


        final Batch readBack = saveAndReadBack(unsaved);

        assertThat(readBack, is(unsaved));
    }
}
