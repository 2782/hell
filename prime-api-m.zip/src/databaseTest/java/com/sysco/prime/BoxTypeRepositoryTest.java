package com.sysco.prime;

import com.sysco.prime.packages.BoxType;
import com.sysco.prime.packages.BoxTypeRepository;
import org.junit.Test;

import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

public class BoxTypeRepositoryTest extends RepositoryTestBase<BoxType, BoxTypeRepository> {
    @Test
    public void shouldRoundtrip() {
        final BoxType boxType = BoxType.builder()
                .boxDescription("I'm only a box")
                .boxTare(12.34d)
                .build();

        final BoxType saved = saveAndReadBack(boxType);
        final BoxType readBack = repository.getOneOrNull(saved.getId());

        assertThat(readBack, is(equalTo(saved)));
    }
}
