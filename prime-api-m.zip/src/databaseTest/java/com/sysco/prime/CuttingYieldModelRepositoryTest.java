package com.sysco.prime;

import com.sysco.prime.product.Product;
import com.sysco.prime.yieldModel.CuttingYieldAdditive;
import com.sysco.prime.yieldModel.CuttingYieldByproduct;
import com.sysco.prime.yieldModel.CuttingYieldModel;
import com.sysco.prime.yieldModel.CuttingYieldModelRepository;
import org.junit.Before;
import org.junit.Test;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

import static com.google.common.collect.Lists.newArrayList;
import static com.sysco.prime.DummyObjectFactory.cuttingYieldAdditiveBuilder;
import static com.sysco.prime.DummyObjectFactory.cuttingYieldByproductBuilder;
import static com.sysco.prime.DummyObjectFactory.cuttingYieldModelBuilder;
import static com.sysco.prime.DummyObjectFactory.productBuilder;
import static com.sysco.prime.utils.SetUtils.asSet;
import static com.sysco.prime.utils.SetUtils.first;
import static java.util.Arrays.asList;
import static java.util.Collections.singleton;
import static java.util.Collections.singletonList;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.hamcrest.Matchers.hasSize;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

public class CuttingYieldModelRepositoryTest extends
        RepositoryTestBase<CuttingYieldModel, CuttingYieldModelRepository> {
    private static final String productOneCode = "0078889";
    private static final String productTwoCode = "0078891";
    private static final String productThreeCode = "0214101";
    private CuttingYieldModel savedYieldModelOne;

    @Before
    public void setup() {
        final Product yieldProduct = productBuilder().code(productOneCode).build();
        final Product sourceProduct = productBuilder().code(productTwoCode).build();
        final Product productThree = productBuilder().code(productThreeCode).build();

        final CuttingYieldAdditive yieldAdditive = CuttingYieldAdditive.builder()
                .productCode("4181840")
                .weight(BigDecimal.valueOf(30.0d))
                .build();

        final CuttingYieldModel yieldModelOne = cuttingYieldModelBuilder()
                .finishedProductCode(productOneCode)
                .sourceProductCode(productTwoCode)
                .labor(new BigDecimal("1.11"))
                .finishedProductCost(BigDecimal.valueOf(17.65d))
                .pricingModel(true)
                .yieldAdditives(singleton(yieldAdditive))
                .build();

        final CuttingYieldModel yieldModelTwo = cuttingYieldModelBuilder()
                .finishedProductCode(productTwoCode)
                .sourceProductCode(productOneCode)
                .labor(new BigDecimal("11.01"))
                .finishedProductCost(BigDecimal.valueOf(45.32d))
                .pricingModel(false)
                .build();

        final CuttingYieldModel yieldModelThree = cuttingYieldModelBuilder()
                .finishedProductCode(productOneCode)
                .sourceProductCode(productThreeCode)
                .labor(new BigDecimal("11.11"))
                .finishedProductCost(BigDecimal.valueOf(33.01d))
                .pricingModel(false)
                .build();

        entityManager.persist(yieldProduct);
        entityManager.persist(sourceProduct);
        entityManager.persist(productThree);
        savedYieldModelOne = entityManager.persist(yieldModelOne);
        entityManager.persist(yieldModelTwo);
        entityManager.persist(yieldModelThree);
        entityManager.flush();
    }

    @Test
    public void shouldFindByYieldProductCodeAndSourceProductCode() {
        final Optional<CuttingYieldModel> result = repository
                .findByFinishedProductCodeAndSourceProductCode(productOneCode, productTwoCode);

        assertThat(result.isPresent(), is(true));

        final CuttingYieldModel yieldModel = result.get();
        assertThat(yieldModel.getLabor(), is(BigDecimal.valueOf(1.11)));
        assertThat(yieldModel.getFinishedProductCost(), is(BigDecimal.valueOf(17.65d)));
        assertThat(yieldModel.isPricingModel(), is(true));
        assertThat(yieldModel.getFinishedProductCode(), is(productOneCode));
        assertThat(yieldModel.getSourceProductCode(), is(productTwoCode));
        assertThat(first(yieldModel.getYieldByproducts()).getYieldPercentage(), is(BigDecimal.valueOf(10.0)));
        assertThat(yieldModel.getYieldAdditives().stream().findFirst().get().getWeight(), is(BigDecimal.valueOf(30.0)));
        assertThat(yieldModel.getYieldAdditives().size(), is(1));
    }

    @Test
    public void shouldFindById() {
        final Optional<CuttingYieldModel> result = repository.findById(savedYieldModelOne.getId());

        assertThat(result.isPresent(), is(true));

        final CuttingYieldModel yieldModel = result.get();
        assertThat(yieldModel.getLabor(), is(BigDecimal.valueOf(1.11)));
        assertThat(yieldModel.getFinishedProductCost(), is(BigDecimal.valueOf(17.65d)));
        assertThat(yieldModel.isPricingModel(), is(true));
        assertThat(yieldModel.getFinishedProductCode(), is(productOneCode));
        assertThat(yieldModel.getSourceProductCode(), is(productTwoCode));
        assertThat(first(yieldModel.getYieldByproducts()).getYieldPercentage(), is(BigDecimal.valueOf(10.0)));
        assertThat(yieldModel.getYieldAdditives().stream().findFirst().get().getWeight(), is(BigDecimal.valueOf(30.0)));
        assertThat(yieldModel.getYieldAdditives().size(), is(1));
    }

    @Test
    public void shouldFindByYieldProductCodeAndIsPricingModelTrue() {
        final Optional<CuttingYieldModel> result = repository
                .findByFinishedProductCodeAndPricingModelTrue(productOneCode);

        assertThat(result.isPresent(), is(true));

        final CuttingYieldModel yieldModel = result.get();
        assertThat(yieldModel.getLabor(), is(BigDecimal.valueOf(1.11)));
        assertThat(yieldModel.getFinishedProductCost(), is(BigDecimal.valueOf(17.65d)));
        assertThat(yieldModel.isPricingModel(), is(true));
        assertThat(yieldModel.getFinishedProductCode(), is(productOneCode));
        assertThat(yieldModel.getSourceProductCode(), is(productTwoCode));
    }

    @Test
    public void shouldGetYieldModelWithCorrectSchema() {
        final List<CuttingYieldModel> yieldModelList = repository.findAll();

        final CuttingYieldModel yieldModel = yieldModelList.get(0);
        assertThat(yieldModel.getLabor(), is(BigDecimal.valueOf(1.11)));
        assertThat(yieldModel.getFinishedProductCost(), is(BigDecimal.valueOf(17.65d)));
        assertThat(yieldModel.isPricingModel(), is(true));
        assertThat(yieldModel.getFinishedProductCode(), is(productOneCode));
        assertThat(yieldModel.getSourceProductCode(), is(productTwoCode));
    }

    @Test
    public void shouldGetYieldModelsWhenQueryByFinishedProductCodes() {
        final List<CuttingYieldModel> yieldModelList = repository
                .findByFinishedProductCodeIn(newArrayList(productTwoCode, "productCodeWithoutYieldModel"));

        assertThat(yieldModelList.size(), is(1));
        assertThat(yieldModelList.get(0).getFinishedProductCode(), is("0078891"));
    }

    @Test
    public void shouldRoundtrip() {
        final CuttingYieldModel model = CuttingYieldModel.builder()
                .finishedProductCode(productThreeCode)
                .sourceProductCode(productTwoCode)
                .pricingModel(true)
                .yieldByproducts(singleton(CuttingYieldByproduct.builder()
                        .cost(new BigDecimal("10.00"))
                        .byproductCode(productOneCode)
                        .yieldPercentage(BigDecimal.valueOf(100d))
                        .build()))
                .ingredients("TASTY BITS")
                .overhead(new BigDecimal("4.44"))
                .packaging(new BigDecimal("5.55"))
                .build();
        model.getYieldByproducts().forEach(byproduct -> byproduct.setYieldModel(model));

        final CuttingYieldModel saved = saveAndReadBack(model);
        final CuttingYieldModel readBack = repository.getOneOrNull(saved.getId());

        assertThat(readBack, is(saved));
        // Extra check for the @MappedSuperclass fields
        assertThat(readBack.getPackaging(), is(saved.getPackaging()));
    }

    @Test
    public void shouldFindExistingPricingModelForAFinishedProductSourceProductCombination() {
        final Optional<CuttingYieldModel> pricingModel =
                repository.findByFinishedProductCodeAndSourceProductCodeAndPricingModelTrue(
                        productOneCode, productTwoCode);

        final Optional<CuttingYieldModel> noPricingModel =
                repository.findByFinishedProductCodeAndSourceProductCodeAndPricingModelTrue(
                        productTwoCode, productOneCode);

        assertTrue(pricingModel.isPresent());
        assertFalse(noPricingModel.isPresent());
    }

    @Test
    public void shouldReturnCuttingYieldModelsBySourceOrByproductCode() {
        final String sourceProductCode2 = "SOURCE_CODE_2";
        final String byproductCode1 = "BYPRODUCT_CODE_1";
        final String byproductCode2 = "BYPRODUCT_CODE_2";
        final String additiveCode1 = "ADDITIVE_CODE_1";
        final String additiveCode2 = "ADDITIVE_CODE_2";

        entityManager.persist(productBuilder()
                .code("FINISHED_CODE_1")
                .build());
        entityManager.persist(productBuilder()
                .code("FINISHED_CODE_2")
                .build());
        entityManager.persist(productBuilder()
                .code("FINISHED_CODE_3")
                .build());
        entityManager.persist(productBuilder()
                .code("SOURCE_CODE_1")
                .build());
        entityManager.persist(productBuilder()
                .code(sourceProductCode2)
                .build());
        entityManager.persist(productBuilder()
                .code("SOURCE_CODE_3")
                .build());
        entityManager.persist(productBuilder()
                .code(byproductCode1)
                .build());
        entityManager.persist(productBuilder()
                .code(byproductCode2)
                .build());
        entityManager.persist(productBuilder()
                .code(additiveCode1)
                .build());
        entityManager.persist(productBuilder()
                .code(additiveCode2)
                .build());

        final CuttingYieldModel yieldModelWithByproductCode = entityManager.persist(cuttingYieldModelBuilder()
                .finishedProductCode("FINISHED_CODE_1")
                .sourceProductCode("SOURCE_CODE_1")
                .yieldByproducts(asSet(
                        cuttingYieldByproductBuilder()
                                .byproductCode(byproductCode1)
                                .build(),
                        cuttingYieldByproductBuilder()
                                .byproductCode(byproductCode2)
                                .build()))
                .build());
        final CuttingYieldModel yieldModelWithSourceCode = entityManager.persist(cuttingYieldModelBuilder()
                .finishedProductCode("FINISHED_CODE_2")
                .sourceProductCode(sourceProductCode2)
                .build());
        final CuttingYieldModel yieldModelWithAdditiveCode = entityManager.persist(cuttingYieldModelBuilder()
                .finishedProductCode("FINISHED_CODE_3")
                .sourceProductCode("SOURCE_CODE_3")
                .yieldAdditives(asSet(
                        cuttingYieldAdditiveBuilder()
                                .productCode(additiveCode1)
                                .build(),
                        cuttingYieldAdditiveBuilder()
                                .productCode(additiveCode2)
                                .build()
                ))
                .build());
        entityManager.flush();

        final List<CuttingYieldModel> actual = repository.findBySourceProductCodeOrByproductCodeOrAdditiveCodeIn(
                asList(byproductCode2, sourceProductCode2, additiveCode1));

        assertThat(actual, hasSize(3));
        assertThat(actual, containsInAnyOrder(
                yieldModelWithByproductCode,
                yieldModelWithSourceCode,
                yieldModelWithAdditiveCode));
    }
}
