package com.sysco.prime;

import com.sysco.prime.packages.FilmType;
import com.sysco.prime.packages.FilmTypeRepository;
import org.junit.Test;

import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

public class FilmTypeRepositoryTest extends RepositoryTestBase<FilmType, FilmTypeRepository> {
    @Test
    public void shouldRoundtrip() {
        final FilmType filmType = FilmType.builder()
                .filmDescription("Black and white is artsy")
                .filmTare(12.34d)
                .build();

        final FilmType saved = saveAndReadBack(filmType);
        final FilmType readBack = repository.getOneOrNull(saved.getId());

        assertThat(readBack, is(equalTo(saved)));
    }
}
