package com.sysco.prime;

import com.sysco.prime.cost.Money;
import com.sysco.prime.product.Product;
import com.sysco.prime.product.ProductOutput;
import com.sysco.prime.yieldModel.CuttingSourceDependency;
import com.sysco.prime.yieldModel.CuttingSourceDependencyRepository;
import com.sysco.prime.yieldModel.CuttingYieldModelCopy;
import com.sysco.prime.yieldModel.PointsTo;
import org.junit.Assert;
import org.junit.Test;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import static com.sysco.prime.DummyObjectFactory.productBuilder;
import static com.sysco.prime.yieldModel.YieldModelFactory.sourceProduct;
import static java.math.BigDecimal.ROUND_HALF_UP;
import static java.util.Collections.emptySet;
import static org.hamcrest.CoreMatchers.is;

public class CuttingSourceDependencyRepositoryTest extends
        RepositoryTestBase<CuttingSourceDependency, CuttingSourceDependencyRepository> {

    @Test
    public void shouldFindSourceDependenciesByProductCodeCorrespondingToTwoPricingModels() {
        final Product finishedProduct = productBuilder()
                .minWeight(BigDecimal.valueOf(1.0d).setScale(5, ROUND_HALF_UP))
                .maxWeight(BigDecimal.valueOf(25.0d).setScale(5, ROUND_HALF_UP))
                .code("1961172")
                .productOutput(ProductOutput.FINISHED)
                .build();
        final Product finishedProductTwo = productBuilder()
                .code("7734412")
                .productOutput(ProductOutput.FINISHED)
                .build();
        final Product finishedProductThree = productBuilder()
                .code("4102218")
                .productOutput(ProductOutput.FINISHED)
                .build();
        final Product sourceProduct = sourceProduct();

        final CuttingSourceDependency sourceDependency = CuttingSourceDependency.builder()
                .pointsTo(PointsTo.COST)
                .product(sourceProduct)
                .build();
        final CuttingYieldModelCopy model1 = CuttingYieldModelCopy.builder()
                .finishedProduct(finishedProduct)
                .sourceProduct(sourceDependency)
                .yieldAdditives(emptySet())
                .yieldByproducts(emptySet())
                .ingredients("Soy,milk,love")
                .labor(Money.ofCost(BigDecimal.ONE))
                .overhead(Money.ofCost(BigDecimal.ONE))
                .packaging(Money.ofCost(BigDecimal.ONE))
                .pickupPercent(BigDecimal.TEN)
                .pricingModel(true)
                .sourceLbs(BigDecimal.TEN.setScale(3, RoundingMode.HALF_UP))
                .build();

        sourceDependency.setOwner(model1);

        entityManager.persist(model1);

        final CuttingSourceDependency sourceDependencyTwo = CuttingSourceDependency.builder()
                .pointsTo(PointsTo.COST)
                .product(sourceProduct)
                .build();
        final CuttingYieldModelCopy model2 = CuttingYieldModelCopy.builder()
                .finishedProduct(finishedProductTwo)
                .sourceProduct(sourceDependencyTwo)
                .yieldAdditives(emptySet())
                .yieldByproducts(emptySet())
                .ingredients("Soy,milk,fear")
                .labor(Money.ofCost(BigDecimal.TEN))
                .overhead(Money.ofCost(BigDecimal.TEN))
                .packaging(Money.ofCost(BigDecimal.TEN))
                .pickupPercent(BigDecimal.TEN)
                .pricingModel(true)
                .sourceLbs(BigDecimal.TEN.setScale(3, RoundingMode.HALF_UP))
                .build();
        sourceDependencyTwo.setOwner(model2);

        entityManager.persist(model2);

        final CuttingSourceDependency sourceDependencyThree = CuttingSourceDependency.builder()
                .pointsTo(PointsTo.COST)
                .product(sourceProduct)
                .build();
        final CuttingYieldModelCopy model3 = CuttingYieldModelCopy.builder()
                .finishedProduct(finishedProductThree)
                .sourceProduct(sourceDependencyThree)
                .yieldAdditives(emptySet())
                .yieldByproducts(emptySet())
                .ingredients("Soy,milk,fear")
                .labor(Money.ofCost(BigDecimal.TEN))
                .overhead(Money.ofCost(BigDecimal.TEN))
                .packaging(Money.ofCost(BigDecimal.TEN))
                .pickupPercent(BigDecimal.TEN)
                .pricingModel(false)
                .sourceLbs(BigDecimal.TEN.setScale(3, RoundingMode.HALF_UP))
                .build();
        sourceDependencyThree.setOwner(model3);

        entityManager.persist(model3);
        entityManager.flush();

        final String sourceProductCode = sourceProduct.getCode();

        final List<CuttingSourceDependency> readBack = repository.findByProduct_Code(sourceProductCode);

        Assert.assertThat(readBack.stream()
                .map(CuttingSourceDependency::getOwner)
                .collect(Collectors.toList()), is(Arrays.asList(model1, model2, model3)));
    }
}
