package com.sysco.prime.product.validation;

import com.sysco.prime.cost.CostService;
import com.sysco.prime.product.Product;
import com.sysco.prime.product.ProductService;
import com.sysco.prime.validation.ValidationErrorType;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import javax.validation.ConstraintValidatorContext;
import javax.validation.ConstraintValidatorContext.ConstraintViolationBuilder;

import static com.sysco.prime.DummyObjectFactory.buildCost;
import static com.sysco.prime.DummyObjectFactory.productBuilder;
import static com.sysco.prime.validation.ValidationErrorType.INVALID_COST;
import static junit.framework.TestCase.assertTrue;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class CostValidatorTest {
    private final Product product = productBuilder().code("0077889").build();

    private final ConstraintViolationBuilder builder = mock(ConstraintViolationBuilder.class);
    private final ConstraintValidatorContext context = mock(ConstraintValidatorContext.class);

    @Mock
    private ProductService productService;
    @Mock
    private CostService costService;

    private CostValidator costValidator;

    @Before
    public void given() {
        when(context.buildConstraintViolationWithTemplate(anyString())).thenReturn(builder);
        costValidator = new CostValidator(productService, costService);
    }

    @Test
    public void shouldThrowExceptionWhenCostNotFound() {
        when(productService.findByCode("0077889")).thenReturn(product);
        when(costService.findCost(product)).thenReturn(null);

        assertFalse(costValidator.isValid("0077889", context));
        verify(context).buildConstraintViolationWithTemplate(ValidationErrorType.INVALID_COST.toString());
    }

    @Test
    public void shouldValidateCostSuccessfullyWhenCostIsAvailable() {
        when(productService.findByCode("0077889")).thenReturn(product);
        when(costService.findCost(product)).thenReturn(buildCost());

        assertTrue(costValidator.isValid("0077889", context));
    }
}
