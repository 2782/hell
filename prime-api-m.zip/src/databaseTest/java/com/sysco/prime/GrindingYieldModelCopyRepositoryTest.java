package com.sysco.prime;

import com.sysco.prime.cost.CostService;
import com.sysco.prime.productionOrder.Blend;
import com.sysco.prime.yieldModel.GrindingSourceDependency;
import com.sysco.prime.yieldModel.GrindingYieldModelCopy;
import com.sysco.prime.yieldModel.GrindingYieldModelCopyRepository;
import com.sysco.prime.yieldModel.PointsTo;
import org.junit.Before;
import org.junit.Test;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Clock;
import java.time.LocalDate;
import java.util.List;

import static com.sysco.prime.utils.SetUtils.asSet;
import static com.sysco.prime.utils.TimeUtilsTest.mockClockToNow;
import static com.sysco.prime.yieldModel.YieldModelFactory.grindingAllCosts;
import static org.assertj.core.api.Java6Assertions.assertThat;
import static org.mockito.Mockito.mock;

public class GrindingYieldModelCopyRepositoryTest extends
        RepositoryTestBase<GrindingYieldModelCopy, GrindingYieldModelCopyRepository> {

    private CostService costService;
    private LocalDate date;
    private GrindingYieldModelCopy existingPricingModel;
    private GrindingYieldModelCopy existingModel;

    @Before
    public void setup() {
        final Clock when = mock(Clock.class);
        costService = mock(CostService.class);
        mockClockToNow(when);
        date = LocalDate.now(when);

        final Blend pricingBlend = entityManager.find(Blend.class, 1L);
        final Blend modelBlend = entityManager.find(Blend.class, 2L);

        GrindingYieldModelCopy pricingModel = grindingAllCosts(costService, date, null);
        pricingModel.setBlend(pricingBlend);

        final GrindingYieldModelCopy model = grindingAllCosts(costService, date, null);
        model.setSourceProducts(asSet(GrindingSourceDependency.builder()
                .pointsTo(PointsTo.COST)
                .blendPercentage(BigDecimal.TEN.setScale(3, RoundingMode.HALF_UP))
                .product(DummyObjectFactory.buildProduct())
                .build()));
        model.setPricingModel(false);

        model.setBlend(modelBlend);

        existingPricingModel = saveAndReadBack(pricingModel);
        existingModel = saveAndReadBack(model);
    }

    @Test
    public void shouldFetchExistingGrindingYieldModelByBlendName() {
        List<GrindingYieldModelCopy> byBlendName =
                repository.findByBlendName(existingPricingModel.getBlend().getName());

        assertThat(byBlendName).contains(existingPricingModel);
    }

    @Test
    public void shouldFetchExistingGrindingYieldModelByBlendNameAndPricingModelIsTrue() {
        GrindingYieldModelCopy byBlendNameAndPricingModelTrue =
                repository.findByBlendNameAndPricingModelTrue(existingPricingModel.getBlend().getName());

        assertThat(byBlendNameAndPricingModelTrue).isEqualTo(existingPricingModel);
    }

    @Test
    public void shouldNotFetchANonPricingModel() {
        GrindingYieldModelCopy byBlendNameAndPricingModelTrue =
                repository.findByBlendNameAndPricingModelTrue(existingModel.getBlend().getName());

        assertThat(byBlendNameAndPricingModelTrue).isNull();
    }
}
