package com.sysco.prime;

import com.sysco.prime.product.Product;
import com.sysco.prime.product.ProductGroup;
import com.sysco.prime.product.ProductGroupRepository;
import com.sysco.prime.product.ProductRepository;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import static com.sysco.prime.DummyObjectFactory.productBuilder;
import static com.sysco.prime.product.ProductGroup.cuttingProductGroup;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

public class ProductGroupRepositoryTest extends RepositoryTestBase<ProductGroup, ProductGroupRepository> {
    @Autowired
    private ProductRepository productRepository;

    private Product primaryProduct;
    private Product commonProduct;

    @Before
    public void setUp() {
        entityManager.clear();

        // TODO: Pick product names that *cannot* collide with existing - does this help?
        primaryProduct = entityManager.persist(productBuilder()
                .code("T916515")
                .productGroup(null)
                .build());
        commonProduct = entityManager.persist(productBuilder()
                .code("T204000")
                .productGroup(null)
                .build());
        entityManager.flush();
    }

    @Test
    public void shouldRoundtrip() {
        final ProductGroup productGroup = cuttingProductGroup(primaryProduct)
                .add(commonProduct);

        final ProductGroup saved = saveAndReadBack(productGroup);
        final ProductGroup readBack = repository.getOneOrNull(saved.getId());

        assertThat(readBack, is(saved));
    }
}