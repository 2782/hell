package com.sysco.prime;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectReader;
import com.sysco.prime.batch.BatchNumber;
import com.sysco.prime.customerOrder.OrderStatusSnapshot;
import com.sysco.prime.sus.eventProcessors.OrderStatusSnapshotRepository;
import org.junit.Test;

import java.io.IOException;
import java.util.Map;

import static com.sysco.prime.utils.TimeUtils.SUS_TIMESTAMP;
import static java.time.LocalDateTime.parse;
import static java.util.Collections.singletonList;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

public class OrderStatusSnapshotRepositoryTest extends RepositoryTestBase<OrderStatusSnapshot,
        OrderStatusSnapshotRepository> {

    @Test
    public void shouldRoundtrip() throws IOException {
        final String orderNumber = "5111";
        final String message = "{ \"message\": \"message\"}";
        final ObjectReader reader = new ObjectMapper().readerFor(Map.class);
        final OrderStatusSnapshot unsaved = OrderStatusSnapshot.builder()
                .message(reader.readValue(message))
                .orderNumber(orderNumber)
                .susCreatedOn(parse("2018-12-17 10:22:36", SUS_TIMESTAMP))
                .susModifiedOn(parse("2018-12-17 10:25:36", SUS_TIMESTAMP))
                .build();

        final OrderStatusSnapshot readBack = saveAndReadBack(unsaved);

        assertThat(readBack, is(unsaved));
    }

    @Test
    public void shouldFindByOrderNumber() throws IOException {
        final String orderNumber = "5111";
        final String message = "{ \"message\": \"message\"}";
        final ObjectReader reader = new ObjectMapper().readerFor(Map.class);
        final OrderStatusSnapshot snapshot = OrderStatusSnapshot.builder()
                .message(reader.readValue(message))
                .orderNumber(orderNumber)
                .susCreatedOn(parse("2018-12-17 10:22:36", SUS_TIMESTAMP))
                .susModifiedOn(parse("2018-12-17 10:25:36", SUS_TIMESTAMP))
                .build();

        repository.save(snapshot);

        assertThat(repository.findByOrderNumber(orderNumber).get(),
                is(snapshot));
    }
}