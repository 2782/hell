package com.sysco.prime;

import com.sysco.prime.saml.user.PrimeUserDetails;
import com.sysco.prime.saml.user.PrimeUserDetailsRepository;
import com.sysco.prime.saml.user.Role;
import org.junit.Test;

import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

public class PrimeUserDetailsRepositoryTest extends RepositoryTestBase<PrimeUserDetails, PrimeUserDetailsRepository> {
    @Test
    public void shouldRoundtrip() {
        final PrimeUserDetails userDetails = PrimeUserDetails.builder()
                .role(Role.ROLE_ADMIN)
                .userId("testUser0012")
                .build();

        final PrimeUserDetails saved = saveAndReadBack(userDetails);
        final PrimeUserDetails readBack = repository.getOneOrNull(saved.getId());

        assertThat(readBack, is(equalTo(saved)));
    }
}
