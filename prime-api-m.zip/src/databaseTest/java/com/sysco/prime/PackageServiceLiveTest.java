package com.sysco.prime;

import com.sysco.prime.packages.BoxTypeRepository;
import com.sysco.prime.packages.FilmTypeRepository;
import com.sysco.prime.packages.PackageService;
import com.sysco.prime.packages.PiecesPackage;
import com.sysco.prime.packages.PiecesPackageRepository;
import com.sysco.prime.packages.TarePackage;
import com.sysco.prime.packages.TarePackageRepository;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

import static com.sysco.prime.DummyObjectFactory.buildPiecesPackage;
import static com.sysco.prime.DummyObjectFactory.buildTarePackage;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

public class PackageServiceLiveTest extends RepositoryTestBase<TarePackage, TarePackageRepository> {
    @Autowired
    private BoxTypeRepository boxTypeRepository;
    @Autowired
    private FilmTypeRepository filmTypeRepository;
    @Autowired
    private PiecesPackageRepository piecesPackageRepository;

    private PackageService service;

    private static TarePackage copyWithoutDatabaseDetails(final TarePackage tarePackage) {
        return tarePackage.toBuilder().build();
    }

    @Before
    public void setUp() {
        service = new PackageService(boxTypeRepository, filmTypeRepository, repository, piecesPackageRepository);
    }

    @Test
    public void shouldUpdateExistingEntityInDatabase() {
        final TarePackage tarePackage = buildTarePackage();

        final PiecesPackage savedPiecesPackage = buildPiecesPackage();

        piecesPackageRepository.save(savedPiecesPackage);
        boxTypeRepository.save(tarePackage.getBoxType());
        filmTypeRepository.save(tarePackage.getFilmType());

        // Defensive copy since Spring Data mutates the argument, and we want that copy to remain pristine
        final TarePackage saved = service.saveOneTarePackage(copyWithoutDatabaseDetails(tarePackage));
        assertThat(saved.getId(), is(notNullValue()));

        final TarePackage found = service.findOneTarePackageLike(tarePackage);
        assertTrue(found.entityEquals(saved));

        final TarePackage fresh = copyWithoutDatabaseDetails(found);
        fresh.setDefaulted(false);
        final TarePackage savedAgain = service.saveOneTarePackage(fresh);
        assertTrue(found.entityEquals(savedAgain));

        final List<PiecesPackage> foundPiecesPackages = service.getAllPiecesPackages();
        assertThat(savedPiecesPackage, is(foundPiecesPackages.get(0)));
    }
}
