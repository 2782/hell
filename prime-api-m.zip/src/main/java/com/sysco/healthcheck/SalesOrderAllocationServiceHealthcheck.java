package com.sysco.healthcheck;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.Health.Builder;
import org.springframework.boot.actuate.health.HealthIndicator;
import org.springframework.boot.actuate.health.Status;
import org.springframework.context.annotation.Profile;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.oauth2.client.OAuth2RestTemplate;
import org.springframework.stereotype.Component;

import static org.springframework.http.HttpMethod.GET;

@Component
@Profile("realsus")
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
@Slf4j
public class SalesOrderAllocationServiceHealthcheck implements HealthIndicator {
    private final CheckStatus checkStatus;

    @Override
    public Health health() {
        return checkStatus.apply("/sales-order-allocations/v1/health");
    }
}
