package com.sysco;

import lombok.Generated;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.service.Contact;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

import java.util.function.Predicate;

import static springfox.documentation.spi.DocumentationType.SWAGGER_2;

@Configuration
@EnableSwagger2
@Generated // Lie, so JaCoCo ignores in the report
public class ApiDocsConfiguration {
    private static final String PROJECT_VERSION = "0.1.0";
    private static final String PROJECT_CONTACT_NAME = "Patrick Murphy";
    private static final String PROJECT_CONTACT_URL
            = "https://apicentral-qa.sysco.com/store/site/pages/application.jag?name=Prime-API-QA";

    private Contact contact() {
        return new Contact(PROJECT_CONTACT_NAME, PROJECT_CONTACT_URL, null);
    }

    @Bean
    public Docket primeDocket() {
        final Predicate<String> apiPaths = PathSelectors.ant("/api/**")::apply;

        return new Docket(SWAGGER_2)
                .groupName("Prime API")
                .apiInfo(new ApiInfoBuilder()
                        .title("Prime RESTful APIs")
                        .description("The main APIs for Prime")
                        .contact(contact())
                        .version(PROJECT_VERSION)
                        .build())
                .select()
                .paths(apiPaths::test)
                .build();
    }

    @Bean
    public Docket susDocket() {
        final Predicate<String> apiPaths = PathSelectors.ant("/sus/**")::apply;

        return new Docket(SWAGGER_2)
                .groupName("Dummy APIs")
                .apiInfo(new ApiInfoBuilder()
                        .title("Dummy RESTful APIs")
                        .description("Support APIs for Prime")
                        .contact(contact())
                        .version(PROJECT_VERSION)
                        .build())
                .select()
                .paths(apiPaths::test)
                .build();
    }

    @Bean
    public Docket reportingDocket() {
        final Predicate<String> apiPaths = PathSelectors.ant("/metrics/**")::apply;

        return new Docket(SWAGGER_2)
                .groupName("Reporting APIs")
                .apiInfo(new ApiInfoBuilder()
                        .title("Reporting RESTful APIs")
                        .description("Reporting APIs for Prime")
                        .contact(contact())
                        .version(PROJECT_VERSION)
                        .build())
                .select()
                .paths(apiPaths::test)
                .build();
    }
}
