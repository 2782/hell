package com.sysco.prime.cost;

import com.sysco.prime.product.Product;
import com.sysco.prime.shared.model.TransactionalEntity;
import com.sysco.prime.yieldModel.ByproductDependency;
import com.sysco.prime.yieldModel.CuttingYieldByproduct;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;

import javax.persistence.Entity;
import javax.persistence.Enumerated;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Objects;

import static com.sysco.prime.cost.CostSource.BYPRODUCT_ONLY;
import static com.sysco.prime.cost.CostSource.REMOVE_OVERRIDE;
import static com.sysco.prime.cost.CostSource.YIELD_MODEL;
import static com.sysco.prime.cost.Money.ofCost;
import static com.sysco.prime.yieldModel.YieldModelUtils.calculateMarketCost;
import static java.math.BigDecimal.ZERO;
import static javax.persistence.EnumType.STRING;

@Builder(toBuilder = true)
@Entity
@EqualsAndHashCode(callSuper = false)
@Getter // No setters - Cost table is append-only, not for updates
@NoArgsConstructor
@ToString
public class Cost extends TransactionalEntity implements Comparable<Cost> {
    public static final LocalDate COST_NEVER_EXPIRES = LocalDate.of(2999, 1, 1);
    public static final Cost WITH_ZERO_COSTS = Cost.builder()
            .marketCost(ZERO)
            .currentCostPerPound(ZERO)
            .weightedAverageCost(ZERO)
            .labor(ZERO)
            .build();

    private String name;
    private Long yieldModelId;
    private BigDecimal marketCost;
    private BigDecimal labor;
    private LocalDate startDate;
    private LocalDate endDate;
    private BigDecimal weightedAverageCost;
    private BigDecimal currentCostPerPound;
    @Enumerated(STRING)
    private CostSource source;

    /**
     * Custom ctor (not Lombok) to enforce two decimal places for cost components.
     *
     * @todo Alter the cost table so cost component columns use {@code NUMERIC(10,2)}, or appropriate
     */
    public Cost(
            final String name,
            final Long yieldModelId,
            final BigDecimal marketCost,
            final BigDecimal labor,
            final LocalDate startDate,
            final LocalDate endDate,
            final BigDecimal weightedAverageCost,
            final BigDecimal currentCostPerPound,
            final CostSource source) {
        this.name = name;
        this.yieldModelId = yieldModelId;
        this.marketCost = costOrNothing(marketCost);
        this.labor = moneyOrNothing(labor);
        this.startDate = startDate;
        this.endDate = endDate;
        this.weightedAverageCost = costOrNothing(weightedAverageCost);
        this.currentCostPerPound = costOrNothing(currentCostPerPound);
        this.source = source;
    }

    private static BigDecimal moneyOrNothing(final BigDecimal maybeMissing) {
        return null == maybeMissing ? null : Money.of(maybeMissing.doubleValue());
    }

    private static BigDecimal costOrNothing(final BigDecimal maybeMissing) {
        return null == maybeMissing ? null : ofCost(maybeMissing);
    }

    public static Cost byproductOnlyCostFrom(final Product product, final BigDecimal marketCost) {
        final BigDecimal currentCostPerPound = CostUtils.calculateCurrentCostPerPound(
                product, marketCost);

        return Cost.builder()
                .source(BYPRODUCT_ONLY)
                .name(product.getCostName())
                .weightedAverageCost(null)
                .yieldModelId(null)
                .startDate(null)
                .endDate(null)
                .labor(ZERO)
                .currentCostPerPound(currentCostPerPound)
                .marketCost(marketCost)
                .build();
    }

    public Cost updateCurrentCost(final Product product) {
        return this.toBuilder()
                .currentCostPerPound(CostUtils.calculateCurrentCostPerPound(product, marketCost))
                .build();
    }

    static Cost unsetPricingModelFrom(final Cost cost) {
        return cost.toBuilder()
                .source(YIELD_MODEL)
                .build();
    }

    public Cost assignWeightedAverageCost(final Cost cost) {
        return toBuilder()
                .weightedAverageCost(cost.getWeightedAverageCost())
                .build();
    }

    public Cost getCostOfMember(final Product product) {
        return toBuilder()
                .marketCost(calculateMarketCost(product, currentCostPerPound))
                .build();
    }


    //TODO: Clean up
    public static Cost removeOverride(final ByproductDependency byproduct,
                                      final LocalDate date) {
        return builder()
                .startDate(date)
                .marketCost(null)
                .currentCostPerPound(null)
                .weightedAverageCost(null)
                .labor(null)
                .source(REMOVE_OVERRIDE)
                .yieldModelId(byproduct.getOwner().getId())
                .name(byproduct.getProductCode())
                .endDate(COST_NEVER_EXPIRES)
                .build();
    }

    //TODO: Test calculate market cost change
    public static Cost from(final CuttingYieldByproduct yieldByproduct, final Product product,
                            final Long yieldModelId,
                            final CostSource sourceType) {
        return builder()
                .marketCost(ofCost(calculateMarketCost(product, yieldByproduct.getCost())))
                .currentCostPerPound(ofCost(yieldByproduct.getCost()))
                .labor(null)
                .weightedAverageCost(null)
                .yieldModelId(yieldModelId)
                .source(sourceType)
                .name(yieldByproduct.getByproductCode())
                .build();
    }

    boolean hasPrimeCostChanged(final Cost other) {
        return !Objects.equals(currentCostPerPound, other.currentCostPerPound)
                || !Objects.equals(labor, other.labor)
                || !Objects.equals(source, other.source);
    }

    boolean isEmpty() {
        return null == marketCost
                && null == labor
                && null == weightedAverageCost
                && null == currentCostPerPound;
    }

    public String getMarketCostString() {
        return String.valueOf(marketCost);
    }

    @Override
    public int compareTo(final Cost next) {

        if (this.startDate == null
                || this.endDate == null
                || this.getCreatedAt() == null
                || next.getStartDate() == null
                || next.getEndDate() == null
                || next.getCreatedAt() == null) {
            return 0;
        }

        if (this.name.equals(next.getName())
                && this.startDate.compareTo(next.getStartDate()) == 0
                && this.endDate.compareTo(next.getEndDate()) == 0) {
            return next.getCreatedAt().compareTo(this.getCreatedAt());
        }

        return next.getStartDate().compareTo(this.startDate);
    }
}
