package com.sysco.prime.cost.request;

import com.sysco.prime.cost.Cost;
import com.sysco.prime.cost.Cost.CostBuilder;
import com.sysco.prime.cost.Money;
import com.sysco.prime.product.Product;
import com.sysco.prime.product.ProductService;
import com.sysco.prime.product.validation.PositiveNumberString;
import com.sysco.prime.product.validation.ValidProduct;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

import java.math.BigDecimal;
import java.time.Clock;
import java.time.LocalDate;

import static com.sysco.prime.cost.Cost.COST_NEVER_EXPIRES;
import static com.sysco.prime.cost.CostSource.SUS;
import static com.sysco.prime.product.ProductService.formatProductCode;
import static java.math.RoundingMode.HALF_UP;

@AllArgsConstructor
@Builder
@Data
public class SourceCostRequest {
    @ValidProduct(source = true, nosus = true)
    private String sourceProductCode;
    @PositiveNumberString
    private String cost;

    public Cost toDomain(final ProductService productService,
                         final Clock clock) {
        final String formattedProductCode = formatProductCode(sourceProductCode);
        final Product product = productService.findByCodeIgnoringSus(formattedProductCode);

        final CostBuilder builder = Cost.builder()
                .source(SUS)
                .name(formattedProductCode)
                .startDate(LocalDate.now(clock))
                .endDate(COST_NEVER_EXPIRES)
                .labor(null);

        Double costValue = Double.valueOf(cost);
        //Only source products copy over all fields
        if (!Money.of(costValue).equals(Money.zero())) {
            builder.marketCost(Money.of(costValue))
                    .currentCostPerPound(calculateCurrentCostPerPound(product));
        }
        return builder.build();
    }

    public BigDecimal calculateCurrentCostPerPound(final Product product) {
        Double costValue = Double.valueOf(cost);
        return product.isFixedWeight()
                ? Money.of(costValue).divide(Money.of(product.getWeightPerBox()), 2, HALF_UP)
                : Money.of(costValue);
    }
}
