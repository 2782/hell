package com.sysco.prime.cost;

import lombok.Builder;
import lombok.Data;

import java.math.BigDecimal;

@Data
@Builder
public class CostResponse {
    private final BigDecimal cost;
    private final BigDecimal labor;

    public static CostResponse from(final Cost cost) {
        if (cost == null) {
            return null;
        }

        final BigDecimal currentCostPerPound = cost.getCurrentCostPerPound();
        final BigDecimal labor = cost.getLabor();

        return CostResponse.builder()
                .cost(null == currentCostPerPound ? Money.zero() : currentCostPerPound)
                .labor(null == labor ? Money.zero() : labor)
                .build();
    }
}
