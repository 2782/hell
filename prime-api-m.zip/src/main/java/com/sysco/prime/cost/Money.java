package com.sysco.prime.cost;

import lombok.NoArgsConstructor;

import java.math.BigDecimal;

import static java.math.BigDecimal.ZERO;
import static java.math.RoundingMode.HALF_UP;
import static lombok.AccessLevel.PRIVATE;

@NoArgsConstructor(access = PRIVATE)
public final class Money {
    private static final BigDecimal zeroMoney = roundToUsd(ZERO);

    /** Rounds the given <var>amount</var> to 2 decimal places (cents). */
    public static BigDecimal of(final double amount) {
        return roundToUsd(BigDecimal.valueOf(amount));
    }

    /** Rounds the given <var>amount</var> to 2 decimal places (cents), defaulting to "0.00" if <code>null</code>. */
    public static BigDecimal of(final BigDecimal amount) {
        return null == amount ? zero() : roundToUsd(amount);
    }

    /** Provides a "0.00" value rounded to 2 decimal places (cents). */
    public static BigDecimal zero() {
        return zeroMoney;
    }

    private static BigDecimal roundToUsd(final BigDecimal amount) {
        return amount.setScale(2, HALF_UP);
    }

    public static BigDecimal ofCost(final BigDecimal amount) {
        return null == amount ? costZero() : amount.setScale(3, HALF_UP);
    }

    public static BigDecimal ofCost(final double amount) {
        return BigDecimal.valueOf(amount).setScale(3, HALF_UP);
    }

    public static BigDecimal costZero() {
        return ZERO.setScale(3, HALF_UP);
    }
}
