package com.sysco.prime.customer.request;

import com.sysco.prime.customer.SubPrimal;
import com.sysco.prime.customer.validation.ValidSubPrimal;
import lombok.Builder;
import lombok.Getter;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

@Getter
@Builder
@ValidSubPrimal
public class SubPrimalRequest {
    @NotNull
    private String subPrimalCode;
    @NotNull
    @Min(1)
    @Max(99)
    private Integer dateValue;

    SubPrimal toDomain() {
        return SubPrimal.builder()
                .subPrimalCode(subPrimalCode)
                .dateValue(dateValue)
                .build();
    }
}
