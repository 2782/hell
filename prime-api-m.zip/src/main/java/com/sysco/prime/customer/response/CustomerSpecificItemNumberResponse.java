package com.sysco.prime.customer.response;

import com.sysco.prime.customer.CustomerSpecificItemNumber;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.ToString;

@Getter
@AllArgsConstructor
@Builder(toBuilder = true)
@ToString
public class CustomerSpecificItemNumberResponse {
    private final String itemNumber;
    private final String productCode;

    CustomerSpecificItemNumberResponse(final CustomerSpecificItemNumber customerSpecificItemNumber) {
        itemNumber = customerSpecificItemNumber.getItemNumber();
        productCode = customerSpecificItemNumber.getProduct().getCode();
    }
}
