package com.sysco.prime.customer;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.io.Serializable;

@AllArgsConstructor
@Builder
@EqualsAndHashCode(callSuper = false)
@Getter
@NoArgsConstructor
@ToString
public class Address implements Serializable {
    private String lineOne;
    private String lineTwo;
    private String city;
    private String country;
    private String postalCode;
}
