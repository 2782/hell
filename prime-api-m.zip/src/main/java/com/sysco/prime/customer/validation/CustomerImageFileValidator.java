package com.sysco.prime.customer.validation;

import com.sysco.prime.product.validation.PrimeConstraintValidator;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.ConstraintValidatorContext;
import java.io.IOException;

import static com.sysco.prime.validation.ValidationErrorType.REQUIRED;
import static org.springframework.util.StringUtils.isEmpty;

@Component
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class CustomerImageFileValidator implements PrimeConstraintValidator<CustomerValidImageFile, MultipartFile> {

    @Override
    public void initialize(final CustomerValidImageFile constraintAnnotation) {
    }

    @Override
    public boolean isValid(final MultipartFile multipartFile, final ConstraintValidatorContext context) {

        if (multipartFile == null) {
            return true;
        }

        final String fileName = multipartFile.getOriginalFilename();
        final String contentType = multipartFile.getContentType();

        if (isEmpty(fileName)) {
            return validationFailedBecause(context, REQUIRED);
        }

        if (fileName.contains("..")) {
            context.disableDefaultConstraintViolation();
            context.buildConstraintViolationWithTemplate(
                    "Image fileName contains invalid path sequence " + fileName)
                    .addConstraintViolation();
            return false;
        }
        if (isEmpty(contentType) || !isSupportedContentType(contentType)) {
            context.disableDefaultConstraintViolation();
            context.buildConstraintViolationWithTemplate(
                    "Invalid file type. Only JPG, JPEG, PNG or BMP images are allowed.")
                    .addConstraintViolation();
            return false;
        }

        try {
            if (multipartFile.getBytes().length > 1000000) {
                context.disableDefaultConstraintViolation();
                context.buildConstraintViolationWithTemplate(
                        "Maximum file size exceeded. Current restriction is 1MB")
                        .addConstraintViolation();
                return false;
            }
        } catch (IOException e) {
            context.disableDefaultConstraintViolation();
            context.buildConstraintViolationWithTemplate(
                    "Error reading file " + fileName)
                    .addConstraintViolation();
            return false;
        }

        return true;
    }

    private boolean isSupportedContentType(String contentType) {
        return contentType.equals("image/png")
                || contentType.equals("image/jpg")
                || contentType.equals("image/jpeg")
                || contentType.equals("image/bmp");
    }
}