package com.sysco.prime.customer;

public enum DateType {
    BESTBY("BEST BY"), FREEZEBY("FREEZE BY"), SELLBY("SELL BY"), NONE("NONE");

    private String displayValue;

    DateType(final String displayValue) {
        this.displayValue = displayValue;
    }

    public String getDisplayValue() {
        return displayValue;
    }
}
