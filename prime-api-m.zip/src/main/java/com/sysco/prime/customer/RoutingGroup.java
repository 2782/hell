package com.sysco.prime.customer;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.sysco.prime.shared.model.TransactionalEntity;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import java.time.DayOfWeek;
import java.util.Map;
import java.util.Objects;
import java.util.StringJoiner;

import static java.lang.Integer.MAX_VALUE;
import static javax.persistence.FetchType.LAZY;

@Entity
@Getter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class RoutingGroup extends TransactionalEntity {
    @ManyToOne(fetch = LAZY)
    @JoinColumn(name = "customerId", nullable = false)
    @JsonIgnore
    private Customer customer;

    private int dayOfWeek;
    private int value;

    @JsonIgnore
    public static RoutingGroup from(final Map.Entry<String, String> routingGroups) {
        return builder()
                .dayOfWeek(DayOfWeek.valueOf(routingGroups.getKey().toUpperCase()).getValue())
                .value(routingGroups.getValue() != null ? Integer.parseInt(routingGroups.getValue()) : MAX_VALUE)
                .build();
    }

    RoutingGroup attachTo(final Customer customer) {
        this.customer = customer;
        return this;
    }

    @Override
    public String toString() {
        return new StringJoiner(", ", RoutingGroup.class.getSimpleName() + "[", "]")
                .add("customer=" + (customer != null ? customer.getCustomerCode() : "[null]"))
                .add("dayOfWeek=" + dayOfWeek)
                .add("value=" + value)
                .toString();
    }

    @Override
    public boolean equals(final Object other) {
        if (this == other) {
            return true;
        }

        if (other == null || getClass() != other.getClass()) {
            return false;
        }
        final RoutingGroup that = (RoutingGroup) other;

        if (dayOfWeek != that.dayOfWeek) {
            return false;
        }
        if (value != that.value) {
            return false;
        }
        return customer != null
                ? Objects.equals(customer.getCustomerCode(), that.customer.getCustomerCode())
                : that.customer == null;
    }

    @Override
    public int hashCode() {
        int result = customer != null
                ? customer.getCustomerCode().hashCode()
                : 0;
        result = 31 * result + dayOfWeek;
        result = 31 * result + value;
        return result;
    }
}
