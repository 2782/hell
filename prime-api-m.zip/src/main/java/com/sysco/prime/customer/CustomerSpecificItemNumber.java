package com.sysco.prime.customer;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.sysco.prime.product.Product;
import com.sysco.prime.shared.model.TransactionalEntity;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Generated;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import java.util.Objects;

import static javax.persistence.FetchType.EAGER;
import static javax.persistence.FetchType.LAZY;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class CustomerSpecificItemNumber extends TransactionalEntity {
    @ManyToOne(fetch = LAZY)
    @JoinColumn(name = "customerId")
    @JsonIgnore
    private Customer customer;

    @ManyToOne(fetch = EAGER)
    @JoinColumn(name = "productId")
    @JsonIgnore
    private Product product;

    private String itemNumber;

    public void attachTo(final Customer customer) {
        this.customer = customer;
    }

    @Generated
    @Override
    public boolean equals(final Object other) {
        if (this == other) {
            return true;
        }

        if (other == null || getClass() != other.getClass()) {
            return false;
        }

        final CustomerSpecificItemNumber that = (CustomerSpecificItemNumber) other;

        if (customer != null) {
            if (!customer.getCustomerCode().equals(that.customer.getCustomerCode())) {
                return false;
            }
        } else if (that.customer != null) {
            return false;
        }

        if (product != null) {
            if (!product.getCode().equals(that.product.getCode())) {
                return false;
            }
        } else if (that.product != null) {
            return false;
        }
        return Objects.equals(itemNumber, that.itemNumber);
    }

    @Generated
    @Override
    public int hashCode() {
        int result = customer != null ? customer.getCustomerCode().hashCode() : 0;
        result = 31 * result + (product != null ? product.getCode().hashCode() : 0);
        result = 31 * result + (itemNumber != null ? itemNumber.hashCode() : 0);
        return result;
    }

    @Generated
    @Override
    public String toString() {
        String customerCode = customer != null ? customer.getCustomerCode() : "[null]";
        String productCode = product != null ? product.getCode() : "[null]";
        return "CustomerSpecificItemNumber{"
                + "customer=" + customerCode
                + ", product=" + productCode
                + ", itemNumber='" + itemNumber + '\''
                + '}';
    }
}
