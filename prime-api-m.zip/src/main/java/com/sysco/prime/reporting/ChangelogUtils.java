package com.sysco.prime.reporting;

import com.sysco.prime.saml.user.PrimeUserDetails;

import java.math.BigDecimal;
import java.math.RoundingMode;

public class ChangelogUtils {
    public static final String PRIME_USER = "primeUser";
    public static final String PRIME_USER_INDIRECT = "primeUserIndirect";
    public static final String SUS_USER = "SUS";

    public static BigDecimal getBigDecimalFromString(String value) {
        if (value != null && !value.isEmpty() && !value.equalsIgnoreCase("null")) {
            if (value.equalsIgnoreCase("true")) {
                return new BigDecimal(("999999"));
            }
            if (value.equalsIgnoreCase("false")) {
                return new BigDecimal("-999999");
            }
            return new BigDecimal(value);
        }
        return new BigDecimal("-9999999");
    }

    public static BigDecimal getValueToStoreInChangelog(final BigDecimal oldValue) {
        return oldValue != null ? oldValue.compareTo(BigDecimal.ZERO) == 0 ? BigDecimal.ZERO :
                oldValue.scale() > 0 ? oldValue.setScale(3, RoundingMode.HALF_UP) :
                        oldValue : oldValue;
    }
}
