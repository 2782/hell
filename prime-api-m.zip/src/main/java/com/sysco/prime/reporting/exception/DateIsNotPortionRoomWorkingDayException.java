package com.sysco.prime.reporting.exception;

import static com.sysco.prime.reporting.exception.ReportingValidationErrorType.DATE_IS_NOT_PORTION_ROOM_WORKING_DAY;

public class DateIsNotPortionRoomWorkingDayException extends ReportingException {
    public DateIsNotPortionRoomWorkingDayException(final String reportDateValue) {
        super("reportDate", reportDateValue, DATE_IS_NOT_PORTION_ROOM_WORKING_DAY);
    }
}
