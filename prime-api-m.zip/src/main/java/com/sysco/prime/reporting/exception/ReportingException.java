package com.sysco.prime.reporting.exception;

import lombok.Getter;

@Getter
public abstract class ReportingException extends RuntimeException {
    private final ReportingValidationErrorType error;
    private final String fieldName;
    private final String value;

    public ReportingException(final String fieldName, final String value, final ReportingValidationErrorType error) {
        super(error.getMessage());
        this.error = error;
        this.fieldName = fieldName;
        this.value = value;
    }
}
