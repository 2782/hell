package com.sysco.prime.product.response;

import com.sysco.prime.product.Product;
import com.sysco.prime.product.ProductGroup;
import lombok.Value;

import java.util.List;
import java.util.stream.Collectors;

@Value
public class ProductGroupResponse {
    private final String primaryProductCode;
    private final List<String> memberProductCodes;
    private final String name;

    public ProductGroupResponse(final ProductGroup productGroup) {
        final Product primaryProduct = productGroup.getPrimaryProduct();
        primaryProductCode = null == primaryProduct ? null : primaryProduct.getCode();
        name = productGroup.getName();
        memberProductCodes = productGroup.getMemberProducts().stream()
                .map(Product::getCode)
                .collect(Collectors.toList());
    }
}
