package com.sysco.prime.product;

import com.sysco.prime.blend.BlendService;
import com.sysco.prime.cost.Cost;
import com.sysco.prime.cost.CostService;
import com.sysco.prime.packages.PackageService;
import com.sysco.prime.packages.PiecesPackage;
import com.sysco.prime.packages.TarePackage;
import com.sysco.prime.portionRoomTable.PortionRoomTable;
import com.sysco.prime.portionRoomTable.PortionRoomTableService;
import com.sysco.prime.product.request.CuttingProductGroupRequest;
import com.sysco.prime.product.request.GrindingProductGroupRequest;
import com.sysco.prime.product.request.ProductGroupNameLookup;
import com.sysco.prime.product.request.ProductSetupRequest;
import com.sysco.prime.product.response.AllergenResponse;
import com.sysco.prime.product.response.IncompleteProductResponse;
import com.sysco.prime.product.response.ProductResponse;
import com.sysco.prime.product.response.ProductSubPrimalResponse;
import com.sysco.prime.yieldModel.CuttingYieldModel;
import com.sysco.prime.yieldModel.CuttingYieldModelService;
import com.sysco.prime.yieldModel.GrindingYieldModelService;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.springframework.util.MultiValueMap;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import java.util.List;

import static java.util.Collections.emptyList;
import static java.util.stream.Collectors.toList;
import static org.springframework.http.HttpStatus.CREATED;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

@Validated
@RestController
@RequestMapping(path = "/api/products", produces = APPLICATION_JSON_VALUE)
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class ProductController {
    private final ProductService productService;
    private final AllergenService allergenService;
    private final ProductGroupService productGroupService;
    private final BlendService blendService;
    private final CostService costService;
    private final CuttingYieldModelService cuttingYieldModelService;
    private final GrindingYieldModelService grindingYieldModelService;

    private final PortionRoomTableService portionRoomTableService;
    private final PackageService packageService;

    @GetMapping(path = "/by-code")
    @ApiOperation(value = "get product by code",
            notes = "get product info by code, will fill prefix '0' if length less than 7")
    @Secured({"ROLE_ADMIN", "ROLE_PORTION_ROOM_MEMBER", "ROLE_COSTING"})
    public ProductResponse getProduct(@RequestParam final String productCode) {
        final Product product = productService.findByCodeFillZeroBefore(productCode);
        final Cost cost = costService.findCost(product);

        CuttingYieldModel pricingModel = null;
        if (product.isCutting()) {
            pricingModel = cuttingYieldModelService.findCuttingPricingModelTakingIntoAccountGroup(product);
        }

        return new ProductResponse(product, cost, pricingModel);
    }

    @GetMapping
    @ApiOperation(value = "get all products by codes",
            notes = "get product info by codes")
    @Secured({"ROLE_ADMIN", "ROLE_PORTION_ROOM_MEMBER", "ROLE_COSTING"})
    public List<ProductResponse> getProducts(@RequestParam final MultiValueMap<String, String> queries) {
        return productService.findAllProducts(queries.toSingleValueMap()).stream()
                .map(ProductResponse::new)
                .collect(toList());
    }

    @PostMapping(path = "/group/cutting")
    @ResponseStatus(CREATED)
    @Secured({"ROLE_ADMIN", "ROLE_COSTING"})
    public void assignToCuttingProductGroup(@Valid @RequestBody final CuttingProductGroupRequest request) {
        productGroupService.createOrUpdate(request.toDomain(productService));
    }

    @PostMapping(path = "/group/grinding")
    @ResponseStatus(CREATED)
    @Secured({"ROLE_ADMIN", "ROLE_COSTING"})
    public void assignToGrindingProductGroup(@Valid @RequestBody final GrindingProductGroupRequest request) {
        productGroupService.createOrUpdate(request.toDomain(productService));
    }

    @GetMapping(path = "/group/lookup")
    @Secured({"ROLE_ADMIN", "ROLE_COSTING"})
    public ProductGroupNameLookup lookupProductGroupByName(@RequestParam("name") final String productGroupName) {
        return new ProductGroupNameLookup(productGroupName, productService, blendService, productGroupService);
    }

    @GetMapping(path = "/incomplete")
    @Secured({"ROLE_ADMIN", "ROLE_COSTING"})
    public List<IncompleteProductResponse> getAllIncompleteProducts() {
        return productService.findAllIncompleteProducts();
    }

    @PostMapping("/setup")
    @ApiOperation("setup product: assign table, tarePackage ...")
    @Secured({"ROLE_ADMIN", "ROLE_COSTING"})
    public void setupProduct(@Valid @RequestBody final ProductSetupRequest productSetupRequest) {
        //TODO: Move all this logic into the service. Keep controllers simple
        final Long tarePackageId = productSetupRequest.getTarePackageId();
        final Long retailSpecificTareId = productSetupRequest.getRetailSpecificTareId();
        final Long piecesPackageId = productSetupRequest.getPiecesPackageId();
        final List<String> allergenNames = productSetupRequest.getAllergens();

        final TarePackage tarePackage = null != tarePackageId
                ? packageService.findTarePackageById(tarePackageId) : null;
        final TarePackage retailTarePackage = null != retailSpecificTareId
                ? packageService.findTarePackageById(retailSpecificTareId) : null;
        final Product byCode = productService.findByCode(productSetupRequest.getProductCode());
        final PortionRoomTable tableByCode = portionRoomTableService.getTableByCode(productSetupRequest.getTableCode());
        final PiecesPackage piecesPackageById = null != piecesPackageId
                ? packageService.findPiecesPackageById(piecesPackageId) : null;
        final List<Allergen> allergens = null != allergenNames
                ? allergenService.findAllByName(allergenNames)
                : emptyList();

        final ProductSetup productSetup = productSetupRequest.toDomain(
                byCode,
                tarePackage,
                tableByCode,
                piecesPackageById,
                retailTarePackage,
                allergens);

        productService.setupProduct(productSetup);
    }

    @GetMapping("/by-descriptions")
    @ApiOperation("search product by descriptions, split by comma")
    @Secured({"ROLE_ADMIN", "ROLE_PORTION_ROOM_MEMBER", "ROLE_COSTING"})
    public List<ProductResponse> searchByDescription(@RequestParam("descriptions") final String descriptions) {
        return productService.findByDescriptions(descriptions).stream()
                .map(ProductResponse::new)
                .collect(toList());
    }

    @GetMapping("/sub-primal")
    @ApiOperation("find product subPrimal by subPrimalCode")
    @Secured({"ROLE_ADMIN"})
    public ProductSubPrimalResponse findSubPrimal(@RequestParam("sub-primal-code") final String subPrimalCode) {
        return new ProductSubPrimalResponse(productService.findBySubPrimalCode(subPrimalCode));
    }

    @GetMapping("/allergens")
    @ApiOperation("retrieve allergens")
    @Secured({"ROLE_ADMIN", "ROLE_COSTING"})
    public List<AllergenResponse> getAllergens() {
        return allergenService.getAllergens()
                .stream()
                .map(AllergenResponse::new)
                .collect(toList());
    }

}
