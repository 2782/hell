package com.sysco.prime.product;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.sysco.prime.packages.TarePackage;
import com.sysco.prime.shared.model.TransactionalEntity;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import java.math.BigDecimal;
import java.util.Objects;

@Getter
@Setter
@ToString(exclude = {"product"})
@Entity
@Builder(toBuilder = true)
@AllArgsConstructor
@NoArgsConstructor
public class RetailSpecific extends TransactionalEntity {
    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "productId", unique = true)
    @JsonIgnore
    private Product product;

    private BigDecimal price;

    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "tareId")
    private TarePackage tare;
    private BigDecimal minWeight;
    private BigDecimal maxWeight;
    private String retailNumber;

    @Override
    public boolean equals(final Object other) {
        if (this == other) {
            return true;
        }
        if (other == null || getClass() != other.getClass()) {
            return false;
        }
        final RetailSpecific that = (RetailSpecific) other;
        return Objects.equals(getIdSafely(product), getIdSafely(that.product))
                && Objects.equals(price, that.price)
                && Objects.equals(getIdSafely(tare), getIdSafely(that.tare))
                && Objects.equals(minWeight, that.minWeight)
                && Objects.equals(maxWeight, that.maxWeight)
                && Objects.equals(retailNumber, that.retailNumber);
    }

    @Override
    public int hashCode() {
        return Objects.hash(getIdSafely(product), price, tare, minWeight, maxWeight, retailNumber);
    }
}
