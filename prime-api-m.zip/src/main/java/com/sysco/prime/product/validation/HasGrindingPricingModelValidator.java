package com.sysco.prime.product.validation;

import com.sysco.prime.exception.InvalidValueException;
import com.sysco.prime.productionOrder.Blend;
import com.sysco.prime.productionOrder.BlendRepository;
import com.sysco.prime.yieldModel.GrindingYieldModelRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.validation.ConstraintValidatorContext;

@Component
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class HasGrindingPricingModelValidator implements PrimeConstraintValidator<HasGrindingPricingModel, String> {
    private final GrindingYieldModelRepository grindingYieldModelRepository;
    private final BlendRepository blendRepository;

    @Override
    public boolean isValid(final String blendName, final ConstraintValidatorContext context) {
        try {
            final Blend blend = Blend.fromString(blendName, blendRepository);
            return grindingYieldModelRepository.findByBlendNameAndPricingModelTrue(
                    blend.getName()).isPresent();
        } catch (InvalidValueException e) {
            return false;
        }
    }
}
