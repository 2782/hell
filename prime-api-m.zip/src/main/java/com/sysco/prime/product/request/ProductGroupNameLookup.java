package com.sysco.prime.product.request;

import com.sysco.prime.blend.BlendService;
import com.sysco.prime.exception.InvalidValueException;
import com.sysco.prime.exception.NotFoundException;
import com.sysco.prime.product.Product;
import com.sysco.prime.product.ProductGroupService;
import com.sysco.prime.product.ProductService;
import com.sysco.prime.product.response.BlendNameLookup;
import com.sysco.prime.product.response.GroupLookup;
import com.sysco.prime.product.response.NameLookup;
import com.sysco.prime.product.response.ProductNameLookup;
import com.sysco.prime.product.response.ProductResponse;
import com.sysco.prime.productionOrder.Blend;
import com.sysco.prime.productionOrder.response.BlendResponse;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

import java.util.Optional;

import static com.sysco.prime.product.response.BlendOrProductLookup.isBlendNameOrProductCode;

@AllArgsConstructor
@Data
@Builder
public class ProductGroupNameLookup {
    private NameLookup nameLookup;
    private GroupLookup groupLookup;

    public ProductGroupNameLookup(final String productGroupName,
                                  final ProductService productService,
                                  final BlendService blendService,
                                  final ProductGroupService groupService) {
        switch (isBlendNameOrProductCode(productGroupName)) {
            case PRODUCT:
                try {
                    final Product product = productService.findByCodeFillZeroBefore(productGroupName);
                    nameLookup = new ProductNameLookup(
                            new ProductResponse(product));
                    groupLookup = Optional.ofNullable(product.getProductGroup())
                            .map(group -> new GroupLookup(group, blendService))
                            .orElse(null);
                } catch (NotFoundException e) {
                    nameLookup = new ProductNameLookup();
                    groupLookup = null;
                }
                break;
            case BLEND:
            default:
                try {
                    final Blend blend = blendService.getBlend(productGroupName);
                    nameLookup = new BlendNameLookup(
                            new BlendResponse(blend));
                    groupLookup = groupService.findByName(productGroupName)
                            .map(group -> new GroupLookup(group, blendService))
                            .orElse(null);
                } catch (InvalidValueException e) {
                    nameLookup = new BlendNameLookup();
                    groupLookup = null;
                }

                break;
        }
    }
}
