package com.sysco.prime.product;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.sysco.prime.exception.InvalidValueException;
import com.sysco.prime.productionOrder.ProductionType;
import com.sysco.prime.shared.model.TransactionalEntity;
import lombok.Generated;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.validation.constraints.NotNull;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.StringJoiner;
import java.util.stream.Collectors;

import static com.sysco.prime.productionOrder.ProductionType.CUTTING;
import static com.sysco.prime.productionOrder.ProductionType.GRINDING;
import static com.sysco.prime.validation.ValidationError.buildError;
import static com.sysco.prime.validation.ValidationErrorType.INVALID;
import static com.sysco.prime.validation.ValidationErrorType.UNIQUE;
import static java.util.Collections.emptyList;
import static java.util.stream.Collectors.toList;
import static javax.persistence.CascadeType.ALL;
import static javax.persistence.FetchType.EAGER;

@Entity
@Getter
@NoArgsConstructor
@Setter
public class ProductGroup extends TransactionalEntity {
    public static final String ERROR_MESSAGE = "Invalid product group";

    @NotNull
    private String name;
    @OneToOne(fetch = EAGER)
    @JoinColumn(name = "primaryProductId")
    private Product primaryProduct;
    @OneToMany(mappedBy = "productGroup", cascade = ALL, fetch = EAGER, orphanRemoval = false)
    private List<Product> memberProducts = new ArrayList<>();

    private ProductGroup(final Product primaryProduct, final String name) {
        this.name = name;

        if (null != primaryProduct) {
            add(primaryProduct);
            this.primaryProduct = primaryProduct;
        }
    }

    public static ProductGroup grindingProductGroup(final String blend) {
        return new ProductGroup(null, blend);
    }

    public static ProductGroup cuttingProductGroup(final Product primaryProduct) {
        return new ProductGroup(primaryProduct, primaryProduct.getCode());
    }

    public String primaryProductCode() {
        return Optional.ofNullable(primaryProduct)
                .map(Product::getCode)
                .orElse(null);
    }

    public ProductionType type() {
        return null == primaryProduct ? GRINDING : CUTTING;
    }

    public boolean isEmpty() {
        return GRINDING == type() ? memberProducts.isEmpty() : 1 == memberProducts.size();
    }

    public ProductGroup add(final Product member) {
        if (member.equals(primaryProduct)) {
            throw new InvalidValueException("primary product cannot be a finished product",
                    buildError("primaryProductCode", UNIQUE, ERROR_MESSAGE, primaryProduct.getCode()));
        }

        if (memberProductCodes().contains(member.getCode())) {
            throw new InvalidValueException("finished products cannot contain duplicates",
                    buildError("finishedProductCode", UNIQUE, ERROR_MESSAGE, member.getCode()));
        }

        memberProducts.add(member);
        member.addTo(this);
        return this;
    }

    public ProductGroup reattachPrimaryGroup(final Product member) {
        memberProducts.add(member);
        member.addTo(this);
        return this;
    }

    public ProductGroup remove(final Product member) {
        if (member.equals(primaryProduct)) {
            throw new InvalidValueException("cannot remove primary product",
                    buildError("primaryProductCode", INVALID, ERROR_MESSAGE, member.getCode()));
        }
        if (!memberProducts.remove(member)) {
            throw new InvalidValueException("product not a member of group",
                    buildError("finishedProductCode", INVALID, ERROR_MESSAGE, member.getCode()));
        }

        member.removeFromGroup();
        memberProducts.remove(member);
        return this;
    }

    boolean isPrimaryProduct(final Product product) {
        return CUTTING == type() && primaryProduct.getCode().equals(product.getCode());
    }

    List<String> memberProductCodes() {
        return memberProducts.stream()
                .map(Product::getCode)
                .collect(toList());
    }

    @JsonIgnore
    public boolean isCuttingProductGroup() {
        return null != getPrimaryProduct();
    }

    @Override
    @Generated
    public boolean equals(final Object other) {
        if (this == other) {
            return true;
        }
        if (other == null || getClass() != other.getClass()) {
            return false;
        }

        final ProductGroup that = (ProductGroup) other;
        return Objects.equals(name, that.name)
                && Objects.equals(primaryProductCode(), that.primaryProductCode())
                && memberProductCodes().equals(that.memberProductCodes());
    }

    @Override
    @Generated
    public int hashCode() {
        return Objects.hash(name, primaryProductCode(), memberProductCodes());
    }

    @Override
    @Generated
    public String toString() {
        return new StringJoiner(", ", ProductGroup.class.getSimpleName() + "[", "]")
                .add("name='" + name + "'")
                .add("primaryProduct=" + (primaryProductCode()))
                .add("memberProducts=" + memberProductCodes())
                .toString();
    }
}
