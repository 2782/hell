package com.sysco.prime.product;

import com.sysco.prime.cost.CostService;
import com.sysco.prime.yieldModel.CuttingYieldModelService;
import com.sysco.prime.yieldModel.CuttingYieldModelServiceCopy;
import com.sysco.prime.yieldModel.FutureCostPublisher;
import com.sysco.prime.yieldModel.GrindingYieldModelServiceCopy;
import com.sysco.prime.yieldModel.YieldModelBaseCopy;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static com.sysco.prime.product.ProductGroup.cuttingProductGroup;
import static com.sysco.prime.product.ProductGroup.grindingProductGroup;

@Service
public class ProductGroupService {
    static final boolean TODO_SERVICE_CLEANS_UP_EMPTY_GROUPS = false;

    private final ProductGroupRepository repository;
    private final ProductService productService;
    private final CuttingYieldModelService cuttingYieldModelService;
    private final CuttingYieldModelServiceCopy cuttingYieldModelServiceCopy;
    private final CostService costService;
    private final ItemMasterUpdateService itemMasterUpdateService;
    private final GrindingYieldModelServiceCopy grindingYieldModelServiceCopy;
    private final FutureCostPublisher futureCostPublisher;

    public ProductGroupService(
            final ProductGroupRepository repository,
            @Lazy final ProductService productService,
            @Lazy final CuttingYieldModelService cuttingYieldModelService,
            @Lazy final CuttingYieldModelServiceCopy cuttingYieldModelServiceCopy,
            @Lazy final CostService costService,
            @Lazy final ItemMasterUpdateService itemMasterUpdateService,
            @Lazy final GrindingYieldModelServiceCopy grindingYieldModelServiceCopy,
            @Lazy final FutureCostPublisher futureCostPublisher) {
        this.repository = repository;
        this.productService = productService;
        this.cuttingYieldModelService = cuttingYieldModelService;
        this.cuttingYieldModelServiceCopy = cuttingYieldModelServiceCopy;
        this.costService = costService;
        this.itemMasterUpdateService = itemMasterUpdateService;
        this.grindingYieldModelServiceCopy = grindingYieldModelServiceCopy;
        this.futureCostPublisher = futureCostPublisher;
    }

    public void create(final List<ProductGroup> productGroup) {
        productGroup.forEach(this::createOrUpdate);
    }

    @Transactional
    public ProductGroup createOrUpdate(final ProductGroup productGroup) {

        if (productGroup.isCuttingProductGroup()) {
            productGroup.getMemberProducts().stream()
                    .filter(product -> !product.isGroupPrimary())
                    .forEach(product -> {
                        cuttingYieldModelService.unsetCuttingPricingModelFor(product);
                        cuttingYieldModelServiceCopy.unsetCuttingPricingModelFor(product);
                    });
        }

        repository.findByName(productGroup.getName()).ifPresent(found -> {
            productGroup.setId(found.getId());
            productGroup.setCreatedAt(found.getCreatedAt());
        });

        YieldModelBaseCopy pricingModel = productGroup.isCuttingProductGroup()
                ? cuttingYieldModelServiceCopy
                .getPricingModelTakingIntoAccountGroupFor(productGroup.getPrimaryProduct()) :
                grindingYieldModelServiceCopy.getPricingModelFor(productGroup.getName());

        if (pricingModel != null) {
            futureCostPublisher.publishAllEffectiveCosts(pricingModel, cuttingYieldModelServiceCopy,
                    grindingYieldModelServiceCopy);
        }

        return repository.save(productGroup);
    }

    public void evictFromOldGroup(final Product finishedProduct) {
        createOrUpdate(finishedProduct.getProductGroup().remove(finishedProduct));
        createProductGroupIfGroupDoesNotYetExist(finishedProduct);
    }

    public ProductGroup findById(final Long id) {
        return repository.getOneOrNull(id);
    }

    public List<Product> productsInGroupOf(final String productGroupName) {
        return repository.findByName(productGroupName)
                .map(group -> productService.productsInGroupOf(group.getId()))
                .orElseGet(Collections::emptyList);
    }

    private ProductGroup updateCosts(final ProductGroup productGroup) {
        costService.updateCostForProductsInGroup(productGroup);

        return productGroup;
    }

    public void createProductGroupIfGroupDoesNotYetExist(final String blend) {
        final Optional<ProductGroup> productGroupOptional = repository.findByName(blend);
        if (!productGroupOptional.isPresent()) {
            repository.save(grindingProductGroup(blend));
        }
    }

    public void createProductGroupIfGroupDoesNotYetExist(final Product primaryProduct) {
        final Optional<ProductGroup> existingGroupOptional = repository.findByName(primaryProduct.getCode());
        if (existingGroupOptional.isPresent()) {
            final ProductGroup group = existingGroupOptional.get();
            primaryProduct.removeFromGroup();
            primaryProduct.addTo(group);
            productService.save(group.getMemberProducts());
            return;
        }

        productService.save(repository
                .save(cuttingProductGroup(primaryProduct))
                .getMemberProducts());
    }

    public Optional<ProductGroup> findByName(final String name) {
        return repository.findByName(name);
    }
}
