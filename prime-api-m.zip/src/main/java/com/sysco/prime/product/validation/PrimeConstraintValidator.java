package com.sysco.prime.product.validation;

import com.sysco.prime.validation.ValidationErrorType;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import java.lang.annotation.Annotation;

public interface PrimeConstraintValidator<A extends Annotation, T> extends ConstraintValidator<A, T> {
    default void initialize(final A constraintAnnotation) {
    }

    default boolean validationFailedBecause(
            final ConstraintValidatorContext context,
            final ValidationErrorType errorType) {
        context.disableDefaultConstraintViolation();
        context.buildConstraintViolationWithTemplate(errorType.name())
                .addConstraintViolation();
        return false;
    }
}
