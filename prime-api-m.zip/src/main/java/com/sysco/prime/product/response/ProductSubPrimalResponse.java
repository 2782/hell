package com.sysco.prime.product.response;

import com.sysco.prime.product.Product;
import lombok.Data;

@Data
public class ProductSubPrimalResponse {
    private final String subPrimalCode;
    private final String subPrimalDescription;

    public ProductSubPrimalResponse(final Product product) {
        subPrimalCode = product.getSubPrimalCode();
        subPrimalDescription = product.getSubPrimalDescription();
    }
}
