package com.sysco.prime.product;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

import static lombok.AccessLevel.PACKAGE;
import static org.apache.commons.lang3.StringUtils.isEmpty;

@RequiredArgsConstructor(access = PACKAGE)
public enum GrindSize {
    THREE_THIRTY_TWO("3/32"),
    THREE_SIXTEEN("3/16"),
    THREE_EIGHT("3/8"),
    ONE_TWO("1/2");

    @Getter(onMethod = @__(@JsonValue))
    private final String value;

    @Override
    public String toString() {
        return value;
    }

    @JsonCreator
    public static GrindSize from(final String value) {
        if (isEmpty(value)) {
            return null;
        }
        for (final GrindSize grindSize : GrindSize.values()) {
            if (grindSize.getValue().equals(value)) {
                return grindSize;
            }
        }
        throw new IllegalArgumentException();
    }
}
