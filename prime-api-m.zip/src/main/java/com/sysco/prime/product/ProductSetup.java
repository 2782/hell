package com.sysco.prime.product;

import com.sysco.prime.cost.Cost;
import com.sysco.prime.packages.PiecesPackage;
import com.sysco.prime.packages.TarePackage;
import com.sysco.prime.portionRoomTable.PortionRoomTable;
import lombok.Builder;
import lombok.Data;

import java.math.BigDecimal;
import java.util.List;

import static com.sysco.prime.cost.Cost.byproductOnlyCostFrom;
import static java.util.Collections.singletonList;
import static java.util.Objects.nonNull;

@Data
@Builder
public class ProductSetup {
    private final Product product;
    private final PortionRoomTable table;
    private final TarePackage tarePackage;
    private final PiecesPackage piecesPackage;
    private final CutSpecific cutSpecific;
    private final GrindSpecific grindSpecific;
    private final RetailSpecific retailSpecific;
    private final BigDecimal minWeight;
    private final BigDecimal maxWeight;
    private final boolean boneguard;
    private final boolean allocateParToBroadline;
    private final boolean byproductOnly;
    private final BigDecimal byproductOnlyCost;
    private final String ingredientsStatement;
    private final String labelProductDescription;
    private final SpecialDiet specialDiet;
    private final List<Allergen> allergens;

    Product getSetUpProduct(RetailSpecificRepository retailSpecificRepository) {
        product.assignToTable(getTable());
        if (nonNull(getTarePackage())) {
            product.setTarePackage(getTarePackage());
        }

        if (null != product.getRetailSpecific() && null == retailSpecific) {
            retailSpecificRepository.delete(product.getRetailSpecific());
        }
        product.setRetailSpecific(retailSpecific);

        product.setPiecesPackage(getPiecesPackage());

        product.setProductOutput(byproductOnly ? ProductOutput.BYPRODUCT_ONLY : ProductOutput.FINISHED);
        product.setBoneguard(isBoneguard());
        product.setAllocateParToBroadline(isAllocateParToBroadline());
        product.setGrindSpecific(product.isGrinding() ? grindSpecific : GrindSpecific.builder().build());
        product.setCutSpecific(product.isCutting() ? cutSpecific : CutSpecific.builder().tenderized("None").build());
        product.setMinWeight(minWeight);
        product.setMaxWeight(maxWeight);
        product.setIngredientsStatement(ingredientsStatement);
        product.setLabelProductDescription(labelProductDescription);
        product.setSpecialDiet(specialDiet);
        product.setAllergens(allergens);

        return product;
    }

    Cost getSetUpByproductOnlyCost() {
        return byproductOnlyCostFrom(product, byproductOnlyCost);
    }
}
