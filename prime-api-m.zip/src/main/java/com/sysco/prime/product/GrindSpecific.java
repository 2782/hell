package com.sysco.prime.product;

import com.sysco.prime.product.request.ProductSetupRequest;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Embeddable;
import javax.persistence.Enumerated;
import java.io.Serializable;

import static javax.persistence.EnumType.STRING;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Embeddable
public class GrindSpecific implements Serializable {
    private String packInstruction;
    private boolean tenderform;
    @Enumerated(STRING)
    private GrindSize grindSize;
    private String diameter;
    private String thickness;
    private String plateUsed;
    private Integer casesPerTray;
}
