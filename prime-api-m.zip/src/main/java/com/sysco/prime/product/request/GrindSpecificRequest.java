package com.sysco.prime.product.request;

import com.sysco.prime.product.GrindSize;
import com.sysco.prime.product.GrindSpecific;
import com.sysco.prime.product.validation.Positive;
import lombok.Builder;
import lombok.Data;

import javax.persistence.Enumerated;
import javax.validation.constraints.Max;

import static javax.persistence.EnumType.STRING;

@Data
@Builder
public class GrindSpecificRequest {
    private String packInstructionA;
    private String packInstructionB;
    private boolean tenderform;
    @Enumerated(STRING)
    private String grindSize;
    private String diameter;
    private String thickness;
    private String plateUsed;

    @Positive(required = false)
    @Max(9)
    private Integer casesPerTray;

    public GrindSpecific toDomain() {
        return GrindSpecific.builder()
                .packInstruction(
                        String.format("%s,%s",
                                packInstructionA,
                                packInstructionB
                        ))
                .tenderform(tenderform)
                .grindSize(GrindSize.from(grindSize))
                .diameter(diameter)
                .thickness(thickness)
                .plateUsed(plateUsed)
                .casesPerTray(casesPerTray)
                .build();
    }
}
