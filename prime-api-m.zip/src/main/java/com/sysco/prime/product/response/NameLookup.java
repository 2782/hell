package com.sysco.prime.product.response;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

public interface NameLookup {

}
