package com.sysco.prime.product.validation;

import javax.validation.Constraint;
import javax.validation.Payload;
import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import static java.lang.annotation.ElementType.TYPE_USE;

@Constraint(validatedBy = {NoDuplicateProductsValidator.class})
@Documented
@Target({TYPE_USE})
@Retention(RetentionPolicy.RUNTIME)
public @interface NoDuplicateProducts {

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};

    String message() default "Group group cannot contain duplicates";
}