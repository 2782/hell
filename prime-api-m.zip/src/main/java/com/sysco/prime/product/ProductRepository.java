package com.sysco.prime.product;

import com.sysco.prime.PrimeRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Collection;
import java.util.List;
import java.util.Optional;

public interface ProductRepository extends PrimeRepository<Product>, JpaSpecificationExecutor<Product> {
    Optional<Product> findByCode(String productCode);

    List<Product> findByCodeIn(Collection<String> code);

    @Query("SELECT p FROM Product p WHERE p.productOutput = 'FINISHED' AND "
            + "(p.table IS NULL OR p.productGroup IS NULL OR p.maxWeight IS NULL OR p.minWeight IS NULL)")
    List<Product> findAllIncompleteProducts();

    List<Product> findByProductOutputInOrderByCode(List<ProductOutput> productOutputs);

    List<Product> findByProductGroupId(Long productGroupId);

    @Query(nativeQuery = true, value =
            "SELECT * FROM product p WHERE  p.description ~* :description")
    List<Product> findByDescription(@Param("description") String description);

    List<Product> findByProductGroupName(String productGroupName);

    Optional<Product> findFirstBySubPrimalCodeIgnoreCase(String subPrimalCode);
}
