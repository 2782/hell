package com.sysco.prime.product;

public enum ProductCategory {
    FIXED,
    CATCH
}
