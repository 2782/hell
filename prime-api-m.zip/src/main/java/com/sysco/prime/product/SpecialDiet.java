package com.sysco.prime.product;

public enum SpecialDiet {
    HALAL, KOSHER, NONE
}
