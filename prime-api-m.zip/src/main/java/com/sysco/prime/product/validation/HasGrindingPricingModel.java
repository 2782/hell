package com.sysco.prime.product.validation;

import javax.validation.Constraint;
import javax.validation.Payload;
import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import static java.lang.annotation.ElementType.FIELD;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

@Constraint(validatedBy = HasGrindingPricingModelValidator.class)
@Documented
@Target({FIELD})
@Retention(RUNTIME)
public @interface HasGrindingPricingModel {
    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};

    String message() default "PRODUCT_LACKS_GRINDING_PRICING_MODEL";
}
