package com.sysco.prime.product.validation;

import com.sysco.prime.packages.TarePackage;
import com.sysco.prime.packages.TarePackageRepository;
import com.sysco.prime.packages.TarePackageRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.stereotype.Component;

import javax.validation.ConstraintValidatorContext;

import static org.springframework.data.domain.ExampleMatcher.matching;

@Component
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class UniqueTarePackageValidator implements PrimeConstraintValidator<UniqueTarePackage, TarePackageRequest> {
    private final TarePackageRepository packageRepository;

    @Override
    public boolean isValid(final TarePackageRequest request, final ConstraintValidatorContext context) {
        final TarePackage matchingPackage = packageRepository.findOne(Example.of(request.toTarePackage(),
                matching().withIgnorePaths("defaulted", "id"))).orElse(null);

        if (null == request.getId()) {
            return null == matchingPackage;
        } else {
            return matchingPackage == null || matchingPackage.getId().equals(request.getId());
        }
    }
}
