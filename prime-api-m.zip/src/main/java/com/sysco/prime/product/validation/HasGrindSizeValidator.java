package com.sysco.prime.product.validation;

import com.sysco.prime.portionRoomTable.PortionRoomTable;
import com.sysco.prime.portionRoomTable.PortionRoomTableService;
import com.sysco.prime.product.request.ProductSetupRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.validation.ConstraintValidatorContext;

import static com.sysco.prime.productionOrder.ProductionType.GRINDING;

@Component
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class HasGrindSizeValidator implements PrimeConstraintValidator<HasGrindSize, ProductSetupRequest> {
    private final PortionRoomTableService portionRoomTableService;

    @Override
    public boolean isValid(final ProductSetupRequest productSetupRequest, final ConstraintValidatorContext context) {
        if (productSetupRequest.getTableCode() == null) {
            return true;
        }

        final PortionRoomTable table = portionRoomTableService.getTableByCode(productSetupRequest.getTableCode());

        if (table != null && table.getProductionType() == GRINDING) {
            return productSetupRequest.getGrindSpecific() != null
                    && productSetupRequest.getGrindSpecific().getGrindSize() != null;
        }

        return true;
    }
}
