package com.sysco.prime.product;

public enum ProductOutput {
    FINISHED, SOURCE, BYPRODUCT_ONLY
}
