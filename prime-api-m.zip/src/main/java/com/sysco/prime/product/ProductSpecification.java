package com.sysco.prime.product;

import org.springframework.data.jpa.domain.Specification;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import static java.util.Arrays.asList;
import static org.apache.commons.lang3.StringUtils.isNotBlank;

public class ProductSpecification implements Specification<Product> {
    private static final Pattern COMMA = Pattern.compile(",");
    private final Map<String, String> queries;

    public ProductSpecification(final Map<String, String> queries) {
        this.queries = queries;
    }

    private static List<Predicate> getPredicate(final Root<Product> root, final Map<String, String> queries) {
        final List<Predicate> predicate = new ArrayList<>();
        if (isNotBlank(queries.get("product-codes"))) {
            predicate.add(root.get("code").in(asList(COMMA.split(queries.get("product-codes")))));
        }

        return predicate;
    }

    @Override
    public Predicate toPredicate(final Root<Product> root, final CriteriaQuery<?> query, final CriteriaBuilder cb) {
        final List<Predicate> predicate = getPredicate(root, queries);
        final Predicate[] pre = new Predicate[predicate.size()];
        return query.distinct(true).where(predicate.toArray(pre)).getRestriction();
    }
}
