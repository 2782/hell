package com.sysco.prime.product.validation;

import com.sysco.prime.product.Allergen;
import com.sysco.prime.product.AllergenService;
import com.sysco.prime.validation.ValidationErrorType;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.validation.ConstraintValidatorContext;
import java.util.Optional;

@Component
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class ValidAllergenValidator implements PrimeConstraintValidator<ValidAllergen, String> {
    private final AllergenService allergenService;

    @Override
    public boolean isValid(final String allergenName,
                           final ConstraintValidatorContext context) {
        final Optional<Allergen> maybeAllergen = allergenService.findByName(allergenName);
        if (!maybeAllergen.isPresent()) {
            return validationFailedBecause(context, ValidationErrorType.ALLERGEN_DOES_NOT_EXIST);
        }
        return true;
    }
}
