package com.sysco.prime.product;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.sysco.prime.shared.model.TransactionalEntity;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

import javax.persistence.Entity;
import javax.persistence.ManyToMany;
import java.util.List;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@EqualsAndHashCode(callSuper = false)
@ToString(exclude = {"products"})
public class Allergen extends TransactionalEntity {
    private String name;
    private String displayName;

    @JsonIgnore
    @ManyToMany(mappedBy = "allergens")
    private List<Product> products;
}
