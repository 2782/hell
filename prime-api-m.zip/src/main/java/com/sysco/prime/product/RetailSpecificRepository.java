package com.sysco.prime.product;

import com.sysco.prime.PrimeRepository;

public interface RetailSpecificRepository extends PrimeRepository<RetailSpecific> {
}
