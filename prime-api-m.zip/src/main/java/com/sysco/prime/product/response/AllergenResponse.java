package com.sysco.prime.product.response;

import com.sysco.prime.product.Allergen;
import lombok.AllArgsConstructor;
import lombok.Data;

@AllArgsConstructor
@Data
public class AllergenResponse {
    private final String name;
    private final String displayName;

    public AllergenResponse(final Allergen allergen) {
        this.name = allergen.getName();
        this.displayName = allergen.getDisplayName();
    }
}
