package com.sysco.prime.product.response;

import com.sysco.prime.packages.TarePackageResponse;
import com.sysco.prime.product.RetailSpecific;
import lombok.Data;

import java.math.BigDecimal;

@Data
public class RetailSpecificResponse {
    private final BigDecimal price;
    private final TarePackageResponse tare;
    private final BigDecimal minWeight;
    private final BigDecimal maxWeight;
    private final String retailNumber;

    public RetailSpecificResponse(final RetailSpecific retailSpecific) {
        price = retailSpecific.getPrice();

        minWeight = retailSpecific.getMinWeight();
        maxWeight = retailSpecific.getMaxWeight();

        if (retailSpecific.getTare() != null) {
            tare = new TarePackageResponse(retailSpecific.getTare());
        } else {
            tare = null;
        }

        retailNumber = retailSpecific.getRetailNumber();
    }
}
