package com.sysco.prime.product;

import com.sysco.prime.cost.Cost;
import com.sysco.prime.cost.CostService;
import com.sysco.prime.exception.NotFoundException;
import com.sysco.prime.product.response.IncompleteProductResponse;
import com.sysco.prime.productionOrder.ProductionOrderService;
import com.sysco.prime.profile.ProfileService;
import com.sysco.prime.sus.client.SusClient;
import com.sysco.prime.sus.model.product.SusProductData;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import java.util.function.Predicate;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import static com.sysco.prime.sus.eventProcessors.ProductProcessor.buildProductFromSus;
import static com.sysco.prime.sus.eventProcessors.ProductProcessor.mergeProduct;
import static com.sysco.prime.utils.RegexUtils.escapeSpecificCharFromRegex;
import static java.lang.String.format;
import static java.util.Arrays.asList;
import static java.util.Collections.emptyList;
import static java.util.Collections.singletonList;
import static java.util.stream.Collectors.toList;
import static java.util.stream.Collectors.toSet;

@Slf4j
@Service
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class ProductService {
    private static final int PRODUCT_CODE_LENGTH = 7;
    private static final Pattern COMMA = Pattern.compile(",");

    private final ProductRepository productRepository;
    private final ProductionOrderService productionOrderService;
    private final ItemMasterUpdateService itemMasterUpdateService;
    private final SusClient susClient;
    private final ProfileService profileService;
    private final Lock primeAndSusTogether = new ReentrantLock();
    private final RetailSpecificRepository retailSpecificRepository;
    private final CostService costService;

    public static String formatProductCode(final String productCode) {
        if (productCode == null) {
            return null;
        }
        String productCodeWithPrefixZero = productCode;
        if (PRODUCT_CODE_LENGTH >= productCode.length()) {
            productCodeWithPrefixZero = ("0000000" + productCode).substring(productCode.length());
        }
        return productCodeWithPrefixZero;
    }

    private static boolean isProductMatches(final Product product, final List<String> descriptions) {
        return descriptions.stream()
                .allMatch(description -> product.isDescriptionMatch(getDescriptionMatchingRegex(description)));
    }

    private static String getDescriptionMatchingRegex(final String description) {
        final String escapedDescription = escapeSpecificCharFromRegex(description);

        // could match multiple word
        // like 'LA' will match 'LA Steak Beef', 'LA Steak' need also match 'LA Steak Beef'
        return format("^(.*\\W)?%s(\\W.*)?$", escapedDescription);
    }

    private String limitProductCodeTo7(final String productCode) {
        if (productCode == null) {
            return null;
        }
        int length = productCode.length();

        if (length > 7) {
            return formatProductCode(productCode.substring(0, 7));
        }
        return formatProductCode(productCode);
    }

    private Map<String, Product> findByCodesMappedIgnoringSus(final Set<String> productCodes) {
        final List<Product> products = productRepository.findByCodeIn(productCodes);
        final Map<String, Product> productsMap = new HashMap<>();

        products.forEach(product -> productsMap.put(product.getCode(), product));

        return productsMap;
    }

    public Map<String, Product> findByCodesMapped(final Set<String> productCodes) {
        primeAndSusTogether.lock();
        try {
            final Map<String, Product> foundInPrime = findByCodesMappedIgnoringSus(productCodes);
            final Set<String> codesToCheckInSus = productCodes.stream()
                    .filter(code -> !foundInPrime.containsKey(code))
                    .collect(toSet());

            final Map<String, Product> completeFromSus = new HashMap<>();
            final Map<String, Product> incompleteFromSus = new HashMap<>();

            foundInPrime.forEach((code, product) -> {
                if (product.isCompleteFromSus()) {
                    completeFromSus.put(code, product);
                } else {
                    incompleteFromSus.put(code, product);
                }
            });

            codesToCheckInSus.addAll(incompleteFromSus.keySet());

            if (!codesToCheckInSus.isEmpty()) {
                final Map<String, SusProductData> foundInSus = susClient.getProductsFromSus(
                        codesToCheckInSus,
                        profileService.get());

                final List<Product> productsToSave = foundInSus
                        .entrySet()
                        .stream()
                        .map(entry -> {
                            final String code = entry.getKey();
                            final SusProductData productInSus = entry.getValue();
                            if (incompleteFromSus.containsKey(code)) {
                                final Product productToMerge = incompleteFromSus.remove(code);
                                return mergeProduct(productToMerge, productInSus);
                            } else {
                                return buildProductFromSus(productInSus);
                            }
                        })
                        .collect(toList());
                final List<Product> mergedProducts = productsToSave.isEmpty()
                        ? productsToSave
                        : productRepository.saveAll(productsToSave);
                mergedProducts.forEach(mergedProduct -> completeFromSus.put(mergedProduct.getCode(), mergedProduct));
                completeFromSus.putAll(incompleteFromSus);
            }

            return completeFromSus;
        } finally {
            primeAndSusTogether.unlock();
        }
    }

    public Product findByCode(final String productCode) {
        // TODO: No.  This should be a *distributed* lock
        // (1) Right thing to do: Teach the UI to use a chained Promise when referring to products
        // in *every possible spot* (eg, looking up Product async, and Cost)
        // (2) Introduce distributed transactions in API, and the complexity that comes with
        primeAndSusTogether.lock();
        try {
            final String limitedProductCode = limitProductCodeTo7(productCode);
            final Product foundInPrime = findByCodeIgnoringSus(limitedProductCode);
            if (null != foundInPrime && foundInPrime.isCompleteFromSus()) {
                return foundInPrime;
            }

            final SusProductData foundInSus = susClient.getProductFromSus(limitedProductCode, profileService.get());
            if (null != foundInSus) {
                final Product mergedProduct = null != foundInPrime
                        ? mergeProduct(foundInPrime, foundInSus)
                        : buildProductFromSus(foundInSus);
                return productRepository.save(mergedProduct);
            }

            if (null != foundInPrime) {
                return foundInPrime; // Go with what we have, even if missing data from SUS
            }

            throw new NotFoundException(
                    format("[find product] product not found by code: %s", limitedProductCode));
        } finally {
            primeAndSusTogether.unlock();
        }
    }

    public Product getProductAndCheckInCache(final Map<String, Product> productMap, final String productCode) {
        final Product product;
        if (productMap.containsKey(productCode)) {
            product = productMap.get(productCode);
        } else {
            product = findByCode(productCode);
            productMap.put(product.getCode(), product);
        }
        return product;
    }

    public Product findByCodeIgnoringSus(final String productCode) {
        return productRepository.findByCode(productCode).orElse(null);
    }

    public Product findByCodeFillZeroBefore(final String productCode) throws NotFoundException {
        return findByCode(formatProductCode(productCode));
    }

    List<Product> findAllProducts(final Map<String, String> queries) {
        return productRepository.findAll(new ProductSpecification(queries))
                .stream()
                .sorted(Comparator.comparing(Product::getCode))
                .collect(toList());
    }

    List<Product> productsInGroupOf(final Long productGroupId) {
        return productRepository.findByProductGroupId(productGroupId);
    }

    public void create(final Product product) {
        final Product found = findByCodeIgnoringSus(product.getCode());
        if (null != found) {
            return;
        }
        productRepository.save(product);
    }

    public void save(final List<Product> products) {
        productRepository.saveAll(products);
    }

    public List<Product> findByCodeIn(final Collection<String> codes) {
        return productRepository.findByCodeIn(codes);
    }

    List<IncompleteProductResponse> findAllIncompleteProducts() {
        return productRepository.findAllIncompleteProducts().stream()
                .sorted(Comparator.comparing(Product::getCreatedAt).reversed()
                        .thenComparing(Product::getCode))
                .map(IncompleteProductResponse::fromProduct)
                .collect(toList());
    }

    @Transactional
    public void setupProduct(final ProductSetup productSetup) {
        final Product productToSetup = productSetup.getSetUpProduct(retailSpecificRepository);
        final Product savedProduct = productRepository.save(productToSetup);
        productionOrderService.assignCutOrderBelongToProductToTable(savedProduct.getCode(), savedProduct.getTable());

        if (savedProduct.isByproductOnlyOutput()) {
            final Cost byproductOnlyCost = productSetup.getSetUpByproductOnlyCost();
            costService.createByproductOnlyCost(byproductOnlyCost);
            itemMasterUpdateService.updateSusItemMaster(savedProduct, byproductOnlyCost);
        } else {
            itemMasterUpdateService.updateSusItemMaster(savedProduct);
        }
    }

    List<Product> findByDescriptions(final String queryString) {
        final List<String> descriptions = COMMA.splitAsStream(queryString)
                .map(String::trim)
                .filter(s -> !s.isEmpty())
                .collect(toList());
        if (descriptions.isEmpty()) {
            return emptyList();
        }
        final String firstDescription = descriptions.get(0);

        final List<Product> products =
                productRepository.findByDescription(getDescriptionMatchingRegex(firstDescription));
        final Predicate<Product> matchesDescriptions = product -> isProductMatches(product, descriptions);
        return products.stream()
                .filter(matchesDescriptions)
                .collect(toList());
    }

    public List<Product> findByProductGroupName(final String blend) {
        return productRepository.findByProductGroupName(blend);
    }

    public void sync() {
        productRepository.findAll().forEach(product -> findByCode(product.getCode()));
    }

    public Product findBySubPrimalCode(final String subPrimalCode) {
        final Optional<Product> optionalProduct = productRepository.findFirstBySubPrimalCodeIgnoreCase(subPrimalCode);
        if (!optionalProduct.isPresent()) {
            throw new NotFoundException(
                    format("[find subPrimal] product not found by subPrimalCode: %s", subPrimalCode));
        }
        return optionalProduct.get();
    }

    public List<Product> getAllFinishedAndByproductOnlyProducts() {
        return productRepository.findByProductOutputInOrderByCode(asList(
                ProductOutput.FINISHED,
                ProductOutput.BYPRODUCT_ONLY));
    }

    public Map<String, Product> getAllSourceProducts() {
        return productRepository.findByProductOutputInOrderByCode(singletonList(ProductOutput.SOURCE)).stream()
                .collect(Collectors.toMap(Product::getCode, sourceProduct -> sourceProduct));
    }
}
