package com.sysco.prime.product.validation;

import com.sysco.prime.exception.NotFoundException;
import com.sysco.prime.product.Product;
import com.sysco.prime.product.ProductCategory;
import com.sysco.prime.product.ProductService;
import com.sysco.prime.product.request.ProductSetupRequest;
import com.sysco.prime.product.request.RetailSpecificRequest;
import com.sysco.prime.validation.ValidationErrorType;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.validation.ConstraintValidatorContext;

@Component
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class RequiredRetailFieldsValidator implements PrimeConstraintValidator<RequiredRetailFields,
        ProductSetupRequest> {
    private final ProductService productService;

    @Override
    public boolean isValid(final ProductSetupRequest request, final ConstraintValidatorContext context) {
        if (null == request.getRetailSpecific()) {
            return true;
        }

        ProductCategory category;
        try {
            final Product product = productService.findByCode(request.getProductCode());
            category = product.getCategory();
        } catch (NotFoundException e) {
            return true;
        }

        final RetailSpecificRequest retailSpecific = request.getRetailSpecific();

        switch (category) {
            case FIXED:
                return !isMissingAnyFixedProductFields(retailSpecific) || validationFailedBecause(context,
                        ValidationErrorType.REQUIRED);
            case CATCH:
            default:
                return !isMissingAnyCatchProductFields(retailSpecific) || validationFailedBecause(context,
                        ValidationErrorType.REQUIRED);
        }
    }

    private boolean isMissingAnyCatchProductFields(final RetailSpecificRequest retailSpecific) {
        return isMissingAnyFixedProductFields(retailSpecific)
                || retailSpecific.getMaxWeight() == null;
    }

    private boolean isMissingAnyFixedProductFields(final RetailSpecificRequest retailSpecific) {
        return retailSpecific.getPrice() == null
                || retailSpecific.getTare() == null
                || retailSpecific.getMinWeight() == null;
    }
}
