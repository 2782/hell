package com.sysco.prime.productionOrder.validation;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

public class TicketCodeUtils {
    static boolean nonParseableDate(final String dateString, final String dateFormat) {
        try {
            final DateTimeFormatter formatter = DateTimeFormatter.ofPattern(dateFormat);
            LocalDate.parse(dateString, formatter);
            return false;
        } catch (DateTimeParseException e) {
            return true;
        }
    }

    static boolean missingPrefix(final char valueToCheck, final char character) {
        return valueToCheck != character && valueToCheck != Character.toLowerCase(character);
    }

    static boolean invalidLength(final String value, final int length) {
        return value.length() != length;
    }
}
