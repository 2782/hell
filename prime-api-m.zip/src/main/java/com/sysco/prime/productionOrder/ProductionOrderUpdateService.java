package com.sysco.prime.productionOrder;

import com.sysco.prime.customerOrder.CustomerOrder;
import com.sysco.prime.customerOrder.LineItem;
import com.sysco.prime.customerOrder.LineItemDiff;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

import static com.sysco.prime.productionOrder.CutOrderSource.LINE_ITEM;
import static com.sysco.prime.unitOfMeasure.UnitOfMeasure.PIECE;
import static java.lang.Math.ceil;
import static java.lang.Math.max;
import static java.util.stream.Collectors.toList;

@Service
@Slf4j
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class ProductionOrderUpdateService {
    private final ProductionOrderRepository productionOrderRepository;

    public void update(final LineItemDiff itemDiff) {
        final List<ProductionOrder> existingOrders = getProductionOrdersForLineItem(itemDiff);

        final List<ProductionOrder> ordersWithShipDateUpdated =
                updateShipDate(existingOrders, itemDiff);

        final List<ProductionOrder> ordersWithUnitOfMeasureUpdated =
                updateUnitOfMeasure(ordersWithShipDateUpdated, itemDiff);

        final List<ProductionOrder> ordersWithQtyDecreased =
                decreaseOrders(ordersWithUnitOfMeasureUpdated, itemDiff);

        productionOrderRepository.saveAll(ordersWithQtyDecreased);
    }

    List<ProductionOrder> updateShipDate(
            final List<ProductionOrder> productionOrders,
            final LineItemDiff itemDiff) {
        final LineItem item = itemDiff.getNewItem();
        final CustomerOrder customerOrder = item.getCustomerOrder();
        return productionOrders.stream().map(productionOrder -> {
            final ProductionOrder updated = productionOrder.toBuilder()
                    .deliveryDate(customerOrder.getShipDate())
                    .build();
            updated.setCreatedAt(productionOrder.getCreatedAt());
            updated.setId(productionOrder.getId());
            return updated;
        }).collect(toList());
    }

    List<ProductionOrder> decreaseOrders(
            final List<ProductionOrder> productionOrders,
            final LineItemDiff itemDiff) {
        final LineItem lineItem = itemDiff.getNewItem();

        final int quantity = lineItem.getQuantity();
        final int sum = productionOrders.stream()
                .mapToInt(productionOrder -> productionOrder.isActive()
                        ? productionOrder.getQtyToProduce()
                        : productionOrder.getQtyAlreadyPacked())
                .sum();
        int quantityRemainingToDecrement = sum - quantity;

        final List<ProductionOrder> decreasedOrders = new ArrayList<>();
        for (final ProductionOrder productionOrder : productionOrders) {
            if (quantityRemainingToDecrement > 0 && productionOrder.isActive()) {
                final int previousQtyToProduce = productionOrder.getQtyToProduce();
                final int updatedQtyToProduce = max(previousQtyToProduce - quantityRemainingToDecrement, 0);

                productionOrder.updateProduceQuantities(updatedQtyToProduce);

                decreasedOrders.add(productionOrder);

                quantityRemainingToDecrement -= previousQtyToProduce - updatedQtyToProduce;
            } else {
                decreasedOrders.add(productionOrder);
            }
        }
        return decreasedOrders;
    }

    List<ProductionOrder> updateUnitOfMeasure(final List<ProductionOrder> existingProductionOrders,
                                              final LineItemDiff itemDiff) {
        if (itemDiff.unitOfMeasureHasChangedFromCasesToPieces()) {
            final List<ProductionOrder> updatedOrders = existingProductionOrders.stream()
                    .map(productionOrder -> {
                        int qtyToProduceInCases = (int) ceil(
                                productionOrder.getQtyToProduce() * 1.0 / productionOrder.getPiecesPerCase());

                        final ProductionOrder updatedOrder = productionOrder.toBuilder()
                                .qtyToProduceInCases(qtyToProduceInCases)
                                .unitOfMeasure(PIECE)
                                .build();
                        updatedOrder.setCreatedAt(productionOrder.getCreatedAt());
                        updatedOrder.setId(productionOrder.getId());

                        updatedOrder.setToPackedIfOrderedAmountFulfilled();

                        return updatedOrder;
                    })
                    .collect(toList());
            return updatedOrders;
        }

        return existingProductionOrders;

    }

    private List<ProductionOrder> getProductionOrdersForLineItem(final LineItemDiff itemDiff) {
        return productionOrderRepository.findBySourceAndSourceId(LINE_ITEM, itemDiff.getId());
    }
}
