package com.sysco.prime.productionOrder;

import com.sysco.prime.PrimeRepository;

import java.util.Optional;

public interface BlendRepository extends PrimeRepository<Blend> {
    Optional<Blend> findByName(final String name);
}
