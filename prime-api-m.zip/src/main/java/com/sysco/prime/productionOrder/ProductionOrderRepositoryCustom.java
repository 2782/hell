package com.sysco.prime.productionOrder;

import com.sysco.prime.portionRoomTable.PortionRoomTable;

import java.util.List;
import java.util.Optional;

import static com.sysco.prime.productionOrder.ProductionType.GRINDING;
import static java.util.Collections.emptyList;
import static java.util.stream.Collectors.toList;

@FunctionalInterface
public interface ProductionOrderRepositoryCustom {
    List<ProductionOrder> findAll(
            final String roomCode,
            final Optional<ProductionType> productionType,
            final List<Long> stationIds,
            final Optional<PortionRoomTable> table,
            final Optional<Boolean> cancelled,
            final List<ProductionOrderStatus> cutOrderStatus);

    default List<ProductionOrder> findGrindingOrders(final String roomCode, final Optional<List<String>> statuses,
                                                     final Optional<Boolean> cancelled) {
        List<ProductionOrderStatus> filteredStatuses = emptyList();
        if (statuses.isPresent()) {
            filteredStatuses = statuses.get().stream().map(ProductionOrderStatus::from).collect(toList());
        }

        return findAll(
                roomCode,
                Optional.of(GRINDING),
                emptyList(),
                Optional.empty(),
                cancelled,
                filteredStatuses
        );
    }
}
