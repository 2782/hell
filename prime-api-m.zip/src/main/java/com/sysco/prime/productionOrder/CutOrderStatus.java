package com.sysco.prime.productionOrder;

import com.fasterxml.jackson.annotation.JsonCreator;

public enum CutOrderStatus {
    TO_CUT("to-cut"),
    TO_PACK("to-pack"),
    PACKED("packed"),
    DISMISSED("dismissed"),
    CLOSED("closed");

    private final String value;

    CutOrderStatus(final String value) {
        this.value = value;
    }

    @JsonCreator
    public static CutOrderStatus from(final String value) {
        for (final CutOrderStatus cutOrderStatus : CutOrderStatus.values()) {
            if (cutOrderStatus.toString().equals(value)) {
                return cutOrderStatus;
            }
        }
        throw new IllegalArgumentException();
    }

    @Override
    public String toString() {
        return value;
    }
}
