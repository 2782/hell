package com.sysco.prime.productionOrder;

import com.sysco.prime.cutType.CutType;

public enum OrderType {
    STANDARD, BANQUET;

    static OrderType from(final CutType cutType) {
        return valueOf(cutType.toString());
    }
}
