package com.sysco.prime.productionOrder;

import com.fasterxml.jackson.annotation.JsonCreator;

import java.util.Arrays;
import java.util.List;

public enum ProductionOrderStatus {
    TO_APPROVE("to-approve"),
    TO_CUT("to-cut"),
    TO_GRIND("to-grind"),
    TO_PACK("to-pack"),
    PACKED("packed"),
    DISMISSED("dismissed"),
    CLOSED("closed");

    private final String value;

    ProductionOrderStatus(final String value) {
        this.value = value;
    }

    public static ProductionOrderStatus from(final ProductionType productionType) {
        switch (productionType) {
            case CUTTING:
                return TO_CUT;
            case GRINDING:
                return TO_APPROVE;
            default:
                return null;
        }
    }

    @JsonCreator
    public static ProductionOrderStatus from(final String value) {
        for (final ProductionOrderStatus cutOrderStatus : ProductionOrderStatus.values()) {
            if (cutOrderStatus.toString().equalsIgnoreCase(value)) {
                return cutOrderStatus;
            }
        }
        throw new IllegalArgumentException();
    }

    @Override
    public String toString() {
        return value;
    }

    public static List<ProductionOrderStatus> unfinishedStatuses() {
        return Arrays.asList(TO_CUT, TO_PACK);
    }

    public static List<ProductionOrderStatus> unclosedStatuses() {
        return Arrays.asList(TO_CUT, TO_GRIND, TO_PACK, PACKED, DISMISSED);
    }
}
