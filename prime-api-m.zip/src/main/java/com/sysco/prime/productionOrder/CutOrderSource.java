package com.sysco.prime.productionOrder;

public enum CutOrderSource {
    LINE_ITEM, HOUSE_PAR
}
