package com.sysco.prime.productionOrder;

import com.sysco.prime.customerOrder.LineItem;
import com.sysco.prime.portionRoomTable.PortionRoomTable;
import lombok.NoArgsConstructor;
import org.springframework.data.jpa.domain.Specification;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

import static java.util.Objects.isNull;
import static java.util.stream.Collectors.toList;
import static lombok.AccessLevel.PRIVATE;
import static org.springframework.data.jpa.domain.Specification.where;

@SuppressWarnings("OptionalUsedAsFieldOrParameterType")
@NoArgsConstructor(access = PRIVATE)
final class CutOrderSpecification {
    private static Specification<ProductionOrder> areEqual(
            final String attribute,
            final Optional<?> object) {
        return object.<Specification<ProductionOrder>>map(o -> (root, query, cb) -> cb.equal(root.get(attribute), o))
                .orElse(null);
    }

    private static Specification<ProductionOrder> areIn(
            final String attribute,
            final List<?> list) {
        return list.isEmpty()
                ? null
                : (root, query, cb) -> root.<ProductionOrder>get(attribute).in(list);
    }

    private static Specification<ProductionOrder> areStationIdIn(
            final String attribute1,
            final String attribute2,
            final String attribute3,
            final List<Long> stationIds) {
        return !isNull(stationIds) && !stationIds.isEmpty()
                ? (root, query, cb) -> root.join(attribute1).join(attribute2).get(attribute3).in(stationIds)
                : null;
    }

    private static Specification<ProductionOrder> areRoomCodeEqual(final Optional<String> roomCode) {
        return roomCode.<Specification<ProductionOrder>>map(s -> (root, query, cb) -> cb.equal(root
                .join("portionRoomTable")
                .join("station")
                .get("room")
                .get("code"), s))
                .orElse(null);
    }

    static Specification<ProductionOrder> extendQuery(
            final String roomCode,
            final Optional<ProductionType> productionType,
            final List<Long> stationIds,
            final Optional<PortionRoomTable> table,
            final List<ProductionOrderStatus> status) {
        return where(areIn("status", status))
                .and(areStationIdIn("portionRoomTable", "station", "id", stationIds))
                .and(areEqual("portionRoomTable", table))
                .and(areRoomCodeEqual(Optional.of(roomCode)))
                .and(areEqual("productionType", productionType));
    }

    static List<ProductionOrder> filterCancelledOrDeleted(final Optional<Boolean> cancelled,
                                                          final List<ProductionOrder> productionOrders) {
        if (!cancelled.isPresent()) {
            return productionOrders;
        }

        final Boolean cancelledValue = cancelled.get();

        return productionOrders.stream()
                .filter(order -> {
                    if (order.getCustomerOrder() != null) {
                        for (LineItem item : order.getCustomerOrder().getLineItems()) {
                            if (Objects.equals(item.getId(), order.getSourceId())) {
                                return cancelledValue == item.isDeleted();
                            }
                        }
                    }
                    return !cancelledValue;
                }).collect(toList());
    }
}
