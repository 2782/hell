package com.sysco.prime.productionOrder.response.cut;

import com.sysco.prime.customerOrder.LineItem;
import com.sysco.prime.customerOrder.response.CustomerOrderResponse;
import com.sysco.prime.portionRoomTable.response.PortionRoomTableResponse;
import com.sysco.prime.product.response.ProductResponse;
import com.sysco.prime.productionOrder.Blend;
import com.sysco.prime.productionOrder.CutOrderSource;
import com.sysco.prime.productionOrder.ProductionOrder;
import com.sysco.prime.productionOrder.ProductionOrderStatus;
import com.sysco.prime.productionOrder.ProductionType;
import com.sysco.prime.unitOfMeasure.UnitOfMeasure;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.ToString;

import java.time.LocalDate;
import java.time.OffsetDateTime;

@Getter
@AllArgsConstructor
@Builder(toBuilder = true)
@ToString
@EqualsAndHashCode
public class GrindOrderResponse {
    private final Long id;
    private final CutOrderSource source;
    private final UnitOfMeasure unitOfMeasure;
    private final ProductResponse product;
    private final String packInstruction;
    private final Integer piecesPerCase;
    private final String producingInstruction;
    private final Integer qtyToProduce;
    private final Integer qtyPacked;
    private final LocalDate deliveryDate;
    private final Integer qtyInBoxes;
    private final CustomerOrderResponse customerOrder;
    private final PortionRoomTableResponse portionRoomTable;
    private final ProductionOrderStatus status;
    private final OffsetDateTime approvedAt;
    private final Long purchaseOrderId;
    private final Boolean deleted;
    private final Boolean updated;
    private final Blend blend;
    private final ProductionType productionType;
    private final String cutType;


    public GrindOrderResponse(final ProductionOrder productionOrder) {
        id = productionOrder.getId();
        source = productionOrder.getSource();
        unitOfMeasure = productionOrder.getUnitOfMeasure();
        packInstruction = productionOrder.getPackInstruction();
        piecesPerCase = productionOrder.getPiecesPerCase();
        producingInstruction = productionOrder.getProducingInstruction();
        qtyToProduce = productionOrder.getQtyToProduce();
        qtyPacked = productionOrder.getQtyPacked();
        deliveryDate = productionOrder.getDeliveryDate();
        qtyInBoxes = productionOrder.getQtyToProduceInCases();
        status = productionOrder.getStatus();
        approvedAt = productionOrder.getStartProducingAt();
        purchaseOrderId = productionOrder.getPurchaseOrderId();
        blend = productionOrder.getBlend();
        productionType = productionOrder.getProductionType();
        cutType = productionOrder.getOrderType().toString();

        customerOrder = productionOrder.getCustomerOrder() != null
                ? new CustomerOrderResponse(productionOrder.getCustomerOrder())
                : null;

        portionRoomTable = productionOrder.getPortionRoomTable() != null
                ? new PortionRoomTableResponse(productionOrder.getPortionRoomTable())
                : null;

        product = productionOrder.getProduct() != null
                ? new ProductResponse(productionOrder.getProduct())
                : null;

        if (productionOrder.getProduct() != null
                && productionOrder.getCustomerOrder() != null
                && productionOrder.getLineItem() != null
        ) {
            LineItem lineItem = productionOrder.getLineItem();
            deleted = lineItem.isDeleted();
            updated = lineItem.getUpdatedAt() != null;
        } else {
            deleted = false;
            updated = false;
        }
    }
}
