package com.sysco.prime.productionOrder;

import com.sysco.prime.customerOrder.CustomerOrder;
import com.sysco.prime.customerOrder.LineItem;
import com.sysco.prime.customerOrder.LineItemOutService;
import com.sysco.prime.customerOrder.LineItemService;
import com.sysco.prime.customerOrder.PrimeLineItem;
import com.sysco.prime.customerOrder.StockAllocation;
import com.sysco.prime.customerOrder.StockAllocationService;
import com.sysco.prime.exception.InvalidValueException;
import com.sysco.prime.exception.NotFoundException;
import com.sysco.prime.housePar.HousePar;
import com.sysco.prime.housePar.HouseParService;
import com.sysco.prime.packages.PackageService;
import com.sysco.prime.portionRoom.PortionRoom;
import com.sysco.prime.portionRoom.PortionRoomService;
import com.sysco.prime.portionRoomTable.PortionRoomTable;
import com.sysco.prime.portionRoomTable.PortionRoomTableService;
import com.sysco.prime.printer.client.PrintJob;
import com.sysco.prime.printer.client.PrinterClient;
import com.sysco.prime.printer.model.GrindTicketData;
import com.sysco.prime.product.PlateAssociation;
import com.sysco.prime.product.PlateAssociationService;
import com.sysco.prime.product.Product;
import com.sysco.prime.product.ProductService;
import com.sysco.prime.productionOrder.comparator.RoutingGroupsComparator;
import com.sysco.prime.productionOrder.response.cut.CutOrderStationSummary;
import com.sysco.prime.productionOrder.response.cut.CutOrderTableSummary;
import com.sysco.prime.profile.Profile;
import com.sysco.prime.profile.ProfileService;
import com.sysco.prime.purchaseOrder.PurchaseOrder;
import com.sysco.prime.purchaseOrder.PurchaseOrderService;
import com.sysco.prime.reporting.ReportingPublisher;
import com.sysco.prime.station.Station;
import com.sysco.prime.sus.model.stock.SusAsohData;
import com.sysco.prime.sus.model.stock.SusAsohProductData;
import com.sysco.prime.sus.service.AsohService;
import com.sysco.prime.systemConfig.SystemConfigService;
import com.sysco.prime.unitOfMeasure.UnitOfMeasure;
import com.sysco.prime.utils.TimeUtils;
import com.sysco.prime.yieldModel.GrindingYieldModel;
import com.sysco.prime.yieldModel.GrindingYieldModelRepository;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.data.annotation.Transient;
import org.springframework.orm.ObjectOptimisticLockingFailureException;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.math.BigDecimal;
import java.time.Clock;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Objects;
import java.util.Optional;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import static com.sysco.prime.productionOrder.CutOrderSource.HOUSE_PAR;
import static com.sysco.prime.productionOrder.CutOrderSource.LINE_ITEM;
import static com.sysco.prime.productionOrder.CutOrderSpecification.filterCancelledOrDeleted;
import static com.sysco.prime.productionOrder.ProductionOrder.aggregateQuantities;
import static com.sysco.prime.productionOrder.ProductionOrder.byShipDate;
import static com.sysco.prime.productionOrder.ProductionOrder.byTimedWillCall;
import static com.sysco.prime.productionOrder.ProductionOrder.fromHouseParForCutting;
import static com.sysco.prime.productionOrder.ProductionOrder.fromHouseParForGrinding;
import static com.sysco.prime.productionOrder.ProductionOrder.subSortedComparator;
import static com.sysco.prime.productionOrder.ProductionOrderStatus.CLOSED;
import static com.sysco.prime.productionOrder.ProductionOrderStatus.TO_APPROVE;
import static com.sysco.prime.productionOrder.ProductionOrderStatus.TO_CUT;
import static com.sysco.prime.productionOrder.ProductionOrderStatus.TO_PACK;
import static com.sysco.prime.productionOrder.ProductionOrderStatus.unclosedStatuses;
import static com.sysco.prime.productionOrder.ProductionType.CUTTING;
import static com.sysco.prime.productionOrder.response.cut.CutOrderStationSummary.buildCutOrderStationSummary;
import static com.sysco.prime.productionOrder.response.cut.CutOrderTableSummary.buildCutOrderTableSummary;
import static com.sysco.prime.unitOfMeasure.UnitOfMeasure.PIECE;
import static java.lang.Boolean.FALSE;
import static java.lang.String.format;
import static java.time.OffsetDateTime.now;
import static java.util.Collections.emptyList;
import static java.util.Collections.singletonList;
import static java.util.Objects.isNull;
import static java.util.Objects.nonNull;
import static java.util.Optional.empty;
import static java.util.stream.Collectors.groupingBy;
import static java.util.stream.Collectors.toCollection;
import static java.util.stream.Collectors.toList;
import static java.util.stream.Collectors.toSet;
import static javax.transaction.Transactional.TxType.REQUIRES_NEW;

@Service
@Slf4j
public class ProductionOrderService {
    private final ProductionOrderRepository productionOrderRepository;
    private final GrindingYieldModelRepository grindingYieldModelRepository;
    private final BlendRepository blendRepository;
    private final PortionRoomTableService portionRoomTableService;
    private final PortionRoomService portionRoomService;
    private final SystemConfigService systemConfigService;
    private final PurchaseOrderService purchaseOrderService;
    private final ReportingPublisher reportingPublisher;
    private final ProfileService profileService;
    private final PrinterClient printerClient;
    private final ProductService productService;
    private final PlateAssociationService plateAssociationService;
    private final PackageService packageService;
    private final LineItemOutService lineItemOutService;
    private final StockAllocationService stockAllocationService;
    private final AsohService asohService;
    private final HouseParService houseParService;
    private final LineItemService lineItemService;
    private final Clock when;

    /**
     * Manual constructor so can use {@code @Lazy} on <var>portionRoomService</var>.  This breaks a circular dependency
     * between this class and that one.
     *
     * @see <a href="http://www.baeldung.com/circular-dependencies-in-spring">Circular Dependencies in Spring</a>
     * @see <a href="https://github.com/rzwitserloot/lombok/issues/1335#issuecomment-376163200">onX support for
     * constructor argument annotations</a>
     */
    @Autowired
    public ProductionOrderService(
            final ProductionOrderRepository productionOrderRepository,
            final GrindingYieldModelRepository grindingYieldModelRepository,
            final BlendRepository blendRepository,
            final PortionRoomTableService portionRoomTableService,
            @Lazy final PortionRoomService portionRoomService,
            final SystemConfigService systemConfigService,
            @Lazy final PurchaseOrderService purchaseOrderService,
            final ReportingPublisher reportingPublisher,
            final ProfileService profileService,
            final PrinterClient printerClient,
            @Lazy final ProductService productService,
            final PlateAssociationService plateAssociationService,
            final PackageService packageService,
            @Lazy final LineItemOutService lineItemOutService,
            final StockAllocationService stockAllocationService,
            final AsohService asohService,
            final HouseParService houseParService,
            @Lazy final LineItemService lineItemService,
            final Clock when) {
        this.productionOrderRepository = productionOrderRepository;
        this.grindingYieldModelRepository = grindingYieldModelRepository;
        this.blendRepository = blendRepository;
        this.portionRoomTableService = portionRoomTableService;
        this.portionRoomService = portionRoomService;
        this.systemConfigService = systemConfigService;
        this.purchaseOrderService = purchaseOrderService;
        this.reportingPublisher = reportingPublisher;
        this.profileService = profileService;
        this.printerClient = printerClient;
        this.productService = productService;
        this.plateAssociationService = plateAssociationService;
        this.packageService = packageService;
        this.lineItemOutService = lineItemOutService;
        this.stockAllocationService = stockAllocationService;
        this.asohService = asohService;
        this.houseParService = houseParService;
        this.lineItemService = lineItemService;
        this.when = when;
    }

    private static List<ProductionOrder> futureOrderGroup(
            final List<ProductionOrder> productionOrders,
            final LocalDate today,
            final LocalDate nextDay) {
        return productionOrders.stream()
                .filter(ProductionOrder::isLineItemType)
                .filter(o -> o.isShipDateNotIn(today, nextDay))
                .collect(toList());
    }

    private static List<ProductionOrder> houseParOrderGroup(final List<ProductionOrder> productionOrders) {
        return productionOrders.stream()
                .filter(ProductionOrder::isHouseParType)
                .collect(toList());
    }

    private static List<ProductionOrder> normalAndNonImmediateAndNextDayGroup(
            final List<ProductionOrder> productionOrders, final LocalDate nextDay) {
        return productionOrders.stream()
                .filter(ProductionOrder::isLineItemType)
                .filter(ProductionOrder::isNotImmediateOrder)
                .filter(ProductionOrder::isNormalDeliveryMethod)
                .filter(o -> o.isShipDateIn(nextDay))
                .collect(toList());
    }

    private static List<ProductionOrder> timeWillCallAndImmediateAndNextDayGroup(
            final List<ProductionOrder> productionOrders, final LocalDate nextDay) {
        return productionOrders.stream()
                .filter(ProductionOrder::isLineItemType)
                .filter(ProductionOrder::isNotImmediateOrder)
                .filter(ProductionOrder::isWillCallDeliveryMethod)
                .filter(o -> o.isShipDateIn(nextDay))
                .collect(toList());
    }

    private static List<ProductionOrder> nonImmediateAndTodayGroup(
            final List<ProductionOrder> productionOrders, final LocalDate today) {
        return productionOrders.stream()
                .filter(ProductionOrder::isLineItemType)
                .filter(ProductionOrder::isNotImmediateOrder)
                .filter(o -> o.isShipDateIn(today))
                .collect(toList());
    }

    private static List<ProductionOrder> normalAndImmediateBothTodayAndNextDayGroup(
            final List<ProductionOrder> productionOrders, final LocalDate today, final LocalDate nextDay) {
        return productionOrders.stream()
                .filter(ProductionOrder::isLineItemType)
                .filter(ProductionOrder::isImmediateOrder)
                .filter(ProductionOrder::isNormalDeliveryMethod)
                .filter(o -> o.isShipDateIn(today, nextDay))
                .collect(toList());
    }

    private static List<ProductionOrder> timeWillCallAndImmediateBothTodayAndNextDayGroup(
            final List<ProductionOrder> productionOrders, final LocalDate today, final LocalDate nextDay) {
        return productionOrders.stream()
                .filter(ProductionOrder::isLineItemType)
                .filter(ProductionOrder::isImmediateOrder)
                .filter(ProductionOrder::isWillCallDeliveryMethod)
                .filter(o -> o.isShipDateIn(today, nextDay))
                .collect(toList());
    }

    private static ProductionType getProductionType(final PrimeLineItem primeLineItem) {
        return primeLineItem.getLineItem().getProductionType();
    }

    private static int calculateScheduleToProduce(final PrimeLineItem primeLineItem,
                                                  final Map<Long, Integer> scheduledMap) {
        int scheduleToCut = primeLineItem.getQuantityRemaining();
        final LineItem lineItem = primeLineItem.getLineItem();
        if (nonNull(scheduledMap) && scheduledMap.containsKey(lineItem.getId())) {
            final int toProduceToday = scheduledMap.get(lineItem.getId());
            scheduleToCut = lineItem.getUnitOfMeasure() == PIECE
                    ? toProduceToday * lineItem.getProduct().getPiecesPerCase()
                    : toProduceToday;

            if (scheduleToCut > primeLineItem.getQuantityRemaining()) {
                scheduleToCut = primeLineItem.getQuantityRemaining();
            }
        }
        return scheduleToCut;
    }

    private static int calculateQuantityForHousePar(final HousePar housePar, final SusAsohData asohData) {
        final int parConfig = housePar.getParValueToday().getValue();
        if (null == asohData) {
            return parConfig;
        }
        final SusAsohProductData susAsohProductData = asohData.getProducts()
                .stream()
                .filter(item -> housePar.productCode().equals(item.getSupc()))
                .findFirst().orElse(SusAsohProductData.emptySusAsohProductData());

        return parConfig - susAsohProductData.getAvailableOnHand();
    }

    List<ProductionOrder> findActiveGrindOrders(
            final String roomCode,
            final Optional<List<String>> statuses,
            final Optional<Boolean> cancelled) {
        return productionOrderRepository.findGrindingOrders(roomCode, statuses, cancelled).stream()
                .filter(ProductionOrder::isActive)
                .peek(productionOrder -> {
                    final Blend blend = getBlendOf(productionOrder.getProduct());
                    if (productionOrder.isImmediateOrder()) {
                        productionOrder.setDeliveryDate(systemConfigService.getFirstWorkDay(now(when)));
                    }
                    productionOrder.setBlend(blend);
                })
                .collect(toList());
    }

    private Blend getBlendOf(final Product product) {
        final String productGroupName = product.getProductGroup().getName();
        final Optional<GrindingYieldModel> grindingYieldModel = grindingYieldModelRepository
                .findByBlendNameAndPricingModelTrue(productGroupName);
        if (!grindingYieldModel.isPresent()) {
            throw new NotFoundException(format("grindingYieldModel not found by productGroupName %s for product %s",
                    productGroupName, product.getCode()));
        }

        return grindingYieldModel.get().getBlend();
    }

    public List<ProductionOrder> findAllProductionOrdersByRoomCodeAndStatuses(
            final String roomCode,
            final List<ProductionOrderStatus> statuses) {
        return productionOrderRepository.findAll(
                roomCode,
                empty(),
                emptyList(),
                empty(),
                empty(),
                statuses);
    }

    List<ProductionOrder> findAllCutOrdersToPack(
            final LocalDate date,
            final String productCode,
            final String susOrderNo,
            final String customerNo) {
        return productionOrderRepository
                .findByStartProducingAtGreaterThanEqualAndStartProducingAtLessThanAndProduct_CodeAndStatusIs(
                        TimeUtils.getStartTimeOfDay(date), TimeUtils.getStartTimeOfDay(date).plusDays(1), productCode,
                        ProductionOrderStatus.TO_PACK).stream()
                .filter(order -> StringUtils.isEmpty(susOrderNo) || (order.getCustomerOrder() != null
                        && order.getCustomerOrder().getOrderNumber().equals(susOrderNo)))
                .filter(order -> StringUtils.isEmpty(customerNo) || (order.getCustomerOrder() != null
                        && order.getCustomerOrder().getCustomer().getCustomerCode().equals(customerNo)))
                .collect(Collectors.toList());
    }

    List<ProductionOrder> findAllCutOrders(
            final String roomCode,
            final Optional<String> status,
            final Optional<List<Long>> stationIds,
            final Optional<Long> tableId,
            final Optional<Boolean> cancelled) {
        final List<ProductionOrder> cutOrders = findAllProductionOrders(
                roomCode,
                Optional.of(CUTTING),
                status,
                stationIds,
                tableId,
                cancelled);

        final PortionRoom room = portionRoomService.getPortionRoomByCode(roomCode);
        return sortByPriority(cutOrders, room.getLastOpenedAt());
    }

    @Transactional(value = REQUIRES_NEW)
    @Retryable(value = {ObjectOptimisticLockingFailureException.class}, maxAttempts = 3)
    public void packoffOneBox(final Long sourceCutOrderId) {
        final ProductionOrder productionOrder = findById(sourceCutOrderId);
        productionOrder.packBox();
        productionOrderRepository.save(productionOrder);
        reportingPublisher.reportOn(productionOrder.toReporting());
    }

    public List<ProductionOrder> findAllProductionOrders(
            final String roomCode,
            final Optional<ProductionType> productionType,
            final Optional<String> status,
            final Optional<List<Long>> stationIds,
            final Optional<Long> tableId,
            final Optional<Boolean> cancelled) {
        final Optional<PortionRoomTable> table = tableId.map(portionRoomTableService::getTableById);

        final List<ProductionOrderStatus> statuses = new ArrayList<>();
        status.ifPresent(s -> Pattern.compile(",").splitAsStream(s)
                .map(ProductionOrderStatus::from)
                .collect(toCollection(() -> statuses)));

        return productionOrderRepository.findAll(
                roomCode, productionType, stationIds.orElse(emptyList()), table, cancelled, statuses);
    }

    List<ProductionOrder> sortByPriority(
            final List<ProductionOrder> productionOrders, final OffsetDateTime lastOpenedAt) {
        final LocalDate today = systemConfigService.getFirstWorkDay(lastOpenedAt);
        final LocalDate nextDay = systemConfigService.getNextWorkDay(lastOpenedAt);

        final List<ProductionOrder> preparedProductionOrders = productionOrders.stream().peek(productionOrder -> {
            if (null != productionOrder.getCustomerOrder() && productionOrder.getCustomerOrder().isImmediateOrder()) {
                productionOrder.setDeliveryDate(today);
            }
        }).collect(Collectors.toList());

        final List<ProductionOrder> result = new ArrayList<>();

        final List<ProductionOrder> timeWillCallAndImmediateBothTodayAndNextDayGroup =
                timeWillCallAndImmediateBothTodayAndNextDayGroup(preparedProductionOrders, today, nextDay);
        timeWillCallAndImmediateBothTodayAndNextDayGroup.sort(byTimedWillCall.thenComparing(subSortedComparator));
        result.addAll(timeWillCallAndImmediateBothTodayAndNextDayGroup);

        final List<ProductionOrder> normalAndImmediateBothTodayAndNextDayGroup =
                normalAndImmediateBothTodayAndNextDayGroup(preparedProductionOrders, today, nextDay);
        normalAndImmediateBothTodayAndNextDayGroup.sort(subSortedComparator);
        result.addAll(normalAndImmediateBothTodayAndNextDayGroup);

        final List<ProductionOrder> nonImmediateAndTodayGroup =
                nonImmediateAndTodayGroup(preparedProductionOrders, today);
        nonImmediateAndTodayGroup.sort(subSortedComparator);
        result.addAll(nonImmediateAndTodayGroup);

        final List<ProductionOrder> timeWillCallAndNonImmediateAndNextDayGroup =
                timeWillCallAndImmediateAndNextDayGroup(preparedProductionOrders, nextDay);
        timeWillCallAndNonImmediateAndNextDayGroup.sort(subSortedComparator);
        result.addAll(timeWillCallAndNonImmediateAndNextDayGroup);

        final List<ProductionOrder> normalAndNonImmediateAndNextDayGroup =
                normalAndNonImmediateAndNextDayGroup(preparedProductionOrders, nextDay);
        normalAndNonImmediateAndNextDayGroup.sort(new RoutingGroupsComparator(when).thenComparing(subSortedComparator));
        result.addAll(normalAndNonImmediateAndNextDayGroup);

        final List<ProductionOrder> houseParOrderGroup = houseParOrderGroup(preparedProductionOrders);
        houseParOrderGroup.sort(subSortedComparator);
        result.addAll(houseParOrderGroup);

        final List<ProductionOrder> futureOrderGroup =
                futureOrderGroup(preparedProductionOrders, today, nextDay);
        futureOrderGroup.sort(byShipDate.thenComparing(subSortedComparator));
        result.addAll(futureOrderGroup);

        return result;
    }

    List<CutOrderTableSummary> getCutOrdersSummaryForTables(
            final String roomCode,
            final Long stationId,
            final CutOrderStatus status) {
        final PortionRoom room = portionRoomService.getPortionRoomByCode(roomCode);
        final LocalDate today = systemConfigService.getFirstWorkDay(room.getLastOpenedAt());
        final LocalDate nextDay = systemConfigService.getNextWorkDay(room.getLastOpenedAt());

        final Station station = room.getStations()
                .stream()
                .filter(stationInRoom -> Objects.equals(stationId, stationInRoom.getId()))
                .findAny()
                .orElseThrow(() -> new NotFoundException(format("[find Station] with Id %d Not Found", stationId)));

        final List<PortionRoomTable> tables = station.getPortionRoomTables();

        return tables.stream()
                .map(table -> {
                    List<ProductionOrder> productionOrders = productionOrderRepository
                            .findByPortionRoomTableIdAndStatus(table.getId(),
                                    ProductionOrderStatus.from(status.toString()));

                    List<ProductionOrder> productionOrdersExcludingDeleted =
                            filterCancelledOrDeleted(Optional.of(false), productionOrders);

                    return buildCutOrderTableSummary(roomCode, table, productionOrdersExcludingDeleted, today, nextDay);
                })
                .filter(tableSummary -> !tableSummary.getBoxesToCutForCustomerOrders().isEmpty())
                .sorted(Comparator.comparing(CutOrderTableSummary::getTableCode))
                .collect(toList());
    }

    List<CutOrderStationSummary> getCutOrdersSummaryForStations(final String roomCode) {
        final PortionRoom room = portionRoomService.getPortionRoomByCode(roomCode);
        final LocalDate today = systemConfigService.getFirstWorkDay(room.getLastOpenedAt());
        final LocalDate nextDay = systemConfigService.getNextWorkDay(room.getLastOpenedAt());

        return room.getStations().stream()
                .map(station -> {
                    List<Long> tableIds = station.getPortionRoomTables().stream()
                            .map(PortionRoomTable::getId)
                            .collect(toList());
                    List<ProductionOrder> productionOrders = productionOrderRepository
                            .findByPortionRoomTableIdInAndStatus(tableIds, TO_CUT);

                    List<ProductionOrder> productionOrdersExcludingCancelledOrDeleted =
                            filterCancelledOrDeleted(Optional.of(false), productionOrders);

                    return buildCutOrderStationSummary(
                            station, productionOrdersExcludingCancelledOrDeleted, today, nextDay);
                })
                .filter(stationSummary -> !stationSummary.getBoxesToCutForCustomerOrders().isEmpty())
                .sorted(Comparator.comparing(CutOrderStationSummary::getStationCode))
                .collect(toList());
    }

    public ProductionOrder findById(final Long id) {
        final ProductionOrder order = productionOrderRepository.getOneOrNull(id);
        if (null == order) {
            throw new ProductionOrderNotFoundException(
                    format("[find productionOrder] productionOrder not found, id: %s", id));
        }
        return order;
    }

    public void updateUnclosedProductionOrders(final PortionRoom room) {
        final List<ProductionOrder> unclosedProductionOrders =
                findAllProductionOrdersByRoomCodeAndStatuses(room.getCode(), unclosedStatuses());
        final LocalDate firstWorkDay = systemConfigService.getFirstWorkDay(room.getLastOpenedAt());
        final LocalDate nextWorkDay = systemConfigService.getNextWorkDay(room.getLastOpenedAt());

        unclosedProductionOrders.forEach(productionOrder -> {
            if (productionOrder.shouldSendOut(firstWorkDay, nextWorkDay)) {
                final Long lineItemId = productionOrder.getSourceId();
                final StockAllocation lineItem = stockAllocationService.findByLineItemId(lineItemId);
                final int allocatedQuantity = null != lineItem ? lineItem.getAllocatedQuantity() : 0;

                final int outQuantity = productionOrder.calculateOutQuantity(allocatedQuantity);

                if (outQuantity > 0) {
                    lineItemOutService.create(lineItemId, outQuantity);
                }
            }
        });

        if (room.isGrindingRoom()) {
            lineItemService.sendOutsForUnscheduledLineItems(room, firstWorkDay);
        }

        unclosedProductionOrders.forEach(productionOrder -> productionOrder.setStatus(CLOSED));

        productionOrderRepository.saveAll(unclosedProductionOrders);
        unclosedProductionOrders.stream()
                .map(ProductionOrder::toReporting)
                .forEach(reportingPublisher::reportOn);
    }

    @Transient
    void updateAll(final List<ProductionOrder> productionOrders) {
        productionOrders.forEach(this::updateOne);
    }

    void completeBanquetOrderWithOrderQuantityPacked(final Long cutOrderId) throws InvalidValueException {
        if (cutOrderId == null || cutOrderId <= 0) {
            throw new InvalidValueException("invalid input value");
        }

        final ProductionOrder productionOrder = findById(cutOrderId);
        productionOrder.completeBanquetOrder();

        productionOrderRepository.save(productionOrder);

        purchaseOrderService.updatePurchaseOrderLineItemWithOrderQuantityPacked(productionOrder);

        reportingPublisher.reportOn(productionOrder.toReporting());
    }

    void updateOne(final ProductionOrder updatedProductionOrder) {
        final ProductionOrder existingProductionOrder = findById(updatedProductionOrder.getId());

        final boolean cutOrderSelected = CUTTING == existingProductionOrder.getProductionType()
                && TO_CUT == existingProductionOrder.getStatus()
                && TO_PACK == updatedProductionOrder.getStatus();

        existingProductionOrder.update(updatedProductionOrder, when);
        productionOrderRepository.save(existingProductionOrder);
        reportingPublisher.reportOn(existingProductionOrder.toReporting());

        if (cutOrderSelected) {
            reportingPublisher.reportOn(existingProductionOrder.toReportingCutSelection());
        }
    }

    List<ProductionOrder> getLatestToApproveGrindOrders(final List<PrimeLineItem> primeLineItems,
                                                        final Map<Long, Integer> scheduledMap) {
        return primeLineItems.stream()
                .map(primeLineItem -> getLatestToApproveGrindOrder(primeLineItem, scheduledMap))
                .filter(productionOrder -> productionOrder.getQtyToProduce() > 0)
                .collect(toList());
    }

    private ProductionOrder getLatestToApproveGrindOrder(final PrimeLineItem primeLineItem,
                                                         final Map<Long, Integer> scheduledMap) {
        final LineItem lineItem = primeLineItem.getLineItem();
        final ProductionType productionType = getProductionType(primeLineItem);

        final List<ProductionOrder> existingProductionOrders = getExistingToApproveGrindOrders(lineItem);

        final ProductionOrder newProductionOrder = ProductionOrder.fromLineItem(
                lineItem,
                productionType,
                calculateScheduleToProduce(primeLineItem, scheduledMap));

        newProductionOrder.setBlend(Blend.fromString(
                lineItem.getProduct().getProductGroup().getName(),
                blendRepository));

        return ProductionOrder.aggregateQuantities(newProductionOrder, existingProductionOrders);
    }

    private List<ProductionOrder> getToApproveGrindOrdersToDelete(final List<PrimeLineItem> primeLineItems) {
        return primeLineItems.stream()
                .map(primeLineItem -> getExistingToApproveGrindOrders(primeLineItem.getLineItem()))
                .reduce(new ArrayList<>(), (productionOrders, productionOrders2) -> {
                    productionOrders.addAll(productionOrders2);
                    return productionOrders;
                });
    }

    private List<ProductionOrder> getExistingToApproveGrindOrders(final LineItem lineItem) {
        return productionOrderRepository.findBySourceAndSourceIdAndStatus(
                LINE_ITEM,
                lineItem.getId(),
                TO_APPROVE);
    }

    public void generateOrdersFromPrimeLineItems(
            final List<PrimeLineItem> primeLineItems, final Map<Long, Integer> scheduledMap) {
        final List<ProductionOrder> productionOrders = primeLineItems.stream()
                .map(primeLineItem -> {
                    final ProductionType productionType = getProductionType(primeLineItem);
                    return ProductionOrder.fromLineItem(
                            primeLineItem.getLineItem(),
                            productionType,
                            calculateScheduleToProduce(primeLineItem, scheduledMap));
                })
                .collect(toList());

        generatePurchaseOrdersForCustomerOrders(productionOrders);

        productionOrderRepository.saveAll(productionOrders);
    }

    private void generatePurchaseOrdersForCustomerOrders(final List<ProductionOrder> productionOrders) {
        final Map<CustomerOrder, List<ProductionOrder>> orderListMap = productionOrders.stream()
                .collect(groupingBy(ProductionOrder::getCustomerOrder));

        orderListMap.keySet().forEach(customerOrder -> {
            final List<ProductionOrder> productionOrderForCustomerOrder = orderListMap.get(customerOrder);
            final PurchaseOrder purchaseOrder = purchaseOrderService
                    .createOrUpdatePurchaseOrderFromCustomerOrder(customerOrder, productionOrderForCustomerOrder);
            productionOrderForCustomerOrder.forEach(productionOrder ->
                    productionOrder.assignPurchaseOrderId(purchaseOrder.getId()));
        });
    }

    public List<ProductionOrder> findBySourceIdIn(final List<Long> sourceIds) {
        return productionOrderRepository.findBySourceIdInAndSourceIsAndCustomerOrderCancelledIsFalse(sourceIds,
                LINE_ITEM);
    }

    public List<ProductionOrder> findBySourceIdAndProductDate(final Long sourceId, final LocalDate produceDate) {
        return productionOrderRepository.findBySourceIdAndDeliveryDate(sourceId, produceDate);
    }

    public void assignCutOrderBelongToProductToTable(final String productCode, final PortionRoomTable table) {
        final List<ProductionOrder> productionOrders = productionOrderRepository
                .findByProductCodeAndStatus(productCode, TO_CUT);
        assignCutOrderToTable(table, productionOrders);
    }

    private void assignCutOrderToTable(final PortionRoomTable table, final List<ProductionOrder> productionOrders) {
        productionOrders.forEach(cutOrder -> cutOrder.assignToTable(table));
        productionOrderRepository.saveAll(productionOrders);
    }

    public void generateCutOrdersFromHousePar(
            final List<HousePar> housePars,
            final String roomCode,
            final OffsetDateTime date) {
        final Profile profile = profileService.get();

        if (isNull(profile)) {
            throw new NotFoundException("need config your company profile first");
        }

        final List<String> productCodes = housePars.stream().map(HousePar::productCode).collect(toList());

        if (!housePars.isEmpty()) {
            final SusAsohData asohData = asohService.getStocks(productCodes, profile.getPlantNumber(), roomCode, true);

            final List<ProductionOrder> productionOrders = housePars.stream()
                    .map(housePar -> toCutOrder(housePar, asohData, date))
                    .filter(cutOrder -> !isNull(cutOrder))
                    .collect(toList());

            if (!productionOrders.isEmpty()) {
                saveProductionOrdersAndCreatePurchaseOrderForHousePar(roomCode, productionOrders);
            }
        }
    }

    private void saveProductionOrdersAndCreatePurchaseOrderForHousePar(
            final String roomCode, final List<ProductionOrder> productionOrders) {
        final PurchaseOrder purchaseOrder = purchaseOrderService.createPurchaseOrderForHousePar(
                productionOrders,
                roomCode);

        productionOrders.forEach(cutOrder -> cutOrder.assignPurchaseOrderId(purchaseOrder.getId()));
        productionOrderRepository.saveAll(productionOrders);
    }

    private ProductionOrder toCutOrder(
            final HousePar housePar, final SusAsohData asohData, final OffsetDateTime date) {
        final LocalDate today = systemConfigService.getFirstWorkDay(date);
        final int quantity = calculateQuantityForHousePar(housePar, asohData);
        if (quantity <= 0) {
            return null;
        }
        return fromHouseParForCutting(housePar, quantity, today);
    }

    @Transactional
    void scheduleGrindOrders(final List<PrimeLineItem> primeLineItems, final Map<Long, Integer> scheduledMap) {
        final List<ProductionOrder> grindOrdersToDelete = getToApproveGrindOrdersToDelete(primeLineItems);
        final List<ProductionOrder> grindOrdersToApprove = getLatestToApproveGrindOrders(primeLineItems, scheduledMap);

        productionOrderRepository.deleteAll(grindOrdersToDelete);
        productionOrderRepository.saveAll(grindOrdersToApprove);
    }

    void approveGrindOrdersForTheDay(final String roomCode) {
        if (portionRoomService.isRoomAlreadyApprovedForToday(roomCode)) {
            throw new IllegalStateException("Grind orders for room already approved: " + roomCode);
        }

        final List<ProductionOrder> activeGrindOrders = findActiveGrindOrders(roomCode, empty(), Optional.of(FALSE));

        final List<ProductionOrder> lineItemGrindOrders = activeGrindOrders.stream()
                .filter(grindOrder -> LINE_ITEM.equals(grindOrder.getSource()))
                .collect(toList());
        generatePurchaseOrdersForCustomerOrders(lineItemGrindOrders);
        final List<ProductionOrder> houseParGrindOrders = activeGrindOrders.stream()
                .filter(grindOrder -> HOUSE_PAR.equals(grindOrder.getSource()))
                .collect(toList());
        if (!houseParGrindOrders.isEmpty()) {
            generatePurchaseOrdersForHouseParOrders(roomCode, houseParGrindOrders);
        }

        final Map<String, List<ProductionOrder>> ordersGroupedByProductCode =
                activeGrindOrders.stream()
                        .collect(groupingBy(order -> order.getProduct().getCode()));
        ordersGroupedByProductCode.keySet().stream()
                .flatMap(productCode -> buildGrindingPrintJob(ordersGroupedByProductCode.get(productCode))
                        .stream())
                .forEach(printerClient::createGrindTicketPrintingJob);
        ordersGroupedByProductCode.values().stream()
                .flatMap(Collection::stream)
                .forEach(this::readyToPack);

        portionRoomService.approve(roomCode);
    }

    private void generatePurchaseOrdersForHouseParOrders(
            final String roomCode, final List<ProductionOrder> houseParGrindOrders) {
        final PurchaseOrder purchaseOrderForHousePar = purchaseOrderService
                .createPurchaseOrderForHousePar(houseParGrindOrders, roomCode);
        houseParGrindOrders.forEach(houseParGrindOrder ->
                houseParGrindOrder.setPurchaseOrderId(purchaseOrderForHousePar.getId()));
    }

    List<PrintJob> buildGrindingPrintJob(final List<ProductionOrder> productionOrders) {
        final ProductionOrder firstProductionOrder = productionOrders.get(0);
        final Product product = firstProductionOrder.getProduct();
        final String plateUsed = product.getGrindSpecific().getPlateUsed();
        final PlateAssociation plateAssociation = plateAssociationService.findByModelNumber(plateUsed);
        final String plateName = null == plateAssociation
                ? plateUsed : plateAssociation.getPlate().generatePlateName();

        if (null == product.getTarePackage()) {
            product.setTarePackage(packageService.findDefaultParePackage());
        }

        final int totalCases = productionOrders.stream()
                .mapToInt(ProductionOrder::getQtyToProduceInCases)
                .sum();
        final int totalTickets = BigDecimal.valueOf(totalCases)
                .divide(BigDecimal.valueOf(product.getGrindSpecific().getCasesPerTray() * 10L), BigDecimal.ROUND_UP)
                .intValue();

        final List<PrintJob> printJobs = new ArrayList<>();
        for (int i = 1; i <= totalTickets; i++) {
            final PrintJob printJob = new PrintJob(new GrindTicketData(firstProductionOrder, product, plateName,
                    totalCases, i, totalTickets), product.getPrinterName());
            printJobs.add(printJob);
        }

        return printJobs;
    }

    private void readyToPack(final ProductionOrder order) {
        order.setStatus(TO_PACK);
        productionOrderRepository.save(order);
    }

    void updatePurchaseOrderQuantity(final long id, final int qtyInBoxes) {
        final ProductionOrder foundOrder = findById(id);
        if (qtyInBoxes <= foundOrder.getQtyToProduceInCases()) {
            final int qtyToProduce = foundOrder.getUnitOfMeasure() == UnitOfMeasure.BOX
                    ? qtyInBoxes
                    : qtyInBoxes * foundOrder.getPiecesPerCase();

            if (qtyToProduce > 0) {
                foundOrder.setQtyToProduce(qtyToProduce);
                foundOrder.setQtyToProduceInCases(qtyInBoxes);
                productionOrderRepository.save(foundOrder);
            } else {
                productionOrderRepository.delete(foundOrder);
            }
        }
    }

    @Transactional
    public void scheduleHouseParGrindingOrders(final Map<Long, Integer> houseParMap, final String roomCode) {
        final List<Long> sourceIds = houseParMap.entrySet().stream()
                .filter(entry -> entry.getValue() > 0)
                .map(Entry::getKey)
                .collect(toList());

        final List<HousePar> housePars = houseParService.findByIdIn(sourceIds);
        final List<ProductionOrder> existingProductionOrders = productionOrderRepository
                .findBySourceIsAndSourceIdAndStatusIs(HOUSE_PAR,
                        housePars.stream()
                                .map(HousePar::getId)
                                .collect(toSet()),
                        TO_APPROVE);
        final Map<Long, List<ProductionOrder>> parToOrderMap = existingProductionOrders.stream()
                .collect(groupingBy(ProductionOrder::getSourceId));

        final LocalDate dateToShowHousePar = houseParService.getDateToShowHousePar(roomCode);

        final List<ProductionOrder> productionOrders = housePars.stream()
                .map(par -> {
                    Long sourceId = par.getId();
                    ProductionOrder newProductionOrder =
                            fromHouseParForGrinding(par, houseParMap.get(sourceId), dateToShowHousePar);

                    if (parToOrderMap.containsKey(sourceId)) {
                        List<ProductionOrder> existingProductionOrderForSourceId = parToOrderMap.get(sourceId);
                        return aggregateQuantities(newProductionOrder, existingProductionOrderForSourceId);
                    } else {
                        return newProductionOrder;
                    }
                })
                .collect(toList());

        // TODO: could update existing vs. deleting existing/saving new
        productionOrderRepository.deleteAll(existingProductionOrders);
        productionOrderRepository.saveAll(productionOrders);
    }

    public List<ProductionOrder> getProductionOrdersFromCustomerOrder(final CustomerOrder customerOrder) {
        return customerOrder.getLineItems().stream()
                .map(lineItem -> findBySourceIdIn(singletonList(lineItem.getId())))
                .flatMap(List::stream)
                .collect(toList());
    }

    public List<Long> getProductionOrderIdsFor(final CustomerOrder customerOrder) {
        // TODO: Rather than using IDs directly, we should use objects
        // TODO: Update `Box` to use production-orders instead of ids
        return getProductionOrdersFromCustomerOrder(customerOrder).stream()
                .map(ProductionOrder::getId)
                .collect(toList());
    }

    public List<ProductionOrder> getAllProductionOrdersCreatedAtWorkingDay(final PortionRoom room) {
        final LocalDate startDate = systemConfigService.getFirstWorkDay(room.getLastOpenedAt());
        final LocalDate endDate =
                systemConfigService.getNextWorkDay(TimeUtils.getStartTimeOfDay(startDate));

        return productionOrderRepository
                .findByDeliveryDateBetweenAndProductTableStationRoomCode(startDate, endDate, room.getCode());
    }

    public boolean areThereProductionOrdersForCustomerOrder(CustomerOrder customerOrder) {
        return productionOrderRepository.findByCustomerOrderId(customerOrder.getId()).size() > 0;
    }

    ProductionOrder findByCutTicketCodeAndRoomCode(final String cutTicketCode, final String roomCode) {
        final String ticketDate = cutTicketCode.substring(1, 7);
        final String ticketSuffix = cutTicketCode.substring(7);
        final LocalDate deliveryDate = LocalDate.parse(ticketDate, DateTimeFormatter.ofPattern("MMddyy"));

        final List<ProductionOrder> orders = productionOrderRepository
                .findByDeliveryDateAndPortionRoomTableStationRoomCodeAndStatusOrderByIdDesc(
                        deliveryDate,
                        roomCode,
                        ProductionOrderStatus.TO_PACK);

        for (ProductionOrder order : orders) {
            final String paddedId = order.getTicketCodeSuffixFromId();
            if (paddedId.equals(ticketSuffix)) {
                return order;
            }
        }

        throw new ProductionOrderNotFoundException("No production order found in room for cut ticket order id.");
    }

    String getProductForGroupedProductionOrdersByGrindTicketCodeAndRoomCode(final String grindTicketCode,
                                                                            final String roomCode) {
        final String ticketDate = grindTicketCode.substring(1, 7);
        final LocalDate deliveryDate = LocalDate.parse(ticketDate, DateTimeFormatter.ofPattern("MMddyy"));
        final String productCode = grindTicketCode.substring(7, 14);
        final List<ProductionOrder> orders = productionOrderRepository
                .findByDeliveryDateAndPortionRoomTableStationRoomCodeAndStatusOrderByIdDesc(
                        deliveryDate,
                        roomCode,
                        ProductionOrderStatus.TO_PACK);

        final List<ProductionOrder> productionOrderWithProduct = orders.stream().filter(order -> order.getProduct()
                .getCode().equals(productCode)).collect(Collectors.toList());
        if (!productionOrderWithProduct.isEmpty()) {
            return productCode;
        }

        throw new ProductionOrderNotFoundException("No production order found in room for grind ticket order id.");
    }
}
