package com.sysco.prime.productionOrder;

import com.sysco.prime.PrimeRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.Collection;
import java.util.List;

// TODO: Unused methods?
public interface ProductionOrderRepository extends PrimeRepository<ProductionOrder>,
        JpaSpecificationExecutor<ProductionOrder>,
        ProductionOrderRepositoryCustom {
    List<ProductionOrder> findByProductCodeAndStatus(
            String productCode, ProductionOrderStatus status);

    List<ProductionOrder> findBySourceIdInAndSourceIsAndCustomerOrderCancelledIsFalse(
            List<Long> sourceIds, CutOrderSource sourceType);

    List<ProductionOrder> findBySourceAndSourceId(CutOrderSource source, Long lineItemId);

    List<ProductionOrder> findByPortionRoomTableIdInAndStatus(
            List<Long> tableIds, ProductionOrderStatus status);

    List<ProductionOrder> findByPortionRoomTableIdAndStatus(
            Long tableId, ProductionOrderStatus toCut);

    List<ProductionOrder> findBySourceAndSourceIdAndStatus(
            CutOrderSource source, Long sourceId, ProductionOrderStatus status);

    List<ProductionOrder> findBySourceIsAndSourceIdAndStatusIs(
            CutOrderSource source, Collection<Long> sourceId, ProductionOrderStatus status);

    List<ProductionOrder> findBySourceIdAndDeliveryDate(
            Long sourceId, LocalDate produceDate);

    List<ProductionOrder> findByDeliveryDateBetweenAndProductTableStationRoomCode(
            LocalDate startingDate, LocalDate endingDate, String roomCode);

    List<ProductionOrder> findByProductTableStationRoomCodeAndProductCode(String roomCode, String productCode);

    List<ProductionOrder> findByDeliveryDateAndPortionRoomTableStationRoomCodeAndStatusOrderByIdDesc(
            LocalDate deliveryDate, String roomCode, ProductionOrderStatus status);

    List<ProductionOrder> findByCustomerOrderId(Long id);

    List<ProductionOrder> findByStartProducingAtGreaterThanEqualAndStartProducingAtLessThanAndProduct_CodeAndStatusIs(
            OffsetDateTime startDate, OffsetDateTime endDate, String productCode, ProductionOrderStatus status);
}
