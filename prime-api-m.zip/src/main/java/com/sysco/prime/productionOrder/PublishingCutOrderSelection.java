package com.sysco.prime.productionOrder;

import com.sysco.prime.Reportable;
import com.sysco.prime.customerOrder.CustomerOrder;
import com.sysco.prime.portionRoomTable.PortionRoomTable;
import com.sysco.prime.product.Product;
import com.sysco.prime.unitOfMeasure.UnitOfMeasure;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.time.LocalDate;
import java.time.OffsetDateTime;

@Builder
@Data
@EqualsAndHashCode(callSuper = false)
public class PublishingCutOrderSelection implements Reportable {
    private CutOrderSource source;
    private UnitOfMeasure unitOfMeasure;
    private Long sourceId;
    private Product product;
    private OrderType orderType;
    private ProductionType productionType;
    private String packInstruction;
    private Integer piecesPerCase;
    private String producingInstruction;
    private Integer qtyToProduce;
    private Integer qtyPacked;
    private LocalDate deliveryDate;
    private Integer qtyToProduceInCases;
    private CustomerOrder customerOrder;
    private PortionRoomTable portionRoomTable;
    private ProductionOrderStatus status;
    private OffsetDateTime startProducingAt;
    private LocalDate workingDate;

    @Override
    public String productCode() {
        return product.getCode();
    }
}
