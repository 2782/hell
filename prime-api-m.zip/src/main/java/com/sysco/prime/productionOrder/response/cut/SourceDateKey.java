package com.sysco.prime.productionOrder.response.cut;

import com.sysco.prime.productionOrder.CutOrderSource;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.time.LocalDate;

@Getter
@AllArgsConstructor
class SourceDateKey {
    private final CutOrderSource source;
    private final LocalDate date;
}
