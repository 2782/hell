package com.sysco.prime.productionOrder.response.cut;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.sysco.prime.productionOrder.CutOrderSource;
import com.sysco.prime.productionOrder.ProductionOrder;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.List;
import java.util.Objects;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class CutOrderSummaryItem {
    private CutOrderSource source;
    private LocalDate date;
    private Long total;

    public boolean isShippedOn(final LocalDate date) {
        return Objects.equals(this.date, date);
    }

    @JsonIgnore
    public boolean isFromHousePar() {
        return CutOrderSource.HOUSE_PAR.equals(source);
    }

    @JsonIgnore
    public boolean isFromLineItem() {
        return CutOrderSource.LINE_ITEM.equals(source);
    }

    public static CutOrderSummaryItem from(final CutOrderSource source,
                                           final LocalDate date,
                                           final List<ProductionOrder> productionOrders) {
        final Integer total = productionOrders.stream()
                .map(cutOrder -> cutOrder.getQtyToProduceInCases() - cutOrder.getQtyPacked())
                .reduce(0, Integer::sum);
        return builder()
                .source(source)
                .date(date)
                .total(Long.valueOf(total))
                .build();
    }
}
