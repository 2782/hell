package com.sysco.prime.customerOrder;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.sysco.prime.product.Product;
import com.sysco.prime.product.ProductService;
import com.sysco.prime.productionOrder.ProductionOrder;
import com.sysco.prime.productionOrder.ProductionType;
import com.sysco.prime.shared.model.TransactionalEntity;
import com.sysco.prime.sus.model.product.SusLineItemData;
import com.sysco.prime.unitOfMeasure.UnitOfMeasure;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import org.springframework.util.StringUtils;

import javax.persistence.Entity;
import javax.persistence.Enumerated;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.validation.constraints.NotNull;
import java.util.List;
import java.util.Objects;

import static com.sysco.prime.unitOfMeasure.UnitOfMeasure.PIECE;
import static java.lang.Math.ceil;
import static javax.persistence.EnumType.STRING;
import static javax.persistence.FetchType.EAGER;
import static org.apache.commons.lang3.StringUtils.isNumericSpace;

@Entity
@Getter
@NoArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
@ToString(exclude = "customerOrder")
public class LineItem extends TransactionalEntity {
    @Setter
    @ManyToOne(fetch = EAGER)
    @JoinColumn(name = "customerOrderId")
    private CustomerOrder customerOrder;

    @OneToOne
    @JoinColumn(name = "productId")
    private Product product;

    @NotNull
    private int lineNumber;

    @NotNull
    private int quantity;
    @Enumerated(STRING)
    private UnitOfMeasure unitOfMeasure;
    private String cutInstruction;
    private String packInstruction;
    @NotNull
    private boolean banquetType;
    private boolean deleted;

    static LineItem fromSus(final SusLineItemData susLineItem, final ProductService productService) {
        final Product product = productService.findByCode(susLineItem.getItemNumber());
        return LineItem.builder()
                .banquetType(susLineItem.isBanquetType())
                .cutInstruction(susLineItem.getCutInstruction())
                .packInstruction(susLineItem.getPackInstruction())
                .lineNumber(removePrefix(String.valueOf(susLineItem.getLineNumber())))
                .product(product)
                .quantity(susLineItem.getQuantity())
                .unitOfMeasure(UnitOfMeasure.fromSus(susLineItem.getSoldAs()))
                .deleted(susLineItem.cancelled() || susLineItem.deleted())
                .build();
    }

    private static Integer removePrefix(final String number) {
        return isNumericSpace(number)
                ? Integer.parseInt(number.replaceFirst("^0", "")) : 0;
    }

    @JsonIgnore
    public String getRoomCode() {
        return product.getPortionRoomCode();
    }

    boolean hasCuttingInstructions() {
        return !StringUtils.isEmpty(cutInstruction);
    }

    boolean hasPackingInstructions() {
        return !StringUtils.isEmpty(packInstruction);
    }

    @JsonIgnore
    public ProductionType getProductionType() {
        return product.getProductionType();
    }

    @JsonIgnore
    boolean isPackedComplete(final List<ProductionOrder> orders, final int stockAllocated) {

        int totalQuantityProduced = 0;
        for (ProductionOrder order: orders) {
            if (order.getQtyPacked() >= order.getQtyToProduceInCases()) {
                totalQuantityProduced += order.getQtyToProduce();
            }
        }

        return quantity - totalQuantityProduced - stockAllocated <= 0;
    }

    @JsonIgnore
    int getQuantityInCases() {
        if (unitOfMeasure == UnitOfMeasure.PIECE) {
            return (int) ceil(quantity * 1.0 / product.getPiecesPerCase());
        } else {
            return quantity;
        }
    }

    @JsonIgnore
    boolean notAllocable() {
        return unitOfMeasure == PIECE
                || hasCuttingInstructions()
                || banquetType
                || hasPackingInstructions()
                || customerOrder.getCustomer().isBroadline() && !getProduct().isAllocateParToBroadline();
    }

    @Override
    public boolean equals(final Object other) {
        if (this == other) {
            return true;
        }
        if (other == null || getClass() != other.getClass()) {
            return false;
        }

        final LineItem lineItem = (LineItem) other;
        return lineNumber == lineItem.lineNumber
                && quantity == lineItem.quantity
                && banquetType == lineItem.banquetType
                && deleted == lineItem.deleted
                && Objects.equals(product, lineItem.product)
                && unitOfMeasure == lineItem.unitOfMeasure
                && Objects.equals(cutInstruction, lineItem.cutInstruction)
                && Objects.equals(packInstruction, lineItem.packInstruction)
                // Compare customer order numbers
                &&
                (null == customerOrder || null == lineItem.customerOrder)
                || (customerOrder.getOrderNumber().equals(lineItem.customerOrder.getOrderNumber()));
    }

    @Override
    public int hashCode() {
        return Objects.hash(product, lineNumber, quantity, unitOfMeasure, cutInstruction,
                packInstruction, banquetType, deleted, getCustomerOrderNumber());
    }

    String getCustomerOrderNumber() {
        if (null != customerOrder) {
            return customerOrder.getOrderNumber();
        }
        return "";
    }

    public LineItem copy() {
        final LineItem itemCopy = toBuilder().build();
        itemCopy.setId(getId());
        itemCopy.setCreatedAt(getCreatedAt());
        itemCopy.setUpdatedAt(getUpdatedAt());
        return itemCopy;
    }
}
