package com.sysco.prime.customerOrder;

import com.sysco.prime.shared.model.TransactionalEntity;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.validation.constraints.NotNull;

import static javax.persistence.FetchType.EAGER;

@Data
@Entity
@Builder(toBuilder = true)
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
public class StockAllocation extends TransactionalEntity {
    @NotNull
    @OneToOne(fetch = EAGER)
    @JoinColumn(name = "lineItemId")
    private LineItem lineItem;

    @NotNull
    private int allocatedQuantity;

    @NotNull
    private boolean enough;
}
