package com.sysco.prime.customerOrder.response;

import com.sysco.prime.customer.response.CustomerResponse;
import com.sysco.prime.customerOrder.CustomerOrder;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.ToString;

import java.time.LocalDate;
import java.util.List;

import static java.util.stream.Collectors.toList;

@Getter
@AllArgsConstructor
@Builder(toBuilder = true)
@ToString
public class CustomerOrderResponse {
    private final Long id;
    private final String orderNumber;
    private final LocalDate orderDate;
    private final LocalDate shipDate;
    private final String createdBy;
    private final boolean immediateOrder;
    private final boolean onHold;
    private final boolean cancelled;
    private CustomerResponse customer;

    public CustomerOrderResponse(final CustomerOrder customerOrder) {
        id = customerOrder.getId();
        orderNumber = customerOrder.getOrderNumber();
        orderDate = customerOrder.getOrderDate();
        shipDate = customerOrder.getShipDate();
        createdBy = customerOrder.getCreatedBy();
        immediateOrder = customerOrder.isImmediateOrder();
        onHold = customerOrder.isOnHold();
        cancelled = customerOrder.isCancelled();

        if (customerOrder.getCustomer() != null) {
            customer = new CustomerResponse(customerOrder.getCustomer());
        }
    }
}
