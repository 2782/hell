package com.sysco.prime.customerOrder;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.ser.std.StdSerializer;
import com.sysco.prime.product.response.ProductResponse;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class PrimeLineItemSerializer extends StdSerializer<PrimeLineItem> {
    PrimeLineItemSerializer() {
        super(PrimeLineItem.class);
    }

    @Override
    public void serialize(
            final PrimeLineItem value,
            final JsonGenerator gen,
            final SerializerProvider provider) throws IOException {
        final Map<String, Object> map = new HashMap<>();
        final LineItem lineItem = value.getLineItem();
        map.put("itemId", lineItem.getId());
        map.put("product", new ProductResponse(lineItem.getProduct(), value.getCosting()));
        map.put("customerOrder", lineItem.getCustomerOrder());
        map.put("quantity", lineItem.getQuantity());
        map.put("quantityInCases", lineItem.getQuantityInCases());
        map.put("quantityRemaining", value.getQuantityRemainingInCases());

        gen.writeObject(map);
    }
}
