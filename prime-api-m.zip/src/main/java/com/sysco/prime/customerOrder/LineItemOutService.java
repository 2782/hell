package com.sysco.prime.customerOrder;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.persistence.EntityManager;
import java.util.List;

@Service
public class LineItemOutService {
    private final LineItemOutRepository repository;
    private final EntityManager entityManager;

    @Autowired
    public LineItemOutService(final LineItemOutRepository repository, final EntityManager entityManager) {
        this.repository = repository;
        this.entityManager = entityManager;
    }

    public void create(final Long lineItemId, final int outQuantity) {
        final LineItem lineItem = entityManager.getReference(LineItem.class, lineItemId);
        repository.save(new LineItemOut(lineItem,outQuantity));
    }

    List<LineItemOut> getOutsByLineItemIds(final List<Long> lineItemIds) {
        return repository.findByLineItemIdIn(lineItemIds);
    }
}
