package com.sysco.prime.customerOrder;

import com.sysco.prime.PrimeRepository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

public interface CustomerOrderRepository extends PrimeRepository<CustomerOrder> {
    Optional<CustomerOrder> findByOrderNumber(String orderNumber);

    Optional<CustomerOrder> findByOrderNumberAndShipDate(String orderNumber, LocalDate shipDate);

    List<CustomerOrder> findByShipDateGreaterThanEqual(LocalDate nextWorkDay);
}
