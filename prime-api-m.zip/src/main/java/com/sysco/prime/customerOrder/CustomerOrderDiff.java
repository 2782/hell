package com.sysco.prime.customerOrder;

import lombok.Data;

import java.time.LocalDate;
import java.util.List;

import static com.sysco.prime.customerOrder.LineItemDiff.lineItemDiffs;

@Data
class CustomerOrderDiff {
    private final CustomerOrder oldOrder;
    private final CustomerOrder newOrder;

    private final List<LineItemDiff> lineItemDiff;

    CustomerOrderDiff(final CustomerOrder oldOrder, final CustomerOrder newOrder) {
        this.oldOrder = oldOrder;
        this.newOrder = newOrder;

        lineItemDiff = lineItemDiffs(oldOrder.getLineItems(), newOrder.getLineItems());
    }


    private boolean hasChangedFromFutureToToday(final LocalDate today) {
        final LocalDate oldDate = oldOrder.getShipDate();
        final LocalDate newDate = newOrder.getShipDate();

        return oldDate.isAfter(today) && newDate.equals(today);
    }

    private boolean hasChangedFromFutureToTomorrow(final LocalDate tomorrow) {
        final LocalDate oldDate = oldOrder.getShipDate();
        final LocalDate newDate = newOrder.getShipDate();

        return oldDate.isAfter(tomorrow) && newDate.equals(tomorrow);
    }


    private boolean hasChangedFromNonImmediateOrderToImmediateOrder(final LocalDate tomorrow) {
        final boolean newImmedOrderFlag = newOrder.isImmediateOrder();
        final boolean oldImmedOrderFlag = oldOrder.isImmediateOrder();

        return !oldImmedOrderFlag && newImmedOrderFlag;
    }

    boolean isNowNecessaryToCreateNewProductionOrdersFor(final LocalDate today, final LocalDate tomorrow) {
        return hasChangedFromFutureToToday(today)
                || hasChangedFromFutureToTomorrow(tomorrow)
                || hasChangedFromNonImmediateOrderToImmediateOrder(tomorrow);
    }
}
