package com.sysco.prime.customerOrder;

import com.fasterxml.jackson.annotation.JsonCreator;

import java.util.Comparator;

public enum DeliveryMethod {
    WILL_CALL("W", 1), NORMAL("N", 2);

    private final String value;
    private final int priority;

    DeliveryMethod(final String value, final int priority) {
        this.value = value;
        this.priority = priority;
    }

    @JsonCreator
    public static DeliveryMethod from(final String value) {
        for (final DeliveryMethod deliveryMethod : DeliveryMethod.values()) {
            if (deliveryMethod.value.equals(value)) {
                return deliveryMethod;
            }
        }
        throw new IllegalArgumentException();
    }

    @Override
    public String toString() {
        return value;
    }

    public int getPriority() {
        return priority;
    }

    public static final Comparator<DeliveryMethod> deliveryMethodComparator = Comparator
            .comparingInt(DeliveryMethod::getPriority);
}
