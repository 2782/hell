package com.sysco.prime.customerOrder;

import com.sysco.prime.PrimeRepository;

import java.util.List;

public interface StockAllocationRepository extends PrimeRepository<StockAllocation> {
    List<StockAllocation> findByLineItemIdIn(List<Long> lineItemIds);
}
