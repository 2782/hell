package com.sysco.prime.customerOrder;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.sysco.prime.customer.Customer;
import com.sysco.prime.product.ProductService;
import com.sysco.prime.shared.model.TransactionalEntity;
import com.sysco.prime.sus.model.product.SusLineItemData;
import com.sysco.prime.sus.model.product.salesOrder.SusSalesOrderStatus;
import com.sysco.prime.sus.model.product.salesOrder.SusSalesOrderStatusHeader;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

import javax.persistence.Entity;
import javax.persistence.Enumerated;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.validation.constraints.NotNull;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static java.util.stream.Collectors.toList;
import static javax.persistence.CascadeType.ALL;
import static javax.persistence.EnumType.STRING;
import static javax.persistence.FetchType.EAGER;
import static org.apache.commons.lang.RandomStringUtils.randomNumeric;

@AllArgsConstructor
@Builder(toBuilder = true)
@Data
@Entity
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
public class CustomerOrder extends TransactionalEntity {
    @NotNull
    private String orderNumber;

    @NotNull
    @ManyToOne(fetch = EAGER)
    @JoinColumn(name = "customerId")
    private Customer customer;

    private String createdBy;
    private String name; // TODO : Do we use this?
    @NotNull
    private LocalDate orderDate;
    private LocalDate shipDate;

    private boolean immediateOrder;
    @Enumerated(STRING)
    private DeliveryMethod deliveryMethod;
    @Enumerated(STRING)
    private TimedWillCallRoutes timedWillCallRoutes;
    private String routeName;
    @Setter
    private boolean cancelled;
    private boolean onHold;

    @Setter
    @OneToMany(mappedBy = "customerOrder", cascade = ALL, fetch = EAGER)
    @Fetch(value = FetchMode.SUBSELECT)
    @JsonIgnore
    @Builder.Default
    private List<LineItem> lineItems = new ArrayList<>();
    private String poNumber; // TODO : Do we use this?

    public static CustomerOrder fromSus(
            final SusSalesOrderStatus susSalesOrderData,
            final Customer customer,
            final ProductService productService) {
        final List<LineItem> lineItems = buildLineItems(productService, susSalesOrderData.getLineItems());

        return buildCustomerOrder(customer, susSalesOrderData.getHeader(), lineItems);
    }

    private static List<LineItem> buildLineItems(
            final ProductService productService,
            final List<SusLineItemData> susLineItems) {
        return susLineItems.stream()
                .map(susLineItem -> LineItem.fromSus(susLineItem, productService))
                .filter(lineItem -> lineItem.getProduct().isFinishedProductOutput()
                        || lineItem.getProduct().isByproductOnlyOutput())
                .collect(Collectors.toList());
    }

    private static CustomerOrder buildCustomerOrder(
            final Customer customer,
            final SusSalesOrderStatusHeader susSalesOrderDataHeader,
            final List<LineItem> lineItems) {
        final CustomerOrder customerOrder = CustomerOrder.builder()
                .orderDate(LocalDate.parse(susSalesOrderDataHeader.getOrderDate()))
                .shipDate(LocalDate.parse(susSalesOrderDataHeader.getShipDate()))
                .customer(customer)
                .createdBy(customer != null ? customer.getName() : "")
                .orderNumber(Optional
                        .ofNullable(susSalesOrderDataHeader.getOrderNumber())
                        .orElse(randomNumeric(5)))
                .immediateOrder(susSalesOrderDataHeader.immediateOrder())
                .deliveryMethod(DeliveryMethod.from(susSalesOrderDataHeader.getDeliveryMethod()))
                .timedWillCallRoutes(susSalesOrderDataHeader.hasTimedWillCallRoutes()
                        ? TimedWillCallRoutes.from(susSalesOrderDataHeader.getRouteNumber()) : null)
                .routeName(susSalesOrderDataHeader.getRouteNumber())
                .lineItems(lineItems)
                .cancelled(susSalesOrderDataHeader.isCancelled())
                .onHold(susSalesOrderDataHeader.onHold())
                .build();

        customerOrder.getLineItems().forEach(item -> item.setCustomerOrder(customerOrder));

        return customerOrder;
    }

    @JsonIgnore
    public String getCustomerCode() {
        return getCustomer().getCustomerCode();
    }

    @JsonIgnore
    boolean isShipDateIncludes(final LocalDate... dates) {
        return Stream.of(dates).anyMatch(date -> shipDate.equals(date));
    }

    @JsonIgnore
    boolean isFutureImmediateAfter(final LocalDate date) {
        return isImmediateOrder() && shipDate.isAfter(date);
    }

    public CustomerOrder update(final CustomerOrder updateWithOrder) {
        final Map<Integer, LineItem> existingItemsBySequenceNumber = new HashMap<>();
        for (LineItem existingItem : this.lineItems) {
            existingItemsBySequenceNumber.put(existingItem.getLineNumber(), existingItem);
        }

        final List<LineItem> updatedItems = updateWithOrder.getLineItems().stream().map(item -> {
            final LineItem updatedItem = item.toBuilder().build();
            final int sequenceNumber = updatedItem.getLineNumber();
            if (existingItemsBySequenceNumber.containsKey(sequenceNumber)) {
                final LineItem existingItem = existingItemsBySequenceNumber.get(sequenceNumber);
                updatedItem.setId(existingItem.getId());
                updatedItem.setCreatedAt(existingItem.getCreatedAt());
            }
            return updatedItem;
        }).collect(toList());

        final CustomerOrder updated = updateWithOrder.toBuilder()
                .lineItems(updatedItems)
                .build();

        updated.setCreatedAt(this.getCreatedAt());
        updated.setId(this.getId());

        updated.lineItems.forEach(lineItem -> lineItem.setCustomerOrder(updated));

        return updated;
    }

    public boolean hasNonSourceLineItems() {
        return this.lineItems.stream()
                .filter(item -> item.getProduct().isFinishedProductOutput()
                        || item.getProduct().isByproductOnlyOutput())
                .count() > 0;
    }

    public CustomerOrder copy() {
        final List<LineItem> itemCopies = lineItems.stream()
                .map(LineItem::copy)
                .collect(toList());
        final CustomerOrder orderCopy = toBuilder()
                .lineItems(itemCopies)
                .build();
        orderCopy.setId(getId());
        orderCopy.setCreatedAt(getCreatedAt());
        orderCopy.setUpdatedAt(getUpdatedAt());
        return orderCopy;
    }
}
