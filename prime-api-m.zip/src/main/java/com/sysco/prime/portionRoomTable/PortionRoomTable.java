package com.sysco.prime.portionRoomTable;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.sysco.prime.productionOrder.ProductionType;
import com.sysco.prime.shared.model.TransactionalEntity;
import com.sysco.prime.station.Station;
import com.sysco.prime.station.StationSerializer;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.RequiredArgsConstructor;
import lombok.ToString;

import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.validation.constraints.NotNull;
import java.time.LocalTime;

import static javax.persistence.FetchType.EAGER;

@Entity
@Data
@RequiredArgsConstructor
@EqualsAndHashCode(callSuper = false)
@AllArgsConstructor
@Builder
@ToString(callSuper = true, exclude = "station")
public class PortionRoomTable extends TransactionalEntity {
    @ManyToOne(fetch = EAGER)
    @JoinColumn(name = "stationId")
    @ApiModelProperty(hidden = true)
    @JsonSerialize(using = StationSerializer.class)
    private Station station;

    @NotNull
    private Integer tableCode;
    @NotNull
    private String tableDescription;

    private LocalTime tableOpenTime;
    private LocalTime tableCloseTime;
    private Integer poundsPerHour;

    public Long getStationId() {
        return station.getId();
    }

    boolean existing() {
        return null != getId();
    }

    public ProductionType getProductionType() {
        return station == null ? null : station.getProductionType();
    }
}
