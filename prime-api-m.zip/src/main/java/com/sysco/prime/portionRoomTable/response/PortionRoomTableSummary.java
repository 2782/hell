package com.sysco.prime.portionRoomTable.response;

import com.sysco.prime.portionRoomTable.PortionRoomTable;
import com.sysco.prime.station.Station;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;

import static java.util.stream.Collectors.toList;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class PortionRoomTableSummary {
    private Long tableId;
    private Integer tableCode;
    private Long stationId;
    private Integer stationCode;
    private String stationName;
    private String room;
    private String tableDescription;
    private LocalTime tableOpenTime;
    private LocalTime tableCloseTime;
    private Integer poundsPerHour;
    private String hours;

    public static final DateTimeFormatter hoursFormatter = DateTimeFormatter.ofPattern("h:mm a");

    private static PortionRoomTableSummary buildTableSummary(final PortionRoomTable entry) {
        final Station station = Optional.ofNullable(entry.getStation()).orElseGet(() -> Station.builder().build());

        return builder()
                .tableDescription(entry.getTableDescription())
                .room(station.getRoom().getCode())
                .tableCode(entry.getTableCode())
                .tableId(entry.getId())
                .stationId(station.getId())
                .stationCode(station.getStationCode())
                .stationName(station.getName())
                .tableCloseTime(entry.getTableCloseTime())
                .tableOpenTime(entry.getTableOpenTime())
                .poundsPerHour(entry.getPoundsPerHour())
                .hours(entry.getTableOpenTime().format(hoursFormatter) +  " - "
                        + entry.getTableCloseTime().format(hoursFormatter) )
                .build();
    }

    public static List<PortionRoomTableSummary> buildTableSummaryList(final List<PortionRoomTable>
                                                                              tableSummaryEntryList) {
        return tableSummaryEntryList.stream()
                .filter(entry -> !(entry.getTableCode() == null || entry.getTableCode() == 0))
                .map(PortionRoomTableSummary::buildTableSummary)
                .sorted(Comparator.comparing(PortionRoomTableSummary::getTableCode))
                .collect(toList());
    }
}
