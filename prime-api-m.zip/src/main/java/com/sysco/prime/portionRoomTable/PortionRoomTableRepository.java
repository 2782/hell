package com.sysco.prime.portionRoomTable;

import com.sysco.prime.PrimeRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface PortionRoomTableRepository extends PrimeRepository<PortionRoomTable> {
    Optional<PortionRoomTable> findByTableCode(Integer tableCode);

    @Query("SELECT p FROM PortionRoomTable p WHERE p.station.id = :stationId")
    List<PortionRoomTable> findByStationIdIs(@Param("stationId") Long stationId);
}
