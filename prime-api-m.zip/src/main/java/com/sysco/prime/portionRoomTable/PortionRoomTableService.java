package com.sysco.prime.portionRoomTable;

import com.sysco.prime.exception.NotFoundException;
import com.sysco.prime.portionRoomTable.response.PortionRoomTableSummary;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

import static com.sysco.prime.portionRoomTable.response.PortionRoomTableSummary.buildTableSummaryList;
import static java.lang.String.format;

@Service
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class PortionRoomTableService {
    private final PortionRoomTableRepository repository;
    private final PortionRoomTableValidator portionRoomTableValidator;

    public PortionRoomTable getTableById(final Long tableId) {
        final PortionRoomTable found = repository.getOneOrNull(tableId);
        if (null == found) {
            throw new NotFoundException(format("[find PortionRoomTable] Table with Id %s Not Found", tableId));
        }
        return found;
    }

    List<PortionRoomTableSummary> findAllTableSummary() {
        return buildTableSummaryList(repository.findAll());
    }

    public PortionRoomTable create(final PortionRoomTable table) {
        portionRoomTableValidator.validate(table);
        return repository.save(table);
    }

    public PortionRoomTable update(final Long tableId, final PortionRoomTable table) {
        final PortionRoomTable updated = getTableById(tableId);
        updated.setTableDescription(table.getTableDescription());
        updated.setPoundsPerHour(table.getPoundsPerHour());
        updated.setTableCloseTime(table.getTableCloseTime());
        updated.setTableOpenTime(table.getTableOpenTime());
        updated.setStation(table.getStation());

        portionRoomTableValidator.validate(updated);
        return repository.save(updated);
    }

    public PortionRoomTable getTableByCode(final int tableCode) {
        final Optional<PortionRoomTable> portionRoomTableFound = repository.findByTableCode(tableCode);
        if (!portionRoomTableFound.isPresent()) {
            throw new NotFoundException(format("[find PortionRoomTable] Table with code %s Not Found", tableCode));
        }
        return portionRoomTableFound.get();
    }
}
