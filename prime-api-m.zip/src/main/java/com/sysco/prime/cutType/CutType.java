package com.sysco.prime.cutType;

public enum CutType {
    STANDARD, BANQUET
}
