package com.sysco.prime.housePar.response;

import com.sysco.prime.housePar.HousePar;
import com.sysco.prime.product.response.ProductResponse;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.Singular;

import java.util.List;

import static java.util.stream.Collectors.toList;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class HouseParResponse {
    private Long id;
    private ProductResponse product;
    @Singular
    private List<ParValueResponse> configValues;

    public HouseParResponse(final HousePar housePar) {
        id = housePar.getId();
        configValues = housePar.getConfigValues().stream()
                .map(ParValueResponse::new)
                .collect(toList());

        if (housePar.getProduct() != null) {
            product = new ProductResponse(housePar.getProduct());
        }
    }
}
