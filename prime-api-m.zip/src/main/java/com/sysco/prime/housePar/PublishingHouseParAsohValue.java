package com.sysco.prime.housePar;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public class PublishingHouseParAsohValue {
    private String productCode;
    private int availableOnHand;
}
