package com.sysco.prime.housePar;

import com.sysco.prime.Reportable;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@AllArgsConstructor
@Builder
@Data
public class PublishingHouseParAsoh implements Reportable {
    private LocalDate date;
    private List<PublishingHouseParAsohValue> details;

    public static PublishingHouseParAsoh from(final LocalDate asohDate, final Map<String, Integer> stocks) {
        final PublishingHouseParAsoh result = builder()
                .date(asohDate)
                .details(new ArrayList<>())
                .build();

        stocks.forEach((productCode, availableOnHand) ->
                result.add(new PublishingHouseParAsohValue(productCode, availableOnHand)));

        return result;
    }

    private void add(final PublishingHouseParAsohValue value) {
        details.add(value);
    }
}

