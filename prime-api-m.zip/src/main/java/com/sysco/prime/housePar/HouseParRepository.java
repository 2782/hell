package com.sysco.prime.housePar;

import com.sysco.prime.PrimeRepository;

import java.util.List;

public interface HouseParRepository extends PrimeRepository<HousePar> {
    List<HousePar> findByDeletedFalse();

    List<HousePar> findByIdInAndDeletedFalse(List<Long> id);

    HousePar findFirstByDeletedFalseAndProductCodeIs(String productCode);
}
