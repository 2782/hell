package com.sysco.prime.profile;

import com.sysco.prime.PrimeRepository;

public interface ProfileRepository extends PrimeRepository<Profile> {
}
