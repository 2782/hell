package com.sysco.prime.profile;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder(toBuilder = true)
@EqualsAndHashCode(callSuper = false)
class ProfileRequest {
    @NotNull
    @Size(max = 3)
    @Pattern(regexp = "[0-9]*")
    private String plantNumber;
    @NotNull
    private String name;
    @NotNull
    private String address;
    @NotNull
    private String city;
    @NotNull
    @Pattern(regexp = "[0-9]+")
    private String zipCode;
    @NotNull
    private String establishmentNumber;
    private String state;
    @NotNull
    @Min(0)
    @Max(999999)
    private int vendorShipFrom;
    @NotNull
    @Min(0)
    @Max(99)
    private int sequenceNumber;

    Profile toProfile() {
        return Profile.builder()
                .city(city)
                .name(name)
                .state(state)
                .plantNumber(plantNumber)
                .address(address)
                .establishmentNumber(establishmentNumber)
                .zipCode(zipCode)
                .sequenceNumber(sequenceNumber)
                .vendorShipFrom(vendorShipFrom)
                .build();
    }
}
