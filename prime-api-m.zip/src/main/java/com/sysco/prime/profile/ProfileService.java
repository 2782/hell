package com.sysco.prime.profile;

import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

import static java.util.Objects.isNull;

@Service
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class ProfileService {

    private final ProfileRepository profileRepository;

    void createOrUpdate(final Profile profile) {
        final Profile existProfile = get();
        if (!isNull(existProfile)) {
            profile.setId(existProfile.getId());
            profile.setCreatedAt(existProfile.getCreatedAt());
        }

        profileRepository.save(profile);
    }

    public Profile get() {
        final List<Profile> profiles = profileRepository.findAll();
        if (isNull(profiles) || profiles.isEmpty()) {
            return null;
        }
        return profiles.get(0);
    }
}
