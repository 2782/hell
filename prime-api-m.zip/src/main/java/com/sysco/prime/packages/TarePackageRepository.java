package com.sysco.prime.packages;

import com.sysco.prime.PrimeRepository;

import java.util.Optional;

public interface TarePackageRepository extends PrimeRepository<TarePackage> {
    Optional<TarePackage> findByDefaultedTrue();
}
