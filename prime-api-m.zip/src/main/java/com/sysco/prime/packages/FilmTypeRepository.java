package com.sysco.prime.packages;

import com.sysco.prime.PrimeRepository;

public interface FilmTypeRepository extends PrimeRepository<FilmType> {
}
