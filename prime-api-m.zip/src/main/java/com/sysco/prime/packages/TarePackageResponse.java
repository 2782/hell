package com.sysco.prime.packages;

import lombok.Getter;

@Getter
public class TarePackageResponse {
    private final Long id;
    private final BoxType boxType;
    private final FilmType filmType;
    private final boolean defaulted;

    public TarePackageResponse(final TarePackage tarePackage) {
        id = tarePackage.getId();
        boxType = tarePackage.getBoxType();
        filmType = tarePackage.getFilmType();
        defaulted = tarePackage.isDefaulted();
    }
}
