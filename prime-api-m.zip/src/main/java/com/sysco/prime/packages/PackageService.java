package com.sysco.prime.packages;

import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

import static org.springframework.data.domain.ExampleMatcher.matching;

@Service
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class PackageService {
    private final BoxTypeRepository boxTypeRepository;
    private final FilmTypeRepository filmTypeRepository;
    private final TarePackageRepository tarePackageRepository;
    private final PiecesPackageRepository piecesPackageRepository;

    List<BoxType> getAllBoxTypes() {
        return boxTypeRepository.findAll();
    }

    List<FilmType> getAllFilmTypes() {
        return filmTypeRepository.findAll();
    }

    List<TarePackage> getAllTarePackages() {
        final Sort sort = new Sort(Direction.ASC, "boxType.boxDescription", "filmType.filmDescription");
        return tarePackageRepository.findAll(sort);
    }

    public TarePackage findTarePackageById(final Long id) {
        return tarePackageRepository.getOneOrNull(id);
    }

    public TarePackage findOneTarePackageLike(final TarePackage example) {
        return tarePackageRepository.findOne(Example.of(example)).orElse(null);
    }

    public TarePackage findDefaultParePackage() {
        return tarePackageRepository.findByDefaultedTrue().orElse(null);
    }

    @Transactional
    public TarePackage saveOneTarePackage(final TarePackage tarePackage) {
        final TarePackage previouslySaved;
        final Long tarePackageId = tarePackage.getId();

        if (null == tarePackageId) {
            previouslySaved = tarePackageRepository.findOne(
                    Example.of(tarePackage, matching().withIgnorePaths("defaulted", "id"))).orElse(null);
        } else {
            previouslySaved = tarePackageRepository.getOneOrNull(tarePackageId);
        }

        return saveTarePackage(tarePackage, previouslySaved);
    }

    private TarePackage saveTarePackage(final TarePackage tarePackage, final TarePackage previouslySaved) {
        if (tarePackage.isDefaulted()) {
            tarePackageRepository.findByDefaultedTrue().ifPresent(existingTarePackage -> {
                existingTarePackage.removeDefault(existingTarePackage);
                tarePackageRepository.save(existingTarePackage);
            });
        }

        if (null != previouslySaved) {
            tarePackage.update(previouslySaved);
        }

        return tarePackageRepository.save(tarePackage);
    }

    public List<PiecesPackage> getAllPiecesPackages() {
        return piecesPackageRepository.findAll();
    }

    public PiecesPackage findPiecesPackageById(final Long piecesPackageId) {
        return piecesPackageRepository.getOneOrNull(piecesPackageId);
    }
}
