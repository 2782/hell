package com.sysco.prime.packages;

import lombok.Getter;

@Getter
public class PiecesPackageResponse {
    private final Long id;
    private final String description;
    private final double weight;

    public PiecesPackageResponse(final PiecesPackage piecesPackage) {
        id = piecesPackage.getId();
        description = piecesPackage.getDescription();
        weight = piecesPackage.getWeight();
    }
}
