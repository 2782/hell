package com.sysco.prime.packages;

import com.sysco.prime.shared.model.TransactionalEntity;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

import static javax.persistence.FetchType.EAGER;

@Entity
@Data
@Builder(toBuilder = true)
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
public class TarePackage extends TransactionalEntity {
    @OneToOne(fetch = EAGER)
    @JoinColumn(name = "boxTypeId")
    private BoxType boxType;

    @OneToOne(fetch = EAGER)
    @JoinColumn(name = "filmTypeId")
    private FilmType filmType;

    private boolean defaulted;

    void update(final TarePackage previouslySaved) {
        setId(previouslySaved.getId());
        setCreatedAt(previouslySaved.getCreatedAt());
    }

    void removeDefault(final TarePackage previouslySaved) {
        setDefaulted(false);
        update(previouslySaved);
    }
}
