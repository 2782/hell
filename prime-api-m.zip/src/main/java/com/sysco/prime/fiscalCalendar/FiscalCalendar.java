package com.sysco.prime.fiscalCalendar;

import com.sysco.prime.shared.model.TransactionalEntity;
import com.sysco.prime.utils.TimeUtils;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import javax.persistence.Entity;
import javax.validation.constraints.NotNull;
import java.time.Duration;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.HashMap;
import java.util.Map;

@EqualsAndHashCode(callSuper = false)
@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class FiscalCalendar extends TransactionalEntity {
    private static final int DAYS_IN_A_WEEK = 7;
    private static final int WEEK_COUNT_FOR_FIRST_MONTH_OF_FISCAL_YEAR = 4;
    private static final int WEEK_COUNT_AT_END_OF_SECOND_MONTH_OF_FISCAL_YEAR = 8;
    private static final int WEEK_COUNT_OF_LAST_MONTH_OF_A_FISCAL_QUARTER = 5;
    private static final int WEEK_COUNT_FOR_A_QUARTER = 13;

    @NotNull
    private LocalDate startDate;
    private LocalDate nextStartDate;
    private boolean active;

    void update(final FiscalCalendar newFiscalCalendar) {
        setNextStartDate(newFiscalCalendar.getNextStartDate());
    }

    boolean checkReportDateIsInCurrentFiscalCalendar(final OffsetDateTime reportDate) {
        return getDateDifference(reportDate, startDate) > 0;
    }

    Map<String, LocalDate> getFiscalMonthFor(final OffsetDateTime reportDate) {
        final LocalDate startDateOfCurrentMonth = getFiscalMonthStartingDateFor(reportDate);
        final LocalDate endDateOfCurrentMonth = reportDate.plusWeeks(1).toLocalDate();
        final HashMap<String, LocalDate> fiscalMonthMap = new HashMap<>();
        fiscalMonthMap.put("start", startDateOfCurrentMonth);
        fiscalMonthMap.put("end", endDateOfCurrentMonth);

        return fiscalMonthMap;
    }

    Map<Integer, LocalDate> getFiscalWeeksForReportDateMonth(final OffsetDateTime reportDate) {
        final LocalDate startDateOfCurrentMonth = getFiscalMonthStartingDateFor(reportDate);
        final long fiscalWeekOfStartDate =
                getFiscalWeek(TimeUtils.getStartTimeOfDay(startDateOfCurrentMonth));

        final Map<Integer, LocalDate> result = new HashMap<>();
        for (long start = fiscalWeekOfStartDate; start <= getFiscalWeek(reportDate); start++) {
            result.put((int) start, startDate.plusDays((int) ((start - 1) * DAYS_IN_A_WEEK)));
        }

        return result;
    }

    String getFiscalWeekWithYear(final OffsetDateTime reportDate) {
        final int year = getFiscalCalenderYear();
        final long week = getFiscalWeek(reportDate);

        return String.format("%s/%s", week, year);
    }

    private LocalDate getFiscalMonthStartingDateFor(final OffsetDateTime reportDate) {
        final long fiscalWeek = getFiscalWeek(reportDate);
        final long quarter = fiscalWeek / WEEK_COUNT_FOR_A_QUARTER;
        final long weekForNextQuarter = fiscalWeek % WEEK_COUNT_FOR_A_QUARTER;
        final long startingWeekOfMonth = getWeekCount(weekForNextQuarter, false);
        final long weeks = quarter * WEEK_COUNT_FOR_A_QUARTER + startingWeekOfMonth;

        return startDate.plusWeeks((int) weeks);
    }

    private long getWeekCount(final long weekForNextQuarter, final boolean fromStartDateOfFiscalMonth) {
        final long weekCount;
        if (weekForNextQuarter <= WEEK_COUNT_FOR_FIRST_MONTH_OF_FISCAL_YEAR) {
            weekCount = !fromStartDateOfFiscalMonth ? 0 : WEEK_COUNT_FOR_FIRST_MONTH_OF_FISCAL_YEAR;
        } else if (weekForNextQuarter <= WEEK_COUNT_AT_END_OF_SECOND_MONTH_OF_FISCAL_YEAR) {
            weekCount = WEEK_COUNT_FOR_FIRST_MONTH_OF_FISCAL_YEAR;
        } else {
            weekCount = !fromStartDateOfFiscalMonth
                    ? WEEK_COUNT_AT_END_OF_SECOND_MONTH_OF_FISCAL_YEAR : WEEK_COUNT_OF_LAST_MONTH_OF_A_FISCAL_QUARTER;
        }

        return weekCount;
    }

    private long getDateDifference(final OffsetDateTime checkedDate, final LocalDate originDate) {
        return Duration.between(originDate.atStartOfDay(), checkedDate.toLocalDateTime()).toDays();
    }

    private int getFiscalCalenderYear() {
        return startDate.getYear();
    }

    private long getFiscalWeek(final OffsetDateTime reportDate) {
        final long diff = getDateDifference(reportDate, startDate);
        return diff / DAYS_IN_A_WEEK + 1;
    }
}
