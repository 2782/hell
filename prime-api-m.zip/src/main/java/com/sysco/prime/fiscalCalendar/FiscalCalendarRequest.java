package com.sysco.prime.fiscalCalendar;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotNull;
import java.time.LocalDate;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder(toBuilder = true)
@EqualsAndHashCode(callSuper = false)
class FiscalCalendarRequest {
    @NotNull
    private Long id;
    @NotNull
    private LocalDate nextStartDate;

    FiscalCalendar toDomain() {
        return FiscalCalendar.builder().nextStartDate(nextStartDate).build();
    }
}
