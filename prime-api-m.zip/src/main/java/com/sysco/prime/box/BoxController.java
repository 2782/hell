package com.sysco.prime.box;

import com.sysco.prime.box.request.CustomerBoxRequest;
import com.sysco.prime.box.request.RelabelRequest;
import com.sysco.prime.box.request.ReprintForStationRequest;
import com.sysco.prime.box.request.ReprintRequest;
import com.sysco.prime.box.request.StockBoxRequest;
import com.sysco.prime.box.request.WipBoxRequest;
import com.sysco.prime.cost.CostService;
import com.sysco.prime.portionRoom.PortionRoomService;
import com.sysco.prime.product.ProductService;
import com.sysco.prime.productionOrder.ProductionOrderService;
import com.sysco.prime.station.StationService;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import java.time.Clock;
import java.time.LocalDate;
import java.util.List;

import static com.sysco.prime.box.BoxResponse.from;
import static java.util.stream.Collectors.toList;
import static org.springframework.format.annotation.DateTimeFormat.ISO.DATE;
import static org.springframework.http.HttpStatus.CREATED;
import static org.springframework.http.HttpStatus.NO_CONTENT;

@RestController
@RequestMapping("/api/boxes")
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BoxController {
    private final Clock clock;
    private final BoxService service;
    private final ProductService productService;
    private final ProductionOrderService productionOrderService;
    private final StationService stationService;
    private final CostService costService;
    private final PortionRoomService portionRoomService;

    @GetMapping
    @ApiOperation(value = "Get boxes", notes = "Get packed off boxes.")
    @Secured({"ROLE_ADMIN", "ROLE_PORTION_ROOM_MEMBER"})
    public List<BoxResponse> getBoxes(
            @RequestParam(value = "product-code") final String productCode,
            @RequestParam(value = "date") @DateTimeFormat(iso = DATE) final LocalDate date,
            @RequestParam(value = "sus-order-no", required = false) final String susOrderNo) {
        return service.getBoxes(productCode, date, susOrderNo).stream()
                .map(BoxResponse::from)
                .collect(toList());
    }

    @GetMapping(path = "/wip")
    @ApiOperation(value = "Get Wip boxes", notes = "Get Wip boxes.")
    @Secured({"ROLE_ADMIN", "ROLE_PORTION_ROOM_MEMBER"})
    public List<WipBoxResponse> getBoxes() {
        return service.getWipBoxes().stream()
                .map(box -> WipBoxResponse.from(box,
                        costService.costing(box.getItemProduct())))
                .collect(toList());
    }

    @PostMapping
    @ApiOperation(value = "packOff off a single order and create a box",
            notes = "packOff off a single order by id and create a box.")
    @ResponseStatus(CREATED)
    @Secured({"ROLE_ADMIN", "ROLE_PORTION_ROOM_MEMBER"})
    public BoxResponse packOff(@Valid @RequestBody final CustomerBoxRequest boxRequest) {
        return from(service.packoffCustomerBox(
                boxRequest.toDomain(stationService, productionOrderService, productService, clock),
                portionRoomService.getPortionRoomByCode(boxRequest.getRoomCode())));
    }

    @PostMapping("/stock")
    @ApiOperation(value = "packOff off a single order and create a box",
            notes = "packOff off a single order by id and create a box.")
    @ResponseStatus(CREATED)
    @Secured({"ROLE_ADMIN", "ROLE_PORTION_ROOM_MEMBER"})
    public BoxResponse packStock(@Valid @RequestBody final StockBoxRequest boxRequest) {
        return from(service.packoffGenericBox(
                boxRequest.toDomainForStock(stationService, productService, clock),
                portionRoomService.getPortionRoomByCode(boxRequest.getRoomCode())));
    }

    @PostMapping("pack-wip")
    @ApiOperation(value = "packOff off a single order and create a box",
            notes = "packOff off a single order by id and create a box.")
    @ResponseStatus(CREATED)
    @Secured({"ROLE_ADMIN", "ROLE_PORTION_ROOM_MEMBER"})
    public BoxResponse packWip(@Valid @RequestBody final WipBoxRequest boxRequest) {
        return from(service.packoffGenericBox(boxRequest.toDomainForPackWip(stationService, productService, clock),
                portionRoomService.getPortionRoomByCode(boxRequest.getRoomCode())));
    }

    @GetMapping("read-houston-scale")
    @ApiOperation(value = "reads the Net Weight in pounds from the Houston scale",
            notes = "A 500 status code indicates an API code bug")
    @Secured({"ROLE_ADMIN", "ROLE_PORTION_ROOM_MEMBER"})
    public String readWeightFromHoustonScale() {
        return service.readWeightFromScale();
    }

    @PostMapping(path = "/labels/reprint")
    @ApiOperation(value = "Reprint a label",
            notes = "reprint the labels.")
    @ResponseStatus(NO_CONTENT)
    @Secured({"ROLE_ADMIN", "ROLE_PORTION_ROOM_MEMBER"})
    public void reprintLabel(@Valid @RequestBody final ReprintRequest reprintRequest) {
        service.reprintLabel(reprintRequest.getReprintWeightingId(), reprintRequest.getType(),
                null);
    }

    @PostMapping(path = "/labels/reprint-for-station")
    @ApiOperation(value = "Reprint a label given stationCode",
            notes = "reprint the labels for a given station.")
    @ResponseStatus(NO_CONTENT)
    @Secured({"ROLE_ADMIN", "ROLE_PORTION_ROOM_MEMBER"})
    public void reprintLabelForStation(@Valid @RequestBody final ReprintForStationRequest reprintForStationRequest) {
        service.reprintLabel(reprintForStationRequest.getReprintWeightingId(), reprintForStationRequest.getType(),
                reprintForStationRequest.getStationCode());
    }

    @PostMapping(path = "/labels/relabel")
    @ApiOperation(value = "Relabel a packoff label",
            notes = "relabel the packoff label in a given station.")
    @ResponseStatus(NO_CONTENT)
    @Secured({"ROLE_ADMIN", "ROLE_PORTION_ROOM_MEMBER"})
    public void relabelPackOffLabel(@Valid @RequestBody final RelabelRequest relabelRequest) {
        service.relabelPackOffLabel(relabelRequest.getReprintBoxId(), relabelRequest.getStationCode());
    }

    @DeleteMapping(path = "/wip/{wipId}")
    @ApiOperation(value = "Delete a wip box", notes = "delete the spoiled WIP box")
    @Secured({"ROLE_ADMIN"})
    public void deleteWip(@PathVariable final long wipId) {
        service.deleteWipBox(wipId);
    }

    @PutMapping("/wip/{barcode}/room/{roomCode}")
    @ApiOperation(value = "Bring box back in room",
            notes = "Bring box back in room")
    @ResponseStatus(NO_CONTENT)
    @Secured({"ROLE_ADMIN", "ROLE_PORTION_ROOM_MEMBER"})
    public void bringWipInRoom(@PathVariable final String barcode, @PathVariable final String roomCode) {
        service.bringWipInRoom(barcode, portionRoomService.getPortionRoomByCode(roomCode));
    }
}
