package com.sysco.prime.box.request;

import com.sysco.prime.box.validation.ExistedWeighing;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.RequiredArgsConstructor;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

@Data
@RequiredArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
@EqualsAndHashCode(callSuper = false)
public class ReprintRequest {
    @Valid
    @NotNull
    @ExistedWeighing
    private Long reprintWeightingId;

    @NotNull
    private ReprintLabelRequestType type;
}
