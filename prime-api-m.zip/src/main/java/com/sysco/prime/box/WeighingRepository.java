package com.sysco.prime.box;

import com.sysco.prime.PrimeRepository;

public interface WeighingRepository extends PrimeRepository<Weighing> {

}
