package com.sysco.prime.box;

import com.sysco.prime.Reportable;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.time.LocalDate;

@Builder(toBuilder = true)
@Data
@EqualsAndHashCode(callSuper = false)
public class PublishingReturnBox implements Reportable {
    private String productCode;
    private String productDescription;
    private double currentCost;
    private double weightedAverageCost;
    private double weight;
    private double totalTareWeight;
    private double packageTareWeight;
    private double netWeight;
    private boolean isFixedWeightProduct;
    private LocalDate workingDate;
    private String portionRoomCode;
    private boolean incomplete;
    private String packoffStationName;
    private String userId;

    @Override
    public String productCode() {
        return productCode;
    }
}
