package com.sysco.prime.box.request;

import com.sysco.prime.box.validation.PackoffUser;

@PackoffUser
public interface BoxRequest {

    String getRoomCode();
}
