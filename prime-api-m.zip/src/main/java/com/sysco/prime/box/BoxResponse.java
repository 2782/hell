package com.sysco.prime.box;

import lombok.Builder;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

import static java.util.Collections.emptyList;
import static java.util.stream.Collectors.toList;

@Data
@Builder
public class BoxResponse {
    private final Long id;
    private final LocalDateTime packTime;
    private final BigDecimal weight;
    private final BigDecimal packagingTare;
    private final Double netWeight;
    private final Integer overrideWeightRangeReasonCode;
    private final Boolean forProductionOrder;
    private final Boolean isFullBox;
    private final List<WeighingResponse> weighings;
    private final String productCode;

    public static BoxResponse from(final Box box) {
        return builder()
                .id(box.getId())
                .packTime(box.getCreatedAt())
                .isFullBox(box.isFullBox())
                .weight(box.getWeight())
                .packagingTare(box.getPackagingTare())
                .netWeight(box.getNetWeight().doubleValue())
                .overrideWeightRangeReasonCode(box.getOverrideWeightRangeReasonCode())
                .forProductionOrder(box.isForProductionOrder())
                .weighings(box.getWeighings() == null ? emptyList() : box.getWeighings()
                        .stream()
                        .map(WeighingResponse::from)
                        .collect(toList()))
                .productCode(box.getProductCode())
                .build();
    }
}
