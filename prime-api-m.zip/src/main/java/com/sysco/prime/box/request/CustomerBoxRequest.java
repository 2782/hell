package com.sysco.prime.box.request;

import com.sysco.prime.box.Box;
import com.sysco.prime.box.validation.ActiveCutOrder;
import com.sysco.prime.box.validation.PackoffCustomerBox;
import com.sysco.prime.box.validation.WeighingsPerBox;
import com.sysco.prime.product.Product;
import com.sysco.prime.product.ProductService;
import com.sysco.prime.product.validation.ValidProduct;
import com.sysco.prime.productionOrder.ProductionOrderService;
import com.sysco.prime.shared.validation.FieldChecks;
import com.sysco.prime.station.StationService;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

import javax.validation.GroupSequence;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.groups.Default;
import java.math.BigDecimal;
import java.time.Clock;
import java.util.List;

import static com.sysco.prime.box.Box.Status.ASSIGNED;
import static java.time.LocalDate.now;
import static java.util.stream.Collectors.toList;

@Data
@RequiredArgsConstructor
@Builder
@GroupSequence({FieldChecks.class, CustomerBoxRequest.class})
@WeighingsPerBox
@PackoffCustomerBox(groups = Default.class)
@ActiveCutOrder
public class CustomerBoxRequest implements BoxRequest {
    private final Long id;

    private final Long productionOrderId;
    private final Integer qtyToProduce;
    @NotNull(groups = FieldChecks.class)
    @ValidProduct(groups = FieldChecks.class, finished = true)
    private final String productCode;
    @NotNull
    private final String roomCode;
    @NotNull
    private final BigDecimal packagingTare;

    @Valid
    private final List<WeighingRequest> weighings;

    public Box toDomain(final StationService stationService,
                        final ProductionOrderService productionOrderService,
                        final ProductService productService,
                        final Clock clock) {
        final Product productForBox = productService.findByCode(productCode);

        final Box box = Box.builder()
                .itemProduct(productForBox)
                .sourceCutOrderId(productionOrderId)
                .packoffStationName(stationService.getCurrentPackoffStation().getName())
                .targetProductionOrder(productionOrderService.findById(productionOrderId))
                .packagingTare(packagingTare)
                .incomplete(false)
                .consumedDate(now(clock))
                .status(ASSIGNED)
                .weighings(weighings.stream()
                        .map(WeighingRequest::toDomain)
                        .collect(toList()))
                .build();
        box.setId(id);
        box.getWeighings().forEach(weighing -> weighing.setBox(box));
        return box;
    }
}
