package com.sysco.prime.box;

import com.sysco.prime.cost.Costing;
import com.sysco.prime.cost.Money;
import com.sysco.prime.product.Product;
import com.sysco.prime.product.ProductOutput;
import com.sysco.prime.product.ProductPortionSize;
import lombok.Builder;
import lombok.Data;

import javax.validation.constraints.NotNull;
import java.time.LocalDate;

@Data
@Builder
public class WipBoxResponse {
    private final long id; // For React keys, please don't use for domain logic
    private final double netWeight;
    private final String productCode;
    private final String productDesc;
    private final ProductPortionSize productPortionSize;
    private final boolean productionProduct;
    private final LocalDate packDate;
    private final String cost; // Ensure BigDecimal rounding is preserved
    private final String status;
    private final String portionRoomDesc;

    public static WipBoxResponse from(final Box box, final Costing costing) {
        return build(box)
                .cost(Money.of(costing.getCurrentCost())
                        .toString())
                .build();
    }

    public static WipBoxResponse from(final Box box) {
        return build(box).build();
    }

    private static WipBoxResponseBuilder build(final Box box) {
        @NotNull final Product product = box.getItemProduct();
        return builder()
                .id(box.getId())
                .netWeight(box.getNetWeight().doubleValue())
                .productCode(product.getCode())
                .productDesc(product.getDescription())
                .productPortionSize(product.getProductPortionSize())
                .productionProduct(product.isFinishedProductOutput() || product.isByproductOnlyOutput())
                .portionRoomDesc(null != box.getReservedForPortionRoom()
                        ? box.getReservedForPortionRoom().getDescription() : null)
                .packDate(box.getConsumedDate())
                .status(box.getStatus().name());
    }
}
