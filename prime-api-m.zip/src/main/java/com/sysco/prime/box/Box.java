package com.sysco.prime.box;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.sysco.prime.box.PublishingBox.PublishingBoxBuilder;
import com.sysco.prime.cost.Cost;
import com.sysco.prime.cost.Costing;
import com.sysco.prime.customerOrder.CustomerOrder;
import com.sysco.prime.portionRoom.PortionRoom;
import com.sysco.prime.product.Product;
import com.sysco.prime.productionOrder.ProductionOrder;
import com.sysco.prime.purchaseOrder.PurchaseLineItemCase;
import com.sysco.prime.shared.model.TransactionalEntity;
import com.sysco.prime.yieldModel.CuttingYieldModel;
import com.sysco.prime.yieldModel.YieldModelBase;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

import javax.persistence.Entity;
import javax.persistence.Enumerated;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Version;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;

import static com.sysco.prime.box.Box.Status.ASSIGNED;
import static com.sysco.prime.box.Box.Status.AVAILABLE;
import static com.sysco.prime.box.Box.Status.IN_PORTION_ROOM;
import static com.sysco.prime.box.Box.Status.RESERVED;
import static com.sysco.prime.product.ProductCategory.CATCH;
import static com.sysco.prime.utils.TimeUtils.LABEL_YEAR_MONTH_DAY_FORMATTER;
import static java.lang.String.valueOf;
import static java.math.BigDecimal.ZERO;
import static java.math.RoundingMode.HALF_UP;
import static java.time.LocalDate.now;
import static java.time.temporal.ChronoUnit.DAYS;
import static javax.persistence.CascadeType.ALL;
import static javax.persistence.EnumType.STRING;
import static javax.persistence.FetchType.EAGER;
import static javax.persistence.FetchType.LAZY;

@AllArgsConstructor
@Builder(toBuilder = true)
@Getter
@Setter
@ToString
@Entity
@NoArgsConstructor
public class Box extends TransactionalEntity {
    private static final String REGEX_SLASH = "\\/";
    @Version
    @JsonIgnore
    private Long version;
    private Long sourceCutOrderId; // TODO: Use a production order reference
    @OneToOne(fetch = EAGER)
    @JoinColumn(name = "productionOrderId")
    private ProductionOrder targetProductionOrder;
    private LocalDate consumedDate;
    @NotNull
    @OneToOne(fetch = EAGER)
    @JoinColumn(name = "productCode", referencedColumnName = "code")
    @JsonIgnore
    private Product itemProduct;
    @Enumerated(STRING)
    private Status status;
    private String packoffStationName;
    private boolean relabel;
    // TODO: Rename this to something else
    private boolean incomplete;
    @OneToOne(fetch = LAZY)
    @JoinColumn(name = "reservedForPortionRoom", referencedColumnName = "id")
    private PortionRoom reservedForPortionRoom;
    private String barcode;
    @NotNull
    private BigDecimal packagingTare;
    @OneToMany(fetch = EAGER, cascade = ALL, targetEntity = Weighing.class, mappedBy = "box")
    @Fetch(value = FetchMode.SUBSELECT)
    private List<Weighing> weighings;

    public PurchaseLineItemCase toPurchaseLineItemCase() {
        return PurchaseLineItemCase.builder()
                .weight(getWeight().floatValue())
                .packDate(consumedDate)
                .build();
    }

    public BigDecimal getWeight() {
        return aggregateWeighings(Weighing::getWeight);
    }

    public BigDecimal getTotalTare() {
        return packagingTare.add(aggregateWeighings(Weighing::getRetailPieceTare));
    }

    public BigDecimal getNetWeight() {
        final BigDecimal netWeightAggregateOfPieces = aggregateWeighings(Weighing::getNetWeight);
        return netWeightAggregateOfPieces.subtract(packagingTare);
    }

    private BigDecimal aggregateWeighings(final Function<Weighing, BigDecimal> operator) {
        if (weighings == null) {
            return ZERO;
        }
        return weighings.stream()
                .map(operator)
                .reduce(BigDecimal.ZERO, BigDecimal::add)
                .setScale(2, HALF_UP);
    }

    void assign(final ProductionOrder productionOrder) {
        targetProductionOrder = productionOrder;
        consumedDate = now();
        status = ASSIGNED;
    }

    public Box changeBoxStatusToInPortionRoom() {
        final Box updatedBox = this.toBuilder()
                .status(IN_PORTION_ROOM)
                .incomplete(false)
                .build();
        updatedBox.setId(getId());
        updatedBox.setCreatedAt(getCreatedAt());
        updatedBox.setUpdatedAt(getUpdatedAt());
        return updatedBox;
    }

    public long daysFromConsumed(final LocalDate currentDate) {
        return DAYS.between(currentDate, consumedDate);
    }

    public void assignBarCode() {
        final String gtin = itemProduct.getPaddedGtin();
        final BigDecimal currentWeight = CATCH == itemProduct.getCategory() || isIncomplete()
                ? getNetWeight()
                : BigDecimal.valueOf(itemProduct.getWeightPerBox());
        final BigDecimal weightInLbs = currentWeight.setScale(2, HALF_UP);
        final String netWeightInLbsTimeHundred = valueOf(new BigDecimal(
                valueOf(weightInLbs))
                .multiply(new BigDecimal(100)));
        final int decimalPlace = netWeightInLbsTimeHundred.indexOf('.');
        final String netWeightInLbs = netWeightInLbsTimeHundred.substring(0, decimalPlace);
        final String paddedNetWeightInLbs = String.format("%06d", Integer.parseInt(netWeightInLbs));
        final String packDate = getConsumedDate().format(LABEL_YEAR_MONTH_DAY_FORMATTER).replaceAll(REGEX_SLASH, "");

        final String uniqueSerialNumber = getBoxSerialNumber();
        final StringBuilder dataToGenerateBarcodeBuilder = new StringBuilder();

        dataToGenerateBarcodeBuilder.append("01")
                .append(gtin)
                .append("3202")
                .append(paddedNetWeightInLbs)
                .append("11")
                .append(packDate)
                .append("21")
                .append(uniqueSerialNumber);

        barcode = dataToGenerateBarcodeBuilder.toString();
    }

    private PublishingBox.PublishingBoxBuilder publishingBoxBuilder(final Product portionRoomProduct,
                                                                    final Cost cost,
                                                                    final PortionRoom portionRoom,
                                                                    String packoffBoxUserId) {
        final String portionSize = portionRoomProduct.getProductPortionSize().getPortionSize();
        final CustomerOrder builtCustomerOrder = getCustomerOrderIfExists();
        return PublishingBox.builder()
                .cost(cost.getCurrentCostPerPound().doubleValue())
                .customerOrder(builtCustomerOrder)
                .weightPerBox(portionRoomProduct.getWeightPerBox())
                .weight(getWeight().doubleValue())
                .totalTareWeight(getTotalTare().doubleValue())
                .packageTareWeight(getPackagingTare().doubleValue())
                .isFixedWeightProduct(portionRoomProduct.isFixedWeight())
                .labor(cost.getLabor().doubleValue())
                .netWeight(getNetWeight().doubleValue())
                .packoffStationName(packoffStationName)
                .portionRoomCode(portionRoom.getCode())
                .portionSize(portionSize)
                .productCode(itemProduct.getCode())
                .productDescription(portionRoomProduct.getDescription())
                .stationCode(portionRoomProduct.getTable().getStation().getStationCode())
                .status(status)
                .tableCode(portionRoomProduct.getTable().getTableCode())
                .tableDescription(portionRoomProduct.getTable().getTableDescription())
                .weightedAverageCost(cost.getWeightedAverageCost().doubleValue())
                .workingDate(portionRoom.getLastOpenedAt().toLocalDate())
                .incomplete(incomplete)
                .userId(packoffBoxUserId)
                .byproductOnly(false)
                .piecesPerCase((targetProductionOrder != null && isRetail())
                        ? portionRoomProduct.getPiecesPerCase() : 0);
    }

    public PublishingBox toReportingOnFinishedProduct(
            final Product portionRoomProduct,
            final Cost cost,
            final PortionRoom portionRoom,
            final YieldModelBase yieldModel, String packoffBoxUserId) {
        final PublishingBoxBuilder builder =
                publishingBoxBuilder(portionRoomProduct, cost, portionRoom, packoffBoxUserId);

        if (yieldModel instanceof CuttingYieldModel) {
            final CuttingYieldModel cuttingYieldModel = (CuttingYieldModel) yieldModel;
            builder.sourceProductCode(cuttingYieldModel.getSourceProductCode())
                    .yieldPercentage(cuttingYieldModel.getYieldPercentage().doubleValue());
        }

        return builder.build();
    }

    public PublishingWipSpoil toReportingWipSpoil(final Costing costing) {
        final PublishingWipSpoil publishingWipSpoil =
                PublishingWipSpoil.builder()
                        .productCode(itemProduct.getCode())
                        .productDescription(itemProduct.getDescription())
                        .netWeight(getNetWeight().setScale(2, RoundingMode.HALF_UP).doubleValue())
                        .cost(costing.getCurrentCost())
                        .age(Long.valueOf(DAYS.between(consumedDate, now())).intValue())
                        .build();

        return publishingWipSpoil;
    }

    public PublishingBox toReportingOnByproductOnlyProduct(
            final Product byproduct,
            final Cost cost,
            final PortionRoom portionRoom, String packoffBoxUserId) {
        final PublishingBoxBuilder builder = publishingBoxBuilder(byproduct, cost, portionRoom, packoffBoxUserId);

        builder.byproductOnly(true);

        return builder.build();
    }

    public PublishingReturnBox toReportingOnSourceProduct(
            final Product sourceProduct,
            final Cost cost,
            final PortionRoom portionRoom) {
        return PublishingReturnBox.builder()
                .productCode(itemProduct.getCode())
                .productDescription(sourceProduct.getDescription())
                .currentCost(cost.getMarketCost().doubleValue())
                .weightedAverageCost(cost.getWeightedAverageCost().doubleValue())
                .netWeight(getNetWeight().doubleValue())
                .weight(getWeight().doubleValue())
                .totalTareWeight(getTotalTare().doubleValue())
                .packageTareWeight(getPackagingTare().doubleValue())
                .isFixedWeightProduct(sourceProduct.isFixedWeight())
                .portionRoomCode(portionRoom.getCode())
                .workingDate(portionRoom.getLastOpenedAt().toLocalDate())
                .packoffStationName(packoffStationName)
                .userId("2")
                .incomplete(incomplete)
                .build();
    }

    public boolean isForProductionOrder() {
        return targetProductionOrder != null;
    }

    void relabel() {
        relabel = true;
    }

    boolean isWipBox() {
        return incomplete;
    }

    boolean isReserved() {
        return status == RESERVED;
    }

    public boolean isCustomerOrder() {
        final CustomerOrder customerOrder = (targetProductionOrder != null)
                ? targetProductionOrder.getCustomerOrder() : null;
        return customerOrder != null;
    }

    public boolean isPar() {
        return targetProductionOrder != null && targetProductionOrder.getCustomerOrder() == null;
    }

    public boolean isStock() {
        return targetProductionOrder == null && !incomplete;
    }

    Optional<Box> reserve(final PortionRoom room) {
        if (status != AVAILABLE) {
            return Optional.empty();
        }

        final Box reservedBox = this.toBuilder()
                .status(RESERVED)
                .reservedForPortionRoom(room)
                .build();
        reservedBox.setId(getId());
        reservedBox.setCreatedAt(getCreatedAt());
        return Optional.of(reservedBox);
    }

    private CustomerOrder getCustomerOrderIfExists() {
        if (!isForProductionOrder() || null == targetProductionOrder.getCustomerOrder()) {
            return null;
        }

        return CustomerOrder
                .builder()
                .orderNumber(targetProductionOrder.getCustomerOrder().getOrderNumber())
                .orderDate(targetProductionOrder.getCustomerOrder().getOrderDate())
                .customer(targetProductionOrder.getCustomerOrder().getCustomer())
                .name(targetProductionOrder.getCustomerOrder().getName())
                .shipDate(targetProductionOrder.getCustomerOrder().getShipDate())
                .build();
    }

    void returnWip() {
        if (isReserved()) {
            status = AVAILABLE;
            reservedForPortionRoom = null;
        }
    }

    public String getBoxSerialNumber() {
        if (null == getId()) {
            return null;
        } else {
            final long boxSerialNumber = getId() % 100_000_000;
            return String.format("%08d", boxSerialNumber);
        }
    }

    public Integer getOverrideWeightRangeReasonCode() {
        if (null == weighings || weighings.isEmpty()) {
            return null;
        }
        return weighings.get(0).getOverrideWeightRangeReasonCode();
    }

    private boolean isRetailFullBox() {
        return isRetail() && (isPiecesPerCaseLimitReached() || isRetailPackedForStockOrWip());
    }

    private boolean isRetailPackedForStockOrWip() {
        return weighings.size() == 1 && weighings.get(0).getType() == WeighingType.BOX;
    }

    boolean isPiecesPerCaseLimitReached() {
        return weighings.size() == itemProduct.getPiecesPerCase();
    }

    boolean isNonRetailFullBox() {
        return !isRetail() && weighings.size() == 1;
    }

    boolean isRetail() {
        return itemProduct.isRetail();
    }

    boolean isFullBox() {
        return isRetailFullBox() || isNonRetailFullBox();
    }

    public String getProductCode() {
        return itemProduct.getCode();
    }

    public Weighing getLatestWeighing() {
        List<Weighing> nonSaved = weighings.stream()
                .filter(weighing -> weighing.getId() == null)
                .collect(Collectors.toList());

        //Solution put in place incase the latest weighing for the box is saved and has an id.  If the caller uses
        // Async annotation, it may result in the box here to either have an id or be null.
        return nonSaved.size() == 1 ? nonSaved.get(0) :
                weighings.size() > 0 ? weighings.stream().max(Comparator.comparing(Weighing::getId)).get() : null;
    }

    @Override
    public boolean equals(final Object other) {
        if (this == other) {
            return true;
        }
        if (other == null || getClass() != other.getClass()) {
            return false;
        }
        final Box box = (Box) other;
        return relabel == box.relabel
                && incomplete == box.incomplete
                && Objects.equals(version, box.version)
                && Objects.equals(sourceCutOrderId, box.sourceCutOrderId)
                && Objects.equals(targetProductionOrder, box.targetProductionOrder)
                && Objects.equals(consumedDate, box.consumedDate)
                && Objects.equals(itemProduct, box.itemProduct)
                && status == box.status
                && Objects.equals(packoffStationName, box.packoffStationName)
                && Objects.equals(reservedForPortionRoom, box.reservedForPortionRoom)
                && Objects.equals(barcode, box.barcode)
                && Objects.equals(
                weighings == null ? null : new ArrayList<>(weighings),
                box.weighings == null ? null : new ArrayList<>(box.weighings));
    }

    @Override
    public int hashCode() {
        return Objects.hash(version, sourceCutOrderId, targetProductionOrder, consumedDate, itemProduct,
                status, packoffStationName, relabel, incomplete,
                reservedForPortionRoom, barcode, weighings);
    }

    public enum Status {
        AVAILABLE, ASSIGNED, RESERVED, IN_PORTION_ROOM
    }
}
