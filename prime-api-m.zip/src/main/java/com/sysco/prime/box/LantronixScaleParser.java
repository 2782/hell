package com.sysco.prime.box;

import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;
import org.xml.sax.InputSource;

import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;
import java.io.ByteArrayInputStream;
import java.nio.charset.Charset;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Stream;

import static java.lang.String.format;
import static java.util.regex.Pattern.MULTILINE;
import static java.util.stream.Collectors.joining;
import static org.springframework.http.MediaType.APPLICATION_FORM_URLENCODED;

@Service
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
@Profile("realscale")
public class LantronixScaleParser implements ScaleParser {
    private static final Pattern SPACE = Pattern.compile(" ");
    private static final Pattern NET_WEIGHT_PATTERN = Pattern.compile("^.*Net\\s+(-?\\d+\\.\\d+)\\s+lb.*$", MULTILINE);

    private final RestTemplate restTemplate;

    @Override
    public String readWeightFromScale() {
        final HttpHeaders headers = new HttpHeaders();
        headers.setContentType(APPLICATION_FORM_URLENCODED);
        headers.set("Authorization", "Basic YWRtaW46UEFTUw==");
        final MultiValueMap<String, String> map = new LinkedMultiValueMap<>();
        map.add("group", "Line");
        map.add("optionalGroupInstance", "1");
        map.add("action", "Command n=500 m=1000 0A050d");
        final HttpEntity<MultiValueMap<String, String>> request = new HttpEntity<>(map, headers);
        final String scaleEndpoint = "http://prime-dev-scale1.na.sysco.net/action/status";
        final String response = restTemplate.postForObject(scaleEndpoint, request, String.class);

        if (null == response) {
            throw new ScaleException(format("This Lantronix scale is unreadable: No response from %s.", scaleEndpoint));
        }

        final XPathFactory xPathFactory = XPathFactory.newInstance();
        final XPath xPath = xPathFactory.newXPath();

        try {
            final XPathExpression xPathExpression = xPath.compile("/function/return/message/text()");
            final String spacedHexData = xPathExpression.evaluate(
                    new InputSource(new ByteArrayInputStream(response.getBytes(Charset.forName("UTF-8")))));
            final String asAscii = Stream.of(SPACE.split(spacedHexData))
                    .map(s -> (char) Integer.parseInt(s, 16))
                    .map(String::valueOf)
                    .collect(joining());

            final Matcher matcher = NET_WEIGHT_PATTERN.matcher(asAscii);
            if (matcher.find()) {
                final String netWeight = matcher.group(1);
                return Double.valueOf(netWeight) + "lb";
            }
        } catch (final XPathExpressionException e) {
            throw new ScaleException(
                    format("This Lantronix scale is unreadable: %s: %s (%s)",
                            scaleEndpoint, e.getMessage(), e.getClass().getName()), e);
        }

        throw new ScaleException(
                "This Lantronix scale is turned off, not on the network, not set to measure in pounds, or is"
                        + " broken, or you are not on the Sysco internal network or the VPN: " + scaleEndpoint);
    }
}
