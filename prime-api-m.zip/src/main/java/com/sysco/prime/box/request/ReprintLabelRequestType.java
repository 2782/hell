package com.sysco.prime.box.request;

public enum ReprintLabelRequestType {
    BOTH,
    RETAIL,
    BOX
}
