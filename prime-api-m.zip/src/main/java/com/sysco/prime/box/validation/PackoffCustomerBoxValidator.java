package com.sysco.prime.box.validation;

import com.sysco.prime.box.request.CustomerBoxRequest;
import com.sysco.prime.box.request.WeighingRequest;
import com.sysco.prime.product.Product;
import com.sysco.prime.product.ProductService;
import com.sysco.prime.product.validation.PrimeConstraintValidator;
import com.sysco.prime.productionOrder.ProductionOrder;
import com.sysco.prime.productionOrder.ProductionOrderService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;

import javax.validation.ConstraintValidatorContext;

import java.math.BigDecimal;

import static com.sysco.prime.productionOrder.ProductionOrderStatus.TO_GRIND;
import static com.sysco.prime.productionOrder.ProductionOrderStatus.TO_PACK;
import static com.sysco.prime.validation.ValidationErrorType.ALREADY_PACKED;
import static com.sysco.prime.validation.ValidationErrorType.BELOW_MIN_VALUE;
import static com.sysco.prime.validation.ValidationErrorType.OUT_OF_RANGE;
import static java.util.Objects.isNull;

@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class PackoffCustomerBoxValidator
        implements PrimeConstraintValidator<PackoffCustomerBox, CustomerBoxRequest> {

    private final ProductService productService;
    private final ProductionOrderService productionOrderService;

    @Override
    public boolean isValid(final CustomerBoxRequest boxRequest, final ConstraintValidatorContext context) {
        for (WeighingRequest weighing : boxRequest.getWeighings()) {
            if (weighing.getId() != null) {
                continue;
            }
            if (weighing.getWeight() == null || weighing.getRetailPieceTare() == null) {
                return true;
            }

            final Product product = productService.findByCode(boxRequest.getProductCode());

            final BigDecimal weight = weighing.getWeight();
            final BigDecimal tare = product.isRetail() ? weighing.getRetailPieceTare() : boxRequest.getPackagingTare();
            final BigDecimal netWeight = weight.subtract(tare);

            if (netWeight.compareTo(BigDecimal.ZERO) < 0) {
                return validationFailedBecause(context, OUT_OF_RANGE);
            }

            if (isNull(weighing.getOverrideWeightRangeReasonCode())) {
                final BigDecimal minWeightForValidation = product.isRetail() ? product.getRetailMinWeight() :
                        product.getMinWeight();
                final BigDecimal maxWeightForValidation = product.isRetail() ? product.getRetailMaxWeight() :
                        product.getMaxWeight();

                if (product.isCatchWeight()) {
                    if (netWeight.compareTo(minWeightForValidation) < 0
                            || netWeight.compareTo(maxWeightForValidation) > 0) {
                        return validationFailedBecause(context, OUT_OF_RANGE);
                    }
                }

                if (product.isFixedWeight()) {
                    if (netWeight.compareTo(minWeightForValidation) < 0) {
                        return validationFailedBecause(context, BELOW_MIN_VALUE);
                    }
                }
            }
        }

        final ProductionOrder productionOrder = productionOrderService.findById(
                boxRequest.getProductionOrderId());
        return TO_PACK.equals(productionOrder.getStatus())
                || TO_GRIND.equals(productionOrder.getStatus())
                || validationFailedBecause(context, ALREADY_PACKED);

    }
}
