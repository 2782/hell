package com.sysco.prime.box;

import lombok.Builder;
import lombok.Data;

import java.math.BigDecimal;

@Data
@Builder
public class WeighingResponse {
    private Long id;
    
    private BigDecimal weight;
    private BigDecimal retailPieceTare;
    private Integer overrideWeightRangeReasonCode;
    private WeighingType type;

    public static WeighingResponse from(final Weighing weighing) {
        return builder()
                .id(weighing.getId())
                .weight(weighing.getWeight())
                // TODO: Change this response field name?
                .retailPieceTare(weighing.getRetailPieceTare())
                .overrideWeightRangeReasonCode(weighing.getOverrideWeightRangeReasonCode())
                .type(weighing.getType())
                .build();
    }
}
