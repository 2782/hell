package com.sysco.prime.box.request;

import com.sysco.prime.box.Weighing;
import com.sysco.prime.box.WeighingType;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

import javax.validation.constraints.NotNull;
import java.math.BigDecimal;

@Data
@RequiredArgsConstructor
@Builder
public class WeighingRequest {
    private final Long id;
    @NotNull
    private final BigDecimal weight;
    @NotNull
    private final BigDecimal retailPieceTare;
    private final Integer overrideWeightRangeReasonCode;
    @NotNull
    private final WeighingType type;

    public Weighing toDomain() {
        final Weighing weighing = Weighing.builder()
                .overrideWeightRangeReasonCode(overrideWeightRangeReasonCode)
                .weight(weight)
                .retailPieceTare(type == WeighingType.RETAIL_PIECE ? retailPieceTare : BigDecimal.ZERO)
                .type(type)
                .build();
        weighing.setId(id);
        return weighing;
    }
}