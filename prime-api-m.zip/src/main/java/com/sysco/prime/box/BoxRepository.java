package com.sysco.prime.box;

import com.sysco.prime.PrimeRepository;
import com.sysco.prime.box.Box.Status;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

public interface BoxRepository extends PrimeRepository<Box> {
    List<Box> findBySourceCutOrderIdInAndItemProductCode(List<Long> productionOrderIds, String productCode);

    List<Box> findByConsumedDateAndItemProductCode(LocalDate consumedDate, String productCode);

    List<Box> findByIncompleteIsTrue();

    List<Box> findByStatusAndIncompleteIsTrueAndItemProductCode(Status status, String productCode);

    List<Box> findByReservedForPortionRoomCodeAndStatusAndIncompleteIsTrue(String roomCode, Status status);

    Optional<Box> findByBarcodeAndIncompleteIsTrue(String barcode);

    List<Box> findBySourceCutOrderIdOrderByCreatedAtDesc(Long id);
}
