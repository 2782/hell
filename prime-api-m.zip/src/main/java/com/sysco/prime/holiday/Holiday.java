package com.sysco.prime.holiday;

import com.sysco.prime.shared.model.TransactionalEntity;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import javax.persistence.Entity;
import javax.validation.constraints.NotNull;
import java.time.LocalDate;

@AllArgsConstructor
@Data
@Builder(toBuilder = true)
@Entity
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
public class Holiday extends TransactionalEntity {
    @NotNull
    private LocalDate date;
    @NotNull
    private String description;

    public void updateHoliday(final Holiday holiday) {
        date = holiday.getDate();
        description = holiday.getDescription();
    }
}
