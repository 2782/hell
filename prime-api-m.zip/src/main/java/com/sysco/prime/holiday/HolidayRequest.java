package com.sysco.prime.holiday;

import com.sysco.prime.exception.InvalidValueException;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

import javax.validation.constraints.NotNull;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;

import static com.sysco.prime.validation.ValidationError.buildError;
import static com.sysco.prime.validation.ValidationErrorType.INVALID;

@Builder(toBuilder = true)
@Data
@RequiredArgsConstructor
public class HolidayRequest {
    @NotNull
    private final String date; // Let controller decode so we can throw our own exception type
    @NotNull
    private final String description;

    public Holiday toDomain() {
        try {
            return Holiday.builder()
                    .date(LocalDate.parse(date))
                    .description(description)
                    .build();
        } catch (final DateTimeParseException e) {
            throw new InvalidValueException(e.getMessage(),
                    buildError("date", INVALID, "unparseable"));
        }
    }
}
