package com.sysco.prime.purchaseOrder;

import com.sysco.prime.box.Box;
import com.sysco.prime.cost.Cost;
import com.sysco.prime.cost.CostService;
import com.sysco.prime.cost.Money;
import com.sysco.prime.customerOrder.CustomerOrder;
import com.sysco.prime.customerOrder.LineItemService;
import com.sysco.prime.portionRoom.PortionRoom;
import com.sysco.prime.portionRoom.PortionRoomService;
import com.sysco.prime.product.Product;
import com.sysco.prime.product.ProductService;
import com.sysco.prime.productionOrder.ProductionOrder;
import com.sysco.prime.productionOrder.ProductionOrderService;
import com.sysco.prime.profile.Profile;
import com.sysco.prime.profile.ProfileService;
import com.sysco.prime.sus.client.SusClient;
import com.sysco.prime.sus.model.SusPurchaseOrderResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

import java.time.Clock;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static com.sysco.prime.productionOrder.ProductionOrderStatus.PACKED;
import static com.sysco.prime.purchaseOrder.PurchaseOrder.fromPackOffByProductAsStock;
import static java.time.LocalDate.now;
import static java.util.Objects.isNull;
import static java.util.stream.Collectors.toList;

@Service
@Slf4j
public class PurchaseOrderService {
    private final SusClient susClient;
    private final ProfileService profileService;
    private final LineItemService lineItemService;
    private final ProductionOrderPricer pricer;
    private final PurchaseOrderRepository purchaseOrderRepository;
    private final CostService costService;
    private final ProductService productService;
    private final ProductionOrderService productionOrderService;
    private final PortionRoomService portionRoomService;
    private final PurchaseLineItemCaseService purchaseLineItemCaseService;
    private final Clock when;

    public PurchaseOrderService(
            @Lazy final SusClient susClient,
            final ProfileService profileService,
            final LineItemService lineItemService,
            @Lazy final ProductionOrderPricer pricer,
            final PurchaseOrderRepository purchaseOrderRepository,
            final CostService costService,
            @Lazy final ProductService productService,
            @Lazy final ProductionOrderService productionOrderService,
            @Lazy final PortionRoomService portionRoomService,
            final PurchaseLineItemCaseService purchaseLineItemCaseService,
            final Clock when) {
        this.susClient = susClient;
        this.profileService = profileService;
        this.lineItemService = lineItemService;
        this.pricer = pricer;
        this.purchaseOrderRepository = purchaseOrderRepository;
        this.costService = costService;
        this.productService = productService;
        this.productionOrderService = productionOrderService;
        this.portionRoomService = portionRoomService;
        this.purchaseLineItemCaseService = purchaseLineItemCaseService;
        this.when = when;
    }

    public void updatePoNumberFromPurchaseOrder(final SusPurchaseOrderResponse data) {
        // TODO: This is not realistic -- we'd always have a req# when the processor runs
        purchaseOrderRepository.findByRequestNumber(data.getRequestNumber())
                .ifPresent(order -> {
                    assignPoNumberToPurchaseOrder(order, data);
                    updateStatusForUntrackedPurchaseLineItems(order);
                });
    }

    private void updateStatusForUntrackedPurchaseLineItems(final PurchaseOrder order) {
        final Profile profile = profileService.get();

        updateUntrackedLineItems(order, profile);
    }

    void assignPoNumberToPurchaseOrder(final PurchaseOrder order,
                                       final SusPurchaseOrderResponse data) {
        order.setSusPoNumber(data.getPurchaseOrderNumber());
        order.withSusLineItem(data, this::sendReceiptToSusForItem);
        purchaseOrderRepository.save(order);
    }

    public PurchaseOrder createPurchaseOrderForHousePar(
            final List<ProductionOrder> productionOrders,
            final String roomCode) {
        final Profile profile = profileService.get();
        PurchaseOrder order = PurchaseOrder.fromOrderListAndRoom(
                profile, roomCode, productionOrders, pricer, now(when));
        order = purchaseOrderRepository.save(order);
        return purchaseOrderRepository.save(sendToSus(order));
    }

    public PurchaseOrder createOrUpdatePurchaseOrderFromCustomerOrder(
            final CustomerOrder customerOrder,
            final List<ProductionOrder> productionOrderList) {
        final Profile profile = profileService.get();
        final Optional<PurchaseOrder> found =
                purchaseOrderRepository.findBySalesOrderNumber(customerOrder.getOrderNumber());

        PurchaseOrder existingPurchaseOrder = found.orElse(null);

        PurchaseOrder purchaseOrder = PurchaseOrder.fromCustomerOrder(existingPurchaseOrder,
                customerOrder, profile, productionOrderList, pricer, now(when));

        if (null != existingPurchaseOrder) {

            purchaseOrder = purchaseOrderRepository.saveAndFlush(purchaseOrder);

            if (existingPurchaseOrder.isCreatedInSus()) {
                purchaseOrder = updateUntrackedLineItems(purchaseOrder, profile);
            }

            return purchaseOrder;
        } else {
            purchaseOrder = purchaseOrderRepository.save(purchaseOrder);
            purchaseOrder = sendToSus(purchaseOrder);
            return purchaseOrderRepository.save(purchaseOrder);
        }
    }

    private PurchaseOrder updateUntrackedLineItems(PurchaseOrder purchaseOrder, final Profile profile) {
        susClient.updatePurchaseOrder(purchaseOrder, profile);
        purchaseOrder.setNewLineItemsAsPending();
        purchaseOrder = purchaseOrderRepository.saveAndFlush(purchaseOrder);

        return purchaseOrder;
    }

    private PurchaseOrder sendToSus(final PurchaseOrder order) {
        final String requestNumber = susClient.sendPurchaseOrder(order, profileService.get());
        return order
                .withSusRequestNumber(requestNumber)
                .setNewLineItemsAsPending();
    }

    PurchaseOrder findByProductionOrder(final ProductionOrder productionOrder) {
        PurchaseOrder order = getExistingPurchaseOrderFor(productionOrder);
        if (isNull(order)) {
            //Todo should create PO for it??
            log.error("Could got find existing purchase order for production order: \n{}", productionOrder);
            throw new RuntimeException();
        } else {
            return order;
        }
    }

    void updatePurchaseOrderWithNewPackBoxForCustomerOrder(
            final ProductionOrder productionOrder,
            final Box box) {
        PurchaseOrder order = findByProductionOrder(productionOrder);
        order.complete(isCustomerOrderCompleted(productionOrder));

        order.getLineItemFor(box).add(box.toPurchaseLineItemCase());

        order = purchaseOrderRepository.save(order);

        if (order.isCreatedInSus()) {
            order = sendReceiptToSusForOrder(order, box);
            purchaseOrderRepository.save(order);
        }
    }

    public void updatePurchaseOrderLineItemWithOrderQuantityPacked(final ProductionOrder productionOrder) {
        PurchaseOrder purchaseOrder = findByProductionOrder(productionOrder);
        purchaseOrder.complete(isCustomerOrderCompleted(productionOrder));

        final PurchaseLineItem lineItemFor = purchaseOrder.getLineItemFor(productionOrder.getProduct());
        lineItemFor.updateQuantityToProduce(productionOrder.getQtyPacked());

        purchaseOrder = purchaseOrderRepository.save(purchaseOrder);

        if (purchaseOrder.isCreatedInSus()) {
            susClient.updatePurchaseOrder(purchaseOrder, profileService.get());
        }
    }

    private PurchaseOrder getExistingPurchaseOrderFor(final ProductionOrder cutOrder) {
        return purchaseOrderRepository.findBySalesOrderNumber(cutOrder.getCustomerOrder()
                .getOrderNumber())
                .orElse(null);
    }

    void createOrUpdateGenericPurchaseOrderWithNewBox(
            final String roomCode, final Box box) {
        final PortionRoom portionRoom = portionRoomService.getPortionRoomByCode(roomCode);
        final LocalDate orderDate = portionRoom.getLastOpenedAt().toLocalDate();
        final Optional<PurchaseOrder> existingOrder = purchaseOrderRepository
                .findTopByOrderDateAndRoomCodeOrderByCreatedAtDesc(orderDate, portionRoom.getCode());

        final Profile profile = profileService.get();

        if (!existingOrder.isPresent()) {
            PurchaseOrder order = fromPackOffByProductAsStock(roomCode, profile, now(when), orderDate);
            final Cost cost = costService.findCost(box.getItemProduct());
            order.add(PurchaseLineItem.fromPackOffByProductAsStock(box, cost));
            order.updateGenericOrderShipDateToLatestPackedCase();
            order = purchaseOrderRepository.save(order);
            purchaseOrderRepository.save(sendToSus(order));
            return;
        }

        PurchaseOrder order = existingOrder.get();

        final PurchaseLineItem lineItem = order.getOrAddLineItemForProduct(box.getProductCode());
        final PurchaseLineItemCase itemCase = box.toPurchaseLineItemCase();
        lineItem.add(itemCase);
        lineItem.increaseQuantity();
        order.updateGenericOrderShipDateToLatestPackedCase();

        updateCosts(order);
        order.complete(false);

        order = purchaseOrderRepository.save(order);

        if (order.isCreatedInSus()) {
            susClient.updatePurchaseOrder(order, profileService.get());
            order.setNewLineItemsAsPending();

            order = sendReceiptToSusForOrder(order, box);

            purchaseOrderRepository.save(order);
        }
    }

    private PurchaseOrder sendReceiptToSusForOrder(final PurchaseOrder order, final Box box) {
        final PurchaseLineItem lineItem = order.getLineItemFor(box);
        final PurchaseLineItemCase latestCase = lineItem.getLatestCase();

        final Long requestNumberForCase = sendReceiptToSusForItem(lineItem);

        latestCase.withRequestNumber(requestNumberForCase);
        return order;
    }

    private void updateCosts(final PurchaseOrder order) {
        order.getLineItems().forEach(item -> {
            final Product itemProduct = productService.findByCode(item.getProductCode());
            final Cost lineItemCost = costService.findCost(itemProduct);
            item.setCost(lineItemCost.getMarketCost());
        });
    }

    Long sendReceiptToSusForItem(final PurchaseLineItem lineItem) {
        if (null == lineItem.getSusLineItem()
                || lineItem.getLineItemCases().isEmpty()) {
            return null;
        }

        return susClient.sendPurchaseOrderReceipt(lineItem);
    }

    public void createOrUpdatePurchaseOrderWithNewPackBox(final Box box, final String roomCode) {
        if (!box.isForProductionOrder()) {
            createOrUpdateGenericPurchaseOrderWithNewBox(roomCode, box);
            return;
        }

        final Long productionOrderId = box.getSourceCutOrderId();
        final ProductionOrder productionOrder = productionOrderService.findById(productionOrderId);

        if (productionOrder.isLineItemType()) {
            updatePurchaseOrderWithNewPackBoxForCustomerOrder(productionOrder, box);
        } else if (productionOrder.isHouseParType()) {
            createOrUpdateGenericPurchaseOrderWithNewBox(roomCode, box);
        }
    }

    private boolean isCustomerOrderCompleted(final ProductionOrder productionOrder) {
        return productionOrder.getStatus() == PACKED
                && lineItemService.isAllLineItemsComplete(productionOrder.getCustomerOrder().getLineItems());
    }

    public boolean isAllPurchaseOrderCreatedInSus(final PortionRoom portionRoom) {
        final List<PurchaseOrder> allPurchaseOrders = getAllPurchaseOrdersForCurrentWorkingDay(portionRoom);

        return allPurchaseOrders.stream().allMatch(PurchaseOrder::isCreatedInSus);
    }

    public boolean isAllPurchaseOrderProcessed(final PortionRoom portionRoom) {
        final List<PurchaseOrder> allPurchaseOrders = getAllPurchaseOrdersForCurrentWorkingDay(portionRoom);

        return allPurchaseOrders.stream().allMatch(PurchaseOrder::isProcessed);
    }

    public boolean isAllLineItemReceiptProcessed(final PortionRoom portionRoom) {
        final List<PurchaseOrder> allPurchaseOrders = getAllPurchaseOrdersForCurrentWorkingDay(portionRoom);

        final List<PurchaseLineItem> purchaseLineItemsForClosedRoom = allPurchaseOrders.stream()
                .flatMap(purchaseOrder -> purchaseOrder.getLineItems().stream())
                .filter(purchaseLineItem ->
                        portionRoom.getCode().equals(
                                productService.findByCode(purchaseLineItem.getProductCode())
                                        .getPortionRoomCode()))
                .collect(toList());

        final List<PurchaseLineItemCase> purchaseLineItemCasesForClosedRoom = purchaseLineItemsForClosedRoom.stream()
                .flatMap(purchaseLineItem -> purchaseLineItem.getLineItemCases().stream())
                .collect(toList());

        return purchaseLineItemCasesForClosedRoom.stream().allMatch(PurchaseLineItemCase::isProcessed);
    }

    private List<PurchaseOrder> getAllPurchaseOrdersForCurrentWorkingDay(final PortionRoom portionRoom) {
        final List<ProductionOrder> productionOrdersCreatedAtWorkingDay =
                productionOrderService.getAllProductionOrdersCreatedAtWorkingDay(portionRoom);
        final List<Long> customerOrderIds = productionOrdersCreatedAtWorkingDay.stream()
                .filter(productionOrder -> productionOrder.getCustomerOrder() != null)
                .map(cutItem -> cutItem.getCustomerOrder().getId())
                .collect(toList());
        final LocalDate orderDate = portionRoom.getLastOpenedAt().toLocalDate();
        final List<PurchaseOrder> allPurchaseOrders = new ArrayList<>();

        if (!customerOrderIds.isEmpty()) {
            allPurchaseOrders.addAll(purchaseOrderRepository.findByCustomerOrderIdIn(customerOrderIds));
        }

        allPurchaseOrders.addAll(purchaseOrderRepository.findByOrderDateAndRoomCode(orderDate, portionRoom.getCode()));

        return allPurchaseOrders;
    }

    public void sync() {
        final List<PortionRoom> allPortionRooms = portionRoomService.getAllPortionRooms();
        final List<PortionRoom> openedPortionRooms = allPortionRooms.stream()
                .filter(PortionRoom::isOpened)
                .collect(toList());

        if (openedPortionRooms.size() > 0) {
            log.info("Start sync unsuccessful purchase orders...");

            syncUnsuccessfulPurchaseOrder(allPortionRooms);
            syncUnsuccessfulReceipts(openedPortionRooms);

            log.info("Purchase orders info updated.");
        }
    }

    private void syncUnsuccessfulReceipts(final List<PortionRoom> openedPortionRooms) {
        openedPortionRooms.forEach(portionRoom -> {
            final LocalDate openDate = portionRoom.getLastOpenedAt().toLocalDate();
            final List<PurchaseLineItemCase> lineItemCases =
                    purchaseLineItemCaseService.findLineItemCasesForCurrentWorkingDay(openDate);
            final List<PurchaseLineItemCase> purchaseLineItemCases = lineItemCases.stream().filter(lineItemCase -> {
                if (lineItemCase.getRequestNumber() != null) {
                    return false;
                }

                final String portionRoomCode = productService
                        .findByCode(lineItemCase.getPurchaseLineItem().getProductCode()).getPortionRoomCode();
                return portionRoomCode.equals(portionRoom.getCode());
            }).collect(toList());

            purchaseLineItemCases.forEach(lineItemCase ->
                    sendReceiptToSusAndUpdateCases(lineItemCase.getPurchaseLineItem()));
        });
    }

    private void sendReceiptToSusAndUpdateCases(final PurchaseLineItem lineItem) {
        final List<PurchaseLineItemCase> unsyncLineItemCases = lineItem.getLineItemCases().stream()
                .filter(lineItemCase -> lineItemCase.getRequestNumber() == null)
                .collect(toList());

        final PurchaseLineItem purchaseLineItem = lineItem.toBuilder().build();
        purchaseLineItem.addTo(lineItem.getPurchaseOrder());
        purchaseLineItem.overrideLineItemCases(unsyncLineItemCases);

        final Long requestNumber = sendReceiptToSusForItem(purchaseLineItem);
        if (requestNumber != null) {
            unsyncLineItemCases.forEach(purchaseLineItemCase -> {
                purchaseLineItemCase.setRequestNumber(requestNumber);

                purchaseLineItemCaseService.save(purchaseLineItemCase);
            });
        }
    }

    private void syncUnsuccessfulPurchaseOrder(final List<PortionRoom> allPortionRooms) {
        allPortionRooms.forEach(portionRoom -> {
            final OffsetDateTime lastOpenedAt = portionRoom.getLastOpenedAt();
            if (lastOpenedAt != null) {
                final LocalDate orderDate = lastOpenedAt.toLocalDate();
                final List<PurchaseOrder> unsyncPurchaseOrders =
                        purchaseOrderRepository.findByOrderDateAndRequestNumberIsNull(orderDate);

                unsyncPurchaseOrders.forEach(order -> {
                    order.getLineItems().forEach(purchaseLineItem -> {
                        final Product product = productService.findByCode(purchaseLineItem.getProductCode());
                        final Cost cost = costService.findCost(product);
                        if (null == cost) {
                            log.error("Purchase order for product {} with no costs", product.getCostName());
                            purchaseLineItem.setCost(Money.zero());
                        } else {
                            purchaseLineItem.setCost(cost.getMarketCost());
                        }
                    });

                    purchaseOrderRepository.save(sendToSus(order));
                });
            }
        });
    }

    public String getPoNumberById(Long purchaseOrderId) {
        Optional<PurchaseOrder> purchaseOrder = purchaseOrderRepository.findById(purchaseOrderId);
        if (purchaseOrder.isPresent()) {
            return purchaseOrder.get().getPoNumber();
        }
        return null;
    }
}
