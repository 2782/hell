package com.sysco.prime.purchaseOrder;

import com.sysco.prime.PrimeRepository;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

public interface PurchaseOrderRepository extends PrimeRepository<PurchaseOrder> {
    Optional<PurchaseOrder> findBySalesOrderNumber(String salesOrderNumber);

    Optional<PurchaseOrder> findTopByRoomCodeOrderByCreatedAtDesc(String roomCode);

    Optional<PurchaseOrder> findByRequestNumber(String requestNumber);

    List<PurchaseOrder> findByCustomerOrderIdIn(final List<Long> customerOrderIds);

    List<PurchaseOrder> findByOrderDateAndRoomCode(final LocalDate orderDate, final String roomCode);

    Optional<PurchaseOrder> findTopByOrderDateAndRoomCodeOrderByCreatedAtDesc(final LocalDate orderDate, final String roomCode);

    List<PurchaseOrder> findByOrderDateAndRequestNumberIsNull(final LocalDate orderDate);
}
