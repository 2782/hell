package com.sysco.prime.purchaseOrder;

public final class PurchaseOrderException extends RuntimeException {
    public PurchaseOrderException(final String message) {
        super(message);
    }
}
