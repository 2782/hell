package com.sysco.prime.purchaseOrder;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.sysco.prime.box.Box;
import com.sysco.prime.cost.Cost;
import com.sysco.prime.productionOrder.ProductionOrder;
import com.sysco.prime.shared.model.TransactionalEntity;
import com.sysco.prime.sus.model.PurchaseOrderItem;
import com.sysco.prime.sus.model.SusPurchaseOrderResponse;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.extern.slf4j.Slf4j;

import javax.persistence.Entity;
import javax.persistence.Enumerated;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OrderBy;
import javax.persistence.Transient;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.function.Function;

import static com.sysco.prime.purchaseOrder.PurchaseLineItem.PurchaseLineItemStatus.CREATED;
import static com.sysco.prime.purchaseOrder.PurchaseLineItem.PurchaseLineItemStatus.PENDING;
import static java.util.Collections.singletonList;
import static java.util.Collections.unmodifiableList;
import static javax.persistence.CascadeType.ALL;
import static javax.persistence.EnumType.STRING;
import static javax.persistence.FetchType.EAGER;

@AllArgsConstructor
@Entity
@Getter
@NoArgsConstructor
@Slf4j
@ToString(callSuper = true, exclude = "purchaseOrder")
public class PurchaseLineItem extends TransactionalEntity {
    private int lineItemId;
    private Integer susLineItem;
    private String productCode;

    @SuppressWarnings("FieldMayBeFinal")
    @OneToMany(mappedBy = "purchaseLineItem", cascade = ALL, fetch = EAGER, orphanRemoval = true)
    @JsonIgnore
    @OrderBy
    private Set<PurchaseLineItemCase> lineItemCases = new LinkedHashSet<>();

    @ManyToOne(fetch = EAGER, cascade = ALL, optional = false)
    @JoinColumn(name = "purchaseOrderId")
    private PurchaseOrder purchaseOrder;

    private int quantityToProduce;

    @Transient
    private BigDecimal cost;
    @Enumerated(STRING)
    private PurchaseLineItemStatus status;

    @Builder(toBuilder = true)
    public PurchaseLineItem(
            final int lineItemId,
            final Integer susLineItem,
            final String productCode,
            final int quantityToProduce,
            final PurchaseLineItemStatus status,
            final BigDecimal cost) {
        this.lineItemId = lineItemId;
        this.susLineItem = susLineItem;
        this.productCode = productCode;
        this.quantityToProduce = quantityToProduce;
        this.status = status;
        this.cost = cost;
    }

    static PurchaseLineItem fromCutOrder(
            final ProductionOrder order, final int itemNumber, final BigDecimal cost) {
        return PurchaseLineItem.builder()
                .lineItemId(itemNumber)
                .productCode(order.getProduct().getCode())
                .quantityToProduce(order.getQtyToProduceInCases())
                .cost(cost)
                .build();
    }

    // TODO: Use a Clock for `now(clock)` for testability
    static PurchaseLineItem fromPackOffByProductAsStock(
            final Box box, final Cost cost) {
        final List<PurchaseLineItemCase> lineItemCases = singletonList(PurchaseLineItemCase.builder()
                .packDate(LocalDate.now())
                .weight(box.getWeight().floatValue())
                .build());

        return PurchaseLineItem.builder()
                .productCode(box.getProductCode())
                .cost(cost.getMarketCost())
                .quantityToProduce(1)
                .build()
                .addAll(lineItemCases);
    }

    public static boolean isNotPending(final PurchaseLineItem purchaseLineItem) {
        return purchaseLineItem.status != PENDING;
    }

    public List<PurchaseLineItemCase> getLineItemCases() {
        return unmodifiableList(new ArrayList<>(lineItemCases));
    }

    void overrideLineItemCases(final List<PurchaseLineItemCase> cases) {
        lineItemCases.clear();
        cases.forEach(this::add);
    }

    /**
     * <strong>Assumption</strong>: SUS only sends
     * <var>poLineSequenceNumber</var> <em>once</em> per line item.
     */
    void updateWithSusLineItem(
            final SusPurchaseOrderResponse susData, final Function<PurchaseLineItem, Long> onUpdate) {
        final String productCode = getProductCode();
        for (final PurchaseOrderItem orderItem : susData.getDetail()) {
            if (productCode.equals(orderItem.getItemNumber())) {
                if (null != susLineItem) {
                    // TODO: Better formatting to be greppable in log files
                    log.error("SUS acknowledged the same line item twice, "
                            + "ignoring:\n{}\n{}", this, susData);
                    break;
                }
                susLineItem = orderItem.getPoLineSequenceNumber();
                status = CREATED;
                this.setSusRequestNumber(onUpdate.apply(this));
                break;
            }
        }
    }

    public void updateQuantityToProduce(final Integer updateQuantity) {
        quantityToProduce = updateQuantity;
    }

    void addTo(final PurchaseOrder order) {
        purchaseOrder = order;
    }

    public PurchaseLineItem add(final PurchaseLineItemCase lineItemCase) {
        lineItemCases.add(lineItemCase);
        lineItemCase.addTo(this);
        return this;
    }

    public void increaseQuantity() {
        quantityToProduce += 1;
    }

    public PurchaseLineItem addAll(final Collection<PurchaseLineItemCase> lineItemCases) {
        lineItemCases.forEach(this::add);
        return this;
    }

    public void setCost(final BigDecimal cost) {
        this.cost = cost;
    }

    private void setSusRequestNumber(final Long susRequestNumber) {
        lineItemCases.forEach(lineItemCase -> lineItemCase.withRequestNumber(susRequestNumber));
    }

    PurchaseLineItemCase getLatestCase() {
        final List<PurchaseLineItemCase> cases = getLineItemCases();
        return cases.isEmpty()
                ? null
                : cases.get(cases.size() - 1);
    }

    @Override
    @lombok.Generated
    public boolean equals(final Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }

        final PurchaseLineItem that = (PurchaseLineItem) obj;
        return Objects.equals(getId(), that.getId())
                && lineItemId == that.lineItemId
                && quantityToProduce == that.quantityToProduce
                && Objects.equals(susLineItem, that.susLineItem)
                && Objects.equals(productCode, that.productCode)
                && Objects.equals(lineItemCases, that.lineItemCases)
                && Objects.equals(cost, that.cost)
                && status == that.status;
    }

    @Override
    @lombok.Generated
    public int hashCode() {
        return Objects.hash(getId(), lineItemId, susLineItem, productCode, lineItemCases, quantityToProduce, cost,
                status);
    }

    void setToPendingIfNew() {
        this.status = status == null ? PENDING : status;
    }

    public enum PurchaseLineItemStatus {
        PENDING,
        CREATED
    }
}
