package com.sysco.prime.purchaseOrder;

import com.sysco.prime.PrimeRepository;

public interface PurchaseLineItemRepository extends PrimeRepository<PurchaseLineItem> {
}
