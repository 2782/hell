package com.sysco.prime.purchaseOrder;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.sysco.prime.box.Box;
import com.sysco.prime.customerOrder.CustomerOrder;
import com.sysco.prime.customerOrder.LineItem;
import com.sysco.prime.exception.InvalidValueException;
import com.sysco.prime.product.Product;
import com.sysco.prime.productionOrder.ProductionOrder;
import com.sysco.prime.profile.Profile;
import com.sysco.prime.shared.model.TransactionalEntity;
import com.sysco.prime.sus.model.SusPurchaseOrderResponse;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Generated;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.Entity;
import javax.persistence.OneToMany;
import javax.persistence.Transient;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.function.Function;

import static java.util.Arrays.asList;
import static java.util.Collections.unmodifiableList;
import static java.util.stream.Collectors.toList;
import static javax.persistence.CascadeType.ALL;
import static javax.persistence.FetchType.EAGER;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Getter
@ToString(callSuper = true)
public class PurchaseOrder extends TransactionalEntity {
    static final int TODO_PAR_NEEDS_LINE_ITEM_ID = 0;

    private String opcoNumber;
    private LocalDate orderDate;
    private LocalDate shipDate;
    private String customerShipTo;
    private String salesOrderNumber;
    private String vendorNumber;
    private String roomCode;
    private boolean isComplete;
    private boolean finalShipment;

    @Transient
    @Setter
    private String customerName;

    @SuppressWarnings("FieldMayBeFinal")
    @OneToMany(mappedBy = "purchaseOrder", cascade = ALL, fetch = EAGER,
            orphanRemoval = true)
    @JsonIgnore
    private Set<PurchaseLineItem> lineItems = new LinkedHashSet<>();

    private Long customerOrderId;

    private String poNumber;
    private String requestNumber;

    @Builder(toBuilder = true)
    public PurchaseOrder(
            final String opcoNumber,
            final LocalDate orderDate,
            final LocalDate shipDate,
            final String customerShipTo,
            final String salesOrderNumber,
            final String vendorNumber,
            final String roomCode,
            final String customerName,
            final boolean isComplete,
            final boolean finalShipment,
            final Long customerOrderId,
            final String poNumber,
            final String requestNumber) {
        this.opcoNumber = opcoNumber;
        this.orderDate = orderDate;
        this.shipDate = shipDate;
        this.customerShipTo = customerShipTo;
        this.salesOrderNumber = salesOrderNumber;
        this.vendorNumber = vendorNumber;
        this.roomCode = roomCode;
        this.customerName = customerName;
        this.isComplete = isComplete;
        this.finalShipment = finalShipment;
        this.customerOrderId = customerOrderId;
        this.poNumber = poNumber;
        this.requestNumber = requestNumber;
    }

    static PurchaseOrder fromPackOffByProductAsStock(
            final String roomCode, final Profile profile, final LocalDate shipDate, final LocalDate orderDate) {
        return PurchaseOrder.builder()
                .finalShipment(false)
                .isComplete(false)
                .opcoNumber(profile.getPlantNumber())
                .vendorNumber(profile.getAsVendorNumber())
                .shipDate(shipDate)
                .orderDate(orderDate)
                .salesOrderNumber(null)
                .roomCode(roomCode)
                .poNumber(null)
                .customerShipTo(null)
                .requestNumber(null)
                .customerOrderId(null)
                .build();
    }

    static PurchaseOrder fromCustomerOrder(
            PurchaseOrder existingPurchaseOrder,
            final CustomerOrder customerOrder,
            final Profile profile,
            final List<ProductionOrder> productionOrderList,
            final Function<ProductionOrder, BigDecimal> pricer, final LocalDate orderDate) {
        final List<LineItem> lineItems = customerOrder.getLineItems();
        final List<PurchaseLineItem> lineItemList = productionOrderList.stream()
                .map(order -> PurchaseLineItem.fromCutOrder(order, retrieveItemNumber(lineItems, order),
                        pricer.apply(order)))
                .collect(toList());

        if (null != existingPurchaseOrder) {
            existingPurchaseOrder.setCustomerName(customerOrder.getCustomer().getName());
            existingPurchaseOrder.addAll(lineItemList);
            return existingPurchaseOrder;
        }

        return PurchaseOrder.builder().finalShipment(false).isComplete(false)
                .opcoNumber(profile.getPlantNumber())
                .vendorNumber(profile.getAsVendorNumber())
                .shipDate(customerOrder.getShipDate())
                .orderDate(orderDate)
                .salesOrderNumber(customerOrder.getOrderNumber())
                // TODO:  .customerShipTo(customerOrder.getCustomerCode())
                .customerOrderId(customerOrder.getId())
                .customerName(customerOrder.getCustomer().getName())
                .build()
                .addAll(lineItemList);
    }

    static PurchaseOrder fromOrderListAndRoom(
            final Profile profile,
            final String roomCode,
            final List<ProductionOrder> productionOrderList,
            final Function<ProductionOrder, BigDecimal> pricer, final LocalDate orderShipDate) {
        final List<PurchaseLineItem> lineItems = generatePurchaseLineItemsForPar(productionOrderList, pricer);

        return PurchaseOrder.builder()
                .finalShipment(false)
                .isComplete(false)
                .opcoNumber(profile.getPlantNumber())
                .vendorNumber(profile.getAsVendorNumber())
                .shipDate(orderShipDate)
                .orderDate(orderShipDate)
                .roomCode(roomCode)
                .build()
                .addAll(lineItems);
    }

    private static List<PurchaseLineItem> generatePurchaseLineItemsForPar(
            final List<ProductionOrder> productionOrderList,
            final Function<ProductionOrder, BigDecimal> pricer) {
        final List<PurchaseLineItem> lineItemList = new ArrayList<>(productionOrderList.size());
        for (int itemNumber = 0, size = productionOrderList.size();
             itemNumber < size; ++itemNumber) {
            final ProductionOrder productionOrder = productionOrderList
                    .get(itemNumber);
            final BigDecimal cost = pricer.apply(productionOrder);
            lineItemList.add(PurchaseLineItem.fromCutOrder(productionOrder, itemNumber, cost));
        }
        return lineItemList;
    }

    private static int retrieveItemNumber(
            final List<LineItem> lineItems, final ProductionOrder order) {
        final Optional<LineItem> lineItem = lineItems.stream()
                .filter(item -> item.getId().equals(order.getSourceId()))
                .findFirst();
        if (lineItem.isPresent()) {
            return lineItem.get().getLineNumber();
        }
        throw new InvalidValueException("ProductionOrder should generate from a exist lineitem");
    }

    PurchaseOrder withSusLineItem(
            final SusPurchaseOrderResponse susData, final Function<PurchaseLineItem, Long> onUpdate) {
        lineItems.forEach(lineItem -> lineItem.updateWithSusLineItem(susData, onUpdate));
        return this;
    }

    public List<PurchaseLineItem> getLineItems() {
        return unmodifiableList(new ArrayList<>(lineItems));
    }

    public PurchaseOrder add(final PurchaseLineItem lineItem) {
        final Optional<PurchaseLineItem> found = lineItems.stream()
                .filter(item -> item.getProductCode().equals(lineItem.getProductCode()))
                .findFirst();
        if (found.isPresent()) {
            found.get().addAll(lineItem.getLineItemCases());
        } else {
            lineItems.add(lineItem);
            lineItem.addTo(this);
        }
        return this;
    }

    public PurchaseOrder addAll(final Collection<PurchaseLineItem> lineItems) {
        lineItems.forEach(this::add);
        return this;
    }

    public PurchaseOrder addAll(final PurchaseLineItem... lineItems) {
        addAll(asList(lineItems));
        return this;
    }

    private List<String> lineItemProductCodes() {
        return lineItems.stream()
                .map(PurchaseLineItem::getProductCode)
                .collect(toList());
    }

    PurchaseLineItem getLineItemFor(final Box packedBox) {
        return lineItems.stream()
                .filter(lineItem -> packedBox.getProductCode().equals(lineItem.getProductCode()))
                .findFirst()
                .orElse(null);
    }

    public PurchaseLineItem getLineItemFor(final Product product) {
        return lineItems.stream()
                .filter(lineItem -> product.getCode().equals(lineItem.getProductCode()))
                .findFirst()
                .orElse(null);
    }

    PurchaseLineItem getOrAddLineItemForProduct(final String productCode) {
        return getLineItems().stream()
                .filter(item -> productCode.equals(item.getProductCode()))
                .findFirst() //there can be only one
                .orElse(addFromProduct(productCode));
    }

    private PurchaseLineItem addFromProduct(final String productCode) {
        final PurchaseLineItem lineItem = PurchaseLineItem.builder()
                .lineItemId(TODO_PAR_NEEDS_LINE_ITEM_ID)
                .productCode(productCode)
                .build();
        add(lineItem);
        return lineItem;
    }

    void setSusPoNumber(final String poNumber) {
        this.poNumber = poNumber;
    }

    PurchaseOrder withSusPoNumber(final String poNumber) {
        setSusPoNumber(poNumber);
        return this;
    }

    PurchaseOrder withSusRequestNumber(final String requestNumber) {
        this.requestNumber = requestNumber;
        return this;
    }

    PurchaseOrder complete(final boolean completed) {
        isComplete = completed;
        finalShipment = completed;
        return this;
    }

    PurchaseOrder setNewLineItemsAsPending() {
        lineItems.forEach(PurchaseLineItem::setToPendingIfNew);
        return this;
    }

    @JsonIgnore
    boolean isCreatedInSus() {
        return null != poNumber;
    }

    @JsonIgnore
    boolean isProcessed() {
        return null != requestNumber;
    }

    @Override
    @Generated
    public boolean equals(final Object other) {
        if (this == other) {
            return true;
        }
        if (other == null || getClass() != other.getClass()) {
            return false;
        }

        final PurchaseOrder that = (PurchaseOrder) other;
        return Objects.equals(poNumber, that.poNumber)
                && Objects.equals(requestNumber, that.requestNumber)
                && Objects.equals(orderDate, that.orderDate)
                && Objects.equals(customerOrderId, that.customerOrderId)
                && Objects.equals(roomCode, that.roomCode)
                && lineItemProductCodes().equals(that.lineItemProductCodes());
    }

    @Override
    @Generated
    public int hashCode() {
        return Objects.hash(poNumber, requestNumber, orderDate, customerOrderId, roomCode, lineItemProductCodes());
    }

    void updateGenericOrderShipDateToLatestPackedCase() {
        if (customerOrderId == null) {
            final List<PurchaseLineItemCase> allCases = lineItems.stream()
                    .map(PurchaseLineItem::getLineItemCases)
                    .reduce(new ArrayList<>(), (cases1, cases2) -> {
                        cases1.addAll(cases2);
                        return cases1;
                    });
            allCases.stream().map(PurchaseLineItemCase::getPackDate)
                    .filter(Objects::nonNull)
                    .sorted(Comparator.reverseOrder())
                    .findFirst()
                    .ifPresent(localDate -> shipDate = localDate);
        }
    }
}
