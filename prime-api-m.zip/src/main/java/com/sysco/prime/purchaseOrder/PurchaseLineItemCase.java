package com.sysco.prime.purchaseOrder;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.sysco.prime.shared.model.TransactionalEntity;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;

import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import java.time.LocalDate;
import java.util.Objects;

import static javax.persistence.CascadeType.ALL;
import static javax.persistence.FetchType.EAGER;

@AllArgsConstructor
@Builder(toBuilder = true)
@Entity
@Getter
@NoArgsConstructor
@ToString(callSuper = true, exclude = "purchaseLineItem")
public class PurchaseLineItemCase extends TransactionalEntity {
    private Float weight;
    private LocalDate packDate;
    private Long requestNumber;

    @ManyToOne(fetch = EAGER, cascade = ALL, optional = false)
    @JoinColumn(name = "purchaseLineItemId")
    private PurchaseLineItem purchaseLineItem;

    void addTo(final PurchaseLineItem lineItem) {
        purchaseLineItem = lineItem;
    }

    public void setRequestNumber(final Long susRequestNumber) {
        if (null != requestNumber) {
            throw new PurchaseOrderException(
                    "Sent PO receipt twice for same box: " + this);
        }
        requestNumber = susRequestNumber;
    }

    PurchaseLineItemCase withRequestNumber(final Long susRequestNumber) {
        setRequestNumber(susRequestNumber);
        return this;
    }

    @Override
    @lombok.Generated
    public boolean equals(final Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }

        final PurchaseLineItemCase that = (PurchaseLineItemCase) obj;
        return Objects.equals(getId(), that.getId())
                && Objects.equals(weight, that.weight)
                && Objects.equals(packDate, that.packDate);
    }

    @Override
    @lombok.Generated
    public int hashCode() {
        return Objects.hash(getId(), weight, packDate);
    }

    @JsonIgnore
    public boolean isProcessed() {
        return null != requestNumber;
    }
}
