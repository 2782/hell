package com.sysco.prime.portionRoom;

import com.sysco.prime.exception.NotFoundException;

public class PortionRoomNotFoundException extends NotFoundException {
    PortionRoomNotFoundException(final String message) {
        super(message);
    }
}
