package com.sysco.prime.portionRoom.response;

import com.sysco.prime.batch.Batch;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
@AllArgsConstructor
public class UnfinishedBatchResponse {
    private long id;
    private int batchNumber;

    public static UnfinishedBatchResponse from(final Batch batch) {
        return UnfinishedBatchResponse.builder()
                .id(batch.getId())
                .batchNumber(batch.getBatchNumber())
                .build();
    }
}
