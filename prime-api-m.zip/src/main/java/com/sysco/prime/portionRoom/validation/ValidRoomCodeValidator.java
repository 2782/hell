package com.sysco.prime.portionRoom.validation;

import com.sysco.prime.portionRoom.PortionRoomRepository;
import com.sysco.prime.product.validation.PrimeConstraintValidator;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.validation.ConstraintValidatorContext;
import java.util.regex.Pattern;

import static com.sysco.prime.validation.ValidationErrorType.ALPHA_NUMERIC;
import static com.sysco.prime.validation.ValidationErrorType.LENGTH;
import static com.sysco.prime.validation.ValidationErrorType.NON_ZERO;
import static com.sysco.prime.validation.ValidationErrorType.REQUIRED;
import static com.sysco.prime.validation.ValidationErrorType.UNIQUE;
import static org.apache.commons.lang.StringUtils.isAlphanumeric;
import static org.springframework.util.StringUtils.isEmpty;

@Component
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class ValidRoomCodeValidator implements PrimeConstraintValidator<ValidRoomCode, String> {
    private static final Pattern ONLY_ZEROES = Pattern.compile("^0+$");
    private final PortionRoomRepository portionRoomRepository;

    @Override
    public void initialize(final ValidRoomCode constraintAnnotation) {
    }

    @Override
    public boolean isValid(final String roomCode, final ConstraintValidatorContext context) {
        if (isEmpty(roomCode)) {
            return validationFailedBecause(context, REQUIRED);
        }
        if (!isAlphanumeric(roomCode)) {
            return validationFailedBecause(context, ALPHA_NUMERIC);
        }
        if (roomCode.length() > 2 || roomCode.length() < 1) {
            return validationFailedBecause(context, LENGTH);
        }
        if (ONLY_ZEROES.matcher(roomCode).matches()) {
            return validationFailedBecause(context, NON_ZERO);
        }
        if (portionRoomRepository.findByCode(roomCode).isPresent()) {
            return validationFailedBecause(context, UNIQUE);
        }

        return true;
    }
}
