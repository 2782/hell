package com.sysco.prime.portionRoom;

import com.sysco.prime.batch.Batch;
import com.sysco.prime.batch.BatchNumberRepository;
import com.sysco.prime.batch.BatchService;
import com.sysco.prime.box.BoxService;
import com.sysco.prime.customerOrder.LineItemService;
import com.sysco.prime.customerOrder.PrimeLineItem;
import com.sysco.prime.housePar.HousePar;
import com.sysco.prime.housePar.HouseParService;
import com.sysco.prime.portionRoom.response.CloseRoomResult;
import com.sysco.prime.portionRoom.response.PortionRoomResponse;
import com.sysco.prime.portionRoom.response.UnfinishedBatchResponse;
import com.sysco.prime.productionOrder.ProductionOrder;
import com.sysco.prime.productionOrder.ProductionOrderService;
import com.sysco.prime.profile.ProfileService;
import com.sysco.prime.purchaseOrder.PurchaseOrderService;
import com.sysco.prime.reporting.ReportingPublisher;
import com.sysco.prime.systemConfig.SystemConfigService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Clock;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Supplier;

import static com.sysco.prime.batch.BatchNumber.resetBatchNumber;
import static com.sysco.prime.portionRoom.PortionRoomStatus.CLOSED;
import static com.sysco.prime.portionRoom.PortionRoomStatus.OPENED;
import static com.sysco.prime.portionRoom.response.CloseRoomResult.Reason.UNFINISHED_BATCHES;
import static com.sysco.prime.portionRoom.response.CloseRoomResult.Reason.UNFINISHED_PRODUCTION_ORDERS;
import static com.sysco.prime.portionRoom.response.CloseRoomResult.Reason.UNPROCESSED_PURCHASE_ORDERS_OR_RECEIPTS;
import static com.sysco.prime.portionRoom.response.CloseRoomResult.Reason.UNRECEIVED_PURCHASE_ORDERS;
import static com.sysco.prime.productionOrder.ProductionOrderStatus.unfinishedStatuses;
import static java.lang.String.format;
import static java.util.stream.Collectors.groupingBy;
import static java.util.stream.Collectors.toList;

@Service
@Slf4j
public class PortionRoomService {
    private final PortionRoomRepository portionRoomRepository;
    private final BatchNumberRepository batchNumberRepository;
    private final SystemConfigService systemConfigService;
    private final ProductionOrderService productionOrderService;
    private final LineItemService lineItemService;
    private final PortionRoomWorkingDatesService portionRoomWorkingDatesService;
    private final ReportingPublisher reportingPublisher;
    private final HouseParService houseParService;
    private final ProfileService profileService;
    private final Clock when;
    private final BatchService batchService;
    private final PurchaseOrderService purchaseOrderService;
    private final BoxService boxService;

    private final ThreadLocal<PortionRoom> currentPortionRoom = new ThreadLocal<>();

    public PortionRoomService(final PortionRoomRepository portionRoomRepository,
                              final BatchNumberRepository batchNumberRepository,
                              final SystemConfigService systemConfigService,
                              final ProductionOrderService productionOrderService,
                              final LineItemService lineItemService,
                              final PortionRoomWorkingDatesService portionRoomWorkingDatesService,
                              final ReportingPublisher reportingPublisher,
                              final HouseParService houseParService,
                              final ProfileService profileService,
                              final Clock when,
                              final BatchService batchService,
                              final PurchaseOrderService purchaseOrderService,
                              @Lazy final BoxService boxService) {
        this.portionRoomRepository = portionRoomRepository;
        this.batchNumberRepository = batchNumberRepository;
        this.systemConfigService = systemConfigService;
        this.productionOrderService = productionOrderService;
        this.lineItemService = lineItemService;
        this.portionRoomWorkingDatesService = portionRoomWorkingDatesService;
        this.reportingPublisher = reportingPublisher;
        this.houseParService = houseParService;
        this.profileService = profileService;
        this.when = when;
        this.batchService = batchService;
        this.purchaseOrderService = purchaseOrderService;
        this.boxService = boxService;
    }

    List<PortionRoomResponse> getPortionRooms() {
        final boolean isWorkToday = systemConfigService.isWorkday(OffsetDateTime.now(when));
        return getAllPortionRooms()
                .stream()
                .map(item -> item.toResponse(isWorkToday, when))
                .collect(toList());
    }

    Map<String, LocalDate> getOperatingDates(final String roomCode) {
        final Map<String, LocalDate> operatingDates = new HashMap<>();
        final PortionRoom room = getPortionRoomByCode(roomCode);

        operatingDates.put("today", LocalDate.now(when));
        operatingDates.put("first", systemConfigService.getFirstWorkDay(room.getLastOpenedAt()));
        operatingDates.put("second", systemConfigService.getNextWorkDay(room.getLastOpenedAt()));
        return operatingDates;
    }

    @Transactional
    public List<PortionRoomResponse> open(final Long portionRoomId, final OffsetDateTime lastOpenedAt) {
        if (systemConfigService.isWorkday(lastOpenedAt)) {
            open(getPortionRoom(portionRoomId), lastOpenedAt);
        }
        return getPortionRooms();
    }

    private void open(final PortionRoom portionRoom, final OffsetDateTime lastOpenedAt) {
        if (!portionRoom.isOpenable(when)) {
            return;
        }

        log.info("[PortionRoomService::open] opening portionRoom - ", portionRoom);

        portionRoom.setPortionRoomStatus(OPENED);
        portionRoom.setLastOpenedAt(lastOpenedAt);
        final PortionRoomWorkingDates workingDates = portionRoom.workingDatesOnOpening();
        portionRoomWorkingDatesService.save(workingDates);

        if (portionRoom.isCuttingRoom()) {
            openCuttingRoom(portionRoom, lastOpenedAt);
        }

        saveAndReport(portionRoom);
    }

    void openCuttingRoom(final PortionRoom portionRoom, final OffsetDateTime lastOpenedAt) {
        // TODO: Calling the line item service is the wrong way about this
        // Better is to publish a Spring event which the line item service subscribes for
        // See how the reporting service publishes events, and a listener writes them to DB
        lineItemService.getCutItems(portionRoom).stream()
                .collect(groupingBy(PrimeLineItem::asSusGroupingKey))
                .forEach((key, value) -> allocateAndGenerateFor(value, portionRoom));

        final List<HousePar> housePars =
                houseParService.getAvailableHouseParsForOrderGenerating(portionRoom, lastOpenedAt);
        productionOrderService.generateCutOrdersFromHousePar(
                housePars, portionRoom.getCode(), lastOpenedAt);
    }

    void allocateAndGenerateFor(
            final List<PrimeLineItem> items,
            final PortionRoom portionRoom) {
        final String opCo = profileService.get().getPlantNumber();

        final List<PrimeLineItem> toProduce = lineItemService.allocateStocksAndGetRemainingLineItems(
                opCo, items, portionRoom.getCode(), false);

        productionOrderService.generateOrdersFromPrimeLineItems(toProduce, null);
    }

    void saveAndReport(final PortionRoom portionRoom) {
        portionRoomRepository.save(portionRoom);
        batchNumberRepository.save(resetBatchNumber(portionRoom));

        final PortionRoomWorkingDates workingDates =
                portionRoomWorkingDatesService.findNewestWorkingDatesFor(portionRoom.getCode());
        reportingPublisher.reportOn(
                portionRoom.toReporting(workingDates.getOpening(), workingDates.getClosing()));
    }

    private PortionRoom getPortionRoom(final Long id) {
        return Optional.ofNullable(portionRoomRepository.getOneOrNull(id))
                .orElseThrow(() -> new PortionRoomNotFoundException(
                        format("[PortionRoomService::getPortionRoomCode] PortionRoom not found, id: %s", id)));
    }

    public PortionRoom getPortionRoomByCode(final String code) {
        final Optional<PortionRoom> portionRoom = portionRoomRepository.findByCode(code);
        if (!portionRoom.isPresent()) {
            throw new PortionRoomNotFoundException(
                    format("[PortionRoomService::getPortionRoomByCode] PortionRoom not found, code: %s", code));
        }
        return portionRoom.get();
    }

    PortionRoom createNewRoom(final PortionRoom room) {
        room.setPortionRoomStatus(CLOSED);
        final PortionRoom saved = portionRoomRepository.save(room);
        batchNumberRepository.save(resetBatchNumber(saved));
        return saved;
    }

    CloseRoomResult close(final Long id, final boolean evenWhenThereAreUnfinishedOrders,
                          final boolean evenSusPoUnavailable) {
        final PortionRoom portionRoom = getPortionRoom(id);
        final List<Batch> unfinishableBatches = batchService.findUnfinishableBatches(portionRoom.getCode());
        if (!unfinishableBatches.isEmpty()) {
            return CloseRoomResult.builder()
                    .closed(false)
                    .reason(UNFINISHED_BATCHES)
                    .batches(unfinishableBatches.stream()
                            .map(UnfinishedBatchResponse::from)
                            .collect(toList()))
                    .build();
        }

        if (!purchaseOrderService.isAllPurchaseOrderCreatedInSus(portionRoom)) {
            return CloseRoomResult.builder()
                    .closed(false)
                    .reason(UNRECEIVED_PURCHASE_ORDERS)
                    .build();
        }

        if (!evenWhenThereAreUnfinishedOrders && isAllOrdersFinishedInRoom(portionRoom)) {
            return CloseRoomResult.builder()
                    .closed(false)
                    .reason(UNFINISHED_PRODUCTION_ORDERS)
                    .build();
        }

        if (!evenSusPoUnavailable && (!purchaseOrderService.isAllPurchaseOrderProcessed(portionRoom)
                || !purchaseOrderService.isAllLineItemReceiptProcessed(portionRoom))) {
            return CloseRoomResult.builder()
                    .closed(false)
                    .reason(UNPROCESSED_PURCHASE_ORDERS_OR_RECEIPTS)
                    .build();
        }

        final OffsetDateTime closingAt = OffsetDateTime.now(when);

        closePortionRoom(portionRoom, closingAt);
        return CloseRoomResult.builder()
                .closed(true)
                .build();
    }

    private boolean isAllOrdersFinishedInRoom(final PortionRoom room) {
        final LocalDate localDate = room.getLastOpenedAt().toLocalDate();
        final LocalDate today = LocalDate.of(localDate.getYear(), localDate.getMonthValue(), localDate.getDayOfMonth());

        final Optional<String> status = Optional.ofNullable(StringUtils.join(unfinishedStatuses(), ","));
        final List<ProductionOrder> orders = productionOrderService
                .findAllProductionOrders(
                        room.getCode(),
                        Optional.empty(),
                        status,
                        Optional.empty(),
                        Optional.empty(),
                        Optional.of(false));
        return orders.stream().anyMatch(order -> order.isUnfinished(today));
    }

    @Transactional
    public void closePortionRoom(final PortionRoom portionRoom, final OffsetDateTime closingAt) {
        if (!portionRoom.isOpened()) {
            return;
        }

        productionOrderService.updateUnclosedProductionOrders(portionRoom);

        portionRoom.setPortionRoomStatus(CLOSED);
        portionRoom.setApproved(false);
        portionRoomRepository.save(portionRoom);

        if (portionRoom.isGrindingRoom()) {
            lineItemService.allocateStocksForGrindingOrders(portionRoom);
        }

        final PortionRoomWorkingDates openingWorkingDates = portionRoomWorkingDatesService
                .findUnClosedWorkingDatesFor(portionRoom.getCode());
        final PortionRoomWorkingDates workingDates = openingWorkingDates.closeAt(closingAt);
        portionRoomWorkingDatesService.save(workingDates);

        batchService.finishBatch(portionRoom);

        boxService.returnReservedWipBoxes(portionRoom.getCode());

        reportingPublisher.reportOn(portionRoom.toReporting(workingDates.getOpening(), workingDates.getClosing()));
    }

    public List<PortionRoom> getAllPortionRooms() {
        return portionRoomRepository.findAll().stream()
                .filter(item -> !item.isCostingRoom())
                .collect(toList());
    }

    public void approve(final String roomCode) {
        final PortionRoom room = getPortionRoomByCode(roomCode);
        room.setApproved(true);
        portionRoomRepository.save(room);
    }

    public boolean isRoomAlreadyApprovedForToday(final String roomCode) {
        return getPortionRoomByCode(roomCode).isApproved();
    }

    public PortionRoomWorkingDates getPortionRoomWorkingDates(final String roomCode) {
        return portionRoomWorkingDatesService.findNewestWorkingDatesFor(roomCode);
    }

    public int nextBatchNumber(final PortionRoom room) {
        return batchNumberRepository.nextBatchNumber(room);
    }

    Boolean stockAlerted(final String roomCode) {
        final PortionRoom portionRoom = getPortionRoomByCode(roomCode);
        PortionRoomWorkingDates portionRoomWorkingDates = null;

        if (portionRoom.isCuttingRoom()) {
            portionRoomWorkingDates = getPortionRoomWorkingDates(roomCode);
        } else if (portionRoom.isGrindingRoom()) {
            if (!portionRoom.isOpened()) {
                portionRoomWorkingDates = getPortionRoomWorkingDates(roomCode);
            } else {
                portionRoomWorkingDates = getPortionRoomWorkingDatesForPreviousWorkingDay(roomCode);
            }
        }

        if (null == portionRoomWorkingDates) {
            return true;
        }

        final Boolean stockAlerted = portionRoomWorkingDates.getStockAlerted();

        if (stockAlerted == null) {
            return true;
        }

        if (!stockAlerted) {
            portionRoomWorkingDates.setStockAlerted(true);
            portionRoomWorkingDatesService.save(portionRoomWorkingDates);
        }

        return stockAlerted;
    }

    private PortionRoomWorkingDates getPortionRoomWorkingDatesForPreviousWorkingDay(final String roomCode) {
        final List<PortionRoomWorkingDates> portionRoomWorkingDates =
                portionRoomWorkingDatesService.findFirstTwoWorkingDatesFor(roomCode);

        if (portionRoomWorkingDates.size() <= 1) {
            return null;
        }

        return portionRoomWorkingDates.get(1);
    }

    public void setCurrentPortionRoom(String roomCode) {
        currentPortionRoom.set(getPortionRoomByCode(roomCode));
    }

    public PortionRoom getCurrentPortionRoom() {
        return currentPortionRoom.get();
    }

    public boolean isCustomerNumberMatch(String customerNumber) {
        return portionRoomRepository.findAll()
                .stream()
                .anyMatch(portionRoom -> customerNumber.equals(portionRoom.getCustomerNumber()));
    }

    PortionRoom getCostingRoom() {
        return portionRoomRepository.findByRoomType(PortionRoomType.COSTING)
                .orElseThrow(() -> new RuntimeException("Costing Room not found: Be sure to add to DB."));
    }
}
