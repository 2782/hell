package com.sysco.prime.portionRoom;

import com.sysco.prime.Reportable;
import lombok.Builder;
import lombok.Data;

import javax.annotation.Nullable;
import java.time.OffsetDateTime;

@Builder
@Data
public final class PublishingPortionRoom implements Reportable {
    private final String code;
    private final String description;
    private final PortionRoomType roomType;
    private final PortionRoomStatus portionRoomStatus;
    private final OffsetDateTime opening;
    @Nullable
    private final OffsetDateTime closing;
}
