package com.sysco.prime.portionRoom;

public enum PortionRoomType {
    CUTTING, GRINDING, COSTING
}
