package com.sysco.prime.portionRoom.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.util.List;

@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CloseRoomResult {
    private boolean closed;
    private List<UnfinishedBatchResponse> batches;
    private Reason reason;


    public enum Reason {
        UNFINISHED_BATCHES, UNFINISHED_PRODUCTION_ORDERS, UNRECEIVED_PURCHASE_ORDERS,
        UNPROCESSED_PURCHASE_ORDERS_OR_RECEIPTS
    }
}
