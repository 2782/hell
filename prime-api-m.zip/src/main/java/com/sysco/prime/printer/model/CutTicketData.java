package com.sysco.prime.printer.model;

import com.sysco.prime.customerOrder.CustomerOrder;
import com.sysco.prime.product.Product;
import com.sysco.prime.product.ProductPortionSize;
import com.sysco.prime.productionOrder.ProductionOrder;
import com.sysco.prime.ticket.TicketType;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

import static com.sysco.prime.utils.TimeUtils.LABEL_DATE_FORMATTER;
import static java.lang.String.valueOf;
import static java.util.Objects.isNull;

@Data
@Builder
@EqualsAndHashCode(callSuper = false)
public class CutTicketData implements PrinterSerializable {
    private String id;
    private String orderNumber;
    private String productCode;
    private String productDescription;
    private String piecesPerBox;
    private String portionSize;
    private String quantity;
    private String packingInstruction;
    private String cuttingInstruction;
    private String deliveryDate;
    private TicketType type;
    private String customerNumber;
    private String customerName;
    private String cutTicketCode;
    private boolean reprint;

    public static CutTicketData from(final ProductionOrder productionOrder, final boolean reprint) {
        final Product product = productionOrder.getProduct();
        final CustomerOrder customerOrder = productionOrder.getCustomerOrder();

        final ProductPortionSize productPortionSize = product.getProductPortionSize();
        return builder()
                .id(productionOrder.getId().toString())
                .orderNumber(isNull(customerOrder) ? null : customerOrder.getOrderNumber())
                .deliveryDate(productionOrder.getDeliveryDate().format(LABEL_DATE_FORMATTER))
                .productCode(product.getCode())
                .productDescription(product.getDescription())
                .quantity(String.format("%d %s", productionOrder.getQtyToProduce(), productionOrder.getUnitOfMeasure()))
                .portionSize(product.getProductPortionSize().getPortionSize())
                .piecesPerBox(valueOf(productPortionSize.getPiecesPerCase()))
                .portionSize(valueOf(productPortionSize.getPortionSize()))
                .packingInstruction(productionOrder.getPackInstruction())
                .cuttingInstruction(productionOrder.getProducingInstruction())
                .type(TicketType.CUT_TICKET)
                .customerName(null == customerOrder ? null : customerOrder.getCustomer().getName())
                .customerNumber(null == customerOrder ? null : customerOrder.getCustomerCode())
                .cutTicketCode(productionOrder.getTicketCode(TicketType.CUT_TICKET))
                .reprint(reprint)
                .build();
    }
}
