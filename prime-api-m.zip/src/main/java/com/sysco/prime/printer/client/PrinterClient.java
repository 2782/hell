package com.sysco.prime.printer.client;

import com.sysco.dummysus.RestTemplateSetup;
import com.sysco.prime.printer.model.CutTicketData;
import com.sysco.prime.printer.model.PackOffTicketData;
import com.sysco.prime.printer.model.RetailTicketData;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class PrinterClient {
    private final RestTemplate restTemplate;
    private final String uriPrefix;

    @Autowired
    public PrinterClient(final RestTemplateSetup restTemplateSetup,
                         @Value("${printer.service.domain}") final String uriPrefix) throws Exception {
        this.restTemplate = restTemplateSetup.setup();
        this.uriPrefix = uriPrefix;
    }

    public String createCutTicketPrintingJob(final CutTicketData cutTicketData, final String printer) {
        return restTemplate.postForObject(uriPrefix + "/cut-ticket/print",
                new PrintJob(cutTicketData, printer), String.class);
    }

    public String createPackOffTicketPrintingJob(final PackOffTicketData packOffTicketData, final String printer) {
        return restTemplate.postForObject(uriPrefix + "/ticket/packoff", new PrintJob(packOffTicketData, printer),
                String.class);
    }

    public String createRetailTicketPrintingJob(final PrintJob printJob) {
        return restTemplate.postForObject(uriPrefix + "/retail-ticket/print", printJob, String.class);
    }

    public String createGrindTicketPrintingJob(final PrintJob printJob) {
        return restTemplate.postForObject(uriPrefix + "/grind-ticket/print", printJob, String.class);
    }
}
