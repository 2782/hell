package com.sysco.prime.printer.model;

import com.sysco.prime.box.Box;
import com.sysco.prime.customer.Customer;
import com.sysco.prime.customer.CustomerImageFile;
import com.sysco.prime.customer.CustomerSpecificItemNumber;
import com.sysco.prime.customer.DateType;
import com.sysco.prime.product.Allergen;
import com.sysco.prime.product.Product;
import com.sysco.prime.product.ProductPortionSize;
import com.sysco.prime.product.SpecialDiet;
import com.sysco.prime.productionOrder.OrderType;
import com.sysco.prime.productionOrder.ProductionOrder;
import com.sysco.prime.profile.Profile;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.persistence.Enumerated;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import static com.google.common.collect.Lists.newArrayList;
import static com.sysco.prime.customer.DateType.NONE;
import static com.sysco.prime.product.ProductCategory.CATCH;
import static com.sysco.prime.utils.TimeUtils.LABEL_DATETIME_FORMATTER;
import static com.sysco.prime.utils.TimeUtils.LABEL_DATE_FORMATTER;
import static com.sysco.prime.utils.TimeUtils.LABEL_YEAR_MONTH_DAY_FORMATTER;
import static java.lang.String.valueOf;
import static java.math.RoundingMode.HALF_UP;
import static java.util.Collections.emptyList;
import static javax.persistence.EnumType.STRING;

@Data
@Builder(toBuilder = true)
@EqualsAndHashCode(callSuper = false)
public class PackOffTicketData implements PrinterSerializable {
    private String id;
    private String opCoNumber;
    private String establishmentNumber;
    private String companyName;
    private String companyAddress;
    private String companyCity;
    private String companyState;
    private String companyZip;
    private String poNumber;
    private String productCode;
    private String itemNumber;
    private String productDescription;
    private String usdaGrade;
    private String instructions;
    private String customerNumber;
    private String customerName;
    private String packDate;
    private String barCodePackDate;
    private String netWeightLbs;
    private String netWeightKgs;
    private String piecesPerBox;
    private String portionSize;
    private String storageCode;
    private String tenderized;
    private String ingredientsStatement;
    private String labelProductDescription;
    @Enumerated(STRING)
    private SpecialDiet specialDiet;
    private Integer quantityToProduce;
    private Integer quantityPacked;
    private String salesOrderNumber;
    private String barcode;
    private String routeId;
    private List<String> allergens;
    private byte[] logoImageData;

    @Enumerated(STRING)
    private DateType dateType;
    private String formattedDateValue;

    private static BigDecimal poundsToPoundsToTwoPlaces(final BigDecimal weightInPounds) {
        return weightInPounds
                .setScale(2, HALF_UP);
    }

    private static BigDecimal poundsToKilogramsToTwoPlaces(final BigDecimal weightInPounds) {
        return weightInPounds.multiply(new BigDecimal("0.453592"))
                .setScale(2, HALF_UP);
    }

    public static PackOffTicketData from(
            final Box box, final Profile profile, final Customer customer,
            final String poNumber) {

        PackOffTicketDataBuilder packOffTicketDataBuilder =
                buildBasicPackOffTicketData(box, profile, false)
                        .poNumber(poNumber);

        if (null != customer) {
            packOffTicketDataBuilder = packOffTicketDataBuilder
                    .customerNumber(customer.getCustomerCode())
                    .customerName(customer.getName());

            if (customer.hasDateType()) {
                packOffTicketDataBuilder = packOffTicketDataBuilder
                        .dateType(customer.getDateType())
                        .formattedDateValue(
                                box.getConsumedDate()
                                        .plusDays(customer.getDateValue(box.getItemProduct()))
                                        .format(LABEL_DATE_FORMATTER)
                        );
            }

            if (!customer.getItemNumbers().isEmpty()) {
                final String productCode = box.getProductCode();
                final Optional<CustomerSpecificItemNumber> customerItemNumberForProduct = customer.getItemNumbers()
                        .stream()
                        .filter(itemNumber -> itemNumber.getProduct().getCode().equals(productCode))
                        .findFirst();
                if (customerItemNumberForProduct.isPresent()) {
                    packOffTicketDataBuilder = packOffTicketDataBuilder
                            .itemNumber(customerItemNumberForProduct.get().getItemNumber());
                }
            }

            if (!customer.getCustomerImageFiles().isEmpty()) {
                final Optional<CustomerImageFile> customerImageFile = customer.getCustomerImageFiles()
                        .stream()
                        .findFirst();
                if (customerImageFile.isPresent()) {
                    packOffTicketDataBuilder = packOffTicketDataBuilder
                            .logoImageData(customerImageFile.get().getData());
                }
            }

            final ProductionOrder productionOrder = box.getTargetProductionOrder();
            packOffTicketDataBuilder = packOffTicketDataBuilder
                    .salesOrderNumber(productionOrder.getCustomerOrder().getOrderNumber());
            if (productionOrder.getOrderType() != OrderType.BANQUET) {
                packOffTicketDataBuilder = packOffTicketDataBuilder
                        .quantityPacked(productionOrder.getQtyPacked())
                        .quantityToProduce(productionOrder.getQtyToProduceInCases());
            }
        }
        return packOffTicketDataBuilder.build();
    }

    public static PackOffTicketData forRelabel(final Box box, final Profile profile, final boolean stockOverrun) {
        return buildBasicPackOffTicketData(box, profile, stockOverrun)
                .build();
    }

    private static PackOffTicketDataBuilder buildBasicPackOffTicketData(
            final Box box,
            final Profile profile,
            final boolean stockOverrun) {
        final Product product = box.getItemProduct();
        final BigDecimal weight = CATCH == product.getCategory() || box.isIncomplete()
                ? box.getNetWeight()
                : BigDecimal.valueOf(product.getWeightPerBox());
        final BigDecimal weightInLbs = poundsToPoundsToTwoPlaces(weight);
        final BigDecimal weightInKgs = poundsToKilogramsToTwoPlaces(weight);
        final List<String> allergenNames = Optional.ofNullable(product.getAllergens())
                .orElseGet(ArrayList::new).stream()
                .map(Allergen::getDisplayName)
                .collect(Collectors.toList());

        final ProductPortionSize productPortionSize = product.getProductPortionSize();
        return PackOffTicketData.builder()
                .id(valueOf(box.getId()))
                .barcode(box.getBarcode())
                .opCoNumber(profile.getPlantNumber())
                .establishmentNumber(profile.getEstablishmentNumber())
                .companyName(profile.getName())
                .companyAddress(profile.getAddress())
                .companyCity(profile.getCity())
                .companyState(profile.getState())
                .companyZip(profile.getZipCode())
                .productCode(product.getCode())
                .productDescription(product.getDescription())
                .usdaGrade(product.getUsdaGrade())
                .instructions(product.getInstructions())
                .packDate(box.getCreatedAt().format(LABEL_DATETIME_FORMATTER))
                .barCodePackDate(box.getConsumedDate().format(LABEL_YEAR_MONTH_DAY_FORMATTER))
                .netWeightLbs(valueOf(weightInLbs))
                .netWeightKgs(valueOf(weightInKgs))
                .piecesPerBox(valueOf(productPortionSize.getPiecesPerCase()))
                .portionSize(valueOf(productPortionSize.getPortionSize()))
                .storageCode(product.getStorageCode())
                .tenderized(null != product.getCutSpecific() ? product.getCutSpecific().getTenderized() : null)
                .ingredientsStatement(product.getIngredientsStatement())
                .labelProductDescription(product.getLabelProductDescription())
                .specialDiet(product.getSpecialDiet())
                .routeId(getRouteId(box, stockOverrun))
                .allergens(allergenNames);
    }

    static String getRouteId(final Box box, final boolean stockOverrun) {
        String routeId;

        if (box.isRelabel()) {
            routeId = "RELBL";
        } else if (box.isCustomerOrder()) {
            routeId = box.getTargetProductionOrder().getCustomerOrder().getRouteName();
        } else if (box.isPar()) {
            routeId = "PAR";
        } else if (box.isStock()) {
            routeId = stockOverrun ? "000" : "999";
        } else {
            routeId = "WIP";
        }

        return routeId;
    }

    public List<String> getStorageCodeText() {
        return storageCode != null ? StorageCodeText.valueOf(storageCode).storageTextDisplayedValue : emptyList();
    }

    public boolean showStorageCodeText() {
        return !getStorageCodeText().isEmpty();
    }

    public boolean isTenderized() {
        return !"None".equals(tenderized);
    }

    public boolean isGraded() {
        return usdaGrade != null ? !"UNGRADED".equals(usdaGrade.toUpperCase()) : false;
    }

    public boolean hasDateType() {
        return (null != dateType && NONE != dateType);
    }

    public boolean hasCustomerLogoImage() {
        return (logoImageData != null && logoImageData.length > 0);
    }

    public boolean hasLabelProductDescription() {
        return null != labelProductDescription && !labelProductDescription.isEmpty();
    }

    public String generateTenderizedMessage() {
        final Map<String, String> messageMapping = new HashMap<>();

        messageMapping.put("None", "");
        messageMapping.put("Blade", "Blade Tenderized*");
        messageMapping.put("Needle", "Needle Tenderized*");
        messageMapping.put("Papain and Bromelain", "Tenderized with Papain and Bromelain*");
        messageMapping.put("Papain", "Tenderized with Papain*");

        return messageMapping.get(tenderized);
    }

    public enum StorageCodeText {
        F(Collections.singletonList("KEEP FROZEN")),
        C(newArrayList("KEEP REFRIGERATED", "MAY BE FROZEN")),
        D(emptyList());

        private final List<String> storageTextDisplayedValue;

        StorageCodeText(final List<String> storageTextDisplayedValue) {
            this.storageTextDisplayedValue = storageTextDisplayedValue;
        }
    }
}
