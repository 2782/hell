package com.sysco.prime.batch;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.sysco.prime.product.Product;
import com.sysco.prime.shared.model.TransactionalEntity;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Generated;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Transient;
import javax.validation.constraints.NotNull;
import java.util.Objects;
import java.util.StringJoiner;

import static javax.persistence.CascadeType.ALL;
import static javax.persistence.FetchType.EAGER;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class BatchFinishedProduct extends TransactionalEntity {
    @JsonIgnore
    @JoinColumn(name = "batchId")
    @ManyToOne(fetch = EAGER, cascade = ALL, optional = false)
    private Batch batch;

    @NotNull
    @OneToOne(fetch = EAGER)
    @JoinColumn(name = "productCode", referencedColumnName = "code")
    @JsonIgnore
    private Product finishedProduct;

    @Builder(toBuilder = true)
    public BatchFinishedProduct(final Product finishedProduct) {
        this.finishedProduct = finishedProduct;
    }

    public void addTo(final Batch batch) {
        this.batch = batch;
    }

    @Transient
    public String productCode() {
        return finishedProduct.getCode();
    }

    @Override
    @Generated
    public boolean equals(final Object other) {
        if (this == other) {
            return true;
        }
        if (other == null || getClass() != other.getClass()) {
            return false;
        }

        final BatchFinishedProduct that = (BatchFinishedProduct) other;
        return Objects.equals(getId(), that.getId())
                && Objects.equals(productCode(), that.productCode());
    }

    @Generated
    @Override
    public int hashCode() {
        return Objects.hash(getId(), productCode());
    }

    @Generated
    @Override
    public String toString() {
        return new StringJoiner(", ", BatchFinishedProduct.class.getSimpleName() + "[", "]")
                .add("batchId=" + batch.getId())
                .add("finishedProductCode=" + productCode())
                .toString();
    }
}
