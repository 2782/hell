package com.sysco.prime.batch;

import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;

@Data
@Builder
@EqualsAndHashCode(callSuper = false)
public class PublishingBatchIngredient implements Serializable {
    private String ingredientProductCode;
    private String vendor;
    private String poNumber;
    private Double actualLbs;
    private boolean allergens;
}
