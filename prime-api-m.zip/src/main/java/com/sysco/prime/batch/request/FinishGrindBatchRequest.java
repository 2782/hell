package com.sysco.prime.batch.request;

import com.sysco.prime.batch.Batch;
import com.sysco.prime.batch.BatchSourceMeat;
import com.sysco.prime.portionRoom.PortionRoomService;
import com.sysco.prime.product.GrindSize;
import com.sysco.prime.product.ProductService;
import com.sysco.prime.productionOrder.Blend;
import com.sysco.prime.productionOrder.BlendRepository;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.Valid;
import javax.validation.constraints.AssertTrue;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

import static java.util.Collections.emptyList;
import static java.util.stream.Collectors.toList;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class FinishGrindBatchRequest implements Serializable {
    private Long id;
    private int batchNumber;
    private String blendName;
    @NotNull
    private LocalDate productionDate;
    @NotNull
    private String tumbler;
    @NotNull
    private LocalTime tumblerStartTime;
    @NotNull
    private LocalTime tumblerStopTime;
    @NotNull
    private Double startBatchTemp;
    @NotNull
    private Double finishedBatchTemp;

    private GrindSize grindSize;
    @NotNull
    private String portionRoomCode;

    @NotNull
    @AssertTrue
    private boolean finished;
    @NotNull
    @Valid
    @Size(min = 1)
    private List<FinishBatchSourceMeatRequest> sourceMeats;

    public Batch toDomain(final ProductService productService,
                          final PortionRoomService portionRoomService,
                          final BlendRepository blendRepository) {

        final Batch batch = Batch.builder()
                .batchNumber(batchNumber)
                .blend(null == blendName ? null : Blend.fromString(blendName, blendRepository))
                .grindSize(grindSize)
                .productionDate(productionDate)
                .tumbler(tumbler)
                .tumblerStartTime(tumblerStartTime)
                .tumblerStopTime(tumblerStopTime)
                .startBatchTemp(startBatchTemp)
                .finishedBatchTemp(finishedBatchTemp)
                .finished(finished)
                .portionRoom(portionRoomService.getPortionRoomByCode(portionRoomCode))
                .build()
                .addSourceMeats(toSourceMeats(productService))
                .addFinishedProducts(emptyList())
                .addIngredients(emptyList());

        batch.getSourceMeats().forEach(sourceMeat -> sourceMeat.setBatch(batch));
        batch.setId(id);
        return batch;
    }

    private List<BatchSourceMeat> toSourceMeats(final ProductService productService) {
        return sourceMeats.stream()
                .map(sourceMeat -> sourceMeat.toDomain(productService))
                .collect(toList());
    }
}
