package com.sysco.prime.batch;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.sysco.prime.product.Product;
import com.sysco.prime.shared.model.TransactionalEntity;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Generated;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Transient;
import javax.validation.constraints.NotNull;
import java.util.Objects;
import java.util.StringJoiner;

import static java.util.Objects.isNull;
import static javax.persistence.CascadeType.ALL;
import static javax.persistence.FetchType.EAGER;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class BatchIngredient extends TransactionalEntity {
    @JsonIgnore
    @JoinColumn(name = "batchId")
    @ManyToOne(fetch = EAGER, cascade = ALL, optional = false)
    private Batch batch;
    @NotNull
    @OneToOne(fetch = EAGER)
    @JoinColumn(name = "ingredientProductCode", referencedColumnName = "code")
    @JsonIgnore
    private Product ingredientProduct;
    private String vendor;
    private String poNumber;
    private Double actualLbs;
    private boolean allergens;

    @Builder(toBuilder = true)
    public BatchIngredient(final Product ingredientProduct, final String vendor, final String poNumber,
                           final Double actualLbs, final boolean allergens) {
        this.ingredientProduct = ingredientProduct;
        this.vendor = vendor;
        this.poNumber = poNumber;
        this.actualLbs = actualLbs;
        this.allergens = allergens;
    }

    public void addTo(final Batch batch) {
        this.batch = batch;
    }

    @Transient
    String getIngredientProductCode() {
        return ingredientProduct.getCode();
    }

    @Generated
    @Override
    public boolean equals(final Object other) {
        if (this == other) {
            return true;
        }
        if (other == null || getClass() != other.getClass()) {
            return false;
        }

        final BatchIngredient that = (BatchIngredient) other;
        return Objects.equals(getId(), that.getId())
                && Objects.equals(getIngredientProductCode(), that.getIngredientProductCode())
                && Objects.equals(vendor, that.vendor)
                && Objects.equals(poNumber, that.poNumber)
                && Objects.equals(allergens, that.allergens)
                && Objects.equals(actualLbs, that.actualLbs);
    }

    @Generated
    @Override
    public int hashCode() {
        return Objects.hash(getId(),
                getIngredientProductCode(),
                vendor,
                poNumber,
                actualLbs,
                allergens);
    }

    @Generated
    @Override
    public String toString() {
        return new StringJoiner(", ", BatchIngredient.class.getSimpleName() + "[", "]")
                .add("batchId=" + batch.getId())
                .add("ingredientProductCode=" + getIngredientProductCode())
                .add("vendor='" + vendor + "'")
                .add("poNumber='" + poNumber + "'")
                .add("netWeight=" + actualLbs)
                .add("allergens=" + allergens)
                .toString();
    }

    boolean couldNotBeFinished() {
        return isNull(vendor) || isNull(poNumber) || isNull(actualLbs);
    }
}
