package com.sysco.prime.batch;

import com.sysco.prime.PrimeRepository;

public interface BatchSourceMeatRepository extends PrimeRepository<BatchSourceMeat> {
}
