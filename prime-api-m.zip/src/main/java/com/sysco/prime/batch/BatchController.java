package com.sysco.prime.batch;

import com.sysco.prime.batch.request.BatchRequest;
import com.sysco.prime.batch.request.FinishGrindBatchRequest;
import com.sysco.prime.batch.request.FinishMarinationBatchRequest;
import com.sysco.prime.batch.response.BatchResponse;
import com.sysco.prime.portionRoom.PortionRoomService;
import com.sysco.prime.product.ProductService;
import com.sysco.prime.productionOrder.Blend;
import com.sysco.prime.productionOrder.BlendRepository;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

import static java.util.stream.Collectors.toList;
import static org.springframework.http.HttpStatus.CREATED;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

@RestController
@RequestMapping(path = "/api")
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
@Secured({"ROLE_ADMIN", "ROLE_PORTION_ROOM_MEMBER"})
public class BatchController {
    private final BatchService batchService;
    private final ProductService productService;
    private final PortionRoomService portionRoomService;
    private final BlendRepository blendRepository;

    @PostMapping(path = "/batches")
    @ResponseStatus(CREATED)
    @ApiOperation(value = "create batch", notes = "create batch")
    public BatchResponse create(@Valid @RequestBody final BatchRequest batch) {
        return new BatchResponse(batchService.create(
                batch.toDomain(productService, portionRoomService, blendRepository)));
    }

    @PutMapping(path = "/batches/{id}")
    @ApiOperation(value = "update batch", notes = "update batch")
    public BatchResponse update(@Valid @RequestBody final BatchRequest batch, @PathVariable("id") final Long id) {
        final Batch batchToUpdate = batch.toDomain(productService, portionRoomService, blendRepository);
        batchToUpdate.setId(id);
        return new BatchResponse(batchService.update(batchToUpdate));
    }

    @PostMapping(path = "/batches/marination/finish")
    @ApiOperation(value = "finish batch", notes = "finish batch")
    public BatchResponse finishMarination(
            @Valid @RequestBody final FinishMarinationBatchRequest finishBatchRequest) {
        return new BatchResponse(batchService.finish(
                finishBatchRequest.toDomain(productService, portionRoomService)));
    }

    @PostMapping(path = "/batches/grind/finish")
    @ApiOperation(value = "finish batch", notes = "finish batch")
    public BatchResponse finishGrind(
            @Valid @RequestBody final FinishGrindBatchRequest finishBatchRequest) {
        return new BatchResponse(batchService.finish(
                finishBatchRequest.toDomain(productService, portionRoomService, blendRepository)));
    }

    @GetMapping(path = "/batches", produces = APPLICATION_JSON_VALUE)
    @ApiOperation(value = "find batches by blendNames and produce-date",
            notes = "find batches by blendNames and produce-date")
    public List<BatchResponse> getByBlendNames(
            @RequestParam("blend-names") final List<String> blendNames,
            @RequestParam("produce-date") @DateTimeFormat(iso = ISO.DATE) final LocalDate produceDate) {
        final List<String> upperCaseBlendNames = blendNames.stream()
                .map(blendName -> Blend.fromString(blendName, blendRepository).getName())
                .collect(Collectors.toList());
        return batchService.getByBlendNames(upperCaseBlendNames, produceDate).stream()
                .map(BatchResponse::new).collect(toList());
    }

    @GetMapping(path = "/batches/criteria", produces = APPLICATION_JSON_VALUE)
    @ApiOperation(value = "find batches by start and end production date, sourcePurchaseNumber, finishedNumber and "
            + "sourceNumber",
            notes = "find batches by start and end production date, sourcePurchaseNumber, finishedNumber and "
                    + "sourceNumber")
    public List<BatchResponse> getBatches(
            @RequestParam(value = "start-production-date", required = false)
            @DateTimeFormat(iso = ISO.DATE) final LocalDate startProductionDate,
            @RequestParam(value = "end-production-date", required = false)
            @DateTimeFormat(iso = ISO.DATE) final LocalDate endProductionDate,
            @RequestParam(value = "source-po-number", required = false) final String sourcePurchaseNumber,
            @RequestParam(value = "finished-or-blend", required = false) final String finishedOrBlendName,
            @RequestParam(value = "source-number", required = false) final String sourceNumber) {
        return batchService.findAllBatches(
                startProductionDate,
                endProductionDate,
                sourcePurchaseNumber,
                finishedOrBlendName,
                sourceNumber).stream()
                .map(BatchResponse::new).collect(toList());
    }
}
