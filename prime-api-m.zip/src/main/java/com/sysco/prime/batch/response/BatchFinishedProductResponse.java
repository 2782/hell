package com.sysco.prime.batch.response;

import com.sysco.prime.batch.BatchFinishedProduct;
import lombok.Data;

@Data
public class BatchFinishedProductResponse {
    private final Long id;
    private final String finishedProductCode;

    public BatchFinishedProductResponse(final BatchFinishedProduct finishedProduct) {
        id = finishedProduct.getId();
        finishedProductCode = finishedProduct.productCode();
    }
}
