package com.sysco.prime.batch.response;

import com.sysco.prime.batch.BatchIngredient;
import lombok.Data;

@Data
public class BatchIngredientResponse {
    private final Long id;
    private final String ingredientProductCode;
    private final String vendor;
    private final String poNumber;
    protected boolean allergens;
    private Double actualLbs;

    BatchIngredientResponse(final BatchIngredient batchIngredient) {
        id = batchIngredient.getId();
        ingredientProductCode = batchIngredient.getIngredientProduct().getCode();
        vendor = batchIngredient.getVendor();
        poNumber = batchIngredient.getPoNumber();
        actualLbs = batchIngredient.getActualLbs();
        allergens = batchIngredient.isAllergens();
    }
}
