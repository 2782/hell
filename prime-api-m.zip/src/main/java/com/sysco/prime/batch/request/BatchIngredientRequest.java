package com.sysco.prime.batch.request;

import com.sysco.prime.batch.BatchIngredient;
import com.sysco.prime.product.ProductService;
import com.sysco.prime.product.validation.ValidProduct;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

import javax.validation.constraints.NotNull;

@AllArgsConstructor
@Builder
@Data
public class BatchIngredientRequest {
    @NotNull
    protected boolean allergens;
    private Long id;
    @ValidProduct
    private String ingredientProductCode;
    @NotNull
    private String vendor;
    @NotNull
    private String poNumber;
    @NotNull
    private Double actualLbs;

    public BatchIngredient toDomain(final ProductService productService) {
        final BatchIngredient ingredient = BatchIngredient.builder()
                .ingredientProduct(productService.findByCode(ingredientProductCode))
                .vendor(vendor)
                .poNumber(poNumber)
                .actualLbs(actualLbs)
                .allergens(allergens)
                .build();
        if (id != null) {
            ingredient.setId(id);
        }
        return ingredient;
    }
}
