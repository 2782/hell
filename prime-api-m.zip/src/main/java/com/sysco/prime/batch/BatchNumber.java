package com.sysco.prime.batch;

import com.sysco.prime.portionRoom.PortionRoom;
import com.sysco.prime.shared.model.TransactionalEntity;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

@AllArgsConstructor
@Builder
@Data
@Entity
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
@ToString(callSuper = true)
public class BatchNumber extends TransactionalEntity {
    @OneToOne
    @JoinColumn(name = "portionRoomId")
    private PortionRoom portionRoom;
    private int lastBatchNumber;

    public static BatchNumber resetBatchNumber(final PortionRoom portionRoom) {
        return BatchNumber.builder()
                .portionRoom(portionRoom)
                .lastBatchNumber(0)
                .build();
    }
}
