package com.sysco.prime.batch;

import com.sysco.prime.product.validation.ProductValidator;
import com.sysco.prime.validation.AlphanumericValidation;
import com.sysco.prime.validation.MinValueValidation;
import com.sysco.prime.validation.NumericValidation;
import com.sysco.prime.validation.Validation;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.stream.Stream;

import static java.lang.String.format;
import static java.util.Objects.nonNull;

@Component
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BatchValidator {
    private static final String ERROR_MESSAGE = "Saving Batch failed.";
    private static final double MIN_VALUE = 0;

    private final BatchRepository batchRepository;
    private final ProductValidator productValidator;

    public void validate(final Batch batch) {
        Stream.of(
                new NumericValidation(ERROR_MESSAGE, batch.getTumbler(), "tumbler"),
                validateIndividualForSourceMeats(batch)
        ).forEach(Validation::validate);
    }

    private Validation validateIndividualForSourceMeats(final Batch batch) {
        return () -> {
            if (nonNull(batch.getSourceMeats())) {
                batch.getSourceMeats().forEach(this::validateBatchSourceMeat);
            }
        };
    }

    private void validateBatchSourceMeat(final BatchSourceMeat sourceMeat) {
        final String sourceProductCode = sourceMeat.getSourceProductCode();

        Stream.of(
                validateProductExists(sourceProductCode, format("source meat %s", sourceProductCode)),
                new AlphanumericValidation(ERROR_MESSAGE, sourceMeat.getLotNumber(),
                        format("source meat %s's lot number", sourceProductCode)),
                new AlphanumericValidation(ERROR_MESSAGE, sourceMeat.getPoNumber(),
                        format("source meat %s's po number", sourceProductCode)),
                new AlphanumericValidation(ERROR_MESSAGE, sourceMeat.getEstablishmentNumber(),
                        format("source meat %s's establishment number", sourceProductCode)),
                new MinValueValidation(ERROR_MESSAGE, format("source meat %s's actual lbs", sourceProductCode),
                        MIN_VALUE, sourceMeat.getActualLbs()),
                new MinValueValidation(ERROR_MESSAGE, format("source meat %s's meat temp", sourceProductCode),
                        MIN_VALUE, sourceMeat.getMeatTemp())
        ).forEach(Validation::validate);
    }

    private Validation validateProductExists(final String productCode, final String fieldName) {
        return () -> productValidator.validateProductMustExist(productCode, fieldName, ERROR_MESSAGE);
    }
}
