package com.sysco.prime.batch;

import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;

@Data
@Builder
@EqualsAndHashCode(callSuper = false)
public class PublishingBatchFinishedProduct implements Serializable {
    private String finishedProductCode;
}
