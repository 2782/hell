package com.sysco.prime.batch;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.util.List;

import static com.sysco.prime.batch.BatchSpecification.extendQuery;
import static java.util.stream.Collectors.toList;

@Component
public class BatchRepositoryImpl implements BatchRepositoryCustom {
    @Autowired
    BatchRepository repository;

    @Override
    public List<Batch> findAll(
            final LocalDate startProductionDate,
            final LocalDate endProductionDate,
            final String sourcePurchaseNumber,
            final String blendName,
            final String finishedNumber,
            final String sourceNumber) {
        final List<Batch> found = repository.findAll(extendQuery(
                startProductionDate,
                endProductionDate,
                sourcePurchaseNumber,
                finishedNumber,
                sourceNumber));
        if (blendName == null) {
            return found;
        }

        final String blendNameCorrected = blendName.trim().toUpperCase();

        return found.stream()
                .filter(batch -> batch.getBlend() != null)
                .filter(batch -> batch.getBlendName().equals(blendNameCorrected))
                .collect(toList());
    }
}
