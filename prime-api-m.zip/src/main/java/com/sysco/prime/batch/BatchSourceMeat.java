package com.sysco.prime.batch;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.sysco.prime.product.Product;
import com.sysco.prime.shared.model.TransactionalEntity;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Generated;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Transient;
import javax.validation.constraints.NotNull;
import java.time.LocalDate;
import java.util.Objects;
import java.util.StringJoiner;

import static java.util.Objects.isNull;
import static javax.persistence.CascadeType.ALL;
import static javax.persistence.FetchType.EAGER;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class BatchSourceMeat extends TransactionalEntity {
    @JsonIgnore
    @JoinColumn(name = "batchId")
    @ManyToOne(fetch = EAGER, cascade = ALL, optional = false)
    private Batch batch;
    @NotNull
    @OneToOne(fetch = EAGER)
    @JoinColumn(name = "sourceProductCode", referencedColumnName = "code")
    @JsonIgnore
    private Product sourceProduct;
    private LocalDate harvestDate;
    private String establishmentNumber;
    private String lotNumber;
    private String vendor;
    private String poNumber;
    private Double meatTemp;
    private Double actualLbs;

    @Builder(toBuilder = true)
    public BatchSourceMeat(final Product sourceProduct, final LocalDate harvestDate, final String
            establishmentNumber, final String lotNumber, final String vendor, final String poNumber, final Double
                                   meatTemp, final Double actualLbs) {
        this.sourceProduct = sourceProduct;
        this.harvestDate = harvestDate;
        this.establishmentNumber = establishmentNumber;
        this.lotNumber = lotNumber;
        this.vendor = vendor;
        this.poNumber = poNumber;
        this.meatTemp = meatTemp;
        this.actualLbs = actualLbs;
    }

    @Transient
    public String getSourceProductCode() {
        return sourceProduct.getCode();
    }

    @Generated
    @Override
    public boolean equals(final Object other) {
        if (this == other) {
            return true;
        }
        if (other == null || getClass() != other.getClass()) {
            return false;
        }

        final BatchSourceMeat that = (BatchSourceMeat) other;
        return Objects.equals(getId(), that.getId())
                && Objects.equals(getSourceProductCode(), that.getSourceProductCode())
                && Objects.equals(harvestDate, that.harvestDate)
                && Objects.equals(establishmentNumber, that.establishmentNumber)
                && Objects.equals(lotNumber, that.lotNumber)
                && Objects.equals(vendor, that.vendor)
                && Objects.equals(poNumber, that.poNumber)
                && Objects.equals(meatTemp, that.meatTemp)
                && Objects.equals(actualLbs, that.actualLbs);
    }

    @Generated
    @Override
    public int hashCode() {
        return Objects.hash(getId(),
                getSourceProductCode(),
                harvestDate,
                establishmentNumber,
                lotNumber,
                vendor,
                poNumber,
                meatTemp,
                actualLbs);
    }

    @Generated
    @Override
    public String toString() {
        return new StringJoiner(", ", BatchSourceMeat.class.getSimpleName() + "[", "]")
                .add("batchId=" + batch.getId())
                .add("sourceProductCode=" + getSourceProductCode())
                .add("harvestDate=" + harvestDate)
                .add("establishmentNumber='" + establishmentNumber + "'")
                .add("lotNumber='" + lotNumber + "'")
                .add("vendor='" + vendor + "'")
                .add("poNumber='" + poNumber + "'")
                .add("meatTemp=" + meatTemp)
                .add("netWeight=" + actualLbs)
                .toString();
    }

    void addTo(final Batch batch) {
        this.batch = batch;
    }

    public boolean couldNotBeFinished() {
        return isNull(harvestDate) || isNull(establishmentNumber) || isNull(lotNumber)
                || isNull(poNumber) || isNull(meatTemp) || isNull(actualLbs) || isNull(vendor);
    }
}
