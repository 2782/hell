package com.sysco.prime.batch;

import com.sysco.prime.PrimeRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDate;
import java.util.Collection;
import java.util.List;

public interface BatchRepository extends PrimeRepository<Batch>,
        JpaSpecificationExecutor<Batch>,
        BatchRepositoryCustom {
    @Query("SELECT a FROM Batch a, Blend b "
            + "WHERE a.productionDate = :produceDate "
            + "AND a.blend.id = b.id "
            + "AND b.name IN :blendNames")
    List<Batch> findByBlendNameInAndProductionDate(
            @Param("blendNames") Collection<String> names, @Param("produceDate") LocalDate produceDate);

    Batch findByBatchNumberAndProductionDate(int batchNumber, LocalDate productionName);

    List<Batch> findByPortionRoomCodeAndProductionDateAndFinishedIsFalse(String roomCode, LocalDate lastOpenDate);
}
