package com.sysco.prime.batch;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.sysco.prime.portionRoom.PortionRoom;
import com.sysco.prime.product.GrindSize;
import com.sysco.prime.productionOrder.Blend;
import com.sysco.prime.shared.model.TransactionalEntity;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Generated;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.Entity;
import javax.persistence.Enumerated;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.validation.constraints.NotNull;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.StringJoiner;

import static java.util.Collections.unmodifiableList;
import static java.util.Objects.isNull;
import static java.util.stream.Collectors.toList;
import static javax.persistence.CascadeType.ALL;
import static javax.persistence.EnumType.STRING;
import static javax.persistence.FetchType.EAGER;
import static javax.persistence.FetchType.LAZY;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class Batch extends TransactionalEntity {
    private int batchNumber;
    @OneToOne(fetch = EAGER)
    @JoinColumn(name = "blendId")
    private Blend blend;
    @NotNull
    private LocalDate productionDate;
    private String tumbler;
    private LocalTime tumblerStartTime;
    private LocalTime tumblerStopTime;
    private Double startBatchTemp;
    private Double finishedBatchTemp;
    private boolean allergens;
    @NotNull
    @OneToOne(fetch = LAZY)
    @JoinColumn(name = "portionRoomCode", referencedColumnName = "code")
    @JsonIgnore
    private PortionRoom portionRoom;

    private boolean finished;
    @Enumerated(STRING)
    private GrindSize grindSize;
    @OneToMany(mappedBy = "batch", cascade = ALL, fetch = EAGER, orphanRemoval = true)
    private Set<BatchSourceMeat> sourceMeats = new LinkedHashSet<>();

    @OneToMany(mappedBy = "batch", cascade = ALL, fetch = EAGER, orphanRemoval = true)
    private Set<BatchIngredient> ingredients = new LinkedHashSet<>();

    @OneToMany(mappedBy = "batch", cascade = ALL, fetch = EAGER, orphanRemoval = true)
    private Set<BatchFinishedProduct> finishedProducts = new LinkedHashSet<>();

    @Builder(toBuilder = true)
    public Batch(
            final int batchNumber,
            final Blend blend,
            final LocalDate productionDate,
            final String tumbler,
            final LocalTime tumblerStartTime,
            final LocalTime tumblerStopTime,
            final Double startBatchTemp,
            final Double finishedBatchTemp,
            final boolean allergens,
            final boolean finished,
            final GrindSize grindSize,
            final PortionRoom portionRoom) {
        this.batchNumber = batchNumber;
        this.blend = blend;
        this.productionDate = productionDate;
        this.tumbler = tumbler;
        this.tumblerStartTime = tumblerStartTime;
        this.tumblerStopTime = tumblerStopTime;
        this.startBatchTemp = startBatchTemp;
        this.finishedBatchTemp = finishedBatchTemp;
        this.allergens = allergens;
        this.finished = finished;
        this.grindSize = grindSize;
        this.portionRoom = portionRoom;
    }

    @JsonIgnore
    public boolean doesNotExist() {
        return isNull(getId());
    }

    public PublishingBatch toReporting(final String portionRoomCode, final OffsetDateTime workingDay) {
        final List<PublishingBatchSourceMeat> publishingSourceMeats = sourceMeats.stream()
                .map(item ->
                        PublishingBatchSourceMeat.builder()
                                .actualLbs(item.getActualLbs())
                                .productCode(item.getSourceProductCode())
                                .build())
                .collect(toList());

        return PublishingBatch.builder()
                .batchNumber(batchNumber)
                .blendName(Optional.ofNullable(blend)
                        .map(Blend::getName)
                        .orElse(null))
                .productionDate(productionDate)
                .portionRoomCode(portionRoomCode)
                .workingDay(workingDay)
                .build()
                .addSourceMeats(publishingSourceMeats);
    }

    public List<BatchSourceMeat> getSourceMeats() {
        return unmodifiableList(new ArrayList<>(sourceMeats));
    }

    public List<BatchFinishedProduct> getFinishedProducts() {
        return unmodifiableList(new ArrayList<>(finishedProducts));
    }

    public boolean couldNotBeFinished() {
        boolean result = isNull(tumbler) || isNull(tumblerStartTime) || isNull(tumblerStopTime)
                || isNull(startBatchTemp) || sourceMeats.isEmpty()
                || sourceMeats.stream().anyMatch(BatchSourceMeat::couldNotBeFinished);

        if (portionRoom.isCuttingRoom()) {
            result = result || ingredients.isEmpty()
                    || ingredients.stream().anyMatch(BatchIngredient::couldNotBeFinished)
                    || finishedProducts.isEmpty();
        }

        return result;
    }

    @Override
    @Generated
    public boolean equals(final Object other) {
        if (this == other) {
            return true;
        }
        if (other == null || getClass() != other.getClass()) {
            return false;
        }

        final Batch that = (Batch) other;
        return Objects.equals(batchNumber, that.batchNumber)
                && Objects.equals(getName(blend), getName(that.blend))
                && Objects.equals(productionDate, that.productionDate)
                && Objects.equals(tumbler, that.tumbler)
                && Objects.equals(tumblerStartTime, that.tumblerStartTime)
                && Objects.equals(tumblerStopTime, that.tumblerStopTime)
                && Objects.equals(startBatchTemp, that.startBatchTemp)
                && Objects.equals(finishedBatchTemp, that.finishedBatchTemp)
                && Objects.equals(allergens, that.allergens)
                && Objects.equals(finished, that.finished)
                && Objects.equals(grindSize, that.grindSize)
                && Objects.equals(getPortionRoomCode(), that.getPortionRoomCode())
                && getSourceMeatProductCodes().equals(that.getSourceMeatProductCodes())
                && getIngredientProductCodes().equals(that.getIngredientProductCodes())
                && getFinishedProductCodes().equals(that.getFinishedProductCodes());
    }

    @Override
    @Generated
    public int hashCode() {
        return Objects.hash(batchNumber, getName(blend), productionDate, tumbler, tumblerStartTime,
                tumblerStopTime, startBatchTemp, finishedBatchTemp, allergens, finished, grindSize,
                getPortionRoomCode(),
                getSourceMeatProductCodes(), getIngredientProductCodes(), getFinishedProductCodes());
    }

    private String getName(final Blend blend) {
        return blend == null ? null : blend.getName();
    }

    String getPortionRoomCode() {
        return portionRoom.getCode();
    }

    List<String> getSourceMeatProductCodes() {
        return sourceMeats.stream()
                .map(BatchSourceMeat::getSourceProductCode)
                .sorted()
                .collect(toList());
    }

    List<String> getIngredientProductCodes() {
        return ingredients.stream()
                .map(BatchIngredient::getIngredientProductCode)
                .sorted()
                .collect(toList());
    }

    List<String> getFinishedProductCodes() {
        return finishedProducts.stream()
                .map(BatchFinishedProduct::productCode)
                .sorted()
                .collect(toList());
    }

    // TODO: Lombok, not hand coded: source meat should exclude parent back-reference to avoid loops
    @Generated
    @Override
    public String toString() {
        return new StringJoiner(", ", Batch.class.getSimpleName() + "[", "]")
                .add("batchNumber='" + batchNumber + "'")
                .add("blend='" + getName(blend) + "'")
                .add("productionDate=" + productionDate)
                .add("tumbler='" + tumbler + "'")
                .add("tumblerStartTime=" + tumblerStartTime)
                .add("tumblerStopTime=" + tumblerStopTime)
                .add("startBatchTemp=" + startBatchTemp)
                .add("finishedBatchTemp=" + finishedBatchTemp)
                .add("allergens=" + allergens)
                .add("finished=" + finished)
                .add("grindSize=" + grindSize)
                .add("portionRoomCode=" + getPortionRoomCode())
                .add("sourceMeats=" + sourceMeats.stream()
                        .map(BatchSourceMeat::getSourceProductCode)
                        .collect(toList()))
                .add("ingredients=" + ingredients.stream()
                        .map(BatchIngredient::getIngredientProductCode)
                        .collect(toList()))
                .add("finishedProducts=" + finishedProducts.stream()
                        .map(BatchFinishedProduct::productCode)
                        .collect(toList()))
                .toString();
    }

    public Batch addSourceMeat(final BatchSourceMeat sourceMeat) {
        sourceMeats.add(sourceMeat);
        sourceMeat.addTo(this);
        return this;
    }

    public Batch addIngredient(final BatchIngredient ingredient) {
        ingredients.add(ingredient);
        ingredient.addTo(this);
        return this;
    }

    public Batch addFinishedProduct(final BatchFinishedProduct finishedProduct) {
        finishedProducts.add(finishedProduct);
        finishedProduct.addTo(this);
        return this;
    }

    public Batch addSourceMeats(final Collection<BatchSourceMeat> sourceMeats) {
        sourceMeats.forEach(this::addSourceMeat);
        return this;
    }

    public Batch addIngredients(final Collection<BatchIngredient> ingredients) {
        ingredients.forEach(this::addIngredient);
        return this;
    }

    public Batch addFinishedProducts(final Collection<BatchFinishedProduct> finishedProducts) {
        finishedProducts.forEach(this::addFinishedProduct);
        return this;
    }

    public void changeToFinished() {
        this.setFinished(true);
    }

    public String getBlendName() {
        return blend == null ? null : blend.getName();
    }
}
