package com.sysco.prime.batch.request;

import com.sysco.prime.batch.BatchFinishedProduct;
import com.sysco.prime.product.ProductService;
import com.sysco.prime.product.validation.ValidProduct;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

@AllArgsConstructor
@Builder
@Data
public class BatchFinishedProductRequest {
    private Long id;
    @ValidProduct
    private String finishedProductCode;

    public BatchFinishedProduct toDomain(final ProductService productService) {
        return BatchFinishedProduct.builder()
                .finishedProduct(productService.findByCode(finishedProductCode))
                .build();
    }
}
