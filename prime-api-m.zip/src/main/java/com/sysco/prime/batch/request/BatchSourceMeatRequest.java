package com.sysco.prime.batch.request;

import com.sysco.prime.batch.BatchSourceMeat;
import com.sysco.prime.product.ProductService;
import com.sysco.prime.product.validation.ValidProduct;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

import java.time.LocalDate;

@AllArgsConstructor
@Builder
@Data
public class BatchSourceMeatRequest {
    private Long id;
    @ValidProduct
    private String sourceProductCode;
    private LocalDate harvestDate;
    private String establishmentNumber;
    private String lotNumber;
    private String vendor;
    private String poNumber;
    private Double meatTemp;
    private Double actualLbs;

    public BatchSourceMeat toDomain(final ProductService productService) {
        final BatchSourceMeat sourceMeat = BatchSourceMeat.builder()
                .sourceProduct(productService.findByCode(sourceProductCode))
                .harvestDate(harvestDate)
                .establishmentNumber(establishmentNumber)
                .lotNumber(lotNumber)
                .vendor(vendor)
                .poNumber(poNumber)
                .meatTemp(meatTemp)
                .actualLbs(actualLbs)
                .build();
        if (id != null) {
            sourceMeat.setId(id);
        }
        return sourceMeat;
    }
}
