package com.sysco.prime.blend;

import com.sysco.prime.productionOrder.Blend;
import com.sysco.prime.productionOrder.response.BlendResponse;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

import static java.util.stream.Collectors.toList;

@RestController
@RequestMapping("/api")
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BlendController {
    private final BlendService service;

    @GetMapping("/blends")
    @ApiOperation(value = "Get blends", notes = "Get all the blends sorted by id.")
    @Secured({"ROLE_ADMIN", "ROLE_PORTION_ROOM_MEMBER", "ROLE_COSTING"})
    public List<BlendResponse> getBlends() {
        return service.allBlends().stream()
                .map(BlendResponse::new)
                .collect(toList());
    }

    @GetMapping(path = "/blendName")
    @ApiOperation(value = "Get blend", notes = "Get blend by name.")
    @Secured({"ROLE_ADMIN", "ROLE_PORTION_ROOM_MEMBER", "ROLE_COSTING"})
    public BlendResponse getBlend(@RequestParam final String blendName) {
        return new BlendResponse(service.getBlend(blendName));
    }
}
