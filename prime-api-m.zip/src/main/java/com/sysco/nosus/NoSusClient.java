package com.sysco.nosus;

import com.sysco.dummysus.RestTemplateSetup;
import com.sysco.prime.cost.Cost;
import com.sysco.prime.customerOrder.PrimeLineItem;
import com.sysco.prime.product.Product;
import com.sysco.prime.purchaseOrder.PurchaseLineItem;
import com.sysco.prime.purchaseOrder.PurchaseOrder;
import com.sysco.prime.sourceMeat.SourceMeatOrder;
import com.sysco.prime.sus.client.SusClient;
import com.sysco.prime.sus.model.SusCustomerData;
import com.sysco.prime.sus.model.product.SusProductData;
import com.sysco.prime.sus.model.stock.SusAsohData;
import com.sysco.prime.yieldModel.YieldModelBase;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Profile;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.Set;

import static java.util.Collections.emptyMap;

@Service
@Profile("nosus")
@Slf4j
public class NoSusClient implements SusClient {
    @Autowired
    public NoSusClient(
            final RestTemplateSetup restTemplateSetup,
            @Value("${sus.service.domain}") final String uriPrefix) throws Exception {
    }

    @Override
    public void sendSourceMeatOrderToSus(
            final SourceMeatOrder sourceMeatOrder,
            final LocalDate shipDate,
            final String opcoNo,
            final String customerNo) {
    }

    @Override
    public SusAsohData getAsohFromSus(final List<String> productCodes, final String businessUnitNumber) {
        return null;
    }

    @Override
    public void sendProductionProductCostToSus(
            final String productCode, final Cost cost,
            final com.sysco.prime.profile.Profile profile) {
    }

    @Override
    public String sendPurchaseOrder(final PurchaseOrder order, final com.sysco.prime.profile.Profile profile) {
        return "1";
    }

    @Override
    public void updatePurchaseOrder(final PurchaseOrder order, final com.sysco.prime.profile.Profile profile) {
    }

    @Override
    public void updateAvailableStocks(
            final com.sysco.prime.profile.Profile profile,
            final List<PrimeLineItem> primeLineItems) {
    }

    @Override
    public Long sendPurchaseOrderReceipt(final PurchaseLineItem lineItem) {
        return -1L;
    }

    @Override
    public void updateItemMaster(
            final Product product,
            final YieldModelBase yieldModel,
            final com.sysco.prime.profile.Profile profile) {
    }

    @Override
    public void updateItemMaster(final Product product,
                                 final Cost cost,
                                 final com.sysco.prime.profile.Profile profile) {
    }

    @Override
    public SusProductData getProductFromSus(final String productCode,
                                            final com.sysco.prime.profile.Profile profile) {
        log.info("Nosusclient for product {}", productCode);
        return null;
    }

    @Override
    public Map<String, SusProductData> getProductsFromSus(final Set<String> productCodes,
                                                          final com.sysco.prime.profile.Profile profile) {
        return emptyMap();
    }

    @Override
    public SusCustomerData getCustomerFromSus(final com.sysco.prime.profile.Profile profile, final String customerId) {
        return null;
    }
}

