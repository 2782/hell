package com.sysco.dummysus;

import com.sysco.prime.cost.Cost;
import com.sysco.prime.customerOrder.CustomerOrder;
import com.sysco.prime.customerOrder.PrimeLineItem;
import com.sysco.prime.product.Product;
import com.sysco.prime.purchaseOrder.PurchaseLineItem;
import com.sysco.prime.purchaseOrder.PurchaseOrder;
import com.sysco.prime.sourceMeat.SourceMeatOrder;
import com.sysco.prime.sus.client.SusClient;
import com.sysco.prime.sus.model.SusCreatePurchaseOrderData;
import com.sysco.prime.sus.model.SusCustomerData;
import com.sysco.prime.sus.model.SusProductCostUpdateData;
import com.sysco.prime.sus.model.SusPurchaseOrderReceipt;
import com.sysco.prime.sus.model.SusUpdatePurchaseOrderData;
import com.sysco.prime.sus.model.product.SusProductData;
import com.sysco.prime.sus.model.product.itemMaster.SusUpdateProductInfoData;
import com.sysco.prime.sus.model.product.salesOrder.SusSalesOrdersData;
import com.sysco.prime.sus.model.stock.SusAsohData;
import com.sysco.prime.sus.model.stock.SusSalesOrderAllocationData;
import com.sysco.prime.yieldModel.YieldModelBase;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Profile;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

import static java.lang.String.format;
import static java.math.BigDecimal.ZERO;
import static java.util.Collections.emptyMap;
import static java.util.Collections.singletonList;

@Service
@Profile("dummysus")
@Slf4j
public class DummySusClient implements SusClient {
    private final RestTemplate restTemplate;
    private final String uriPrefix;

    @Autowired
    public DummySusClient(
            final RestTemplateSetup restTemplateSetup,
            @Value("${sus.service.domain}") final String uriPrefix) throws Exception {
        restTemplate = restTemplateSetup.setup();
        this.uriPrefix = uriPrefix;
    }

    @Override
    public void sendSourceMeatOrderToSus(
            final SourceMeatOrder sourceMeatOrder,
            final LocalDate shipDate,
            final String opcoNo,
            final String customerNo) {
        restTemplate.postForLocation(uriPrefix + "/sales-order",
                SusSalesOrdersData.fromPrime(sourceMeatOrder, shipDate, opcoNo, customerNo));
    }

    @Override
    @Retryable(maxAttempts = 3)
    public SusAsohData getAsohFromSus(final List<String> productCodes, final String businessUnitNumber) {
        return restTemplate.postForObject(uriPrefix + "/asoh/get",
                SusAsohData.from(productCodes, businessUnitNumber), SusAsohData.class);
    }

    @Override
    public void sendProductionProductCostToSus(
            final String productCode, final Cost cost,
            final com.sysco.prime.profile.Profile profile) {
        final SusProductCostUpdateData updatedData = SusProductCostUpdateData.fromPrime(productCode, cost, profile);
        log.info("SUS responded to change finished update {}", updatedData);
        restTemplate.postForLocation(uriPrefix + "/production-product-cost",
                singletonList(updatedData));
    }

    @Override
    public String sendPurchaseOrder(final PurchaseOrder order, final com.sysco.prime.profile.Profile profile) {
        final SusCreatePurchaseOrderData susPurchaseOrder = SusCreatePurchaseOrderData.fromPrime(order, profile);

        final boolean todoSkipUntilSusAcceptsOrderWithNoLineItems = susPurchaseOrder.getDetail().isEmpty();
        if (todoSkipUntilSusAcceptsOrderWithNoLineItems) {
            log.error("FIXME: I reject your attempt to send SUS a PO with no line items until SUS supports that: {}",
                    susPurchaseOrder);
            log.error("FIXME: As a workaround, if this happened while opening a room, configure Par for now");
            return null;
        }

        final boolean todoSkipUntilUserForcedToCompleteProductBeforeAssigningToPar =
                susPurchaseOrder.getDetail().stream()
                        .anyMatch(lineItem -> ZERO.equals(lineItem.getMerchendiserCost()));
        if (todoSkipUntilUserForcedToCompleteProductBeforeAssigningToPar) {
            log.error("FIXME: I reject your attempt to send SUS a PO with line items of 0 cost; require user to"
                    + " provide a yield model: {}", susPurchaseOrder);
            log.error("FIXME: As a workaround, create a yield model for the product, and run it");
            return null;
        }

        return postForObject(restTemplate, uriPrefix + "/purchase-order", susPurchaseOrder, String.class);
    }

    @Override
    public void updatePurchaseOrder(final PurchaseOrder order, final com.sysco.prime.profile.Profile profile) {
        final String url = uriPrefix + "/purchase-order/" + order.getRequestNumber(); // TEMPORARY: using request
        // number till we find out how to handle async confirmation with SUS
        restTemplate.put(url, SusUpdatePurchaseOrderData.fromPrime(order, profile));
    }

    @Override
    public void updateAvailableStocks(
            final com.sysco.prime.profile.Profile profile,
            final List<PrimeLineItem> primeLineItems) {
        final SusSalesOrderAllocationData allocationData = SusSalesOrderAllocationData.from(profile, primeLineItems);
        final String salesOrderNumber = Optional.ofNullable(primeLineItems.get(0).getCustomerOrder())
                .map(CustomerOrder::getOrderNumber).orElse("");

        if (!salesOrderNumber.isEmpty() && allocationData.hasAllocation()) {
            final String uri = format("%s/sales-orders/%s/opcos/%s/allocations", uriPrefix, salesOrderNumber,
                    profile.getPlantNumber());
            restTemplate.postForObject(uri, allocationData,
                    String.class);
        }
    }

    @Override
    public Long sendPurchaseOrderReceipt(final PurchaseLineItem lineItem) {
        final PurchaseOrder order = lineItem.getPurchaseOrder();
        final String uri = uriPrefix + "/purchase-orders"
                + "/opCo/" + order.getOpcoNumber()
                + "/purchase-order/" + order.getPoNumber()
                + "/receipts";
        final SusPurchaseOrderReceipt susPurchaseOrderReceipt = SusPurchaseOrderReceipt.fromPrime(lineItem);

        return postForObject(restTemplate, uri, susPurchaseOrderReceipt, Long.class);
    }

    @Override
    public void updateItemMaster(
            final Product product,
            final YieldModelBase yieldModel,
            final com.sysco.prime.profile.Profile profile) {
        final String uri = format("%s/item-master/v1/items/%s/opcos/%s", uriPrefix,
                product.getCode(), profile.getPlantNumber());
        final SusUpdateProductInfoData request = SusUpdateProductInfoData.fromPrime(yieldModel);
        if (yieldModel.getPrimeCost(product).getCurrentCostPerPound().compareTo(BigDecimal.ZERO) <= 0) {
            log.error("Unit cost is negative for " + product.getCode() + " " + request);
        }
        restTemplate.patchForObject(uri, request, String.class);
    }

    @Override
    public void updateItemMaster(final Product product,
                                 final Cost cost,
                                 final com.sysco.prime.profile.Profile profile) {
        final String uri = format("%s/item-master/v1/items/%s/opcos/%s", uriPrefix,
                product.getCode(), profile.getPlantNumber());
        restTemplate.patchForObject(uri, SusUpdateProductInfoData.fromPrime(cost), String.class);
    }

    @Override
    public SusProductData getProductFromSus(final String productCode,
                                            final com.sysco.prime.profile.Profile profile) {
        final String uri = format("%s/sm/product-info/opcos/%s/products/%s",
                uriPrefix, profile.getPlantNumber(), productCode);

        return getForObject(restTemplate, uri, SusProductData.class);
    }

    @Override
    public Map<String, SusProductData> getProductsFromSus(final Set<String> productCodes,
                                                          final com.sysco.prime.profile.Profile profile) {
        final String uri = format("%s/sm/product-info/opcos/%s/products_map?supcs={supcs}", uriPrefix,
                profile.getPlantNumber());

        final ParameterizedTypeReference<Map<String, SusProductData>> responseType =
                new ParameterizedTypeReference<Map<String, SusProductData>>() {};

        final Map<String, String> uriVariables = new HashMap<>();
        uriVariables.put("supcs", String.join(",", productCodes));

        return Optional.ofNullable(getForObject(restTemplate, uri, responseType, uriVariables))
                .orElse(emptyMap());
    }

    @Override
    public SusCustomerData getCustomerFromSus(final com.sysco.prime.profile.Profile profile, final String customerId) {
        final String uri = format("%s/opcos/%s/customers/%s",
                uriPrefix, profile.getPlantNumber(), customerId);

        return getForObject(restTemplate, uri, SusCustomerData.class);
    }
}
