package com.sysco.dummysus;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface DummySusSusModelRepository extends JpaRepository<SusModel, String> {
    Optional<SusModel> findByTypeAndModelId(SusModel.SusType type, String modelId);

    List<SusModel> findAllByTypeIs(SusModel.SusType type);
}
