package com.sysco.dummysus;

import com.vladmihalcea.hibernate.type.json.JsonBinaryType;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;
import org.hibernate.annotations.TypeDefs;

import javax.persistence.Entity;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import java.io.Serializable;
import java.util.Map;

import static javax.persistence.EnumType.STRING;

@Entity
@Table(schema = "dummysus")
@NoArgsConstructor
@AllArgsConstructor
@TypeDefs(@TypeDef(name = "jsonb", typeClass = JsonBinaryType.class))
@IdClass(CompositeKey.class)
@Data
class SusModel implements Serializable {
    @Id
    private String modelId;

    @Enumerated(STRING)
    @Id
    private SusType type;

    @Type(type = "jsonb")
    private Map<String, Object> data;

    public enum SusType {
        CUSTOMER_ORDER, SALES_ORDER, PRODUCT, PRODUCT_COST,
        CUSTOMER, ASOH, STOCK_ALLOCATION, PURCHASE_ORDER, SALES_ORDER_STATUS, PO_RECEIPT,
        PRODUCT_SYNC
    }
}


