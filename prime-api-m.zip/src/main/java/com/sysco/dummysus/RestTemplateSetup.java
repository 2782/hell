package com.sysco.dummysus;

import org.springframework.web.client.RestTemplate;

public interface RestTemplateSetup {
    RestTemplate setup() throws Exception;
}
