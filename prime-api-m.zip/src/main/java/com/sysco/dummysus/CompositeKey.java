package com.sysco.dummysus;

import edu.umd.cs.findbugs.annotations.SuppressFBWarnings;
import lombok.EqualsAndHashCode;

import java.io.Serializable;

@EqualsAndHashCode
@SuppressFBWarnings("UwF")
class CompositeKey implements Serializable {
    private String modelId;
    private SusModel.SusType type;
}
