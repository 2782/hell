package com.sysco.prime;

import com.sysco.prime.profile.Profile;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.junit.Test;

import java.io.IOException;

import static io.restassured.RestAssured.get;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

public class ProfileIntegrationTest extends IntegrationTestBase {
    @Test
    public void shouldGetPreexistingProfile() throws IOException {
        final Response response = get(getHostName() + "/api/profile")
                .then()
                .statusCode(200)
                .contentType(ContentType.JSON)
                .extract().response();

        final Profile profile = readBodyAs(response, Profile.class);

        assertThat(profile, is(Profile.builder()
                        .plantNumber("332")
                        .name("Buckhead Dallas")
                        .address("4216 Mint Way")
                        .city("Dallas")
                        .zipCode("75237")
                        .establishmentNumber("2213D")
                        .state("TX")
                        .vendorShipFrom(194)
                        .sequenceNumber(1)
                        .build()));
    }
}
