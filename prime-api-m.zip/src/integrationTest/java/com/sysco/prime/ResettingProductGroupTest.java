package com.sysco.prime;

import com.sysco.prime.cost.Cost;
import com.sysco.prime.cost.CostRepository;
import com.sysco.prime.cost.CostSource;
import com.sysco.prime.product.Product;
import com.sysco.prime.product.ProductGroup;
import com.sysco.prime.product.ProductGroupRepository;
import com.sysco.prime.product.ProductOutput;
import com.sysco.prime.product.ProductRepository;
import com.sysco.prime.yieldModel.CuttingYieldModel;
import com.sysco.prime.yieldModel.CuttingYieldModelRepository;
import com.sysco.prime.yieldModel.CuttingYieldModelService;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.HashMap;

import static com.sysco.prime.DummyObjectFactory.cuttingYieldModelBuilder;
import static com.sysco.prime.DummyObjectFactory.productBuilder;
import static com.sysco.prime.product.ProductGroup.cuttingProductGroup;
import static java.util.Collections.singletonList;
import static org.assertj.core.api.AssertionsForInterfaceTypes.assertThat;

public class ResettingProductGroupTest extends IntegrationTestBase {

    @Autowired
    private ProductRepository productRepo;
    @Autowired
    private CuttingYieldModelRepository cuttingYieldModelRepo;
    @Autowired
    private ProductGroupRepository productGroupRepo;
    @Autowired
    private CostRepository costRepo;

    @Autowired
    private CuttingYieldModelService cuttingYieldModelService;

    private static final String productOneCode = "9999990";
    private static final String productTwoCode = "9999991";
    private static final String productThreeCode = "9999993";

    private Product productToChangeGroups;
    private Product sourceProduct;

    @Before
    public void setup() {
        //Create Products and Cost
        final Product oldProductGroupPrimaryProduct = productBuilder()
                .code(productThreeCode)
                .build();

        productToChangeGroups = productBuilder()
                .code(productOneCode)
                .build();

        sourceProduct = productBuilder()
                .productOutput(ProductOutput.SOURCE)
                .code(productTwoCode)
                .productGroup(null).build();

        Cost sourceProductCost = Cost.builder()
                .name(sourceProduct.getCode())
                .source(CostSource.SUS)
                .currentCostPerPound(new BigDecimal("1.00"))
                .marketCost(new BigDecimal("1.00"))
                .startDate(LocalDate.now())
                .endDate(Cost.COST_NEVER_EXPIRES)
                .build();

        costRepo.save(sourceProductCost);

        final Product oldProductGroupPrimaryProductFromDb = productRepo.save(oldProductGroupPrimaryProduct);
        final Product productToChangeGroupsFromDB = productRepo.save(productToChangeGroups);
        final Product sourceProductFromDB = productRepo.save(sourceProduct);

        //Create original ProductGroup
        ProductGroup originalProductGroup = cuttingProductGroup(productToChangeGroupsFromDB);
        //Set Product Group ID so hibernate won't think Product Group is transient
        originalProductGroup.setId(9999L);
        productGroupRepo.save(originalProductGroup);

        // Create Product Group for member assignment
        final ProductGroup oldProductGroup = cuttingProductGroup(oldProductGroupPrimaryProductFromDb);
        oldProductGroup.setId(999L);
        ProductGroup interimProductGroupFromDb = productGroupRepo.save(oldProductGroup);

        //By pass the error thrown if product is already assigned to group for test.
        interimProductGroupFromDb.getMemberProducts().add(productToChangeGroupsFromDB);
        productToChangeGroupsFromDB.setProductGroup(interimProductGroupFromDb);

        //Create YieldModel Associated with Product Groups with ProductToChange Groups As Member
        final CuttingYieldModel oldYieldPricingModel = cuttingYieldModelBuilder()
                .yieldByproducts(null)
                .finishedProductCode(oldProductGroupPrimaryProductFromDb.getCode())
                .sourceProductCode(sourceProductFromDB.getCode())
                .labor(new BigDecimal("1.11"))
                .finishedProductCost(BigDecimal.valueOf(17.65d))
                .pricingModel(true)
                .build();

        cuttingYieldModelRepo.save(oldYieldPricingModel);
    }

    @Test
    public void shouldSetExistingProductGroupWhenCreatingNewPricingModelFromProductGroupMember() {

        final CuttingYieldModel newPricingYieldModel = CuttingYieldModel.builder()
                .finishedProductCode(productToChangeGroups.getCode())
                .sourceProductCode(sourceProduct.getCode())
                .pricingModel(true)
                .build();

        cuttingYieldModelService.createOrUpdateCuttingYieldModels(singletonList(newPricingYieldModel), new HashMap<>());

        final ProductGroup newPricingModelProductGroup = productGroupRepo.findByName(productToChangeGroups.getCode())
                .get();
        final Product updatedProduct = productRepo.findByCode(productToChangeGroups.getCode()).get();

        assertThat(updatedProduct.getProductGroup()).isEqualTo(newPricingModelProductGroup);
    }
}