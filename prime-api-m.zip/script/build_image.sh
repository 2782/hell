#!/usr/bin/env bash

export PS4='+${BASH_SOURCE}:${LINENO}:${FUNCNAME[0]:+${FUNCNAME[0]}():} '

set -e

BUILD_NUMBER=${GO_PIPELINE_COUNTER:-"SNAPSHOT"}

MAJOR_NUMBER=${MAJOR_VERSION}

PROJECT_NAME="prime-api"

cd ../

# Highlight potential perm issues
id
find $PWD \! -user $USER -ls

cp docker/run-app/Dockerfile .

# TODO: need login to docker hub

IMAGE_NAME="sysco/${PROJECT_NAME}:${MAJOR_NUMBER}-${BUILD_NUMBER}"

docker build --rm --tag ${IMAGE_NAME} .

docker push ${IMAGE_NAME}

rm -rf Dockerfile
