#!/usr/bin/env bash

set -e

echo "DOCKER VERSION:"
docker --version

PROJECT_HOME=$(cd `dirname $0`/../ && pwd)
GRADLE_TEST_IMAGE_NAME="sysco/prime:alpine-java8-gradle"
POSTGRES_IMAGE_NAME="postgres"
POSTGRES_HOST="${POSTGRES_IMAGE_NAME}.test"

POSTGRES_CONTAINER_NAME=$(docker ps | grep ${POSTGRES_IMAGE_NAME} | awk '{print $NF}')
POSTGRES_NETWORK_NAME=$(docker network ls | grep ${POSTGRES_IMAGE_NAME} | awk '{print $2}')

docker run --rm -t \
    -v ${HOME}.gradle:/root/.gradle \
    -v ${PROJECT_HOME}:/opt/app \
    --net ${POSTGRES_NETWORK_NAME} \
    -e POSTGRES_HOST=${POSTGRES_HOST} \
    -e SONAR_HOST=${SONAR_HOST} \
    -e JFROG_USERNAME=${JFROG_USERNAME} \
    -e JFROG_PASSWORD=${JFROG_PASSWORD} \
    -w /opt/app \
    ${GRADLE_TEST_IMAGE_NAME} ./gradlew "$@"
