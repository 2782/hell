#!/usr/bin/env python

import unittest

from load_yield_models import parse_additives, \
    parse_byproducts, \
    parse_finishedproducts, \
    pad_with_zeros, \
    parse_cutting_yield_model_row, \
    parse_yield_model_group_row, \
    parse_grinding_yield_model_row, \
    parse_grinding_source_products


class LoadDataTest(unittest.TestCase):
    def test_should_parse_single_cutting_yield_model_row(self):
        row = {
            'Finished Product #': '12345',
            'Source Product #': '5678',
            'Labor': 'LABOR',
            'Packaging': 'PACKAGING',
            'Overhead': 'OVERHEAD',
            'Pricing Model': 'Yes',
            '# of Additives': 1,
            'Additive 1': '346',
            'Weight (lbs) 1': 'WEIGHT',
            '# of Byproducts': 1,
            'Byproduct 1': '12',
            'BP Yield % 1': 'BYPRODUCT_YIELD_PERC',
            'BP Cost 1': 'BYPRODUCT_COST',
            'BP Labor 1': 'BYPRODUCT_LABOR',
            'Source lbs': 'SOURCE_LBS',
            'Pickup %': 'PICKUP_PERCENT'
        }
        result = parse_cutting_yield_model_row(row)
        self.assertEqual(result, {
            "finishedProductCode": '0012345',
            "finishedProductCost": 1,
            "sourceProductCode": '0005678',
            "labor": 'LABOR',
            "packaging": 'PACKAGING',
            "overhead": 'OVERHEAD',
            "pricingModel": True,
            "yieldByproducts": [
                {
                    'byproductCode': '0000012',
                    'yieldPercentage': 'BYPRODUCT_YIELD_PERC',
                    'cost': 'BYPRODUCT_COST',
                    'labor': 'BYPRODUCT_LABOR'
                }
            ],
            "yieldAdditives": [
                {
                    'productCode': '0000346',
                    'weight': 'WEIGHT'
                }
            ],
            "sourceLbs": 'SOURCE_LBS',
            "pickupPercent": 'PICKUP_PERCENT'
        })

    def test_should_parse_single_additive(self):
        row = {
            '# of Additives': 1,
            'Additive 1': 'PRODUCT_CODE',
            'Weight (lbs) 1': 'WEIGHT'
        }

        result = parse_additives(row)
        self.assertEqual(result, [
            {'productCode': 'PRODUCT_CODE', 'weight': 'WEIGHT'}
        ])

    def test_should_not_parse_when_number_of_additives_is_empty_or_zero(self):
        self.assertEqual(parse_additives({'# of Additives': ''}), [])
        self.assertEqual(parse_additives({'# of Additives': '0'}), [])

    def test_should_parse_number_of_additives_specified(self):
        row = {
            '# of Additives': 3,
            'Additive 1': 'PRODUCT_CODE_1',
            'Additive 2': 'PRODUCT_CODE_2',
            'Additive 3': 'PRODUCT_CODE_3',
            'Weight (lbs) 1': 'WEIGHT_1',
            'Weight (lbs) 2': 'WEIGHT_2',
            'Weight (lbs) 3': 'WEIGHT_3',
        }
        result = parse_additives(row)
        self.assertEqual(result, [
            {'productCode': 'PRODUCT_CODE_1', 'weight': 'WEIGHT_1'},
            {'productCode': 'PRODUCT_CODE_2', 'weight': 'WEIGHT_2'},
            {'productCode': 'PRODUCT_CODE_3', 'weight': 'WEIGHT_3'}
        ])

    def test_should_parse_single_byproduct(self):
        row = {
            '# of Byproducts': 1,
            'Byproduct 1': 'PRODUCT_CODE',
            'BP Yield % 1': 'YIELD_PERCENTAGE',
            'BP Cost 1': 'COST',
            'BP Labor 1': 'LABOR'
        }

        result = parse_byproducts(row)
        self.assertEqual(result, [
            {'byproductCode': 'PRODUCT_CODE', 'yieldPercentage': 'YIELD_PERCENTAGE', 'cost': 'COST', 'labor': 'LABOR'}
        ])

    def test_should_not_parse_when_number_of_byproducts_is_empty_or_zero(self):
        self.assertEqual(parse_byproducts({'# of Byproducts': ''}), [])
        self.assertEqual(parse_byproducts({'# of Byproducts': '0'}), [])

    def test_should_parse_number_of_byproducts_specified(self):
        row = {
            '# of Byproducts': 2,
            'Byproduct 1': 'PRODUCT_CODE_1',
            'BP Yield % 1': 'YIELD_PERCENTAGE_1',
            'BP Cost 1': 'COST_1',
            'BP Labor 1': 'LABOR_1',
            'Byproduct 2': 'PRODUCT_CODE_2',
            'BP Yield % 2': 'YIELD_PERCENTAGE_2',
            'BP Cost 2': 'COST_2',
            'BP Labor 2': 'LABOR_2'
        }

        result = parse_byproducts(row)
        self.assertEqual(result, [
            {'byproductCode': 'PRODUCT_CODE_1', 'yieldPercentage': 'YIELD_PERCENTAGE_1', 'cost': 'COST_1',
             'labor': 'LABOR_1'},
            {'byproductCode': 'PRODUCT_CODE_2', 'yieldPercentage': 'YIELD_PERCENTAGE_2', 'cost': 'COST_2',
             'labor': 'LABOR_2'}
        ])

    def test_should_pad_short_product_codes_less_than_seven_chars_with_leading_zeros(self):
        self.assertEqual(pad_with_zeros('123'), '0000123')
        self.assertEqual(pad_with_zeros('1234567'), '1234567')
        self.assertEqual(pad_with_zeros('12345678910'), '12345678910')

    def test_should_parse_single_grinding_yield_model_row(self):
        row = {
            'Blend Name': 'Brisket Blend',
            'Waste %': 2,
            'Labor': 2.23,
            'Additives': 0.2,
            'Packaging': 1.22,
            'Overhead': 0.38,
            'Pricing Model': 'Yes',
            '# of Source Products': 3,
            'Source 1': '3199233',
            'Blend % 1': 50,
            'Source 2': '1663364',
            'Blend % 2': 30,
            'Source 3': '2423501',
            'Blend % 3': 20
        }
        result = parse_grinding_yield_model_row(row)
        self.assertEqual(result, {
            "blend": "Brisket Blend",
            "pricingModel": True,
            "wastePercentage": 2,
            "additives": 0.2,
            "packaging": 1.22,
            "labor": 2.23,
            "overhead": 0.38,
            "sourceProducts": [
                {
                    "code": "3199233",
                    "blendPercentage": 50
                },
                {
                    "code": "1663364",
                    "blendPercentage": 30
                },
                {
                    "code": "2423501",
                    "blendPercentage": 20
                }
            ]
        })

    def test_should_parse_single_grinding_source_product(self):
        row = {
            '# of Source Products': 1,
            'Source 1': 'PRODUCT_CODE',
            'Blend % 1': 'BLEND_PERCENTAGE'
        }

        result = parse_grinding_source_products(row)
        self.assertEqual(result, [
            {'code': 'PRODUCT_CODE', 'blendPercentage': 'BLEND_PERCENTAGE'}
        ])

    def test_should_not_parse_when_number_of_grinding_source_products_are_empty_or_zero(self):
        self.assertEqual(parse_grinding_source_products({'# of Source Products': ''}), [])
        self.assertEqual(parse_grinding_source_products({'# of Source Products': '0'}), [])

    def test_should_parse_number_of_grinding_source_products_specified(self):
        row = {
            '# of Source Products': 3,
            'Source 1': 'PRODUCT_CODE_1',
            'Source 2': 'PRODUCT_CODE_2',
            'Source 3': 'PRODUCT_CODE_3',
            'Blend % 1': 'BLEND_PERCENTAGE_1',
            'Blend % 2': 'BLEND_PERCENTAGE_2',
            'Blend % 3': 'BLEND_PERCENTAGE_3'
        }
        result = parse_grinding_source_products(row)
        self.assertEqual(result, [
            {'code': 'PRODUCT_CODE_1', 'blendPercentage': 'BLEND_PERCENTAGE_1'},
            {'code': 'PRODUCT_CODE_2', 'blendPercentage': 'BLEND_PERCENTAGE_2'},
            {'code': 'PRODUCT_CODE_3', 'blendPercentage': 'BLEND_PERCENTAGE_3'}
        ])

    def test_should_parse_single_yield_model_group_row(self):
            row = {
                'Primary Product Number / Blend Name': 'Natural',
                'Finished 1': '2184768'
            }
            result = parse_yield_model_group_row(row)
            self.assertEqual(result, {
                "productGroupName": 'Natural',
                "finishedProductCodes": ['2184768']
            })

    def test_should_parse_finishedproduct_with_blanks(self):
        row = {
            'Finished 1': '',
            'Finished 2': 'PRODUCT_CODE_1',
            'Finished 3': '',
            'Finished 4': 'PRODUCT_CODE_2',
        }

        result = parse_finishedproducts(row)
        self.assertEqual(result, ['PRODUCT_CODE_1', 'PRODUCT_CODE_2'])


    def test_should_parse_single_finishedproduct(self):
        row = {
            'Finished 1': '2184768'
        }

        result = parse_finishedproducts(row)
        self.assertEqual(result, ['2184768'])

    def test_should_parse_number_of_finishedproducts_specified(self):
        row = {
            'Finished 1': 'PRODUCT_CODE_1',
            'Finished 2': 'PRODUCT_CODE_2',
            'Finished 3': 'PRODUCT_CODE_3'
        }
        result = parse_finishedproducts(row)
        self.assertEqual(result, [
            'PRODUCT_CODE_1', 'PRODUCT_CODE_2', 'PRODUCT_CODE_3'
        ])

if __name__ == '__main__':
    unittest.main()
