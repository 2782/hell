# Prime API

For operation-support and production, see [PRODUCTION.md](PRODUCTION.md).

Export Restful API for portion room resource.

See [GitHub repo](https://github.aws.na.sysco.net/prime/prime-api).

## Getting Started

Consider setting *per-project* Git name/email, rather than global:
```bash
$ git config user.name 'Your Display Name'
$ git config user.email 'urnm1234@corp.sysco.com'
```

### Prerequisites

Install Java 8 with the JDK and PostgreSQL.  This project does not build
with Java 9 or higher.

Make sure your `$JAVA_HOME` environment variable is set. On a Mac, you can add
the following line in your shell profile:

```bash
export JAVA_HOME=$(/usr/libexec/java_home -v 1.8)
```

If you use the very excellent [jEnv](http://www.jenv.be/), you can set up the
right Java version when you `cd` into the project (after following instructions
to teach jEnv about your installed Java versions -- see web site):

```bash
cd where-you-cloned-prime-api
jenv local 1.8
```

### First time setup

##### Either (if you're on a Mac)
  1. Run `./run-prime.sh`.  It installs PostgreSQL on Mac, and install Gradle
     local to the project.
     
(This is also helpful for resetting your DB, say after switching branches, and
confusing Liquibase.)

##### Or
  1. Make sure to stop any local psql services if they are running. For
     example, `pg_ctl stop` or `brew services stop postgres`.
  1. Run `docker-compose up -d` to start a Postgres Docker container in daemon
     mode.
  2. Run `gradlew` to install Gradle
  
##### IntelliJ Setup
  1. Open (don't import) the project root directory in IntelliJ
  1. [Install the lombok plugin and restart
     IntelliJ](https://github.com/mplushnikov/lombok-intellij-plugin#installation)
  1. [Enable annotation
     processing](https://github.com/mplushnikov/lombok-intellij-plugin#installation)
  1. You may to to rebuild the project afterwards

### Refresh your test data

```bash
$ source local-env  # Docker only
$ ./run-prime.sh reset-data
```

Edit `api-test/resources/database/insert_data.sql` to change the test data.
*Caution!*  This test data is used for:

1. API tests
2. QA
3. Showcase

So only edit as part of a story, and *highlight in a desk check* when editing
the data.

### Starting over

If you get your local database into a bad state, eg, schema changes or
liquibase changelog problems, you can start over; it's harmless (except to lose
your changes which broke your database, which is why you're reading this
section):

##### Local Postgres (re-)installation:
```bash
$ ./run-prime.sh  # Walks you through the process, including deleting current DB!
```

##### Docker container postgres:
```bash
$ docker-compose down
$ docker-compose up -d
$ ./run-prime.sh update-liquibase  # Runs migrations
$ ./run-prime.sh reset-data docker 
```

## Running Prime-API with local authentication turned on
The IDM team has setup a Prime Local app in the Azure workspace. This targets your localhost computer and requires that
you have your prime-ui and prime-api running in authentication mode. For prime-api, this entails using the dummyauth
profile. 

This configuration for prime sets up our application to accept only HTTPS requests locally (a requirement of Azure). For
this to work, we have created a self-signed and self-certified certificate that is loaded in both the keystore and 
truststore in resources/dummyauth. 

However, we currently are seeing behavior where setting the profile from the command line drops the profiles
specified in the application-dummyauth.properties. To run correctly, you will have to run: 
```bash
$ ./gradlew bootrun -Dspring.profiles.active=dummyauth,dummyscale,dummysus,dummyprinter 
```

## Running the tests

The default for Gradle is to run `clean build`.

```bash
$ ./gradlew
# Or
$ ./run-prime.sh full-build  # Also ensures Postgres is sane
```

Run gradle to start app on `http://localhost:8081`.  You do not interact
directly with the API; the UI will contact this URL.  Use this command:

```bash
$ ./gradlew bootRun
# Or
$ ./run-prime.sh app  # Also ensures Postgres is sane
```

## Before pushing commits to origin

Please run API tests before pushing commits:

```bash
$ ./run-prime.sh api-tests
```

If not output appears, it passes!

NB: This will reset your database (`test_data.sh reset`).

## Liquibase

There are a series of tasks provided in Gradle by Liquibase.  These tasks
apply to both the `prime` (runtime) and `prime-test` (unit tests) database
instances.  Among the most useful are:

* `update` -- applies changelogs to bring the databases to "current"
* `rollbackCount` -- undoes changelogs in reverse chrono order.
  Example rolling back latest changelog:
   ```
   $ ./run-prime.sh rollback-liquibase 1
   # Or
   $ ./gradlew -PliquibaseCommandValue=1 rollbackCount
   ```

## Solutions to common problems

### Q. CI SonarQube fell over with the complaint, "No quality profiles have been found, you probably don't have any language plugin installed"

*Answer*:

1. Go to http://prime-sonarqube.aws.na.sysco.net/admin/marketplace.
2. Login as `admin`/`admin`.
3. Search for a Java plugin.
4. Install the SonarJava quality profile.
5. Repeat for JavaScript.
6. Use the restart UI button.
7. Re-run the failed pipeline stage.

## Deployment

Auto deploy to dev env by [CI](http://prime-gocd.aws.na.sysco.net/go/pipelines)

## Built With

* [Gradle](https://gradle.org/)
* [Spring Boot](https://projects.spring.io/spring-boot/)
* [Spring Data](http://projects.spring.io/spring-data/)

